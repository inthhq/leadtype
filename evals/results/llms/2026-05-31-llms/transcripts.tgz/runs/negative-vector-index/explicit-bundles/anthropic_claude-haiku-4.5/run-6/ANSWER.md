# Leadtype Vector Index Answer

## Question
Does Leadtype include a hosted database-backed vector index by default? If not, what does it use by default and when would embeddings be added?

## Answer

**No**, Leadtype does not include a hosted database-backed vector index by default.

### What Leadtype Uses by Default

Leadtype builds a **static local search index** over generated markdown at build time. The default search approach uses **lexical BM25-style ranking** over:
- Titles
- Headings
- Body text
- Code

This search runtime is **edge-safe** and **does not require a database**.

### When Embeddings Should Be Added

According to Leadtype's documentation, embeddings (and thus a vector index) should be added only in these specific scenarios:

1. **When docs vocabulary does not match user vocabulary** — If users are searching for concepts using different terminology than what appears in the documentation
2. **When the corpus grows large enough to need semantic retrieval** — As documentation scales and keyword-based BM25 ranking becomes insufficient

The guidance is clear: embeddings are an optional enhancement, not a default requirement, and should only be introduced when there's a specific need for semantic search capabilities beyond what lexical ranking provides.
