# Does Leadtype include a hosted database-backed vector index by default?

**No.** Leadtype does **not** include a hosted database-backed vector index by default.

## What it uses by default

Leadtype builds a **static local search index** over the generated markdown at build time. The runtime query path is **edge-safe and does not require a database**.

The default search path uses **lexical, BM25-style ranking** over titles, headings, body text, and code. This search output can feed source-grounded answer generation.

## When embeddings would be added

Embeddings are **not** part of the default setup. You would add embeddings **only when**:

- The docs vocabulary does not match the user's vocabulary, or
- The corpus grows large enough to need semantic retrieval.

In other words, embeddings/semantic vector retrieval are an opt-in addition for vocabulary-mismatch or large-corpus cases—not a default component.

## Source

- `/docs/reference/search.md` (via `/docs/llms-full/reference.txt`), reached from `/llms.txt`.
