# Leadtype Vector Index and Default Search

## Direct Answer

**No**, Leadtype does not include a hosted database-backed vector index by default.

## What It Uses By Default

Leadtype builds a **static local search index** over generated markdown at build time. The default search implementation uses:

- **Lexical BM25-style ranking** over titles, headings, body text, and code
- **Edge-safe runtime query path** that does not require a database
- Static index generation that happens during the build process

## When Embeddings Would Be Added

According to the documentation, embeddings should be added only in these circumstances:

1. **When docs vocabulary does not match user vocabulary** - If the terminology in the documentation differs significantly from how users search for information
2. **When the corpus grows large enough** - Semantic retrieval becomes beneficial as the documentation corpus expands

The documentation explicitly states that search output can feed source-grounded answer generation, emphasizing that the static lexical search approach is sufficient for many use cases before investing in embeddings infrastructure.
