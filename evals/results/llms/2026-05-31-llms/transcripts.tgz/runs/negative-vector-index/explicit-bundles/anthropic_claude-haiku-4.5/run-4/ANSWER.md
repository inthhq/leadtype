# Leadtype Default Search Implementation

## Question
Does Leadtype include a hosted database-backed vector index by default? If not, what does it use by default and when would embeddings be added?

## Answer

**No**, Leadtype does not include a hosted database-backed vector index by default.

### What it Uses by Default
Leadtype builds a **static local search index** over generated markdown at build time. The default search uses **lexical BM25-style ranking** over titles, headings, body text, and code. The runtime query path is edge-safe and does not require a database.

### When Embeddings Would be Added
Embeddings should be added only when:
1. **Docs vocabulary does not match user vocabulary**, OR
2. **The corpus grows large enough to need semantic retrieval**

In other words, embeddings are optional and should only be used when lexical search is insufficient for the use case.

Source: /docs/reference/search.md
