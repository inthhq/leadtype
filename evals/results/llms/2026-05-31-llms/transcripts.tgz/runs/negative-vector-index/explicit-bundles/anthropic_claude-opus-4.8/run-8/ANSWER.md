# Does Leadtype include a hosted database-backed vector index by default?

**No.** Per the Leadtype Search reference (`/docs/reference/search.md`), Leadtype does **not** include a hosted database-backed vector index by default.

## What it uses by default

Leadtype builds a **static local search index** over the generated markdown at build time. Key characteristics:

- The runtime query path is **edge-safe and does not require a database**.
- The default search path uses **lexical, BM25-style ranking** over titles, headings, body text, and code.
- Search output can feed **source-grounded answer generation**.

## When would embeddings be added?

Embeddings should be added **only when**:

- The **docs vocabulary does not match user vocabulary** (i.e., users search with different terms than the docs use), or
- The **corpus grows large enough to need semantic retrieval**.

In other words, embeddings/semantic search are an opt-in addition for specific cases, not the default behavior.

---

*Sources: `/docs/reference/search.md` (via the Reference full-context bundle, `/docs/llms-full/reference.txt`).*
