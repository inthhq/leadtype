# Leadtype Vector Index Default Configuration

## Answer

**No, Leadtype does not include a hosted database-backed vector index by default.**

## What It Uses by Default

By default, Leadtype builds a **static local search index** over generated markdown at build time using **lexical BM25-style ranking**. This index:

- Ranks over titles, headings, body text, and code
- Uses an edge-safe runtime query path
- Requires no database
- Can feed source-grounded answer generation

## When to Add Embeddings

According to the documentation, embeddings should be added **only when one of these conditions is met**:

1. **Docs vocabulary does not match user vocabulary** - When the terminology used in the documentation significantly differs from how users search for information
2. **Corpus grows large enough to need semantic retrieval** - When the documentation set becomes substantial enough that lexical matching becomes insufficient for relevance

Source: Leadtype's Search reference documentation states: "Add embeddings only when docs vocabulary does not match user vocabulary or the corpus grows large enough to need semantic retrieval."
