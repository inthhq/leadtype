# Does Leadtype Include a Hosted Database-Backed Vector Index by Default?

## Answer

No, Leadtype does **not** include a hosted database-backed vector index by default.

## What It Uses By Default

By default, Leadtype uses a **static local search index** built at build time, which employs **lexical BM25-style ranking** over:
- Titles
- Headings
- Body text
- Code

This search index is edge-safe and does not require a database.

## When Embeddings Would Be Added

According to the documentation, embeddings should be added only when:

1. **Docs vocabulary does not match user vocabulary** - When users search with different terminology than what appears in the documentation, semantic search via embeddings can help bridge that gap
2. **The corpus grows large enough to need semantic retrieval** - As the documentation grows, lexical ranking alone may become insufficient, making semantic understanding valuable

The key principle is that embeddings are an optional enhancement rather than a default component, to be considered only when specific needs justify their addition.
