# Does Leadtype include a hosted database-backed vector index by default?

**No.** According to the Leadtype docs ([Search reference](/docs/reference/search.md)), Leadtype does **not** include a hosted database-backed vector index by default.

## What it uses by default

Leadtype builds a **static local search index** over generated markdown at build time. The default search path uses **lexical, BM25-style ranking** over titles, headings, body text, and code.

The runtime query path is **edge-safe and does not require a database**. Search output can also feed source-grounded answer generation.

## When would embeddings be added?

Embeddings are an opt-in addition, not a default. You should add embeddings **only when**:

- The docs vocabulary does not match the user's vocabulary, or
- The corpus grows large enough to need semantic retrieval.

In other words, start with the default lexical (BM25) search, and only layer in embeddings/semantic retrieval if those specific conditions arise.
