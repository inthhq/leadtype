# Does Leadtype include a hosted database-backed vector index by default?

**No.** Leadtype does **not** include a hosted database-backed vector index by default.

## What it uses by default

Leadtype builds a **static local search index** over generated markdown at build time. The runtime query path is **edge-safe and does not require a database**.

The default search path uses **lexical BM25-style ranking** over titles, headings, body text, and code. This search output can feed source-grounded answer generation.

## When would embeddings be added?

Embeddings should be added **only when**:

- The docs vocabulary does not match the user vocabulary, **or**
- The corpus grows large enough to need semantic retrieval.

In other words, embeddings are an opt-in enhancement for semantic search, not part of the default lexical setup.

---

*Source: `/docs/reference/search.md` (via `/llms.txt` → Reference bundle).*
