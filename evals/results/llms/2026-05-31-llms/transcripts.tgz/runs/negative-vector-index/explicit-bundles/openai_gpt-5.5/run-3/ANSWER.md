No. Leadtype does **not** include a hosted database-backed vector index by default.

By default, it builds a **static local search index** over generated markdown at build time. Runtime search is **edge-safe** and does not require a database. The default ranking is lexical, BM25-style search over titles, headings, body text, and code.

Embeddings would be added only when they are needed—for example, when the docs vocabulary does not match the users’ vocabulary, or when the corpus becomes large enough to require semantic retrieval.
