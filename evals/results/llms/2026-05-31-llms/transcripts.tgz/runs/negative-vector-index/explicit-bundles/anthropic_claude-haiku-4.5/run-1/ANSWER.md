# Leadtype Vector Index Question

## Answer

**No**, Leadtype does not include a hosted database-backed vector index by default.

### What It Uses By Default

By default, Leadtype uses a **static local search index** built at build time with **lexical BM25-style ranking** over titles, headings, body text, and code. This is an edge-safe approach that does not require a database and works at runtime without database connectivity.

### When Embeddings Would Be Added

According to the documentation, embeddings should be added only when:

1. **Docs vocabulary does not match user vocabulary**, or
2. **The corpus grows large enough to need semantic retrieval**

In other words, embeddings should be considered as an enhancement for cases where lexical search (BM25 ranking) is insufficient due to vocabulary mismatch or scale considerations, but they are not included or necessary by default.

## Source

This information comes from the [Search reference page](/docs/reference/search.md) in the Leadtype documentation.
