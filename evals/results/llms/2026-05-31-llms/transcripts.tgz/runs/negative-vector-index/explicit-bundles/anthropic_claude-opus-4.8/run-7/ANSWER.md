# Does Leadtype include a hosted database-backed vector index by default?

**No.** According to the Leadtype docs (`/docs/reference/search.md`), Leadtype does **not** include a hosted database-backed vector index by default.

## What it uses by default

Leadtype builds a **static local search index** over generated markdown at build time. Key characteristics:

- The runtime query path is **edge-safe and does not require a database**.
- The default search path uses **lexical, BM25-style ranking** over titles, headings, body text, and code.
- Search output can feed **source-grounded answer generation**.

The generated search artifacts are static files (`docs/search-index.json` and `docs/search-content.json`).

## When would embeddings be added?

Embeddings are **not** part of the default setup. You should add embeddings **only when**:

- The docs vocabulary does not match the user vocabulary, **or**
- The corpus grows large enough to need **semantic retrieval**.

In other words, embeddings (and any vector-based semantic search) are an optional enhancement to address vocabulary mismatch or large-corpus semantic search needs—not a default component.
