# Does Leadtype include a hosted database-backed vector index by default?

**No.** Leadtype does **not** include a hosted database-backed vector index by default.

## What it uses by default

Leadtype builds a **static local search index** over the generated markdown at build time. Its default search path uses **lexical, BM25-style ranking** over titles, headings, body text, and code. The runtime query path is **edge-safe and does not require a database**. Search output can also feed source-grounded answer generation.

## When embeddings would be added

Embeddings are an opt-in addition, not a default. You should add embeddings only when:

- The **docs vocabulary does not match the user vocabulary** (so lexical matching misses relevant results), or
- The **corpus grows large enough** to need semantic retrieval.

In short: start with the default static, database-free BM25-style lexical index, and introduce embeddings/semantic retrieval only when vocabulary mismatch or corpus size justifies it.

---
*Source: `/docs/reference/search.md` (via `/llms.txt` → Reference bundle).*
