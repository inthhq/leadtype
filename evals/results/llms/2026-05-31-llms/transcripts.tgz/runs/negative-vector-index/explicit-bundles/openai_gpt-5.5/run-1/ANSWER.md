No. Leadtype does **not** include a hosted database-backed vector index by default.

By default, it builds a **static local search index** at build time over generated markdown. The runtime search path is edge-safe and database-free, using **lexical BM25-style ranking** over titles, headings, body text, and code.

Embeddings would be added only when the docs vocabulary does not match user vocabulary, or when the corpus grows large enough to need semantic retrieval.
