# Leadtype Vector Index Default

## Answer

No, Leadtype does not include a hosted database-backed vector index by default.

## What It Uses By Default

Leadtype builds a **static local search index** at build time using **lexical BM25-style ranking** over:
- Titles
- Headings
- Body text
- Code

This search index is **edge-safe** and does not require a database. The search artifacts are generated and deployed as static files.

## When Embeddings Would Be Added

According to the documentation, embeddings should be added only in these cases:

1. **When docs vocabulary does not match user vocabulary** - semantic retrieval helps when the terminology users search for differs from the terminology used in the docs
2. **When the corpus grows large enough to need semantic retrieval** - for larger documentation sets where lexical search alone becomes insufficient

Source: [Leadtype Search Reference](/docs/reference/search.md)
