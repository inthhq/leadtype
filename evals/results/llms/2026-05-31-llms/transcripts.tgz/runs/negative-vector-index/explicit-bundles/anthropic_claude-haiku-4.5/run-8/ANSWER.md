# Does Leadtype Include a Hosted Database-Backed Vector Index by Default?

## Answer

No, Leadtype does **not** include a hosted database-backed vector index by default.

## What Does It Use By Default?

By default, Leadtype builds a **static local search index** using **lexical BM25-style ranking** over titles, headings, body text, and code. This search index is generated at build time and is edge-safe, meaning it does not require a database at runtime.

## When Would Embeddings Be Added?

According to the documentation, embeddings should be added only when:

1. **Docs vocabulary does not match user vocabulary**, OR
2. **The corpus grows large enough to need semantic retrieval**

In other words, embeddings are an optional enhancement rather than a default feature, and should be implemented specifically when lexical search proves insufficient for the particular documentation needs.

---

*Source: /docs/reference/search.md from the Leadtype docs site*
