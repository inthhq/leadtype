No. Leadtype does **not** include a hosted database-backed vector index by default.

By default, it builds a **static local search index** over generated markdown at build time. Runtime search is edge-safe, database-free, and uses **lexical BM25-style ranking** over titles, headings, body text, and code. Search results can then feed source-grounded answer generation.

Embeddings would be added only when lexical search is not enough—for example, when the docs' vocabulary does not match users' vocabulary, or when the corpus grows large enough to require semantic retrieval.
