No. Leadtype does **not** include a hosted database-backed vector index by default.

By default, Leadtype builds a **static local search index** over generated Markdown at build time. Its runtime query path is edge-safe and database-free, using **lexical BM25-style ranking** over titles, headings, body text, and code.

Embeddings would be added only when needed—for example, when the docs’ vocabulary does not match users’ vocabulary, or when the corpus becomes large enough to require semantic retrieval.
