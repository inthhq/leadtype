# Does Leadtype include a hosted database-backed vector index by default?

**No.** According to the Leadtype Search reference (`/docs/reference/search.md`), Leadtype does **not** include a hosted database-backed vector index by default.

## What it uses by default

Leadtype builds a **static local search index** over the generated markdown at build time. The runtime query path is **edge-safe and does not require a database**.

The default search path uses **lexical, BM25-style ranking** over titles, headings, body text, and code. This search output can also feed source-grounded answer generation.

## When embeddings would be added

Embeddings are an opt-in addition, not part of the default. You should add embeddings only when:

- The **docs vocabulary does not match the user vocabulary**, or
- The **corpus grows large enough to need semantic retrieval**.

In other words, start with the default lexical static index and introduce embeddings/semantic search only when lexical matching is no longer sufficient.

## Source

- `/docs/reference/search.md` (via the Reference full-context bundle, linked from `/llms.txt`)
