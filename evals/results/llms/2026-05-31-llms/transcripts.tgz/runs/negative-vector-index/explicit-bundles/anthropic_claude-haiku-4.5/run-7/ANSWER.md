# Leadtype Vector Index Question

## Answer

**No**, Leadtype does not include a hosted database-backed vector index by default.

## What It Uses By Default

By default, Leadtype builds a **static local search index** over generated markdown at build time. The default search path uses **lexical BM25-style ranking** over titles, headings, body text, and code. This runtime query path is edge-safe and does not require a database.

## When Embeddings Would Be Added

Embeddings should be added only when:
1. **Docs vocabulary does not match user vocabulary**, or
2. **The corpus grows large enough to need semantic retrieval**

In other words, embeddings are an optional enhancement for semantic search capabilities rather than a default feature.

### Source
[/docs/reference/search.md](docs/reference/search.md)
