No. Leadtype does **not** include a hosted database-backed vector index by default.

By default, Leadtype builds a **static local search index** over generated markdown at build time. Its runtime query path is edge-safe and does not require a database, using **lexical BM25-style ranking** over titles, headings, body text, and code.

Embeddings would be added only when they are needed—specifically, when the docs vocabulary does not match users’ vocabulary, or when the corpus grows large enough to require semantic retrieval.
