# Leadtype Vector Index Answer

## Does Leadtype include a hosted database-backed vector index by default?

**No**, Leadtype does not include a hosted database-backed vector index by default.

## What does it use by default?

By default, Leadtype builds a **static local search index** using **lexical BM25-style ranking** over:
- Titles
- Headings
- Body text
- Code

This static search index is:
- Built at build time
- Edge-safe for runtime querying
- Does not require a database

## When would embeddings be added?

Embeddings should be added only when:
1. **Docs vocabulary does not match user vocabulary**, OR
2. **The corpus grows large enough to need semantic retrieval**

In other words, embeddings are an optional enhancement for improving search quality in specific situations, not a default feature.

---

Source: [Search Reference](/docs/reference/search.md)
