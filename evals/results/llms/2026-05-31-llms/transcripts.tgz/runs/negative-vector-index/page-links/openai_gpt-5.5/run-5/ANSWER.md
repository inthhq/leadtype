No. Leadtype does not include a hosted database-backed vector index by default.

By default, it builds a static local search index over generated markdown at build time. Runtime search is edge-safe, database-free, and uses lexical BM25-style ranking over titles, headings, body text, and code.

Embeddings would be added only when the docs vocabulary does not match user vocabulary, or when the corpus becomes large enough to need semantic retrieval.
