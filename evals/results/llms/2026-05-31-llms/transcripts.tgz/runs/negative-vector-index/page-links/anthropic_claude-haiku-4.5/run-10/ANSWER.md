# Leadtype Default Search Architecture

## Does Leadtype include a hosted database-backed vector index by default?

**No.** Leadtype does not include a hosted database-backed vector index by default.

## What does it use by default?

By default, Leadtype builds a **static local search index** using **lexical BM25-style ranking** over:
- Titles
- Headings
- Body text
- Code

The index is generated at build time and the runtime query path is edge-safe, requiring no database.

## When would embeddings be added?

According to the documentation, embeddings should be added only when:
1. **Docs vocabulary does not match user vocabulary**, OR
2. **The corpus grows large enough to need semantic retrieval**

In other words, embeddings are optional enhancements added only when the default lexical search is insufficient for your specific use case.
