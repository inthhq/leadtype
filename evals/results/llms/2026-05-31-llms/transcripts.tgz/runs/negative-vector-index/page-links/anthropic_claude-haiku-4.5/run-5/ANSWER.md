# Leadtype Vector Index Answer

## Does Leadtype include a hosted database-backed vector index by default?

**No**, Leadtype does not include a hosted database-backed vector index by default.

## What does it use by default?

By default, Leadtype uses a **static local search index** built at build time with **lexical BM25-style ranking** over titles, headings, body text, and code. The runtime query path is edge-safe and does not require a database.

## When would embeddings be added?

According to the documentation, embeddings should be added only when:
1. **Docs vocabulary does not match user vocabulary**, OR
2. **The corpus grows large enough to need semantic retrieval**

In other words, embeddings are an optional addition for improving search quality in specific scenarios, not a default feature.
