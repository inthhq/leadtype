# Leadtype Vector Index and Embeddings

## Does Leadtype include a hosted database-backed vector index by default?

**No**, Leadtype does not include a hosted database-backed vector index by default.

## What does it use by default?

By default, Leadtype builds a **static local search index** over generated markdown at build time. The default search uses **lexical BM25-style ranking** over:
- Titles
- Headings
- Body text
- Code

The runtime query path is edge-safe and does not require a database.

## When would embeddings be added?

According to the documentation, embeddings should be added only when:

1. **Docs vocabulary does not match user vocabulary**, OR
2. **The corpus grows large enough to need semantic retrieval**

In other words, embeddings are optional enhancements to consider for specific use cases, not a default component of Leadtype.

**Source:** /docs/reference/search.md
