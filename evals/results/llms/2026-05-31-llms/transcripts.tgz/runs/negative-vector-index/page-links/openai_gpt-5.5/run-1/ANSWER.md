No. Leadtype does **not** include a hosted database-backed vector index by default.

By default, it builds a **static local search index** at build time over the generated markdown. The runtime query path is edge-safe, database-free, and uses **lexical BM25-style ranking** across titles, headings, body text, and code.

Embeddings would be added only when they are useful for semantic retrieval—for example, when the docs vocabulary does not match the user vocabulary, or when the corpus grows large enough that lexical search is no longer sufficient.
