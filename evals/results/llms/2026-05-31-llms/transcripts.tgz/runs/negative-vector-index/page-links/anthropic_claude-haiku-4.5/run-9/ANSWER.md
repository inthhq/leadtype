# Leadtype Vector Index and Database Question

## Answer

**Does Leadtype include a hosted database-backed vector index by default?**

No, Leadtype does not include a hosted database-backed vector index by default.

## What Does It Use By Default?

By default, Leadtype uses a **static local search index** built at build time with:
- **Lexical BM25-style ranking** over titles, headings, body text, and code
- An **edge-safe runtime query path** that does not require a database

## When Would Embeddings Be Added?

According to the documentation, embeddings should be added in these scenarios:
1. When docs vocabulary does not match user vocabulary
2. When the corpus grows large enough to need semantic retrieval

---

*Source: [/docs/reference/search.md](/docs/reference/search.md)*
