# Does Leadtype include a hosted database-backed vector index by default?

**No.** Leadtype does not include a hosted database-backed vector index by default.

## What it uses by default

Leadtype builds a **static local search index** over the generated markdown at build time. Key characteristics:

- The runtime query path is **edge-safe** and **does not require a database**.
- The default search path uses **lexical BM25-style ranking** over titles, headings, body text, and code.
- Search output can feed **source-grounded answer generation**.

## When would embeddings be added?

Embeddings should be added **only when**:

- The docs vocabulary does not match the user's vocabulary, **or**
- The corpus grows large enough to need **semantic retrieval**.

---

*Source: [/docs/reference/search.md](/docs/reference/search.md)*
