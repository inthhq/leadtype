# Does Leadtype include a hosted database-backed vector index by default?

**No.** According to the Leadtype docs (`/docs/reference/search.md`), Leadtype does **not** include a hosted database-backed vector index by default.

## What it uses by default

Leadtype builds a **static local search index** over the generated markdown at build time. Key characteristics:

- The runtime query path is **edge-safe** and does **not require a database**.
- The default search path uses **lexical BM25-style ranking** over titles, headings, body text, and code.
- Search output can feed **source-grounded answer generation**.

The build emits search artifacts (`searchIndex` and `searchContent`) as static files, served alongside other static agent-readability artifacts.

## When would embeddings be added?

Embeddings are **opt-in**, not part of the default setup. The docs say to add embeddings only when:

- The **docs vocabulary does not match user vocabulary** (lexical/keyword matching falls short), or
- The **corpus grows large enough to need semantic retrieval**.

In short: start with the default static, database-free BM25-style lexical search, and add embeddings/semantic retrieval only when keyword matching is insufficient or the corpus becomes large.

---
*Source: `/docs/reference/search.md` (via `/llms.txt` → `/llms-full.txt` → Reference topic).*
