No. Leadtype does **not** include a hosted, database-backed vector index by default.

By default, it builds a **static local search index** over the generated markdown at build time. Runtime search is edge-safe and does not require a database, using lexical BM25-style ranking over titles, headings, body text, and code.

Embeddings would be added only when semantic retrieval is needed—for example, when the docs vocabulary does not match users’ vocabulary, or when the corpus becomes large enough that lexical search is insufficient.
