# Answer: Leadtype's Default Search Index and Vector Index

## Does Leadtype include a hosted database-backed vector index by default?

**No.** Leadtype does not include a hosted database-backed vector index by default.

## What does it use by default?

By default, Leadtype builds a **static local search index** over generated markdown at build time. This search index:

- Uses **lexical BM25-style ranking** over titles, headings, body text, and code
- Is **edge-safe** and does **not require a database** at runtime
- Operates locally without requiring a hosted service

## When would embeddings be added?

According to Leadtype's documentation, embeddings should be added only when:

1. **Docs vocabulary does not match user vocabulary** - When the language used in documentation differs significantly from how users would naturally search for that information
2. **The corpus grows large enough to need semantic retrieval** - When the documentation volume becomes substantial enough that semantic understanding becomes beneficial

In other words, embeddings are optional enhancements for specific use cases rather than a default requirement.
