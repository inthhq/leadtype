# Leadtype Vector Index Answer

## Question
Does Leadtype include a hosted database-backed vector index by default? If not, what does it use by default and when would embeddings be added?

## Answer

**No**, Leadtype does not include a hosted database-backed vector index by default.

### What it uses by default:
Leadtype builds a **static local search index** over generated markdown at build time. The default search path uses **lexical BM25-style ranking** over titles, headings, body text, and code. This approach is:
- Edge-safe
- Does not require a database
- Built at build time, not at runtime

### When embeddings would be added:
According to the documentation, embeddings should be added only when:
1. **Docs vocabulary does not match user vocabulary**, OR
2. **The corpus grows large enough to need semantic retrieval**

In other words, embeddings are an optional enhancement for specific use cases, not a default feature.

### Source
This information comes from the [Search reference page](/docs/reference/search.md) in the Leadtype documentation.
