# Leadtype Vector Index and Embeddings

## Does Leadtype include a hosted database-backed vector index by default?

**No.** Leadtype does not include a hosted database-backed vector index by default.

## What does it use by default?

Leadtype builds a **static local search index** over generated markdown at build time. The default search implementation uses:

- **Lexical BM25-style ranking** over titles, headings, body text, and code
- A runtime query path that is **edge-safe and does not require a database**

## When would embeddings be added?

According to the documentation, embeddings should be added only when one of these conditions is met:

1. **Docs vocabulary does not match user vocabulary** - When domain-specific or specialized terminology might not align with how users naturally search
2. **The corpus grows large enough to need semantic retrieval** - When the documentation becomes so large that semantic understanding becomes more valuable than lexical matching

In other words, embeddings are an optional enhancement for specific use cases, not a default feature of Leadtype.
