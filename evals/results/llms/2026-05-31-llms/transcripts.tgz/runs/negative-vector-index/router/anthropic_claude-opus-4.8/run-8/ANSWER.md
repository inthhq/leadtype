# Does Leadtype include a hosted database-backed vector index by default?

**No.** According to the Leadtype docs (`/docs/reference/search.md`), Leadtype does **not** include a hosted database-backed vector index by default.

## What it uses by default

- Leadtype builds a **static local search index** over the generated markdown at build time.
- The runtime query path is **edge-safe** and **does not require a database**.
- The default search path uses **lexical BM25-style ranking** over titles, headings, body text, and code.
- Search output can feed **source-grounded answer generation**.

## When embeddings would be added

Embeddings (semantic retrieval) should be added **only when**:

- The docs vocabulary does not match the user's vocabulary, **or**
- The corpus grows large enough to need semantic retrieval.

In other words, embeddings are an opt-in enhancement layered on top of the default lexical search, not part of the default setup.
