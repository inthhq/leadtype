# Does Leadtype include a hosted database-backed vector index by default?

**No.** According to the Leadtype docs ([/docs/reference/search.md](/docs/reference/search.md)), Leadtype **does not include a hosted database-backed vector index by default.**

## What it uses by default

Leadtype builds a **static local search index** over the generated markdown at build time. Its default behavior is:

- **Lexical BM25-style ranking** over titles, headings, body text, and code.
- A **runtime query path that is edge-safe and does not require a database.**
- Search output can feed **source-grounded answer generation**.

## When would embeddings be added?

Embeddings are **not part of the default**. You should add them **only when**:

- The docs vocabulary does not match the user vocabulary, or
- The corpus grows large enough to need **semantic retrieval**.

In other words, the default is the lightweight, database-free lexical (BM25-style) index, and embeddings/semantic search are an opt-in enhancement reserved for vocabulary-mismatch or large-corpus scenarios.

---

*Source: Leadtype docs — `/docs/reference/search.md` (via `/llms.txt` → `/llms-full.txt` → Reference topic).*
