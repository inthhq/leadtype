# Leadtype Vector Index and Embeddings

## Answer

**No, Leadtype does not include a hosted database-backed vector index by default.**

Instead, Leadtype uses:

### Default Search Implementation
- **Static local search index** built over generated markdown at build time
- **Lexical BM25-style ranking** over titles, headings, body text, and code
- **Edge-safe runtime query path** that does not require a database

### When to Add Embeddings

According to the Leadtype documentation, embeddings should be added only when:

1. **Docs vocabulary does not match user vocabulary** - When the terminology users search for differs significantly from the documentation's language
2. **The corpus grows large enough to need semantic retrieval** - When the documentation becomes so large that keyword-based lexical search becomes insufficient

This approach allows developers to start with a lightweight, zero-database solution and only adopt vector embeddings and semantic search when it becomes necessary for their use case.

**Source:** /docs/reference/search.md
