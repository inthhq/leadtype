# Leadtype Vector Index and Search

## Does Leadtype include a hosted database-backed vector index by default?

**No**, Leadtype does not include a hosted database-backed vector index by default.

## What does it use by default?

By default, Leadtype uses a **static local search index** built at build time with **lexical BM25-style ranking**. The search process:
- Ranks over titles, headings, body text, and code
- Uses an edge-safe runtime query path
- Does not require a database
- Can feed output into source-grounded answer generation

## When would embeddings be added?

Embeddings (vector index) should be added only when:
1. **Docs vocabulary does not match user vocabulary**, OR
2. **The corpus grows large enough to need semantic retrieval**

In other words, embeddings are optional enhancements for specific use cases where lexical search alone is insufficient.
