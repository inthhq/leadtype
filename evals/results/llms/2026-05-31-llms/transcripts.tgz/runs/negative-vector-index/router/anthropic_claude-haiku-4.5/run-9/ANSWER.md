# Leadtype Vector Index and Embeddings

## Answer

**No, Leadtype does not include a hosted database-backed vector index by default.**

### What Leadtype Uses By Default

Leadtype uses a **static local search index** built at build time using **lexical BM25-style ranking**. This search index:
- Is generated over the markdown documentation at build time
- Ranks results based on titles, headings, body text, and code
- Operates via an edge-safe runtime query path
- Does not require a database

### When Embeddings Should Be Added

According to the Leadtype documentation, embeddings should be added in these scenarios:

1. **When docs vocabulary does not match user vocabulary** - If the terminology used in the documentation differs significantly from how users search for information
2. **When the corpus grows large enough to need semantic retrieval** - As the documentation grows, semantic understanding (embeddings) becomes more valuable for finding conceptually related content

### Source

This information comes from the official Leadtype documentation at `/docs/reference/search.md`.
