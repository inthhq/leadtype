# Does Leadtype include a hosted database-backed vector index by default?

**No.** According to the Leadtype docs ([/docs/reference/search.md](/docs/reference/search.md)), Leadtype does **not** include a hosted database-backed vector index by default.

## What it uses by default

Leadtype builds a **static local search index** over the generated markdown at build time. Key characteristics:

- The runtime query path is **edge-safe** and does **not require a database**.
- The default search path uses **lexical BM25-style ranking** over titles, headings, body text, and code.
- Search output can feed **source-grounded answer generation**.

## When embeddings would be added

Embeddings are an opt-in addition, not a default. You should add embeddings **only when**:

- The docs vocabulary does not match the user vocabulary, or
- The corpus grows large enough to need semantic retrieval.

In other words, embeddings are introduced to enable semantic retrieval when lexical (keyword) matching is insufficient or the corpus scale demands it.
