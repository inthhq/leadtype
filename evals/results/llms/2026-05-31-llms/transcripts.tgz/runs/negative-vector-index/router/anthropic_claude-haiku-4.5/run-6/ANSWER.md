# Does Leadtype Include a Hosted Database-Backed Vector Index by Default?

## Answer

No, Leadtype does not include a hosted database-backed vector index by default.

## What It Uses by Default

Leadtype uses a **static local search index** built at build time with **lexical BM25-style ranking**. This index:
- Operates over generated markdown
- Ranks results based on titles, headings, body text, and code
- Has an edge-safe runtime query path that does not require a database
- Can feed source-grounded answer generation

## When Embeddings Would Be Added

Embeddings should be added only when:
1. **Docs vocabulary does not match user vocabulary** - When users search for concepts with different terminology than what's in the documentation
2. **The corpus grows large enough to need semantic retrieval** - When the documentation becomes so large that keyword-based search is no longer performant or accurate enough

This approach prioritizes simplicity and performance by default, while allowing semantic search capabilities to be added when the use case justifies the additional complexity.
