No. Leadtype does **not** include a hosted, database-backed vector index by default.

By default, it builds a **static local search index** over the generated markdown at build time. The runtime search path is edge-safe, requires no database, and uses **lexical BM25-style ranking** across titles, headings, body text, and code.

Embeddings would be added only when they are actually needed: for example, when users’ vocabulary does not match the docs’ vocabulary, or when the documentation corpus becomes large enough that semantic retrieval is helpful.
