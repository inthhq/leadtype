No. Leadtype does not include a hosted database-backed vector index by default.

By default, it builds a static local search index over generated markdown at build time. Its runtime search path is edge-safe, requires no database, and uses lexical BM25-style ranking over titles, headings, body text, and code.

Embeddings would be added only when the docs vocabulary does not match users’ vocabulary, or when the corpus becomes large enough to need semantic retrieval.
