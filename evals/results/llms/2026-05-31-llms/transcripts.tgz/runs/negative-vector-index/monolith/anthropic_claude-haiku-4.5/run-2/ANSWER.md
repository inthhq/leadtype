# Leadtype Vector Index Configuration

## Answer

**No, Leadtype does not include a hosted database-backed vector index by default.**

## What It Uses by Default

By default, Leadtype uses a **static local search index** built at build time with **lexical BM25-style ranking**. This index:
- Ranks over titles, headings, body text, and code
- Is edge-safe and does not require a database
- Can feed source-grounded answer generation
- Is generated at build time as a static artifact

## When Embeddings Would Be Added

According to the Leadtype documentation, embeddings should only be added when:

1. **Docs vocabulary does not match user vocabulary**, OR
2. **The corpus grows large enough to need semantic retrieval**

In other words, embeddings are an optional enhancement that should be added when the default lexical BM25 search is insufficient for your use case, not a default feature.

## Source
This information comes from the Search section of the Leadtype documentation (URL: /docs/reference/search.md).
