# Leadtype Default Search and Vector Index

## Does Leadtype Include a Hosted Database-Backed Vector Index by Default?

**No**, Leadtype does not include a hosted database-backed vector index by default.

## What Does It Use by Default?

Leadtype uses a **static local search index** built at build time. Specifically:

- The default search path uses **lexical BM25-style ranking** over:
  - Titles
  - Headings
  - Body text
  - Code

- The runtime query path is **edge-safe** and does **not require a database**
- The search index is generated from markdown at build time as a static artifact

## When Would Embeddings Be Added?

According to the Leadtype documentation, embeddings should be added **only when**:

1. **Docs vocabulary does not match user vocabulary**, OR
2. **The corpus grows large enough to need semantic retrieval**

In other words, embeddings are optional enhancements for specific use cases where the static lexical search becomes insufficient for finding relevant content.
