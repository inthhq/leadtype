# Leadtype Default Vector Index

## Answer

**No**, Leadtype does **not** include a hosted database-backed vector index by default.

## What Leadtype Uses by Default

By default, Leadtype builds a **static local search index** using **lexical BM25-style ranking** over:
- Titles
- Headings
- Body text
- Code

This search index is built at build time and is edge-safe, requiring no database at runtime.

## When to Add Embeddings

According to the Leadtype documentation, embeddings should be added only in these situations:

1. **When docs vocabulary does not match user vocabulary** - If users search using different terms than what appears in the documentation
2. **When the corpus grows large enough to need semantic retrieval** - As the documentation grows, lexical search alone may become less effective

The documentation explicitly states: "Add embeddings only when docs vocabulary does not match user vocabulary or the corpus grows large enough to need semantic retrieval."

**Source:** [Search documentation](/docs/reference/search.md) in the Leadtype docs site
