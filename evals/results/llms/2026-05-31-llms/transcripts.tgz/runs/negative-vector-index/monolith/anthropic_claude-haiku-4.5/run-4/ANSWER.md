# Leadtype Vector Index Answer

## Does Leadtype include a hosted database-backed vector index by default?

**No**, Leadtype does not include a hosted database-backed vector index by default.

## What does it use by default?

By default, Leadtype builds a **static local search index** using **lexical BM25-style ranking** over:
- Titles
- Headings
- Body text
- Code

This static search index is built at build time and the runtime query path is edge-safe without requiring a database.

## When would embeddings be added?

According to the documentation, embeddings should only be added when:

1. **Docs vocabulary does not match user vocabulary**, OR
2. **The corpus grows large enough to need semantic retrieval**

In other words, embeddings are considered an optional enhancement to be added when the default lexical search approach becomes insufficient for the specific use case.
