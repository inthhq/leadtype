# Leadtype Vector Index

## Does Leadtype include a hosted database-backed vector index by default?

**No.** Leadtype does not include a hosted database-backed vector index by default.

## What does it use by default?

By default, Leadtype uses a **static local search index** built at build time using **lexical BM25-style ranking**. This approach:
- Searches over generated markdown
- Ranks results based on titles, headings, body text, and code
- Is edge-safe and does not require a database
- Can feed source-grounded answer generation

## When would embeddings be added?

According to the documentation, you should add embeddings only in these scenarios:
1. When your docs vocabulary does not match user vocabulary
2. When the corpus grows large enough to need semantic retrieval

In other words, embeddings are an optional enhancement for specific use cases where lexical search alone is insufficient.
