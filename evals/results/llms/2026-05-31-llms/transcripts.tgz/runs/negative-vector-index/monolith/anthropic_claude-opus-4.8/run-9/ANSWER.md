# Does Leadtype include a hosted database-backed vector index by default?

**No.** According to the Leadtype docs (`/docs/reference/search.md`), Leadtype does **not** include a hosted database-backed vector index by default.

## What it uses by default

Leadtype builds a **static local search index** over the generated markdown at build time. Key characteristics:

- The runtime query path is **edge-safe** and does **not require a database**.
- The default search path uses **lexical BM25-style ranking** over titles, headings, body text, and code.
- The search output can feed source-grounded answer generation.

## When would embeddings be added?

Embeddings should be added **only when**:

1. The docs vocabulary does not match the user's vocabulary, **or**
2. The corpus grows large enough to need semantic retrieval.

In other words, embeddings (semantic/vector search) are an opt-in enhancement for those specific cases, not part of the default setup.
