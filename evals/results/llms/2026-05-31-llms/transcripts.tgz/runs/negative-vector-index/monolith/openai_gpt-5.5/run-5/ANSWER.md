No. Leadtype does not include a hosted database-backed vector index by default.

By default, it builds a static local search index at build time over the generated markdown. The runtime query path is edge-safe, does not require a database, and uses lexical BM25-style ranking over titles, headings, body text, and code.

Embeddings would be added only when the docs vocabulary does not match user vocabulary well enough, or when the corpus grows large enough to need semantic retrieval.
