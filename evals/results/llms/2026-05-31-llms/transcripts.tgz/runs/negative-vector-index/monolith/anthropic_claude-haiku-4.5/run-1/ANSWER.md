# Leadtype Default Vector Index Analysis

## Answer

**No**, Leadtype does not include a hosted database-backed vector index by default.

## What Leadtype Uses By Default

By default, Leadtype uses a **static local search index** built at build time. Specifically:

- **Search Type**: Lexical BM25-style ranking
- **Index Scope**: Built over generated markdown at build time
- **Runtime Execution**: Edge-safe query path that does not require a database
- **Indexed Elements**: Titles, headings, body text, and code

## When Embeddings Would Be Added

According to the documentation, embeddings should be added only when one of the following conditions is met:

1. **Docs vocabulary does not match user vocabulary** - When the terminology used in the documentation differs significantly from what users search for
2. **Corpus grows large enough** - When the documentation corpus becomes large enough to benefit from semantic retrieval capabilities

## Source

This information comes from the "Search" section of the Leadtype documentation at `/docs/reference/search.md`:

> "Leadtype does not include a hosted database-backed vector index by default. Add embeddings only when docs vocabulary does not match user vocabulary or the corpus grows large enough to need semantic retrieval."
