# Does Leadtype include a hosted database-backed vector index by default?

**No.** According to the Leadtype docs (`/docs/reference/search.md`), Leadtype does **not** include a hosted database-backed vector index by default.

## What it uses by default instead

Leadtype builds a **static local search index** over the generated markdown at build time. Key characteristics of this default search path:

- The runtime query path is **edge-safe** and does **not require a database**.
- It uses **lexical, BM25-style ranking** over titles, headings, body text, and code.
- Its output can feed source-grounded answer generation.

## When would embeddings be added?

Embeddings are not part of the default setup. You should add embeddings **only when**:

- the docs vocabulary does not match the user vocabulary, **or**
- the corpus grows large enough to need semantic retrieval.

In other words, embeddings are an opt-in enhancement for semantic retrieval, not a default component.
