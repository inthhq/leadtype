# Leadtype Default Vector Index

## Answer

**No**, Leadtype does not include a hosted database-backed vector index by default.

## What It Uses By Default

Leadtype builds a **static local search index** using **lexical BM25-style ranking**. This search index:
- Is built at build time over generated markdown
- Is edge-safe and does not require a database
- Ranks results based on titles, headings, body text, and code
- Can feed source-grounded answer generation

## When Embeddings Would Be Added

According to the Leadtype documentation, embeddings should be added only in these two scenarios:

1. **When docs vocabulary does not match user vocabulary** - If users search using different terminology than what appears in the docs
2. **When the corpus grows large enough to need semantic retrieval** - When the size of the documentation is large enough that semantic understanding becomes necessary for effective search

In summary, Leadtype takes a pragmatic approach by defaulting to a simple, performant lexical search index and recommends adding vector embeddings only when there is a demonstrated need.
