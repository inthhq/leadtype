# Does Leadtype include a hosted database-backed vector index by default?

**No.** According to the Leadtype docs (Search reference, `/docs/reference/search.md`), Leadtype does **not** include a hosted database-backed vector index by default.

## What it uses by default

Leadtype builds a **static local search index** over the generated markdown at build time. The runtime query path is **edge-safe and does not require a database**.

The default search path uses **lexical, BM25-style ranking** over:

- titles
- headings
- body text
- code

This search output can also feed source-grounded answer generation.

## When would embeddings be added?

Embeddings should be added **only when**:

- the docs vocabulary does not match the user's vocabulary, or
- the corpus grows large enough to need semantic retrieval.

In other words, embeddings/semantic (vector) search are an opt-in addition for specific cases, not part of the default setup.
