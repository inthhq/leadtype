# Does Leadtype include a hosted database-backed vector index by default?

**No.** According to the Leadtype docs (`/docs/reference/search.md`), Leadtype does **not** include a hosted database-backed vector index by default.

## What it uses by default

Leadtype builds a **static, local search index** over the generated markdown at build time. Key characteristics:

- The runtime query path is **edge-safe and does not require a database**.
- The default search path uses **lexical, BM25-style ranking** over titles, headings, body text, and code.
- This search output can feed source-grounded answer generation.

## When would embeddings be added?

Embeddings are an opt-in addition, not part of the default. You should add embeddings only when:

- The **docs vocabulary does not match user vocabulary** (so lexical matching falls short), or
- The **corpus grows large enough to need semantic retrieval**.

In short: Leadtype defaults to a lightweight, database-free, lexical BM25 search index, and embeddings/semantic retrieval are introduced later only if vocabulary mismatch or corpus size makes them necessary.
