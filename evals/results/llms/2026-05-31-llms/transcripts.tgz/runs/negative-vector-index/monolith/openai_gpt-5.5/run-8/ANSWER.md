No. Leadtype does **not** include a hosted database-backed vector index by default.

By default, it builds a **static local search index** over the generated markdown at build time. The runtime search path is edge-safe, requires no database, and uses **lexical BM25-style ranking** across titles, headings, body text, and code.

Embeddings would be added only when the docs vocabulary does not match user vocabulary well, or when the corpus grows large enough to need semantic retrieval.
