# Leadtype Default Vector Index

## Answer

**No**, Leadtype does not include a hosted database-backed vector index by default.

### What It Uses By Default

By default, Leadtype builds a **static local search index** using **lexical BM25-style ranking** at build time. This search index is generated over the markdown content and ranks results based on titles, headings, body text, and code.

The search path is:
- Edge-safe (runs without a database)
- Query-time efficient
- Can feed source-grounded answer generation

### When Embeddings Would Be Added

According to the documentation, you should add embeddings (vector index) only when:

1. **Docs vocabulary does not match user vocabulary** - When your documentation terminology differs significantly from how users naturally search for information
2. **Corpus grows large enough to need semantic retrieval** - When the documentation becomes too large for lexical search to be effective

In other words, add embeddings when the default BM25-based lexical search is no longer sufficient for your use case.

### Source

From `/docs/reference/search.md`:
> "Leadtype does not include a hosted database-backed vector index by default. Add embeddings only when docs vocabulary does not match user vocabulary or the corpus grows large enough to need semantic retrieval."
