No. Leadtype does **not** include a hosted database-backed vector index by default.

By default, Leadtype builds a **static local search index** at build time over the generated markdown. Its runtime search path is edge-safe, requires no database, and uses **lexical BM25-style ranking** over titles, headings, body text, and code.

Embeddings would be added only when they are needed: for example, when the docs vocabulary does not match users’ vocabulary, or when the corpus becomes large enough to require semantic retrieval.
