No. Leadtype does **not** include a hosted database-backed vector index by default.

By default, Leadtype builds a **static local search index** at build time over generated markdown. Its runtime query path is **edge-safe** and requires **no database**, using lexical **BM25-style ranking** over titles, headings, body text, and code.

Embeddings would be added only when:

- the docs vocabulary does not match users’ search vocabulary, or
- the corpus becomes large enough to need semantic retrieval.
