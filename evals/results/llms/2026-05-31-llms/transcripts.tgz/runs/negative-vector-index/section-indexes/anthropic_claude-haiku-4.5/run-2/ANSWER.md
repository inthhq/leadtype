# Leadtype Vector Index - Default Behavior

## Does Leadtype include a hosted database-backed vector index by default?

**No.** Leadtype does not include a hosted database-backed vector index by default.

## What does Leadtype use by default?

By default, Leadtype builds a **static local search index** over generated markdown at build time. The search uses **lexical BM25-style ranking** over:
- Titles
- Headings
- Body text
- Code

The runtime query path is edge-safe and does not require a database.

## When would embeddings be added?

According to the documentation, embeddings should be added only when:
1. **Docs vocabulary does not match user vocabulary**, or
2. **The corpus grows large enough to need semantic retrieval**

In other words, embeddings are an optional enhancement that improves search quality when the default lexical ranking becomes insufficient.

## Source
[Search Reference](/docs/reference/search.md)
