# Leadtype Database-Backed Vector Index Answer

## Does Leadtype include a hosted database-backed vector index by default?

**No**, Leadtype does not include a hosted database-backed vector index by default.

## What does it use by default?

By default, Leadtype builds a **static local search index** over generated markdown at build time. The default search path uses **lexical BM25-style ranking** over titles, headings, body text, and code. This runtime query path is edge-safe and does not require a database.

## When would embeddings be added?

According to the documentation, embeddings should be added only when:

1. **Docs vocabulary does not match user vocabulary**, OR
2. **The corpus grows large enough to need semantic retrieval**

In other words, embeddings are not added by default but should be considered when the static lexical search becomes insufficient for the specific use case.

---

**Source**: `/docs/reference/search.md` - Leadtype Reference Documentation
