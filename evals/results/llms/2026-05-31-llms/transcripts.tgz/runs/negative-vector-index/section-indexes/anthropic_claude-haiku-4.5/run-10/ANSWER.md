# Leadtype Vector Index and Search

## Answer

**No, Leadtype does not include a hosted database-backed vector index by default.**

### What It Uses By Default

Leadtype builds a **static local search index** over generated markdown at build time. The default search uses **lexical BM25-style ranking** over:
- Titles
- Headings
- Body text
- Code

The runtime query path is edge-safe and does not require a database.

### When Embeddings Are Added

Leadtype recommends adding embeddings only when:
1. **Docs vocabulary does not match user vocabulary**, OR
2. **The corpus grows large enough to need semantic retrieval**

In other words, embeddings are optional enhancements for specific use cases, not included by default.

### Source
This information comes from the [Search page](/docs/reference/search.md) in the Leadtype documentation.
