# Leadtype Default Vector Index and Embeddings

## Does Leadtype include a hosted database-backed vector index by default?

No, Leadtype does **not** include a hosted database-backed vector index by default.

## What does it use by default?

Leadtype builds a **static local search index** over generated markdown at build time. The default search path uses **lexical BM25-style ranking** over titles, headings, body text, and code. The runtime query path is edge-safe and does not require a database.

## When would embeddings be added?

According to the documentation, embeddings should be added only when:

1. **Docs vocabulary does not match user vocabulary**, or
2. **The corpus grows large enough to need semantic retrieval**

In other words, embeddings are an optional addition to enhance search when the lexical BM25 approach alone isn't sufficient for your use case.

**Source:** /docs/reference/search.md
