No. Leadtype does **not** include a hosted database-backed vector index by default.

By default, it builds a **static local search index** at build time and uses **lexical BM25-style ranking** over generated markdown content such as titles, headings, body text, and code. The runtime search path is edge-safe and does not require a database.

Embeddings would be added only when lexical search is not enough—for example, when the docs’ vocabulary does not match users’ vocabulary, or when the corpus becomes large enough to need semantic retrieval.
