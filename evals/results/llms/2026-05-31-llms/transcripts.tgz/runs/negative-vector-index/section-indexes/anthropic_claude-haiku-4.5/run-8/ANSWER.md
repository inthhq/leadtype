# Leadtype Vector Index Answer

## Does Leadtype include a hosted database-backed vector index by default?

**No**, Leadtype does not include a hosted database-backed vector index by default.

## What does it use by default?

By default, Leadtype uses a **static local search index** built at build time. The search approach is:
- **Lexical BM25-style ranking** over titles, headings, body text, and code
- **Edge-safe runtime** that does not require a database
- Built during the docs generation process

## When would embeddings be added?

According to the Leadtype documentation, embeddings should be added only when:

1. **Docs vocabulary does not match user vocabulary**, or
2. **The corpus grows large enough to need semantic retrieval**

In other words, embeddings are an optional enhancement for semantic search capabilities, not a default feature. They should be considered when the standard lexical BM25 search is insufficient for the use case.

Source: [Leadtype Search Reference](/docs/reference/search.md)
