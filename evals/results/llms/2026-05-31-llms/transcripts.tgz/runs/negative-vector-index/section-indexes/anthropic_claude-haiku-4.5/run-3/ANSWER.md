# Leadtype Vector Index Default

## Answer

**Does Leadtype include a hosted database-backed vector index by default?**

No, Leadtype does not include a hosted database-backed vector index by default.

## What Does It Use By Default?

Leadtype uses a **static local search index** built at build time over generated markdown. The default search path uses **lexical BM25-style ranking** over titles, headings, body text, and code. The runtime query path is edge-safe and does not require a database.

## When Would Embeddings Be Added?

According to the documentation, embeddings should be added only when:

1. **Docs vocabulary does not match user vocabulary**, or
2. **The corpus grows large enough to need semantic retrieval**

In other words, embeddings should be added for semantic retrieval capabilities when the default lexical search is insufficient.

**Source:** /docs/reference/search.md
