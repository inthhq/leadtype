# Leadtype Vector Index Question

## Answer

**Does Leadtype include a hosted database-backed vector index by default?**

No, Leadtype does not include a hosted database-backed vector index by default.

## What it uses by default

By default, Leadtype uses a **static local search index** built at build time with **lexical BM25-style ranking** over titles, headings, body text, and code. This is an edge-safe runtime query path that does not require a database.

## When embeddings would be added

According to the documentation, embeddings should only be added when:

1. **Docs vocabulary does not match user vocabulary**, OR
2. **The corpus grows large enough to need semantic retrieval**

In other words, embeddings are an optional enhancement to consider only when the basic lexical search approach becomes insufficient for your documentation needs.

**Source**: /docs/reference/search.md
