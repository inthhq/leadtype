# Frontmatter `group`, navigation, and `/llms-full.txt`

In Leadtype, each MDX page has YAML frontmatter. `title` is required, while `group` is optional. When present, `group` should match a slug from `docs.config.ts`; an unknown group fails the build.

`group` is used for organization and routing, not for splitting the full-context output. It controls or contributes to:

- the page's sidebar/navigation position,
- the section where the page appears in `llms.txt`,
- search metadata,
- `AGENTS.md` grouping.

A page may belong to more than one group by using an array, for example:

```yaml
title: API Reference
description: Reference for the public API
group: [reference, build]
```

For monolithic output, Leadtype generates one root `/llms-full.txt` file that contains every generated markdown docs page. Groups still affect navigation, `llms.txt`, search metadata, and `AGENTS.md`, but they do **not** create per-group full-context files by default. In other words: use groups for routing and organization, not sharding.

Optional frontmatter fields include `description`, `icon`, `deprecated`, `deprecatedReason`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor`. `description` is recommended because it becomes the routing hint in `llms.txt`; `lastModified` and `lastAuthor` can be filled when `--enrich-git` is enabled.
