# Frontmatter `group` and `/llms-full.txt`

In Leadtype, each MDX page has YAML frontmatter. `title` is required, while `group` is optional and should match a group slug from `docs.config.ts`.

The `group` field is used for organization and routing metadata:

- It controls where the page appears in the sidebar/navigation.
- It determines the section where the page appears in `llms.txt`.
- It is added to search metadata.
- It controls grouping in generated `AGENTS.md`.
- A page can be assigned to multiple groups with `group: [a, b]`.
- If a page declares a group that is not defined in `docs.config.ts`, the build fails.

`group` does **not** shard the monolithic full-context output. The root `/llms-full.txt` fallback contains every generated markdown docs page, regardless of group, and Leadtype does not publish per-group full-context files by default. In other words, groups are for navigation, routing hints, search metadata, and AGENTS.md organization—not for splitting `/llms-full.txt`.

Optional frontmatter fields include `description`, `icon`, `deprecated`, `deprecatedReason`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor`. `description` is recommended because it becomes the routing hint in `llms.txt`; `lastModified` and `lastAuthor` are filled in when `--enrich-git` is enabled.
