# Frontmatter `group` and Monolithic Output in Leadtype

## What `group` is

Every Leadtype MDX page carries YAML frontmatter. Only `title` is required;
`group` is **optional** and, when present, should match a slug defined in
`docs.config.ts`. If a page declares a `group` that is not defined there, the
build fails. Linting (`leadtype lint`) validates these group references.

A page can belong to more than one group using a list, e.g. `group: [a, b]`.

## How `group` controls navigation

The `group` value is a single piece of metadata that drives several outputs at
once:

- **Sidebar position** — determines where the page sits in the docs navigation.
- **`llms.txt` sections** — organizes the product-level router into sections.
- **Search metadata** — tags the page in the static search index.
- **`AGENTS.md` grouping** — organizes the npm-bundled agent docs.

The guidance is explicit: **use groups for routing, not sharding**, and group
descriptions should read as routing hints rather than marketing copy.

## How `group` relates to monolithic output (`/llms-full.txt`)

`generateLLMFullContextFiles` writes **one** root `/llms-full.txt` file that
contains **every** generated markdown docs page. This monolithic full-context
file is intentionally **not split by group**:

- The root `/llms-full.txt` fallback includes all generated markdown pages.
- Groups still organize the `llms.txt` sections, navigation, search metadata,
  and `AGENTS.md`, but they are **not** published as per-group full-context
  files by default.

So `group` shapes how content is *routed and organized*, while the monolithic
`/llms-full.txt` deliberately ignores group boundaries and bundles everything
together as a single fallback context.

## At least two optional frontmatter fields

In addition to the optional `group`, available optional frontmatter fields
include:

- `description` — optional but recommended, because it becomes the routing hint
  shown in `llms.txt`.
- `icon`
- `deprecated` / `deprecatedReason`
- `experimental`, `canary`, `new`, `draft`
- `tags`
- `availableIn`
- `full`
- `lastModified` and `lastAuthor` — populated only when `--enrich-git` is
  enabled during generation.
