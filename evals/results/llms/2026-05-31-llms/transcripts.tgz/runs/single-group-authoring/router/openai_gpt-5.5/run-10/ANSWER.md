# Frontmatter `group` and `/llms-full.txt`

In Leadtype, each MDX page has YAML frontmatter. `title` is required, while `group` is optional. When present, `group` should match a group slug defined in `docs.config.ts`; an unknown group causes the build to fail.

`group` is used for routing and organization, not for sharding the full-context output:

- It controls where the page appears in the sidebar/navigation.
- It determines which section the page appears under in `llms.txt`.
- It is included in search metadata.
- It controls grouping in generated `AGENTS.md`.
- A page can be assigned to multiple groups with array syntax, for example `group: [a, b]`.

For monolithic output, Leadtype writes one root `/llms-full.txt` file containing every generated markdown docs page. Groups do not create separate per-group full-context files by default; they still organize navigation, `llms.txt`, search metadata, and `AGENTS.md`, but `/llms-full.txt` remains a single fallback bundle.

Optional frontmatter fields include `description`, `icon`, `deprecated`, `deprecatedReason`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor`. `description` is recommended because it becomes the routing hint in `llms.txt`; `lastModified` and `lastAuthor` can be filled when `--enrich-git` is enabled.
