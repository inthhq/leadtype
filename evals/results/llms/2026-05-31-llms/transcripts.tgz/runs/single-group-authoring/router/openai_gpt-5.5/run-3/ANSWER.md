# Frontmatter `group` and `/llms-full.txt`

In Leadtype, each MDX page has YAML frontmatter. `title` is required, while `description` is optional but recommended because it becomes the routing hint in `llms.txt`.

The optional `group` field assigns a page to one or more navigation groups. Its value should match a slug from `docs.config.ts`; if a page declares an unknown group, the build fails. A page can belong to multiple groups with array syntax, for example `group: [a, b]`.

`group` affects the organized, navigational outputs:

- sidebar position/navigation grouping
- the section where the page appears in `llms.txt`
- search metadata
- grouping in generated `AGENTS.md`

However, `group` does **not** shard the monolithic full-context output. `generateLLMFullContextFiles` writes one root `/llms-full.txt` containing every generated markdown docs page. Groups still organize routing-oriented artifacts such as `llms.txt`, navigation, search metadata, and `AGENTS.md`, but Leadtype does not publish per-group full-context files by default. In short: use groups for routing and organization, not for splitting `/llms-full.txt`.

Other optional frontmatter fields include `icon`, `deprecated`, `deprecatedReason`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor`. When `--enrich-git` is enabled, `lastModified` and `lastAuthor` are filled in automatically.
