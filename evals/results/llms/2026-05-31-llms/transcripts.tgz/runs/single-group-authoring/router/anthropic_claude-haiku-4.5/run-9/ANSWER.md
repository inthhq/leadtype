# Frontmatter Group and Monolithic Output in Leadtype

## How Frontmatter `group` Controls Navigation

The `group` frontmatter field is optional and should match a slug from `docs.config.ts`. It serves as a critical organizational mechanism that controls multiple aspects of the documentation site:

1. **Sidebar Position**: The `group` value determines where a page appears in the navigation sidebar
2. **llms.txt Sections**: Pages are organized into different sections of the LLM bundle based on their group assignment
3. **Search Metadata**: Group information is included in search index metadata
4. **AGENTS.md Grouping**: Pages are grouped together in the generated AGENTS.md file

Pages can belong to multiple groups using the syntax `group: [a, b]`, allowing flexible organization across multiple categories. If a page declares an unknown group, the build fails, ensuring consistency.

## Monolithic Output (`/llms-full.txt`)

The root `/llms-full.txt` serves as a comprehensive fallback that contains all generated markdown pages and is **not split by group**. This monolithic output provides a complete, flattened view of the entire documentation in a single file, making it ideal for:

- Full-context AI agent operations
- Complete documentation review
- Comprehensive indexing without category separation

## Optional Frontmatter Fields

The documentation specifies several optional frontmatter fields that can enhance metadata:

1. **`icon`**: Provides visual representation for navigation items
2. **`deprecated`**: Boolean flag indicating whether a page covers deprecated content
3. **`deprecatedReason`**: Explanation for why content is deprecated
4. **`experimental`**: Marks content as experimental or unstable
5. **`canary`**: Indicates feature is in canary/preview status
6. **`new`**: Highlights newly added content
7. **`draft`**: Marks content as a draft not yet ready for publication
8. **`tags`**: Categorical tags for additional organization
9. **`availableIn`**: Specifies version or edition availability
10. **`full`**: Customization option for full-context output
11. **`lastModified`**: Timestamp of last modification (populated with `--enrich-git`)
12. **`lastAuthor`**: Author of last modification (populated with `--enrich-git`)

Additionally, `description` is optional but strongly recommended, as it becomes the routing hint in `llms.txt` and helps with LLM navigation.
