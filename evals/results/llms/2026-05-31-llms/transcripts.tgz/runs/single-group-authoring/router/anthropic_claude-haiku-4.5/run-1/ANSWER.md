# Frontmatter Group and Monolithic Output in Leadtype

## How Frontmatter `group` Controls Navigation

The `group` field in frontmatter is a powerful organizational mechanism in Leadtype that influences multiple aspects of documentation structure:

### Navigation Control
- **Sidebar Position**: The `group` value determines where a page appears in the sidebar navigation of the documentation site.
- **Section Organization**: Pages are organized into sections based on their assigned `group`, which should match a slug from `docs.config.ts`.
- **Multiple Groups**: A single page can belong to multiple groups by using array syntax: `group: [a, b]`, allowing flexible cross-referencing.

### Additional Navigation Impact
The `group` field also drives:
- **Search Metadata**: Groups help categorize and filter search results
- **AGENTS.md Grouping**: Pages are grouped in the AGENTS.md file according to their declared groups
- **llms.txt Section**: Each group gets its own section in the generated llms.txt routing file

## Monolithic Output (`/llms-full.txt`)

The monolithic output is handled specially:
- **Fallback Mechanism**: The root `/llms-full.txt` file serves as a fallback containing all generated markdown pages
- **Not Split by Group**: Unlike the topic-specific llms.txt files that are organized by group, the full context router (`/llms-full.txt`) includes all pages regardless of their group assignment
- **Complete Coverage**: This ensures agents have access to the full documentation context in a single file

## Optional Frontmatter Fields

Beyond the required `title` field and optional `group`, Leadtype supports several additional optional frontmatter fields:

1. **`description`**: Recommended field that becomes the routing hint in llms.txt
2. **`icon`**: Used for visual identification of pages in navigation
3. **`deprecated`**: Boolean flag indicating a page is no longer current
4. **`experimental`**: Boolean flag indicating a page covers experimental features
5. **`tags`**: Array of tags for classification and filtering
6. **`lastModified`**: Automatically filled when `--enrich-git` is enabled to track update dates
7. **`lastAuthor`**: Automatically filled when `--enrich-git` is enabled to track who last edited the page
8. **`canary`**, **`new`**, **`draft`**: Additional status indicators for content staging

These optional fields provide rich metadata for organizing, categorizing, and maintaining documentation across the entire Leadtype pipeline.
