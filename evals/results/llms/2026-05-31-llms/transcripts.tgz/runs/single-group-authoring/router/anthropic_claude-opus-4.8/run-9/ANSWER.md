# Frontmatter `group` and Monolithic Output in Leadtype

## How `group` works

Every MDX page in Leadtype carries YAML frontmatter. `title` is required, while
`group` is **optional** and, when present, must match a slug defined in
`docs.config.ts`. If a page declares a group that doesn't exist, **the build
fails** (`leadtype lint` also validates group references).

A single `group` value drives several outputs at once:

- **Sidebar/navigation position** — the group determines where the page sits in
  the docs site navigation.
- **`llms.txt` section** — pages are organized into sections by their group.
- **Search metadata** — the group is attached to the page's search entry.
- **`AGENTS.md` grouping** — bundled package docs are organized by group.

A page can belong to more than one group using list syntax, e.g.
`group: [a, b]`.

The recommended philosophy (from the LLM reference) is: **use groups for routing,
not sharding**, and write group descriptions as routing hints rather than
marketing copy.

## Monolithic output (`/llms-full.txt`)

`generateLLMFullContextFiles` writes a **single, monolithic** root file at
`/llms-full.txt` that contains **every generated markdown docs page**.

The key point about `group` and monolithic output:

- The root `/llms-full.txt` **fallback is not split by group** — it includes all
  generated markdown regardless of group assignment.
- Groups still organize `llms.txt` sections, navigation, search metadata, and
  `AGENTS.md`, **but they are not published as per-group full-context files by
  default**.

In other words, `group` shapes how content is *indexed and routed*, while
`/llms-full.txt` deliberately ignores group boundaries to provide one complete
context bundle. (Note: in this docs site, `/llms-full.txt` itself also serves as
a topic router pointing to smaller per-topic `/docs/llms-full/*.txt` files.)

## Optional frontmatter fields (at least two)

Beyond `group`, the optional frontmatter fields include:

- `icon`
- `deprecated`
- `deprecatedReason`
- `experimental`
- `canary`
- `new`
- `draft`
- `tags`
- `availableIn`
- `full`
- `lastModified` — filled in automatically when `--enrich-git` is enabled.
- `lastAuthor` — also filled in automatically when `--enrich-git` is enabled.

`description` is also optional (but recommended) because it becomes the routing
hint shown in `llms.txt`.

To make unknown frontmatter fields fail the build, run
`leadtype lint --error-unknown --max-warnings 0`.
