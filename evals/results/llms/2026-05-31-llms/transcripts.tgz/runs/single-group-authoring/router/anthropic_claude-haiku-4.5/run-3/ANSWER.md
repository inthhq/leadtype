# Frontmatter Group and Monolithic Output

## How Frontmatter `group` Controls Navigation

The `group` frontmatter field is optional and should match a slug from `docs.config.ts`. It drives multiple aspects of the documentation site:

1. **Sidebar Position**: The group value determines where a page appears in the sidebar navigation.
2. **LLMs.txt Section**: Each group gets its own section in the generated `llms.txt` file, organizing pages by topic.
3. **Search Metadata**: Group information is embedded in search indexes for better categorization.
4. **AGENTS.md Grouping**: Pages are organized by group in the AGENTS.md artifact for agent-readable bundles.

Pages can belong to multiple groups using the syntax `group: [a, b]`. If a page declares an unknown group, the build fails as a validation check.

## Monolithic Output (`/llms-full.txt`)

The `/llms-full.txt` file is the root fallback that contains **all generated markdown pages not split by group**. This monolithic output provides complete context as a single unified file, making it ideal for agent requests that need full documentation context without group-based filtering. According to the docs, `/llms-full.txt` is served as a static artifact and should be kept available for agent-readability purposes.

## Two Optional Frontmatter Fields

1. **`description`**: Recommended optional field that becomes the routing hint in llms.txt and helps agents understand page content.

2. **`icon`**: An optional field that can add visual indicators in the documentation interface to help identify page types or categories at a glance.

Additional optional fields available include: `deprecated`, `deprecatedReason`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor`.
