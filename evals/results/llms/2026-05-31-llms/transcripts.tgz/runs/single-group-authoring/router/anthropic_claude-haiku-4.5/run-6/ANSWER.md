# Frontmatter Group and Monolithic Output

## How Frontmatter `group` Controls Navigation

The `group` frontmatter field drives multiple navigation and organizational systems in the Leadtype docs pipeline:

1. **Sidebar Position**: The group value determines where a page appears in the documentation sidebar navigation hierarchy.

2. **llms.txt Sections**: Pages are organized into their respective `group` sections in the generated `llms.txt` routing file.

3. **Search Metadata**: The group is used as metadata in the search index to help categorize and filter search results.

4. **AGENTS.md Grouping**: Pages are grouped together in the generated AGENTS.md file based on their group value.

Pages can belong to multiple groups using array syntax: `group: [a, b]`. The group value should match a slug from `docs.config.ts`, and if a page declares an unknown group, the build fails.

## Monolithic Output (/llms-full.txt)

The `/llms-full.txt` file serves as the root fallback that **contains all generated markdown pages and is not split by group**. This monolithic output provides a complete, unified context of the entire documentation site, consolidating all pages regardless of their individual group assignments. This allows for comprehensive context when full documentation needs to be processed as a single entity.

## Optional Frontmatter Fields

In addition to `title` (required) and `group` (optional), Leadtype supports several optional frontmatter fields:

1. **`description`**: Optional but recommended, as it becomes the routing hint in llms.txt files.

2. **`icon`**: Allows specifying an icon for visual identification in navigation.

3. **`deprecated`**: Marks a page as deprecated and can be paired with `deprecatedReason` to explain why.

4. **`experimental`**: Indicates experimental content that may change.

5. **`canary`**: Marks content as canary/pre-release.

6. **`new`**: Flags newly added content.

7. **`draft`**: Marks content as draft/work-in-progress.

8. **`tags`**: For tagging pages with custom metadata.

9. **`availableIn`**: Specifies availability conditions.

10. **`full`**: Configuration option for full-context behavior.

11. **`lastModified` and `lastAuthor`**: Git-enriched fields populated when `--enrich-git` flag is enabled.
