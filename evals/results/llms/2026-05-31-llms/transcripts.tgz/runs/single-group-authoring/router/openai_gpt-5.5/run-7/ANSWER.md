# Frontmatter `group` and `/llms-full.txt`

In Leadtype, each MDX page uses YAML frontmatter. `title` is required, while `group` is optional. When present, `group` should match a slug defined in `docs.config.ts`; if a page declares an unknown group, the build fails.

`group` controls grouped navigation and metadata surfaces:

- It determines the page’s sidebar position.
- It determines the section where the page appears in `llms.txt`.
- It is included in search metadata.
- It affects grouping in generated `AGENTS.md` output.

A page can belong to more than one group by using an array, for example `group: [a, b]`.

The monolithic `/llms-full.txt` output is different: it is a fallback containing all generated markdown pages and is not split by `group`. In other words, `group` organizes navigation, routing hints, search metadata, and grouped agent artifacts, but it does not partition the full bundled output.

Optional frontmatter fields include `description`, `icon`, `deprecated`, `deprecatedReason`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor`. `description` is recommended because it becomes the routing hint in `llms.txt`; `lastModified` and `lastAuthor` can be filled when `--enrich-git` is enabled.
