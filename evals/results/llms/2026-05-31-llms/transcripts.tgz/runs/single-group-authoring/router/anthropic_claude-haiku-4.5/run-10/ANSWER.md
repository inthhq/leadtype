# Frontmatter Group and Monolithic Output

## How Frontmatter `group` Controls Navigation

The `group` frontmatter field is an optional YAML attribute that must match a slug from `docs.config.ts`. This field has significant control over documentation organization:

- **Sidebar Position**: The group value determines where a page appears in the sidebar navigation
- **Section Organization**: The group controls which section a page belongs to in the `llms.txt` routing file
- **Search Metadata**: Group values populate search metadata for filtering and organization
- **AGENTS.md Grouping**: Pages are grouped together in the generated `AGENTS.md` file based on their group assignment

Pages can belong to multiple groups using the syntax `group: [a, b]`, enabling flexible organizational schemes. If a page declares an unknown group that doesn't exist in `docs.config.ts`, the build will fail with an error.

## Monolithic Output (`/llms-full.txt`)

The root `/llms-full.txt` file serves as a fallback monolithic output that contains **all generated markdown pages**. Importantly, this file is **not split by group** — it aggregates the entire documentation site into a single, comprehensive file. This ensures that agents have access to the complete documentation context regardless of group-based filtering.

## Two Optional Frontmatter Fields

1. **`icon`**: Allows custom icon specification for visual identification in navigation and UI elements.

2. **`deprecated`**: A boolean flag that marks a page as deprecated, useful for managing legacy content while keeping it accessible. This field works alongside `deprecatedReason` to provide context about the deprecation status.

Other optional fields available include: `deprecatedReason`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor` (where `lastModified` and `lastAuthor` are automatically populated when using the `--enrich-git` flag).
