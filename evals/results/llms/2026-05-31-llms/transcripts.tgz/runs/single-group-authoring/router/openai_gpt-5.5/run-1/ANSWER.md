# Frontmatter `group` and `/llms-full.txt`

In Leadtype, each MDX page has YAML frontmatter. `title` is required, while `group` is optional. When present, `group` should match a group slug defined in `docs.config.ts`; if a page declares an unknown group, the build fails.

`group` is used for organization and routing metadata:

- It controls the page's sidebar/navigation placement.
- It determines which section the page appears under in `llms.txt`.
- It is included in search metadata.
- It affects grouping in generated `AGENTS.md`.
- A page can belong to more than one group with array syntax, for example `group: [a, b]`.

`group` does **not** shard the monolithic full-context output. Leadtype's root `/llms-full.txt` is a single fallback file containing every generated markdown docs page. Groups still organize navigation, `llms.txt`, search metadata, and `AGENTS.md`, but they are not published as separate per-group full-context files by default. In short: use groups for routing and organization, not for splitting `/llms-full.txt`.

Optional frontmatter fields include, for example:

- `description` — recommended because it becomes the routing hint in `llms.txt`.
- `icon`
- `deprecated`
- `deprecatedReason`
- `experimental`
- `tags`
- `lastModified`
- `lastAuthor`

`lastModified` and `lastAuthor` can be filled automatically when generation runs with `--enrich-git`.
