# Frontmatter Group and Monolithic Output

## Overview

In Leadtype, the frontmatter `group` field is a critical control mechanism that orchestrates both navigation structure and the generation of agent-readable documentation artifacts.

## How `group` Controls Navigation

The `group` frontmatter field drives multiple navigation aspects:

1. **Sidebar Position**: The group value determines where a page appears in the documentation site's sidebar navigation structure.

2. **llms.txt Section Organization**: The group controls which section of the topic-specific `/llms.txt` router a page appears in. This allows agents to quickly navigate to relevant documentation grouped by functional area.

3. **Search Metadata**: Group values become part of the search metadata, enabling better filtering and categorization of search results.

4. **AGENTS.md Grouping**: Pages are organized in the AGENTS.md bundle according to their group assignment.

### Multiple Groups

Pages can belong to multiple groups using the syntax `group: [a, b]`, allowing a single page to appear in multiple navigation contexts.

### Configuration Requirement

The `group` value must match a slug defined in `docs.config.ts`. If a page declares an unknown group, the build fails, ensuring consistency.

## Monolithic Output and `/llms-full.txt`

The `/llms-full.txt` file serves as a **fallback monolithic output** that contains all generated markdown pages. Unlike the topic-specific routers:

- **Not Split by Group**: The root `/llms-full.txt` is not divided or filtered by group assignments.
- **Comprehensive Context**: It provides the complete context router, allowing agents to access all documentation pages regardless of their group membership.
- **Static Artifact**: `/llms-full.txt` is served as a static artifact alongside `/llms.txt` to ensure agents always have access to the full documentation corpus.

## Optional Frontmatter Fields

Beyond `group`, Leadtype supports multiple optional frontmatter fields:

### 1. `icon`
Specifies an icon identifier for the page in navigation and UI elements.

### 2. `deprecated`
Marks a page as deprecated, signaling to users and agents that the content is no longer recommended.

## Additional Optional Fields

The complete list of optional fields includes: `deprecatedReason`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor`.

The `lastModified` and `lastAuthor` fields are automatically populated when the build is run with the `--enrich-git` flag.

## Summary

The `group` field in Leadtype frontmatter is the primary mechanism for structuring documentation into logical categories that control sidebar navigation, router organization, and search metadata. While grouped routers organize content by topic in `/llms.txt`, the `/llms-full.txt` monolithic output ensures agents always have complete access to all documentation regardless of group assignments. This dual-output approach balances context efficiency with comprehensiveness.
