# Frontmatter `group` and Monolithic Output in Leadtype

## What `group` is

Each MDX page in Leadtype carries YAML frontmatter. `title` is required, while
`group` is **optional** and, when present, should match a slug defined in
`docs.config.ts`. If a page declares an unknown `group`, the build fails (and
`leadtype lint` validates these group references).

A page can belong to more than one group using list syntax:

```yaml
group: [a, b]
```

## How `group` controls navigation

The `group` value is the single piece of metadata that organizes a page across
several outputs. Specifically, it drives:

- **Sidebar position** — where the page appears in docs-site navigation.
- **The `llms.txt` section** — which section of the agent router the page is
  listed under.
- **Search metadata** — grouping/categorization in the static search index.
- **AGENTS.md grouping** — how pages cluster in npm-bundled agent docs.

The guidance is to **use groups for routing, not sharding**, and to write group
descriptions as concise routing hints rather than marketing copy.

## How `group` relates to monolithic output (`/llms-full.txt`)

The root `/llms-full.txt` is the **monolithic full-context fallback**. It is
produced by `generateLLMFullContextFiles`, which writes **one** root
`/llms-full.txt` file containing **every** generated markdown docs page.

Key point: **`/llms-full.txt` is not split or sharded by `group`.** Groups still
organize the `llms.txt` sections, navigation, search metadata, and AGENTS.md,
but they are **not** published as per-group full-context files by default. In
other words, `group` shapes how content is *routed and indexed*, while the
monolithic bundle simply concatenates all pages regardless of group.

## At least two optional frontmatter fields

Besides `group` (itself optional), Leadtype supports many optional frontmatter
fields, including:

- **`description`** — optional but recommended, because it becomes the routing
  hint shown in `llms.txt`.
- **`icon`** — an optional display icon for the page.
- **`deprecated` / `deprecatedReason`** — flag a page as deprecated and explain
  why.
- **`experimental`, `canary`, `new`, `draft`** — lifecycle/status markers.
- **`tags`**, **`availableIn`**, **`full`** — additional metadata.
- **`lastModified`** and **`lastAuthor`** — auto-filled only when the
  `--enrich-git` flag is enabled during generation.

(Two concrete examples: `description` and `icon`.)
