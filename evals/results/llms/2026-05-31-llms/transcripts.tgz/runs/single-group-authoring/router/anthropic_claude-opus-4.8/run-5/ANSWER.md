# Frontmatter `group` and Monolithic Output in Leadtype

## What `group` is

Each MDX page in Leadtype carries YAML frontmatter. `title` is **required**, while `group` is **optional**. When present, the `group` value should match a slug defined in `docs.config.ts` — if a page declares an unknown group, the build fails (and `leadtype lint` validates group references).

A page can belong to a single group or to multiple groups using list syntax: `group: [a, b]`.

## How `group` controls navigation

The `group` value is a routing/organization signal that drives several outputs at once:

- **Sidebar position** — determines where the page sits in the docs navigation.
- **`llms.txt` sections** — organizes the entries in the generated `/llms.txt` map.
- **Search metadata** — tags the page in the static search index.
- **AGENTS.md grouping** — organizes the npm-bundled agent docs.

The guidance is to **use groups for routing, not sharding**, and group descriptions should be routing hints rather than marketing copy.

## How `group` relates to monolithic output (`/llms-full.txt`)

The root `/llms-full.txt` is the **monolithic full-context fallback**: `generateLLMFullContextFiles` writes **one** root `/llms-full.txt` file that contains **every** generated markdown docs page.

Crucially, this file is **not split by group**. Groups still organize navigation, `llms.txt` sections, search metadata, and AGENTS.md, but Leadtype does **not** publish per-group full-context files by default. In other words, `group` shapes how content is *organized and routed*, while `/llms-full.txt` is a single, all-inclusive bundle regardless of group assignment.

## At least two optional frontmatter fields

Besides `group`, the optional frontmatter fields include:

- `description` — recommended because it becomes the routing hint in `llms.txt`.
- `icon`
- `deprecated` / `deprecatedReason`
- `experimental`
- `canary`
- `new`
- `draft`
- `tags`
- `availableIn`
- `full`
- `lastModified` and `lastAuthor` — populated only when `--enrich-git` is enabled.

(Two clear examples: `description` and `tags`.)
