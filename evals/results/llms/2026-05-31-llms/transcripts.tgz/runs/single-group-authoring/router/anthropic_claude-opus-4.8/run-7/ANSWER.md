# Frontmatter `group` and Monolithic Output

## What `group` is

Every Leadtype MDX page carries YAML frontmatter. `title` is required, while `group` is **optional**. When present, its value should match a slug defined in `docs.config.ts`. If a page declares an unknown `group`, the build fails.

A page can belong to a single group or to multiple groups by using a list:

```yaml
group: [a, b]
```

## How `group` controls navigation

The `group` value is the organizing key for several outputs. Specifically, it drives:

- **Sidebar position** — where the page appears in the docs-site navigation.
- **The `llms.txt` section** — which section heading the page is listed under in the agent router.
- **Search metadata** — grouping information attached to the search index.
- **AGENTS.md grouping** — how pages are organized in packaged agent docs.

## How `group` relates to monolithic output (`/llms-full.txt`)

The monolithic output behaves differently from the per-group navigation. The root **`/llms-full.txt` fallback contains *all* generated markdown pages and is *not* split by group.** In other words, `group` partitions the navigable/sectioned views (sidebar, `llms.txt` sections, search, AGENTS.md), but the full-context bundle deliberately includes everything regardless of group so agents have a complete corpus to route through.

## Optional frontmatter fields (at least two)

Beyond `group`, Leadtype supports many optional frontmatter fields:

- **`description`** — optional but recommended, because it becomes the routing hint shown in `llms.txt`.
- **`icon`** — optional UI/navigation hint.

Additional optional fields include: `deprecated`, `deprecatedReason`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor`. The `lastModified` and `lastAuthor` fields are only populated when the build runs with `--enrich-git` enabled.

## Summary

`group` is an optional frontmatter field (matching a `docs.config.ts` slug) that controls sidebar placement, `llms.txt` sectioning, search metadata, and AGENTS.md grouping, and may list multiple groups. The monolithic `/llms-full.txt` output ignores grouping and includes all generated markdown pages. Optional fields such as `description` (the `llms.txt` routing hint) and `icon` (plus many others) further annotate pages.
