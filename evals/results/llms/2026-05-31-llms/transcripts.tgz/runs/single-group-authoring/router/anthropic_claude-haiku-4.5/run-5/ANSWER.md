# Frontmatter Group and Monolithic Output Summary

## How Frontmatter `group` Controls Navigation

The frontmatter `group` field is a key organizational mechanism in Leadtype that drives multiple aspects of documentation architecture:

1. **Sidebar Navigation**: The group value controls the position of pages in the documentation sidebar, organizing content hierarchically.

2. **LLM Router Sections**: The group determines which llms.txt section a page appears in, allowing agents to discover related content through the router file.

3. **Search Metadata**: Group values are used as metadata for search functionality, enabling categorized search results.

4. **AGENTS.md Grouping**: Pages are organized by group in the generated AGENTS.md file, which is included in npm packages for easy agent discovery.

5. **Multi-Group Support**: Pages can belong to multiple groups using `group: [a, b]` syntax, enabling content to appear in multiple organizational contexts simultaneously.

## Monolithic Output (`/llms-full.txt`)

The `/llms-full.txt` file serves as a complete fallback that contains all generated markdown pages regardless of group assignment. Unlike the group-split llms.txt router files, the full context router is **not split by group**—it provides comprehensive content coverage. This allows agents to access the entire documentation set in one request when needed.

## Optional Frontmatter Fields

Beyond the required `title` field and optional `description`, Leadtype supports numerous optional frontmatter fields:

1. **`icon`**: Specifies an icon to represent the page in navigation UI.

2. **`deprecated`**: A boolean flag marking a page as deprecated, signaling to users that the content is outdated.

3. **`deprecatedReason`**: Explains why a page is deprecated, providing context for users.

4. **`experimental`**: Marks features or content as experimental and subject to change.

5. **`canary`**: Indicates early-stage or beta functionality.

6. **`new`**: Flags recently added content.

7. **`draft`**: Marks pages as work-in-progress.

8. **`tags`**: Allows custom tagging for advanced categorization.

9. **`availableIn`**: Specifies availability constraints or product editions.

10. **`full`**: Controls whether content appears in the full monolithic output.

11. **`lastModified`**: Auto-populated timestamp (when `--enrich-git` is enabled).

12. **`lastAuthor`**: Auto-populated author information (when `--enrich-git` is enabled).

The `group` field itself is optional and should match a slug from `docs.config.ts`. If a page declares an unknown group, the build fails with validation.
