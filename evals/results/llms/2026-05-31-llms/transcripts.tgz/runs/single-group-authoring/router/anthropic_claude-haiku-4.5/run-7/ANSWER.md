# Frontmatter Group and Monolithic Output in Leadtype

## How Frontmatter `group` Controls Navigation and Monolithic Output

The `group` field in Leadtype frontmatter is a powerful control mechanism that influences multiple aspects of documentation architecture:

### Navigation and Organization
The `group` value drives three primary navigation-related outputs:
1. **Sidebar Position**: Controls where pages appear in the documentation sidebar hierarchy
2. **llms.txt Sections**: Organizes agent-readable bundles into logical sections within the topic-specific LLM context files
3. **AGENTS.md Grouping**: Groups pages in the AGENTS.md artifact for package documentation

### Flexible Group Assignment
Pages can belong to multiple groups simultaneously using the syntax: `group: [a, b]`. This allows single pages to appear in multiple navigation contexts and be included in different logical groupings.

### Group Validation
The `group` field should match a slug from `docs.config.ts`. If a page declares an unknown group, the build fails, ensuring referential integrity.

### Monolithic Output Fallback
The root `/llms-full.txt` file serves as a monolithic fallback that contains **all generated markdown pages**. Crucially, this full-context router is **not split by group**, providing a comprehensive view of the entire documentation regardless of how individual pages are grouped.

## Optional Frontmatter Fields

Leadtype supports numerous optional frontmatter fields beyond the required `title` and optional `description` and `group`:

1. **icon**: Adds visual indicators in navigation elements
2. **deprecated**: Marks pages as deprecated (boolean flag)
3. **deprecatedReason**: Provides explanation for deprecation status
4. **experimental**: Marks features as experimental
5. **canary**: Indicates canary/preview features
6. **new**: Marks newly added pages
7. **draft**: Indicates draft status (not yet published)
8. **tags**: Categorization through keyword tagging
9. **availableIn**: Specifies version or environment availability
10. **full**: Affects full-context inclusion
11. **lastModified**: Records last modification date (auto-populated with --enrich-git)
12. **lastAuthor**: Records the last author (auto-populated with --enrich-git)

These optional fields provide rich metadata that enables search functionality, version management, status indicators, and git integration.
