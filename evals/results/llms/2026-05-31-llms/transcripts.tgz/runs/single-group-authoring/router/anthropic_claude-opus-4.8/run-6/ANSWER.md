# Frontmatter `group` and Monolithic Output

## How `group` works

In Leadtype, each MDX page carries YAML frontmatter. The `group` field is **optional**, and when present it should match a slug defined in `docs.config.ts`. If a page declares an unknown group, **the build fails**.

A single page can belong to multiple groups using array syntax: `group: [a, b]`.

## What `group` controls

The `group` value is a routing/organization signal, not a content-sharding mechanism. It drives:

- **Navigation / sidebar position** — groups order pages in the docs-site sidebar.
- **The `llms.txt` section** — pages are organized into sections by group.
- **Search metadata** — group is included in the search index metadata.
- **AGENTS.md grouping** — group organizes the npm-bundled `AGENTS.md`.

The Leadtype guidance is explicit: *"Use groups for routing, not sharding,"* and group descriptions should be routing hints rather than marketing copy.

## Relationship to monolithic output (`/llms-full.txt`)

The monolithic full-context file is produced by `generateLLMFullContextFiles`, which writes **one root `/llms-full.txt`** containing **every generated markdown docs page**.

Crucially, `/llms-full.txt` is **not split by group**:

- The root `/llms-full.txt` is a fallback that contains all generated markdown pages.
- Groups still organize `llms.txt` sections, navigation, search metadata, and `AGENTS.md`, but they are **not published as per-group full-context files by default**.

So `group` affects how content is *indexed and routed*, but the monolithic bundle deliberately ignores group boundaries and aggregates everything into a single file. `/llms-full.txt` is also treated as a static agent-readability artifact (alongside `llms.txt`, sitemaps, `robots.txt`, search JSON, and `agent-readability.json`) and is not rewritten as a missing markdown page.

## Optional frontmatter fields (examples)

Besides `group` (which is itself optional), the optional frontmatter fields include:

`icon`, `deprecated`, `deprecatedReason`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor`.

At least two examples:

- **`tags`** — additional metadata/labels for a page.
- **`deprecated`** — marks a page as deprecated (paired with `deprecatedReason` to explain why).

Note: `lastModified` and `lastAuthor` are populated only when the build runs with `--enrich-git` enabled.

Also worth noting: `description` is optional but recommended, because it becomes the routing hint shown in `llms.txt`.
