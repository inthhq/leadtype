# Frontmatter `group` and Monolithic Output

## How `group` controls navigation

In Leadtype, each MDX page carries YAML frontmatter. The `group` field is **optional** and, when present, should match a slug defined in `docs.config.ts`. (If a page declares an unknown `group`, the build fails.)

The `group` value drives several aspects of navigation and metadata:

- **Sidebar position** — determines where the page appears in the docs navigation.
- **`llms.txt` section** — places the page under the corresponding section in the agent-readable router.
- **Search metadata** — feeds the search index grouping.
- **`AGENTS.md` grouping** — organizes pages in the shipped agent file.

A page can belong to **multiple groups** by using an array, e.g. `group: [a, b]`.

## How `group` relates to monolithic output (`/llms-full.txt`)

The root `/llms-full.txt` is the **fallback / monolithic bundle**: it contains **all** generated markdown pages and is **not split by group**. In other words, while `group` slices content into sections for the sidebar, per-topic `llms-full` files, search, and `AGENTS.md`, the top-level `/llms-full.txt` ignores group boundaries and aggregates everything into one combined output. (Group-specific deep-context files such as `/docs/llms-full/authoring.txt` are the grouped counterparts that route to smaller topic subsets.)

## Optional frontmatter fields (at least two)

`title` is the only required field. `description` is optional but recommended because it becomes the routing hint in `llms.txt`. Additional optional fields include:

- **`icon`** — an icon for the page.
- **`deprecated`** (with **`deprecatedReason`**) — marks a page as deprecated.
- **`experimental`**, **`canary`**, **`new`**, **`draft`** — lifecycle/status markers.
- **`tags`** — page tags.
- **`availableIn`** — availability/version info.
- **`full`** — full-context flag.
- **`lastModified`** and **`lastAuthor`** — git metadata, populated only when `--enrich-git` is enabled.

(The `group` field itself is also optional.)
