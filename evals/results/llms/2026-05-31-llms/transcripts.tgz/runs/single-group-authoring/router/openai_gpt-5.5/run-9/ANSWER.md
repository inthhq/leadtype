# Frontmatter `group` and `/llms-full.txt`

In Leadtype, every MDX docs page has YAML frontmatter. `title` is required. `group` is optional, but when present it should match a group slug from `docs.config.ts`; an unknown group fails the build.

`group` is used for organization and routing metadata:

- It controls where the page appears in the sidebar/navigation.
- It determines the page’s section in `llms.txt`.
- It is included in search metadata.
- It controls grouping in generated `AGENTS.md`.
- A page can be in more than one group with `group: [a, b]`.

However, `group` does **not** shard the monolithic full-context output. The root `/llms-full.txt` is a fallback file that contains every generated markdown docs page. Groups still organize navigation, `llms.txt`, search metadata, and `AGENTS.md`, but Leadtype does not publish per-group full-context files by default. In short: use groups for routing and organization, not for splitting `/llms-full.txt`.

Optional frontmatter fields include:

- `description`: recommended; used as the routing hint in `llms.txt`.
- `icon`
- `deprecated`
- `deprecatedReason`
- `experimental`
- `canary`
- `new`
- `draft`
- `tags`
- `availableIn`
- `full`
- `lastModified`
- `lastAuthor`

`lastModified` and `lastAuthor` can be filled automatically when generation runs with `--enrich-git`.