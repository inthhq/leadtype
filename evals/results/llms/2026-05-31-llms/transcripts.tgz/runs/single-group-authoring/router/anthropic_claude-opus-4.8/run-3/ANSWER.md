# Frontmatter `group` and Monolithic Output in Leadtype

## How `group` controls navigation

In Leadtype, every MDX page carries YAML frontmatter. The `group` field is **optional**, and when present it should match a slug defined in `docs.config.ts`. (If a page declares an unknown group, the build fails — and lint validates group references.)

A single `group` value drives several outputs at once:

- **Sidebar position** — it determines where the page appears in the docs navigation.
- **`llms.txt` section** — it organizes which section the page is routed under in the product-level map.
- **Search metadata** — it tags the page in the static search index.
- **AGENTS.md grouping** — it organizes pages in the npm-bundled `AGENTS.md`.

A page can belong to multiple groups using list syntax: `group: [a, b]`.

The guiding principle from the reference is: **use groups for routing, not sharding** — group descriptions should be routing hints, not marketing copy.

## How `group` relates to monolithic output (`/llms-full.txt`)

The key point is that `group` does **not** shard the monolithic full-context file:

- `generateLLMFullContextFiles` writes **one** root `/llms-full.txt` file that contains **every** generated markdown docs page.
- This root full-context file is a fallback and is **not split by group**.
- Groups still organize `llms.txt` sections, navigation, search metadata, and `AGENTS.md`, but they are **not** published as per-group full-context files by default.

So `group` shapes how content is *navigated and routed*, while `/llms-full.txt` remains a single monolithic bundle of all pages regardless of grouping.

## Optional frontmatter fields (at least two)

The only required field is `title`. Optional fields include:

- **`description`** — optional but recommended, because it becomes the routing hint shown in `llms.txt`.
- **`icon`** — optional UI/navigation icon.

Additional optional fields available: `deprecated`, `deprecatedReason`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor`. Note that `lastModified` and `lastAuthor` are populated only when `--enrich-git` is enabled.

## Related lint/CLI behavior

`leadtype lint` validates frontmatter, group references, links, and schema rules. To make unknown frontmatter fields fail the build (e.g., in CI), use `--error-unknown` with `--max-warnings 0`, and `--format github` for CI output.
