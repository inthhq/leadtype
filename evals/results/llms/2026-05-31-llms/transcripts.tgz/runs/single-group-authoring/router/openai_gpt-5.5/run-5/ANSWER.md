# Frontmatter `group`, navigation, and `/llms-full.txt`

In Leadtype, every MDX page has YAML frontmatter. `title` is required. `description` is optional but recommended because it becomes the routing hint in `llms.txt`.

`group` is optional, but when used it should match a slug from `docs.config.ts`. Its purpose is organization and routing: the `group` value controls the page’s sidebar position, the section where it appears in `llms.txt`, search metadata, and `AGENTS.md` grouping. A page can appear in more than one group by using an array, for example `group: [a, b]`. If a page declares a group that is not known, the build fails.

For monolithic agent output, groups do **not** shard the full-context file. Website mode emits `/llms-full.txt`, and `generateLLMFullContextFiles` writes one root `/llms-full.txt` containing every generated markdown docs page. Groups still organize navigation, `llms.txt` sections, search metadata, and `AGENTS.md`, but they are not published as per-group full-context files by default. In short: use groups for routing and navigation, not for splitting `/llms-full.txt`.

Optional frontmatter fields include `description`, `icon`, `deprecated`, `deprecatedReason`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor`. `lastModified` and `lastAuthor` are filled in when `--enrich-git` is enabled.