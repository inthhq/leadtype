# Frontmatter `group` and `/llms-full.txt`

In Leadtype, each MDX page has YAML frontmatter. The only required field is `title`; `group` is optional, but when present it should match a group slug from `docs.config.ts`.

## How `group` controls navigation and routing

The `group` value is used as an organizing signal across the generated docs experience. It controls or contributes to:

- the page's sidebar position/navigation grouping,
- the section where the page appears in `llms.txt`,
- search metadata,
- grouping in generated `AGENTS.md`.

A page can be assigned to more than one group with array syntax, for example:

```yaml
group: [get-started, reference]
```

If a page declares a group that is not known in `docs.config.ts`, the build fails. The docs recommend using groups for routing and organization, not for sharding the full-context output; group descriptions should act as routing hints rather than marketing copy.

## How `group` affects `/llms-full.txt`

`/llms-full.txt` is the root full-context fallback. It is generated as one monolithic file containing every generated markdown docs page. Even though groups organize navigation, `llms.txt` sections, search metadata, and `AGENTS.md`, Leadtype does not publish per-group full-context files by default. In other words, `group` helps route readers and agents to the right docs area, but it does not split `/llms-full.txt` into separate group-specific bundles.

## Optional frontmatter fields

Optional frontmatter fields include:

- `description` — recommended because it becomes the routing hint in `llms.txt`.
- `icon`
- `deprecated`
- `deprecatedReason`
- `experimental`
- `canary`
- `new`
- `draft`
- `tags`
- `availableIn`
- `full`
- `lastModified`
- `lastAuthor`

`lastModified` and `lastAuthor` can be filled automatically when generation runs with `--enrich-git`.
