# Frontmatter Group and Monolithic Output in Leadtype

## How Frontmatter `group` Controls Navigation

The frontmatter `group` field is an optional field that should match a slug from `docs.config.ts`. The `group` value is a powerful metadata field that drives multiple aspects of documentation organization:

1. **Sidebar Position**: The group determines where a page appears in the documentation website's sidebar navigation.

2. **Routing Hints**: The group controls how pages are organized within the `llms.txt` section routing, determining which topic-specific context files pages belong to.

3. **Search Metadata**: The group value is used to tag and organize pages in the search index, allowing users to filter results by documentation section.

4. **AGENTS.md Grouping**: The group determines how pages are grouped in the `AGENTS.md` bundle, organizing content for agent-readable consumption.

Pages can belong to multiple groups using the syntax `group: [a, b]`, enabling cross-cutting concerns and pages that logically fit in multiple sections.

## Monolithic Output (`/llms-full.txt`)

The `/llms-full.txt` file serves as the root fallback that contains **all generated markdown pages** and is **not split by group**. This monolithic output provides complete context in a single file, making it ideal for scenarios where:

- A comprehensive, unfiltered view of the entire documentation is needed
- Full-context routing to any topic is required
- All documentation must be accessible in a single request

If a page declares an unknown group value, the build fails, ensuring that group references are always valid against the configuration.

## Two Optional Frontmatter Fields

### 1. `icon`
The `icon` field allows you to specify an icon to represent the page visually in the sidebar navigation and other UI elements, enhancing the visual organization of the documentation.

### 2. `deprecated`
The `deprecated` field marks a page as outdated or no longer recommended. When set to true, it signals to readers that the content is no longer actively maintained. This can be paired with `deprecatedReason` to provide context about why the page is deprecated and what users should use instead.

Both fields contribute to the overall content quality and user experience of the documentation site while remaining optional for basic documentation needs.
