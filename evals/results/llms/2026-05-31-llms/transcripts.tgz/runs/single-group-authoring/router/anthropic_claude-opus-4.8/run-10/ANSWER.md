# Frontmatter `group` and Monolithic Output

## Overview

In Leadtype, every MDX page carries YAML frontmatter. Only `title` is
**required**. `description` is optional but recommended (it becomes the routing
hint in `llms.txt`), and `group` is optional. When present, a `group` value
should match a slug defined in `docs.config.ts`.

## How `group` Controls Navigation

The `group` value is a single field that simultaneously drives several outputs:

- **Sidebar position** — determines where the page appears in the docs-site
  navigation.
- **`llms.txt` section** — places the page under the corresponding section in
  the agent-readable router file.
- **Search metadata** — feeds grouping/categorization into the search index.
- **`AGENTS.md` grouping** — organizes pages when bundling package docs.

A page can belong to **multiple groups** by using a list, e.g.
`group: [a, b]`. If a page declares an **unknown group** (one not defined in
`docs.config.ts`), the **build fails**, which keeps navigation consistent.

## How `group` Relates to Monolithic Output (`/llms-full.txt`)

`/llms-full.txt` is the **root full-context fallback**. Unlike the
group-driven, topic-specific bundles, this root monolithic file:

- **Contains all generated markdown pages**, and
- **Is not split by `group`.**

In other words, `group` shapes the split/topic-scoped artifacts (sidebar,
`llms.txt` sections, search, `AGENTS.md`, and the per-topic
`/docs/llms-full/*.txt` routes), but the monolithic `/llms-full.txt` ignores
grouping entirely and aggregates every page so agents always have a complete
fallback context source.

## Optional Frontmatter Fields (at least two)

Besides `description` and `group` (both optional), Leadtype supports many
optional frontmatter fields:

- `icon`
- `deprecated`
- `deprecatedReason`
- `experimental`
- `canary`
- `new`
- `draft`
- `tags`
- `availableIn`
- `full`
- `lastModified` — populated automatically when `--enrich-git` is enabled.
- `lastAuthor` — populated automatically when `--enrich-git` is enabled.

For example, two commonly useful optional fields are **`tags`** (search/metadata
hints) and **`deprecated`** (with `deprecatedReason` to explain the deprecation).

## Sources

- `/docs/authoring/frontmatter.md` (via `/docs/llms-full/authoring.txt`)
- `/llms-full.txt` (Full Context Router)
- `/docs/llms-full/build.txt`
