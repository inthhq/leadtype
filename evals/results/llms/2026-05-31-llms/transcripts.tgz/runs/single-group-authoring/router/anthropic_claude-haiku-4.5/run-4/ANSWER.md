# Frontmatter Group and Monolithic Output

## Overview

In Leadtype, the frontmatter `group` field is a critical control mechanism that manages both navigation structure and the generation of the monolithic output file (`/llms-full.txt`).

## How Frontmatter `group` Controls Navigation and Monolithic Output

### Group Control Functions

The `group` field (optional, must match a slug from `docs.config.ts`) drives several key aspects of documentation organization:

1. **Sidebar Position**: The group value determines where a page appears in the documentation sidebar navigation hierarchy.

2. **llms.txt Sections**: Pages are organized into separate sections within the routing files based on their group assignment.

3. **Search Metadata**: Group information is embedded in search index metadata to help organize and categorize searchable content.

4. **AGENTS.md Grouping**: Pages are grouped in the AGENTS.md file according to their group assignment, enabling better organization for agent-readable bundles.

### Multiple Group Assignment

A single page can belong to multiple groups using the syntax: `group: [a, b]`. This enables pages to appear in multiple navigation sections and groupings simultaneously.

### Monolithic Output Fallback

The root `/llms-full.txt` file serves as a universal fallback that contains **all generated markdown pages** and is **not split by group**. This monolithic output ensures complete documentation is always available as a single comprehensive file, regardless of individual page group assignments.

### Group Validation

If a page declares an unknown group (not found in `docs.config.ts`), the build fails. This ensures consistency and prevents misconfiguration.

## Optional Frontmatter Fields

Beyond `group`, several optional frontmatter fields control documentation behavior:

1. **deprecated**: Marks a page as deprecated, typically used alongside deprecatedReason to explain why and suggest alternatives.

2. **experimental**: Flags content that is in experimental status, indicating it may be unstable or subject to breaking changes.

These optional fields provide metadata that controls how pages are indexed, filtered, and presented throughout the documentation system and agent-readable outputs.
