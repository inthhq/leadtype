# Frontmatter `group` and `/llms-full.txt`

In Leadtype, each MDX page has YAML frontmatter. `title` is required, while `description` is optional but recommended because it becomes a routing hint in `llms.txt`.

## How `group` controls navigation and organization

The optional `group` field should match a slug from `docs.config.ts`. When set, it controls how a page is organized across the generated docs artifacts:

- Sidebar/navigation position
- The section where the page appears in `llms.txt`
- Search metadata
- `AGENTS.md` grouping

A page can belong to more than one group by using an array:

```yaml
group: [get-started, reference]
```

If a page declares a group that is not known from `docs.config.ts`, the build fails. Leadtype recommends using groups for routing and organization, not for sharding content.

## How `group` affects `/llms-full.txt`

`group` does **not** split the root full-context file. Leadtype generates one monolithic root `/llms-full.txt` containing every generated markdown docs page. Groups still organize `llms.txt`, navigation, search metadata, and `AGENTS.md`, but they are not published as per-group full-context files by default.

In short: `group` affects navigation and routing-oriented indexes, while `/llms-full.txt` remains a single fallback bundle containing all generated markdown pages.

## Optional frontmatter fields

Optional frontmatter fields include:

- `description`
- `icon`
- `deprecated`
- `deprecatedReason`
- `experimental`
- `canary`
- `new`
- `draft`
- `tags`
- `availableIn`
- `full`
- `lastModified`
- `lastAuthor`

`lastModified` and `lastAuthor` are filled in when `--enrich-git` is enabled.
