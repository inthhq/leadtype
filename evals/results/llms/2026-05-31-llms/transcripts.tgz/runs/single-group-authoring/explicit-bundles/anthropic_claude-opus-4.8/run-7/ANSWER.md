# Frontmatter `group` and Monolithic Output in Leadtype

## What `group` is

Each Leadtype MDX page carries YAML frontmatter. `title` is required, while
`group` is **optional** and, when present, must match a slug defined in
`docs.config.ts`. A page may belong to multiple groups using list syntax
(`group: [a, b]`). If a page declares an unknown group, the build fails
(and `leadtype lint` validates group references).

## How `group` controls navigation

The `group` value is a single source of truth that drives several
navigation/metadata surfaces:

- **Sidebar position** — determines where the page sits in the docs site nav.
- **`llms.txt` sections** — organizes the product-level routing map into sections.
- **Search metadata** — tags entries in the static search index.
- **AGENTS.md grouping** — organizes the npm-bundled agent docs.

Guidance from the reference docs: use groups **for routing, not sharding**, and
write group descriptions as routing hints rather than marketing copy.

## How `group` relates to monolithic output (`/llms-full.txt`)

The monolithic bundle is deliberately **not** split by group:

- `generateLLMFullContextFiles` writes **one** root `/llms-full.txt` file that
  contains **every** generated markdown docs page.
- The root `/llms-full.txt` is a fallback containing all generated markdown,
  and it is **not** divided per group.
- Groups still organize `llms.txt` sections, navigation, search metadata, and
  AGENTS.md — but they are **not** published as per-group full-context files by
  default.

In short: `group` shapes how content is *organized and routed* (sidebar,
`llms.txt`, search, AGENTS.md), while the monolithic `/llms-full.txt` ignores
grouping and simply concatenates all pages as a complete-context fallback.

## Optional frontmatter fields (examples)

Besides `group`, the following frontmatter fields are optional:

- `description` — optional but recommended, since it becomes the routing hint
  shown in `llms.txt`.
- `icon` — optional sidebar/visual icon.

Other optional fields include: `deprecated`, `deprecatedReason`, `experimental`,
`canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and
`lastAuthor`. The `lastModified` and `lastAuthor` fields are filled in only when
`--enrich-git` is enabled during `leadtype generate`.

## Sources
- `/docs/authoring/frontmatter.md`
- `/docs/reference/llm.md`
- `/docs/reference/cli.md`
