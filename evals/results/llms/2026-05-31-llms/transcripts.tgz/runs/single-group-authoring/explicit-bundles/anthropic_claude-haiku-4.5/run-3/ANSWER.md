# Frontmatter Group and Monolithic Output in Leadtype

## How the `group` Frontmatter Field Controls Navigation

The `group` frontmatter field is optional but highly significant in Leadtype documentation. It should match a slug from `docs.config.ts` and drives multiple aspects of the documentation system:

1. **Sidebar Position**: The group value determines where a page appears in the sidebar navigation structure
2. **llms.txt Sections**: Pages are organized into separate LLM-readable bundles based on their group assignment
3. **Search Metadata**: Group information is included in search indexing to help categorize content
4. **AGENTS.md Grouping**: Pages with the same group are grouped together in the generated AGENTS.md file

Pages can belong to multiple groups using the syntax `group: [a, b]`, allowing flexible content organization. If a page declares an unknown group, the build fails, ensuring data consistency.

## Monolithic Output (/llms-full.txt)

The `/llms-full.txt` file serves as a fallback monolithic output that contains **all generated markdown pages not split by group**. This means:

- All documentation content is consolidated into a single file
- This provides a complete, unfiltered view of the entire documentation
- It's useful for contexts where the full scope of documentation is needed

## Optional Frontmatter Fields

Leadtype supports numerous optional frontmatter fields beyond `group`:

1. **`icon`**: Specifies an icon to display alongside the page in navigation
2. **`deprecated`**: A boolean flag marking a page as deprecated to indicate it's no longer the recommended approach

Additional optional fields include:
- `deprecatedReason`: Provides context for why a page is deprecated
- `experimental`: Marks content as experimental/unstable
- `canary`: Indicates pre-release functionality
- `new`: Highlights newly added content
- `draft`: Marks pages under development
- `tags`: For categorizing and filtering content
- `availableIn`: Specifies which versions/tiers the feature is available in
- `full`: Boolean for full-page rendering
- `lastModified`: Timestamp (auto-filled with `--enrich-git`)
- `lastAuthor`: Author name (auto-filled with `--enrich-git`)

The `description` field is optional but recommended, as it becomes the routing hint in llms.txt bundles. The only required field is `title`.
