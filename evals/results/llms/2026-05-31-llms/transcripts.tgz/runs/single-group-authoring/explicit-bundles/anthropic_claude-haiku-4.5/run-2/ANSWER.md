# Frontmatter Group and Monolithic Output in Leadtype

## How Frontmatter `group` Controls Navigation

The `group` frontmatter field is optional and must match a slug from `docs.config.ts`. It plays a central role in organizing documentation:

- **Sidebar Position**: The group value determines where a page appears in the sidebar navigation
- **Section Organization**: Pages are grouped into sections in `llms.txt` based on their group value
- **Search Metadata**: The group influences how pages are categorized in the search index
- **AGENTS.md Grouping**: Pages are organized in the AGENTS.md file according to their assigned group

Pages can belong to multiple groups by using array syntax: `group: [a, b]`.

If a page declares an unknown group (one not defined in docs.config.ts), the build will fail.

## Monolithic Output (`/llms-full.txt`)

The `/llms-full.txt` file serves as a fallback monolithic bundle that contains **all generated markdown pages** without splitting by group. This means:

- Even if pages are split into different group-based `llms.txt` sections, the full context bundle aggregates everything
- It provides a complete, unified view of all documentation
- Users can choose this bundle when they need comprehensive context across all groups

## Optional Frontmatter Fields

The Leadtype documentation specifies several optional frontmatter fields in addition to `group`:

1. **`icon`**: Specifies an icon to represent the page in navigation
2. **`deprecated`**: Marks a page as deprecated, affecting how it's treated in the build and displayed to users

Other optional fields include:
- `deprecatedReason`: Provides context for why something is deprecated
- `experimental`: Marks a page as experimental/beta
- `canary`: Indicates bleeding-edge features
- `new`: Marks newly added content
- `draft`: Indicates work-in-progress pages
- `tags`: Custom metadata tags
- `availableIn`: Specifies availability/version information
- `full`: Additional metadata
- `lastModified`: Git-populated timestamp (when `--enrich-git` is enabled)
- `lastAuthor`: Git-populated author information (when `--enrich-git` is enabled)

Note: `description` is optional but recommended as it becomes the routing hint in llms.txt, while `title` is required.
