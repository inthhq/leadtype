# Frontmatter `group` and Monolithic Output in Leadtype

## What `group` is

`group` is an **optional** frontmatter field on each MDX page. When present, its value should match a slug defined in `docs.config.ts`. A page can belong to multiple groups using array syntax: `group: [a, b]`. If a page declares an unknown group, **the build fails** (and `leadtype lint` validates group references).

## How `group` controls navigation

The `group` value drives several pieces of the generated output:

- **Sidebar position** — determines where the page sits in the docs-site navigation.
- **`llms.txt` sections** — groups organize the section structure of the product-level `/llms.txt` routing map.
- **Search metadata** — group is attached as search metadata used by the static index.
- **`AGENTS.md` grouping** — group organizes the npm-bundled `AGENTS.md`.

The guiding principle from the reference is: **"Use groups for routing, not sharding."** Group descriptions are meant to be routing hints, not marketing copy.

## How `group` relates to monolithic output (`/llms-full.txt`)

`generateLLMFullContextFiles` writes **one root `/llms-full.txt` file containing every generated markdown docs page**. This monolithic fallback is **not split by group** — groups still organize `llms.txt` sections, navigation, search metadata, and `AGENTS.md`, but they are **not** published as per-group full-context files by default.

In short: `group` shapes *how content is routed and organized*, while `/llms-full.txt` is a single, un-sharded bundle of *all* pages. Sharded full-context bundles (e.g. `/docs/llms-full/authoring.txt`) exist but the root monolithic file ignores group boundaries.

## Optional frontmatter fields (at least two)

`title` is the only required field. `description` is optional but recommended (it becomes the routing hint in `llms.txt`), and `group` is optional. Additional optional fields include:

- **`icon`** — sidebar/navigation icon.
- **`deprecated`** (with **`deprecatedReason`**) — flags deprecated pages.
- **`experimental`**, **`canary`**, **`new`**, **`draft`** — status flags.
- **`tags`** — categorization metadata.
- **`availableIn`** — version/availability info.
- **`full`** — full-context handling.
- **`lastModified`** and **`lastAuthor`** — git enrichment fields, populated only when `--enrich-git` is enabled.

> Two concrete examples of optional fields: **`description`** (used as the `llms.txt` routing hint) and **`tags`** (search/categorization metadata).
