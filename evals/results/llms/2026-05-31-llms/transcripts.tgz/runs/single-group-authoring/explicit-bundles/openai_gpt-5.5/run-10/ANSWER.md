# Frontmatter `group` and `/llms-full.txt`

In Leadtype, every MDX page has YAML frontmatter. `title` is required, while `description` is optional but recommended because it becomes a routing hint in `llms.txt`.

The optional `group` field should match a group slug defined in `docs.config.ts`. It can be a single group or multiple groups, for example `group: [a, b]`. Leadtype uses `group` to organize several non-page-output concerns:

- the page's sidebar/navigation position
- the section where the page appears in `llms.txt`
- search metadata
- `AGENTS.md` grouping

If a page declares a group that is not known, the build fails. The docs also recommend using groups for routing rather than sharding, with group descriptions written as routing hints.

`/llms-full.txt` is different: it is a monolithic root full-context fallback. Leadtype writes one `/llms-full.txt` containing every generated markdown docs page. Groups still affect navigation, `llms.txt`, search metadata, and `AGENTS.md`, but they do not split `/llms-full.txt` into per-group full-context files by default.

Optional frontmatter fields include `description`, `icon`, `deprecated`, `deprecatedReason`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor`. `lastModified` and `lastAuthor` can be filled when `--enrich-git` is enabled.
