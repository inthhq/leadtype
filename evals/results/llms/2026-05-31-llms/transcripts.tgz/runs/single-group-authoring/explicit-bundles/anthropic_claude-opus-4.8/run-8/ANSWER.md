# Frontmatter `group` and Monolithic Output

## What `group` is

In Leadtype, every MDX page has YAML frontmatter. `title` is **required**, while
`group` is **optional**. When present, the `group` value should match a slug
defined in `docs.config.ts` — if a page declares an *unknown* group, **the build
fails**. A page can also belong to several groups at once using array syntax:
`group: [a, b]`.

## How `group` controls navigation (and more)

The `group` value is the single piece of metadata that organizes the docs across
multiple outputs. Specifically, it drives:

- **Sidebar position** — where the page appears in the docs-site navigation.
- **`llms.txt` section** — which routing section the page is listed under in the
  agent-readable map.
- **Search metadata** — grouping used by the search index.
- **`AGENTS.md` grouping** — how pages are bucketed in the npm-bundled
  `AGENTS.md`.

Guidance from the reference: use groups for **routing, not sharding**, and write
group descriptions as concise routing hints rather than marketing copy.

## How `group` relates to monolithic output (`/llms-full.txt`)

The monolithic full-context file is **not** split by group:

- `generateLLMFullContextFiles` writes **one root `/llms-full.txt`** that contains
  **every generated markdown docs page**.
- The root `/llms-full.txt` is described as the fallback bundle and is **not split
  by group**.
- Groups still organize the `llms.txt` sections, navigation, search metadata, and
  `AGENTS.md` — but they are **not** published as per-group full-context files by
  default.

In short: `group` shapes how content is *organized and routed* (sidebar,
`llms.txt`, search, `AGENTS.md`), whereas `/llms-full.txt` is a single
all-pages bundle that ignores group boundaries. `/llms-full.txt` is also treated
as an agent-readability artifact (recognized by `isAgentReadabilityArtifactPath`,
alongside `llms.txt`, sitemap files, `robots.txt`, search JSON, and
`agent-readability.json`) and should be served as a static artifact.

## Optional frontmatter fields (examples)

Besides `group`, optional frontmatter fields include:

- **`description`** — optional but recommended, because it becomes the routing
  hint shown in `llms.txt`.
- **`icon`** — an optional display field.

Other optional fields available: `deprecated`, `deprecatedReason`, `experimental`,
`canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and
`lastAuthor`. The `lastModified` and `lastAuthor` fields are populated only when
`--enrich-git` is enabled.
