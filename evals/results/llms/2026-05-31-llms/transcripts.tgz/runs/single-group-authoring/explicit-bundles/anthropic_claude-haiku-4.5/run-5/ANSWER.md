# Frontmatter Group and Monolithic Output in Leadtype

## How Frontmatter `group` Controls Navigation

The `group` field in frontmatter is a key organizational mechanism in Leadtype that controls multiple aspects of how documentation is presented and structured:

1. **Sidebar Navigation**: The `group` value drives the sidebar position, organizing pages into hierarchical sections within the docs site.

2. **llms.txt Organization**: The group value determines how pages are organized and presented in `/llms.txt`, creating logical sections that agents can navigate.

3. **Search Metadata**: Group assignments influence how pages are categorized in search metadata, helping organize searchable content.

4. **AGENTS.md Grouping**: Pages are grouped in `AGENTS.md` according to their group assignments, providing organization for offline package documentation.

5. **Multiple Groups**: Pages can belong to multiple groups using the syntax `group: [a, b]`, allowing flexible content categorization.

The `group` value must match a slug from `docs.config.ts`. If a page declares an unknown group, the build fails. Groups are used for **routing, not sharding** — group descriptions should serve as routing hints rather than marketing copy.

## Monolithic Output: /llms-full.txt

The root `/llms-full.txt` file is the monolithic fallback output that contains all generated markdown pages. Unlike the organized `/llms.txt` which is split by group, `/llms-full.txt` provides a comprehensive single file containing every page's converted markdown.

Key characteristics:
- **Not split by group**: While groups organize llms.txt sections and other artifacts, groups do not create per-group full-context files
- **Complete reference**: Serves as a catch-all containing all documentation in a single monolithic format
- **Generated artifact**: Written alongside other website-mode artifacts when running `leadtype generate`

## Two Optional Frontmatter Fields

In addition to the required `title` field and the recommended `description` field, Leadtype supports several optional frontmatter fields:

1. **`icon`**: Allows specifying an icon to visually represent the page in navigation interfaces.

2. **`deprecated`**: A boolean flag indicating whether the page or content is deprecated, with an optional companion field `deprecatedReason` to explain the deprecation.

Additional optional fields include: `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor` (the latter two are populated when `--enrich-git` is enabled).

This system allows Leadtype to manage multiple output formats (website navigation, agent bundles, and monolithic fallback files) through a unified frontmatter configuration while maintaining flexibility in content categorization and status tracking.
