# Frontmatter `group` and Monolithic Output (`/llms-full.txt`)

## What `group` is

In Leadtype, every MDX page carries YAML frontmatter. `title` is required, while `group` is **optional**. When present, the `group` value should match a slug defined in `docs.config.ts`. If a page declares an unknown group, **the build fails**.

A page can belong to multiple groups using array syntax: `group: [a, b]`.

## How `group` controls navigation (and related outputs)

The `group` value is a routing/organization signal rather than a content-sharding mechanism. A single group value simultaneously drives:

- **Sidebar position** — where the page appears in the docs-site navigation.
- **The `llms.txt` section** — how the page is grouped in the agent-readable map.
- **Search metadata** — how the page is categorized in the search index.
- **AGENTS.md grouping** — how npm-bundled docs are organized.

The guidance is explicit: *use groups for routing, not sharding*, and group descriptions should be concise routing hints rather than marketing copy.

## How `group` relates to monolithic output (`/llms-full.txt`)

The monolithic full-context output is produced by `generateLLMFullContextFiles`, which writes **one root `/llms-full.txt` file containing every generated markdown docs page**.

Key point: `/llms-full.txt` is **not split by group**. Groups still organize the `llms.txt` sections, sidebar navigation, search metadata, and AGENTS.md, but they are **not published as per-group full-context files by default**. In other words, `group` affects how content is indexed and navigated, but the root `/llms-full.txt` is a flat, complete fallback bundle of all pages regardless of group.

`/llms-full.txt` is treated as a static agent-readability artifact (alongside `llms.txt`, sitemap files, `robots.txt`, search JSON, and `agent-readability.json`). It is generated in website mode and is skipped in npm bundle mode. `isAgentReadabilityArtifactPath` recognizes it so it is not rewritten as a missing markdown page.

## Optional frontmatter fields

`group` itself is optional. Additional optional frontmatter fields include:

- `description` — optional but recommended; it becomes the routing hint shown in `llms.txt`.
- `icon`
- `deprecated`
- `deprecatedReason`
- `experimental`
- `canary`
- `new`
- `draft`
- `tags`
- `availableIn`
- `full`
- `lastModified` *(populated only when `--enrich-git` is enabled)*
- `lastAuthor` *(populated only when `--enrich-git` is enabled)*

(At least two are highlighted above: `description` and `icon` — plus `deprecated`, `tags`, etc.)
