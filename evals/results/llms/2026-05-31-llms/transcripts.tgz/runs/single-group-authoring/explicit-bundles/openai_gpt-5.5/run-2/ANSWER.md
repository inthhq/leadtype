# Frontmatter `group` and `/llms-full.txt`

In Leadtype, every MDX page has YAML frontmatter. `title` is required, while `group` is optional. When present, `group` should match a group slug from `docs.config.ts`; an unknown group causes the build to fail.

`group` is used to organize and route content, not to shard full-context output. It controls:

- the page’s position in the sidebar/navigation,
- which section the page appears under in `llms.txt`,
- search metadata,
- grouping in `AGENTS.md`.

A page can belong to more than one group by using an array, for example `group: [a, b]`.

For monolithic output, Leadtype writes a single root `/llms-full.txt` file containing every generated markdown docs page. Groups do not produce separate per-group full-context files by default; they still organize `llms.txt`, navigation, search metadata, and `AGENTS.md`, but `/llms-full.txt` remains one all-docs fallback bundle.

Optional frontmatter fields include `description`, `icon`, `deprecated`, `deprecatedReason`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor`. `description` is recommended because it becomes the routing hint in `llms.txt`; `lastModified` and `lastAuthor` can be filled when `--enrich-git` is enabled.
