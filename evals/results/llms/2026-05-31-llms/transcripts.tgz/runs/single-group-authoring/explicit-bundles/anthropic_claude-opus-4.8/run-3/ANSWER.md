# Frontmatter `group` and Monolithic Output

## How `group` works

In Leadtype, each MDX page carries YAML frontmatter. The `title` field is required, while `group` is **optional** and, when present, must match a slug defined in `docs.config.ts`. If a page declares an **unknown group**, the build fails (and `leadtype lint` validates these group references).

A single `group` value (or multiple via `group: [a, b]`) drives four things at once:

- **Navigation / sidebar position** — the group determines where the page appears in the sidebar.
- **`llms.txt` sections** — pages are organized into sections by group.
- **Search metadata** — group is recorded as search metadata.
- **`AGENTS.md` grouping** — npm-bundled docs are grouped accordingly.

Guidance from the reference: use **groups for routing, not sharding**, and write group descriptions as routing hints rather than marketing copy.

## Monolithic output (`/llms-full.txt`)

Although `group` shapes navigation, sections, search, and `AGENTS.md`, it does **not** shard the full-context output:

- `generateLLMFullContextFiles` writes **one root `/llms-full.txt`** file that contains **every** generated markdown docs page.
- The root `/llms-full.txt` fallback is **not split by group**.
- Groups still organize `llms.txt` sections, navigation, search metadata, and `AGENTS.md`, but they are **not published as per-group full-context files by default**.

In short: `group` controls how content is *organized and discovered*, while `/llms-full.txt` is a single monolithic bundle of all pages regardless of group. (In website mode, `--json` output also reports paths such as `llmsFullTxt`, `docsLlmsTxt`, and `llmsTxt`.)

## At least two optional frontmatter fields

Besides `group`, optional frontmatter fields include:

- `description` — optional but recommended, because it becomes the routing hint in `llms.txt`.
- `icon`
- `deprecated`
- `deprecatedReason`
- `experimental`
- `canary`
- `new`
- `draft`
- `tags`
- `availableIn`
- `full`
- `lastModified` — populated when `--enrich-git` is enabled.
- `lastAuthor` — populated when `--enrich-git` is enabled.

(Two concrete examples: **`description`**, which feeds the `llms.txt` routing hint, and **`tags`**, used for additional metadata.)
