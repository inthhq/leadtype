# Frontmatter Group and Monolithic Output in Leadtype

## How Frontmatter `group` Controls Navigation

The `group` frontmatter field is optional and should match a slug from `docs.config.ts`. The group value drives several critical aspects of documentation organization:

1. **Sidebar Position**: The group determines where a page appears in the navigation sidebar
2. **llms.txt Section**: Pages are organized into sections within the `llms.txt` file according to their assigned group
3. **Search Metadata**: The group is included in search metadata for categorization
4. **AGENTS.md Grouping**: Pages are grouped together in the generated `AGENTS.md` file based on their group assignment

A page can belong to multiple groups by using the syntax `group: [a, b]`. If a page declares an unknown group (one that doesn't match a slug in `docs.config.ts`), the build fails.

## Monolithic Output (`/llms-full.txt`)

The `/llms-full.txt` file is a fallback monolithic output that contains all generated markdown pages without being split by group. This provides a complete, unified view of all documentation regardless of how individual pages are grouped for navigation purposes. The monolithic output ensures that agents have access to the entire documentation set when group-based filtering is not needed.

## Optional Frontmatter Fields

In addition to `group`, Leadtype supports several optional frontmatter fields:

1. **`icon`**: Specifies an icon for the page (typically used in navigation)
2. **`deprecated`**: Marks a page as deprecated
3. **`deprecatedReason`**: Provides an explanation for why a page is deprecated
4. **`experimental`**: Marks a feature as experimental
5. **`canary`**: Marks a feature as in canary/beta status
6. **`new`**: Marks a page or feature as newly added
7. **`draft`**: Indicates the page is still in draft status
8. **`tags`**: Allows tagging pages for better categorization
9. **`availableIn`**: Specifies where or when a feature is available
10. **`full`**: Configuration for full-context bundle inclusion
11. **`lastModified`**: Records when the page was last modified (populated with `--enrich-git` flag)
12. **`lastAuthor`**: Records who last modified the page (populated with `--enrich-git` flag)

Note: `description` is also optional but highly recommended, as it becomes the routing hint in `llms.txt`. The only required field is `title`.
