# Frontmatter `group` and `/llms-full.txt`

In Leadtype, each MDX page uses YAML frontmatter. `title` is required, while `group` is optional but should match a group slug from `docs.config.ts`.

## What `group` controls

The frontmatter `group` value is used for organization and routing metadata:

- It determines the page's sidebar/navigation position.
- It places the page into the appropriate section of `llms.txt`.
- It is included in search metadata.
- It controls grouping in generated `AGENTS.md` files.

A page can belong to multiple groups by using an array, for example:

```yaml
group: [authoring, reference]
```

If a page declares a group that is not known in `docs.config.ts`, the build fails.

## How this relates to `/llms-full.txt`

Groups do **not** shard or split the root monolithic output. Leadtype generates one root `/llms-full.txt` file that contains every generated markdown docs page. Groups still organize navigation, `llms.txt` sections, search metadata, and `AGENTS.md`, but they are not published as per-group full-context files by default.

In short: use `group` for routing and organization, not for splitting the full-context bundle.

## Optional frontmatter fields

Optional fields include:

- `description` — recommended; becomes the routing hint in `llms.txt`.
- `icon`
- `deprecated`
- `deprecatedReason`
- `experimental`
- `canary`
- `new`
- `draft`
- `tags`
- `availableIn`
- `full`
- `lastModified`
- `lastAuthor`

`lastModified` and `lastAuthor` can be filled automatically when generation runs with `--enrich-git`.
