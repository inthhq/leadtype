# Frontmatter `group` and Monolithic Output in Leadtype

## Summary

In Leadtype, every MDX page carries YAML frontmatter. `title` is the only **required** field; `group` is **optional** but, when present, must match a slug defined in `docs.config.ts`. If a page declares an unknown group, the build fails (and `leadtype lint` validates these group references).

## How `group` Controls Navigation

The `group` value is a single organizing key that simultaneously drives several downstream outputs:

- **Sidebar position** — determines where the page sits in the docs navigation.
- **`llms.txt` section** — controls which section the page is listed under in the product-level map.
- **Search metadata** — feeds the static search index.
- **`AGENTS.md` grouping** — organizes the npm-bundled agent docs.

A page can belong to **multiple groups** using list syntax: `group: [a, b]`.

The guiding principle from the reference docs: **"Use groups for routing, not sharding."** Group descriptions are meant to be routing hints, not marketing copy.

## How `group` Relates to Monolithic Output (`/llms-full.txt`)

Despite organizing navigation, search, and `llms.txt`, **`group` does NOT split the monolithic full-context output**:

- `generateLLMFullContextFiles` writes **one** root `/llms-full.txt` file that contains **every** generated markdown docs page.
- This root `/llms-full.txt` is a fallback and is **not split by group**.
- Groups are explicitly **not** published as per-group full-context files by default — they continue to organize `llms.txt` sections, navigation, search metadata, and `AGENTS.md`, but not the monolithic bundle.

In short: groups handle *routing/organization*, while `/llms-full.txt` is a single, unsharded, all-pages bundle.

## At Least Two Optional Frontmatter Fields

Beyond `group`, the optional frontmatter fields include:

- `description` — optional but recommended, because it becomes the routing hint shown in `llms.txt`.
- `icon`
- `deprecated`
- `deprecatedReason`
- `experimental`
- `canary`
- `new`
- `draft`
- `tags`
- `availableIn`
- `full`
- `lastModified` — populated only when `--enrich-git` is enabled.
- `lastAuthor` — populated only when `--enrich-git` is enabled.

(Two concrete examples: **`description`**, which supplies the `llms.txt` routing hint, and **`tags`**, which contributes metadata. `lastModified` and `lastAuthor` are notable because they are auto-filled by Git enrichment rather than authored by hand.)
