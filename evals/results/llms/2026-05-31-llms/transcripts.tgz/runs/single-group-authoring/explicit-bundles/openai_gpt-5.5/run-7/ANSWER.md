# Frontmatter `group` and `/llms-full.txt`

In Leadtype, each MDX page has YAML frontmatter. `title` is required, while `description` is optional but recommended because it becomes the routing hint shown in `llms.txt`.

The optional `group` field should match a group slug from `docs.config.ts`. It controls how a page is organized across the generated docs experience:

- sidebar/navigation position
- the section where the page appears in `llms.txt`
- search metadata
- grouping in generated `AGENTS.md`

A page can belong to more than one group by using an array, for example `group: [get-started, reference]`. If a page declares a group that is not defined in `docs.config.ts`, the build fails.

`group` does **not** shard the monolithic LLM output. Leadtype’s `generateLLMFullContextFiles` writes a single root `/llms-full.txt` containing every generated markdown docs page. Groups still affect routing and organization in navigation, `llms.txt`, search metadata, and `AGENTS.md`, but they are not published as separate per-group full-context files by default. In short: use groups for routing and organization, not for splitting `/llms-full.txt`.

Optional frontmatter fields include `description`, `icon`, `deprecated`, `deprecatedReason`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor`. When `--enrich-git` is enabled, `lastModified` and `lastAuthor` can be filled in from Git metadata.
