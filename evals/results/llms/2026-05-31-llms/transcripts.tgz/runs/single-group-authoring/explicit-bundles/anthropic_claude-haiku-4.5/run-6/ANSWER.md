# Frontmatter `group` and Monolithic Output in Leadtype

## Frontmatter `group` - Navigation Control

The `group` field in Leadtype frontmatter is an optional field that must match a slug from `docs.config.ts`. It plays a crucial role in controlling how documentation is organized and navigated:

### Navigation and Organization Effects:
- **Sidebar Position**: The group value directly drives where a page appears in the sidebar navigation
- **llms.txt Sections**: Groups organize how pages are grouped within the product-level `/llms.txt` file
- **Search Metadata**: Group information becomes part of the search metadata, affecting how pages are indexed and categorized
- **AGENTS.md Grouping**: Pages are grouped in the `AGENTS.md` file based on their group assignment
- **Multiple Groups**: Pages can belong to multiple groups using the syntax `group: [a, b]`, allowing cross-cutting organization

## Monolithic Output (`/llms-full.txt`)

The root `/llms-full.txt` file is a complete, monolithic bundle that contains **every generated markdown docs page** in a single file, serving as a fallback full-context resource:

### Key Characteristics:
- **Not Split by Group**: Unlike the sectioned `/llms.txt` file, the monolithic `/llms-full.txt` is not organized or split according to group values
- **Complete Coverage**: It includes all generated markdown pages regardless of their group assignments
- **Fallback Resource**: It functions as a comprehensive fallback when smaller, group-specific bundles are insufficient for agent context needs
- **Group Independence**: Groups continue to organize sidebar navigation, llms.txt sections, search metadata, and AGENTS.md grouping, but they do not affect the structure of the monolithic output

## Optional Frontmatter Fields

Beyond the required `title` and optional `group` field, Leadtype supports several optional frontmatter fields:

### Examples of Optional Fields:
1. **`description`**: Optional but recommended, as it becomes the routing hint in llms.txt and helps provide context to agents
2. **`icon`**: Specifies an icon for visual representation in navigation and UI elements
3. **`deprecated`**: Boolean field indicating whether the page or feature is deprecated
4. **`experimental`**: Boolean field marking a page or feature as experimental
5. **`tags`**: Allows categorization of pages beyond group-based organization
6. **`lastModified`**: Timestamp of the last modification (filled in when `--enrich-git` flag is enabled)

Additional optional fields include `deprecatedReason`, `canary`, `new`, `draft`, `availableIn`, `full`, and `lastAuthor`.
