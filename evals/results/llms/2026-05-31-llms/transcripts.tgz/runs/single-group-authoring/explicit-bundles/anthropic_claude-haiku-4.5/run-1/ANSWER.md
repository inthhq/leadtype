# Frontmatter Group and Monolithic Output in Leadtype

## How Frontmatter `group` Controls Navigation

The `group` frontmatter field is a crucial control mechanism in Leadtype that drives multiple aspects of documentation organization:

1. **Sidebar Position**: The group value determines where a page appears in the website's sidebar navigation structure.

2. **llms.txt Sections**: The group organizes content into different sections within the `/llms.txt` file, which serves as a routing map for hosted websites.

3. **Search Metadata**: Groups classify pages in search functionality, allowing users to filter or organize search results by category.

4. **AGENTS.md Grouping**: When generating bundle mode artifacts, groups organize the AGENTS.md file that gets shipped with npm packages.

Pages can belong to multiple groups using the syntax `group: [a, b]`, allowing content to appear in multiple navigation contexts simultaneously. The group value must match a slug defined in `docs.config.ts`, or the build will fail.

## Monolithic Output: `/llms-full.txt`

The `/llms-full.txt` file is Leadtype's monolithic output that serves as a comprehensive, unsplit bundle of all generated markdown pages:

- **Complete Coverage**: It contains every generated markdown docs page in a single file
- **Not Split by Groups**: Unlike `/llms.txt` which organizes content by groups, `/llms-full.txt` serves as a root fallback that remains unified regardless of group organization
- **Website Artifact**: It is generated in website mode alongside `/llms.txt`, markdown mirrors, and other agent-readable artifacts
- **Static Deployment**: `/llms-full.txt` should be kept as a static artifact when serving agent requests, allowing LLMs and agents to fetch complete documentation context

The key distinction is that **groups organize** the structured index (`/llms.txt`), navigation, search, and bundled docs, but they do **not** split the monolithic `/llms-full.txt` file. This allows agents to optionally request either grouped context (via `/llms.txt` and its sections) or complete unstructured context (via `/llms-full.txt`).

## Optional Frontmatter Fields

Beyond the required `title` and the important `group` field, Leadtype supports several optional frontmatter fields:

1. **`description`**: Optional but recommended. Becomes the routing hint in llms.txt, helping agents understand page purpose and content scope.

2. **`icon`**: Optional field for visual representation in navigation interfaces.

3. **`deprecated`**: Optional boolean flag to mark pages that are no longer maintained or relevant.

4. **`experimental`**: Optional field to indicate pages describing experimental or unstable features.

5. **`tags`**: Optional field for categorizing and filtering content by arbitrary tags.

6. **`lastModified`**: Optional field that is automatically filled in when the `--enrich-git` flag is enabled during build, tracking the last modification date from git history.

7. **`lastAuthor`**: Optional field that is automatically populated when `--enrich-git` is enabled, recording the last author to modify the page from git history.

These optional fields provide metadata that enhances documentation organization, discoverability, and maintenance tracking without being required for a valid document.
