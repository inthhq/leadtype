# Frontmatter `group` and `/llms-full.txt`

In Leadtype, each MDX page has YAML frontmatter. `title` is required, while `group` is optional. When used, `group` should match a group slug defined in `docs.config.ts`; an unknown group causes the build to fail.

`group` controls organization and routing metadata, not content sharding:

- It determines where the page appears in the sidebar/navigation.
- It determines which section of `llms.txt` the page is listed under.
- It contributes to search metadata.
- It controls grouping in generated `AGENTS.md` for package docs.
- A page can belong to multiple groups with array syntax, for example `group: [a, b]`.

For monolithic output, Leadtype writes a single root `/llms-full.txt` containing every generated markdown docs page. Groups still organize navigation, `llms.txt`, search metadata, and `AGENTS.md`, but `/llms-full.txt` is not split by group, and per-group full-context files are not published by default. In other words: use groups for routing and navigation, not for sharding the full-context output.

Optional frontmatter fields include `description`, `icon`, `deprecated`, `deprecatedReason`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor`. `description` is recommended because it becomes the routing hint in `llms.txt`; `lastModified` and `lastAuthor` can be filled when `--enrich-git` is enabled.
