# Frontmatter `group` and Monolithic Output in Leadtype

## What `group` is

`group` is an **optional** frontmatter field on each MDX page. When present, it should match a slug defined in `docs.config.ts`. A page can belong to multiple groups using array syntax (`group: [a, b]`). If a page declares an **unknown** group, the build fails (group references are also validated by `leadtype lint`).

## How `group` controls navigation (and more)

A single `group` value drives several outputs at once:

- **Sidebar position** — determines where the page appears in the docs-site navigation.
- **`llms.txt` section** — organizes the routing map into sections.
- **Search metadata** — tags the page for the static search index.
- **`AGENTS.md` grouping** — organizes the npm-bundled agent docs.

The guidance is to **use groups for routing, not sharding**, and to write group/section descriptions as routing hints rather than marketing copy.

## How `group` relates to monolithic output (`/llms-full.txt`)

`/llms-full.txt` is the **root full-context fallback**: one monolithic file containing **every generated markdown docs page**. Key points:

- It is **not split by group**. Groups still organize navigation, the `llms.txt` sections, search metadata, and `AGENTS.md`, but they are **not published as per-group full-context files by default**.
- It is produced by `generateLLMFullContextFiles`, which writes the single root `/llms-full.txt` containing all pages. (By contrast, `generateLlmsTxt` writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` map.)
- In website mode it is served as a static artifact (the `--json` output exposes its path as `llmsFullTxt`), alongside `llms.txt`, sitemaps, `robots.txt`, search JSON, and `agent-readability.json`.

In short: `group` shapes *how content is organized for navigation, routing maps, search, and AGENTS.md*, while `/llms-full.txt` ignores grouping entirely and bundles *all* generated markdown into one file for full-context agent consumption.

## Optional frontmatter fields (at least two)

Besides `group`, the optional frontmatter fields include:

- **`description`** — optional but recommended, because it becomes the routing hint shown in `llms.txt`.
- **`icon`** — page icon.
- **`deprecated`** / **`deprecatedReason`** — mark a page (and explain why) as deprecated.
- **`experimental`**, **`canary`**, **`new`**, **`draft`** — lifecycle/status flags.
- **`tags`** — page tags.
- **`availableIn`** — version/availability information.
- **`full`** — full-page flag.
- **`lastModified`** / **`lastAuthor`** — git enrichment fields filled in when `--enrich-git` is enabled.

(Note: `title` is the only **required** field.)
