# Frontmatter `group` and `/llms-full.txt`

In Leadtype, each MDX page has YAML frontmatter. `title` is required, while `group` is optional. When provided, `group` should match a group slug from `docs.config.ts`; if a page declares an unknown group, the build fails.

`group` is used for organization and routing, not for splitting full-context output. It controls:

- the page's sidebar position/navigation grouping
- the section where the page appears in `llms.txt`
- search metadata
- grouping in generated `AGENTS.md`

A page can belong to more than one group by using an array, for example `group: [a, b]`.

The monolithic `/llms-full.txt` output is different: `generateLLMFullContextFiles` writes one root `/llms-full.txt` file containing every generated markdown docs page. Groups still organize navigation, `llms.txt`, search metadata, and `AGENTS.md`, but Leadtype does not publish per-group full-context files by default. In short: use groups for routing and organization, not sharding.

Optional frontmatter fields include `description`, `icon`, `deprecated`, `deprecatedReason`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor`. `description` is especially useful because it becomes the routing hint in `llms.txt`; `lastModified` and `lastAuthor` can be filled in when `--enrich-git` is enabled.