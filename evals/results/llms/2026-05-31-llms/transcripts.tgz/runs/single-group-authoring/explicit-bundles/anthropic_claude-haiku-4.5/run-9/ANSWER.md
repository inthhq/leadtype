# Frontmatter Group and Monolithic Output

## How Frontmatter `group` Controls Navigation and Output

The `group` field in Leadtype frontmatter is a powerful control mechanism that drives multiple aspects of documentation organization and output generation:

### Navigation and Organization
The `group` value drives the **sidebar position**, organizing how pages appear in the documentation site's navigation structure. Pages are grouped logically according to their assigned group value, which must match a slug from `docs.config.ts`.

### Multi-Group Support
Pages can belong to multiple groups using the syntax `group: [a, b]`, allowing flexible organization where a single page appears in multiple navigation sections if needed.

### Monolithic Output (llms-full.txt)
The root `/llms-full.txt` file is a **fallback that contains all generated markdown pages** in a monolithic format. Importantly, this file is **not split by group** — instead, groups organize other outputs while the full-context file remains unified. The `generateLLMFullContextFiles` API writes this comprehensive file containing every generated markdown docs page, with groups continuing to organize the other outputs (llms.txt sections, navigation, search metadata, and AGENTS.md) but not the monolithic bundle itself.

### Routing and Metadata
Beyond navigation, the `group` value also drives:
- **llms.txt section organization** - groups structure how content is presented in the index file
- **Search metadata** - groups are used to categorize content for search purposes
- **AGENTS.md grouping** - npm-bundled documentation uses groups to organize agent guidance

### Group Validation
If a page declares an unknown group (one that doesn't match a slug in `docs.config.ts`), the build fails, ensuring group integrity.

## Optional Frontmatter Fields

Leadtype supports several optional frontmatter fields beyond the required `title` and optional `description` and `group`:

1. **`icon`** - Specifies an icon to display alongside the page in navigation or documentation listings.

2. **`deprecated`** - A boolean field marking the page as deprecated, signaling to users that the content is outdated or no longer recommended for use.

Additionally, other optional fields include:
- `deprecatedReason` - Provides context on why something is deprecated
- `experimental` - Marks content as experimental
- `canary` - Marks content as canary/preview
- `new` - Marks content as newly added
- `draft` - Marks content as draft/work-in-progress
- `tags` - Applies searchable tags to the page
- `availableIn` - Specifies availability constraints
- `full` - Controls full-context inclusion
- `lastModified` - Records when the page was last modified (auto-filled with `--enrich-git`)
- `lastAuthor` - Records the last author (auto-filled with `--enrich-git`)

These optional fields provide additional metadata that influences both the rendered website and the agent-readable artifact generation.
