# Frontmatter `group` and Monolithic Output in Leadtype

## What `group` is

`group` is an **optional** frontmatter field on each MDX page. Its value should
match a slug defined in `docs.config.ts`. If a page declares an **unknown
group**, the build fails (and `leadtype lint` validates group references).

A page can also belong to **multiple groups** using list syntax:

```yaml
group: [a, b]
```

## How `group` controls navigation

The `group` value drives several pieces of the generated output:

- **Sidebar position** — it determines where the page sits in the docs-site navigation.
- **`/llms.txt` sections** — pages are organized into the corresponding sections of the product-level `llms.txt` routing map.
- **Search metadata** — group is attached as metadata in the static search index.
- **`AGENTS.md` grouping** — group organizes the npm-bundled `AGENTS.md` output.

The guiding principle from the reference docs: **"Use groups for routing, not
sharding."** Group descriptions are meant to be routing hints, not marketing copy.

## How `group` relates to monolithic output (`/llms-full.txt`)

The monolithic, root full-context file is **not** split by group:

- `generateLLMFullContextFiles` writes **one** root `/llms-full.txt` file that
  contains **every** generated markdown docs page.
- This root file is a fallback that includes all generated markdown — it is
  **not split by group**.
- Groups still *organize* `llms.txt` sections, navigation, search metadata, and
  `AGENTS.md`, but they are **not published as per-group full-context files by
  default**. In other words, groups do routing/organization, not sharding of the
  monolithic bundle.

`/llms-full.txt` is also treated as a static agent-readability artifact (alongside
`llms.txt`, sitemap files, `robots.txt`, search JSON, and `agent-readability.json`),
so it is served as-is and not rewritten as a missing markdown page.

## At least two optional frontmatter fields

`group` itself is optional. Other optional frontmatter fields include:

- **`description`** — optional but recommended, because it becomes the routing
  hint shown in `llms.txt`.
- **`icon`**
- **`deprecated`** / **`deprecatedReason`**
- **`experimental`**, **`canary`**, **`new`**, **`draft`**
- **`tags`**, **`availableIn`**, **`full`**
- **`lastModified`** and **`lastAuthor`** — these two are populated automatically
  when the `--enrich-git` flag is enabled.

(Only `title` is required.)
