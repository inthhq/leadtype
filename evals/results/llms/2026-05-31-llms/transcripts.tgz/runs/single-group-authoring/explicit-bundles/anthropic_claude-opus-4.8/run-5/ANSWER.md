# Frontmatter `group` and Monolithic Output in Leadtype

## What `group` is

In Leadtype, every MDX page carries YAML frontmatter. Only `title` is
required; `group` is **optional**, and when present it should match a slug
defined in `docs.config.ts`. A page can belong to a single group or to
multiple groups using array syntax (`group: [a, b]`). If a page declares an
**unknown** group, the build fails (and `leadtype lint` validates group
references).

## How `group` controls navigation

The `group` value is the single piece of metadata that organizes how content
is presented across surfaces. Specifically, it drives:

- **Sidebar position** — a page's place in the docs navigation.
- **The `llms.txt` section** — which section heading a page is listed under in
  the routing-oriented `/llms.txt` map.
- **Search metadata** — grouping used by the static search index.
- **AGENTS.md grouping** — how npm-bundled docs are organized.

The guiding principle from the reference docs: **use groups for routing, not
sharding**, and write group descriptions as routing hints rather than
marketing copy.

## How `group` relates to monolithic output (`/llms-full.txt`)

Monolithic output is produced by `generateLLMFullContextFiles`, which writes a
**single root `/llms-full.txt` file containing every generated markdown docs
page**.

The key point: `/llms-full.txt` is a full, unsplit fallback. It is **not
split or sharded by `group`**. Groups still organize the `llms.txt` sections,
navigation, search metadata, and AGENTS.md, but they are **not published as
per-group full-context files by default**. In other words, `group` shapes
discovery and navigation, while the monolithic bundle deliberately ignores
groups and includes all generated markdown pages.

(Note: the bundles under `/docs/llms-full/*.txt`, such as `authoring.txt` or
`reference.txt`, are curated topic bundles — distinct from the root
`/llms-full.txt`, which is the all-pages fallback.)

## Required vs. optional frontmatter fields

- **Required:** `title`
- **Optional (recommended):** `description` — becomes the routing hint shown in
  `llms.txt`.
- **Optional:** `group` — see above.

### Other optional frontmatter fields (at least two)

Leadtype supports many optional fields, including:

- `icon`
- `deprecated`
- `deprecatedReason`
- `experimental`
- `canary`
- `new`
- `draft`
- `tags`
- `availableIn`
- `full`
- `lastModified` — populated only when `--enrich-git` is enabled.
- `lastAuthor` — populated only when `--enrich-git` is enabled.

## Summary

`group` is an optional frontmatter field (matched against `docs.config.ts`)
that controls sidebar position, `llms.txt` sectioning, search metadata, and
AGENTS.md grouping — i.e., navigation and routing. The monolithic
`/llms-full.txt` output, by contrast, is a single root file containing every
generated markdown page and is intentionally **not** split by group.
