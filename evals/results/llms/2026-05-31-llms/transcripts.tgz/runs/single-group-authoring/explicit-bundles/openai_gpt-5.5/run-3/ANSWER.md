# Frontmatter `group` and `/llms-full.txt`

In Leadtype, each MDX page has YAML frontmatter. `title` is required; `group` is optional, but when used it should match a group slug from `docs.config.ts`.

`group` is a routing and organization signal:

- It controls where the page appears in the sidebar/navigation.
- It determines which section of `llms.txt` the page is listed under.
- It is included in search metadata.
- It affects grouping in generated `AGENTS.md`.
- A page can be assigned to multiple groups with `group: [a, b]`.
- If a page references an unknown group, the build fails.

`group` does **not** shard the full-context output. Leadtype’s `generateLLMFullContextFiles` writes one root `/llms-full.txt` containing every generated markdown docs page. Groups still organize navigation, `llms.txt`, search metadata, and `AGENTS.md`, but per-group full-context files are not published by default. In short: use groups for routing and organization, not for splitting `/llms-full.txt`.

Optional frontmatter fields include `description`, `icon`, `deprecated`, `deprecatedReason`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor`. `description` is recommended because it becomes a routing hint in `llms.txt`; `lastModified` and `lastAuthor` can be filled automatically when `--enrich-git` is enabled.
