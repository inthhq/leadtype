# Frontmatter Group and Monolithic Output

## How Frontmatter `group` Controls Navigation

In Leadtype, the `group` frontmatter field is optional but plays a crucial role in organizing documentation structure. The `group` value must match a slug from `docs.config.ts` and drives multiple aspects of the documentation system:

1. **Sidebar Navigation**: The group value controls where a page appears in the sidebar hierarchy of the documentation site.
2. **llms.txt Section Organization**: Pages are grouped into sections within the product-level `/llms.txt` file based on their assigned group.
3. **Search Metadata**: Group information is used to organize and categorize search results.
4. **AGENTS.md Grouping**: Pages are grouped in the `AGENTS.md` file used for npm-bundled documentation.

Pages can belong to multiple groups simultaneously using the syntax `group: [a, b]`, allowing flexible organization across multiple sections.

## Monolithic Output (`/llms-full.txt`)

The `/llms-full.txt` file is the root full-context fallback that contains every generated markdown docs page in a monolithic bundle. Unlike the group-organized `/llms.txt` file, which is split into sections based on the `group` frontmatter field, the `/llms-full.txt` file serves as a comprehensive, all-in-one output containing all documentation in portable markdown format.

**Key distinction**: Groups do not control the generation of per-group full-context files. Instead, groups are used for:
- Routing and navigation organization
- Not for sharding the monolithic output

The `generateLLMFullContextFiles` function writes this single root `/llms-full.txt` file, while groups continue to organize the sectioned `/llms.txt` output, navigation, search metadata, and `AGENTS.md`.

## Optional Frontmatter Fields

Leadtype supports several optional frontmatter fields beyond the required `title` field and the optional but recommended `description` and `group` fields:

1. **`icon`**: Specifies an icon for the page, useful for visual navigation and sidebar display.

2. **`deprecated`**: A boolean flag indicating whether the page or feature is deprecated. When set to `true`, it signals to users and AI agents that the content should not be used for new implementations.

3. **`new`**: Marks a page as newly added content, helping users identify recently introduced documentation or features.

4. **`tags`**: Allows tagging pages with multiple keywords for better categorization and search filtering.

5. **`draft`**: Indicates that the page is still in draft status and may not be complete.

6. **`experimental`**: Marks features or content as experimental, not yet stable.

7. **`canary`**: Similar to experimental, indicates canary/beta status.

8. **`deprecatedReason`**: Provides context about why something is deprecated.

9. **`availableIn`**: Specifies which versions or contexts the page applies to.

10. **`full`**: Controls full-context inclusion behavior.

11. **`lastModified`**: Automatically filled when `--enrich-git` is enabled, showing when the page was last modified.

12. **`lastAuthor`**: Automatically filled when `--enrich-git` is enabled, showing who last authored the page.

The `description` field is particularly important as it becomes the routing hint in `llms.txt`, helping AI agents understand page content at a glance.
