# Frontmatter `group` and `/llms-full.txt`

In Leadtype, every MDX page has YAML frontmatter. `title` is required, while `group` is optional but should match a group slug defined in `docs.config.ts`.

`group` is used for organization and routing metadata:

- It controls where the page appears in the sidebar/navigation.
- It determines the section where the page is listed in `llms.txt`.
- It is included in search metadata.
- It affects grouping in generated `AGENTS.md`.
- A page can belong to multiple groups with array syntax, for example `group: [a, b]`.
- If a page declares an unknown group, the build fails.

Groups do **not** shard the monolithic full-context output. The root `/llms-full.txt` is a fallback bundle containing every generated markdown docs page. Leadtype does not publish per-group full-context files by default; groups still organize navigation, `llms.txt`, search metadata, and `AGENTS.md`, but `/llms-full.txt` remains one combined output.

Optional frontmatter fields include `description`, `icon`, `deprecated`, `deprecatedReason`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor`. `description` is recommended because it becomes the routing hint in `llms.txt`; `lastModified` and `lastAuthor` can be filled automatically when `--enrich-git` is enabled.
