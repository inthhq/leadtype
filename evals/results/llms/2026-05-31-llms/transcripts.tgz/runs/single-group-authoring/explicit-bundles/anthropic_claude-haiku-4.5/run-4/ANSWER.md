# Frontmatter Group and Monolithic Output

## Overview

In Leadtype, the frontmatter `group` field is an optional but important parameter that controls both navigation and content aggregation within the documentation system. It serves as a key organizational mechanism that impacts multiple aspects of the documentation pipeline.

## How Frontmatter `group` Controls Navigation

The `group` field value must match a slug from `docs.config.ts` and directly drives the sidebar position in the website. Pages assigned to the same group are organized together in the sidebar, creating a logical hierarchy for site navigation.

## How Frontmatter `group` Controls Monolithic Output

The `group` value also controls how content is organized in the agent-readable bundles and monolithic output files:

- **Section Organization**: Pages are grouped by their assigned group value in the `llms.txt` file, creating separate sections for each group.
- **Search Metadata**: The group affects search metadata organization, helping categorize content for search functionality.
- **AGENTS.md Grouping**: Pages belonging to the same group are grouped together in the `AGENTS.md` file.
- **Multiple Groups Support**: Pages can belong to multiple groups using `group: [a, b]` syntax, appearing in multiple sections across these outputs.
- **Fallback to Monolithic**: The root `/llms-full.txt` serves as a comprehensive fallback that contains all generated markdown pages without group splitting. This ensures complete documentation is always available when group-based organization isn't needed or desired.

## Optional Frontmatter Fields

Beyond the required `title` field and the important `group` field, Leadtype supports several optional frontmatter fields:

1. **`description`** - While optional, this is recommended because it becomes the routing hint in `llms.txt`, providing contextual information for AI agents.
2. **`icon`** - Allows you to specify an icon to visually represent the page in navigation.
3. **`tags`** - Enables tagging of pages for better categorization and search.
4. **`lastModified`** - Automatically filled when `--enrich-git` is enabled during the build process, tracking when the page was last updated.

## Build Validation

It's important to note that if a page declares an unknown group (one that doesn't match a slug in `docs.config.ts`), the build will fail. This ensures consistency and prevents orphaned pages.
