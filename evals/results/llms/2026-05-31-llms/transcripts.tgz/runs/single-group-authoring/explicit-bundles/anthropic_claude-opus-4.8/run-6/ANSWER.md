# Frontmatter `group` and Monolithic Output in Leadtype

## What `group` is

Each MDX page in Leadtype carries YAML frontmatter. `title` is required, `description`
is optional (but recommended), and `group` is **optional**. When set, the `group`
value should match a slug defined in `docs.config.ts` — if a page declares an unknown
group, the build fails (and `leadtype lint` validates group references).

A page may belong to a single group or multiple groups using list syntax, e.g.
`group: [a, b]`.

## How `group` controls navigation

A single `group` value drives several pieces of organization at once:

- **Sidebar position** — the group determines where the page sits in the docs navigation.
- **`llms.txt` sections** — pages are grouped into sections of the product-level
  `/llms.txt` (and the docs-scoped `/docs/llms.txt` map).
- **Search metadata** — the group is attached to the search index entries.
- **`AGENTS.md` grouping** — the group organizes the npm-bundled `AGENTS.md`.

The guiding principle from the reference docs: **use groups for routing, not sharding**,
and group descriptions should read as routing hints rather than marketing copy.

## How `group` relates to monolithic output (`/llms-full.txt`)

`generateLLMFullContextFiles` writes **one** root `/llms-full.txt` file that contains
**every** generated markdown docs page. This monolithic fallback is **not split by
group** — groups still organize the `llms.txt` sections, navigation, search metadata,
and `AGENTS.md`, but they are **not** published as per-group full-context files by
default. In other words, `group` shapes how content is *routed and organized*, while
`/llms-full.txt` is a complete, un-sharded bundle of all pages.

(The CLI's `--json` output for website mode reports this artifact as `llmsFullTxt`,
alongside `docsLlmsTxt`, `llmsTxt`, and others.)

## At least two optional frontmatter fields

Besides `group` (and `description`), the optional frontmatter fields include:

- `icon`
- `deprecated`
- `deprecatedReason`
- `experimental`
- `canary`
- `new`
- `draft`
- `tags`
- `availableIn`
- `full`
- `lastModified` — filled in when `--enrich-git` is enabled
- `lastAuthor` — filled in when `--enrich-git` is enabled

**Two concrete examples:** `tags` (additional search/classification metadata) and
`deprecated` (marks a page as deprecated, paired with `deprecatedReason`).

## Summary

`group` is an optional frontmatter field that, when matched to a `docs.config.ts` slug,
simultaneously controls sidebar order, `llms.txt` sectioning, search metadata, and
`AGENTS.md` grouping — i.e., navigation and routing. The monolithic `/llms-full.txt`
deliberately ignores grouping and emits one file with all generated markdown pages.
