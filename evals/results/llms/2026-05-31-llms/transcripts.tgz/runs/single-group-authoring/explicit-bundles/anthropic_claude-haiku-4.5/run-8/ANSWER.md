# Frontmatter Group and Monolithic Output

## Overview

The `group` field in Leadtype frontmatter is an optional YAML field that serves multiple critical functions in controlling navigation and content organization across the documentation site, including the generation of monolithic output bundles.

## How `group` Controls Navigation and Monolithic Output

### Navigation Control

The `group` field drives several navigation-related aspects:

1. **Sidebar Position**: The group value determines where a page appears in the website's sidebar navigation
2. **Section Organization in llms.txt**: Each group gets its own section in the agent-readable `llms.txt` bundle
3. **Search Metadata**: Group information is included in search indexing, helping organize searchable content
4. **AGENTS.md Grouping**: Pages are grouped together in the AGENTS.md file based on their group assignment

### Monolithic Output (`/llms-full.txt`)

The `group` field works in conjunction with monolithic output as follows:

- Pages can belong to **multiple groups** using the syntax: `group: [a, b]`
- The root `/llms-full.txt` fallback contains **all generated markdown pages** and is **not split by group**, serving as a comprehensive, ungrouped bundle of all documentation
- If a page declares an unknown group (one that doesn't match a slug from `docs.config.ts`), the build fails

## Optional Frontmatter Fields

Beyond the required `title` and optional `group`, Leadtype supports the following optional frontmatter fields:

### Two Examples of Optional Fields:

1. **`deprecated`**: A boolean flag indicating whether a page or feature is deprecated. This helps users identify outdated content and can be paired with `deprecatedReason` to explain why.

2. **`tags`**: A field for assigning metadata tags to pages, enabling filtering and categorization beyond the group structure.

### Additional Optional Fields:

The complete list of optional fields includes: `icon`, `deprecated`, `deprecatedReason`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor` (the latter two are populated when `--enrich-git` is enabled).

## Summary

The `group` field in Leadtype's frontmatter is essential for structuring navigation hierarchies, organizing search results, and filtering content across various output formats. While the grouped llms.txt bundles split content by group, the monolithic `/llms-full.txt` provides a comprehensive, ungrouped fallback containing all markdown pages, ensuring complete context availability for LLM agents and comprehensive documentation access.
