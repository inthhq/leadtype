# Cross-group Agent Flows: Hosted vs npm Bundle

## Overview

Leadtype supports two complementary flows for agents to consume documentation:

1. **Hosted Website Flow**: HTTP agents accessing a public docs site
2. **npm Bundle Flow**: Coding agents accessing documentation bundled inside node_modules

Both flows start from different entry points and skip different artifacts based on their deployment context.

## Hosted Website Flow (HTTP Agents)

### Entry Point
- **Starting File**: `/llms.txt` (product-level root agent file)
- **Secondary Map**: `/docs/llms.txt` (docs-scoped agent map)

### Flow
HTTP agents start at `/llms.txt` and follow markdown links to navigate the documentation structure. The `/llms.txt` file provides the initial roadmap organized by groups.

### Generated Artifacts
Website mode generates the following complete set of artifacts:

**Root-level files:**
- `/llms.txt` - Product-level agent entry point
- `/llms-full.txt` - Root full-context file containing all generated markdown pages

**Documentation artifacts:**
- `/docs/*.md` - Markdown mirrors of all documentation
- `/docs/llms.txt` - Docs-scoped agent map
- `/docs/sitemap.xml` - XML sitemap
- `/docs/sitemap.md` - Markdown sitemap
- `/docs/robots.txt` - Robots directive
- `/docs/search-index.json` - Search metadata
- `/docs/search-content.json` - Search content
- `/docs/agent-readability.json` - Agent readability configuration

### Deployment Strategy
- Requires HTTP endpoints serving markdown with proper Accept headers
- Agents can fetch `/llms.txt` to discover endpoints
- AI user agents requesting docs pages receive text/markdown content
- All static artifacts remain discoverable for web indexing and agent discovery

## npm Bundle Flow (Coding Agents)

### Entry Point
- **Starting File**: `AGENTS.md` (package root agent entry point)

### Flow
Coding agents working inside installed npm packages start at `AGENTS.md` and follow relative `docs/*.md` links. This enables offline documentation access without requiring network requests.

### Generated Artifacts
Bundle mode writes only these files:

**Root-level files:**
- `AGENTS.md` - Package root agent entry point (npm bundle specific)

**Documentation:**
- `docs/*.md` - Markdown files with relative links

### Skipped Website-Only Artifacts
Bundle mode **intentionally skips** all website-only artifacts:

1. `llms.txt` - Product-level entry point (HTTP routing specific)
2. `llms-full.txt` - Full context fallback (website-only)
3. `docs/llms.txt` - Docs-scoped map (website routing)
4. `docs/sitemap.xml` - XML sitemap
5. `docs/sitemap.md` - Markdown sitemap
6. `docs/robots.txt` - Robots directive
7. `docs/search-index.json` - Search metadata
8. `docs/search-content.json` - Search content
9. `docs/agent-readability.json` - Agent readability config

### Deployment Strategy
- Uses relative links like `./docs/reference/cli.md`
- Works entirely offline inside node_modules
- No network requests needed for agent discovery or documentation access
- Ignores `product.agentGuidance` (written for website URL routing)

## Key Differences Summary

| Aspect | Hosted Website | npm Bundle |
|--------|---|---|
| **Agent Type** | HTTP agents | Coding agents |
| **Entry Point** | `/llms.txt` | `AGENTS.md` |
| **Link Style** | Absolute URLs (`/docs/*.md`) | Relative paths (`./docs/*.md`) |
| **Discovery** | HTTP + agent files | Direct filesystem access |
| **Network Required** | Yes | No |
| **Website Artifacts** | Generated | Skipped |
| **Full Context File** | `/llms-full.txt` | None |

## Complementary Deployment

A package can publish both flows simultaneously:
- **Hosted**: Provide `/llms.txt` and markdown at stable URLs for HTTP agents
- **Bundled**: Include `AGENTS.md` and `docs/*.md` in the npm package for offline agents

This allows documentation consumers to choose between network-based and offline-first agent access patterns.
