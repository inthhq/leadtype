# Cross-group agent flows: hosted website vs npm package bundle

Leadtype supports two complementary agent flows:

## Hosted website flow

- **When to use:** For a docs site that should expose HTTP-discoverable agent files.
- **Agent starting file:** `/llms.txt` at the site root.
- **How agents continue:** HTTP agents follow markdown links from `/llms.txt`, including the full-context router at `/llms-full.txt` and markdown mirrors under `/docs/*.md`.
- **Generated/served website artifacts:** Website mode writes `/llms.txt`, `/llms-full.txt`, markdown mirrors under `/docs/*.md`, sitemap files, robots.txt, search JSON, and `agent-readability.json`. The docs also mention `/docs/llms.txt`, `docs/sitemap.xml`, `docs/sitemap.md`, `docs/robots.txt`, `docs/search-index.json`, and `docs/search-content.json` as website-mode outputs.
- **Serving behavior:** For agent requests, the hosted site should serve markdown when the `Accept` header asks for `text/markdown` or when a known AI user agent requests a docs page.

## npm package bundle flow

- **When to use:** When publishing an npm package with offline, version-matched docs inside the tarball.
- **Command:** `leadtype generate --bundle`.
- **Agent starting file:** `AGENTS.md` at the package root.
- **How agents continue:** Coding agents working inside `node_modules` follow relative links from `AGENTS.md`, such as `./docs/reference/cli.md`, to `docs/*.md` files bundled with the package. This works without a network request.

## Website artifacts skipped by bundle mode

Bundle mode writes only `AGENTS.md` plus bundled `docs/*.md` files for npm packages. It skips these website-only artifacts:

- `llms.txt`
- `llms-full.txt`
- search JSON
- sitemap files
- `robots.txt`
- `agent-readability.json`

In short: hosted agents start from `/llms.txt` on the website, while package-local coding agents start from `AGENTS.md` inside the installed npm package.