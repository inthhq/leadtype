# Cross-group agent flows: hosted website vs. npm package bundle

Leadtype turns one MDX source into two complementary agent-facing delivery
flows. Both are produced by `leadtype generate`, but they target different
agent environments and emit different artifacts.

## The two flows at a glance

| | Hosted website flow | npm package bundle flow |
|---|---|---|
| Command | `leadtype generate` (website mode, default) | `leadtype generate --bundle` |
| Target agent | HTTP/URL-based agents fetching docs over the network | Coding agents reading docs inside `node_modules` (offline) |
| Entry file | `/llms.txt` | `AGENTS.md` (at the package root) |
| Link style | Absolute, URL-based markdown links | Relative links (e.g. `./docs/reference/cli.md`) |

## Which file each flow starts from

- **Hosted website flow:** HTTP agents start at **`/llms.txt`** and follow
  markdown links. `/llms.txt` is the product-level router; `/docs/llms.txt`
  provides the docs-scoped map, and `/llms-full.txt` is the full-context
  router that points to topic-specific deep-context files.
- **npm package bundle flow:** Coding agents working inside an installed npm
  package start at **`AGENTS.md`** and follow relative `docs/*.md` links so
  they can read docs from within `node_modules` without any network request.

(Source: `docs/how-it-works.md` — "HTTP agents start at /llms.txt and follow
markdown links. Coding agents working inside installed npm packages start at
AGENTS.md and follow relative docs/*.md links.")

## What each flow generates

### Website mode (`leadtype generate`)
Writes the full set of HTTP-discoverable artifacts:

- `/llms.txt`
- `/docs/llms.txt`
- `/llms-full.txt`
- Markdown mirrors under `/docs/*.md`
- `docs/sitemap.xml`
- `docs/sitemap.md`
- `docs/robots.txt`
- `docs/agent-readability.json`
- `docs/search-index.json`
- `docs/search-content.json`

(The `--json` output of website mode reports these as `llmsFullTxt`,
`docsLlmsTxt`, `llmsTxt`, `agentReadabilityJson`, `sitemapXml`, `sitemapMd`,
`robotsTxt`, `searchIndex`, and `searchContent`.)

### Bundle mode (`leadtype generate --bundle`)
Writes only the offline, package-local artifacts:

- `AGENTS.md` at the package root
- `docs/*.md` beneath it, with relative links that work inside `node_modules`

Note: `generateAgentsMd` intentionally ignores `product.agentGuidance`,
because that guidance text is written specifically for website URL routing,
not for the bundled offline docs.

## Website artifacts that bundle mode skips

Bundle mode produces no website-only routing, discovery, or search artifacts.
It explicitly **skips**:

- `llms.txt`
- `llms-full.txt`
- Search JSON (`search-index.json` and `search-content.json`)
- Sitemap files (`sitemap.xml` and `sitemap.md`)
- `robots.txt`
- `agent-readability.json`

(Source: `docs/package-docs/bundle.md` — "Bundle mode skips website-only
artifacts: llms.txt, llms-full.txt, search JSON, sitemap files, robots.txt,
and agent-readability.json." These are the same paths recognized by
`isAgentReadabilityArtifactPath` as website artifacts.)

## How the flows complement each other

The two flows are not mutually exclusive. A single package can both:

- publish **bundled offline docs** (`AGENTS.md` + relative `docs/*.md`) for
  coding agents working inside `node_modules`, and
- deploy a **hosted docs website** with `llms.txt` and markdown mirrors for
  URL-based HTTP agents (which should serve markdown when `Accept:
  text/markdown` or a known AI user agent requests a docs page, while keeping
  `llms.txt`, `llms-full.txt`, sitemaps, `robots.txt`, search JSON, and
  `agent-readability.json` as static artifacts).
