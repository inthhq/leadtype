# Cross-group agent flows: hosted vs npm bundle

Leadtype supports two complementary agent documentation flows:

## Hosted website flow

Use **website mode** when documentation should be discoverable over HTTP from a hosted docs site.

Agents start at:

- `/llms.txt`

From there, agents can follow links such as:

- `/llms-full.txt` for routing into deeper topic files
- Markdown mirrors under `/docs/*.md`

In this flow, the site also keeps website-oriented static artifacts available, including sitemap, robots, search, and agent-readability files. Agents can fetch docs pages as markdown, especially when the request asks for `text/markdown` or comes from a known AI user agent.

## npm package bundle flow

Use **bundle mode** when publishing docs inside an npm package for coding agents working offline in `node_modules`.

Run:

```sh
leadtype generate --bundle
```

Agents start at:

- `AGENTS.md` at the package root

`AGENTS.md` uses relative links such as:

- `./docs/reference/cli.md`

The bundled package includes markdown docs under:

- `docs/*.md`

This lets agents read version-matched package documentation locally without making network requests.

## Website artifacts skipped by bundle mode

Bundle mode deliberately skips website-only artifacts. It does **not** emit:

- `llms.txt`
- `llms-full.txt`
- search JSON
- sitemap files
- `robots.txt`
- `agent-readability.json`

In short: hosted docs are URL-based and start from `/llms.txt`; bundled npm docs are filesystem-based and start from `AGENTS.md`.