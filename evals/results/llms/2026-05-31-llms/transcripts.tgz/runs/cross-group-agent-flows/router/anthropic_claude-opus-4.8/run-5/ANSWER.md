# Cross-group agent flows: hosted website vs npm package bundle

Leadtype turns one MDX source into two complementary agent flows. Both are produced
by `leadtype generate`, but they target different runtime environments and emit
different artifacts.

## The two flows at a glance

| | Hosted website flow | npm package bundle flow |
| --- | --- | --- |
| Command | `leadtype generate` (website mode) | `leadtype generate --bundle` |
| Agent type | HTTP / URL-based agents | Coding agents reading inside `node_modules` |
| Entry file | `/llms.txt` | `AGENTS.md` (package root) |
| Link style | Absolute URLs / markdown mirrors (`/docs/*.md`) | Relative links (`./docs/reference/cli.md`) |
| Network needed? | Yes (fetched over HTTP) | No (read offline from disk) |

## Which file each flow starts from

- **Hosted website flow:** HTTP agents start at **`/llms.txt`** at the site root and
  follow markdown links (the `/docs/*.md` mirrors). `/llms.txt` routes to
  `/llms-full.txt`, which in turn routes to topic-specific deep-context files.
- **npm package bundle flow:** Coding agents working inside an installed npm package
  start at **`AGENTS.md`** at the package root and follow relative `./docs/*.md`
  links so they can read docs inside `node_modules` without any network request.

## What each flow emits

**Website mode** (`leadtype generate`) writes the full set of HTTP-discoverable artifacts:

- `/llms.txt` and `/docs/llms.txt`
- `/llms-full.txt` (the full-context router)
- Markdown mirrors under `/docs/*.md`
- `docs/sitemap.xml` and `docs/sitemap.md`
- `docs/robots.txt`
- `docs/agent-readability.json`
- `docs/search-index.json` and `docs/search-content.json`

It also serves markdown when `Accept: text/markdown` is requested or when a known AI
user agent requests a docs page, while keeping `llms.txt`, `llms-full.txt`, sitemap
files, `robots.txt`, search JSON, and `agent-readability.json` as static artifacts.

**Bundle mode** (`leadtype generate --bundle`) writes only what an offline agent needs:

- `AGENTS.md` at the package root
- `docs/*.md` beneath it, with relative links that work inside `node_modules`

## Which website artifacts bundle mode skips

Bundle mode deliberately omits the website-only (HTTP-discoverable) artifacts, because
an agent reading from `node_modules` has no HTTP layer to serve or discover them:

- `llms.txt`
- `llms-full.txt`
- search JSON (`search-index.json` / `search-content.json`)
- sitemap files (`sitemap.xml` / `sitemap.md`)
- `robots.txt`
- `agent-readability.json`

## How they complement each other

The two flows are not mutually exclusive. A single package can publish **bundled
offline docs** (`AGENTS.md` + `docs/*.md`) for agents inside `node_modules`, *and* a
**hosted docs website** with `llms.txt` for URL-based agents. Website mode optimizes
for HTTP discovery and search; bundle mode optimizes for self-contained, network-free,
version-matched docs that ship inside the npm tarball.
