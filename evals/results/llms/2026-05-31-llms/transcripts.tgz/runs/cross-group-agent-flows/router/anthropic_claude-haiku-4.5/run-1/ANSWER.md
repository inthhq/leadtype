# Cross-group Agent Flows: Hosted vs NPM Bundle

## Hosted Website Flow (Website Mode)

The hosted website flow is designed for HTTP-discoverable agent files and is activated when generating a docs site for web hosting.

### Starting Files
- **`/llms.txt`** at the site root - This is the entry point for agent discovery
- **`/llms-full.txt`** - The full context router for more detailed topic navigation
- **`/docs/*.md`** - Markdown mirrors of documentation

### Key Characteristics
- Agents discover documentation via HTTP requests
- When an agent requests a docs page with `Accept: text/markdown` or via a known AI user agent, the server responds with markdown format
- Full set of website infrastructure artifacts are preserved for navigation and discoverability

### Artifacts Generated
- `/llms.txt` and `/llms-full.txt` (navigation entry points)
- `/docs/sitemap.xml` (sitemap for crawling)
- `/robots.txt` (with allowance for /llms.txt)
- Search JSON (for agent search capabilities)
- `agent-readability.json` (readability metadata)
- Markdown content under `/docs/*.md`

---

## NPM Package Bundle Flow (Bundle Mode)

The NPM package bundle flow is designed for offline consumption when publishing an npm package.

### Starting Files
- **`AGENTS.md`** at the package root - This is the entry point for agents consuming the bundle
- **`docs/*.md`** - Markdown documentation nested beneath the root

### Key Characteristics
- Uses relative links (e.g., `./docs/reference/cli.md`) so agents can read docs inside `node_modules` without network requests
- Completely offline—no HTTP discovery needed
- Self-contained within the tarball

### Artifacts Skipped (Website-Only)
The bundle mode intentionally **skips these website-only artifacts**:
- `llms.txt` - HTTP discovery mechanism
- `llms-full.txt` - HTTP-based router
- Search JSON - Not needed for offline consumption
- Sitemap files (e.g., `/docs/sitemap.xml`) - Not needed without HTTP crawling
- `robots.txt` - Not applicable in npm context
- `agent-readability.json` - Not needed for offline use

---

## Summary

| Aspect | Hosted Website | NPM Bundle |
|--------|---|---|
| **Entry Point** | `/llms.txt` | `AGENTS.md` |
| **Discovery Method** | HTTP-based | File system (in `node_modules`) |
| **Link Strategy** | Absolute URLs (served via HTTP) | Relative links (e.g., `./docs/`) |
| **Infrastructure** | Full (sitemap, robots.txt, search, etc.) | Minimal (docs only) |
| **Use Case** | Online documentation site | Offline agent access in npm packages |

The key insight is that **hosted flow prioritizes HTTP discoverability** with a full ecosystem of navigation tools, while **bundle flow prioritizes offline accessibility** with self-contained relative linking and minimal overhead.
