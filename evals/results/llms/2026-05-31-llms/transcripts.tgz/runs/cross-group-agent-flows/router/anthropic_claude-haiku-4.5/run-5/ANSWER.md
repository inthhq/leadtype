# Cross-group Agent Flows: Hosted vs NPM Bundle

## Overview
Leadtype supports two complementary agent flows that serve different deployment contexts: a hosted website flow for HTTP-based agents and an npm bundle flow for coding agents working inside installed packages.

## Hosted Website Flow

**Starting Point:** `/llms.txt`

The hosted website flow is designed for HTTP-discoverable agent files:

1. HTTP agents start by fetching `/llms.txt` at the site root
2. Agents follow markdown links through the documentation
3. The build generates a full set of website artifacts for serving both humans and agents

**Generated Artifacts:**
- `/llms.txt` - Router for small context
- `/llms-full.txt` - Full context router to topic-specific files
- `/docs/*.md` - Markdown mirrors of all doc pages
- `/docs/sitemap.xml` - XML sitemap for discoverability
- `/docs/sitemap.md` - Markdown sitemap
- `/docs/robots.txt` - Robot rules
- `/docs/agent-readability.json` - Agent readability metadata
- `/docs/search-index.json` - Search index
- `/docs/search-content.json` - Search content data

## NPM Bundle Flow

**Starting Point:** `AGENTS.md` (at package root)

The npm bundle flow is designed for coding agents working inside installed node_modules:

1. Coding agents start at `AGENTS.md` in the package root
2. Agents follow relative links like `./docs/reference/cli.md`
3. The build generates minimal artifacts optimized for offline access
4. All links are relative, enabling agents to discover docs without network requests

**Generated Artifacts:**
- `AGENTS.md` - Agent entrypoint with relative links
- `docs/*.md` - Markdown docs beneath the package root

## Artifacts Skipped in Bundle Mode

The following website-only artifacts are **not generated** in bundle mode:

- `llms.txt` - Small context router (HTTP-specific)
- `llms-full.txt` - Full context router (HTTP-specific)
- Search JSON files (`search-index.json`, `search-content.json`)
- Sitemap files (`sitemap.xml`, `sitemap.md`)
- `robots.txt` - Web crawler rules (not needed in node_modules)
- `agent-readability.json` - Agent readability metadata

## Key Differences Summary

| Aspect | Hosted Website | NPM Bundle |
|--------|---|---|
| **Agent Starting Point** | `/llms.txt` | `AGENTS.md` |
| **Link Style** | HTTP URLs | Relative paths (e.g., `./docs/reference/cli.md`) |
| **Network Dependency** | Requires HTTP requests | Offline (no network needed) |
| **Router Files** | llms.txt, llms-full.txt | None |
| **Search Support** | Full search index included | Search JSON skipped |
| **Sitemap** | XML and markdown sitemaps | Skipped |
| **Robot Rules** | robots.txt included | Skipped |
| **Metadata** | agent-readability.json | Skipped |

## Complementary Deployment

A single package can use both flows simultaneously:
- Publish bundled offline docs for `node_modules` (bundle mode)
- Maintain a hosted docs website with `/llms.txt` for URL-based HTTP agents (website mode)

This allows developers working with the package to have fast, offline agent access while also supporting web-based documentation for external agents.
