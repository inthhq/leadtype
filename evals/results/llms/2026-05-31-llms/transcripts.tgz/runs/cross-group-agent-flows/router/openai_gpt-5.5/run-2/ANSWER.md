# Cross-group agent flows: hosted website vs npm bundle

## Hosted website flow

- **Starting file:** HTTP/URL-based agents start at the site-root **`/llms.txt`**.
- From there, they follow markdown links to the router/full-context files and generated markdown mirrors such as **`/docs/*.md`**.
- Website mode is intended for docs exposed over HTTP. It generates agent-readable static artifacts including:
  - **`/llms.txt`**
  - **`/docs/llms.txt`**
  - **`/llms-full.txt`**
  - markdown mirrors under **`/docs/*.md`**
  - sitemap files such as **`sitemap.xml`** and **`sitemap.md`**
  - **`robots.txt`**
  - **`agent-readability.json`**
  - search JSON such as **`search-index.json`** and **`search-content.json`**
- In this flow, groups are used as routing hints for agents and organize `llms.txt` sections, navigation, search metadata, and related output.

## npm package bundle flow

- **Starting file:** coding agents working inside an installed npm package start at package-root **`AGENTS.md`**.
- From there, they follow **relative links** into bundled markdown docs, for example **`./docs/reference/cli.md`**.
- Bundle mode is produced with **`leadtype generate --bundle`** and is meant for offline/version-matched docs inside an npm tarball or `node_modules`.
- It writes:
  - **`AGENTS.md`** at the package root
  - **`docs/*.md`** beneath it

## Website artifacts skipped by bundle mode

Bundle mode intentionally does **not** emit website-only artifacts. It skips:

- **`llms.txt`**
- **`llms-full.txt`**
- search JSON, including **`search-index.json`** and **`search-content.json`**
- sitemap files, including **`sitemap.xml`** and **`sitemap.md`**
- **`robots.txt`**
- **`agent-readability.json`**

In short: hosted agents begin at **`/llms.txt`** and navigate URL-based markdown artifacts, while npm-bundled coding agents begin at **`AGENTS.md`** and navigate relative `docs/*.md` files inside the package.