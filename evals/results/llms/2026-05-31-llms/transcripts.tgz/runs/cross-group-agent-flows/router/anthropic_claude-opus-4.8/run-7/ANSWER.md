# Cross-group agent flows: hosted website vs npm package bundle

Leadtype turns one MDX source into two complementary agent flows. Both are produced by `leadtype generate`, but they target different consumers and emit different artifacts.

## The two flows at a glance

| | Hosted website flow | npm package bundle flow |
| --- | --- | --- |
| Command | `leadtype generate` (website mode, default) | `leadtype generate --bundle` |
| Agent type | HTTP / URL-based agents | Coding agents inside installed `node_modules` |
| Entry file | `/llms.txt` | `AGENTS.md` (package root) |
| Link style | Absolute/site URLs followed over HTTP | Relative links (e.g. `./docs/reference/cli.md`), no network needed |

## Which file each flow starts from

- **Hosted website flow:** HTTP agents start at **`/llms.txt`** and follow markdown links. `/llms.txt` routes to `/llms-full.txt` (the full-context router) and on to topic deep-context files and the `/docs/*.md` markdown mirrors.
- **npm package bundle flow:** Coding agents working inside an installed npm package start at **`AGENTS.md`** at the package root and follow relative `./docs/*.md` links. Because the links are relative, agents can read the docs directly inside `node_modules` without making any network request.

(Per the docs, these flows complement each other: a package can publish bundled offline docs for `node_modules` *and* a hosted docs website with `llms.txt` for URL-based agents.)

## What the website flow generates

Website mode writes the full set of HTTP-discoverable agent artifacts:

- `/llms.txt` and `/docs/llms.txt`
- `/llms-full.txt` (root full-context router/fallback)
- Markdown mirrors under `/docs/*.md`
- `docs/sitemap.xml` and `docs/sitemap.md`
- `docs/robots.txt`
- `docs/agent-readability.json`
- `docs/search-index.json` and `docs/search-content.json`

(The `--json` output for website mode lists exactly these paths: `llmsTxt`, `docsLlmsTxt`, `llmsFullTxt`, `agentReadabilityJson`, `sitemapXml`, `sitemapMd`, `robotsTxt`, `searchIndex`, and `searchContent`.)

## What the bundle flow generates

Bundle mode (`--bundle`) writes only what an offline coding agent needs:

- `AGENTS.md` at the package root
- `docs/*.md` beneath it, linked with relative paths

Note that `generateAgentsMd` intentionally ignores `product.agentGuidance`, because that guidance text is written specifically for website URL routing and is not meaningful inside a bundled package.

## Website artifacts that bundle mode skips

Bundle mode deliberately omits the website-only artifacts, because they assume HTTP serving, a site root, and a hosted search runtime that don't exist inside `node_modules`:

- `llms.txt`
- `llms-full.txt`
- Search JSON (`search-index.json` and `search-content.json`)
- Sitemap files (`sitemap.xml` and `sitemap.md`)
- `robots.txt`
- `agent-readability.json`

These are the same paths that `isAgentReadabilityArtifactPath` recognizes as artifact paths (llms.txt, llms-full.txt, sitemap files, robots.txt, search JSON, and agent-readability.json) — they are website infrastructure, so they are skipped in the bundle.

## Summary

- **Hosted flow:** entry at `/llms.txt`, full HTTP artifact set (llms.txt, docs/llms.txt, llms-full.txt, markdown mirrors, sitemaps, robots.txt, agent-readability.json, search JSON), served with markdown content negotiation.
- **Bundle flow:** entry at `AGENTS.md`, relative `docs/*.md` links for offline reads in `node_modules`, and it skips every website-only artifact above (llms.txt, llms-full.txt, search JSON, sitemap files, robots.txt, agent-readability.json).
