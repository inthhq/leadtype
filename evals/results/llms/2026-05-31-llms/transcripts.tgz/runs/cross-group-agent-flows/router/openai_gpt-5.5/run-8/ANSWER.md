# Cross-group agent flows: hosted vs npm bundle

## Hosted website flow

For a hosted Leadtype docs site, agents start at the site-root `/llms.txt`. That file points them to `/llms-full.txt`, the full-context router, which then routes to the smallest relevant topic deep-context file such as `/docs/llms-full/build.txt` or `/docs/llms-full/package-docs.txt`. Hosted website mode also exposes markdown mirrors for docs pages under `/docs/*.md`; docs pages should be served as markdown when the request asks for `text/markdown` or comes from a known AI user agent.

Hosted website generation includes HTTP-discoverable artifacts such as:

- `/llms.txt`
- `/llms-full.txt`
- `/docs/llms.txt` docs-scoped map
- markdown mirrors under `/docs/*.md`
- sitemap files
- `robots.txt`
- search JSON
- `agent-readability.json`

## npm package bundle flow

For an npm package, agents do not start from the hosted website routing files. Bundle mode is intended for offline, version-matched docs inside the published tarball. It writes `AGENTS.md` at the package root and `docs/*.md` beneath it. Agents start from package-root `AGENTS.md`, then follow relative links such as `./docs/reference/cli.md` inside `node_modules`, without making a network request.

## Website artifacts skipped by bundle mode

`leadtype generate --bundle` skips website-only artifacts:

- `llms.txt`
- `llms-full.txt`
- search JSON
- sitemap files
- `robots.txt`
- `agent-readability.json`

In short: hosted docs start from `/llms.txt` and use website routing plus static web artifacts; npm-bundled docs start from `AGENTS.md` and use relative in-package markdown links, omitting the website-only discovery, search, sitemap, robots, and readability artifacts.
