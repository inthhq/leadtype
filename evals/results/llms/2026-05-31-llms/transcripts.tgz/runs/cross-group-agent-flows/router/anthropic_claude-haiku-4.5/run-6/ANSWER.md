# Cross-Group Agent Flows: Hosted vs NPM Bundle

## Overview
Leadtype supports two distinct agent flows for accessing documentation: a hosted website flow for HTTP agents and an npm bundle flow for coding agents working offline inside node_modules.

## Hosted Website Flow
**Starting File:** `/llms.txt`

The hosted website flow begins with agents fetching `/llms.txt` at the site root. From there, agents follow markdown links to discover and navigate the full documentation hierarchy.

**Website Artifacts Generated:**
- `/llms.txt` (entry point)
- `/llms-full.txt` (full context router)
- `/docs/*.md` (markdown mirrors)
- `/docs/sitemap.xml` and `/docs/sitemap.md` (navigation)
- `/docs/robots.txt` (crawling directives)
- `/docs/agent-readability.json` (agent capabilities)
- `/docs/search-index.json` and `/docs/search-content.json` (search indexes)

## NPM Bundle Flow
**Starting File:** `AGENTS.md` (at package root)

The bundle flow is designed for coding agents working offline inside installed npm packages. Agents start by reading `AGENTS.md` at the package root and follow relative links to discover documentation.

**Bundle Artifacts Generated:**
- `AGENTS.md` (entry point)
- `docs/*.md` (documentation with relative links)

All links in `AGENTS.md` use relative paths like `./docs/reference/cli.md`, allowing agents to resolve documentation without network requests.

## Key Differences: Website Artifacts Skipped in Bundle Mode

Bundle mode explicitly skips all website-only artifacts:
- `llms.txt` - Not needed for offline agents
- `llms-full.txt` - Not needed for offline agents
- Search JSON files - Not applicable for offline access
- Sitemap files - Not needed for node_modules agents
- `robots.txt` - Not applicable for npm packages
- `agent-readability.json` - Not needed for bundled docs

## Summary

| Aspect | Hosted Website | NPM Bundle |
|--------|---|---|
| **Entry Point** | `/llms.txt` | `AGENTS.md` |
| **Link Style** | Absolute HTTP URLs | Relative file paths (`./docs/...`) |
| **Access Pattern** | HTTP discovery | Offline, inside node_modules |
| **Discovery Mechanism** | Follows markdown links from llms.txt | Follows relative links from AGENTS.md |
| **Extra Artifacts** | All 8 file types listed above | None; only docs + AGENTS.md |

The two flows are complementary and allow a single MDX source to serve both URL-based HTTP agents (via hosted website) and offline coding agents (via npm bundles).
