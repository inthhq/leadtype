# Cross-group agent flows: hosted website vs npm bundle

Leadtype turns one MDX source into two complementary agent flows. Both come out of `leadtype generate`, but they target different consumers, start from different entry files, and emit different artifacts.

## The two flows at a glance

| | Hosted website flow | npm package bundle flow |
|---|---|---|
| Consumer | HTTP / URL-based agents | Coding agents inside installed `node_modules` |
| Command | `leadtype generate` (website mode, the default) | `leadtype generate --bundle` |
| Entry file | `/llms.txt` | `AGENTS.md` (at the package root) |
| Link style | Markdown links to HTTP-discoverable URLs (`/docs/*.md`) | Relative links (e.g. `./docs/reference/cli.md`) that work offline |

These flows are designed to complement each other: a package can ship bundled offline docs for `node_modules` **and** publish a hosted docs website with `llms.txt` for URL-based agents.

## Where each flow starts

- **Hosted website flow:** HTTP agents start at **`/llms.txt`** and follow markdown links. The site serves markdown when `Accept: text/markdown` is requested (or when a known AI user agent requests a docs page), with markdown mirrors under `/docs/*.md`.
- **npm bundle flow:** Coding agents working inside installed npm packages start at **`AGENTS.md`** and follow relative `docs/*.md` links — so they can read docs inside `node_modules` without any network request.

## What each flow emits

**Website mode** (`leadtype generate`) writes the full set of HTTP-discoverable artifacts:

- `/llms.txt` and `/docs/llms.txt` (the docs-scoped map)
- `/llms-full.txt` (one root full-context router containing every generated markdown page)
- Markdown mirrors under `/docs/*.md`
- `docs/sitemap.xml` and `docs/sitemap.md`
- `docs/robots.txt`
- `docs/agent-readability.json`
- `docs/search-index.json` and `docs/search-content.json` (the static search index)

**Bundle mode** (`leadtype generate --bundle`) writes only what an offline agent needs inside the tarball:

- `AGENTS.md` at the package root
- `docs/*.md` beneath it, with relative links

Note: `AGENTS.md` intentionally ignores `product.agentGuidance`, because that text is written specifically for website URL routing.

## Which website artifacts bundle mode skips

Bundle mode skips all the website-only, HTTP-discoverable artifacts:

- `llms.txt`
- `llms-full.txt`
- search JSON (`search-index.json` / `search-content.json`)
- sitemap files (`sitemap.xml`, `sitemap.md`)
- `robots.txt`
- `agent-readability.json`

This is the same set that `isAgentReadabilityArtifactPath` recognizes as artifact paths (llms.txt, llms-full.txt, sitemap files, robots.txt, search JSON, and agent-readability.json) — files that exist to support the website flow and have no role in an offline npm bundle.

## A note on groups

Groups organize `llms.txt` sections, navigation, search metadata, and `AGENTS.md`, but they are **not** published as per-group full-context files by default — `llms-full.txt` is a single root file. Groups are meant for routing hints, not for sharding the docs.
