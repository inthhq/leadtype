# Cross-group agent flows: hosted website vs npm bundle

Leadtype turns one MDX source into artifacts for two complementary agent flows. Both are
produced by `leadtype generate`, but they target different agents and emit different files.

## The two flows

| Flow | Target agent | Entry file | Link style |
| --- | --- | --- | --- |
| Hosted website (default mode) | HTTP/URL-based agents fetching over the network | `/llms.txt` | Absolute, HTTP-discoverable links to `/docs/*.md` |
| npm package bundle (`--bundle`) | Coding agents reading inside `node_modules` offline | `AGENTS.md` (at package root) | Relative links like `./docs/reference/cli.md` |

(Sources: `docs/how-it-works.md`, `docs/quickstart.md`, `docs/build/connect-docs-site.md`, `docs/package-docs/bundle.md`.)

## Hosted website flow — which files it starts from

- An HTTP agent **starts at `/llms.txt`** and follows markdown links from there
  (`docs/how-it-works.md`).
- `/llms.txt` is the product-level router; it points to the full-context router
  `/llms-full.txt`, which routes to per-topic deep-context files, which in turn link to the
  markdown mirrors under `/docs/*.md` (`llms.txt`, `llms-full.txt`,
  `docs/reference/llm.md`).
- Website mode also serves markdown for agent requests (when `Accept: text/markdown` or a
  known AI user agent asks for a docs page) and keeps a set of static support artifacts
  (`docs/build/connect-docs-site.md`).

Website mode artifacts written by `leadtype generate` (`docs/quickstart.md`):

- `/llms.txt` and `/docs/llms.txt`
- `/llms-full.txt`
- markdown mirrors under `/docs/*.md`
- `docs/sitemap.xml` and `docs/sitemap.md`
- `docs/robots.txt`
- `docs/agent-readability.json`
- `docs/search-index.json` and `docs/search-content.json`

## npm bundle flow — which files it starts from

- A coding agent working inside an installed npm package **starts at `AGENTS.md`** and
  follows relative `docs/*.md` links (`docs/how-it-works.md`).
- `leadtype generate --bundle` writes `AGENTS.md` at the package root and `docs/*.md`
  beneath it, using relative links (e.g. `./docs/reference/cli.md`) so agents can read the
  docs without a network request (`docs/package-docs/bundle.md`, `docs/quickstart.md`).
- `AGENTS.md` is produced by `generateAgentsMd`, which intentionally ignores
  `product.agentGuidance` because that guidance text is written for website URL routing
  (`docs/reference/llm.md`).

## Which website artifacts bundle mode skips

Bundle mode emits only `AGENTS.md` + `docs/*.md` and **skips the website-only artifacts**
(`docs/package-docs/bundle.md`):

- `llms.txt`
- `llms-full.txt`
- search JSON (`search-index.json` / `search-content.json`)
- sitemap files (`sitemap.xml` / `sitemap.md`)
- `robots.txt`
- `agent-readability.json`

This skip set matches the artifact paths that website mode treats as agent-readability
artifacts (`isAgentReadabilityArtifactPath` covers `llms.txt`, `llms-full.txt`, sitemap
files, `robots.txt`, search JSON, and `agent-readability.json` — `docs/reference/llm.md`).

## Why both exist

The flows complement each other: a single package can publish **bundled offline docs**
(entry: `AGENTS.md`, relative links) for agents working in `node_modules`, and a **hosted
docs website** (entry: `/llms.txt`, absolute links plus sitemaps, robots, and search JSON)
for URL-based agents (`docs/how-it-works.md`).
