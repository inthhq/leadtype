# Cross-group agent flows: hosted website vs npm bundle

Leadtype turns a single MDX source into two complementary agent-facing distributions. The docs describe these as **website mode** (hosted) and **bundle mode** (npm package). The two flows are documented across different topic groups — Build/Get Started for the hosted flow and Ship Package Docs/Get Started for the bundle flow — but they describe one shared pipeline emitting either website or package artifacts.

## Hosted website flow

**Where agents start:** HTTP/URL-based agents start at **`/llms.txt`** at the site root and follow markdown links from there (`/llms.txt` → `/llms-full.txt` router → topic files → `/docs/*.md` mirrors).

**How it works:** Website mode is used when a docs site should expose HTTP-discoverable agent files. The build serves markdown when the `Accept` header asks for `text/markdown` (or when a known AI user agent requests a docs page).

**Artifacts generated (website mode):**

- `/llms.txt` and `/docs/llms.txt`
- `/llms-full.txt` (the full-context router)
- Markdown mirrors under `/docs/*.md`
- `docs/sitemap.xml` and `docs/sitemap.md`
- `docs/robots.txt` (must allow `/llms.txt`)
- `docs/agent-readability.json`
- `docs/search-index.json` and `docs/search-content.json`

These are served as static artifacts and are the basis for the recommended verification checks (fetch `/llms.txt`, fetch a docs page with `Accept: text/markdown`, check `/docs/sitemap.xml`, confirm `/robots.txt` allows `/llms.txt`).

## npm package bundle flow

**Where agents start:** Coding agents working inside an installed npm package start at **`AGENTS.md`** at the package root and follow **relative** `./docs/*.md` links.

**How it works:** Bundle mode is invoked with `leadtype generate --bundle` when publishing an npm package. It writes `AGENTS.md` at the package root and `docs/*.md` beneath it. Links such as `./docs/reference/cli.md` are relative so agents can read the docs inside `node_modules` **without any network request** (offline).

**Artifacts generated (bundle mode):**

- `AGENTS.md` (package root)
- `docs/*.md` (with relative links)

## What bundle mode skips

Bundle mode deliberately skips the website-only artifacts because they require an HTTP host and absolute URLs:

- `llms.txt`
- `llms-full.txt`
- search JSON (`search-index.json` / `search-content.json`)
- sitemap files (`sitemap.xml` / `sitemap.md`)
- `robots.txt`
- `agent-readability.json`

## Summary

| | Hosted website flow | npm bundle flow |
|---|---|---|
| Trigger | `leadtype generate` (website mode) | `leadtype generate --bundle` |
| Agent entry point | `/llms.txt` (HTTP) | `AGENTS.md` (package root) |
| Link style | Absolute URL paths, follow markdown links | Relative `./docs/*.md` links |
| Access model | Network/HTTP, content negotiation on `Accept` | Offline, inside `node_modules`, no network |
| Markdown docs | `/docs/*.md` mirrors | `docs/*.md` |
| Routing/index files | `llms.txt`, `llms-full.txt`, search JSON, sitemaps, `robots.txt`, `agent-readability.json` | None of these — skipped |

The two flows complement each other: a single package can publish bundled offline docs for `node_modules` *and* a hosted docs website with `llms.txt` for URL-based agents.
