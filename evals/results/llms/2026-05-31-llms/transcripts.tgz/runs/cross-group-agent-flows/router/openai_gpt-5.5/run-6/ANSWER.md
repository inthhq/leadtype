# Hosted website flow vs npm package bundle flow for agents

## Hosted website flow

Use website mode when docs should be discoverable over HTTP.

- **Starting file:** `/llms.txt` at the website root.
- **Routing/context files:** `/llms.txt` points agents to the hosted full-context/router file, such as `/llms-full.txt`, which then links to the smallest relevant topic/deep-context files.
- **Content files:** generated markdown mirrors live under `/docs/*.md` and can be served directly, including when `Accept: text/markdown` is sent or a known AI user agent requests a docs page.
- **Static website artifacts kept:** `/llms.txt`, `/llms-full.txt`, sitemap files, `robots.txt`, search JSON, and `agent-readability.json`.

## npm package bundle flow

Use bundle mode when publishing an npm package so agents can read version-matched docs from `node_modules` without making network requests.

- **Command/mode:** `leadtype generate --bundle`.
- **Starting file:** `AGENTS.md` at the package root.
- **Content files:** markdown docs are written beneath `docs/*.md` inside the package.
- **Links:** `AGENTS.md` uses relative links such as `./docs/reference/cli.md` so coding agents can navigate the bundled docs locally.

## What bundle mode skips

Bundle mode skips the website-only artifacts used by the hosted HTTP flow:

- `llms.txt`
- `llms-full.txt`
- search JSON
- sitemap files
- `robots.txt`
- `agent-readability.json`

In short: hosted agents begin at `/llms.txt` and navigate HTTP-discoverable website artifacts and markdown mirrors; bundled package agents begin at package-root `AGENTS.md` and follow local relative links to `docs/*.md`, with the website-only discovery/search/sitemap artifacts omitted.