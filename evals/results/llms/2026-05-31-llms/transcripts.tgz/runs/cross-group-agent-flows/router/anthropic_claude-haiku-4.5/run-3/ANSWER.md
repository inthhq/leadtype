# Cross-group Agent Flows: Hosted vs NPM Bundle

## Overview

Leadtype supports two distinct cross-group agent flows, each designed for different deployment contexts:

1. **Hosted Website Flow**: For HTTP-based agents accessing a live docs site
2. **NPM Bundle Flow**: For coding agents accessing docs inside installed npm packages

---

## Hosted Website Flow

### Starting Point
HTTP agents start at **/llms.txt** (located at the site root)

### File Structure Generated
The hosted website mode produces these agent-readable artifacts:
- `/llms.txt` - Root discovery file for agents
- `/docs/llms.txt` - Docs-scoped map for routing
- `/llms-full.txt` - Complete full-context file with every markdown page
- `/docs/*.md` - Markdown mirrors of all documentation
- `docs/sitemap.xml` - XML sitemap for discovery
- `docs/sitemap.md` - Markdown sitemap
- `docs/robots.txt` - Robots directive
- `docs/agent-readability.json` - Agent readability metadata
- `docs/search-index.json` - Static search index (BM25-style)
- `docs/search-content.json` - Search content data

### How Agents Navigate
HTTP agents follow the discovery chain:
1. Fetch `/llms.txt` 
2. Follow markdown links from page to page
3. Use group routing to locate topics
4. Access content via HTTP requests

### Key Details
- Groups organize sections in `/llms.txt`
- `product.agentGuidance` text is used in hosted website artifacts
- Groups provide routing hints, not content sharding

---

## NPM Bundle Flow

### Starting Point
Coding agents start at **AGENTS.md** (located at the package root)

### File Structure Generated
The bundle mode (using `leadtype generate --bundle`) produces:
- `AGENTS.md` - Root discovery file for package agents
- `docs/*.md` - Markdown documentation files

### How Agents Navigate
Coding agents working inside installed npm packages:
1. Fetch `AGENTS.md` from the package root
2. Follow **relative links** like `./docs/reference/cli.md`
3. Read docs offline without network requests
4. Access content from the local filesystem

### Key Details
- Uses **relative links** instead of HTTP URLs
- Works completely offline inside `node_modules`
- `generateAgentsMd` intentionally **ignores** `product.agentGuidance` (that text is website-specific)
- Groups still organize AGENTS.md sections but are not published as per-group full-context files

---

## Website Artifacts Skipped in Bundle Mode

Bundle mode explicitly **skips** these website-only artifacts:

1. **llms.txt** - HTTP discovery file (no HTTP routing needed)
2. **llms-full.txt** - Full-context root file (not needed offline)
3. **search-index.json** - Static search index (agents can read markdown directly)
4. **search-content.json** - Search content data
5. **sitemap.xml** - XML sitemap (no HTTP discovery needed)
6. **sitemap.md** - Markdown sitemap
7. **robots.txt** - Robots directive (not applicable in node_modules)
8. **agent-readability.json** - Agent readability metadata (not needed for local access)

---

## Comparison Summary

| Aspect | Hosted Website | NPM Bundle |
|--------|---|---|
| **Starting File** | `/llms.txt` | `AGENTS.md` |
| **Agent Type** | HTTP-based agents | Coding agents |
| **Navigation** | HTTP links and markdown links | Relative filesystem links |
| **Network** | Requires HTTP requests | Completely offline |
| **Artifacts Generated** | ~13 files (full website suite) | 2 file types (AGENTS.md + docs/*.md) |
| **Product Guidance** | Included in website artifacts | Intentionally ignored |
| **Use Case** | Live hosted documentation | Local npm package documentation |

---

## Complementary Deployment

The two flows are complementary—a single package can publish both:
- **Bundled offline docs** for node_modules (npm bundle flow)
- **Hosted docs website** with llms.txt for URL-based agents (hosted flow)

This allows different agent types (HTTP-based and coding/import-based) to access the same underlying documentation through their respective optimal paths.
