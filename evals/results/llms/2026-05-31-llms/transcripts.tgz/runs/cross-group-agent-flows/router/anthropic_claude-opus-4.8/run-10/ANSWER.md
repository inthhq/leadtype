# Cross-group agent flows: hosted website vs npm bundle

Leadtype turns one MDX source into multiple agent-facing outputs. Two distinct
delivery flows exist for agents, and they start from different files and emit
different artifacts.

## 1. Hosted website flow (website mode)

**Purpose:** Expose HTTP-discoverable agent files so agents can fetch docs over
the network.

**Where the flow starts:**
- `/llms.txt` — the product-level entry/router served at the site root.
- `/llms-full.txt` — the full-context router that points agents to topic files.
- `/docs/*.md` — markdown mirrors of each docs page, served when an agent
  requests `Accept: text/markdown` or is a known AI user agent.

**Generation:** `leadtype generate` (without `--bundle`). With `--json`, the
website-mode object reports paths for:
`llmsTxt`, `docsLlmsTxt`, `llmsFullTxt`, `agentReadabilityJson`, `sitemapXml`,
`sitemapMd`, `robotsTxt`, `searchIndex`, and `searchContent`.

**Static website artifacts produced:**
- `/llms.txt` and `/docs/llms.txt` (product-level + docs-scoped maps, via `generateLlmsTxt`)
- `/llms-full.txt` (one root full-context file with every markdown page, via `generateLLMFullContextFiles`)
- `/docs/sitemap.xml` and the markdown sitemap
- `/robots.txt` (should allow `/llms.txt`)
- search JSON (static index + search content)
- `agent-readability.json`

**Verification:** fetch `/llms.txt`, fetch a docs page with
`Accept: text/markdown`, check `/docs/sitemap.xml`, and confirm `/robots.txt`
allows `/llms.txt`.

## 2. npm package bundle flow (bundle mode)

**Purpose:** Ship version-matched docs inside an npm tarball so coding agents
can read them **offline inside `node_modules` without a network request**.

**Where the flow starts:**
- `AGENTS.md` at the package root — the entry point for bundled docs
  (written by `generateAgentsMd`).
- `docs/*.md` beneath the package root — the bundled markdown pages.

`AGENTS.md` uses **relative** links such as `./docs/reference/cli.md` instead of
absolute site URLs, so navigation works locally without a server.

**Generation:** `leadtype generate --bundle`.

## Which website artifacts bundle mode skips

Because bundle mode is for offline, file-relative reading rather than HTTP
discovery, it intentionally omits all website-only artifacts:

- `llms.txt`
- `llms-full.txt`
- search JSON
- sitemap files
- `robots.txt`
- `agent-readability.json`

## Why the entry points differ

- The website flow relies on URL routing, so its entry files (`llms.txt`,
  `llms-full.txt`) and the product's `agentGuidance` are written for HTTP URL
  routing.
- `generateAgentsMd` intentionally ignores `product.agentGuidance` because that
  guidance text is written for website URL routing, not for the relative-link,
  in-package layout that bundle mode produces.

## Summary table

| Aspect | Hosted website flow | npm bundle flow |
| --- | --- | --- |
| Command | `leadtype generate` | `leadtype generate --bundle` |
| Starts from | `/llms.txt`, `/llms-full.txt`, `/docs/*.md` | `AGENTS.md` (root) + `docs/*.md` |
| Link style | Absolute site URLs / HTTP routing | Relative links (`./docs/...`) |
| Access model | Network fetch (Accept: text/markdown) | Offline read in `node_modules` |
| Emits llms.txt / llms-full.txt | Yes | No (skipped) |
| Emits search JSON | Yes | No (skipped) |
| Emits sitemap files | Yes | No (skipped) |
| Emits robots.txt | Yes | No (skipped) |
| Emits agent-readability.json | Yes | No (skipped) |
| Uses product.agentGuidance | Yes | No (ignored) |
