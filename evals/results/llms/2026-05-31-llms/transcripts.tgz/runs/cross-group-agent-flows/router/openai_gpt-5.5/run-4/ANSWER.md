# Cross-group agent flows: hosted website vs npm bundle

Leadtype supports two complementary agent flows:

## Hosted website flow

- **Starts at:** `/llms.txt` on the hosted site.
- **Then:** agents follow markdown links from that entry point. On this docs site, `/llms.txt` points to `/llms-full.txt`, which acts as the full-context router for choosing a smaller topic file.
- **Generated website artifacts include:**
  - `/llms.txt`
  - `/docs/llms.txt`
  - `/llms-full.txt`
  - markdown mirrors under `/docs/*.md`
  - sitemap files such as `docs/sitemap.xml` and `docs/sitemap.md`
  - `robots.txt`
  - `agent-readability.json`
  - search JSON such as `search-index.json` and `search-content.json`
- **HTTP behavior:** docs pages can be served as markdown when the request asks for `text/markdown` or comes from a known AI user agent.

## npm package bundle flow

- **Starts at:** `AGENTS.md` at the npm package root.
- **Then:** coding agents follow relative links such as `./docs/reference/cli.md` into the bundled `docs/*.md` files inside `node_modules`, without needing a network request.
- **Generated bundle artifacts include:**
  - `AGENTS.md`
  - `docs/*.md`
- **Purpose:** version-matched, offline docs inside the package tarball.

## What bundle mode skips

`leadtype generate --bundle` skips website-only artifacts:

- `llms.txt`
- `llms-full.txt`
- search JSON
- sitemap files
- `robots.txt`
- `agent-readability.json`

In short: URL-based agents use the hosted website flow starting from `/llms.txt`; coding agents inside installed npm packages use the bundle flow starting from `AGENTS.md`. Groups can organize routing, navigation, search metadata, and `AGENTS.md`, but Leadtype does not publish per-group full-context files by default.