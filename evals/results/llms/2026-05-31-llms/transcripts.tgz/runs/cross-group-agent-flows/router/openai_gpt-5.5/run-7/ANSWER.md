# Cross-group agent flows: hosted vs npm bundle

Leadtype supports two complementary agent flows from the same MDX source.

## Hosted website flow

Use website mode for HTTP-discoverable docs. Agents start at the site-root file:

- `/llms.txt`

From there, agents follow markdown links such as `/llms-full.txt` and topic or page markdown under `/docs/*.md`. The hosted build should also serve markdown for docs pages when `Accept: text/markdown` is requested or when a known AI user agent requests a docs page.

Website mode writes artifacts such as:

- `/llms.txt`
- `/docs/llms.txt`
- `/llms-full.txt`
- markdown mirrors under `/docs/*.md`
- sitemap files such as `/docs/sitemap.xml` and `/docs/sitemap.md`
- `/docs/robots.txt`
- `/docs/agent-readability.json`
- `/docs/search-index.json`
- `/docs/search-content.json`

## npm package bundle flow

Use bundle mode when publishing docs inside an npm package:

```sh
leadtype generate --bundle
```

Coding agents working in an installed package start at:

- `AGENTS.md`

`AGENTS.md` is written at the package root and uses relative links, for example `./docs/reference/cli.md`, so agents can read version-matched docs inside `node_modules` without making network requests. Bundle mode also writes markdown docs under `docs/*.md` in the package.

## Website artifacts skipped by bundle mode

Bundle mode intentionally skips website-only artifacts:

- `llms.txt`
- `llms-full.txt`
- search JSON
- sitemap files
- `robots.txt`
- `agent-readability.json`

In short: hosted agents enter through `/llms.txt` on the website; package-local coding agents enter through `AGENTS.md` in the npm tarball. The npm bundle keeps the offline markdown docs and relative links, but omits the HTTP/search/discovery artifacts needed only by the hosted site.
