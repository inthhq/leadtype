# Cross-group agent flows: hosted website vs npm package bundle

Leadtype turns one MDX source into two complementary agent-facing flows. The docs
describe them across two topic groups — **Build** (hosted website) and **Ship Package
Docs** (npm bundle) — with shared background in **Get Started**.

## The two flows at a glance

| Aspect | Hosted website flow | npm package bundle flow |
| --- | --- | --- |
| Command/mode | `leadtype generate` (website mode) | `leadtype generate --bundle` |
| Agent entry file | `/llms.txt` | `AGENTS.md` (at package root) |
| Link style | HTTP URLs to `/docs/*.md` mirrors | Relative links like `./docs/reference/cli.md` |
| Discovery | Network fetch (HTTP), Accept negotiation | Local reads inside `node_modules`, no network |
| Audience | URL-based / HTTP agents | Coding agents working inside installed packages |

## Which file each flow starts from

- **Hosted website flow:** HTTP agents **start at `/llms.txt`** at the site root and
  follow markdown links. `/llms.txt` routes to `/llms-full.txt` (the full-context
  router), which points to topic-specific deep-context files, which in turn link to
  the `/docs/*.md` markdown mirrors. The site can serve markdown when the request
  asks for `Accept: text/markdown` or comes from a known AI user agent.

- **npm package bundle flow:** Coding agents working inside an installed npm package
  **start at `AGENTS.md`** (written at the package root) and follow relative
  `./docs/*.md` links. Because the links are relative, agents can read the docs
  directly inside `node_modules` without making a network request.

The two flows complement each other: a single package can publish bundled offline
docs for `node_modules` **and** a hosted docs website with `llms.txt` for URL-based
agents.

## Artifacts each flow emits

**Website mode (`leadtype generate`) writes:**
- `/llms.txt` and `/docs/llms.txt`
- `/llms-full.txt`
- markdown mirrors under `/docs/*.md`
- `docs/sitemap.xml` and `docs/sitemap.md`
- `docs/robots.txt`
- `docs/agent-readability.json`
- `docs/search-index.json` and `docs/search-content.json`

**Bundle mode (`leadtype generate --bundle`) writes:**
- `AGENTS.md` at the package root
- `docs/*.md` beneath it (with relative links)

## Website artifacts that bundle mode skips

Bundle mode produces only `AGENTS.md` + `docs/*.md` and **skips the website-only
artifacts**:

- `llms.txt`
- `llms-full.txt`
- search JSON (`search-index.json` / `search-content.json`)
- sitemap files (`sitemap.xml` / `sitemap.md`)
- `robots.txt`
- `agent-readability.json`

These skipped files are exactly the static, HTTP-discoverable artifacts the hosted
website relies on (the docs note that `/llms.txt`, `/llms-full.txt`, sitemap files,
`robots.txt`, search JSON, and `agent-readability.json` are kept as static website
artifacts). They are unnecessary for the bundle flow because offline coding agents
read local files directly rather than discovering them over HTTP.
