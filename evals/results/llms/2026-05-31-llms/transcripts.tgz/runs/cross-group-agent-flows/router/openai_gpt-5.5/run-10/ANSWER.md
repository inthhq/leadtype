# Cross-group agent flows: hosted website vs npm bundle

Leadtype supports two complementary agent flows:

| Flow | Starts from | How agents navigate | Output shape |
| --- | --- | --- | --- |
| Hosted website / HTTP agents | `/llms.txt` at the site root | Agents follow markdown links from `/llms.txt` into `/llms-full.txt`, topic files, and markdown mirrors under `/docs/*.md`. Docs pages can also be served as markdown when `Accept: text/markdown` or a known AI user agent requests them. | Website artifacts: `/llms.txt`, `/llms-full.txt`, markdown mirrors under `/docs/*.md`, sitemap files, `robots.txt`, search JSON, and `agent-readability.json`. |
| npm package bundle / coding agents in `node_modules` | `AGENTS.md` at the package root | Agents follow relative links such as `./docs/reference/cli.md` to bundled `docs/*.md` files, without making network requests. | Package artifacts: `AGENTS.md` plus `docs/*.md` inside the npm tarball. |

Use website mode for URL-based discovery on a hosted docs site. Use `leadtype generate --bundle` when publishing an npm package so the docs are version-matched and available offline inside the installed package.

Bundle mode intentionally skips website-only artifacts: `llms.txt`, `llms-full.txt`, search JSON, sitemap files, `robots.txt`, and `agent-readability.json`.
