# Cross-Group Agent Flows: Hosted vs NPM Bundle

## Overview

Leadtype generates agent-readable documentation in two distinct flows that serve different deployment models:

1. **Hosted Website Flow** - For HTTP agents accessing docs via a public website
2. **NPM Bundle Flow** - For coding agents reading offline docs inside installed npm packages

Both flows process the same MDX source but generate different artifacts and use different entry points.

---

## Hosted Website Flow

### Starting Point
- **Entry File**: `/llms.txt`
- This is the root discovery file served at the site root

### Flow Details
HTTP agents start at `/llms.txt` and follow markdown links to discover and read documentation. The hosted flow generates a complete set of website artifacts that support HTTP-based discovery and navigation.

### Generated Artifacts
The hosted website flow produces:
- `/llms.txt` - Root entry point for agents
- `/llms-full.txt` - Fallback containing all generated pages (not split by group)
- `/docs/llms.txt` - Per-doc-area routing
- Markdown mirrors under `/docs/*.md`
- `docs/sitemap.xml` and `docs/sitemap.md` - Navigation aids
- `docs/robots.txt` - Crawl directives
- `docs/agent-readability.json` - Agent accessibility metadata
- `docs/search-index.json` and `docs/search-content.json` - Search support

---

## NPM Bundle Flow

### Starting Point
- **Entry File**: `AGENTS.md`
- This is bundled at the package root alongside docs

### Flow Details
Coding agents working inside installed npm packages start at `AGENTS.md` and follow relative links to read documentation. The bundle flow generates minimal artifacts optimized for offline, node_modules-based discovery.

### Generated Artifacts
The npm bundle flow produces:
- `AGENTS.md` - Entry point at package root
- `docs/*.md` - Documentation files with relative paths
- Uses relative links like `./docs/reference/cli.md` so agents can read docs without network requests

### Skipped Artifacts
Bundle mode intentionally **skips website-only artifacts**:
- `llms.txt` - Not needed for offline package reading
- `llms-full.txt` - Not needed for offline package reading
- `search-index.json` and `search-content.json` - Search is not relevant for offline readers
- `sitemap.xml` and `sitemap.md` - Sitemaps are for website navigation
- `robots.txt` - Crawl directives are unnecessary for offline access
- `agent-readability.json` - Accessibility metadata for HTTP agents only

---

## Key Differences Summary

| Aspect | Hosted Website | NPM Bundle |
|--------|----------------|-----------|
| **Entry Point** | `/llms.txt` | `AGENTS.md` |
| **Link Style** | HTTP URLs and absolute paths | Relative paths (e.g., `./docs/`) |
| **Discovery Method** | HTTP-based, network requests | File system, local node_modules |
| **Grouping** | Groups + fallback `/llms-full.txt` | Groups only in AGENTS.md |
| **Navigation Aids** | Sitemaps, search index, robots | Relative file paths only |
| **Use Case** | URL-based agents accessing hosted docs | Code agents in installed packages |

---

## Complementary Flows

The two flows complement each other. A package can simultaneously:
- Publish **bundled offline docs** for coding agents in `node_modules`
- Maintain a **hosted docs website** with `/llms.txt` for HTTP-based agents

Both flows start from the same MDX source but diverge in their output artifacts and how agents discover the documentation.
