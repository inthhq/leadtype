# Cross-group agent flows: hosted website vs npm package bundle

Leadtype turns one MDX source into two complementary agent flows. The docs describe these across multiple groups (Get Started, Build, Ship Package Docs, and Reference), so this answer ties those groups together.

## The two flows at a glance

| | Hosted website flow | npm package bundle flow |
|---|---|---|
| Mode | `leadtype generate` (website mode) | `leadtype generate --bundle` (bundle mode) |
| Agent type | HTTP / URL-based agents | Coding agents working inside installed `node_modules` |
| Entry file | `/llms.txt` | `AGENTS.md` (package root) |
| Link style | Markdown links to `/docs/*.md` URLs (fetched over HTTP) | Relative links like `./docs/reference/cli.md` (no network request) |

Per *How it works*, the two flows complement each other: a single package can publish bundled offline docs for `node_modules` **and** a hosted docs website with `llms.txt` for URL-based agents.

## Where each flow starts

### Hosted website flow
HTTP agents **start at `/llms.txt`** and follow markdown links. From *How it works* and *Build (Connect a docs site)*:

- Start file: `/llms.txt` at the site root.
- Routing: `/llms-full.txt` is the full-context router pointing to topic files; markdown mirrors live under `/docs/*.md`.
- Serving: markdown is served when `Accept: text/markdown` is requested or when a known AI user agent requests a docs page.

### npm package bundle flow
Coding agents inside installed npm packages **start at `AGENTS.md`** and follow relative `docs/*.md` links. From *Ship Package Docs (Bundle)* and the LLM reference:

- Start file: `AGENTS.md` written at the package root.
- Layout: `docs/*.md` written beneath the package root.
- Links: relative (e.g. `./docs/reference/cli.md`) so agents can read docs inside `node_modules` without a network request.
- Note (`generateAgentsMd`): `AGENTS.md` intentionally ignores `product.agentGuidance`, because that text is written for website URL routing rather than offline bundle use.

## Artifacts each flow generates

### Website mode (`leadtype generate`)
Per *Quickstart* and the CLI reference (`--json` output object), website mode writes:

- `/llms.txt` and `/docs/llms.txt`
- `/llms-full.txt`
- Markdown mirrors under `/docs/*.md`
- `docs/sitemap.xml` and `docs/sitemap.md`
- `docs/robots.txt`
- `docs/agent-readability.json`
- `docs/search-index.json` and `docs/search-content.json`

The `--json` object keys for website mode are `llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, `agentReadabilityJson`, `sitemapXml`, `sitemapMd`, `robotsTxt`, `searchIndex`, and `searchContent`.

### Bundle mode (`leadtype generate --bundle`)
Bundle mode writes only:

- `AGENTS.md` at the package root
- `docs/*.md` beneath it (with relative links)

## Which website artifacts bundle mode skips

Per *Bundle docs into a package*, bundle mode **skips these website-only artifacts**:

- `llms.txt`
- `llms-full.txt`
- search JSON (`search-index.json` / `search-content.json`)
- sitemap files (`sitemap.xml`, `sitemap.md`)
- `robots.txt`
- `agent-readability.json`

This matches `isAgentReadabilityArtifactPath` in the LLM reference, which identifies exactly those paths (`llms.txt`, `llms-full.txt`, sitemap files, `robots.txt`, search JSON, and `agent-readability.json`) as artifact paths — i.e. the discoverability/serving layer that only matters for the hosted website and is therefore unnecessary inside an offline npm tarball.

## Summary
- **Website flow:** mode `generate`; agents enter at `/llms.txt`; emits HTTP-discoverable artifacts (llms.txt, llms-full.txt, /docs/*.md, sitemaps, robots.txt, search JSON, agent-readability.json).
- **Bundle flow:** mode `generate --bundle`; agents enter at `AGENTS.md`; emits only `AGENTS.md` + relative `docs/*.md` for offline use in `node_modules`, skipping all website-only discoverability artifacts listed above.
