# Cross-group agent flows: hosted vs npm bundle

Leadtype supports two complementary agent flows:

## Hosted website flow

Use website mode when docs should be discoverable over HTTP.

- **Agent starting file:** `/llms.txt` at the hosted site root.
- **How agents continue:** HTTP agents follow markdown links from `/llms.txt` into the generated markdown docs, such as markdown mirrors under `/docs/*.md`.
- **Typical website artifacts:** website mode emits `/llms.txt`, `/docs/llms.txt`, `/llms-full.txt`, markdown mirrors under `/docs/*.md`, sitemap files, robots.txt, agent-readability metadata, and search JSON.
- **Serving behavior:** docs pages should return markdown when the request asks for `Accept: text/markdown` or comes from a known AI user agent.

## npm package bundle flow

Use bundle mode when publishing docs inside an npm package for agents working in `node_modules`.

- **Command:** `leadtype generate --bundle`.
- **Agent starting file:** `AGENTS.md` at the package root.
- **How agents continue:** `AGENTS.md` uses relative links, for example `./docs/reference/cli.md`, so coding agents can read bundled docs offline without a network request.
- **Generated package docs:** `AGENTS.md` plus `docs/*.md` beneath the package root.

## Website artifacts skipped by bundle mode

Bundle mode intentionally omits website-only artifacts:

- `llms.txt`
- `llms-full.txt`
- search JSON, including search index/content JSON
- sitemap files, such as sitemap XML/markdown
- `robots.txt`
- `agent-readability.json`

In short: hosted URL-based agents start at `/llms.txt`; coding agents inside an installed npm package start at `AGENTS.md`. The bundle keeps only the package-local agent entrypoint and markdown docs, skipping the HTTP/search/discovery artifacts needed by a hosted docs site.
