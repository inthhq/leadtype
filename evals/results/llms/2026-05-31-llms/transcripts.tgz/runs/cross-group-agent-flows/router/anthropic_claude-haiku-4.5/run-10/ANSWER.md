# Cross-group Agent Flows: Hosted vs npm Bundle

## Overview

Leadtype supports two distinct agent flows for accessing documentation:

1. **Hosted Website Flow** - HTTP-discoverable agent files for remote access
2. **npm Bundle Flow** - Offline agent files embedded in npm packages

## Hosted Website Flow

### Starting Points
The hosted website flow generates multiple entry points at the site root:

- **/llms.txt** - Product-level router with links to all documentation sections
- **/llms-full.txt** - Root full-context fallback containing every generated markdown page
- **/docs/llms.txt** - Docs-scoped map for HTTP routing within the hosted site
- **/docs/*.md** - Markdown mirrors of all documentation pages

### Supporting Artifacts (Static)
The website flow also generates supporting artifacts that enable discovery and navigation:

- **/docs/sitemap.xml** - XML sitemap for crawlability
- **/docs/sitemap.md** - Markdown sitemap
- **/robots.txt** - Robots directive (allows /llms.txt)
- **/search/*.json** - Static local search index
- **/agent-readability.json** - Agent readability metadata
- Content served with **Accept: text/markdown** headers for agent requests

### Key Characteristics
- Uses HTTP routing via base-url parameter
- Agents fetch markdown via network requests
- Groups organize sections in llms.txt navigation
- Product-level agent guidance is written for URL routing patterns

## npm Bundle Flow

### Starting Point
The bundle flow generates a single entry point at the package root:

- **AGENTS.md** - Package-level agent guidance file (written to npm tarball root)

### Documentation Structure
- **docs/*.md** - Documentation files beneath the package root (relative to AGENTS.md)

### Link Strategy
- AGENTS.md uses **relative links** like `./docs/reference/cli.md`
- Enables offline agent access from node_modules without network requests
- Self-contained documentation bundle

### Key Characteristics
- Agents read docs locally from node_modules
- No HTTP routing required
- Uses relative filesystem paths instead of URLs

## Skipped Artifacts in Bundle Mode

Bundle mode **intentionally skips** all website-only artifacts:

- **llms.txt** - Product-level router (no HTTP routing in packages)
- **llms-full.txt** - Full-context fallback (unnecessary with relative links)
- **search/*.json** - Static search index (no search infrastructure needed)
- **/docs/sitemap.xml** - XML sitemap (no crawlability needed)
- **/docs/sitemap.md** - Markdown sitemap (navigation via AGENTS.md)
- **robots.txt** - Robots directive (no crawler access)
- **agent-readability.json** - Readability metadata (not applicable offline)

## Code Generation Pattern

The Leadtype API functions handle these flows:

- **generateLlmsTxt()** - Generates /llms.txt and /docs/llms.txt (website mode only)
- **generateLLMFullContextFiles()** - Generates /llms-full.txt (website mode only)
- **generateAgentsMd()** - Generates AGENTS.md (bundle mode, ignores product.agentGuidance)
- **isAgentReadabilityArtifactPath()** - Identifies artifact paths to preserve (prevents rewriting as missing markdown)

## Summary

| Aspect | Hosted Website | npm Bundle |
|--------|---|---|
| **Start File** | /llms.txt (root entry point) | AGENTS.md (package root) |
| **Link Style** | HTTP URLs with base-url | Relative filesystem paths |
| **Access Pattern** | HTTP network requests | Local file system reads |
| **Routing** | URL-based via groups | Relative path-based |
| **Navigation** | llms.txt sections + llms-full.txt | AGENTS.md only |
| **Search** | Static JSON index | None (or external) |
| **Sitemaps** | XML + Markdown | None |
| **Artifacts Skipped** | None (all included) | llms.txt, llms-full.txt, search/, sitemaps, robots.txt, agent-readability.json |

The two flows represent fundamentally different deployment models: **hosted + discoverable** versus **packaged + offline**.
