# Cross-group Agent Flows: Hosted vs NPM Bundle

## Overview

Leadtype has two distinct flows for distributing agent-readable documentation: a **hosted website flow** and an **npm bundle flow**. These flows serve different use cases while sharing core markdown content.

## Hosted Website Flow

**Starting Point:** `/llms.txt` at the site root

The hosted website flow generates discoverable HTTP endpoints for agents to fetch documentation:

- **Entry file:** `/llms.txt` - The root router that agents discover first
- **Navigation:** `/llms-full.txt` - Full context router directing to topic-specific files
- **Content:** Markdown mirrors under `/docs/*.md` 
- **Discovery artifacts:**
  - Sitemap files (`/docs/sitemap.xml`)
  - robots.txt configuration
  - search JSON
  - agent-readability.json

**Flow mechanism:** Agents discover `/llms.txt`, follow the router structure, then fetch markdown pages with `Accept: text/markdown` headers or when known AI user agents request docs pages.

## NPM Bundle Flow

**Starting Point:** `AGENTS.md` at the package root

The npm bundle flow packages documentation for offline access inside node_modules:

- **Entry file:** `AGENTS.md` - The bundle's root router (equivalent to llms.txt in the hosted flow)
- **Content:** Markdown files under `docs/*.md` within the package
- **Link strategy:** Uses relative links like `./docs/reference/cli.md` so agents can read docs offline without network requests

**Flow mechanism:** Agents import the package from node_modules and directly reference AGENTS.md, then follow relative links to access documentation.

## Key Differences

| Aspect | Hosted Flow | Bundle Flow |
|--------|-------------|------------|
| **Entry File** | `/llms.txt` | `AGENTS.md` |
| **Link Style** | HTTP URLs | Relative paths |
| **Network Access** | Required (HTTP discovery) | Not required (offline) |
| **Command** | Default `leadtype generate` | `leadtype generate --bundle` |

## Website Artifacts Skipped in Bundle Mode

Bundle mode **skips the following website-only artifacts:**

1. `llms.txt` - Root router (replaced by AGENTS.md)
2. `llms-full.txt` - Full context router (replaced by AGENTS.md's content)
3. Search JSON - Full-text search indexes not needed offline
4. Sitemap files - HTTP-based discovery not applicable
5. robots.txt - SEO and crawling rules not relevant for packages
6. agent-readability.json - Website-specific metadata

## Summary

The hosted flow creates an HTTP-discoverable documentation system starting from `/llms.txt`, while the npm bundle flow creates a self-contained offline package starting from `AGENTS.md`. The bundle flow optimizes by removing all web-infrastructure artifacts, keeping only the markdown content and a package-relative router file.
