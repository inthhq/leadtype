# Cross-group agent flows: hosted website vs npm bundle

## Hosted website flow

Use website mode when docs are meant to be discovered over HTTP. The hosted site starts agents at the site-root `/llms.txt`, which points to the full-context router at `/llms-full.txt`. From there, agents choose the smallest matching topic file and can fetch markdown mirrors under `/docs/*.md`.

For docs-page requests, the site should serve markdown when the request has `Accept: text/markdown` or comes from a known AI user agent. Website mode also keeps static discovery and support artifacts at the site root or docs paths, including `/llms.txt`, `/llms-full.txt`, sitemap files, `robots.txt`, search JSON, and `agent-readability.json`.

## npm package bundle flow

Use bundle mode when publishing an npm package for offline or version-matched agent use. This flow starts from `AGENTS.md` at the package root, not from `/llms.txt`. `AGENTS.md` links relatively into bundled markdown, for example `./docs/reference/cli.md`, so coding agents can read docs from `node_modules` without making network requests.

Bundle mode writes `AGENTS.md` and `docs/*.md` inside the package tarball.

## Website artifacts skipped by bundle mode

Bundle mode skips these website-only artifacts:

- `llms.txt`
- `llms-full.txt`
- search JSON
- sitemap files
- `robots.txt`
- `agent-readability.json`
