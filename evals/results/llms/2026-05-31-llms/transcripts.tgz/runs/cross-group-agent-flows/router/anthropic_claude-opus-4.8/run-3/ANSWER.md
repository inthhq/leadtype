# Cross-group agent flows: hosted website vs npm bundle

Leadtype turns one MDX source into two complementary agent flows. The two flows
"complement each other": a package can publish bundled offline docs for
`node_modules` *and* a hosted docs website with `llms.txt` for URL-based agents.

## Hosted website flow (website mode)

**Where agents start:** HTTP agents start at **`/llms.txt`** and follow markdown
links from there. The router `/llms-full.txt` then points to topic-specific
deep-context files, and agents fetch markdown mirrors under `/docs/*.md`.

**How it's served:** The build exposes HTTP-discoverable agent files. Markdown is
served when `Accept: text/markdown` is requested or when a known AI user agent
requests a docs page.

**Artifacts generated (from Quickstart + Build docs):**

- `/llms.txt` (site-root entry point) and `/docs/llms.txt`
- `/llms-full.txt` (full-context router)
- Markdown mirrors under `/docs/*.md`
- `docs/sitemap.xml` and `docs/sitemap.md`
- `docs/robots.txt` (configured to allow `/llms.txt`)
- `docs/agent-readability.json`
- `docs/search-index.json` and `docs/search-content.json` (search JSON)

These are kept as static artifacts so agents can discover and fetch them over
HTTP.

## npm package bundle flow (bundle mode)

**Command:** `leadtype generate --bundle` (used when publishing an npm package).

**Where agents start:** Coding agents working *inside installed npm packages*
start at **`AGENTS.md`** (written at the package root) and follow **relative**
`docs/*.md` links — for example `./docs/reference/cli.md`.

**Why relative links:** Relative links let coding agents read docs inside
`node_modules` **without a network request** (offline / version-matched docs).

**Artifacts generated:**

- `AGENTS.md` at the package root
- `docs/*.md` beneath it (with relative links)

## What bundle mode skips

Bundle mode is offline and package-local, so it skips all the website-only
HTTP-discoverable artifacts:

- `llms.txt`
- `llms-full.txt`
- search JSON (`search-index.json` / `search-content.json`)
- sitemap files (`sitemap.xml` / `sitemap.md`)
- `robots.txt`
- `agent-readability.json`

## Summary

| Aspect | Hosted website mode | npm bundle mode (`--bundle`) |
|---|---|---|
| Agent entry point | `/llms.txt` (→ `/llms-full.txt`) | `AGENTS.md` (package root) |
| Doc links | URL-based `/docs/*.md` | relative `./docs/*.md` |
| Delivery | HTTP fetch (network) | offline, inside `node_modules` |
| Discovery/index files | llms.txt, llms-full.txt, sitemaps, robots.txt, search JSON, agent-readability.json | none of these (skipped) |
| Core docs output | markdown mirrors under `/docs/*.md` | `AGENTS.md` + `docs/*.md` |
