# Cross-group Agent Flows: Hosted vs NPM Bundle

## Overview

Leadtype supports two distinct flows for serving documentation to agents:

1. **Hosted Website Flow** - HTTP-discoverable agent files served from a hosted docs site
2. **NPM Bundle Flow** - Offline-accessible agent files bundled inside npm packages

## Hosted Website Flow

### Starting Files
- **`/llms.txt`** - The primary entry point at the site root containing the full-context router
- **`/llms-full.txt`** - Complete context file that routes to topic-specific deep-context files
- **`/docs/*.md`** - Markdown mirrors of the documentation

### Artifacts Generated
The build generates all of the following static artifacts:
- `/llms.txt` - Entry point router
- `/llms-full.txt` - Full context router
- `/docs/*.md` - Markdown documentation mirrors
- `/docs/sitemap.xml` - XML sitemap for discovery
- `/robots.txt` - Robot configuration allowing access to `/llms.txt`
- `search JSON` - Full-text search index
- `agent-readability.json` - Agent accessibility metadata

### Access Pattern
Agents discover and fetch markdown when:
- `Accept: text/markdown` header is present in the request
- A known AI user agent requests a docs page

## NPM Bundle Flow

### Starting Files
- **`AGENTS.md`** - The primary entry point at the package root
- **`docs/*.md`** - Version-matched markdown documentation

### Artifacts Generated
Bundle mode generates a minimal set of files:
- `AGENTS.md` - Root-level agent entry point
- `docs/*.md` - Markdown documentation

### Link Pattern
AGENTS.md uses relative links (e.g., `./docs/reference/cli.md`) so agents can read docs inside `node_modules` without network requests.

## Artifacts Skipped in Bundle Mode

Bundle mode **skips all website-only artifacts**:
- `llms.txt` - HTTP discovery not needed in bundles
- `llms-full.txt` - Full context routing not needed for offline access
- `search JSON` - Search index not applicable to static bundles
- `sitemap files` - XML/HTML sitemaps for web discovery
- `robots.txt` - Robot configuration for web crawlers
- `agent-readability.json` - HTTP metadata not needed offline

## Key Differences Summary

| Aspect | Hosted Flow | Bundle Flow |
|--------|-------------|------------|
| **Entry Point** | `/llms.txt` | `AGENTS.md` |
| **Discovery Method** | HTTP via Accept headers | Local file system access |
| **Network Access** | Required | Not needed |
| **Link Style** | Absolute (e.g., `/docs/reference/cli.md`) | Relative (e.g., `./docs/reference/cli.md`) |
| **Web Artifacts** | Full set included | All skipped |
| **Use Case** | Hosted docs sites with agent access | npm packages for offline agents |
| **Command** | Standard build | `leadtype generate --bundle` |

## Verification

For hosted flow, verify:
- Fetch `/llms.txt` from the site root
- Fetch a docs page with `Accept: text/markdown` header
- Check `/docs/sitemap.xml` exists
- Confirm `/robots.txt` allows `/llms.txt`

For bundle flow, verify:
- `AGENTS.md` exists at package root
- `docs/*.md` files are present
- Links in `AGENTS.md` use relative paths
- Web artifacts are absent
