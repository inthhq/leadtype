# Cross-group agent flows: hosted vs npm bundle

## Overview

Leadtype supports two complementary agent flows for different deployment scenarios:

1. **Hosted Website Flow** - for HTTP-discoverable agents accessing docs via a website
2. **NPM Bundle Flow** - for coding agents working inside installed npm packages

Both flows start from the same MDX source but generate different artifacts optimized for their respective contexts.

---

## Hosted Website Flow

### Starting Point
- **File**: `/llms.txt` (at the site root)
- HTTP agents start here and follow markdown links to discover documentation

### Flow
1. Agent fetches `/llms.txt` (the main entry point)
2. Follows links through `/llms-full.txt` and topic-specific files
3. Navigates to individual markdown pages served at `/docs/*.md`
4. Discovers content through HTTP-discoverable artifacts

### Generated Website Artifacts
- `/llms.txt` - main router for agents
- `/llms-full.txt` - full context router with topic-specific deep-context files
- Markdown mirrors under `/docs/*.md`
- `/docs/sitemap.xml` - XML sitemap for discovery
- `/docs/sitemap.md` - markdown sitemap
- `/docs/robots.txt` - crawling instructions
- `/docs/agent-readability.json` - agent-specific metadata
- `/docs/search-index.json` - search capabilities
- `/docs/search-content.json` - search data
- `/docs/llms.txt` - secondary llms.txt location

---

## NPM Bundle Flow

### Starting Point
- **File**: `AGENTS.md` (at the package root)
- Coding agents working inside installed npm packages start here
- Uses relative links (`./docs/reference/cli.md`) to work offline inside `node_modules`

### Flow
1. Agent reads `AGENTS.md` from the package root
2. Follows relative links to documentation under `docs/*.md`
3. Accesses all docs without requiring network requests
4. Works entirely offline within the installed package

### Generated Bundle Artifacts
- `AGENTS.md` - main entry point (at package root)
- `docs/*.md` - markdown files with relative linking

---

## Artifacts Skipped in Bundle Mode

Bundle mode optimizes for offline use and skips all website-only artifacts:

- `llms.txt` - HTTP router (not needed for relative links)
- `llms-full.txt` - full context router (not needed in package)
- `sitemap.xml` - web discovery artifact
- `sitemap.md` - web discovery artifact
- `robots.txt` - web crawling instructions
- `agent-readability.json` - web-specific metadata
- `search-index.json` - web search data
- `search-content.json` - web search data

---

## Key Differences

| Aspect | Hosted Flow | Bundle Flow |
|--------|-------------|------------|
| **Starting File** | `/llms.txt` | `AGENTS.md` |
| **Link Type** | HTTP absolute links | Relative links (`./docs/`) |
| **Network Required** | Yes (HTTP) | No (offline) |
| **Entry Point Location** | Site root | Package root |
| **Additional Metadata** | Search, sitemaps, robots.txt | None |
| **Use Case** | URL-based agents, web discovery | Node_modules agents, offline access |

---

## Complementary Approach

As documented in the Leadtype "How it works" page:

> HTTP agents start at /llms.txt and follow markdown links. Coding agents working inside installed npm packages start at AGENTS.md and follow relative docs/*.md links.
>
> The two flows complement each other. A package can publish bundled offline docs for node_modules and a hosted docs website with llms.txt for URL-based agents.

This means a single source can power both flows - the same MDX source generates optimized artifacts for each deployment context.
