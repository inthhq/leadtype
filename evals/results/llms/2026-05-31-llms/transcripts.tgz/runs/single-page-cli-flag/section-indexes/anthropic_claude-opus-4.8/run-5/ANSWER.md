# What `leadtype generate --json` reports

`leadtype generate` converts docs and writes agent-readable artifacts. When you add the `--json` flag, `generate` prints a **JSON object whose values are the paths to the generated artifacts**, so the output can be consumed programmatically (for example, in CI pipelines).

## Website-mode output

In website mode, the printed JSON object includes the following keys, each pointing to a generated artifact path:

- `llmsFullTxt` — the root full-context bundle (every generated markdown page in one file)
- `docsLlmsTxt` — the docs-scoped `/docs/llms.txt` section map
- `llmsTxt` — the product-level `/llms.txt`
- `agentReadabilityJson` — the agent-readability metadata file
- `sitemapXml` — the XML sitemap
- `sitemapMd` — the markdown sitemap
- `robotsTxt` — the `robots.txt` file
- `searchIndex` — the static search index
- `searchContent` — the search content data

## Summary

In short, `leadtype generate --json` does the same conversion work as a normal `generate` run, but instead of (or in addition to) writing the files, it emits a machine-readable JSON object that maps each generated agent-readable artifact to its output path. This lets tooling discover exactly where the `llms.txt`, full-context bundle, sitemaps, robots file, search index, and agent-readability JSON were written.

---

*Source: [/docs/reference/cli.md](docs/reference/cli.md) on the Leadtype docs site (reached via `/llms.txt` → Reference → CLI).*
