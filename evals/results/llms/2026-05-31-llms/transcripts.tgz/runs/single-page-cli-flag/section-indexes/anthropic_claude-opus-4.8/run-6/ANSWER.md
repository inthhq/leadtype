# What `leadtype generate --json` reports

When you run `leadtype generate` with the `--json` flag enabled, the command
prints a **JSON object containing the file paths of the artifacts it
generated**. Instead of just converting docs silently, it emits a machine-
readable summary so build tooling and CI can locate each produced file.

## The website-mode JSON object

In website mode, the JSON object reports paths for the following generated
artifacts:

| Field | Artifact it points to |
|-------|------------------------|
| `llmsFullTxt` | The root `/llms-full.txt` full-context bundle containing every generated markdown docs page. |
| `docsLlmsTxt` | The docs-scoped `/docs/llms.txt` section map. |
| `llmsTxt` | The product-level `/llms.txt` entry point. |
| `agentReadabilityJson` | The `agent-readability.json` artifact. |
| `sitemapXml` | The XML sitemap (`sitemap.xml`). |
| `sitemapMd` | The Markdown sitemap (`sitemap.md`). |
| `robotsTxt` | The `robots.txt` file. |
| `searchIndex` | The static search index JSON. |
| `searchContent` | The search content JSON used to back source-grounded answers. |

## Summary

`leadtype generate --json` doesn't change *what* gets built — it changes the
*output format*. It returns a structured object mapping each of the agent-
readable and website deployment artifacts (LLM text files, sitemaps,
`robots.txt`, the agent-readability descriptor, and the search index/content)
to the path where `generate` wrote it. This makes the generated artifact
locations easy to consume programmatically in a build or deployment pipeline.

---

*Sources: `/docs/reference/cli.md`, with supporting context from
`/docs/reference/llm.md`.*
