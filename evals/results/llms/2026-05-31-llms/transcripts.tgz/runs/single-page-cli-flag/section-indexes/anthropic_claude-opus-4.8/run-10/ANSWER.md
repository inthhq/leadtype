# What `leadtype generate --json` reports

`leadtype generate` converts docs and writes agent-readable artifacts. When the
`--json` flag is enabled, `generate` prints a **JSON object containing the paths
to the generated artifacts** (rather than only emitting them to disk silently).

## The JSON object (website mode)

In website mode, the printed JSON object includes paths for the following
generated artifacts:

- `llmsFullTxt` — the root `/llms-full.txt` file containing every generated
  markdown docs page flattened into one full-context bundle.
- `docsLlmsTxt` — the docs-scoped `/docs/llms.txt` map.
- `llmsTxt` — the product-level `/llms.txt` map.
- `agentReadabilityJson` — the `agent-readability.json` artifact.
- `sitemapXml` — the XML sitemap.
- `sitemapMd` — the Markdown sitemap.
- `robotsTxt` — the `robots.txt` file.
- `searchIndex` — the static search index.
- `searchContent` — the search content file.

## How this fits in

These are the agent-readable / hosted-website artifacts that `generate` produces
alongside the converted docs. The `--json` output gives you (or a CI step /
tooling) a machine-readable manifest of exactly where each artifact was written,
which is useful for automation, verification, or downstream deployment steps.

## Related flags

Other notable `generate` flags include `--src`, `--out`, `--base-url`,
`--bundle`, `--enrich-git`, and `--strict`. `--json` simply controls whether the
artifact paths are reported as a JSON object.
