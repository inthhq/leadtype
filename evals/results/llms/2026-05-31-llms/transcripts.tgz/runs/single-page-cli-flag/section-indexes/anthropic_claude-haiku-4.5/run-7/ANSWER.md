# What `leadtype generate --json` Reports

According to the Leadtype documentation, when the `--json` flag is enabled with `leadtype generate`, the command prints a JSON object with paths for the generated artifacts.

The JSON output in website-mode includes the following keys:

- **llmsFullTxt**: Full-context LLM bundle
- **docsLlmsTxt**: Section-specific LLM bundle  
- **llmsTxt**: Root LLM bundle
- **agentReadabilityJson**: JSON representation for agent readability
- **sitemapXml**: XML sitemap
- **sitemapMd**: Markdown sitemap
- **robotsTxt**: robots.txt file
- **searchIndex**: Search index data
- **searchContent**: Search content data

This JSON output provides paths to all the generated artifacts that the `leadtype generate` command produces, making it useful for automation and scripting workflows.

Source: [Leadtype CLI Reference](/docs/reference/cli.md)
