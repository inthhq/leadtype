# `leadtype generate --json`

According to the Leadtype CLI reference, enabling `--json` makes `leadtype generate` print a JSON object that reports the paths of the artifacts it generated.

In website mode, that JSON object includes paths for:

- `llmsFullTxt`
- `docsLlmsTxt`
- `llmsTxt`
- `agentReadabilityJson`
- `sitemapXml`
- `sitemapMd`
- `robotsTxt`
- `searchIndex`
- `searchContent`
