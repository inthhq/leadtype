# What `leadtype generate --json` Reports

According to the Leadtype documentation, when `leadtype generate --json` is enabled, it prints a JSON object with paths for the generated artifacts.

## JSON Output Fields

The JSON output includes paths for the following generated artifacts:

- **llmsFullTxt**: The full-context bundle file
- **docsLlmsTxt**: Section-level index files
- **llmsTxt**: Root llms.txt file
- **agentReadabilityJson**: Agent-readable metadata in JSON format
- **sitemapXml**: XML sitemap for search engines
- **sitemapMd**: Markdown version of the sitemap
- **robotsTxt**: robots.txt file for web crawlers
- **searchIndex**: Search index file
- **searchContent**: Search content file

This allows build systems and CI/CD pipelines to programmatically discover the locations of all generated artifacts for further processing or deployment.
