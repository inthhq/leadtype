# What `leadtype generate --json` Reports

When `leadtype generate --json` is enabled, it prints a JSON object containing paths for the generated artifacts.

The JSON object includes the following fields for website-mode output:

- **llmsFullTxt**: Path to the full-context LLM bundle
- **docsLlmsTxt**: Path to the docs section LLM index
- **llmsTxt**: Path to the root LLM file
- **agentReadabilityJson**: Path to the agent readability JSON artifact
- **sitemapXml**: Path to the XML sitemap
- **sitemapMd**: Path to the markdown sitemap
- **robotsTxt**: Path to the robots.txt file
- **searchIndex**: Path to the static search index
- **searchContent**: Path to the search content bundle

In essence, `leadtype generate --json` provides a structured output listing all the paths to the generated artifacts that Leadtype has created during the build process.
