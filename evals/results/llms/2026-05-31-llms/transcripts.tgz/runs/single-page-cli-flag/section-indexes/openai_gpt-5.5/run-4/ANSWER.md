`leadtype generate --json` prints a JSON object describing the generated output artifacts. In website mode, the object reports paths for:

- `llmsFullTxt`
- `docsLlmsTxt`
- `llmsTxt`
- `agentReadabilityJson`
- `sitemapXml`
- `sitemapMd`
- `robotsTxt`
- `searchIndex`
- `searchContent`

So, rather than changing what `generate` creates, `--json` makes the command report the paths to the generated agent-readable files, sitemap/robots files, and search artifacts in machine-readable JSON.
