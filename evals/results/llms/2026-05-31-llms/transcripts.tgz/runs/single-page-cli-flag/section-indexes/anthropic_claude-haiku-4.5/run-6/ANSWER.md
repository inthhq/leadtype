# What `leadtype generate --json` Reports

According to the Leadtype docs site, when the `--json` flag is enabled with the `leadtype generate` command, it prints a JSON object with paths for the generated artifacts.

Specifically, the website-mode object includes the following artifact paths:

- **llmsFullTxt**: Full-context LLM bundle
- **docsLlmsTxt**: Section-level docs LLM bundle  
- **llmsTxt**: Root LLM file
- **agentReadabilityJson**: Agent readability metrics JSON
- **sitemapXml**: XML sitemap
- **sitemapMd**: Markdown sitemap
- **robotsTxt**: Robots.txt file
- **searchIndex**: Search index
- **searchContent**: Search content

This JSON output provides machine-readable paths to all the agent-readable artifacts generated during the docs site build process.
