# `leadtype generate --json`

According to the Leadtype CLI reference, `leadtype generate --json` makes `leadtype generate` print a JSON object instead of only normal CLI output. That JSON object reports the paths of the artifacts Leadtype generated.

In website mode, the reported object includes paths for:

- `llmsFullTxt` — the root full-context file.
- `docsLlmsTxt` — the docs-scoped `llms.txt` map.
- `llmsTxt` — the product-level `/llms.txt` file.
- `agentReadabilityJson` — the agent readability JSON artifact.
- `sitemapXml` — the XML sitemap.
- `sitemapMd` — the markdown sitemap.
- `robotsTxt` — the `robots.txt` file.
- `searchIndex` — the static search index.
- `searchContent` — generated search content.
