# What `leadtype generate --json` reports

`leadtype generate` converts docs and writes agent-readable artifacts. When the
`--json` flag is enabled, `generate` prints a **JSON object containing the paths
to the generated artifacts** instead of (or in addition to) human-readable
output.

## Website-mode output

In website mode, the JSON object includes paths for the following generated
artifacts:

- `llmsFullTxt`
- `docsLlmsTxt`
- `llmsTxt`
- `agentReadabilityJson`
- `sitemapXml`
- `sitemapMd`
- `robotsTxt`
- `searchIndex`
- `searchContent`

## Summary

`--json` makes `generate` emit a machine-readable manifest of where each build
artifact was written, which is useful for scripting and CI pipelines that need
to locate the generated `llms.txt`/full-context bundles, sitemaps, robots file,
search index, and search content.

*Source: [/docs/reference/cli.md](docs/reference/cli.md)*
