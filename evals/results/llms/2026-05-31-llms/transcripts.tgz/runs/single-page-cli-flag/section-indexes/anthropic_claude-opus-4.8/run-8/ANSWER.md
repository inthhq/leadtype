# What `leadtype generate --json` reports

`leadtype generate` converts docs and writes agent-readable artifacts. When the
`--json` flag is enabled, `generate` prints a **JSON object containing the paths
to the generated artifacts** (rather than just running silently).

## Website-mode output

In website mode, the JSON object includes paths for the following artifacts:

- `llmsFullTxt` — the root `/llms-full.txt` file containing every generated markdown docs page.
- `docsLlmsTxt` — the docs-scoped `/docs/llms.txt` map.
- `llmsTxt` — the product-level `/llms.txt`.
- `agentReadabilityJson` — the `agent-readability.json` artifact.
- `sitemapXml` — the XML sitemap.
- `sitemapMd` — the markdown sitemap.
- `robotsTxt` — the `robots.txt` file.
- `searchIndex` — the static search index.
- `searchContent` — the search content artifact.

## In short

`--json` makes `leadtype generate` emit a machine-readable manifest of the
output it produced, mapping each agent-readable artifact (LLM bundles, sitemaps,
robots.txt, search files, and the agent-readability JSON) to its generated path.
This is useful for build pipelines that need to know exactly which files were
written and where.

*Source: `/docs/reference/cli.md` (with supporting detail from
`/docs/reference/llm.md`).*
