`leadtype generate --json` runs `leadtype generate` normally, but prints a JSON object describing the paths of the generated artifacts.

In website mode, that JSON object includes paths for:

- `llmsFullTxt` — the root `/llms-full.txt` full-context bundle containing every generated markdown docs page.
- `docsLlmsTxt` — the docs-scoped `/docs/llms.txt` map.
- `llmsTxt` — the product-level root `/llms.txt` file.
- `agentReadabilityJson` — the `agent-readability.json` artifact.
- `sitemapXml` — the XML sitemap artifact.
- `sitemapMd` — the markdown sitemap artifact.
- `robotsTxt` — the `robots.txt` artifact.
- `searchIndex` — the generated static search index.
- `searchContent` — the generated search content data.
