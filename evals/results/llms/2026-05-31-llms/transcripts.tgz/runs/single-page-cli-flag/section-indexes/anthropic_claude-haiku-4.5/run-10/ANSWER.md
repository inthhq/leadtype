# What `leadtype generate --json` Reports

According to the Leadtype docs site, when the `--json` flag is enabled on `leadtype generate`, it prints a JSON object with paths for the generated artifacts.

The JSON output includes the following paths for website-mode generation:

- **llmsFullTxt** - Full-context bundle path
- **docsLlmsTxt** - Docs section llms.txt path
- **llmsTxt** - Root llms.txt path
- **agentReadabilityJson** - Agent readability JSON file path
- **sitemapXml** - XML sitemap path
- **sitemapMd** - Markdown sitemap path
- **robotsTxt** - robots.txt file path
- **searchIndex** - Search index path
- **searchContent** - Search content path

This JSON output allows automated tools and scripts to discover the locations of all generated artifacts from a single command invocation.
