# What `leadtype generate --json` reports

`leadtype generate` converts docs and writes agent-readable artifacts. When the
`--json` flag is enabled, `generate` prints a **JSON object containing the file
paths of the generated artifacts** (rather than human-readable log output). This
is intended to be machine-readable so CI pipelines and tooling can locate each
output deterministically.

## Fields in the website-mode JSON object

In website mode, the printed object includes paths for the following artifacts:

| Field | What it points to |
|---|---|
| `llmsFullTxt` | The root `/llms-full.txt` file containing every generated markdown docs page (full-context fallback). |
| `docsLlmsTxt` | The docs-scoped `/docs/llms.txt` map. |
| `llmsTxt` | The product-level `/llms.txt` index. |
| `agentReadabilityJson` | The `agent-readability.json` artifact describing agent-readable paths. |
| `sitemapXml` | The XML sitemap. |
| `sitemapMd` | The Markdown sitemap. |
| `robotsTxt` | The `robots.txt` file. |
| `searchIndex` | The static search index. |
| `searchContent` | The search content data. |

## Summary

`--json` does not change *what* is generated — it changes the **output format**
of the command, emitting a structured JSON object that maps each generated
agent-readable artifact (LLM bundles, sitemaps, robots.txt, and search files) to
its path on disk. This makes it easy for build automation to consume the result
programmatically.

(Sources: `/docs/reference/cli.md`, with supporting context from
`/docs/reference/llm.md`.)
