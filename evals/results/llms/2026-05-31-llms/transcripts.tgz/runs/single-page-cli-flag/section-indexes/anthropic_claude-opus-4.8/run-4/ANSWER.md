# What `leadtype generate --json` reports

According to the Leadtype docs (`/docs/reference/cli.md`), `leadtype generate`
converts docs and writes agent-readable artifacts. When you add the `--json`
flag, `generate` **prints a JSON object containing the paths of the generated
artifacts** instead of (or in addition to) its normal output.

## The website-mode JSON object

In website mode, the JSON object includes paths for the following artifacts:

| Key | Artifact it points to |
| --- | --- |
| `llmsFullTxt` | The root full-context file (`/llms-full.txt`) containing every generated markdown docs page |
| `docsLlmsTxt` | The docs-scoped `/docs/llms.txt` map |
| `llmsTxt` | The product-level `/llms.txt` |
| `agentReadabilityJson` | The `agent-readability.json` artifact |
| `sitemapXml` | The XML sitemap |
| `sitemapMd` | The Markdown sitemap |
| `robotsTxt` | `robots.txt` |
| `searchIndex` | The static search index JSON |
| `searchContent` | The search content JSON |

## Why this is useful

These are the agent-readable and site artifacts Leadtype emits from a single
MDX source (the docs-as-website + LLM bundles + search index pipeline). Emitting
their paths as machine-readable JSON makes it easy to consume the output in
build scripts or CI—for example, to verify each expected artifact was produced
or to feed the paths into deployment steps.

## Related notes

- The full-context file (`llmsFullTxt`) is a single root `/llms-full.txt`;
  Leadtype does not publish per-group full-context files by default
  (`/docs/reference/llm.md`).
- Several of these paths (`llms.txt`, `llms-full.txt`, sitemap files,
  `robots.txt`, search JSON, and `agent-readability.json`) are recognized as
  agent-readability artifact paths, so they are not rewritten as missing
  markdown pages (`/docs/reference/llm.md`).

*Sources: `/llms.txt` → `/docs/reference/llms.txt` → `/docs/reference/cli.md`
and `/docs/reference/llm.md`.*
