# What `leadtype generate --json` reports

`leadtype generate` converts docs and writes agent-readable artifacts. When you
add the `--json` flag, `generate` prints a **JSON object that lists the paths of
the generated artifacts**, rather than (or in addition to) just running the
conversion. This makes the output machine-readable so a build pipeline can pick
up exactly where each artifact was written.

## The reported fields (website mode)

In website mode, the JSON object includes paths for the following generated
artifacts:

| Field | What it points to |
|-------|-------------------|
| `llmsFullTxt` | The root `/llms-full.txt` full-context file containing every generated markdown docs page. |
| `docsLlmsTxt` | The docs-scoped `/docs/llms.txt` section map. |
| `llmsTxt` | The product-level `/llms.txt` map. |
| `agentReadabilityJson` | The `agent-readability.json` artifact. |
| `sitemapXml` | The XML sitemap. |
| `sitemapMd` | The Markdown sitemap. |
| `robotsTxt` | The `robots.txt` file. |
| `searchIndex` | The static local search index built over the generated markdown. |
| `searchContent` | The search content used by the index. |

## Context for the fields

- `llmsTxt` / `docsLlmsTxt` are written by `generateLlmsTxt` — the product-level
  `/llms.txt` and the docs-scoped `/docs/llms.txt` map for hosted websites.
- `llmsFullTxt` is written by `generateLLMFullContextFiles` — a single root
  full-context file containing every generated markdown docs page.
- `searchIndex` / `searchContent` come from Leadtype's static, build-time search
  index (lexical BM25-style ranking over titles, headings, body, and code); the
  runtime query path is edge-safe and needs no database.
- `agentReadabilityJson`, the sitemap files, `robotsTxt`, and the search JSON are
  all recognized as agent-readability artifact paths (via
  `isAgentReadabilityArtifactPath`), so they are not rewritten as missing
  markdown pages.

## Summary

`leadtype generate --json` emits a JSON object mapping the names of the
generated agent-readable/website artifacts to their output paths
(`llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, `agentReadabilityJson`, `sitemapXml`,
`sitemapMd`, `robotsTxt`, `searchIndex`, and `searchContent`), giving build
tooling a programmatic record of everything the generate step produced.

_Source: `/docs/reference/cli.md`, with supporting detail from
`/docs/reference/llm.md` and `/docs/reference/search.md`._
