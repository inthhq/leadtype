# What `leadtype generate --json` Reports

According to the Leadtype docs, when `--json` is enabled, the `leadtype generate` command prints a JSON object with paths for the generated artifacts.

In website mode, the JSON output includes the following paths:
- **llmsFullTxt**: The full-context LLM bundle
- **docsLlmsTxt**: Section-specific LLM bundles
- **llmsTxt**: The root index file
- **agentReadabilityJson**: Agent-readable metadata
- **sitemapXml**: XML sitemap for search engines
- **sitemapMd**: Markdown sitemap
- **robotsTxt**: Robots.txt file
- **searchIndex**: Search index file
- **searchContent**: Search content data

This JSON output allows users and tooling to know exactly where each generated artifact has been written, making it easy to integrate the build process into automation pipelines.

**Source**: [Leadtype CLI Reference](/docs/reference/cli.md)
