# What `leadtype generate --json` reports

`leadtype generate` converts docs and writes agent-readable artifacts. When you add the `--json` flag, `generate` **prints a JSON object containing the file paths for the generated artifacts** (rather than only writing them quietly). This makes it easy for CI pipelines or other tooling to know exactly what was produced and where.

## The website-mode JSON object

In website mode, the emitted JSON object includes paths for the following generated artifacts:

| Key | Artifact |
| --- | --- |
| `llmsFullTxt` | The root full-context file (`/llms-full.txt`) containing every generated markdown docs page. |
| `docsLlmsTxt` | The docs-scoped map (`/docs/llms.txt`). |
| `llmsTxt` | The product-level map (`/llms.txt`). |
| `agentReadabilityJson` | The `agent-readability.json` artifact. |
| `sitemapXml` | The XML sitemap. |
| `sitemapMd` | The markdown sitemap. |
| `robotsTxt` | The `robots.txt` file. |
| `searchIndex` | The static search index. |
| `searchContent` | The search content file. |

## In short

`--json` doesn't change *what* gets built — it changes the **output format of the command**, reporting a machine-readable JSON object that maps each generated agent-readable artifact (LLM map/full-context files, sitemaps, robots.txt, search files, and the agent-readability JSON) to its output path.

## Sources

- `/docs/reference/cli.md` — describes `leadtype generate` flags and the JSON output object and its keys.
- `/docs/reference/llm.md` — describes the underlying artifacts (`llms.txt`, `llms-full.txt`, agent-readability, etc.) that the JSON paths point to.
