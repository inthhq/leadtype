`leadtype generate --json` runs the normal docs generation, but prints a machine-readable JSON object instead of only human-oriented output. According to the Leadtype CLI reference, that JSON reports the paths of the generated artifacts.

In website mode, the object includes paths for:

- `llmsFullTxt` — the root `/llms-full.txt` full-context file containing every generated markdown docs page.
- `docsLlmsTxt` — the docs-scoped `/docs/llms.txt` map.
- `llmsTxt` — the product-level root `/llms.txt` file.
- `agentReadabilityJson` — the agent-readability metadata JSON artifact.
- `sitemapXml` — the XML sitemap.
- `sitemapMd` — the markdown sitemap.
- `robotsTxt` — the generated `robots.txt` file.
- `searchIndex` — the static local search index.
- `searchContent` — the generated search content data.

So, `--json` is primarily for automation/CI: it tells callers where Leadtype wrote each generated website artifact.