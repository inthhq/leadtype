# What `leadtype generate --json` Reports

According to the Leadtype docs site, when the `--json` flag is enabled with `leadtype generate`, it prints a JSON object with paths for the generated artifacts.

The JSON output in website-mode includes the following artifact paths:

- `llmsFullTxt` - Full context LLM bundle
- `docsLlmsTxt` - Section-specific LLM files
- `llmsTxt` - Root LLM file
- `agentReadabilityJson` - Agent-readable metadata
- `sitemapXml` - XML sitemap
- `sitemapMd` - Markdown sitemap
- `robotsTxt` - robots.txt file
- `searchIndex` - Search index artifact
- `searchContent` - Search content artifact

In essence, `leadtype generate --json` provides a structured JSON output that reports the file paths of all the generated artifacts created during the docs build process, making it easy for scripts and tools to programmatically reference these outputs.
