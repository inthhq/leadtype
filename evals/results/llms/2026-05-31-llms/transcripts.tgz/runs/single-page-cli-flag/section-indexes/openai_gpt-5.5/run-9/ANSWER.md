# What `leadtype generate --json` reports

According to the Leadtype CLI reference, `leadtype generate` converts docs and writes agent-readable artifacts. When the `--json` flag is enabled, it prints a JSON object containing paths to the artifacts it generated.

In website mode, that JSON object reports paths for:

- `llmsFullTxt`
- `docsLlmsTxt`
- `llmsTxt`
- `agentReadabilityJson`
- `sitemapXml`
- `sitemapMd`
- `robotsTxt`
- `searchIndex`
- `searchContent`
