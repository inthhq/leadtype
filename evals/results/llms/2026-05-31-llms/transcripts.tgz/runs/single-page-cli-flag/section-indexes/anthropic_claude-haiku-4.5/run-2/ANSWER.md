# What `leadtype generate --json` Reports

According to the Leadtype documentation, when `--json` is enabled with the `leadtype generate` command, it prints a JSON object with paths for the generated artifacts.

The JSON output includes the following properties:
- **llmsFullTxt** - The full-context LLM file
- **docsLlmsTxt** - Section-specific llms.txt files
- **llmsTxt** - The root llms.txt file
- **agentReadabilityJson** - Agent-readable JSON metadata
- **sitemapXml** - XML sitemap for SEO
- **sitemapMd** - Markdown sitemap
- **robotsTxt** - Robots.txt file for search engines
- **searchIndex** - The search index artifact
- **searchContent** - Indexed content for search

This JSON output provides paths to all the generated artifacts, making it useful for scripts and automation that need to reference the locations of these generated files.
