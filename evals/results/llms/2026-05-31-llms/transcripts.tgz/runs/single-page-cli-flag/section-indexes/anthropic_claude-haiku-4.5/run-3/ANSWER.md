# What `leadtype generate --json` Reports

When the `--json` flag is enabled with `leadtype generate`, it prints a JSON object containing paths for the generated artifacts.

## The JSON Output Includes

The website-mode object includes the following paths:
- **llmsFullTxt**: Full-context fallback bundle
- **docsLlmsTxt**: Documentation llms.txt file
- **llmsTxt**: Root llms.txt file
- **agentReadabilityJson**: Agent readability metrics/data
- **sitemapXml**: XML sitemap
- **sitemapMd**: Markdown sitemap
- **robotsTxt**: Robots.txt file
- **searchIndex**: Search index artifact
- **searchContent**: Search content artifact

This JSON output allows for automated processing of the generated documentation artifacts and integration with other build tools or workflows.
