# `leadtype generate --json`

According to the Leadtype CLI reference, `leadtype generate --json` makes `leadtype generate` print a JSON object describing the paths of the artifacts it generated.

In website mode, that JSON object includes paths for:

- `llmsFullTxt`
- `docsLlmsTxt`
- `llmsTxt`
- `agentReadabilityJson`
- `sitemapXml`
- `sitemapMd`
- `robotsTxt`
- `searchIndex`
- `searchContent`

So, `--json` is a machine-readable report of generated output file locations, not a replacement for the generated docs artifacts themselves.
