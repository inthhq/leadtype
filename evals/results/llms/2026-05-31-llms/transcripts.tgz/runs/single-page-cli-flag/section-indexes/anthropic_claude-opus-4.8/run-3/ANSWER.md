# What `leadtype generate --json` reports

`leadtype generate` converts docs and writes agent-readable artifacts. When the
`--json` flag is enabled, `generate` prints a **JSON object containing the paths
of the generated artifacts** (rather than only writing files quietly).

In website mode, that JSON object includes the following keys, each pointing to a
generated artifact path:

- `llmsFullTxt` — the root full-context bundle (`/llms-full.txt`) containing
  every generated markdown docs page.
- `docsLlmsTxt` — the docs-scoped map (`/docs/llms.txt`).
- `llmsTxt` — the product-level map (`/llms.txt`).
- `agentReadabilityJson` — the agent-readability metadata file
  (`agent-readability.json`).
- `sitemapXml` — the XML sitemap.
- `sitemapMd` — the markdown sitemap.
- `robotsTxt` — the `robots.txt` file.
- `searchIndex` — the static search index.
- `searchContent` — the search content file.

In short, `--json` makes `generate` emit a machine-readable manifest of where it
wrote each website/agent artifact, which is useful for build pipelines and CI
that need to locate or verify the generated output.

## Sources
- `/docs/reference/cli.md` — CLI flags and JSON output description.
- `/docs/reference/llm.md` — details on the LLM/agent artifacts referenced above.
