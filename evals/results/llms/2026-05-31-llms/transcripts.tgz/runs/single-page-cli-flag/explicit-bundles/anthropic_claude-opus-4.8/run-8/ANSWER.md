# What `leadtype generate --json` reports

`leadtype generate` converts docs and writes agent-readable artifacts. When the
`--json` flag is enabled, `generate` prints a **JSON object containing the file
paths for the generated artifacts** (instead of/in addition to its normal
output). This makes the build output machine-readable, which is useful for CI
pipelines and tooling that needs to locate the produced files.

## Fields in the website-mode JSON object

In website mode, the JSON object includes paths for the following artifacts:

- `llmsFullTxt` — the root full-context file (`/llms-full.txt`) containing every generated markdown docs page.
- `docsLlmsTxt` — the docs-scoped map (`/docs/llms.txt`).
- `llmsTxt` — the product-level map (`/llms.txt`).
- `agentReadabilityJson` — the `agent-readability.json` artifact.
- `sitemapXml` — the XML sitemap (`/docs/sitemap.xml`).
- `sitemapMd` — the markdown sitemap.
- `robotsTxt` — the `robots.txt` file.
- `searchIndex` — the static search index JSON.
- `searchContent` — the search content JSON.

## In short

`--json` doesn't change *what* is built — it changes the *reporting format*.
It emits a structured JSON object mapping each generated agent-readable
artifact (LLM bundles, sitemaps, robots.txt, and search files) to its output
path, so downstream automation can discover and verify the build outputs.

---

*Sources: `/docs/reference/cli.md` (CLI flags, JSON output) and
`/docs/reference/llm.md` (artifact descriptions), reached from `/llms.txt`.*
