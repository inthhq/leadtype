# What `leadtype generate --json` reports

According to the Leadtype docs ([CLI reference](/docs/reference/cli.md)),
`leadtype generate` converts docs and writes agent-readable artifacts. When the
`--json` flag is enabled, `generate` prints a **JSON object containing the paths
for the generated artifacts**.

In website mode, that JSON object includes the following path fields:

- `llmsFullTxt`
- `docsLlmsTxt`
- `llmsTxt`
- `agentReadabilityJson`
- `sitemapXml`
- `sitemapMd`
- `robotsTxt`
- `searchIndex`
- `searchContent`

In short, `--json` is a machine-readable summary of where each generated
artifact was written (the LLM bundle files, sitemaps, robots.txt, the
agent-readability manifest, and the search index/content files), which is useful
for scripting or CI pipelines that need to locate or verify the build outputs.
