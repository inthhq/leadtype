# What `leadtype generate --json` Reports

According to the Leadtype docs, when the `--json` flag is enabled, `leadtype generate` prints a JSON object with paths for the generated artifacts.

## Generated Artifact Paths (Website Mode)

When running in website mode, the `--json` output includes paths for the following generated artifacts:

1. **llmsFullTxt** - The full-context file containing all markdown docs
2. **docsLlmsTxt** - The docs-scoped LLM map
3. **llmsTxt** - The root LLM text file
4. **agentReadabilityJson** - JSON output for agent readability
5. **sitemapXml** - XML sitemap for the website
6. **sitemapMd** - Markdown sitemap
7. **robotsTxt** - robots.txt file
8. **searchIndex** - Static search index
9. **searchContent** - Search content data

This JSON output allows users to programmatically access the paths of all generated artifacts, making it useful for automation and CI/CD workflows.
