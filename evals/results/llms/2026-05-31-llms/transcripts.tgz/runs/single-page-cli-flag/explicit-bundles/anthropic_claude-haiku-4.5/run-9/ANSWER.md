# What `leadtype generate --json` Reports

According to the Leadtype documentation, when the `--json` flag is enabled, the `leadtype generate` command prints a JSON object with paths for the generated artifacts.

## JSON Output Contents

For website-mode builds, the JSON object includes the following artifact paths:

- **llmsFullTxt** - The root full-context file containing every generated markdown docs page
- **docsLlmsTxt** - The docs-scoped llms.txt map for hosted websites
- **llmsTxt** - The product-level /llms.txt file
- **agentReadabilityJson** - JSON file for agent readability metadata
- **sitemapXml** - XML sitemap for the generated documentation site
- **sitemapMd** - Markdown-formatted sitemap
- **robotsTxt** - robots.txt file for search engine crawling
- **searchIndex** - Static search index built over generated markdown
- **searchContent** - Search content data

This JSON output provides a structured mapping of all the agent-readable artifacts and deployment-related files that `leadtype generate` produces, making it easy for build pipelines and automation tools to programmatically discover and use these outputs.
