# What `leadtype generate --json` reports

`leadtype generate` converts docs and writes agent-readable artifacts. When the
`--json` flag is enabled, the command prints a **JSON object containing the
file paths of the generated artifacts** (rather than just running silently).

In website mode, that JSON object includes the following keys, each pointing to
a generated artifact path:

- `llmsFullTxt` — the root full-context file (`llms-full.txt`)
- `docsLlmsTxt` — the docs-scoped map (`/docs/llms.txt`)
- `llmsTxt` — the product-level `llms.txt`
- `agentReadabilityJson` — the agent-readability metadata (`agent-readability.json`)
- `sitemapXml` — the XML sitemap
- `sitemapMd` — the Markdown sitemap
- `robotsTxt` — the `robots.txt` file
- `searchIndex` — the static search index
- `searchContent` — the search content file

In short, `--json` makes `generate` emit a machine-readable manifest of where
each generated output (LLM bundles, sitemaps, robots, and search files) was
written, which is useful for scripting and CI pipelines.

## Source

- `/docs/reference/cli.md` (via `/llms.txt` → `/docs/llms-full/reference.txt`)
