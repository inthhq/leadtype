# What `leadtype generate --json` reports

`leadtype generate` converts docs and writes the generated, agent-readable artifacts. When run with `--json`, it prints a JSON object that reports the **paths** to those generated artifacts.

In website mode, the JSON object includes paths for:

- `llmsFullTxt` — the root `/llms-full.txt` full-context file containing generated markdown docs pages.
- `docsLlmsTxt` — the docs-scoped `/docs/llms.txt` map.
- `llmsTxt` — the product-level `/llms.txt` map.
- `agentReadabilityJson` — the `agent-readability.json` artifact.
- `sitemapXml` — the XML sitemap.
- `sitemapMd` — the markdown sitemap.
- `robotsTxt` — the generated `robots.txt`.
- `searchIndex` — the static local search index.
- `searchContent` — the generated search content data.

So, `leadtype generate --json` is a machine-readable summary of where Leadtype wrote its website and agent-facing output files.