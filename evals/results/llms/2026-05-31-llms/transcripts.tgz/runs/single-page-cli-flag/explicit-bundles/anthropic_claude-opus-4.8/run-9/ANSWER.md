# What `leadtype generate --json` reports

`leadtype generate` converts docs and writes agent-readable artifacts. When the `--json` flag is enabled, `generate` prints a **JSON object containing the paths to the generated artifacts**.

In website mode, that JSON object includes the following keys:

- `llmsFullTxt`
- `docsLlmsTxt`
- `llmsTxt`
- `agentReadabilityJson`
- `sitemapXml`
- `sitemapMd`
- `robotsTxt`
- `searchIndex`
- `searchContent`

In short, `--json` makes `generate` emit a machine-readable manifest of where each generated artifact (the LLM bundles, sitemaps, robots.txt, search index/content, and agent-readability JSON) was written, which is useful for scripting and CI integration.

## Source

- [CLI reference](/docs/reference/cli.md) (via [Reference full-context bundle](/docs/llms-full/reference.txt), discovered from [/llms.txt](/llms.txt))
