# What `leadtype generate --json` reports

Per the Leadtype CLI reference (`/docs/reference/cli.md`), `leadtype generate`
converts docs and writes agent-readable artifacts. The `--json` flag changes its
output format.

When `--json` is enabled, `generate` prints a **JSON object containing the paths
to the generated artifacts**.

In website mode, that JSON object includes the following keys (paths to the
generated files):

- `llmsFullTxt` — the root full-context file
- `docsLlmsTxt` — the docs-scoped `/docs/llms.txt` map
- `llmsTxt` — the product-level `/llms.txt`
- `agentReadabilityJson` — the agent-readability metadata file
- `sitemapXml` — the XML sitemap
- `sitemapMd` — the Markdown sitemap
- `robotsTxt` — the robots.txt file
- `searchIndex` — the static search index
- `searchContent` — the search content file

In short, `--json` makes the command emit a machine-readable manifest of where
each generated artifact (LLM bundles, sitemaps, robots, and search files) was
written, which is useful for scripting and CI pipelines.
