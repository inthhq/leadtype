# What `leadtype generate --json` Reports

When the `--json` flag is enabled with `leadtype generate`, the command prints a JSON object containing paths for all the generated artifacts.

For website-mode output, this JSON object includes the following fields:

- **llmsFullTxt** - Path to the root full-context fallback file
- **docsLlmsTxt** - Path to the docs-scoped LLM bundle
- **llmsTxt** - Path to the product-level llms.txt file
- **agentReadabilityJson** - Path to the agent readability JSON artifact
- **sitemapXml** - Path to the XML sitemap
- **sitemapMd** - Path to the Markdown sitemap
- **robotsTxt** - Path to the robots.txt file
- **searchIndex** - Path to the static search index
- **searchContent** - Path to the search content data

This JSON output provides a complete manifest of all generated agent-readable artifacts and website assets produced by the build process.
