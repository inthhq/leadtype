# What `leadtype generate --json` Reports

When the `--json` flag is enabled, `leadtype generate` prints a JSON object with paths for the generated artifacts.

For website mode, the JSON object includes the following fields:

- **llmsFullTxt** - Path to the full context file containing every generated markdown docs page
- **docsLlmsTxt** - Path to the docs-scoped llms.txt map for hosted websites
- **llmsTxt** - Path to the product-level llms.txt file
- **agentReadabilityJson** - Path to the agent readability JSON artifact
- **sitemapXml** - Path to the XML sitemap
- **sitemapMd** - Path to the markdown sitemap
- **robotsTxt** - Path to the robots.txt file
- **searchIndex** - Path to the search index
- **searchContent** - Path to the search content

This JSON output provides a structured overview of all the agent-readable artifacts that have been generated during the docs build process.
