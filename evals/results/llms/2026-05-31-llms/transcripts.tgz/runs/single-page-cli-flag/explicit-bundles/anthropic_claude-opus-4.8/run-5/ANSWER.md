# What `leadtype generate --json` reports

According to the Leadtype docs ([CLI reference](/docs/reference/cli.md)), `leadtype generate` converts docs and writes agent-readable artifacts. The `--json` flag is one of its important flags (alongside `--src`, `--out`, `--base-url`, `--bundle`, `--enrich-git`, and `--strict`).

## The JSON output

When `--json` is enabled, `generate` **prints a JSON object containing the paths for the generated artifacts**.

In website mode, that object includes the following path fields:

- `llmsFullTxt` — the root full-context file (`/llms-full.txt`)
- `docsLlmsTxt` — the docs-scoped map (`/docs/llms.txt`)
- `llmsTxt` — the product-level map (`/llms.txt`)
- `agentReadabilityJson` — the agent-readability artifact (`agent-readability.json`)
- `sitemapXml` — the XML sitemap
- `sitemapMd` — the markdown sitemap
- `robotsTxt` — the robots file
- `searchIndex` — the static search index JSON
- `searchContent` — the search content artifact

## In short

`--json` does not change what gets built; it makes the command emit a machine-readable JSON object mapping each generated deployment artifact to its output path. This is useful in build pipelines for locating or verifying the static agent-readable files (the llms files, sitemaps, robots.txt, search JSON, and agent-readability.json) that the docs site should serve.
