# What `leadtype generate --json` Reports

According to the Leadtype docs, when the `--json` flag is enabled, the `leadtype generate` command prints a JSON object containing paths for the generated artifacts.

For website-mode output, the JSON object includes the following paths:

- **llmsFullTxt**: The full-context bundle containing all generated markdown docs pages
- **docsLlmsTxt**: The docs-scoped llms.txt map for hosted websites
- **llmsTxt**: The product-level llms.txt file
- **agentReadabilityJson**: The agent-readability JSON artifact
- **sitemapXml**: The XML sitemap
- **sitemapMd**: The Markdown sitemap
- **robotsTxt**: The robots.txt file
- **searchIndex**: The static search index
- **searchContent**: The search content data

This JSON output allows automation and integration with other tools by providing structured information about all the generated artifacts from the documentation build process.
