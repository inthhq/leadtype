`leadtype generate --json` runs the normal `leadtype generate` conversion, but prints a machine-readable JSON object describing the generated outputs.

In website mode, the JSON object reports paths for these artifacts:

- `llmsFullTxt` — the root `/llms-full.txt` full-context file
- `docsLlmsTxt` — the docs-scoped `/docs/llms.txt` map
- `llmsTxt` — the product-level `/llms.txt`
- `agentReadabilityJson` — `docs/agent-readability.json`
- `sitemapXml` — `docs/sitemap.xml`
- `sitemapMd` — `docs/sitemap.md`
- `robotsTxt` — `docs/robots.txt`
- `searchIndex` — `docs/search-index.json`
- `searchContent` — `docs/search-content.json`

So, `--json` is for automation/CI: it reports where Leadtype wrote its generated agent-readable website artifacts, rather than only printing human-oriented CLI output.
