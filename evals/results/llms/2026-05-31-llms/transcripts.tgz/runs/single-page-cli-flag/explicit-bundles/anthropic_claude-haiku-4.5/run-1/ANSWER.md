# What `leadtype generate --json` Reports

According to the Leadtype docs, when the `--json` flag is enabled, `leadtype generate` prints a JSON object with paths for all the generated artifacts.

## JSON Output Structure

The JSON output includes the following fields in the website-mode object:

- **llmsFullTxt** - Path to the full-context file containing every generated markdown docs page
- **docsLlmsTxt** - Path to the docs-scoped llms.txt map for hosted websites
- **llmsTxt** - Path to the product-level llms.txt file
- **agentReadabilityJson** - Path to the agent readability JSON artifact
- **sitemapXml** - Path to the XML sitemap
- **sitemapMd** - Path to the markdown sitemap
- **robotsTxt** - Path to the robots.txt file
- **searchIndex** - Path to the static search index
- **searchContent** - Path to the search content data

This JSON output allows you to programmatically access the locations of all generated artifacts produced by the documentation build process.
