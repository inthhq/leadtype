# What `leadtype generate --json` reports

`leadtype generate` converts docs and writes agent-readable artifacts. When the `--json` flag is enabled, `generate` prints a **JSON object containing the file paths for the generated artifacts**.

In website mode, that JSON object includes the following paths:

- `llmsFullTxt` — the root full-context `llms-full.txt` file
- `docsLlmsTxt` — the docs-scoped `/docs/llms.txt` map
- `llmsTxt` — the product-level `/llms.txt`
- `agentReadabilityJson` — the `agent-readability.json` artifact
- `sitemapXml` — the XML sitemap
- `sitemapMd` — the Markdown sitemap
- `robotsTxt` — the `robots.txt` file
- `searchIndex` — the static search index
- `searchContent` — the search content

In short, `--json` provides a machine-readable manifest of where each generated artifact was written, which is useful for build tooling and CI pipelines that need to locate or verify the outputs.

## Source

- [/docs/reference/cli.md](docs/reference/cli.md) (via the Reference full-context bundle, `/docs/llms-full/reference.txt`)
