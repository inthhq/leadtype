# What `leadtype generate --json` reports

According to the Leadtype docs ([CLI reference](/docs/reference/cli.md)),
`leadtype generate` converts docs and writes agent-readable artifacts.

When the `--json` flag is enabled, `generate` prints a **JSON object containing
the paths for the generated artifacts**. It does not just print logs — it emits
machine-readable output describing where each output file was written.

## Website-mode output fields

In website mode, the JSON object includes the following artifact paths:

| Field | Artifact |
|-------|----------|
| `llmsFullTxt` | The root full-context `llms-full.txt` file |
| `docsLlmsTxt` | The docs-scoped `/docs/llms.txt` map |
| `llmsTxt` | The product-level `/llms.txt` file |
| `agentReadabilityJson` | The `agent-readability.json` artifact |
| `sitemapXml` | The XML sitemap |
| `sitemapMd` | The Markdown sitemap |
| `robotsTxt` | The `robots.txt` file |
| `searchIndex` | The static search index |
| `searchContent` | The search content data |

## Summary

`leadtype generate --json` reports a JSON object that maps the names of the
generated agent-readable and website artifacts to their output paths. This makes
the build output easy to consume programmatically (for example in CI), since a
tool can read the JSON to locate the generated `llms.txt`, full-context bundle,
sitemaps, `robots.txt`, search index, and agent-readability metadata.
