`leadtype generate --json` makes `leadtype generate` print a JSON report instead of only human-oriented output. The report lists the paths of the artifacts that were generated.

In website mode, the JSON object includes paths for:

- `llmsFullTxt`
- `docsLlmsTxt`
- `llmsTxt`
- `agentReadabilityJson`
- `sitemapXml`
- `sitemapMd`
- `robotsTxt`
- `searchIndex`
- `searchContent`
