# What `leadtype generate --json` reports

According to the Leadtype [CLI reference](/docs/reference/cli.md), `leadtype generate`
converts docs and writes agent-readable artifacts. The `--json` flag controls its
output format.

## Behavior

When `--json` is enabled, `generate` **prints a JSON object containing the file paths
for the generated artifacts**. This lets tooling and CI pipelines discover exactly
where each output was written.

## Fields reported (website mode)

In website mode, the emitted JSON object includes paths for the following artifacts:

- `llmsFullTxt` — the root full-context bundle (`/llms-full.txt`)
- `docsLlmsTxt` — the docs-scoped map (`/docs/llms.txt`)
- `llmsTxt` — the product-level map (`/llms.txt`)
- `agentReadabilityJson` — the agent-readability metadata file
- `sitemapXml` — the XML sitemap
- `sitemapMd` — the Markdown sitemap
- `robotsTxt` — the `robots.txt` file
- `searchIndex` — the static search index
- `searchContent` — the search content data

## Summary

`leadtype generate --json` does not change *what* is built; it changes *how the result
is reported*. Instead of human-oriented logging, it outputs a machine-readable JSON
object mapping each generated agent-readable/website artifact (LLM bundles, sitemaps,
robots, and search files) to its output path.
