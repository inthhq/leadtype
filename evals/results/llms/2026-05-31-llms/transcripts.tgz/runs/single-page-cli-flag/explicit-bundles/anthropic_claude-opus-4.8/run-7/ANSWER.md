# What `leadtype generate --json` reports

According to the Leadtype docs ([CLI reference](/docs/reference/cli.md)), `leadtype generate`
converts docs and writes agent-readable artifacts. The `--json` flag is one of its
important flags (alongside `--src`, `--out`, `--base-url`, `--bundle`, `--enrich-git`, and `--strict`).

## The JSON output

When `--json` is enabled, `generate` prints a **JSON object containing the file paths for
the generated artifacts**.

In website mode, that JSON object includes the following keys (paths to the generated
artifacts):

- `llmsFullTxt`
- `docsLlmsTxt`
- `llmsTxt`
- `agentReadabilityJson`
- `sitemapXml`
- `sitemapMd`
- `robotsTxt`
- `searchIndex`
- `searchContent`

## In short

`leadtype generate --json` doesn't change what gets built; it makes the command emit a
machine-readable JSON manifest mapping each generated agent-readable artifact (the LLM
text bundles, the agent-readability JSON, sitemaps, robots.txt, and the search index/content)
to its output path—useful for scripting and CI consumption.
