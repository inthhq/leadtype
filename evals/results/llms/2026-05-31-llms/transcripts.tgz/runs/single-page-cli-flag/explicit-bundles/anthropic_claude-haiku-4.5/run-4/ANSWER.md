# What `leadtype generate --json` Reports

According to the Leadtype docs, when the `--json` flag is enabled, `leadtype generate` prints a JSON object with paths for the generated artifacts.

## JSON Output for Website Mode

In website mode, the JSON object includes the following paths:

- **llmsFullTxt** - The root full-context file containing all generated markdown
- **docsLlmsTxt** - The docs-scoped LLM file map for hosted websites
- **llmsTxt** - The product-level /llms.txt file
- **agentReadabilityJson** - The agent readability JSON artifact
- **sitemapXml** - XML sitemap
- **sitemapMd** - Markdown sitemap
- **robotsTxt** - robots.txt file
- **searchIndex** - The static search index
- **searchContent** - The search content data

This JSON output allows users to programmatically access the paths of all generated artifacts, making it useful for integration into build pipelines and automation workflows.
