# What `leadtype generate --json` Reports

When the `--json` flag is enabled with `leadtype generate`, the command prints a JSON object containing paths for all the generated artifacts.

## JSON Output Structure

For website-mode builds, the JSON object includes the following artifact paths:

- **llmsFullTxt** - Path to the full-context llms-full.txt file
- **docsLlmsTxt** - Path to the docs-scoped /docs/llms.txt map
- **llmsTxt** - Path to the product-level /llms.txt file
- **agentReadabilityJson** - Path to the agent-readability.json artifact
- **sitemapXml** - Path to the XML sitemap file
- **sitemapMd** - Path to the markdown sitemap file
- **robotsTxt** - Path to the robots.txt file
- **searchIndex** - Path to the static search index
- **searchContent** - Path to the search content data

This JSON output allows programmatic access to the locations of all generated artifacts, making it useful for automation and integration with other tools.
