# `leadtype generate --json`

According to the Leadtype CLI reference, `leadtype generate` converts docs and writes agent-readable artifacts. When run with `--json`, it prints a JSON object reporting the paths of the generated artifacts.

In website mode, that JSON object includes paths for:

- `llmsFullTxt`
- `docsLlmsTxt`
- `llmsTxt`
- `agentReadabilityJson`
- `sitemapXml`
- `sitemapMd`
- `robotsTxt`
- `searchIndex`
- `searchContent`
