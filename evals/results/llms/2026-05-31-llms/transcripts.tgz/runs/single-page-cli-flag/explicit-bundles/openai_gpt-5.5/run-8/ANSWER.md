`leadtype generate --json` makes `leadtype generate` print a JSON object instead of only human-oriented output. That JSON reports the paths to the artifacts Leadtype generated.

For website-mode generation, the reported object includes paths for:

- `llmsFullTxt`
- `docsLlmsTxt`
- `llmsTxt`
- `agentReadabilityJson`
- `sitemapXml`
- `sitemapMd`
- `robotsTxt`
- `searchIndex`
- `searchContent`
