`leadtype generate --json` makes `leadtype generate` print a JSON object instead of only normal CLI output. The JSON reports the paths of the artifacts that were generated.

In website mode, the reported object includes paths for:

- `llmsFullTxt`
- `docsLlmsTxt`
- `llmsTxt`
- `agentReadabilityJson`
- `sitemapXml`
- `sitemapMd`
- `robotsTxt`
- `searchIndex`
- `searchContent`
