# What `leadtype generate --json` reports

`leadtype generate` converts docs and writes agent-readable artifacts. When the
`--json` flag is enabled, `generate` prints a **JSON object containing the file
paths of the generated artifacts**, instead of (or in addition to) human-oriented
output.

## Reported fields (website mode)

In website mode, the JSON object includes paths for the following generated
artifacts:

- `llmsFullTxt` — the root full-context file
- `docsLlmsTxt` — the docs-scoped llms.txt map
- `llmsTxt` — the product-level llms.txt
- `agentReadabilityJson` — the agent-readability metadata file
- `sitemapXml` — the XML sitemap
- `sitemapMd` — the markdown sitemap
- `robotsTxt` — robots.txt
- `searchIndex` — the static search index
- `searchContent` — the search content

## Summary

`--json` makes `leadtype generate` emit a machine-readable manifest of where each
generated artifact was written. This is useful for scripting and CI, since it
lets tooling discover the paths of the produced files (LLM bundles, sitemaps,
robots.txt, and the search index/content) without parsing console text.

*Source: `/docs/reference/cli.md` (via `/llms.txt` → `/llms-full.txt` →
`/docs/llms-full/reference.txt`).*
