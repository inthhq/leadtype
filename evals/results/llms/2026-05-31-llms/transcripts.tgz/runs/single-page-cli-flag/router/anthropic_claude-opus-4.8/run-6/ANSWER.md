# What `leadtype generate --json` reports

`leadtype generate` converts docs and writes agent-readable artifacts. When you add the `--json` flag, `generate` prints a **JSON object containing the file paths of the generated artifacts** (instead of just doing the work silently). This makes it easy for CI pipelines or other tools to discover exactly what was produced.

## The website-mode JSON object

In website mode, the JSON object reports paths for the following generated artifacts:

| Key | Artifact |
| --- | --- |
| `llmsFullTxt` | The root `/llms-full.txt` full-context file (every generated markdown docs page) |
| `docsLlmsTxt` | The docs-scoped `/docs/llms.txt` map |
| `llmsTxt` | The product-level `/llms.txt` |
| `agentReadabilityJson` | The `agent-readability.json` artifact |
| `sitemapXml` | `sitemap.xml` |
| `sitemapMd` | The markdown sitemap |
| `robotsTxt` | `robots.txt` |
| `searchIndex` | The static search index |
| `searchContent` | The search content used by the index |

## Summary

`--json` doesn't change *what* is generated — it changes the *output format* of the command so that the resulting artifact paths are emitted as a structured JSON object. This lets downstream tooling reliably locate the generated LLM bundles (`llms.txt`, `docs/llms.txt`, `llms-full.txt`), the agent-readability metadata, the sitemaps, the robots file, and the search index/content.

## Sources

- `/docs/reference/cli.md` (via `/llms.txt` → `/llms-full.txt` → `/docs/llms-full/reference.txt`)
