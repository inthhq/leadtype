# What `leadtype generate --json` reports

Source: Leadtype docs site — [CLI Reference](/docs/reference/cli.md).

`leadtype generate` converts docs and writes agent-readable artifacts. When the
`--json` flag is enabled, `generate` prints a **JSON object containing the paths
for the generated artifacts**.

In website mode, that JSON object includes the following path fields:

- `llmsFullTxt`
- `docsLlmsTxt`
- `llmsTxt`
- `agentReadabilityJson`
- `sitemapXml`
- `sitemapMd`
- `robotsTxt`
- `searchIndex`
- `searchContent`

## Summary

`--json` makes `leadtype generate` emit a machine-readable manifest of where it
wrote each generated artifact (the LLM text files, agent-readability JSON,
sitemaps, robots.txt, and search index/content), rather than just running the
build. This is useful for scripting and CI, where you need to know the output
paths of the generated files.
