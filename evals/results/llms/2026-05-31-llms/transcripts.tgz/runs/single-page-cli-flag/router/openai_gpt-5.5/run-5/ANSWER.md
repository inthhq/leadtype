# `leadtype generate --json`

According to the Leadtype CLI reference, `leadtype generate --json` prints a JSON object describing the paths of the artifacts that were generated.

In website mode, that JSON object includes paths for:

- `llmsFullTxt`
- `docsLlmsTxt`
- `llmsTxt`
- `agentReadabilityJson`
- `sitemapXml`
- `sitemapMd`
- `robotsTxt`
- `searchIndex`
- `searchContent`
