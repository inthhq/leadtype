`leadtype generate --json` makes `leadtype generate` print a JSON object describing the paths of the artifacts it generated.

In website mode, that JSON object includes paths for:

- `llmsFullTxt`
- `docsLlmsTxt`
- `llmsTxt`
- `agentReadabilityJson`
- `sitemapXml`
- `sitemapMd`
- `robotsTxt`
- `searchIndex`
- `searchContent`

In short, `--json` reports where Leadtype wrote the generated agent-readable, sitemap, robots, and search artifacts.
