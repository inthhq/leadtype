# What `leadtype generate --json` Reports

According to the Leadtype documentation, when the `--json` flag is enabled with `leadtype generate`, the command prints a JSON object containing paths for the generated artifacts.

## Website-Mode Output

For website mode, the JSON object includes the following fields:

- **llmsFullTxt**: Path to the root full-context file containing all generated markdown docs pages
- **docsLlmsTxt**: Path to the docs-scoped llms.txt map for hosted websites
- **llmsTxt**: Path to the product-level llms.txt file
- **agentReadabilityJson**: Path to the agent-readability JSON artifact
- **sitemapXml**: Path to the XML sitemap
- **sitemapMd**: Path to the markdown sitemap
- **robotsTxt**: Path to the robots.txt file
- **searchIndex**: Path to the static search index
- **searchContent**: Path to the search content

This JSON output provides a comprehensive manifest of all the agent-readable artifacts and website resources that were generated during the build process.
