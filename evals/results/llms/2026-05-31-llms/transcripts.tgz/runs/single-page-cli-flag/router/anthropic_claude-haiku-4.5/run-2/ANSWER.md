# What `leadtype generate --json` Reports

According to the Leadtype documentation, when the `--json` flag is enabled with the `leadtype generate` command, it prints a JSON object containing paths for all the generated artifacts.

Specifically, in website-mode, the JSON output includes the following fields:

- **llmsFullTxt**: Path to the complete full-context file containing every generated markdown docs page
- **docsLlmsTxt**: Path to the docs-scoped llms.txt map for hosted websites
- **llmsTxt**: Path to the product-level llms.txt
- **agentReadabilityJson**: Path to the agent-readability JSON artifact
- **sitemapXml**: Path to the XML sitemap
- **sitemapMd**: Path to the markdown sitemap
- **robotsTxt**: Path to robots.txt
- **searchIndex**: Path to the static search index
- **searchContent**: Path to the search content data

This JSON output allows users and automated processes to easily locate all the generated artifacts that Leadtype produces from the source documentation.
