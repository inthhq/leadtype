# What `leadtype generate --json` reports

According to the Leadtype CLI reference, `leadtype generate` converts docs and writes agent-readable artifacts. When you add `--json`, the command prints a JSON object that reports the paths of the generated artifacts.

In website mode, that JSON object includes paths for:

- `llmsFullTxt`
- `docsLlmsTxt`
- `llmsTxt`
- `agentReadabilityJson`
- `sitemapXml`
- `sitemapMd`
- `robotsTxt`
- `searchIndex`
- `searchContent`
