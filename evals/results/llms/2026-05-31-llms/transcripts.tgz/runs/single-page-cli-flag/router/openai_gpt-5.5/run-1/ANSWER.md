`leadtype generate --json` runs `leadtype generate` and prints a JSON object instead of only human-oriented output.

According to the Leadtype CLI reference, the JSON output reports paths for the artifacts that were generated. In website mode, the object includes paths for:

- `llmsFullTxt`
- `docsLlmsTxt`
- `llmsTxt`
- `agentReadabilityJson`
- `sitemapXml`
- `sitemapMd`
- `robotsTxt`
- `searchIndex`
- `searchContent`

So `--json` is primarily for machine-readable reporting of where Leadtype wrote its generated website and agent-readability artifacts.