# What `leadtype generate --json` reports

According to the Leadtype docs ([CLI reference](/docs/reference/cli.md)), `leadtype generate` converts docs and writes agent-readable artifacts. The `--json` flag controls its machine-readable output.

When `--json` is enabled, `generate` **prints a JSON object containing the paths to the generated artifacts**.

In website mode, that JSON object includes the following path entries:

- `llmsFullTxt`
- `docsLlmsTxt`
- `llmsTxt`
- `agentReadabilityJson`
- `sitemapXml`
- `sitemapMd`
- `robotsTxt`
- `searchIndex`
- `searchContent`

In short, `--json` doesn't change what gets built — it makes `generate` emit a structured JSON report mapping the artifact names to their output paths, which is useful for scripting and CI consumption.

## Source

- `/docs/reference/cli.md` (via `/llms.txt` → `/llms-full.txt` → `/docs/llms-full/reference.txt`)
