# What `leadtype generate --json` reports

`leadtype generate` converts docs and writes the agent-readable artifacts. The
`--json` flag changes its output behavior: when `--json` is enabled, `generate`
prints a **JSON object containing the paths to the generated artifacts**.

## Website-mode JSON output

In website mode, the JSON object includes the following keys, each pointing to a
generated artifact path:

- `llmsFullTxt` — the root full-context file (`/llms-full.txt`)
- `docsLlmsTxt` — the docs-scoped map (`/docs/llms.txt`)
- `llmsTxt` — the product-level `/llms.txt`
- `agentReadabilityJson` — the agent-readability metadata (`agent-readability.json`)
- `sitemapXml` — the XML sitemap
- `sitemapMd` — the markdown sitemap
- `robotsTxt` — the `robots.txt` file
- `searchIndex` — the static search index
- `searchContent` — the search content

## Notes

- `--json` is one of `generate`'s flags, alongside `--src`, `--out`,
  `--base-url`, `--bundle`, `--enrich-git`, and `--strict`.
- The purpose is to give machine-readable output (the locations of everything
  `generate` produced), which is useful for build pipelines and CI rather than
  the human-oriented default output.

_Source: `/docs/reference/cli.md` (via the Leadtype docs site `/llms.txt` →
Full Context Router → Reference)._
