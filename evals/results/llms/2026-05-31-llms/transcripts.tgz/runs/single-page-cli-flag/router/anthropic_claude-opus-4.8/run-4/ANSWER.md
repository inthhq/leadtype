# What `leadtype generate --json` reports

`leadtype generate` converts docs and writes agent-readable artifacts. When the
`--json` flag is enabled, `generate` prints a **JSON object containing the paths
of the generated artifacts** (rather than just running silently).

## Website-mode output

In website mode, the JSON object includes the following keys, each pointing to a
generated artifact path:

- `llmsFullTxt` — the root full-context file
- `docsLlmsTxt` — the docs-scoped llms.txt map
- `llmsTxt` — the product-level llms.txt
- `agentReadabilityJson` — the agent-readability metadata file
- `sitemapXml` — the XML sitemap
- `sitemapMd` — the Markdown sitemap
- `robotsTxt` — the robots.txt file
- `searchIndex` — the static search index
- `searchContent` — the search content file

## Why it's useful

Because `--json` emits machine-readable paths to every generated artifact, it's
well suited for build/CI pipelines that need to locate, verify, or further
process the outputs of a docs build.

## Source

- `/docs/reference/cli.md` (via `/llms.txt` → `/llms-full.txt` →
  `/docs/llms-full/reference.txt`)
