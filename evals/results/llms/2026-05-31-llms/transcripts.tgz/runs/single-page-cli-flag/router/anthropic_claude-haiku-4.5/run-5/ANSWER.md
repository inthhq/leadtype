# What `leadtype generate --json` Reports

According to the Leadtype documentation, when the `--json` flag is enabled on the `leadtype generate` command, it prints a JSON object containing the paths for the generated artifacts.

## Generated Artifacts in Website Mode

The JSON output includes the following artifact paths:

- **llmsFullTxt**: The full context root file containing every generated markdown docs page
- **docsLlmsTxt**: The docs-scoped LLM map for hosted websites
- **llmsTxt**: The product-level root LLM map file
- **agentReadabilityJson**: An agent-readability JSON artifact file
- **sitemapXml**: The XML sitemap
- **sitemapMd**: The markdown sitemap
- **robotsTxt**: The robots.txt file
- **searchIndex**: The static search index
- **searchContent**: The search content data

This JSON output allows for programmatic access to all the paths of the generated artifacts, making it useful for CI/CD pipelines and automated workflows that need to locate or process these files after generation.
