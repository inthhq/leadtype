# What `leadtype generate --json` reports

According to the Leadtype CLI reference (`/docs/reference/cli.md`), `leadtype generate` converts docs and writes agent-readable artifacts. The `--json` flag controls how it reports what it produced.

When `--json` is enabled, `generate` prints a **JSON object containing the paths for the generated artifacts**.

In website mode, that JSON object includes the following path fields:

- `llmsFullTxt`
- `docsLlmsTxt`
- `llmsTxt`
- `agentReadabilityJson`
- `sitemapXml`
- `sitemapMd`
- `robotsTxt`
- `searchIndex`
- `searchContent`

In short, `--json` makes `leadtype generate` emit a machine-readable summary of where each generated artifact (the LLM text files, agent-readability JSON, sitemaps, robots.txt, and search index/content) was written, which is convenient for scripting and CI pipelines.
