# What `leadtype generate --json` Reports

According to the Leadtype documentation, when the `--json` flag is enabled, the `leadtype generate` command prints a JSON object containing paths for all the generated artifacts.

For website-mode, the JSON object includes the following fields:

- `llmsFullTxt` - The root full-context fallback file
- `docsLlmsTxt` - Docs-scoped LLM file map
- `llmsTxt` - Product-level LLM file
- `agentReadabilityJson` - Agent readability artifact
- `sitemapXml` - XML sitemap
- `sitemapMd` - Markdown sitemap
- `robotsTxt` - Robots.txt file
- `searchIndex` - Static search index
- `searchContent` - Search content

In summary, `leadtype generate --json` outputs a structured JSON object that reports the file paths of all the generated agent-readable artifacts and website assets created during the documentation build process.
