# What `leadtype generate --json` reports

`leadtype generate` converts docs and writes agent-readable artifacts. When the `--json` flag is enabled, `generate` prints a **JSON object containing the paths to the generated artifacts**.

In website mode, that JSON object includes the following keys (paths):

- `llmsFullTxt`
- `docsLlmsTxt`
- `llmsTxt`
- `agentReadabilityJson`
- `sitemapXml`
- `sitemapMd`
- `robotsTxt`
- `searchIndex`
- `searchContent`

In short, `--json` gives you a machine-readable manifest of where each generated output file (the LLM bundle files, sitemaps, robots.txt, and search index/content) was written, which is useful for scripting and CI pipelines.

## Source

- [/docs/reference/cli.md](/docs/reference/cli.md) — "When `--json` is enabled, generate prints a JSON object with paths for the generated artifacts. The website-mode object includes `llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, `agentReadabilityJson`, `sitemapXml`, `sitemapMd`, `robotsTxt`, `searchIndex`, and `searchContent`."
