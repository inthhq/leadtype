# What `leadtype generate --json` reports

According to the Leadtype CLI reference, `leadtype generate` converts docs and writes agent-readable artifacts. When the `--json` flag is enabled, it prints a JSON object that reports the paths of the generated artifacts.

In website mode, that JSON object includes paths for:

- `llmsFullTxt`
- `docsLlmsTxt`
- `llmsTxt`
- `agentReadabilityJson`
- `sitemapXml`
- `sitemapMd`
- `robotsTxt`
- `searchIndex`
- `searchContent`

So, `leadtype generate --json` is mainly a machine-readable summary of where Leadtype wrote its generated docs, LLM, sitemap, robots, and search artifacts.
