# What `leadtype generate --json` Reports

When the `--json` flag is enabled with the `leadtype generate` command, it prints a JSON object containing paths for the generated artifacts.

For website-mode output, the JSON object includes the following fields:

- **llmsFullTxt**: Path to the full-context router file
- **docsLlmsTxt**: Path to the docs-scoped LLM file
- **llmsTxt**: Path to the product-level llms.txt file
- **agentReadabilityJson**: Path to the agent readability JSON artifact
- **sitemapXml**: Path to the XML sitemap
- **sitemapMd**: Path to the Markdown sitemap
- **robotsTxt**: Path to the robots.txt file
- **searchIndex**: Path to the static search index
- **searchContent**: Path to the search content data

This JSON output allows automation tools and build systems to easily discover the paths of all generated artifacts for further processing or deployment.
