`leadtype generate --json` makes `leadtype generate` print a JSON object describing the paths of the artifacts it generated.

In website mode, that JSON object includes paths for:

- `llmsFullTxt` — the root full-context `/llms-full.txt` file
- `docsLlmsTxt` — the docs-scoped `/docs/llms.txt` map
- `llmsTxt` — the product-level `/llms.txt`
- `agentReadabilityJson` — `agent-readability.json`
- `sitemapXml` — the XML sitemap
- `sitemapMd` — the markdown sitemap
- `robotsTxt` — `robots.txt`
- `searchIndex` — the generated search index JSON
- `searchContent` — the generated search content JSON

So `--json` reports where Leadtype wrote its generated, agent-readable and site-support artifacts; it does not change the generation itself.