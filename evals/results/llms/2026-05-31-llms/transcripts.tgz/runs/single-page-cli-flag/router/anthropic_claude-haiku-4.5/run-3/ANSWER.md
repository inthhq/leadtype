# What `leadtype generate --json` Reports

When the `--json` flag is enabled with `leadtype generate`, the command prints a JSON object containing paths for the generated artifacts.

In **website mode**, the JSON object includes the following properties:

- `llmsFullTxt` - Path to the full-context root file
- `docsLlmsTxt` - Path to the docs-scoped LLM file
- `llmsTxt` - Path to the product-level LLM file
- `agentReadabilityJson` - Path to the agent readability JSON artifact
- `sitemapXml` - Path to the XML sitemap
- `sitemapMd` - Path to the markdown sitemap
- `robotsTxt` - Path to the robots.txt file
- `searchIndex` - Path to the search index
- `searchContent` - Path to the search content

These paths report where Leadtype has written the agent-readable artifacts and other build outputs that enable downstream integration, such as LLM context files for agents, search functionality, and SEO files.
