# What `leadtype generate --json` reports

According to the Leadtype docs ([CLI reference](/docs/reference/cli.md)), `leadtype generate` converts docs and writes agent-readable artifacts. The `--json` flag is one of its important flags (alongside `--src`, `--out`, `--base-url`, `--bundle`, `--enrich-git`, and `--strict`).

When `--json` is enabled, `generate` prints a **JSON object containing paths for the generated artifacts**.

In website mode, that JSON object includes the following keys (paths to the generated files):

- `llmsFullTxt`
- `docsLlmsTxt`
- `llmsTxt`
- `agentReadabilityJson`
- `sitemapXml`
- `sitemapMd`
- `robotsTxt`
- `searchIndex`
- `searchContent`

In short, `--json` is a machine-readable output mode: instead of (or in addition to) plain output, it emits a JSON map of the artifact paths produced by the generate run, which is useful for scripting and CI pipelines that need to locate the generated files.
