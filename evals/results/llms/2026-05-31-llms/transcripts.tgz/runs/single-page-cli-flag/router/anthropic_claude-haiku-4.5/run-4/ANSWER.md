# What `leadtype generate --json` Reports

When the `--json` flag is enabled with `leadtype generate`, the command prints a JSON object with paths for the generated artifacts.

In website mode, the JSON object includes the following properties:

- **llmsFullTxt** - Path to the full-context file containing every generated markdown docs page
- **docsLlmsTxt** - Path to the docs-scoped llms.txt map for hosted websites
- **llmsTxt** - Path to the product-level llms.txt root file
- **agentReadabilityJson** - Path to the agent readability artifact
- **sitemapXml** - Path to the XML sitemap
- **sitemapMd** - Path to the markdown sitemap
- **robotsTxt** - Path to the robots.txt file
- **searchIndex** - Path to the static search index
- **searchContent** - Path to the search content file

These paths allow you to programmatically access all the generated artifacts that result from the `leadtype generate` build process.
