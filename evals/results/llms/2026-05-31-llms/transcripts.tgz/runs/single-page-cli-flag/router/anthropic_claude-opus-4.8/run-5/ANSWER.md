# What `leadtype generate --json` reports

`leadtype generate` converts docs and writes the agent-readable artifacts. When
the `--json` flag is enabled, the command **prints a JSON object containing the
paths to the generated artifacts** (rather than human-oriented log output).

In website mode, that JSON object includes the following keys, each pointing to
a generated artifact's path:

- `llmsFullTxt` — the root full-context file
- `docsLlmsTxt` — the docs-scoped `/docs/llms.txt` map
- `llmsTxt` — the product-level `/llms.txt`
- `agentReadabilityJson` — the agent-readability metadata file
- `sitemapXml` — the XML sitemap
- `sitemapMd` — the Markdown sitemap
- `robotsTxt` — the `robots.txt` file
- `searchIndex` — the static search index
- `searchContent` — the search content file

In short, `--json` makes `generate` emit a machine-readable manifest mapping
each produced website-mode artifact to its output path, which is useful for
scripting and CI integration.

## Source

- [/docs/reference/cli.md](/docs/reference/cli.md)
