# What `leadtype generate --json` Reports

When the `--json` flag is enabled with `leadtype generate`, the command prints a JSON object containing paths for all generated artifacts.

## Website-Mode Output

In website mode, the JSON object includes the following paths:

- **llmsFullTxt**: Path to the full-context file containing every generated markdown docs page
- **docsLlmsTxt**: Path to the docs-scoped llms.txt map for hosted websites
- **llmsTxt**: Path to the product-level llms.txt file
- **agentReadabilityJson**: Path to the agent readability JSON artifact
- **sitemapXml**: Path to the XML sitemap
- **sitemapMd**: Path to the markdown sitemap
- **robotsTxt**: Path to the robots.txt file
- **searchIndex**: Path to the static search index
- **searchContent**: Path to the search content data

This JSON output enables automation and integration workflows by providing precise paths to all generated agent-readable artifacts and website assets.
