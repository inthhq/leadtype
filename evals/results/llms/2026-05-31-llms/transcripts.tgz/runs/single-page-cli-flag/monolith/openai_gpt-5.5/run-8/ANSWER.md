`leadtype generate --json` runs the normal `generate` command but prints a JSON object describing the generated artifacts, rather than only human-oriented output.

According to the Leadtype CLI reference, the JSON contains paths for the artifacts that were written. In website mode, it reports these artifact paths:

- `llmsFullTxt` — the root `/llms-full.txt` full-context file
- `docsLlmsTxt` — the docs-scoped `/docs/llms.txt`
- `llmsTxt` — the site-root `/llms.txt`
- `agentReadabilityJson` — `agent-readability.json`
- `sitemapXml` — the XML sitemap
- `sitemapMd` — the markdown sitemap
- `robotsTxt` — `robots.txt`
- `searchIndex` — the generated search index JSON
- `searchContent` — the generated search content JSON

So, `--json` is mainly for automation/CI: it gives machine-readable paths to the files Leadtype generated.