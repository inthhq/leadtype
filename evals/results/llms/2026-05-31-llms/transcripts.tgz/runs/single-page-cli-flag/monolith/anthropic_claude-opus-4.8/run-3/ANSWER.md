# What `leadtype generate --json` reports

`leadtype generate` converts docs and writes agent-readable artifacts. The
`--json` flag changes its output: instead of (or in addition to) normal
generation, `generate` **prints a JSON object containing the paths of the
generated artifacts**.

## The website-mode JSON object

According to the CLI reference (`/docs/reference/cli.md`), when run in website
mode the JSON object includes the following keys, each pointing to a generated
artifact path:

- `llmsFullTxt` — the root `/llms-full.txt` flattened all-docs file
- `docsLlmsTxt` — the docs-scoped `/docs/llms.txt` map
- `llmsTxt` — the product-level `/llms.txt`
- `agentReadabilityJson` — `docs/agent-readability.json`
- `sitemapXml` — `docs/sitemap.xml`
- `sitemapMd` — `docs/sitemap.md`
- `robotsTxt` — `docs/robots.txt`
- `searchIndex` — `docs/search-index.json`
- `searchContent` — `docs/search-content.json`

## Notes

- These are the artifacts produced by **website mode**. Bundle mode
  (`leadtype generate --bundle`) skips the website-only artifacts (llms.txt,
  llms-full.txt, search JSON, sitemap files, robots.txt, and
  agent-readability.json), so the reported paths differ accordingly.
- In short, `--json` is a machine-readable report of *where each generated file
  was written*, which is useful for scripting and CI verification.
