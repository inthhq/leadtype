# What `leadtype generate --json` reports

According to the Leadtype docs ([CLI reference](/docs/reference/cli.md)), `leadtype generate` converts docs and writes agent-readable artifacts. The `--json` flag changes its output behavior:

> When `--json` is enabled, `generate` prints a JSON object with paths for the generated artifacts.

## What's in the JSON object (website mode)

In website mode, the JSON object reports the file paths of the generated artifacts using the following keys:

- `llmsFullTxt` — the root `/llms-full.txt` flattened full-context file
- `docsLlmsTxt` — the docs-scoped `/docs/llms.txt` map
- `llmsTxt` — the product-level `/llms.txt`
- `agentReadabilityJson` — `docs/agent-readability.json`
- `sitemapXml` — `docs/sitemap.xml`
- `sitemapMd` — `docs/sitemap.md`
- `robotsTxt` — `docs/robots.txt`
- `searchIndex` — `docs/search-index.json`
- `searchContent` — `docs/search-content.json`

## In short

`--json` makes `generate` emit a machine-readable JSON object that maps each generated website artifact to its output path, rather than only writing the files. This is useful for scripting or CI to discover where the generated `llms.txt`, full-context, sitemap, robots, search, and agent-readability artifacts were written.

Note: in bundle mode (`--bundle`), the website-only artifacts (`llms.txt`, `llms-full.txt`, search JSON, sitemap files, `robots.txt`, and `agent-readability.json`) are skipped, so those would not be produced for reporting.
