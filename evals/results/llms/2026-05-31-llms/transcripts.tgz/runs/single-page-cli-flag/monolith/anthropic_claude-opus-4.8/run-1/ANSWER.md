# What `leadtype generate --json` reports

According to the Leadtype docs (`/docs/reference/cli.md`), the `--json` flag for
`leadtype generate` makes the command print a JSON object containing the paths
to the generated artifacts.

## In website mode

When run in website mode, the JSON object includes paths for the following
generated artifacts:

- `llmsFullTxt` — the root `/llms-full.txt` full-context file
- `docsLlmsTxt` — the docs-scoped `/docs/llms.txt` map
- `llmsTxt` — the product-level `/llms.txt`
- `agentReadabilityJson` — `docs/agent-readability.json`
- `sitemapXml` — `docs/sitemap.xml`
- `sitemapMd` — `docs/sitemap.md`
- `robotsTxt` — `docs/robots.txt`
- `searchIndex` — `docs/search-index.json`
- `searchContent` — `docs/search-content.json`

In short, `--json` does not change what is generated; it reports a
machine-readable summary of where each generated artifact was written, which is
useful for scripting and CI.

## Note on bundle mode

`--json` is one of the important flags for `leadtype generate` alongside
`--src`, `--out`, `--base-url`, `--bundle`, `--enrich-git`, and `--strict`. The
artifact list above is the website-mode object. Bundle mode (`--bundle`) skips
the website-only artifacts (such as `llms.txt`, `llms-full.txt`, the search
JSON, sitemap files, `robots.txt`, and `agent-readability.json`) and instead
writes `AGENTS.md` plus `docs/*.md`.
