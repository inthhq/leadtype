# What `leadtype generate --json` Reports

When `leadtype generate --json` is enabled, the command prints a JSON object with paths for the generated artifacts.

## Website Mode Output

For website mode (the default), the JSON object includes the following paths:

- **llmsFullTxt**: Path to the full context file containing every generated markdown docs page
- **docsLlmsTxt**: Path to the docs-scoped `/docs/llms.txt` map for hosted websites
- **llmsTxt**: Path to the product-level `/llms.txt` file
- **agentReadabilityJson**: Path to the agent readability metadata file
- **sitemapXml**: Path to the XML sitemap file
- **sitemapMd**: Path to the markdown sitemap file
- **robotsTxt**: Path to the robots.txt file
- **searchIndex**: Path to the search index JSON file
- **searchContent**: Path to the search content JSON file

This JSON output allows build systems to programmatically discover the paths of all generated artifacts, making it easy to integrate Leadtype into CI/CD pipelines and automate deployment of the generated files.
