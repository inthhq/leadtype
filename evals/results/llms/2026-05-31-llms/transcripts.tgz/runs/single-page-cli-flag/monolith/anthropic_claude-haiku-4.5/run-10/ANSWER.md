# What `leadtype generate --json` Reports

According to the Leadtype docs, when the `--json` flag is enabled with `leadtype generate`, it prints a JSON object containing paths for the generated artifacts.

## Website Mode Output

In website mode (the default), the `--json` output includes paths to the following generated artifacts:

- `llmsFullTxt` - The full context file containing every generated markdown docs page
- `docsLlmsTxt` - The docs-scoped llms.txt map for hosted websites
- `llmsTxt` - The product-level llms.txt file
- `agentReadabilityJson` - Agent readability metadata
- `sitemapXml` - XML sitemap file
- `sitemapMd` - Markdown sitemap file
- `robotsTxt` - Robots.txt file for search engine crawling
- `searchIndex` - Search index JSON file
- `searchContent` - Search content JSON file

## Bundle Mode

When using `--bundle` mode (for npm packages), the `--json` output would contain different artifact paths, as bundle mode skips website-only artifacts like llms.txt, llms-full.txt, search JSON, sitemap files, robots.txt, and agent-readability.json.

The JSON output allows downstream build tools and scripts to programmatically discover the location of generated artifacts without parsing stdout or relying on hardcoded paths.
