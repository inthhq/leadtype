# What `leadtype generate --json` Reports

According to the Leadtype docs, when `--json` is enabled with the `leadtype generate` command, it prints a JSON object with paths for the generated artifacts.

## Website Mode

In website mode (the default), the JSON object includes the following artifact paths:

- `llmsFullTxt` - The full context file containing every generated markdown docs page
- `docsLlmsTxt` - The docs-scoped LLMs file
- `llmsTxt` - The product-level llms.txt file
- `agentReadabilityJson` - JSON metadata for agent readability
- `sitemapXml` - XML sitemap
- `sitemapMd` - Markdown sitemap
- `robotsTxt` - Robots.txt file
- `searchIndex` - Search index data
- `searchContent` - Search content data

This allows you to programmatically discover where all the generated agent-readable artifacts have been written by the build process.
