# What `leadtype generate --json` reports

According to the Leadtype docs ([CLI reference](/docs/reference/cli.md)), `leadtype generate` converts docs and writes agent-readable artifacts. The `--json` flag changes its output behavior:

> When `--json` is enabled, `generate` prints a JSON object with paths for the generated artifacts.

## What's in the JSON object (website mode)

In website mode, the printed JSON object includes paths for the following generated artifacts:

- `llmsFullTxt` — the root `/llms-full.txt` full-context file
- `docsLlmsTxt` — the docs-scoped `/docs/llms.txt` map
- `llmsTxt` — the product-level `/llms.txt`
- `agentReadabilityJson` — `docs/agent-readability.json`
- `sitemapXml` — `docs/sitemap.xml`
- `sitemapMd` — `docs/sitemap.md`
- `robotsTxt` — `docs/robots.txt`
- `searchIndex` — the search index JSON (`docs/search-index.json`)
- `searchContent` — the search content JSON (`docs/search-content.json`)

## Summary

`leadtype generate --json` does not change *what* is built; it makes the command emit a machine-readable JSON object listing the **file paths of the generated artifacts**, so that scripts and CI pipelines can locate the output (the `llms.txt`/`llms-full.txt` files, sitemap files, robots.txt, the agent-readability JSON, and the search index/content JSON) without hardcoding paths.

> Note: Bundle mode (`leadtype generate --bundle`) skips the website-only artifacts (llms.txt, llms-full.txt, search JSON, sitemap files, robots.txt, and agent-readability.json), so the JSON object above describes the website-mode build.
