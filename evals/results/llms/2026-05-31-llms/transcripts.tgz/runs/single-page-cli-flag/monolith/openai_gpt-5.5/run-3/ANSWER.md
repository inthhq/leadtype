# `leadtype generate --json`

According to the Leadtype CLI docs, `leadtype generate` converts docs and writes agent-readable artifacts. When the `--json` flag is enabled, it prints a JSON object reporting the paths of the artifacts that were generated.

In website mode, that JSON object includes paths for:

- `llmsFullTxt`
- `docsLlmsTxt`
- `llmsTxt`
- `agentReadabilityJson`
- `sitemapXml`
- `sitemapMd`
- `robotsTxt`
- `searchIndex`
- `searchContent`

So `leadtype generate --json` is mainly a machine-readable summary of where Leadtype wrote its generated documentation artifacts.