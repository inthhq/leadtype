# What `leadtype generate --json` Reports

According to the Leadtype docs site, when the `--json` flag is enabled with the `leadtype generate` command, it prints a JSON object containing paths for the generated artifacts.

## Website Mode Output

In website mode (the default), the `--json` flag outputs a JSON object that includes the following paths:

- **llmsFullTxt** - Path to the full context file containing all generated markdown docs pages
- **docsLlmsTxt** - Path to the docs-scoped LLM file
- **llmsTxt** - Path to the product-level LLM file
- **agentReadabilityJson** - Path to the agent readability metadata file
- **sitemapXml** - Path to the XML sitemap
- **sitemapMd** - Path to the markdown sitemap
- **robotsTxt** - Path to the robots.txt file
- **searchIndex** - Path to the search index file
- **searchContent** - Path to the search content file

This JSON output is useful for automation and integration with CI/CD pipelines, as it provides structured information about where all the generated artifacts are located after the build completes.
