# What `leadtype generate --json` reports

According to the Leadtype CLI docs, `leadtype generate` converts docs and writes agent-readable artifacts. When the `--json` flag is enabled, it prints a JSON object reporting the paths of the artifacts it generated.

In website mode, that JSON object includes paths for:

- `llmsFullTxt` — the root `/llms-full.txt` full-context file containing all generated markdown docs pages
- `docsLlmsTxt` — the docs-scoped `/docs/llms.txt` map
- `llmsTxt` — the product-level `/llms.txt` entry file
- `agentReadabilityJson` — the `agent-readability.json` artifact
- `sitemapXml` — the XML sitemap
- `sitemapMd` — the markdown sitemap
- `robotsTxt` — the robots.txt artifact
- `searchIndex` — the generated search index JSON
- `searchContent` — the generated search content JSON

So, `leadtype generate --json` is mainly a machine-readable summary of the generated output paths. In bundle mode, Leadtype writes package-oriented docs such as `AGENTS.md` and `docs/*.md` and skips website-only artifacts like `llms.txt`, `llms-full.txt`, search JSON, sitemap files, robots.txt, and `agent-readability.json`.