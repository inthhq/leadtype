`leadtype generate --json` makes `leadtype generate` print a JSON object describing the paths of the artifacts it generated.

In website mode, the JSON object includes paths for:

- `llmsFullTxt`
- `docsLlmsTxt`
- `llmsTxt`
- `agentReadabilityJson`
- `sitemapXml`
- `sitemapMd`
- `robotsTxt`
- `searchIndex`
- `searchContent`

In other words, it is a machine-readable report of the generated agent-readable docs, sitemap/robots files, readability metadata, and search artifacts.