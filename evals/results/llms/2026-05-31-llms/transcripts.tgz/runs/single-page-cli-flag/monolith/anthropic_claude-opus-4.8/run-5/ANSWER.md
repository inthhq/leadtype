# What `leadtype generate --json` reports

Per the Leadtype CLI reference (`/docs/reference/cli.md`), `leadtype generate` converts docs and writes agent-readable artifacts. When the `--json` flag is enabled, `generate` **prints a JSON object containing the paths to the generated artifacts**.

## Website-mode JSON output

In website mode, the JSON object includes the following path fields:

- `llmsFullTxt` — path to the root `/llms-full.txt` (all docs flattened into one file)
- `docsLlmsTxt` — path to the docs-scoped `/docs/llms.txt` map
- `llmsTxt` — path to the product-level `/llms.txt`
- `agentReadabilityJson` — path to `docs/agent-readability.json`
- `sitemapXml` — path to `docs/sitemap.xml`
- `sitemapMd` — path to `docs/sitemap.md`
- `robotsTxt` — path to `docs/robots.txt`
- `searchIndex` — path to `docs/search-index.json`
- `searchContent` — path to `docs/search-content.json`

## Summary

`--json` makes `generate` emit a machine-readable summary of *where* it wrote each
output artifact, rather than just running silently. This is useful for build
pipelines and tooling that need to locate the generated files programmatically.

Note that bundle mode (`--bundle`) skips website-only artifacts (such as
`llms.txt`, `llms-full.txt`, search JSON, sitemap files, robots.txt, and
agent-readability.json), so the reported paths reflect the active generation
mode.
