# What `leadtype generate --json` reports

According to the Leadtype docs site ([CLI reference](/docs/reference/cli.md)),
`leadtype generate` converts docs and writes agent-readable artifacts. The
`--json` flag changes its output: instead of human-readable status, **`generate`
prints a JSON object containing the paths of the generated artifacts**.

## The website-mode JSON object

In website mode, the JSON object includes paths keyed by the following fields:

- `llmsFullTxt` — path to the root `/llms-full.txt` (every generated markdown
  docs page flattened into one file)
- `docsLlmsTxt` — path to the docs-scoped `/docs/llms.txt` map
- `llmsTxt` — path to the product-level `/llms.txt`
- `agentReadabilityJson` — path to `docs/agent-readability.json`
- `sitemapXml` — path to `docs/sitemap.xml`
- `sitemapMd` — path to `docs/sitemap.md`
- `robotsTxt` — path to `docs/robots.txt`
- `searchIndex` — path to the search index JSON (`docs/search-index.json`)
- `searchContent` — path to the search content JSON (`docs/search-content.json`)

## Notes

- These are the artifacts produced by **website mode**. Bundle mode
  (`leadtype generate --bundle`) skips website-only artifacts such as
  `llms.txt`, `llms-full.txt`, search JSON, sitemap files, `robots.txt`, and
  `agent-readability.json`, so the reported paths differ accordingly.
- In short, `--json` is a machine-readable output mode that reports *where* each
  generated artifact was written, which is useful for scripting and CI.
