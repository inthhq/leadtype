# What `leadtype generate --json` Reports

When `--json` is enabled, the `leadtype generate` command prints a JSON object containing paths for the generated artifacts.

## Website Mode Output

In website mode (default), the JSON object includes the following artifact paths:

- `llmsFullTxt` - Path to the root `/llms-full.txt` file containing every generated markdown docs page
- `docsLlmsTxt` - Path to the docs-scoped `/docs/llms.txt` file for hosted websites
- `llmsTxt` - Path to the product-level `/llms.txt` file
- `agentReadabilityJson` - Path to the agent-readability.json file
- `sitemapXml` - Path to the sitemap.xml file
- `sitemapMd` - Path to the sitemap.md file
- `robotsTxt` - Path to the robots.txt file
- `searchIndex` - Path to the search index JSON file
- `searchContent` - Path to the search content JSON file

This JSON output allows build systems and automation tools to programmatically discover and use the generated artifact paths without having to hardcode or guess where files are written.
