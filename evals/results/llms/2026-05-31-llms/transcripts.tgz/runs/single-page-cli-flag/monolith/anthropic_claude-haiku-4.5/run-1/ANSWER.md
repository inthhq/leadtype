# What `leadtype generate --json` Reports

When `--json` is enabled, the `leadtype generate` command prints a JSON object with paths for the generated artifacts.

## Website Mode Output

For website mode, the JSON object includes the following paths:

- **llmsFullTxt** - Path to the full context file containing every generated markdown docs page
- **docsLlmsTxt** - Path to the docs-scoped LLM map file
- **llmsTxt** - Path to the product-level LLM file
- **agentReadabilityJson** - Path to the agent readability metadata file
- **sitemapXml** - Path to the XML sitemap
- **sitemapMd** - Path to the markdown sitemap
- **robotsTxt** - Path to the robots.txt file
- **searchIndex** - Path to the search index JSON file
- **searchContent** - Path to the search content JSON file

This JSON output makes it easy for build systems and CI/CD pipelines to programmatically discover the paths to all generated artifacts.
