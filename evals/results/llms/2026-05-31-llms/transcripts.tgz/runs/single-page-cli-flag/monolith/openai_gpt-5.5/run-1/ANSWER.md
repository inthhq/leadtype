# `leadtype generate --json`

According to the Leadtype CLI docs, `leadtype generate` converts docs and writes agent-readable artifacts. When the `--json` flag is enabled, it prints a JSON object reporting the paths of the generated artifacts.

In website mode, that JSON object includes paths for:

- `llmsFullTxt`
- `docsLlmsTxt`
- `llmsTxt`
- `agentReadabilityJson`
- `sitemapXml`
- `sitemapMd`
- `robotsTxt`
- `searchIndex`
- `searchContent`

These correspond to artifacts such as `/llms.txt`, `/docs/llms.txt`, `/llms-full.txt`, sitemap files, `robots.txt`, search JSON files, and `agent-readability.json`.