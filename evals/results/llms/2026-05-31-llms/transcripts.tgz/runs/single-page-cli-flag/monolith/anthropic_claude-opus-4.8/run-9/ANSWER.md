# What `leadtype generate --json` reports

According to the Leadtype docs site ([CLI reference](/docs/reference/cli.md)), `leadtype generate` converts docs and writes agent-readable artifacts. The `--json` flag controls the command's output format.

## Summary

When `--json` is enabled, `generate` prints a **JSON object containing paths to the generated artifacts**. In other words, it reports *where* each artifact was written, rather than just running silently or printing human-readable log text.

## What the JSON object contains (website mode)

The website-mode JSON object includes paths for the following artifacts:

- `llmsFullTxt` — the root `/llms-full.txt` file (all generated markdown flattened into one file)
- `docsLlmsTxt` — the docs-scoped `/docs/llms.txt` map
- `llmsTxt` — the product-level `/llms.txt`
- `agentReadabilityJson` — `docs/agent-readability.json`
- `sitemapXml` — `docs/sitemap.xml`
- `sitemapMd` — `docs/sitemap.md`
- `robotsTxt` — `docs/robots.txt`
- `searchIndex` — `docs/search-index.json`
- `searchContent` — `docs/search-content.json`

## Note on bundle mode

The artifact set above corresponds to website mode. If you instead run in bundle mode (`leadtype generate --bundle`, used for publishing npm packages), the website-only artifacts are skipped — `llms.txt`, `llms-full.txt`, search JSON, sitemap files, `robots.txt`, and `agent-readability.json` are not produced — so those paths would not be part of the reported output. Bundle mode writes `AGENTS.md` and `docs/*.md` instead.
