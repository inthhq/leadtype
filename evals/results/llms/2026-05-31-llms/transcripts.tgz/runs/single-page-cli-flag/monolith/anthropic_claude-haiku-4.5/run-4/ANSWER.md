# What `leadtype generate --json` Reports

When `--json` is enabled, the `leadtype generate` command prints a JSON object with paths for the generated artifacts.

## Website Mode Output

For website mode, the JSON object includes the following paths:

- **llmsFullTxt** - The root `/llms-full.txt` file containing every generated markdown docs page
- **docsLlmsTxt** - The docs-scoped `/docs/llms.txt` map for hosted websites
- **llmsTxt** - The product-level `/llms.txt` file
- **agentReadabilityJson** - The `agent-readability.json` file
- **sitemapXml** - The `docs/sitemap.xml` file
- **sitemapMd** - The `docs/sitemap.md` file
- **robotsTxt** - The `docs/robots.txt` file
- **searchIndex** - The `docs/search-index.json` file
- **searchContent** - The `docs/search-content.json` file

This JSON output provides a convenient way to programmatically access the paths to all generated artifacts after running the build.
