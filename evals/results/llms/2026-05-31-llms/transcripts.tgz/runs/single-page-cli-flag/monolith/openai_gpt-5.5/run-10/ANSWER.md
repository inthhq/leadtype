`leadtype generate --json` runs `leadtype generate` and prints its result as a JSON object instead of only normal console output. According to the Leadtype CLI docs, the JSON object reports paths for the generated artifacts.

In website mode, that object includes paths for:

- `llmsFullTxt` — the root `/llms-full.txt` full-context file
- `docsLlmsTxt` — the docs-scoped `/docs/llms.txt`
- `llmsTxt` — the root `/llms.txt`
- `agentReadabilityJson` — `agent-readability.json`
- `sitemapXml` — the XML sitemap
- `sitemapMd` — the markdown sitemap
- `robotsTxt` — `robots.txt`
- `searchIndex` — the generated search index JSON
- `searchContent` — the generated search content JSON

So, `--json` reports where Leadtype wrote the generated agent-readable, sitemap, robots, and search artifacts; it is a paths report, not the artifact contents themselves.
