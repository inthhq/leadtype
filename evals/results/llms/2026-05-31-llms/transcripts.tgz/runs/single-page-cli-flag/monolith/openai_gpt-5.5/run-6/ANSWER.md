`leadtype generate --json` makes `leadtype generate` print a JSON object instead of only human-readable output. The object reports the filesystem paths of the artifacts that were generated.

In website mode, the JSON object includes paths for:

- `llmsFullTxt` — the root `/llms-full.txt` full-context file
- `docsLlmsTxt` — the docs-scoped `/docs/llms.txt`
- `llmsTxt` — the root `/llms.txt`
- `agentReadabilityJson` — `agent-readability.json`
- `sitemapXml` — the XML sitemap
- `sitemapMd` — the markdown sitemap
- `robotsTxt` — `robots.txt`
- `searchIndex` — the generated search index JSON
- `searchContent` — the generated search content JSON

The docs describe this specifically for website mode. Bundle mode is different: it writes `AGENTS.md` and `docs/*.md` for npm packages and skips website-only artifacts such as `llms.txt`, `llms-full.txt`, search JSON, sitemap files, `robots.txt`, and `agent-readability.json`.