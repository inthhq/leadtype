# What `leadtype generate --json` Reports

When the `--json` flag is enabled, the `leadtype generate` command prints a JSON object containing paths for all the generated artifacts.

## Website Mode Output

In website mode (the default), the JSON object includes the following artifact paths:

- **llmsFullTxt** - Path to the full context file containing every generated markdown docs page
- **docsLlmsTxt** - Path to the docs-scoped LLM file for hosted websites
- **llmsTxt** - Path to the product-level LLM file
- **agentReadabilityJson** - Path to the agent readability metadata file
- **sitemapXml** - Path to the XML sitemap
- **sitemapMd** - Path to the markdown sitemap
- **robotsTxt** - Path to the robots.txt file
- **searchIndex** - Path to the search index file
- **searchContent** - Path to the search content file

These paths point to the generated artifacts that enable agent discovery and interaction with the documentation site.
