# What `leadtype generate --json` reports

According to the Leadtype docs ([CLI reference](/docs/reference/cli.md)), `leadtype generate` converts docs and writes agent-readable artifacts. The `--json` flag changes its output behavior:

> When `--json` is enabled, generate prints a JSON object with paths for the generated artifacts.

In other words, `--json` makes the command emit a machine-readable JSON object whose values are the file paths of the artifacts that were generated during the build.

## Fields reported in website mode

The docs specify that the website-mode JSON object includes paths for:

- `llmsFullTxt` — the root `/llms-full.txt` full-context file
- `docsLlmsTxt` — the docs-scoped `/docs/llms.txt` map
- `llmsTxt` — the product-level `/llms.txt`
- `agentReadabilityJson` — `docs/agent-readability.json`
- `sitemapXml` — `docs/sitemap.xml`
- `sitemapMd` — `docs/sitemap.md`
- `robotsTxt` — `docs/robots.txt`
- `searchIndex` — the search index JSON (`docs/search-index.json`)
- `searchContent` — the search content JSON (`docs/search-content.json`)

## Notes

- These reported artifacts correspond to the website-mode outputs. In **bundle mode** (`leadtype generate --bundle`), the website-only artifacts (`llms.txt`, `llms-full.txt`, search JSON, sitemap files, `robots.txt`, and `agent-readability.json`) are skipped, so a `--json` report in bundle mode would not include those website-only paths.
- The purpose of `--json` is primarily to give tooling and CI a structured list of where each generated file landed, rather than relying on human-readable console output.
