# What `leadtype generate --json` reports

According to the Leadtype CLI docs, `leadtype generate --json` runs `leadtype generate` and prints a JSON object describing the paths of the artifacts it generated.

In website mode, that JSON object includes paths for:

- `llmsFullTxt` — the root `/llms-full.txt` full-context file
- `docsLlmsTxt` — the docs-scoped `/docs/llms.txt` map
- `llmsTxt` — the product-level `/llms.txt` entrypoint
- `agentReadabilityJson` — `agent-readability.json`
- `sitemapXml` — the XML sitemap
- `sitemapMd` — the Markdown sitemap
- `robotsTxt` — `robots.txt`
- `searchIndex` — the generated search index JSON
- `searchContent` — the generated search content JSON

So, `--json` is mainly a machine-readable reporting option: instead of only writing files, it also outputs where the generated Leadtype artifacts were written.