# What `leadtype generate --json` Reports

When the `--json` flag is enabled with `leadtype generate`, the command prints a JSON object containing paths for the generated artifacts.

## Website Mode Output

In website mode (the default), the `--json` output includes the following artifact paths:

- **llmsFullTxt** - Path to the full context file containing all generated markdown pages
- **docsLlmsTxt** - Path to the docs-scoped llms.txt map
- **llmsTxt** - Path to the product-level llms.txt file
- **agentReadabilityJson** - Path to the agent readability metadata file
- **sitemapXml** - Path to the XML sitemap
- **sitemapMd** - Path to the markdown sitemap
- **robotsTxt** - Path to robots.txt
- **searchIndex** - Path to the search index JSON file
- **searchContent** - Path to the search content JSON file

This JSON output allows tools and scripts to programmatically discover the locations of all generated artifacts after a build completes.
