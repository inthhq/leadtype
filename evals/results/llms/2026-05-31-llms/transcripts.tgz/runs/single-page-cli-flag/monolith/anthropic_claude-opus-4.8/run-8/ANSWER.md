# What `leadtype generate --json` reports

According to the Leadtype docs ([CLI reference](/docs/reference/cli.md)), `leadtype generate`
converts docs and writes agent-readable artifacts. The `--json` flag changes its output behavior:

> When `--json` is enabled, `generate` prints a JSON object with paths for the generated artifacts.

In other words, instead of (or in addition to) producing the files, it emits a machine-readable
JSON object whose values are the file paths of the artifacts that were generated. This is useful
for scripting and CI pipelines that need to know exactly where each output file was written.

## Fields in the website-mode JSON object

In website mode, the printed JSON object includes the following keys, each pointing to a generated
artifact path:

- `llmsFullTxt` — the root `/llms-full.txt` (all generated markdown flattened into one file)
- `docsLlmsTxt` — the docs-scoped `/docs/llms.txt` map
- `llmsTxt` — the product-level `/llms.txt`
- `agentReadabilityJson` — `docs/agent-readability.json`
- `sitemapXml` — `docs/sitemap.xml`
- `sitemapMd` — `docs/sitemap.md`
- `robotsTxt` — `docs/robots.txt`
- `searchIndex` — `docs/search-index.json`
- `searchContent` — `docs/search-content.json`

## Notes

- These reported paths correspond to the website-mode artifacts. Bundle mode
  (`leadtype generate --bundle`) skips the website-only artifacts (llms.txt, llms-full.txt,
  search JSON, sitemap files, robots.txt, and agent-readability.json), so the JSON report's
  website-mode fields apply to website builds.
- `--json` is one of the important flags for `generate`, alongside `--src`, `--out`,
  `--base-url`, `--bundle`, `--enrich-git`, and `--strict`.

Source: [CLI](/docs/reference/cli.md), with supporting detail from
[Quickstart](/docs/quickstart.md) and [LLM files](/docs/reference/llm.md).
