# What `leadtype generate --json` reports

According to the Leadtype docs ([CLI reference](/docs/reference/cli.md)), `leadtype generate` converts docs and writes agent-readable artifacts. The `--json` flag changes its output behavior:

> When `--json` is enabled, `generate` prints a JSON object with paths for the generated artifacts.

In **website mode**, the printed JSON object includes the following keys, each pointing to the path of a generated artifact:

- `llmsFullTxt` — the root `/llms-full.txt` file (every generated markdown page flattened into one file)
- `docsLlmsTxt` — the docs-scoped `/docs/llms.txt` map
- `llmsTxt` — the product-level `/llms.txt`
- `agentReadabilityJson` — `docs/agent-readability.json`
- `sitemapXml` — `docs/sitemap.xml`
- `sitemapMd` — `docs/sitemap.md`
- `robotsTxt` — `docs/robots.txt`
- `searchIndex` — `docs/search-index.json`
- `searchContent` — `docs/search-content.json`

## Summary

`--json` makes `leadtype generate` emit a machine-readable JSON object that maps the names of the generated artifacts to their output paths, so a build pipeline or agent can locate the produced files programmatically. In website mode, that object reports the locations of the llms files (`llmsTxt`, `docsLlmsTxt`, `llmsFullTxt`), the agent-readability JSON, the sitemap files (XML and Markdown), the robots.txt, and the search JSON files (`searchIndex` and `searchContent`).

> Note: Bundle mode (`--bundle`) skips website-only artifacts such as llms.txt, llms-full.txt, search JSON, sitemap files, robots.txt, and agent-readability.json, so the website-mode keys above describe the standard (non-bundle) `--json` output.
