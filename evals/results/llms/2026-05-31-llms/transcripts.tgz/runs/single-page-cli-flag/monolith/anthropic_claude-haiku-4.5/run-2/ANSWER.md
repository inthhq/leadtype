# What `leadtype generate --json` Reports

According to the Leadtype documentation, when the `--json` flag is enabled with `leadtype generate`, it prints a JSON object containing paths for the generated artifacts.

For **website mode** (the default), the JSON object includes the following artifact paths:

- `llmsFullTxt` - The root full-context file containing all generated markdown docs pages
- `docsLlmsTxt` - The docs-scoped LLM map for the hosted website
- `llmsTxt` - The product-level LLM file at the root
- `agentReadabilityJson` - Agent readability metadata
- `sitemapXml` - XML sitemap
- `sitemapMd` - Markdown sitemap
- `robotsTxt` - Robots.txt file
- `searchIndex` - Search index JSON
- `searchContent` - Search content JSON

This JSON output allows build systems and tools to programmatically access information about where each generated artifact was written.
