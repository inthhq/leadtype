# What `leadtype generate --json` Reports

According to the Leadtype docs, when the `--json` flag is enabled with the `leadtype generate` command, it prints a JSON object with paths for the generated artifacts.

## Reported Artifact Paths

The website-mode object includes the following paths for generated artifacts:

- **llmsFullTxt**: The full-context fallback file
- **docsLlmsTxt**: Documentation-specific LLM file
- **llmsTxt**: Root LLM file
- **agentReadabilityJson**: Agent readability metrics in JSON format
- **sitemapXml**: XML sitemap
- **sitemapMd**: Markdown sitemap
- **robotsTxt**: Robots.txt file
- **searchIndex**: Search index data
- **searchContent**: Search content data

These paths allow users and agents to easily locate and reference the various generated artifacts that Leadtype produces from the MDX documentation source.
