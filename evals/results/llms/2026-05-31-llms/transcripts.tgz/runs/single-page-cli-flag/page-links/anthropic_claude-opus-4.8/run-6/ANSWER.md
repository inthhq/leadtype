# What `leadtype generate --json` reports

When you run `leadtype generate` with the `--json` flag, the command prints a
**JSON object containing the file paths of the generated artifacts**. Instead of
just writing files to disk, it emits a machine-readable summary of where each
artifact landed, which is useful for scripting and CI.

## The website-mode JSON object

In website mode, the JSON object includes the following keys, each pointing to a
generated artifact:

| Key | Artifact it points to |
|---|---|
| `llmsFullTxt` | `/llms-full.txt` — a single root file containing every generated markdown docs page (full-context fallback for agents). |
| `docsLlmsTxt` | `/docs/llms.txt` — the docs-scoped map of pages. |
| `llmsTxt` | `/llms.txt` — the product-level index/map. |
| `agentReadabilityJson` | `docs/agent-readability.json` — agent-readability metadata. |
| `sitemapXml` | `docs/sitemap.xml` — the XML sitemap. |
| `sitemapMd` | `docs/sitemap.md` — the markdown sitemap. |
| `robotsTxt` | `docs/robots.txt` — the robots file. |
| `searchIndex` | `docs/search-index.json` — the static local search index (lexical BM25-style ranking). |
| `searchContent` | `docs/search-content.json` — the search content backing the index. |

## Notes

- `--json` reports **paths**, not the contents, of the generated files. It is a
  summary of what `generate` produced.
- The set of keys above is for **website mode**. Bundle mode (`leadtype generate
  --bundle`) is a different output that writes `AGENTS.md` and `docs/*.md` for
  npm packages, so its reporting differs.
- These artifacts are the same ones `generate` normally writes (`/llms.txt`,
  `/docs/llms.txt`, `/llms-full.txt`, the markdown mirrors, the sitemaps,
  `robots.txt`, `agent-readability.json`, and the two search JSON files);
  `--json` simply makes their locations available as structured output.

## Source

- [CLI reference](/docs/reference/cli.md)
- [Quickstart](/docs/quickstart.md)
- [LLM files reference](/docs/reference/llm.md)
- [Search reference](/docs/reference/search.md)
