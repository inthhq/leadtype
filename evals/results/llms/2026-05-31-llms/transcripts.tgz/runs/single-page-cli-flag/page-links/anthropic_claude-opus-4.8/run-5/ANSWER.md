# What `leadtype generate --json` reports

When you run `leadtype generate` with the `--json` flag enabled, the command prints
a **JSON object containing the file paths of the generated artifacts** instead of
just running silently. This lets a build script or CI step machine-read where each
output landed.

## Website-mode output

In website mode, the JSON object includes paths for the following generated
artifacts:

| Key | Artifact |
| --- | --- |
| `llmsFullTxt` | The root `/llms-full.txt` full-context file containing every generated markdown docs page. |
| `docsLlmsTxt` | The docs-scoped `/docs/llms.txt` map. |
| `llmsTxt` | The product-level `/llms.txt` entry point that HTTP agents start from. |
| `agentReadabilityJson` | The `agent-readability.json` artifact. |
| `sitemapXml` | The XML sitemap. |
| `sitemapMd` | The markdown sitemap. |
| `robotsTxt` | The `robots.txt` file. |
| `searchIndex` | The static search index. |
| `searchContent` | The search content used for source-grounded answers. |

## Why it's useful

`leadtype generate` is the command that converts the MDX docs and writes the
agent-readable artifacts (such as `llms.txt`, `llms-full.txt`, sitemaps,
`robots.txt`, and the search files). The `--json` output reports the resolved
paths to each of these artifacts as a single JSON object, so downstream tooling
can locate, verify, or deploy them programmatically.

## Source

- `/docs/reference/cli.md` — documents `leadtype generate`, its flags (including
  `--json`), and the website-mode JSON object keys.
- `/docs/reference/llm.md` — describes the `llms.txt`, `llms-full.txt`, and
  related artifacts that the JSON output references.
