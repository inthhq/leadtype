# What `leadtype generate --json` reports

When `--json` is enabled, `leadtype generate` prints a **JSON object listing the file paths of the generated artifacts** instead of (or alongside) plain console output. It is a machine-readable report of where each output file was written, which is useful for scripting and CI pipelines.

In **website mode**, the JSON object includes the following keys, each pointing at a generated artifact:

| JSON key | Artifact it points to | What it is |
| --- | --- | --- |
| `llmsFullTxt` | `/llms-full.txt` | One root full-context file containing every generated markdown docs page (the full-context fallback). |
| `docsLlmsTxt` | `/docs/llms.txt` | The docs-scoped map of the documentation. |
| `llmsTxt` | `/llms.txt` | The product-level entry point / index for agents. |
| `agentReadabilityJson` | `docs/agent-readability.json` | Agent-readability metadata describing artifact paths. |
| `sitemapXml` | `docs/sitemap.xml` | XML sitemap. |
| `sitemapMd` | `docs/sitemap.md` | Markdown sitemap. |
| `robotsTxt` | `docs/robots.txt` | robots.txt for the hosted site. |
| `searchIndex` | `docs/search-index.json` | The static, edge-safe local search index (BM25-style lexical ranking over titles, headings, body, and code). |
| `searchContent` | `docs/search-content.json` | The search content payload that backs the index / source-grounded answers. |

## Notes

- The exact object shown above is the **website-mode** object. Website mode is the default path where Leadtype writes `/llms.txt`, `/docs/llms.txt`, `/llms-full.txt`, the markdown mirrors under `/docs/*.md`, the sitemaps, `robots.txt`, `agent-readability.json`, and the two search JSON files.
- **Bundle mode** (`--bundle`) is different — it writes `AGENTS.md` and `docs/*.md` for npm packages with relative links, so the `--json` report reflects a different set of artifacts in that mode.
- In short: `--json` gives you a structured manifest of the generated artifact paths so tools and automation can locate each output rather than parsing human-readable log text.

## Source

- `/docs/reference/cli.md` (the `--json` output description)
- `/docs/quickstart.md` (the full list of website-mode artifacts)
- `/docs/reference/llm.md` (definitions of the llms.txt / llms-full.txt / agent-readability artifacts)
- `/docs/reference/search.md` (the search index and search content artifacts)
