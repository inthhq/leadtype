# What `leadtype generate --json` reports

When you run `leadtype generate` with the `--json` flag, the command prints a
JSON object describing the **paths of the generated artifacts**. This makes the
generator's output machine-readable so it can be consumed by build scripts,
CI pipelines, or other tooling.

## The website-mode JSON object

In website mode, the printed JSON object includes the following keys, each
pointing to a generated artifact:

| Key | Artifact it points to |
| --- | --- |
| `llmsFullTxt` | The root `/llms-full.txt` full-context file containing every generated markdown docs page |
| `docsLlmsTxt` | The docs-scoped `/docs/llms.txt` map |
| `llmsTxt` | The product-level `/llms.txt` |
| `agentReadabilityJson` | `docs/agent-readability.json` |
| `sitemapXml` | `docs/sitemap.xml` |
| `sitemapMd` | `docs/sitemap.md` |
| `robotsTxt` | `docs/robots.txt` |
| `searchIndex` | `docs/search-index.json` (the static search index) |
| `searchContent` | `docs/search-content.json` |

## Context

`leadtype generate` converts MDX docs and writes agent-readable artifacts. Its
notable flags include `--src`, `--out`, `--base-url`, `--bundle`, `--json`,
`--enrich-git`, and `--strict`. The `--json` flag specifically controls the
output **format** of the command's report: instead of human-readable text, it
emits the JSON object above listing where each generated file was written.

In website mode the generator produces `/llms.txt`, `/docs/llms.txt`,
`/llms-full.txt`, markdown mirrors under `/docs/*.md`, the sitemap files,
`robots.txt`, the agent-readability JSON, and the search index/content JSON —
and the `--json` output reports the paths to these artifacts.

> Note: This JSON object describes the website-mode artifacts. Bundle mode
> (`--bundle`) produces a different set of outputs (`AGENTS.md` and `docs/*.md`
> for npm packages with relative links).
