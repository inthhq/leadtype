`leadtype generate --json` prints a JSON object describing the files Leadtype generated.

According to the CLI reference, in website mode the JSON object reports paths for these generated artifacts:

- `llmsFullTxt`
- `docsLlmsTxt`
- `llmsTxt`
- `agentReadabilityJson`
- `sitemapXml`
- `sitemapMd`
- `robotsTxt`
- `searchIndex`
- `searchContent`
