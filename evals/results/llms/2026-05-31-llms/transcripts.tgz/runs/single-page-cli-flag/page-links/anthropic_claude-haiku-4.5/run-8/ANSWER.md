# What `leadtype generate --json` Reports

According to the Leadtype docs, when the `--json` flag is enabled, `leadtype generate --json` prints a JSON object containing paths for the generated artifacts.

The JSON output includes the following fields:

- **llmsFullTxt**: Full LLM context file
- **docsLlmsTxt**: Documentation-specific LLMs file
- **llmsTxt**: The root full-context fallback LLMs file
- **agentReadabilityJson**: Agent-readable JSON output
- **sitemapXml**: XML sitemap
- **sitemapMd**: Markdown sitemap
- **robotsTxt**: Robots.txt file
- **searchIndex**: Search index file
- **searchContent**: Search content file

This JSON output provides programmatic access to all the generated artifacts that the Leadtype pipeline creates from MDX sources for websites, agents, and search.
