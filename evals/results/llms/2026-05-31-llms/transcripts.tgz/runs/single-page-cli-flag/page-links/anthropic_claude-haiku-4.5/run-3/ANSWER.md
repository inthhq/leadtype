# What `leadtype generate --json` Reports

According to the Leadtype documentation, when the `--json` flag is enabled with `leadtype generate`, it prints a JSON object containing paths for the generated artifacts.

The JSON output includes the following fields in website-mode:

- `llmsFullTxt` - The full-context fallback file
- `docsLlmsTxt` - Documentation-specific LLM file
- `llmsTxt` - The root LLM file
- `agentReadabilityJson` - Agent-readable JSON artifacts
- `sitemapXml` - XML sitemap for search engines
- `sitemapMd` - Markdown sitemap
- `robotsTxt` - Robots.txt file for crawlers
- `searchIndex` - Static search index
- `searchContent` - Search content data

This JSON output makes it easy for build pipelines and automation to reference the exact paths of all generated artifacts.
