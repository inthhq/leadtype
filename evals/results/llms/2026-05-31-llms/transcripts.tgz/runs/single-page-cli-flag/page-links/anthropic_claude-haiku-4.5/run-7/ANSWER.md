# What `leadtype generate --json` Reports

When the `--json` flag is enabled with the `leadtype generate` command, it prints a JSON object containing paths for the generated artifacts.

The JSON output includes paths for the following website-mode artifacts:

- **llmsFullTxt** - The full context LLM file
- **docsLlmsTxt** - Docs-specific LLM file
- **llmsTxt** - The root LLM file
- **agentReadabilityJson** - Agent-readable JSON artifacts
- **sitemapXml** - XML sitemap
- **sitemapMd** - Markdown sitemap
- **robotsTxt** - Robots.txt file
- **searchIndex** - Search index
- **searchContent** - Search content

This JSON output allows programmatic access to the paths of all generated artifacts from the documentation build process.
