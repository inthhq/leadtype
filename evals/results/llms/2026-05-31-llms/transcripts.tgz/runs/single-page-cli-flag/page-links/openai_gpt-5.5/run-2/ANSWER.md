`leadtype generate --json` makes `leadtype generate` print a JSON object instead of only normal console output. The object reports the paths to the artifacts that were generated.

In website mode, the JSON object includes paths for:

- `llmsFullTxt`
- `docsLlmsTxt`
- `llmsTxt`
- `agentReadabilityJson`
- `sitemapXml`
- `sitemapMd`
- `robotsTxt`
- `searchIndex`
- `searchContent`

These correspond to the generated agent-readable files, sitemap and robots files, and static search artifacts.