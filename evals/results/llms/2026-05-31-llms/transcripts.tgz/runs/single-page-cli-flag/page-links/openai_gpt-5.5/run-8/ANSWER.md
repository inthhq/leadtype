`leadtype generate --json` prints a JSON object describing the files Leadtype generated.

In website mode, that object reports paths for these generated artifacts:

- `llmsFullTxt`
- `docsLlmsTxt`
- `llmsTxt`
- `agentReadabilityJson`
- `sitemapXml`
- `sitemapMd`
- `robotsTxt`
- `searchIndex`
- `searchContent`
