# What `leadtype generate --json` reports

`leadtype generate` converts docs and writes agent-readable artifacts. When the
`--json` flag is enabled, the command prints a **JSON object containing the file
paths of the generated artifacts** instead of (or in addition to) ordinary
output. This makes the result machine-readable, so CI pipelines and tooling can
locate every produced artifact.

## The website-mode JSON object

In website mode, the printed JSON object includes the following keys, each
pointing to a generated artifact path:

| Key | Artifact it points to | Purpose |
| --- | --- | --- |
| `llmsFullTxt` | `/llms-full.txt` | Root full-context file containing every generated markdown docs page. |
| `docsLlmsTxt` | `/docs/llms.txt` | The docs-scoped map for the hosted site. |
| `llmsTxt` | `/llms.txt` | The product-level llms.txt entry/map file. |
| `agentReadabilityJson` | `docs/agent-readability.json` | Agent-readability metadata artifact. |
| `sitemapXml` | `docs/sitemap.xml` | XML sitemap. |
| `sitemapMd` | `docs/sitemap.md` | Markdown sitemap. |
| `robotsTxt` | `docs/robots.txt` | robots.txt file. |
| `searchIndex` | `docs/search-index.json` | Static search index. |
| `searchContent` | `docs/search-content.json` | Search content data. |

## Notes

- `--json` reports *paths to artifacts*, not the artifact contents themselves.
- The set of keys above is specific to **website mode**. Website mode also
  produces markdown mirrors under `/docs/*.md`, while bundle mode
  (`leadtype generate --bundle`) instead writes `AGENTS.md` and `docs/*.md` for
  npm packages.
