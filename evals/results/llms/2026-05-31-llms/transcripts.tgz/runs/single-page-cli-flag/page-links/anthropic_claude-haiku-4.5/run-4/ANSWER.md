# What `leadtype generate --json` Reports

When the `--json` flag is enabled with the `leadtype generate` command, it prints a JSON object containing paths for all the generated artifacts.

## Generated Artifact Paths

The JSON output includes the following paths for:

- **llmsFullTxt** - Full context LLM file
- **docsLlmsTxt** - Docs-specific LLM file
- **llmsTxt** - Root LLM file
- **agentReadabilityJson** - Agent-readable JSON output
- **sitemapXml** - XML sitemap
- **sitemapMd** - Markdown sitemap
- **robotsTxt** - Robots.txt file
- **searchIndex** - Search index file
- **searchContent** - Search content file

This JSON output is useful for automation and CI/CD pipelines where you need to programmatically reference the paths of the generated artifacts for further processing or deployment.
