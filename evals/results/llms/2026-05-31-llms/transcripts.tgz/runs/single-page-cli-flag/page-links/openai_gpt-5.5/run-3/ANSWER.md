# What `leadtype generate --json` reports

`leadtype generate` converts the docs and writes agent-readable artifacts. When run with `--json`, it prints a JSON object that reports the paths of the generated artifacts rather than just human-oriented console output.

In website mode, the JSON object includes paths for:

- `llmsFullTxt` — the root `/llms-full.txt` full-context file containing all generated markdown docs pages.
- `docsLlmsTxt` — the docs-scoped `/docs/llms.txt` map.
- `llmsTxt` — the product-level root `/llms.txt` file.
- `agentReadabilityJson` — the agent readability metadata artifact.
- `sitemapXml` — the generated XML sitemap.
- `sitemapMd` — the generated markdown sitemap.
- `robotsTxt` — the generated robots.txt artifact.
- `searchIndex` — the generated static search index JSON.
- `searchContent` — the generated search content JSON.

So, `leadtype generate --json` is mainly a machine-readable report of where Leadtype wrote each generated website artifact.