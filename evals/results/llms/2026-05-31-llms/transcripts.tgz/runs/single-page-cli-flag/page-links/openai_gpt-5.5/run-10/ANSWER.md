`leadtype generate --json` makes `leadtype generate` print a JSON object instead of only normal CLI output. The object reports the file paths of the artifacts that the generator wrote.

In website mode, the reported paths include:

- `llmsFullTxt`
- `docsLlmsTxt`
- `llmsTxt`
- `agentReadabilityJson`
- `sitemapXml`
- `sitemapMd`
- `robotsTxt`
- `searchIndex`
- `searchContent`

So, `--json` is a machine-readable summary of the generated Leadtype website artifacts and where they were written.
