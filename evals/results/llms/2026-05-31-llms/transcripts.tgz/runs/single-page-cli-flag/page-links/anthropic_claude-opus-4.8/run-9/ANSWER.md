# What `leadtype generate --json` reports

When you run `leadtype generate` with the `--json` flag enabled, the command prints a **JSON object containing the paths of the generated artifacts** instead of (or in addition to) its normal output. This makes the generator's results machine-readable, which is useful for scripting and CI pipelines.

## Website mode output

In website mode, the JSON object reports the paths for the following generated artifacts:

| JSON key | Artifact it points to |
|---|---|
| `llmsFullTxt` | The root `/llms-full.txt` full-context file containing every generated markdown docs page |
| `docsLlmsTxt` | The docs-scoped `/docs/llms.txt` map |
| `llmsTxt` | The product-level `/llms.txt` |
| `agentReadabilityJson` | `docs/agent-readability.json` |
| `sitemapXml` | `docs/sitemap.xml` |
| `sitemapMd` | `docs/sitemap.md` |
| `robotsTxt` | `docs/robots.txt` |
| `searchIndex` | `docs/search-index.json` (the static search index) |
| `searchContent` | `docs/search-content.json` (search content) |

## In short

`leadtype generate --json` emits a JSON object whose fields are the file paths of the artifacts the generator produced. In website mode those fields are `llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, `agentReadabilityJson`, `sitemapXml`, `sitemapMd`, `robotsTxt`, `searchIndex`, and `searchContent` — letting tools discover exactly where each generated LLM file, sitemap, robots file, and search index was written.

> Note: `--json` reports *paths*, not the contents of the artifacts. The set of keys shown above corresponds to website-mode generation (the default). Bundle mode (`--bundle`) instead produces `AGENTS.md` and `docs/*.md` for npm packages.

## Sources

- [CLI reference](/docs/reference/cli.md)
- [Quickstart](/docs/quickstart.md)
- [LLM files reference](/docs/reference/llm.md)
