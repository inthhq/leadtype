# What `leadtype generate --json` reports

`leadtype generate` converts docs and writes agent-readable artifacts. When you
pass the `--json` flag, the command prints a **JSON object whose values are the
file paths of the generated artifacts**, so a build script or CI step can locate
exactly what was produced.

## The reported keys (website mode)

In website mode, the JSON object includes the following keys, each pointing to a
generated artifact:

| Key | Artifact it points to | What it is |
| --- | --- | --- |
| `llmsFullTxt` | `/llms-full.txt` | A single root file containing every generated markdown docs page (the full-context fallback). |
| `docsLlmsTxt` | `/docs/llms.txt` | The docs-scoped map of the documentation. |
| `llmsTxt` | `/llms.txt` | The product-level entry/index file. |
| `agentReadabilityJson` | `docs/agent-readability.json` | Metadata identifying agent-readability artifact paths. |
| `sitemapXml` | `docs/sitemap.xml` | XML sitemap. |
| `sitemapMd` | `docs/sitemap.md` | Markdown sitemap. |
| `robotsTxt` | `docs/robots.txt` | robots.txt for the hosted site. |
| `searchIndex` | `docs/search-index.json` | The static local search index (BM25-style lexical index over titles, headings, body, and code). |
| `searchContent` | `docs/search-content.json` | The search content data that backs the index and source-grounded answers. |

## In short

`--json` doesn't change *what* gets built — it changes *how the result is
reported*. Instead of (or alongside) normal output, `generate` emits a machine-
readable JSON object listing the paths to all generated artifacts: the LLM files
(`llmsTxt`, `docsLlmsTxt`, `llmsFullTxt`), the agent-readability manifest
(`agentReadabilityJson`), the sitemaps (`sitemapXml`, `sitemapMd`), `robotsTxt`,
and the search files (`searchIndex`, `searchContent`). This lets automated
pipelines reliably discover and consume the build outputs.
