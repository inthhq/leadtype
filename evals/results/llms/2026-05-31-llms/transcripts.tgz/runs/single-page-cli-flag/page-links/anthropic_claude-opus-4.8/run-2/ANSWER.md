# What `leadtype generate --json` reports

According to the Leadtype docs (`/docs/reference/cli.md`), `leadtype generate`
converts docs and writes agent-readable artifacts. When you add the `--json`
flag, `generate` **prints a JSON object whose values are the paths to the
generated artifacts**. This makes the output machine-readable so you can wire it
into build scripts and CI.

## Website-mode output

In the default website mode, the JSON object includes paths for the following
artifacts:

- `llmsFullTxt` — the root `/llms-full.txt` full-context file containing every generated markdown page.
- `docsLlmsTxt` — the docs-scoped `/docs/llms.txt` map.
- `llmsTxt` — the product-level `/llms.txt`.
- `agentReadabilityJson` — the `agent-readability.json` artifact.
- `sitemapXml` — the XML sitemap.
- `sitemapMd` — the markdown sitemap.
- `robotsTxt` — `robots.txt`.
- `searchIndex` — the static search index.
- `searchContent` — the search content JSON.

## Note on bundle mode

`--json` reports the paths of whatever artifacts were actually produced. If you
run `generate --bundle` (npm package mode), Leadtype writes `AGENTS.md` and
`docs/*.md` and **skips the website-only artifacts** — `llms.txt`,
`llms-full.txt`, search JSON, sitemap files, robots.txt, and
`agent-readability.json` — so those paths would not be part of a bundle-mode
build. The list above describes the website-mode JSON object as documented in
the CLI reference.

## Sources

- `/docs/reference/cli.md`
- `/docs/package-docs/bundle.md`
- `/docs/reference/llm.md`
