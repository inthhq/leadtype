# What `leadtype generate --json` Reports

According to the Leadtype docs, when the `--json` flag is enabled with the `leadtype generate` command, it prints a JSON object containing paths for the generated artifacts.

The JSON output includes the following artifact paths:

- **llmsFullTxt**: The full context fallback file
- **docsLlmsTxt**: Documentation-specific LLM file
- **llmsTxt**: The main llms.txt file
- **agentReadabilityJson**: Agent-readable metadata in JSON format
- **sitemapXml**: XML sitemap for search engines
- **sitemapMd**: Markdown sitemap
- **robotsTxt**: Robots.txt file for crawlers
- **searchIndex**: Static search index data
- **searchContent**: Search content bundle

This JSON output allows you to programmatically discover the locations of all generated artifacts from the `leadtype generate` command, making it easy to integrate Leadtype into automated build pipelines and CI/CD workflows.
