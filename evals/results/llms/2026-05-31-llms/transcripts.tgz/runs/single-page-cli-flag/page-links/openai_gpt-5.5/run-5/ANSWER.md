# What `leadtype generate --json` reports

`leadtype generate` converts docs and writes agent-readable artifacts. When you add `--json`, it prints a JSON object that reports the paths of the generated artifacts.

In website mode, the reported object includes paths for:

- `llmsFullTxt`
- `docsLlmsTxt`
- `llmsTxt`
- `agentReadabilityJson`
- `sitemapXml`
- `sitemapMd`
- `robotsTxt`
- `searchIndex`
- `searchContent`
