# What `leadtype generate --json` Reports

According to the Leadtype docs site, when the `--json` flag is enabled, the `leadtype generate` command prints a JSON object with paths for the generated artifacts.

The JSON output includes the following fields for website-mode generation:

- **llmsFullTxt** - Full context fallback file
- **docsLlmsTxt** - Docs-specific llms.txt
- **llmsTxt** - Root llms.txt file
- **agentReadabilityJson** - Agent-readable JSON output
- **sitemapXml** - XML sitemap
- **sitemapMd** - Markdown sitemap
- **robotsTxt** - robots.txt file
- **searchIndex** - Static search index
- **searchContent** - Search content data

This JSON output provides file paths for all the generated artifacts that result from the `leadtype generate` command when processing markdown documentation sources.
