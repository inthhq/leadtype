# What `leadtype generate --json` reports

When you run `leadtype generate` with the `--json` flag, the command prints a
JSON object containing the **paths to the generated artifacts**. Instead of just
running silently, the generator emits a machine-readable summary of what it
wrote, which is useful for scripting and CI pipelines.

## Website-mode output

In the default (website) mode, the JSON object includes paths for the following
generated artifacts:

| JSON key | Artifact it points to |
| --- | --- |
| `llmsFullTxt` | The root `/llms-full.txt` full-context file (every generated markdown docs page) |
| `docsLlmsTxt` | The docs-scoped `/docs/llms.txt` map |
| `llmsTxt` | The product-level `/llms.txt` |
| `agentReadabilityJson` | `docs/agent-readability.json` |
| `sitemapXml` | `docs/sitemap.xml` |
| `sitemapMd` | `docs/sitemap.md` |
| `robotsTxt` | `docs/robots.txt` |
| `searchIndex` | `docs/search-index.json` |
| `searchContent` | `docs/search-content.json` |

These correspond to the website-mode outputs that `leadtype generate` writes:
`/llms.txt`, `/docs/llms.txt`, `/llms-full.txt`, the markdown mirrors under
`/docs/*.md`, the sitemap files, `robots.txt`, the agent-readability JSON, and
the two search JSON files.

## A note on bundle mode

The reported paths reflect what is actually generated, and that depends on the
mode. Bundle mode (`leadtype generate --bundle`) is different: it writes
`AGENTS.md` and `docs/*.md` for npm packages and **skips the website-only
artifacts** (`llms.txt`, `llms-full.txt`, search JSON, sitemap files,
`robots.txt`, and `agent-readability.json`). The website-mode JSON keys listed
above therefore describe the artifacts produced in the default website build.

## Sources
- `/docs/reference/cli.md`
- `/docs/quickstart.md`
- `/docs/package-docs/bundle.md`
