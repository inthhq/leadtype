# What `leadtype generate --json` reports

When you run `leadtype generate` with the `--json` flag, the generator prints a
**JSON object listing the paths of the artifacts it generated**. Rather than just
running quietly, it emits a machine-readable summary so build scripts and CI can
locate the output files.

## The reported fields (website mode)

In website mode, the JSON object includes paths for the following generated
artifacts:

| Field | What it points to |
|------|-------------------|
| `llmsFullTxt` | The root `/llms-full.txt` file containing every generated markdown docs page (full-context fallback). |
| `docsLlmsTxt` | The docs-scoped `/docs/llms.txt` map. |
| `llmsTxt` | The product-level `/llms.txt` entry map. |
| `agentReadabilityJson` | `docs/agent-readability.json`, which records artifact paths that shouldn't be treated as missing markdown pages. |
| `sitemapXml` | `docs/sitemap.xml`. |
| `sitemapMd` | `docs/sitemap.md`. |
| `robotsTxt` | `docs/robots.txt`. |
| `searchIndex` | `docs/search-index.json`, the static local search index. |
| `searchContent` | `docs/search-content.json`, the searchable content used for source-grounded answers. |

## Summary

`leadtype generate --json` does not change *what* is built; it changes *how the
result is reported*. It outputs a JSON object whose keys map to the paths of the
generated website artifacts — the LLM files (`llmsTxt`, `docsLlmsTxt`,
`llmsFullTxt`), the agent-readability manifest, the sitemaps, `robots.txt`, and
the two search files — making the output easy to consume programmatically in a
docs-site build pipeline.

> Note: This is the website-mode output. Bundle mode (`leadtype generate --bundle`)
> instead produces `AGENTS.md` and `docs/*.md` with relative links for npm packages.

## Sources
- `/docs/reference/cli.md`
- `/docs/quickstart.md`
- `/docs/reference/llm.md`
- `/docs/reference/search.md`
