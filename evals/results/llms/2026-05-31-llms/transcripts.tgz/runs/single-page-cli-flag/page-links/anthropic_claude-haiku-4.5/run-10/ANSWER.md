# What `leadtype generate --json` Reports

According to the Leadtype docs, when `--json` is enabled with the `leadtype generate` command, it prints a JSON object containing paths for the generated artifacts.

## Generated Artifacts Reported

The JSON output includes the following artifact paths:

- `llmsFullTxt` - The full-context LLM file
- `docsLlmsTxt` - Docs-specific LLM file
- `llmsTxt` - Root llms.txt file
- `agentReadabilityJson` - Agent readability metrics or data
- `sitemapXml` - XML sitemap
- `sitemapMd` - Markdown sitemap
- `robotsTxt` - Robots.txt file
- `searchIndex` - Search index artifact
- `searchContent` - Search content artifact

This JSON output is particularly useful for programmatic access to the paths of all generated artifacts from the Leadtype pipeline, making it easy for build systems and tools to locate and use the generated files.

Source: [CLI Reference](/docs/reference/cli.md)
