# What `leadtype generate --json` Reports

According to the Leadtype docs, when the `--json` flag is enabled, `leadtype generate --json` prints a JSON object with paths for the generated artifacts.

## JSON Output Contents

The website-mode JSON object includes the following paths:

- **llmsFullTxt** - Full context fallback file
- **docsLlmsTxt** - Docs-specific LLM file
- **llmsTxt** - Root LLM file
- **agentReadabilityJson** - Agent-readable metadata in JSON format
- **sitemapXml** - Sitemap in XML format
- **sitemapMd** - Sitemap in Markdown format
- **robotsTxt** - Robots.txt file
- **searchIndex** - Search index file
- **searchContent** - Search content file

This JSON output allows downstream systems to easily locate and reference all the generated artifacts produced by the Leadtype pipeline.
