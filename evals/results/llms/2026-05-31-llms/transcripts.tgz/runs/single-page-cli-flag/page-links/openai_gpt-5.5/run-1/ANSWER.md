`leadtype generate --json` prints a JSON object describing the generated output paths.

In website mode, that JSON object reports paths for these artifacts:

- `llmsFullTxt`
- `docsLlmsTxt`
- `llmsTxt`
- `agentReadabilityJson`
- `sitemapXml`
- `sitemapMd`
- `robotsTxt`
- `searchIndex`
- `searchContent`

These correspond to the website-mode files Leadtype writes, such as `/llms.txt`, `/docs/llms.txt`, `/llms-full.txt`, markdown mirrors, sitemap files, robots.txt, agent readability JSON, and search index/content JSON.