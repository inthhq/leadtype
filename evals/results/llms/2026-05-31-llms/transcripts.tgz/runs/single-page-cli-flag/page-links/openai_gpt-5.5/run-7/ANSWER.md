# What `leadtype generate --json` reports

According to the Leadtype CLI reference, `leadtype generate` converts docs and writes agent-readable artifacts. When the `--json` flag is enabled, it prints a JSON object that reports the paths of the generated artifacts.

In website mode, that JSON object includes paths for:

- `llmsFullTxt` — the root `/llms-full.txt` full-context file
- `docsLlmsTxt` — the docs-scoped `/docs/llms.txt` map
- `llmsTxt` — the product-level `/llms.txt`
- `agentReadabilityJson` — `/docs/agent-readability.json`
- `sitemapXml` — `/docs/sitemap.xml`
- `sitemapMd` — `/docs/sitemap.md`
- `robotsTxt` — `/docs/robots.txt`
- `searchIndex` — `/docs/search-index.json`
- `searchContent` — `/docs/search-content.json`

So, `leadtype generate --json` is meant for machine-readable build output: it tells scripts or CI where Leadtype wrote each generated website artifact.