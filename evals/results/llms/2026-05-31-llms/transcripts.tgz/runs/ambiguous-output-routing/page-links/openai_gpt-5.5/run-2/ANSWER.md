# Answer

Use the **Reference → LLM files** docs area: `/docs/reference/llm.md`.

That page covers the agent-facing output APIs/artifacts, including:

- `generateLlmsTxt` for the product-level `/llms.txt` and docs-scoped `/docs/llms.txt` maps.
- `generateLLMFullContextFiles` for the root `/llms-full.txt` full-context artifact.
- `generateAgentsMd` for npm-bundled `AGENTS.md`.
- `isAgentReadabilityArtifactPath` for recognizing agent-readability/static artifact paths.

Do **not** use the Search reference if your goal is agent-facing output APIs. `/docs/reference/search.md` is about the static search index and search/answer-generation path, not the LLM bundle/output APIs.

Use `/llms-full.txt` only as the **monolithic full-context fallback**: it is one root file containing every generated markdown docs page. The normal agent flow is to start at `/llms.txt` and follow the smallest relevant markdown links. Reach for `/llms-full.txt` when you need the whole docs corpus in one file, or when link-by-link page selection from `/llms.txt` is not sufficient or not practical.