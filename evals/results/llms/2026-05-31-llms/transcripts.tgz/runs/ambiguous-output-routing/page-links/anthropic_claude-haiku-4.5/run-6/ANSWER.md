# Agent-Facing Output APIs in Leadtype Docs Site

## Which docs area to use

For agent-facing output APIs (not search UI), use the **[LLM files reference](/docs/reference/llm.md)** documentation area.

This reference covers:
- `generateLlmsTxt` - writes product-level `/llms.txt` and docs-scoped `/docs/llms.txt` map for hosted websites
- `generateLLMFullContextFiles` - writes the root `/llms-full.txt` file
- `generateAgentsMd` - writes `AGENTS.md` for npm-bundled docs
- `isAgentReadabilityArtifactPath` - identifies artifact paths that should not be rewritten as missing markdown pages

You should also reference:
- **[CLI reference](/docs/reference/cli.md)** - for understanding the `--json` flag output which lists all agent-readable artifact paths (llmsFullTxt, docsLlmsTxt, llmsTxt, agentReadabilityJson, sitemapXml, sitemapMd, robotsTxt, searchIndex, searchContent)
- **[Connect a docs site](/docs/build/connect-docs-site.md)** - for deployment and routing guidance for these APIs

## When to use the `/llms-full.txt` fallback

Use the monolithic `/llms-full.txt` fallback when:

1. **Full-context requirements** - An agent needs access to the complete documentation context in a single file, rather than navigating through the structured page hierarchy
2. **Offline or limited navigation** - When an agent cannot reliably follow markdown links or doesn't support multi-page context assembly
3. **Complete document generation** - As a full-context fallback for agents that prefer one comprehensive file over the sectioned `/llms.txt` navigation structure

The `/llms-full.txt` is generated alongside the standard `/llms.txt` routing structure. Groups still organize the standard llms.txt sections, navigation, search metadata, and AGENTS.md, but they are not published as per-group full-context files by default—only the monolithic root `/llms-full.txt` is created.

This design allows agents to choose between:
- **Structured navigation** via `/llms.txt` (page-level links organized by groups)
- **Full-context fallback** via `/llms-full.txt` (everything in one file)
