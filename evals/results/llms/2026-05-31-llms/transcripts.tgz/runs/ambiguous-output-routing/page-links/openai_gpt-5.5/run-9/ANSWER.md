# Agent-facing Leadtype docs area

Use **Reference → LLM files**: `/docs/reference/llm.md`.

That is the docs area for Leadtype’s agent-facing output APIs:

- `generateLlmsTxt` for the product-level `/llms.txt` and docs-scoped `/docs/llms.txt` maps.
- `generateLLMFullContextFiles` for the root `/llms-full.txt` full-context artifact.
- `generateAgentsMd` for npm-bundled `AGENTS.md`.
- `isAgentReadabilityArtifactPath` for recognizing agent/readability artifacts that should stay static.

For hosted-site wiring, also use **Build → Connect a docs site**: `/docs/build/connect-docs-site.md`. It explains exposing `/llms.txt`, markdown mirrors under `/docs/*.md`, and keeping `/llms-full.txt` and related artifacts static.

Do **not** use the Search docs area for this need. `/docs/reference/search.md` is about the static search index, lexical ranking, and optional source-grounded answer generation/search behavior, not the agent-facing output files/APIs.

## When to use `/llms-full.txt`

Treat `/llms-full.txt` as a **monolithic full-context fallback**, not the normal first choice.

The normal agent flow is:

1. Start at `/llms.txt`.
2. Follow the smallest relevant markdown page links.
3. Fetch individual `/docs/*.md` pages as needed.

Use `/llms-full.txt` only when an agent or integration needs one file containing every generated markdown docs page, or when page-by-page routing through `/llms.txt` is not practical. It is root-level only and includes all generated markdown docs; Leadtype does not publish per-group full-context files by default.