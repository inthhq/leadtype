# Agent-Facing Output APIs in Leadtype Docs

## Which Docs Area to Use

For agent-facing output APIs (not search UI), use the **[Reference - LLM files](/docs/reference/llm.md)** section.

This documentation covers:
- `generateLlmsTxt`: Writes the product-level `/llms.txt` and docs-scoped `/docs/llms.txt` map for hosted websites
- `generateLLMFullContextFiles`: Writes the root `/llms-full.txt` file
- `generateAgentsMd`: Writes AGENTS.md for npm-bundled docs
- `isAgentReadabilityArtifactPath`: Identifies artifact paths that should not be rewritten as missing markdown pages

## When to Use the Monolithic `/llms-full.txt` Fallback

Use the `/llms-full.txt` fallback when:

1. **Fallback content needed**: The root `/llms-full.txt` file contains every generated markdown docs page as a complete, single-file fallback.

2. **Group-based routing not suitable**: While groups still organize `/llms.txt` sections, navigation, search metadata, and AGENTS.md, the `/llms-full.txt` file is not split by group. Use this when you need all content in one place rather than following group-based navigation.

3. **Offline or disconnected access**: The monolithic format works when agents cannot or should not follow links between multiple pages.

4. **Full context needed**: When the agent needs complete context without making multiple requests to different markdown pages.

## Key Takeaway

For structured, agent-friendly navigation: use `/llms.txt` (page-level links organized by group)  
For complete fallback content: use `/llms-full.txt` (all pages in one file)
