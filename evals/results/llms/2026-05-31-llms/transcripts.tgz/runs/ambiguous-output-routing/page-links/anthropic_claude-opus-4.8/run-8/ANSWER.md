# Agent-facing output APIs in the Leadtype docs

## Which docs area to use

Use the **Reference → LLM files** page: [`/docs/reference/llm.md`](/docs/reference/llm.md).

That page documents the agent-facing *output* APIs that emit the agent-readable artifacts:

- **`generateLlmsTxt`** — writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` map for hosted websites.
- **`generateLLMFullContextFiles`** — writes the single root `/llms-full.txt` containing every generated markdown docs page.
- **`generateAgentsMd`** — writes `AGENTS.md` for npm-bundled docs (intentionally ignores `product.agentGuidance`, which is written for website URL routing).
- **`isAgentReadabilityArtifactPath`** — identifies artifact paths that should not be rewritten as missing markdown pages (covers `llms.txt`, `llms-full.txt`, sitemap files, `robots.txt`, search JSON, and `agent-readability.json`).

## What NOT to use for this

Do **not** use **Reference → Search** ([`/docs/reference/search.md`](/docs/reference/search.md)). That page covers the static search index, BM25 lexical ranking, and source-grounded answers — i.e. the search/query path, not the agent-facing output APIs you asked for.

## When to use the monolithic `/llms-full.txt` fallback

`/llms-full.txt` is the **root full-context fallback**: a single file that bundles every generated markdown docs page.

- **Default / preferred approach:** Follow the page-level markdown links from `/llms.txt` and read the smallest page (or pages) that answer the task. Groups exist for routing, not sharding — they are not published as per-group full-context files by default.
- **Use `/llms-full.txt` as a fallback when** you cannot resolve the task by selectively fetching individual pages — e.g., when a client/agent can't follow the per-page links, or when you genuinely need the entire corpus in one context blob. Because it concatenates *all* pages, prefer the targeted page links first and reserve `/llms-full.txt` for the whole-corpus fallback case.
