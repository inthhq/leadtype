# Agent-Facing Output APIs in Leadtype

## Primary Documentation Area

For agent-facing output APIs, use the **[Reference: LLM files](/docs/reference/llm.md)** section.

This documentation covers:
- **generateLlmsTxt**: Writes product-level `/llms.txt` and docs-scoped `/docs/llms.txt` map for hosted websites
- **generateLLMFullContextFiles**: Generates the root `/llms-full.txt` full-context fallback
- **generateAgentsMd**: Writes AGENTS.md for npm-bundled docs

## When to Use `/llms-full.txt` Fallback

Use the monolithic `/llms-full.txt` fallback in these scenarios:

1. **Fallback for Limited Context**: When an agent needs complete context in a single file and cannot make multiple requests to fetch individual markdown pages via the `/docs/*.md` routing.

2. **Offline/Bundled Package Scenarios**: When distributing docs inside an npm tarball for offline agents (alongside AGENTS.md), where HTTP discovery isn't available.

3. **Context Window Constraints**: When an agent has sufficient token budget for the full concatenated docs and prefers it to manage fewer HTTP round-trips.

## Primary Agent Flow (Preferred)

For hosted websites, agents should:
1. Start at `/llms.txt` (the root navigation map)
2. Follow markdown links to specific `/docs/*.md` pages
3. Use the `/docs/llms.txt` scoped map for docs-specific navigation
4. Request pages with `Accept: text/markdown` header when available

This approach keeps payloads small and allows agents to fetch only what they need.

## Related Documentation

- **[How it works](/docs/how-it-works.md)**: Explains the complementary flows for HTTP agents vs. package-bundled agents
- **[Connect a docs site](/docs/build/connect-docs-site.md)**: Guidance on serving agent-readable markdown artifacts from a hosted website
- **[CLI Reference](/docs/reference/cli.md)**: Details on the `--json` flag output showing artifact paths like `llmsFullTxt`, `llmsTxt`, and `docsLlmsTxt`
