# Agent-Facing Output APIs in Leadtype Docs

## Which Docs Area to Use

For agent-facing output APIs (not search UI), use the **[LLM files reference](/docs/reference/llm.md)** documentation area.

## Key Agent-Facing APIs

The LLM files documentation covers three main API outputs:

1. **generateLlmsTxt**: Writes product-level `/llms.txt` and docs-scoped `/docs/llms.txt` map for hosted websites. This is the entry point for HTTP agents.

2. **generateLLMFullContextFiles**: Writes the root `/llms-full.txt` file containing every generated markdown docs page.

3. **generateAgentsMd**: Writes `AGENTS.md` for npm-bundled docs (for offline agents working inside node_modules).

## When to Use the `/llms-full.txt` Fallback

Use the monolithic `/llms-full.txt` fallback when:

- You need **complete context** of all documentation in a single file
- You want a **root full-context fallback** that contains every generated markdown docs page
- You're working with agents that benefit from having **all pages in one place** rather than following links from the smaller `/llms.txt` entry point

The `/llms-full.txt` is distinct from the primary `/llms.txt` entry point, which is the recommended starting point for agents. The full-context file serves as a comprehensive fallback when you need complete documentation coverage.

## Agent Entry Points

- **HTTP agents** accessing a hosted docs website: Start at `/llms.txt` and follow markdown links
- **Coding agents** working offline in installed npm packages: Start at `AGENTS.md` and follow relative `docs/*.md` links
