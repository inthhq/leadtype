Use the **Reference → LLM files** docs area (`/docs/reference/llm.md`) for agent-facing output APIs. That page covers the APIs/artifacts for agent-readable outputs:

- `generateLlmsTxt` for the product-level `/llms.txt` and docs-scoped `/docs/llms.txt` maps
- `generateLLMFullContextFiles` for the root `/llms-full.txt`
- `generateAgentsMd` for npm-bundled `AGENTS.md`
- `isAgentReadabilityArtifactPath` for recognizing static agent-readability artifacts

Do **not** use the Search reference if you are looking for agent-facing output APIs. Search is about the static local search index and source-grounded answer generation, not the LLM/agent output surface.

Use `/llms.txt` as the normal HTTP-agent entry point and follow the page-level markdown links from there. Use the monolithic `/llms-full.txt` only as a full-context fallback when you need every generated markdown docs page in one root file. It is not split by group; groups are for routing, sections, navigation, search metadata, and `AGENTS.md` grouping—not for sharding `/llms-full.txt`.