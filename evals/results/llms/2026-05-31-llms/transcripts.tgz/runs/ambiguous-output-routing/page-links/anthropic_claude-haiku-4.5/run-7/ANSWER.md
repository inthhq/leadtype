# Agent-Facing Output APIs in Leadtype Docs

## Which Docs Area to Use

For **agent-facing output APIs** (not search UI), use the **Reference section**, specifically:

- **[/docs/reference/llm.md](/docs/reference/llm.md)** - Contains the definitive documentation for LLM bundle APIs

This page documents the key API functions:
- `generateLlmsTxt` - Generates product-level `/llms.txt` and docs-scoped `/docs/llms.txt` map
- `generateLLMFullContextFiles` - Generates the root `/llms-full.txt` monolithic fallback
- `generateAgentsMd` - Generates AGENTS.md for npm-bundled docs
- `isAgentReadabilityArtifactPath` - Identifies artifact paths for agent access

## When to Use the `/llms-full.txt` Fallback

Use the monolithic `/llms-full.txt` fallback when:

1. **You need the complete context** - It contains every generated markdown docs page in a single file
2. **You're building a stateless agent** - When you cannot or prefer not to follow the hierarchical page-level markdown links from `/llms.txt`
3. **Context window allows** - If your agent has sufficient token budget to process the entire documentation set at once
4. **Offline/bundle scenarios** - When working with npm-bundled docs offline via AGENTS.md

## Architecture Notes

Leadtype uses two complementary flows:

1. **HTTP agents** start at `/llms.txt` and follow markdown links (page-level API, recommended for bandwidth-aware scenarios)
2. **Package agents** start at `AGENTS.md` and follow relative `docs/*.md` links (for npm-bundled offline docs)

The `/llms-full.txt` serves as a fallback for agents that prefer monolithic context over hierarchical navigation.
