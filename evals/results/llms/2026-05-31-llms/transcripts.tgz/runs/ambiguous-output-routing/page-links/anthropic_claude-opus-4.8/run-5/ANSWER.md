# Agent-facing output APIs vs. search UI

## Which docs area to use

Use the **Reference → LLM files** page (`/docs/reference/llm.md`). This is the agent-facing output area. It documents the APIs that produce the artifacts agents fetch:

- **`generateLlmsTxt`** — writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` map for hosted websites. This is the primary entry point: it gives agents a routed map of page-level markdown links so they can read the smallest page(s) that answer a task.
- **`generateLLMFullContextFiles`** — writes the single root `/llms-full.txt` containing every generated markdown docs page.
- **`generateAgentsMd`** — writes `AGENTS.md` for npm-bundled docs (note: it intentionally ignores `product.agentGuidance`, which is meant for website URL routing).
- **`isAgentReadabilityArtifactPath`** — identifies artifact paths (llms.txt, llms-full.txt, sitemap, robots.txt, search JSON, agent-readability.json) that must not be rewritten as missing markdown pages.

Do **not** use the **Reference → Search** page (`/docs/reference/search.md`) for this. That covers the static search index / BM25 lexical ranking and source-grounded answers — i.e., the search query path, not the agent output APIs.

## When to use the monolithic `/llms-full.txt` fallback

The preferred path is the routed `/llms.txt` map (plus the per-group `/docs/llms.txt`), following each page-level markdown link and reading only the smallest page(s) needed. Groups are for routing, not sharding — there are no per-group full-context files published by default.

Use the monolithic `/llms-full.txt` only as a **fallback** when routed page-level reading isn't viable — i.e., when you need the entire corpus in one file because the routing map and individual page links don't get you to the answer. Because it concatenates *every* generated markdown page into one root file, it's the broad, high-cost option; reach for it only after the targeted `/llms.txt` → individual-page approach falls short.
