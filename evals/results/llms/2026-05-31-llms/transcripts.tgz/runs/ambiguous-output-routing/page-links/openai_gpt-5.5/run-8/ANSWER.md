# Answer

Use the **Reference → LLM files** docs area for agent-facing output APIs, not the Search docs.

That page covers the APIs and artifacts meant for agents:

- `generateLlmsTxt` for the product-level `/llms.txt` and docs-scoped `/docs/llms.txt` maps.
- `generateLLMFullContextFiles` for the root `/llms-full.txt` full-context artifact.
- `generateAgentsMd` for npm-bundled `AGENTS.md` docs.
- `isAgentReadabilityArtifactPath` for recognizing agent/readability artifacts that should stay static.

If you are wiring these artifacts into a hosted site, also use **Build → Connect a docs site**, which explains serving `/llms.txt`, markdown mirrors under `/docs/*.md`, and keeping `/llms-full.txt` and related files as static artifacts.

Do **not** use the Search area for this task. Search is about the static local search index, lexical ranking, source-grounded answer generation, and optional embeddings; it is not the primary reference for agent-facing output files.

Use the monolithic `/llms-full.txt` only as a fallback full-context artifact. The normal agent flow is to start at `/llms.txt` and follow the smallest relevant page-level markdown links. Reach for `/llms-full.txt` when an agent or integration needs one root file containing every generated markdown docs page, or cannot reliably navigate/fetch the linked page-level markdown files. Groups are routing hints for `/llms.txt`, navigation, search metadata, and `AGENTS.md`; they are not published as per-group full-context shards by default.
