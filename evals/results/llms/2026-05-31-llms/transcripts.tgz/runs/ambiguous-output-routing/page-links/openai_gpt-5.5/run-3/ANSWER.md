# Answer

Use the **Reference → LLM files** docs area for the agent-facing output APIs. That page covers the generated agent artifacts such as `/llms.txt`, `/docs/llms.txt`, `/llms-full.txt`, and `AGENTS.md`.

For a hosted docs site, also use **Build → Connect a docs site** for deployment behavior: generate `/llms.txt` at the site root, expose markdown mirrors under `/docs/*.md`, and serve markdown to agents via `Accept: text/markdown` or known AI user agents.

Do **not** use the Search docs if your goal is agent-facing output APIs rather than search UI or retrieval behavior. Search is about the static search index and query path.

Use the monolithic `/llms-full.txt` only as a **full-context fallback**: prefer starting at `/llms.txt` and following the smallest relevant markdown links, and fall back to `/llms-full.txt` when an agent or integration needs the entire generated markdown corpus in one file or cannot reliably route through individual page-level markdown links.
