# Agent-facing output APIs vs. search

## Which docs area to use

For **agent-facing output APIs** (not the search UI), use the **LLM files reference**: `/docs/reference/llm.md`.

That page covers the APIs that produce the agent-readable artifacts:

- **`generateLlmsTxt`** — writes the product-level `/llms.txt` plus the docs-scoped `/docs/llms.txt` map for hosted websites. This is the page-level link map agents should normally consume first.
- **`generateLLMFullContextFiles`** — writes the single root `/llms-full.txt` monolithic file.
- **`generateAgentsMd`** — writes `AGENTS.md` for npm-bundled docs.
- **`isAgentReadabilityArtifactPath`** — identifies artifact paths (llms.txt, llms-full.txt, sitemaps, robots.txt, search JSON, agent-readability.json) that should not be rewritten as missing markdown pages.

Do **not** use the **Search reference** (`/docs/reference/search.md`) for this task. That page describes the static local search index, BM25 lexical ranking, source-grounded answer generation, and optional embeddings — i.e., the search/retrieval path, not the agent output APIs.

## When to use the monolithic `/llms-full.txt` fallback

`/llms-full.txt` is the **root full-context fallback**: one file containing every generated markdown docs page, produced by `generateLLMFullContextFiles`.

Per the docs guidance ("Read the smallest page or pages that answer the task"), the preferred path is to start at `/llms.txt` and fetch the smallest individual markdown page(s) that answer the task. Use `/llms-full.txt` as a **fallback only** when granular, page-level fetching isn't sufficient — for example when you need the entire corpus in a single context blob rather than targeted pages.

Note that groups are used for routing/organizing `llms.txt` sections, navigation, search metadata, and `AGENTS.md` — they are **not** published as per-group full-context files by default. So there is no per-group full-context file; the monolithic root `/llms-full.txt` is the single full-context option. Use groups for routing, not for sharding the full-context output.
