# Agent-facing output APIs vs. search UI

## Which docs area to use

For **agent-facing output APIs**, use the **LLM files** reference: [`/docs/reference/llm.md`](/docs/reference/llm.md).

That page documents the APIs that produce the agent-readable artifacts:

- `generateLlmsTxt` — writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` map for hosted websites. This is the discovery entrypoint agents start from.
- `generateLLMFullContextFiles` — writes the single root `/llms-full.txt` containing every generated markdown docs page.
- `generateAgentsMd` — writes `AGENTS.md` for npm-bundled (offline) docs.
- `isAgentReadabilityArtifactPath` — identifies artifact paths (llms.txt, llms-full.txt, sitemap, robots.txt, search JSON, agent-readability.json) that should not be rewritten as missing markdown pages.

**Do not** use [`/docs/reference/search.md`](/docs/reference/search.md) for this. That page covers the static search index and source-grounded answer generation (the search/query path), which is the "search UI" side, not the agent output APIs.

### Default agent flow (preferred over the monolith)
Per [How it works](/docs/how-it-works.md) and [Connect a docs site](/docs/build/connect-docs-site.md):

- HTTP agents start at `/llms.txt` and follow page-level markdown links, reading the **smallest page(s)** that answer the task.
- Coding agents inside installed npm packages start at `AGENTS.md` and follow relative `docs/*.md` links.
- Hosted sites should serve markdown when `Accept: text/markdown` (or a known AI user agent) requests a docs page.

## When to use the monolithic `/llms-full.txt` fallback

`/llms-full.txt` (produced by `generateLLMFullContextFiles`) is a **fallback**, not the default. It bundles *every* generated markdown page into one root file.

Use it only when the normal link-following flow is not viable — i.e., when an agent **cannot** start at `/llms.txt` and selectively fetch individual `/docs/*.md` pages, and instead needs the entire docs corpus in a single fetch as full context.

In the normal case, prefer the granular flow: start at `/llms.txt`, follow links, and read the smallest page(s) needed. Note also that groups are used for routing/organization (llms.txt sections, navigation, search metadata, AGENTS.md) and are **not** published as per-group full-context files by default, so `/llms-full.txt` is the only monolithic full-context artifact.
