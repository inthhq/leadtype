# Answer

Use the **Reference → LLM files** docs area: `/docs/reference/llm.md`.

That is the agent-facing output API reference. It covers:

- `generateLlmsTxt` for the product-level `/llms.txt` and docs-scoped `/docs/llms.txt` maps
- `generateLLMFullContextFiles` for the root `/llms-full.txt` full-context file
- `generateAgentsMd` for npm-bundled `AGENTS.md`
- `isAgentReadabilityArtifactPath` for recognizing agent/readability artifacts

For a hosted docs site, also use **Build → Connect a docs site** (`/docs/build/connect-docs-site.md`) for deployment behavior: generate `/llms.txt`, expose markdown mirrors under `/docs/*.md`, and serve markdown to agent requests.

Do **not** use the Search reference for this need. `/docs/reference/search.md` is about the static local search index, lexical ranking, and optional embeddings/source-grounded answer generation. It is not the primary reference for agent-facing output files.

Use `/llms.txt` as the normal entry point. Agents should start there and follow the page-level markdown links to the smallest relevant docs pages.

Use the monolithic `/llms-full.txt` only as a fallback when a consumer needs the entire generated markdown corpus in one file or cannot reliably follow the `/llms.txt` page-level routing. It contains every generated markdown docs page at the root. It is not a per-group sharding mechanism; Leadtype groups are routing/navigation hints, not separate full-context bundles by default.
