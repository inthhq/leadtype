# Answer

Use the **Reference → LLM files** docs area: `/docs/reference/llm.md`.

That page covers the agent-facing output APIs/artifacts:

- `generateLlmsTxt` for the product-level `/llms.txt` and docs-scoped `/docs/llms.txt` maps.
- `generateLLMFullContextFiles` for the root `/llms-full.txt` full-context artifact.
- `generateAgentsMd` for npm-bundled `AGENTS.md`.
- `isAgentReadabilityArtifactPath` for recognizing agent/readability artifacts that should remain static.

Do **not** use the Search docs if your need is agent-facing output APIs rather than search UI. `/docs/reference/search.md` is about the static search index, lexical ranking, optional embeddings, and source-grounded answer generation.

Use the monolithic `/llms-full.txt` fallback only when an agent needs a single full-context file containing every generated markdown docs page. Prefer `/llms.txt` first as the routing map and fetch the smallest relevant page-level markdown files. Treat groups as routing/navigation hints, not as per-group full-context shards; Leadtype does not publish per-group full-context files by default.