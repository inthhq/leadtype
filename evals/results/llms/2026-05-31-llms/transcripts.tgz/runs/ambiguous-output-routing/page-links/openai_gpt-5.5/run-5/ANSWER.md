# Answer

Use the **Reference → LLM files** docs area: `/docs/reference/llm.md`.

That is the agent-facing output API reference. It covers:

- `generateLlmsTxt` for the product-level `/llms.txt` and docs-scoped `/docs/llms.txt` maps.
- `generateLLMFullContextFiles` for the root `/llms-full.txt` file.
- `generateAgentsMd` for npm-bundled `AGENTS.md` docs.
- `isAgentReadabilityArtifactPath` for recognizing generated agent/readability artifacts.

Do **not** use the Search reference if you are looking for output APIs. `/docs/reference/search.md` is about the static search index and runtime/source-grounded search behavior, not the agent-facing file outputs.

Use `/llms.txt` as the normal hosted-docs entry point: HTTP agents start there and follow the linked page-level markdown files. Use the monolithic `/llms-full.txt` only as a full-context fallback when an agent needs or can only consume the whole generated docs corpus in one file instead of routing through `/llms.txt` and individual `/docs/*.md` pages.

Important caveat: `/llms-full.txt` is a single root file containing every generated markdown docs page. It is **not** split by group; groups are for routing, navigation, search metadata, `llms.txt` sections, and `AGENTS.md` grouping, not for sharding full-context files.
