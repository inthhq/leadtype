# Leadtype Agent-Facing Output APIs

## Primary API: `/llms.txt` (Docs-scoped routing)

For agent-facing output APIs in the Leadtype docs site, use the **`/docs/reference/llm.md`** documentation area.

The recommended agent workflow is:
1. **Start with `/llms.txt`** - This is the product-level index file that agents should begin at
2. **Follow markdown links** - Navigate to specific `/docs/*.md` pages as needed based on the index
3. **Server returns markdown** - Serve markdown when agents request with `Accept: text/markdown` header or from known AI user agents

This is the primary, efficient approach as `/llms.txt` is scoped to the docs collection with groups organizing sections, navigation, search metadata, and AGENTS.md.

## Fallback API: `/llms-full.txt` (Full-context monolithic)

Use the **monolithic `/llms-full.txt` fallback** when:
- You need complete, full-context documentation in a single file
- The agent cannot follow multiple page links (limited context navigation capability)
- You want to guarantee access to the entire docs corpus without multiple HTTP requests
- Search functionality is unavailable or infeasible

The `/llms-full.txt` file contains every generated markdown docs page bundled into one root file. While groups still organize the content internally, this format is used as a complete fallback when the primary `/llms.txt` + individual pages approach cannot be used.

## Key Points

- **Normal case**: Use `/llms.txt` + `/docs/*.md` pages (efficient, modular)
- **Fallback case**: Use `/llms-full.txt` (complete but monolithic)
- **Verification**: Confirm the setup by fetching `/llms.txt`, testing `/docs/*.md` with `Accept: text/markdown`, and checking `/docs/sitemap.xml`

Reference: `/docs/reference/llm.md` and `/docs/build/connect-docs-site.md`
