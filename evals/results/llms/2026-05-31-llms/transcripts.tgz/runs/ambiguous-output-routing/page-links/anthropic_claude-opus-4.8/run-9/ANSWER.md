# Agent-facing output APIs in Leadtype

## Which docs area to use

Use the **Reference → LLM files** page (`/docs/reference/llm.md`). This is the area that documents the agent-facing *output* APIs, as opposed to the **Search** page (`/docs/reference/search.md`), which is about the static search index / query path (the "search UI"–type functionality).

The agent-facing output APIs documented there are:

- **`generateLlmsTxt`** — writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` map for hosted websites. This is the primary entry point agents follow (HTTP agents start at `/llms.txt` and follow page-level markdown links).
- **`generateLLMFullContextFiles`** — writes the single root `/llms-full.txt` file containing every generated markdown docs page.
- **`generateAgentsMd`** — writes `AGENTS.md` for npm-bundled docs (coding agents inside installed packages start here and follow relative `docs/*.md` links). Note: it intentionally ignores `product.agentGuidance`, since that text is for website URL routing.
- **`isAgentReadabilityArtifactPath`** — identifies artifact paths that shouldn't be rewritten as missing markdown pages (covers `llms.txt`, `llms-full.txt`, sitemaps, `robots.txt`, search JSON, and `agent-readability.json`).

The Search page is **not** the right area for output APIs — it covers the build-time static search index and edge-safe lexical (BM25) query path, plus optional embeddings. Use it only for search/retrieval concerns, not for emitting agent-readable docs.

## When to use the monolithic `/llms-full.txt` fallback

`/llms-full.txt` is a **full-context fallback**: one root file that concatenates every generated markdown docs page.

Per the docs' guidance ("Read the smallest page or pages that answer the task"), the **default and preferred** approach is:

1. Start at `/llms.txt`.
2. Follow the page-level markdown links to the **smallest page(s)** that answer the task.

Use the monolithic `/llms-full.txt` only as a **fallback** — when targeted, page-level navigation is insufficient and you genuinely need the entire corpus in one fetch (i.e., when you need full context rather than a specific page). It should not be your first stop, because it pulls in everything rather than just the relevant pages.

Also note: groups are meant for **routing** (organizing `llms.txt` sections, navigation, search metadata, and `AGENTS.md`), **not** for sharding — Leadtype does not publish per-group full-context files by default; the full-context output is the single root `/llms-full.txt`.
