# Answer

Use the **Reference → LLM files** docs area: `/docs/reference/llm.md`.

That is the agent-facing output API area for Leadtype’s generated agent-readable artifacts:

- `/llms.txt` — product-level entry point for HTTP agents.
- `/docs/llms.txt` — docs-scoped map for hosted docs sites.
- `/llms-full.txt` — root full-context fallback containing every generated markdown docs page.
- `AGENTS.md` — npm-package/offline agent entry point.

Do **not** use the **Search** docs area if you are asking about agent-facing output files rather than search UI or search indexing. `/docs/reference/search.md` covers the static search index, lexical ranking, source-grounded answer generation, and optional embeddings.

Use the monolithic `/llms-full.txt` fallback only when an agent needs or can only consume one full-context file instead of starting at `/llms.txt` and following the smallest relevant page-level markdown links. The normal hosted-docs flow is: start at `/llms.txt`, use its routing map, then fetch the specific markdown pages needed. `/llms-full.txt` is the broad fallback because it contains every generated markdown docs page, not per-group shards.