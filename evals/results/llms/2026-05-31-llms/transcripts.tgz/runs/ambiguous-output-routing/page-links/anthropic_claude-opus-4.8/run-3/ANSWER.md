# Agent-facing output APIs in the Leadtype docs

## Which docs area to use

Use the **Reference → LLM files** page (`/docs/reference/llm.md`).

That page documents the agent-facing output APIs:

- **`generateLlmsTxt`** — writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` map for hosted websites. These are the page-level markdown maps agents follow to read the smallest relevant page(s).
- **`generateLLMFullContextFiles`** — writes the single root `/llms-full.txt` containing every generated markdown docs page (the monolithic fallback).
- **`generateAgentsMd`** — writes `AGENTS.md` for npm-bundled docs (intentionally ignores `product.agentGuidance`, which targets website URL routing).
- **`isAgentReadabilityArtifactPath`** — identifies agent-readability artifact paths (e.g. `llms.txt`, `llms-full.txt`, sitemap/robots files, search JSON, `agent-readability.json`) so they aren't rewritten as missing markdown pages.

**Do not use the Search area** (`/docs/reference/search.md`) for this. Search covers the static lexical BM25 index, source-grounded answers, and embeddings — i.e. the search/retrieval path, not the agent-facing output API surface.

## When to use the monolithic `/llms-full.txt` fallback

The preferred default is to **follow the page-level markdown links in `/llms.txt`** and read only the smallest page(s) that answer the task. `/llms.txt` (and `/docs/llms.txt`) is the routing map; groups exist for routing, not for sharding.

`/llms-full.txt` is the **monolithic, whole-corpus fallback** — one root file with every generated markdown page. Use it when:

- You need the full context in a single fetch rather than navigating page-by-page (e.g. an agent that wants everything at once, or when targeted per-page retrieval isn't practical).
- Note that full-context output is published **only** as this single root file; groups are **not** emitted as per-group full-context files by default. So if you want grouped or scoped context, navigate via `/llms.txt`; if you want everything in one blob, fall back to `/llms-full.txt`.
