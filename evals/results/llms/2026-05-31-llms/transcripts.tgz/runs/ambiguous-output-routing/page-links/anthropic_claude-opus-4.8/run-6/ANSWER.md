# Agent-facing output APIs vs. search, and the `/llms-full.txt` fallback

## Which docs area to use

Use the **Reference → LLM files** doc (`/docs/reference/llm.md`). This is the agent-facing *output* API area — it covers the functions that emit agent-readable artifacts:

- **`generateLlmsTxt`** — writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` map for hosted websites. This is the primary entry point for HTTP agents, which start at `/llms.txt` and follow per-page markdown links.
- **`generateLLMFullContextFiles`** — writes the single root `/llms-full.txt` containing every generated markdown docs page.
- **`generateAgentsMd`** — writes `AGENTS.md` for npm-bundled docs (the entry point for coding agents working inside installed packages).
- **`isAgentReadabilityArtifactPath`** — identifies artifact paths (e.g. `llms.txt`, `llms-full.txt`, sitemaps, `robots.txt`, search JSON, `agent-readability.json`) that should not be rewritten as missing markdown pages.

**Do not use the Search area** (`/docs/reference/search.md`) for this. Search describes the static BM25 lexical index and source-grounded answer generation — that is the search/retrieval path, not the agent-facing output APIs you asked about.

## When to use the monolithic `/llms-full.txt` fallback

The intended primary path is **page-level**: start at `/llms.txt`, follow the markdown links, and read the smallest page (or pages) that answers the task. Groups are for routing, not sharding — there are no per-group full-context files by default.

Use the monolithic `/llms-full.txt` only as a **fallback** when the page-level navigation isn't sufficient — i.e., when you need the entire docs corpus in one fetch (for example, an agent that needs full context and cannot or should not crawl the individual `/llms.txt` markdown links). It bundles every generated markdown page into one root file. Prefer the granular `/llms.txt` → page-link flow first to keep context small, and fall back to `/llms-full.txt` when whole-corpus context is required.
