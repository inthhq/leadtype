# Agent-Facing Output APIs in Leadtype

## Which Docs Area to Use

For agent-facing output APIs (not search UI), use the **[Reference section](/docs/reference/)**, specifically:

1. **[LLM files](/docs/reference/llm.md)** - The primary reference for agent-facing APIs
   - `/llms.txt` - Product-level entry point for HTTP agents
   - `/docs/llms.txt` - Docs-scoped map for hosted websites
   - `/llms-full.txt` - Root full-context fallback (see below)
   - `AGENTS.md` - For npm-bundled docs in node_modules

2. **[Connect a docs site](/docs/build/connect-docs-site.md)** - Implementation guide for serving agent-readable artifacts
   - Describes how to expose `/llms.txt` and markdown mirrors under `/docs/*.md`
   - Lists static artifacts agents expect: `/llms.txt`, `/llms-full.txt`, sitemap files, `robots.txt`, search JSON, and `agent-readability.json`

3. **[Search](/docs/reference/search.md)** - For source-grounded answer generation from static search indices

## When to Use `/llms-full.txt`

Use the monolithic `/llms-full.txt` fallback when:

- **Page-level navigation fails**: When an agent cannot follow page-level markdown links from `/llms.txt`
- **Full context is needed**: When you need every generated markdown docs page in one file for complete context
- **Offline/batch processing**: When agents are working without HTTP request capabilities to fetch individual pages

According to the documentation, `/llms-full.txt` is described as "the root full-context fallback," indicating it's a contingency option rather than the primary agent interface. Agents should normally start at `/llms.txt` (for HTTP requests) or `AGENTS.md` (for npm package installations) and follow markdown links to specific pages.

## Normal Agent Flow

1. HTTP agents: Start at `/llms.txt` → follow markdown links to specific `/docs/*.md` pages
2. Package agents: Start at `AGENTS.md` → follow relative `docs/*.md` links
3. Fallback: Use `/llms-full.txt` only when the normal flow cannot be completed
