# Agent-facing output APIs vs. search UI

## Which docs area to use

Use the **LLM files reference** at [`/docs/reference/llm.md`](/docs/reference/llm.md). That is the area covering the agent-facing output APIs.

It documents the generation APIs that produce agent-readable artifacts:

- **`generateLlmsTxt`** — writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` map for hosted websites. This is the primary entry point for HTTP/URL-based agents, which start at `/llms.txt` and follow page-level markdown links.
- **`generateLLMFullContextFiles`** — writes the single root `/llms-full.txt` monolithic file containing every generated markdown docs page.
- **`generateAgentsMd`** — writes `AGENTS.md` for npm-bundled docs (the entry point for coding agents working inside installed packages). It ignores `product.agentGuidance` because that text targets website URL routing.
- **`isAgentReadabilityArtifactPath`** — identifies artifact paths (llms.txt, llms-full.txt, sitemaps, robots.txt, search JSON, agent-readability.json) that should not be rewritten as missing markdown pages.

### Why NOT the Search area

The **Search reference** ([`/docs/reference/search.md`](/docs/reference/search.md)) describes the static local search index, BM25-style lexical ranking, and the runtime query path / source-grounded answer generation. That is the search subsystem, not the agent-facing output API surface you asked for, so it is not the area to use here.

## When to use the monolithic `/llms-full.txt` fallback

`/llms-full.txt` (produced by `generateLLMFullContextFiles`) is a single root file containing **every** generated markdown docs page concatenated together. It is a fallback, not the default path:

- **Prefer the granular path first.** The intended flow is to start at `/llms.txt` and follow the page-level markdown links, reading only the smallest page(s) that answer the task. Groups are for routing/navigation, not for sharding into per-group full-context files.
- **Use `/llms-full.txt` when** you need full context in one fetch instead of navigating links — e.g., when an agent cannot reliably follow the per-page markdown links, when the task spans many pages, or when you want the entire corpus in a single context window rather than selecting individual pages.

In short: use `/docs/reference/llm.md`'s `generateLlmsTxt` + per-page links as the normal agent path, and fall back to the monolithic `/llms-full.txt` only when whole-corpus, single-fetch context is needed.
