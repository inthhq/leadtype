Use the **Reference → LLM files** docs area for the agent-facing output APIs. That page covers the APIs/artifacts intended for agents, including:

- `generateLlmsTxt` for `/llms.txt` and `/docs/llms.txt` maps
- `generateLLMFullContextFiles` for `/llms-full.txt`
- `generateAgentsMd` for package-bundled `AGENTS.md`
- `isAgentReadabilityArtifactPath` for recognizing static agent-readability artifacts

Do **not** use the **Search** area if your goal is agent-facing output APIs rather than search UI or retrieval behavior. Search is about the static search index and query path.

Use the monolithic **`/llms-full.txt`** only as a fallback when an agent needs one full-context file containing every generated markdown docs page, instead of starting at `/llms.txt` and following the page-level markdown links. It is a single root full-context artifact, not per-group sharding; groups are for routing, navigation, search metadata, and `AGENTS.md` organization.