# Agent-facing output APIs vs. search UI

## Which docs area to use

Use **[LLM files](/docs/reference/llm.md)** (`docs/reference/llm.md`). This is the agent-facing output area — it documents the APIs that produce agent-readable artifacts:

- `generateLlmsTxt` — writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` map (the per-page link maps agents should navigate first).
- `generateLLMFullContextFiles` — writes the single root `/llms-full.txt` file containing every generated markdown docs page.
- `generateAgentsMd` — writes `AGENTS.md` for npm-bundled docs.
- `isAgentReadabilityArtifactPath` — identifies agent-readability artifact paths (llms.txt, llms-full.txt, sitemaps, robots.txt, search JSON, agent-readability.json) so they aren't rewritten as missing markdown pages.

**Do not** use the [Search](/docs/reference/search.md) area for this. Search covers the static local search index (BM25-style lexical ranking) and optional embeddings — that's the query/retrieval path (search UI / source-grounded answers), not the agent output APIs you asked for.

## When to use the monolithic `/llms-full.txt` fallback

`/llms-full.txt` is the **root full-context fallback** — one file bundling every generated markdown page. Prefer the page-level approach first: navigate `/llms.txt` (and `/docs/llms.txt`) and read the smallest page or pages that answer the task.

Reach for `/llms-full.txt` only as a fallback when per-page navigation isn't sufficient — i.e., when an agent needs the entire docs corpus in a single context fetch rather than selectively pulling individual markdown pages.

Note: groups are used to organize `llms.txt` sections, navigation, search metadata, and `AGENTS.md`. They are **not** published as per-group full-context files by default — full context is the single root `/llms-full.txt`. Groups are for routing, not sharding.
