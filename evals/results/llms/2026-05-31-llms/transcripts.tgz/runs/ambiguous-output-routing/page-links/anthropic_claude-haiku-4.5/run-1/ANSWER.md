# Agent-Facing Output APIs in Leadtype Docs

## Which Docs Area to Use

For agent-facing output APIs, refer to the **`/docs/reference/llm.md`** documentation page.

This page documents the key API functions:
- **generateLlmsTxt** - Generates the product-level `/llms.txt` and docs-scoped `/docs/llms.txt` map for hosted websites
- **generateLLMFullContextFiles** - Generates the root `/llms-full.txt` file
- **generateAgentsMd** - Generates AGENTS.md for npm-bundled docs
- **isAgentReadabilityArtifactPath** - Identifies artifact paths that should not be rewritten as missing markdown pages

This is the focused, agent-specific reference. It explicitly addresses agent-readable output APIs, not search UI.

## When to Use the `/llms-full.txt` Fallback

According to the documentation, `/llms-full.txt` should be used as a **full-context fallback**. Here's when:

1. **Full context needed**: When an agent needs complete context across all docs pages in one file, use `/llms-full.txt` which contains every generated markdown docs page.

2. **Complex multi-page queries**: When a single page's context from `/llms.txt` and its linked pages isn't sufficient for the agent to complete its task.

3. **Fallback behavior**: The `/llms-full.txt` is a root-level artifact designed specifically as a fallback for agents that can't effectively follow the page-level markdown links in the standard `/llms.txt`.

The preferred approach is to use the smallest page or pages from `/llms.txt` that answer the task (as stated in the docs home page), resorting to `/llms-full.txt` only when that granular navigation approach is insufficient.

## Related Documentation

For implementation details:
- **CLI flags**: See `/docs/reference/cli.md` for the `--json` flag output which includes `llmsFullTxt` and `llmsTxt` paths
- **Hosted docs setup**: See `/docs/build/connect-docs-site.md` for how to serve these artifacts via HTTP
- **Overall architecture**: See `/docs/how-it-works.md` for how the pipeline generates these agent-facing artifacts
