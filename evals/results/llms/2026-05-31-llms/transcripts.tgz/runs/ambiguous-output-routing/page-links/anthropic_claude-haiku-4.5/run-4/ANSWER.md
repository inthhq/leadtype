# Agent-Facing Output APIs for Leadtype Docs

## Recommended Docs Area

For agent-facing output APIs, use the **[Reference: LLM files](/docs/reference/llm.md)** documentation.

This section covers:
- `generateLlmsTxt` - writes the product-level `/llms.txt` and docs-scoped `/docs/llms.txt` map for hosted websites
- `generateLLMFullContextFiles` - writes the fallback `/llms-full.txt` file
- `generateAgentsMd` - writes `AGENTS.md` for npm-bundled docs
- `isAgentReadabilityArtifactPath` - identifies agent-readability artifact paths

## When to Use `/llms-full.txt` Fallback

Use the monolithic `/llms-full.txt` fallback in these scenarios:

1. **Limited context window**: When agents have insufficient context to follow the page-level navigation structure in `/llms.txt` and need the complete documentation corpus in a single file.

2. **Offline/bundled scenarios**: When distributing docs as part of an npm package (bundle mode), use `AGENTS.md` with relative markdown links instead. The `/llms-full.txt` fallback is generated automatically by the build system for website mode, not for package bundles.

3. **Full-context requirement**: When comprehensive context of all documentation is required upfront, rather than following hyperlinks incrementally from `/llms.txt`.

## Key Distinction

- **HTTP agents** (URL-based): Start at `/llms.txt` and follow markdown links (preferred approach)
- **Coding agents** (npm packages): Use `AGENTS.md` and relative `docs/*.md` links for offline access
- **Fallback**: `/llms-full.txt` serves as a root full-context fallback for limited-window scenarios
