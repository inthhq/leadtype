# Agent-facing output APIs in the Leadtype docs

## Which docs area to use

Use **Reference → [LLM files](/docs/reference/llm.md)**. That page documents the agent-facing output APIs (the artifacts agents fetch/read), not the search UI:

- `generateLlmsTxt` — writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` map for hosted websites. This is the primary entry point for HTTP agents, which start at `/llms.txt` and follow the page-level markdown links.
- `generateLLMFullContextFiles` — writes the single root `/llms-full.txt` containing every generated markdown docs page.
- `generateAgentsMd` — writes `AGENTS.md` for npm-bundled docs (the entry point for coding agents working inside installed packages). Note it intentionally ignores `product.agentGuidance`, which is meant for website URL routing.
- `isAgentReadabilityArtifactPath` — identifies artifact paths (llms.txt, llms-full.txt, sitemaps, robots.txt, search JSON, agent-readability.json) that should not be rewritten as missing markdown pages.

**Do not use Reference → [Search](/docs/reference/search.md) for this.** That page covers the static, BM25-style local search index and source-grounded answer generation — i.e., the search/query path, not the agent-readable output artifacts you asked about.

## When to use the monolithic `/llms-full.txt` fallback

Prefer the normal flow first: start at `/llms.txt` and follow the page-level markdown links, reading the smallest page(s) that answer the task. This is the recommended path and keeps context small.

Use `/llms-full.txt` (produced by `generateLLMFullContextFiles`) as a **fallback for full context** — when you need every generated markdown docs page in one file rather than navigating individual page links. It is a single root file; groups are *not* published as per-group full-context files by default. Groups exist to organize `llms.txt` sections, navigation, search metadata, and `AGENTS.md` (routing, not sharding), so reach for the monolithic `llms-full.txt` only when whole-corpus context is required and the targeted per-page approach is insufficient.
