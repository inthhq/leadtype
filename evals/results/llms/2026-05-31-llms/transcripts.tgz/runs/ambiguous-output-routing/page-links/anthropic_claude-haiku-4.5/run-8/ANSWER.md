# Agent-Facing Output APIs for Leadtype

## Which Docs Area to Use

For agent-facing output APIs (not search UI), use the **Reference** section of the Leadtype docs:

- **[LLM files](/docs/reference/llm.md)** - Describes the agent-readable artifacts:
  - `generateLlmsTxt` - writes product-level `/llms.txt` and docs-scoped `/docs/llms.txt` map for hosted websites
  - `generateLLMFullContextFiles` - writes the `/llms-full.txt` full-context fallback file
  - `generateAgentsMd` - writes AGENTS.md for npm-bundled docs
  - `isAgentReadabilityArtifactPath` - identifies artifact paths that should not be rewritten

- **[CLI](/docs/reference/cli.md)** - Describes the `leadtype generate` command and its flags, including JSON output that includes artifact paths like `llmsFullTxt`, `docsLlmsTxt`, and `llmsTxt`

- **[Connect a docs site](/docs/build/connect-docs-site.md)** - Explains HTTP agent discovery and which artifacts should be served as static files

## When to Use `/llms-full.txt` Fallback

According to the docs, use the monolithic `/llms-full.txt` fallback when:

1. **You need full context in a single file** - `/llms-full.txt` contains every generated markdown docs page in one file, providing complete context without following links
2. **Groups-based navigation is not sufficient** - The reference says `/llms-full.txt` is the "root full-context fallback," implying it should be used when the grouped `/llms.txt` and page-level links are inadequate
3. **As a backup routing strategy** - The `/llms-full.txt` file is one of the static artifacts that should be served alongside `/llms.txt` for agent requests

The normal flow uses `/llms.txt` as the entry point with page-level markdown links for progressive disclosure. The `/llms-full.txt` serves as a fallback when complete context is needed upfront.
