# Leadtype: Agent-Facing Output APIs vs. the Monolithic Fallback

## Which docs area to use

Use the **Reference** bundle ([`/docs/llms-full/reference.txt`](/docs/llms-full/reference.txt)), and specifically the **LLM files** reference page ([`/docs/reference/llm.md`](/docs/reference/llm.md)). That page documents the agent-facing output APIs:

- `generateLlmsTxt` — writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` map for hosted websites.
- `generateLLMFullContextFiles` — writes the single root `/llms-full.txt` containing every generated markdown docs page.
- `generateAgentsMd` — writes `AGENTS.md` for npm-bundled docs (intentionally ignores `product.agentGuidance`, which targets website URL routing).
- `isAgentReadabilityArtifactPath` — identifies artifact paths (e.g., `llms.txt`, `llms-full.txt`, sitemap files, `robots.txt`, search JSON, `agent-readability.json`) that should not be rewritten as missing markdown pages.

For the CLI side of producing these artifacts, see [`/docs/reference/cli.md`](/docs/reference/cli.md): `leadtype generate` with `--json` reports the generated artifact paths, including `llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, `agentReadabilityJson`, and so on. For wiring these into a hosted site, see [`/docs/build/connect-docs-site.md`](/docs/build/connect-docs-site.md).

**Explicitly not the search area.** `/docs/reference/search.md` covers the static search index, BM25 lexical ranking, and source-grounded answers — that is the search/query UI path, not the agent-facing output APIs you asked for.

## When to use the monolithic `/llms-full.txt` fallback

`/llms-full.txt` is the **root full-context fallback** — one file that concatenates *every* generated markdown docs page. The guiding principle from `/llms.txt` is: **choose the smallest full-context bundle that matches the task.**

So:

- **Prefer the scoped bundles first** (e.g., `/docs/llms-full/reference.txt`, `/docs/llms-full/build.txt`, etc.). They give just the context relevant to one task area.
- **Fall back to the monolithic `/llms-full.txt`** only when:
  - The task spans multiple areas and no single scoped bundle covers it, or
  - You need the complete corpus in one fetch / can't determine which scoped bundle applies.

Note that groups are used for routing (navigation, `llms.txt` sections, search metadata, `AGENTS.md`) and are **not** published as per-group full-context files by default — so the choice is effectively between a task-scoped `/docs/llms-full/*.txt` bundle and the single root `/llms-full.txt`. Use the latter as the broad, last-resort fallback.
