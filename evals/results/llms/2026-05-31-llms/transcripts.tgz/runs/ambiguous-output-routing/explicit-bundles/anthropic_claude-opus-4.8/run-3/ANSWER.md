# Agent-Facing Output APIs in the Leadtype Docs

## Which docs area to use

Use the **Reference → LLM files** page: [`/docs/reference/llm.md`](/docs/reference/llm.md)
(bundled in the Reference full-context file [`/docs/llms-full/reference.txt`](/docs/llms-full/reference.txt)).

This is the page that documents the *agent-facing output APIs* — the functions that
generate the artifacts agents fetch over HTTP. Do **not** use the Search page
(`/docs/reference/search.md`); that covers the search index / query path (the
search UI side), not the agent output bundles you asked for.

### The agent-facing output APIs (from `/docs/reference/llm.md`)

- **`generateLlmsTxt`** — writes the product-level `/llms.txt` and the docs-scoped
  `/docs/llms.txt` map for hosted websites. These are the discovery/routing maps.
- **`generateLLMFullContextFiles`** — writes the single root `/llms-full.txt`
  containing every generated markdown docs page (the monolithic fallback).
- **`generateAgentsMd`** — writes `AGENTS.md` for npm-bundled docs (it ignores
  `product.agentGuidance`, which is meant for website URL routing).
- **`isAgentReadabilityArtifactPath`** — identifies artifact paths that must not be
  rewritten as missing markdown pages (covers `llms.txt`, `llms-full.txt`, sitemap
  files, `robots.txt`, search JSON, and `agent-readability.json`).

For deployment wiring of these artifacts, see also
[`/docs/build/connect-docs-site.md`](/docs/build/connect-docs-site.md), which says to
serve per-page markdown mirrors under `/docs/*.md` and keep `/llms.txt`,
`/llms-full.txt`, sitemaps, `robots.txt`, search JSON, and `agent-readability.json`
as static artifacts.

## When to use the monolithic `/llms-full.txt` fallback

The top of `/llms.txt` gives the guiding rule:

> **Choose the smallest full-context bundle that matches the task.**

So the normal path is:

1. Start at `/llms.txt` (and `/docs/llms.txt`) to **route** to the right area.
2. Fetch the smallest scoped bundle that matches your task — e.g. one of the
   topic full-context files (`get-started`, `authoring`, `build`,
   `package-docs`, `reference`) or an individual `/docs/*.md` markdown page.

Use the **monolithic `/llms-full.txt`** (the single root file produced by
`generateLLMFullContextFiles`, containing *every* generated markdown page) only as a
**fallback** — when a smaller, scoped bundle won't do:

- You genuinely need the **entire docs corpus** in one fetch (broad,
  cross-cutting questions that span multiple areas).
- The routing maps / scoped bundles don't isolate the answer and you need
  everything in a single context.

Note: Leadtype does **not** publish per-group full-context files by default —
groups only organize `llms.txt` sections, navigation, search metadata, and
`AGENTS.md`. There is exactly one root `/llms-full.txt`, so reach for it only when no
narrower bundle fits.
