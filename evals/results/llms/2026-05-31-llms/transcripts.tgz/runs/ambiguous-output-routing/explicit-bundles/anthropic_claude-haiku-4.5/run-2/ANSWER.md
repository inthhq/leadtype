# Agent-Facing Output APIs in Leadtype Docs

## Which Docs Area to Use

Use the **[Reference](/docs/reference/)** section, specifically:

1. **[/docs/reference/llm.md](/docs/reference/llm.md)** - The primary source for agent-facing output APIs
   - Documents the three main output APIs:
     - `generateLlmsTxt()` - Writes product-level `/llms.txt` and docs-scoped `/docs/llms.txt`
     - `generateLLMFullContextFiles()` - Writes `/llms-full.txt` (monolithic fallback)
     - `generateAgentsMd()` - Writes `AGENTS.md` for npm-bundled docs
   - Also covers the utility function `isAgentReadabilityArtifactPath()`

2. **[/docs/reference/cli.md](/docs/reference/cli.md)** - For JSON output paths and artifact generation
   - The `--json` flag outputs all artifact paths including `llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, `agentReadabilityJson`, and others

3. **[/docs/reference/search.md](/docs/reference/search.md)** - For static search index APIs
   - Documents the agent-friendly static search capabilities

## When to Use `/llms-full.txt` Fallback

According to the documentation, use the monolithic `/llms-full.txt` when:

- You need a **complete, self-contained context bundle** with every generated markdown docs page
- You're an agent that cannot navigate structured links between multiple files
- The product-level `/llms.txt` file (which contains per-group maps) is insufficient for your task

The `/llms.txt` is the primary entry point for agents, organized by groups and navigation. Use `/llms-full.txt` as a fallback when you need exhaustive context coverage rather than structured, routed documentation.

## Key Output APIs

The agent-facing APIs are:
- `generateLlmsTxt()` - Structured, routed documentation
- `generateLLMFullContextFiles()` - Monolithic fallback
- `generateAgentsMd()` - Package docs format
- `isAgentReadabilityArtifactPath()` - Path validation utility
