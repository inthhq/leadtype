# Agent-Facing Output APIs in Leadtype

## Documentation Area to Use

For agent-facing output APIs (not search UI), you should use the **[Reference](/docs/llms-full/reference.txt)** documentation area.

Specifically, consult:
- **[/docs/reference/llm.md](/docs/reference/llm.md)** - LLM files and agent-readable bundle APIs
- **[/docs/reference/cli.md](/docs/reference/cli.md)** - CLI flags and JSON output structures

## When to Use `/llms-full.txt` Fallback

Use the monolithic `/llms-full.txt` fallback when:

1. **You need comprehensive context** - When you need access to all generated markdown docs pages in a single file
2. **You're not using grouped/scoped bundles** - The `/llms.txt` provides group-organized navigation, but `/llms-full.txt` contains every page without group filtering
3. **You need a catch-all bundle** - `generateLLMFullContextFiles` creates the root `/llms-full.txt` as a complete fallback when more granular bundles aren't suitable

## Key Agent-Facing APIs

The agent-readable output artifacts available include:
- `/llms.txt` - Product-level navigation map (group-organized)
- `/docs/llms.txt` - Docs-scoped map for hosted websites
- `/llms-full.txt` - Complete full-context file with all pages
- `agent-readability.json` - Machine-readable artifact metadata
- Search index and content files (for source-grounded answer generation)
- `AGENTS.md` - For npm-bundled package docs

These are accessed via the `leadtype generate` command with `--json` flag to get paths to all generated artifacts.
