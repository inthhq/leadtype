# Agent-facing output APIs in the Leadtype docs

## Which docs area to use

Use the **Reference → LLM files** area: `/docs/reference/llm.md`
(bundled in the full-context file `/docs/llms-full/reference.txt`).

This is the area that documents the *agent-facing output APIs* — the functions
that emit agent-readable artifacts — rather than the search UI. The relevant
APIs are:

- **`generateLlmsTxt`** — writes the product-level `/llms.txt` and the
  docs-scoped `/docs/llms.txt` map for hosted websites.
- **`generateLLMFullContextFiles`** — writes the single root `/llms-full.txt`
  containing every generated markdown docs page.
- **`generateAgentsMd`** — writes `AGENTS.md` for npm-bundled docs (ignores
  `product.agentGuidance`, which is meant for website URL routing).
- **`isAgentReadabilityArtifactPath`** — identifies artifact paths that should
  not be rewritten as missing markdown pages (covers `llms.txt`,
  `llms-full.txt`, sitemap files, `robots.txt`, search JSON, and
  `agent-readability.json`).

For how these artifacts are actually served/wired in a hosted build, see
**Build → Connect a docs site** (`/docs/build/connect-docs-site.md`).

### Why NOT the search area

`/docs/reference/search.md` covers the static local search index and BM25-style
ranking / source-grounded answers. That is the search retrieval path, not the
agent output APIs, so it is not the area you want here.

## When to use the monolithic `/llms-full.txt` fallback

`/llms-full.txt` is the single root file produced by
`generateLLMFullContextFiles` that concatenates **every** generated markdown
docs page. The guiding rule from `/llms.txt` is:

> Choose the smallest full-context bundle that matches the task.

So the normal workflow is:

1. Start at `/llms.txt` (and `/docs/llms.txt`) to route to the right topic.
2. Pull the **scoped** full-context bundle for that topic, e.g.
   `/docs/llms-full/reference.txt`, `/docs/llms-full/build.txt`, etc.
3. Fall back to the **monolithic `/llms-full.txt`** only when no single scoped
   bundle is sufficient — i.e. when you need the entire corpus at once
   (cross-cutting questions spanning multiple groups, or when you can't
   determine which scoped bundle applies).

Important: Leadtype does **not** publish per-group full-context files by
default. Groups organize `llms.txt` sections, navigation, search metadata, and
`AGENTS.md`, but they are used for routing, not for sharding into separate
full-context files. The only root-level whole-corpus file is `/llms-full.txt`,
which is why it serves as the fallback.
