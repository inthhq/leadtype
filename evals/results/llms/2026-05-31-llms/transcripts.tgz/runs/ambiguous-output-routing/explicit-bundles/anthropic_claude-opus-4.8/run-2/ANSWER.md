# Agent-facing output APIs in the Leadtype docs

## Which docs area to use

Use the **Reference → LLM files** page: [`/docs/reference/llm.md`](/docs/reference/llm.md). This is the docs area covering the agent-facing **output** APIs (the LLM bundle APIs). It is reachable from `/llms.txt` under "Full Context Bundles → Reference," and the full-context version is at `/docs/llms-full/reference.txt`.

This is the right area because it documents the functions that *produce* the agent-readable artifacts, rather than the search UI/query path:

- `generateLlmsTxt` — writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` map for hosted websites.
- `generateLLMFullContextFiles` — writes the single root `/llms-full.txt` containing every generated markdown docs page.
- `generateAgentsMd` — writes `AGENTS.md` for npm-bundled docs (ignores `product.agentGuidance`, which is for website URL routing).
- `isAgentReadabilityArtifactPath` — identifies artifact paths (llms.txt, llms-full.txt, sitemap files, robots.txt, search JSON, agent-readability.json) that should not be rewritten as missing markdown pages.

Supporting context:
- The **CLI** reference ([`/docs/reference/cli.md`](/docs/reference/cli.md)) describes how `leadtype generate` emits these artifacts and, with `--json`, prints the artifact paths (`llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, `agentReadabilityJson`, `sitemapXml`, `sitemapMd`, `robotsTxt`, `searchIndex`, `searchContent`).
- The **Build → Connect a docs site** page ([`/docs/build/connect-docs-site.md`](/docs/build/connect-docs-site.md)) covers serving these artifacts in website mode.

### What to avoid for this task
The **Search** reference ([`/docs/reference/search.md`](/docs/reference/search.md)) covers the static search index and the runtime query/answer path (the search UI side). Since you want agent-facing *output* APIs and explicitly *not* the search UI, the Search page is not the area to use here.

## When to use the monolithic `/llms-full.txt` fallback

`/llms-full.txt` is the **single root file containing every generated markdown docs page**. It is the broad, monolithic fallback — use it when you want the entire corpus in one fetch rather than a targeted, smaller bundle.

The guiding principle from `/llms.txt` is: **"Choose the smallest full-context bundle that matches the task."** So:

- **Prefer a scoped bundle first.** If your task maps to a specific area (e.g., Reference, Build, Authoring, Get Started), fetch that area's full-context bundle (e.g., `/docs/llms-full/reference.txt`). For agent output APIs specifically, that means the Reference bundle.
- **Fall back to `/llms-full.txt`** when no single scoped bundle covers the task — i.e., when you need the complete set of docs pages at once, or your task spans multiple areas and you'd otherwise have to stitch several bundles together.

Note: groups organize `llms.txt` sections, navigation, search metadata, and `AGENTS.md`, but are **not** published as per-group full-context files by default. So the only "everything" full-context file available is the root `/llms-full.txt` — which is exactly why it serves as the monolithic fallback.
