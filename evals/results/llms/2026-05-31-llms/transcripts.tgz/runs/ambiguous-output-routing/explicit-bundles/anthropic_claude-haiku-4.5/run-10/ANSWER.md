# Agent-Facing Output APIs in Leadtype Docs

## Which Docs Area to Use

For **agent-facing output APIs** (not search UI), use the **[Reference](/docs/reference/cli.md)** docs area, specifically:

1. **[/docs/reference/llm.md](/docs/reference/llm.md)** - Details about LLM bundle API functions:
   - `generateLlmsTxt()` - Generates product-level `/llms.txt` and docs-scoped `/docs/llms.txt` maps
   - `generateLLMFullContextFiles()` - Generates the root `/llms-full.txt` file
   - `generateAgentsMd()` - Generates AGENTS.md for npm-bundled docs
   - `isAgentReadabilityArtifactPath()` - Identifies artifact paths for agent-readable output

2. **[/docs/reference/cli.md](/docs/reference/cli.md)** - Output API details:
   - The `--json` flag that enables JSON output
   - Website-mode object structure with keys like `llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, `agentReadabilityJson`, etc.

## When to Use the `/llms-full.txt` Fallback

Use the monolithic `/llms-full.txt` fallback when:

- You need **every generated markdown docs page** in a single, comprehensive context bundle
- You cannot identify which specific groups or sections are relevant to your task
- You need the complete documentation without having to navigate separate pages

The `/llms-full.txt` is the **root full-context fallback** - it contains all pages that the narrower bundles organize by group, but in one consolidated file. As per the `/llms.txt` guidance: "Choose the smallest full-context bundle that matches the task" - so use `/llms-full.txt` only when a smaller, scoped bundle (like the Reference bundle) won't suffice.
