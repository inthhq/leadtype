# Agent-Facing Output APIs - Leadtype Docs Guide

## Which Docs Area to Use

For agent-facing output APIs (not search UI), use the **[Reference](/docs/llms-full/reference.txt)** docs area.

Specifically, consult the **[LLM files](/docs/reference/llm.md)** page, which covers:
- `generateLlmsTxt`: Writes the product-level `/llms.txt` and docs-scoped `/docs/llms.txt` maps
- `generateLLMFullContextFiles`: Writes the monolithic `/llms-full.txt` file
- `generateAgentsMd`: Writes `AGENTS.md` for npm-bundled docs
- `isAgentReadabilityArtifactPath`: Identifies artifact paths that should not be rewritten as missing markdown pages

## When to Use the `/llms-full.txt` Fallback

Use the monolithic `/llms-full.txt` when you need **every generated markdown docs page in a single file**. 

According to the docs:
- `generateLLMFullContextFiles` writes one root `/llms-full.txt` file containing every generated markdown docs page
- This is the full-context fallback for when you want everything
- Groups still organize sections in `/llms.txt`, but are not published as per-group full-context files by default

In practice, you should choose the smallest full-context bundle that matches your task. Start with `/llms.txt` (the product-level map), follow to smaller bundles like `/docs/llms-full/reference.txt`, and only fall back to `/llms-full.txt` when you need comprehensive coverage of all pages.
