# Agent-facing output APIs in the Leadtype docs

## Which docs area to use

Use the **Reference → LLM files** page: `/docs/reference/llm.md` (bundled in `/docs/llms-full/reference.txt`).

This is the area that documents the agent-facing *output* APIs — the functions that emit the agent-readable artifacts — as opposed to the search UI/query path, which lives in `/docs/reference/search.md`.

The relevant output APIs documented there are:

- **`generateLlmsTxt`** — writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` navigation map for hosted websites.
- **`generateLLMFullContextFiles`** — writes the single root `/llms-full.txt` containing every generated markdown docs page.
- **`generateAgentsMd`** — writes `AGENTS.md` for npm-bundled docs (intentionally ignores `product.agentGuidance`, which is for website URL routing).
- **`isAgentReadabilityArtifactPath`** — identifies artifact paths (llms.txt, llms-full.txt, sitemap files, robots.txt, search JSON, agent-readability.json) that should not be rewritten as missing markdown pages.

If you want the CLI surface for producing these (e.g. `--bundle`, `--json` output keys like `llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, `agentReadabilityJson`), see `/docs/reference/cli.md`.

What to **avoid** for this task: `/docs/reference/search.md` covers the static search index, BM25 ranking, and source-grounded answers — that's the search side, not the agent output APIs you asked about.

## When to use the monolithic `/llms-full.txt` fallback

`/llms-full.txt` is the **root, full-context fallback**: a single file containing *every* generated markdown docs page, written by `generateLLMFullContextFiles`.

Per the docs guidance ("Choose the smallest full-context bundle that matches the task"), the intended flow is:

1. **Start at `/llms.txt`** to discover the structure and pick the smallest scoped full-context bundle that matches your task (e.g. `/docs/llms-full/reference.txt`, `/docs/llms-full/build.txt`, etc.).
2. **Fall back to the monolithic `/llms-full.txt`** only when no single scoped bundle covers what you need — i.e., when you need the entire corpus in one shot, or your task spans multiple groups.

Note that groups are used for **routing**, not sharding: full context is *not* published as per-group full-context files by default. So when scoped/per-group splitting isn't enough and you genuinely need everything, the monolithic `/llms-full.txt` is the catch-all fallback.
