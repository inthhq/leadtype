# Agent-Facing Output APIs in Leadtype Docs

## Which Docs Area to Use

For agent-facing output APIs (not search UI), use the **[Reference](/docs/reference/)** docs area, specifically:

- **[LLM files](/docs/reference/llm.md)** - Details the three core API functions for generating agent-readable artifacts:
  - `generateLlmsTxt` - Writes product-level `/llms.txt` and docs-scoped `/docs/llms.txt` map
  - `generateLLMFullContextFiles` - Writes the monolithic `/llms-full.txt` fallback
  - `generateAgentsMd` - Writes AGENTS.md for npm-bundled docs

- **[CLI](/docs/reference/cli.md)** - Documents the `leadtype generate` command and its output, including the JSON output format that specifies artifact paths

## When to Use the Monolithic `/llms-full.txt` Fallback

The `/llms-full.txt` file should be used as a fallback in these scenarios:

1. **When agents cannot follow links** - If an agent cannot or should not make multiple HTTP requests to fetch individual markdown pages, the monolithic bundle contains every generated markdown docs page in one file.

2. **As a complete context fallback** - When an agent needs complete documentation context without making additional HTTP calls to fetch pages referenced in `/llms.txt`.

3. **For groups that aren't individually routed** - While groups organize sections in `/llms.txt`, individual per-group full-context files are not published by default; instead, all content is consolidated into the single `/llms-full.txt`.

## Best Practice

Follow the Leadtype principle: **"Choose the smallest full-context bundle that matches the task."**

Start with `/llms.txt` (the site root map) and have agents follow markdown links to individual pages. Only fall back to `/llms-full.txt` when the agent cannot fetch multiple resources or needs complete offline context.
