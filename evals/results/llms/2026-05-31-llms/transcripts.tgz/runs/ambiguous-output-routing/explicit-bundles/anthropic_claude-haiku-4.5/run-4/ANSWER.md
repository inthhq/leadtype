# Agent-Facing Output APIs for Leadtype

## Recommended Docs Area

Use the **[Reference](/docs/reference/)** docs area, specifically:

- **[LLM files](/docs/reference/llm.md)** - Documents the agent-facing LLM bundle APIs:
  - `generateLlmsTxt()` - Writes product-level `/llms.txt` and docs-scoped `/docs/llms.txt`
  - `generateLLMFullContextFiles()` - Writes the monolithic `/llms-full.txt`
  - `generateAgentsMd()` - Writes AGENTS.md for npm-bundled docs
  - `isAgentReadabilityArtifactPath()` - Identifies artifact paths for agent consumption

- **[CLI](/docs/reference/cli.md)** - Documents the `leadtype generate --json` flag output, which includes paths to all generated agent-readable artifacts (llmsFullTxt, docsLlmsTxt, llmsTxt, agentReadabilityJson, etc.)

## When to Use the `/llms-full.txt` Fallback

Use the monolithic `/llms-full.txt` fallback when:

1. **You need complete context** - It contains every generated markdown docs page in a single file
2. **You want simplicity** - It eliminates the need to navigate hierarchical group-organized sections
3. **Groups are routing-only** - Groups organize llms.txt sections, navigation, and search metadata, but not the full-context file structure
4. **Context size permits** - When your agent has sufficient token budget for the comprehensive bundle

Otherwise, use the more granular `/llms.txt` (product-level) or `/docs/llms.txt` (docs-scoped) for targeted, smaller-context access.
