# Agent-Facing Output APIs in Leadtype Docs

## Which Docs Area to Use

Use the **Reference** section for agent-facing output APIs:
- **URL**: `/docs/llms-full/reference.txt` (full context bundle)
- **Specific page**: `/docs/reference/llm.md` (LLM files API documentation)

The Reference bundle contains:
- **CLI** (`/docs/reference/cli.md`): JSON output structures and artifact paths
- **LLM files** (`/docs/reference/llm.md`): `generateLlmsTxt()`, `generateLLMFullContextFiles()`, and `generateAgentsMd()` APIs
- **Search** (`/docs/reference/search.md`): Static search index APIs (agent-readable, not search UI)

## Key Agent-Facing Output APIs

1. **`generateLlmsTxt()`** - Writes `/llms.txt` (product-level) and `/docs/llms.txt` (docs-scoped) maps
2. **`generateLLMFullContextFiles()`** - Writes `/llms-full.txt` containing all generated markdown
3. **`generateAgentsMd()`** - Writes `AGENTS.md` for npm-bundled docs
4. **Search Index** - Static local search over generated markdown (edge-safe, no database required)
5. **CLI JSON output** - When `--json` flag is enabled, provides structured paths to all artifacts

## When to Use `/llms-full.txt` Fallback

Use `/llms-full.txt` as a **fallback** when:
- The primary `/llms.txt` navigation map is insufficient for your use case
- You need comprehensive, monolithic context containing **every generated markdown page** in one file
- You want complete documentation without navigating through `/llms.txt` sections and groups

The `/llms-full.txt` fallback contains all markdown pages but still respects group organization for navigation, search metadata, and AGENTS.md purposes. It is **not** published as per-group files by default—only as a single root file.

## Important Notes

- These are **agent-facing APIs**, not search UI
- The search index API supports source-grounded answer generation
- Groups organize content for routing, not sharding (per the documentation guidance)
- The `/docs/llms-full/reference.txt` bundle is the recommended starting point for API reference needs
