# Agent-Facing Output APIs in Leadtype Docs

## Docs Area to Use

For agent-facing output APIs (not search UI), use the **[Reference](/docs/reference/llm.md)** docs area, specifically the **[LLM files](/docs/reference/llm.md)** page.

This page documents the agent-readable APIs including:
- `generateLlmsTxt`: Generates `/llms.txt` (product-level) and `/docs/llms.txt` (docs-scoped) for hosted websites
- `generateLLMFullContextFiles`: Generates the monolithic `/llms-full.txt` file
- `generateAgentsMd`: Generates `AGENTS.md` for npm-bundled docs
- `isAgentReadabilityArtifactPath`: Identifies artifact paths that serve agent-readable content

## When to Use `/llms-full.txt`

Use the monolithic `/llms-full.txt` fallback when you need:
- **Complete context**: Every generated markdown docs page in a single file
- **Simplified access**: A single request instead of navigating the modular `/llms.txt` structure
- **Offline/archive use**: A comprehensive snapshot of all documentation

The `/llms-full.txt` file is generated alongside the modular `/llms.txt` system. Groups still organize the content and metadata, but `/llms-full.txt` contains the complete documentation without requiring multiple file fetches or navigation through the docs index.

## Key References

- **[/docs/reference/llm.md](/docs/reference/llm.md)**: LLM files API reference (primary source)
- **[/docs/build/connect-docs-site.md](/docs/build/connect-docs-site.md)**: Deployment guidance for serving these APIs
- **[/llms.txt](/llms.txt)**: Root bundle map showing all available full-context options
