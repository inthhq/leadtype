# Agent-facing output APIs in the Leadtype docs

## Which docs area to use

Use the **Reference → LLM files** page: `/docs/reference/llm.md`
(grouped under the Reference full-context bundle `/docs/llms-full/reference.txt`).

This is the area that documents the *agent-facing output APIs*, as opposed to the
search UI (which lives in `/docs/reference/search.md` and is about query/ranking,
not output generation).

The relevant output APIs there are:

- **`generateLlmsTxt`** — writes the product-level `/llms.txt` and the docs-scoped
  `/docs/llms.txt` map for hosted websites. This is your primary, discoverable
  agent entry point (the navigable map of bundles).
- **`generateLLMFullContextFiles`** — writes the single root `/llms-full.txt`
  containing every generated markdown docs page.
- **`generateAgentsMd`** — writes `AGENTS.md` for npm-bundled docs (deliberately
  ignores `product.agentGuidance`, which is meant for website URL routing).
- **`isAgentReadabilityArtifactPath`** — identifies artifact paths
  (`llms.txt`, `llms-full.txt`, sitemap files, `robots.txt`, search JSON,
  `agent-readability.json`) that should not be rewritten as missing markdown pages.

For deployment/serving details of these artifacts, see
**Build → Connect a docs site** (`/docs/build/connect-docs-site.md`), which covers
website mode, serving markdown to AI agents via `Accept: text/markdown`, and keeping
`/llms.txt`, `/llms-full.txt`, sitemaps, `robots.txt`, and search JSON as static
artifacts.

**Do not use** `/docs/reference/search.md` for this task — that documents the static
search index, BM25-style lexical ranking, and source-grounded answers (the search
side), not the agent output APIs.

## When to use the monolithic `/llms-full.txt` fallback

The guiding principle from `/llms.txt` is: **choose the smallest full-context bundle
that matches the task.** So prefer the scoped, navigable entry points first:

1. Start at **`/llms.txt`** to find the right scoped bundle.
2. Use the **per-area full-context bundles** (e.g. `/docs/llms-full/reference.txt`,
   `/docs/llms-full/build.txt`) when you need full context for one task area.
3. Fetch **individual markdown pages** (e.g. `/docs/reference/llm.md`) for a single
   targeted page.

Fall back to the **monolithic `/llms-full.txt`** only when you genuinely need
*every* generated markdown docs page in one document — i.e. when the task spans the
whole corpus, when scoped bundles don't isolate what you need, or when you want a
single complete snapshot. Note that Leadtype publishes **only one** root
`/llms-full.txt`; groups are used for routing/navigation/search/`AGENTS.md`
organization, not for per-group sharded full-context files. So `/llms-full.txt` is
the catch-all, last-resort context source, not the default.
