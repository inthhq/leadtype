# Agent-Facing Output APIs in Leadtype Docs

## Which Docs Area to Use

For agent-facing output APIs (not search UI), use the **[Reference](/docs/reference/llm.md)** docs area, specifically the **"LLM files"** page.

This page documents the core agent-readable APIs:

- **generateLlmsTxt**: Writes the product-level `/llms.txt` and docs-scoped `/docs/llms.txt` map for hosted websites
- **generateLLMFullContextFiles**: Writes the root `/llms-full.txt` file containing every generated markdown docs page
- **generateAgentsMd**: Writes AGENTS.md for npm-bundled docs
- **isAgentReadabilityArtifactPath**: Identifies artifact paths that should not be rewritten as missing markdown pages (covers llms.txt, llms-full.txt, sitemap files, robots.txt, search JSON, and agent-readability.json)

## When to Use the `/llms-full.txt` Fallback

Use the **monolithic `/llms-full.txt` fallback** when:

1. **You need complete context across all docs**: `generateLLMFullContextFiles` writes one root `/llms-full.txt` file containing every generated markdown docs page
2. **Groups are organized for routing only**: Groups still organize llms.txt sections, navigation, search metadata, and AGENTS.md, but they are not published as per-group full-context files by default
3. **You need a single comprehensive file**: Instead of using the smaller, scoped `/llms.txt` or `/docs/llms.txt`, the `/llms-full.txt` provides everything in one bundle

In summary: Use the specific `/llms.txt` or `/docs/llms.txt` for targeted access to your relevant docs sections, and fall back to `/llms-full.txt` when you need the complete documentation in a single file.
