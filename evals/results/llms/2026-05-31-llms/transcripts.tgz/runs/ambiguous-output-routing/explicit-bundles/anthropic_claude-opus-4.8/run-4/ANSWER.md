# Agent-facing output APIs in Leadtype (not search UI)

## Which docs area to use

Use the **Reference → LLM files** page: [`/docs/reference/llm.md`](/docs/reference/llm.md)
(bundled in the Reference full-context file [`/docs/reference.txt`](/docs/llms-full/reference.txt)).

This is the area that documents the *agent-facing output APIs* — the functions
that produce the agent-readable artifacts — as opposed to **Search**
(`/docs/reference/search.md`), which covers the search/retrieval path (search UI
and source-grounded answers), and is **not** what you want here.

### The agent-facing output APIs (from `/docs/reference/llm.md`)

- **`generateLlmsTxt`** — writes the product-level `/llms.txt` and the
  docs-scoped `/docs/llms.txt` map for hosted websites.
- **`generateLLMFullContextFiles`** — writes the single root `/llms-full.txt`
  file containing every generated markdown docs page.
- **`generateAgentsMd`** — writes `AGENTS.md` for npm-bundled docs (intentionally
  ignores `product.agentGuidance`, which is written for website URL routing).
- **`isAgentReadabilityArtifactPath`** — identifies artifact paths that should
  not be rewritten as missing markdown pages (covers `llms.txt`,
  `llms-full.txt`, sitemap files, `robots.txt`, search JSON, and
  `agent-readability.json`).

### Related CLI surface (`/docs/reference/cli.md`)

`leadtype generate --json` prints the paths of the generated artifacts. In
website mode the JSON includes: `llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`,
`agentReadabilityJson`, `sitemapXml`, `sitemapMd`, `robotsTxt`, `searchIndex`,
and `searchContent`.

## When to use the monolithic `/llms-full.txt` fallback

Start at `/llms.txt` and choose the **smallest full-context bundle** that matches
the task — for output-API questions that is the Reference bundle, and the
specific page above. The per-task `/docs/llms-full/*.txt` bundles are the
preferred, scoped context.

Reach for the **root monolithic `/llms-full.txt`** only as a *fallback* when a
single scoped bundle isn't enough — i.e., when you need the entire corpus in one
fetch:

- It is the one root file that contains **every generated markdown docs page**
  (produced by `generateLLMFullContextFiles`).
- Use it when a task spans multiple areas and no single full-context bundle
  covers it, or when you want the complete docs in a single request rather than
  navigating individual pages/bundles.
- Note: groups are used for **routing**, not sharding — Leadtype does **not**
  publish per-group full-context files by default, so `/llms-full.txt` is the
  catch-all whole-corpus option.

In short: for the agent-facing output APIs, use **Reference / `/docs/reference/llm.md`**
(not Search), and fall back to **`/llms-full.txt`** only when you need the entire
docs corpus in one bundle and the smaller scoped bundles don't suffice.
