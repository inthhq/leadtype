# Agent-facing output APIs vs. search UI

## Which docs area to use

Use **Reference → LLM files** (`/docs/reference/llm.md`). This is the area that documents the agent-facing *output* APIs — the functions that generate the agent-readable artifacts:

- `generateLlmsTxt` — writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` map for hosted websites.
- `generateLLMFullContextFiles` — writes the single root `/llms-full.txt` full-context fallback containing every generated markdown docs page.
- `generateAgentsMd` — writes `AGENTS.md` for npm-bundled docs.
- `isAgentReadabilityArtifactPath` — identifies artifact paths that must stay static (`llms.txt`, `llms-full.txt`, sitemaps, `robots.txt`, search JSON, `agent-readability.json`).

The CLI side of these outputs is in **Reference → CLI** (`/docs/reference/cli.md`): `leadtype generate` with `--json` reports the produced artifact paths, including `llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, `agentReadabilityJson`, sitemaps, `robotsTxt`, `searchIndex`, and `searchContent`.

**Do not** use **Reference → Search** (`/docs/reference/search.md`) for this. That area describes the build-time search index and the runtime query/answer path — i.e., the search experience, not the agent-facing output APIs you asked about.

## When to use the monolithic `/llms-full.txt` fallback

`/llms-full.txt` is the single root file produced by `generateLLMFullContextFiles` that concatenates **every** generated markdown docs page. It is a fallback, not the default path.

Prefer the structured route first (per the docs guidance "choose the smallest full-context bundle that matches the task"):

1. Start at `/llms.txt` and follow its markdown links.
2. Use the smallest matching **full-context bundle** (e.g. `/docs/llms-full/reference.txt`, `/docs/llms-full/build.txt`) that covers the task.

Use the monolithic `/llms-full.txt` only when you need the entire corpus in one request and no narrower bundle suffices — for example, broad cross-cutting questions spanning multiple areas, or when an agent cannot follow links and needs all pages inlined at once. Note that groups organize `llms.txt` sections/navigation/search metadata but are **not** published as per-group full-context files by default, so `/llms-full.txt` is the all-in-one option when a single per-group bundle isn't enough.

Keep `/llms-full.txt` (like `/llms.txt`, sitemaps, `robots.txt`, search JSON, and `agent-readability.json`) served as a static artifact — it should not be rewritten as a missing markdown page.
