# Agent-Facing Output APIs in Leadtype

## Which docs area to use

Use the **Reference → LLM files** area: `/docs/reference/llm.md`
(bundled in the full-context file `/docs/llms-full/reference.txt`).

This is the area that documents the **agent-facing output APIs** — the functions
that produce the HTTP-discoverable artifacts agents consume. Specifically:

- **`generateLlmsTxt`** — writes the product-level `/llms.txt` and the
  docs-scoped `/docs/llms.txt` map for hosted websites.
- **`generateLLMFullContextFiles`** — writes the single root `/llms-full.txt`
  containing every generated markdown docs page.
- **`generateAgentsMd`** — writes `AGENTS.md` for npm-bundled docs (intentionally
  ignores `product.agentGuidance`, which is meant for website URL routing).
- **`isAgentReadabilityArtifactPath`** — identifies artifact paths that should
  not be rewritten as missing markdown (covers `llms.txt`, `llms-full.txt`,
  sitemap files, `robots.txt`, search JSON, and `agent-readability.json`).

For the CLI surface that emits these artifacts, see `/docs/reference/cli.md`:
`leadtype generate --json` prints the artifact paths, including `llmsFullTxt`,
`docsLlmsTxt`, `llmsTxt`, `agentReadabilityJson`, sitemap files, `robotsTxt`,
`searchIndex`, and `searchContent`.

### What to *avoid* for this task

Do **not** use the **Search** area (`/docs/reference/search.md`). That documents
the static lexical (BM25-style) search index and source-grounded answer path —
it is the search/retrieval surface, not the agent-facing output APIs you asked
about. (Note: Leadtype's search is an index/query API, not a separate "search
UI"; either way it is the wrong area for generating agent output artifacts.)

## When to use the monolithic `/llms-full.txt` fallback

`/llms-full.txt` is the **single root file that concatenates every generated
markdown docs page**. Per the docs guidance ("Choose the smallest full-context
bundle that matches the task"):

- **Prefer the smallest matching bundle first.** Use a scoped full-context
  bundle (e.g. `/docs/llms-full/reference.txt`, `get-started.txt`,
  `authoring.txt`, `build.txt`, `package-docs.txt`) or an individual
  `/docs/**/*.md` page when the task maps to one area.
- **Fall back to the monolithic `/llms-full.txt`** only when you need the
  **entire corpus in one fetch** — i.e., the task spans multiple areas, you
  can't predict which page holds the answer, or no single scoped bundle is
  sufficient.

Note that Leadtype does **not** publish per-group full-context files by default;
groups only organize `llms.txt` sections, navigation, search metadata, and
`AGENTS.md`. So the choice is effectively: a scoped `llms-full/*.txt` bundle (or
a specific `.md` page) for targeted work, versus the one monolithic
`/llms-full.txt` as the catch-all fallback.
