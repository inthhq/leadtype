# Agent-Facing Output APIs in Leadtype

## Which docs area to use

Use the **Reference → LLM files** doc (`/docs/reference/llm.md`), which documents the agent-facing output/bundle APIs. This is the right area because you want output APIs, **not** the search UI.

The relevant APIs there are:

- **`generateLlmsTxt`** — writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` navigation map for hosted websites.
- **`generateLLMFullContextFiles`** — writes the single root `/llms-full.txt` file containing every generated markdown docs page.
- **`generateAgentsMd`** — writes `AGENTS.md` for npm-bundled docs (ignores `product.agentGuidance`, which is website-only).
- **`isAgentReadabilityArtifactPath`** — identifies agent-readability artifact paths (llms.txt, llms-full.txt, sitemaps, robots.txt, search JSON, agent-readability.json) so they aren't rewritten as missing markdown.

Supporting context:
- **Reference → CLI** (`/docs/reference/cli.md`): `leadtype generate` writes these artifacts; with `--json` it prints paths including `llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, `agentReadabilityJson`, etc.
- **Build → Connect a docs site** (`/docs/build/connect-docs-site.md`): how to serve these artifacts over HTTP for agents.

**Avoid the Search area** (`/docs/reference/search.md`) for this task — that's the search/query path (BM25 ranking, search index, answer generation), i.e. the search UI/retrieval side, not the agent output APIs.

## When to use the monolithic `/llms-full.txt` fallback

The guiding rule from `/llms.txt` is: **choose the smallest full-context bundle that matches the task.** So you should normally reach for the scoped bundles first:

- The per-topic full-context bundles under `/docs/llms-full/*.txt` (Get Started, Authoring, Build, Ship Package Docs, Reference), or
- Individual markdown mirrors under `/docs/*.md`.

Use the monolithic **root `/llms-full.txt`** (produced by `generateLLMFullContextFiles`) as a **fallback** only when:

- You actually need the entire corpus — every generated markdown docs page in one file — rather than a single topic area.
- No smaller scoped bundle adequately covers the task.

Note: Leadtype does **not** publish per-group full-context files by default. Groups organize `llms.txt` sections, navigation, search metadata, and `AGENTS.md` (routing, not sharding). So when scoped `/docs/llms-full/*.txt` bundles don't fit, the single root `/llms-full.txt` is the all-in-one fallback.
