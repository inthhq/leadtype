# Agent-facing output APIs in the Leadtype docs

## Which docs area to use

Use the **`/docs/reference/llm.md`** page (the "LLM files" reference). This is the
docs area that describes the agent-facing **output** APIs — the functions that
generate the agent-readable artifacts:

- **`generateLlmsTxt`** — writes the product-level `/llms.txt` and the
  docs-scoped `/docs/llms.txt` routing map for hosted websites.
- **`generateLLMFullContextFiles`** — writes the single root `/llms-full.txt`
  containing every generated markdown docs page.
- **`generateAgentsMd`** — writes `AGENTS.md` for npm-bundled docs (deliberately
  ignores `product.agentGuidance`, which is meant for website URL routing).
- **`isAgentReadabilityArtifactPath`** — identifies artifact paths
  (`llms.txt`, `llms-full.txt`, sitemap files, `robots.txt`, search JSON,
  `agent-readability.json`) that should not be rewritten as missing markdown
  pages.

Supporting context for how these artifacts are emitted/served:

- `/docs/reference/cli.md` — `leadtype generate` produces these artifacts; with
  `--json` it prints paths including `llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`,
  `agentReadabilityJson`, etc.
- `/docs/build/connect-docs-site.md` — how to expose `/llms.txt` and `/docs/*.md`
  mirrors over HTTP for agents.
- `/docs/package-docs/bundle.md` — offline `AGENTS.md` + relative `docs/*.md`
  bundle for coding agents inside `node_modules`.

**Do not use** `/docs/reference/search.md`. That covers the search/query path
(BM25 lexical ranking, optional embeddings) — i.e., the search UI/retrieval
side, not the agent-facing output APIs you asked about.

## When to use the monolithic `/llms-full.txt` fallback

`/llms-full.txt` is the all-docs full-context bundle: every generated markdown
page flattened into one file. Use it as a **fallback when task-specific context
is needed** and the normal navigation path isn't enough.

The intended flow is:

1. Agents start at `/llms.txt`, which is a minimal routing map, and follow the
   markdown links (and `/docs/llms.txt` group routing) to the specific pages
   they need.
2. Reach for the monolithic `/llms-full.txt` only when you need broad,
   task-specific context all at once — for example when the right page isn't
   obvious, when a task spans many pages, or when you want the entire corpus in
   a single read rather than chasing individual links.

Notes:

- `/llms-full.txt` is a **website-only** artifact. In bundle/package mode it is
  skipped (offline agents use `AGENTS.md` + relative `docs/*.md` instead).
- Prefer targeted pages (via `/llms.txt` → `/docs/...md`) first; the monolithic
  file is a heavier fallback, not the default entry point.
