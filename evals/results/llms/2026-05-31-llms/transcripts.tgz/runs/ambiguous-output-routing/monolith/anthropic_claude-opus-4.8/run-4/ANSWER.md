# Agent-facing output APIs vs. search UI — which docs area, and when to use `/llms-full.txt`

## Which docs area to use

Use **`/docs/reference/llm.md`** ("LLM files"). This is the docs area that documents the **agent-facing output APIs** — the functions/artifacts that produce agent-readable output:

- `generateLlmsTxt` — writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` map for hosted websites.
- `generateLLMFullContextFiles` — writes the single root `/llms-full.txt` file containing every generated markdown docs page.
- `generateAgentsMd` — writes `AGENTS.md` for npm-bundled docs (deliberately ignores `product.agentGuidance`, which is for website URL routing).
- `isAgentReadabilityArtifactPath` — identifies artifact paths (llms.txt, llms-full.txt, sitemap files, robots.txt, search JSON, agent-readability.json) that should not be rewritten as missing markdown pages.

This is distinct from the **search UI / retrieval** area documented in `/docs/reference/search.md`, which covers the static BM25-style local search index and (optional) embeddings. That is the search path, **not** the agent output API surface you asked about. So for agent-facing outputs, stay in `/docs/reference/llm.md` and avoid the search reference for this purpose.

(Supporting context, if needed: `/docs/reference/cli.md` shows the `leadtype generate --json` output naming these artifacts — `llmsTxt`, `docsLlmsTxt`, `llmsFullTxt`, `agentReadabilityJson`, etc.; and `/docs/package-docs/bundle.md` covers the `AGENTS.md` bundle path for npm packages.)

## When to use the monolithic `/llms-full.txt` fallback

`/llms.txt` itself instructs: *"Read the single all-docs full-context file when task-specific context is needed."*

Use `/llms-full.txt` as a **fallback only when you need the full task-specific context** — i.e., when the lean, link-following flow (`/llms.txt` → individual `/docs/**/*.md` pages) doesn't give you enough, or when you'd rather load every generated markdown page flattened into one file rather than navigate links.

In short:
- **Default / preferred:** start at `/llms.txt` and follow the markdown links to the specific page(s) you need (e.g., `/docs/reference/llm.md`). Groups are for routing, not sharding.
- **Fallback:** pull the monolithic `/llms-full.txt` when task-specific context spans many pages or when you need everything in one flattened file. Note it is the **only** full-context file published by default — per-group full-context files are not emitted.

### Caveat
`/llms-full.txt` is a **website-only artifact**. It is *not* produced in bundle mode (`leadtype generate --bundle`), which instead writes `AGENTS.md` plus relative `./docs/*.md` links for coding agents reading inside `node_modules` offline. So the `/llms-full.txt` fallback applies to the **hosted website / HTTP-agent flow**, not the npm-bundled offline flow.
