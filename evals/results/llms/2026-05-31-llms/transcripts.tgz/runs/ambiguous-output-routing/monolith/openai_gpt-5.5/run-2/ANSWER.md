Use the **Reference → LLM files** docs area: `/docs/reference/llm.md`.

That is the agent-facing output API reference. It covers:

- `generateLlmsTxt` — writes the product-level `/llms.txt` and docs-scoped `/docs/llms.txt` maps for hosted websites.
- `generateLLMFullContextFiles` — writes the root `/llms-full.txt` file.
- `generateAgentsMd` — writes `AGENTS.md` for npm-bundled docs.
- `isAgentReadabilityArtifactPath` — identifies generated agent/readability artifacts such as `llms.txt`, `llms-full.txt`, sitemap files, robots.txt, search JSON, and `agent-readability.json`.

Do **not** use the Search reference as the primary guide for this. `/docs/reference/search.md` is about the static local search index and runtime search path; it can support source-grounded answers, but it is not the main agent-facing output API area.

For hosted docs, the normal agent flow is:

1. Start at `/llms.txt`.
2. Follow the markdown links it exposes to the relevant generated docs pages.
3. Use groups as routing hints, not as separate full-context shards.

Use the monolithic `/llms-full.txt` fallback when the agent needs all generated markdown docs in one file, when task-specific context cannot be confidently selected from `/llms.txt`, or when a broad/full-context read is more useful than following individual routed links. It contains every generated markdown docs page and is not split by group by default.