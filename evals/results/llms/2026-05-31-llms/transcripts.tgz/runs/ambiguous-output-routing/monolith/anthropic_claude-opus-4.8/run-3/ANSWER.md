# Agent-facing output APIs vs. search UI

## Which docs area to use

Use the **LLM files reference** at **`/docs/reference/llm.md`**. This is the docs area that covers the agent-facing output APIs — the functions and artifacts that produce agent-readable output:

- `generateLlmsTxt` — writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` routing map for hosted sites.
- `generateLLMFullContextFiles` — writes the single root `/llms-full.txt` containing every generated markdown docs page.
- `generateAgentsMd` — writes `AGENTS.md` for npm-bundled docs (uses relative `./docs/*.md` links for offline reading inside `node_modules`).
- `isAgentReadabilityArtifactPath` — identifies agent-readability artifact paths.

Supporting context:
- `/docs/how-it-works.md` describes the two agent flows: HTTP agents start at `/llms.txt` and follow markdown links; coding agents in installed npm packages start at `AGENTS.md` and follow relative `docs/*.md` links.
- `/docs/reference/cli.md` shows that `leadtype generate --json` emits the artifact paths (`llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, `agentReadabilityJson`, etc.).
- `/docs/package-docs/bundle.md` covers `--bundle` mode for npm packaging (writes `AGENTS.md` + `docs/*.md`, skips website-only artifacts).

**Do not use `/docs/reference/search.md` for this.** That area describes the static local search index (BM25-style lexical ranking, optional embeddings) — i.e., the search/retrieval UI path, not the agent output APIs. It is the wrong area for the question asked.

## When to use the monolithic `/llms-full.txt` fallback

Per `/llms.txt`'s "How To Use" guidance and `/docs/reference/llm.md`:

- **`/llms-full.txt` is a flattened, all-in-one file** containing every generated markdown docs page concatenated together.
- **Use it as a fallback when task-specific context is needed** — i.e., when you can't efficiently locate the right page by navigating from `/llms.txt` and following links, and you want the entire docs corpus in a single read.
- Prefer the normal routed flow first: start at `/llms.txt`, use group/section links as routing hints, and read individual `/docs/**.md` pages. Groups are for routing, not sharding, and per-group full-context files are **not** published by default — so the single `/llms-full.txt` is the monolithic catch-all.
- Note it is a **website-only artifact**: it is *not* produced in `--bundle` (npm) mode, where agents rely on `AGENTS.md` and relative `docs/*.md` links instead.

### Summary
- Agent output APIs → `/docs/reference/llm.md` (with CLI/bundle/how-it-works as support).
- Search UI → `/docs/reference/search.md` (not what you want here).
- `/llms-full.txt` → fallback when you need broad task-specific context in one file rather than navigating individual pages; website-only.
