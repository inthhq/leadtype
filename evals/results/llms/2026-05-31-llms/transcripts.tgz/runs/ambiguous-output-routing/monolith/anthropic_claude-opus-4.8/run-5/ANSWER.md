# Agent-facing output APIs in the Leadtype docs

## Short answer

- **Docs area to use:** `/docs/reference/llm.md` ("LLM files"). This is the
  reference for the agent-facing output APIs (the functions that emit
  agent-readable artifacts). It is *not* the search UI; that lives separately in
  `/docs/reference/search.md`.
- **Use the monolithic `/llms-full.txt` fallback only when you need
  task-specific, full-document context** that the lighter map/links flow does not
  give you — i.e., when following structured links is not enough and you must
  read every docs page flattened into one file.

## Why `/docs/reference/llm.md` is the right area

This page documents the agent-readability output APIs:

- `generateLlmsTxt` — writes the product-level `/llms.txt` and the docs-scoped
  `/docs/llms.txt` map for hosted websites (the structured entry points and
  navigation map).
- `generateLLMFullContextFiles` — writes the single root `/llms-full.txt`
  containing every generated markdown docs page. Groups organize sections,
  navigation, search metadata, and AGENTS.md but are **not** published as
  per-group full-context files by default.
- `generateAgentsMd` — writes `AGENTS.md` for npm-bundled docs (ignores
  `product.agentGuidance`, which is for website URL routing).
- `isAgentReadabilityArtifactPath` — identifies artifact paths that should not be
  rewritten as missing markdown pages.

These are the "output APIs." By contrast, `/docs/reference/search.md` describes
the **search** subsystem (static BM25 lexical index, edge-safe query path,
optional embeddings) — that is the search side, not the agent output API surface
you asked about.

## How the agent flow normally works (the non-fallback path)

Per `/docs/how-it-works.md` and `/llms.txt`:

- HTTP/URL-based agents start at `/llms.txt` and **follow markdown links** —
  using the `/docs/llms.txt` map to reach only the relevant pages.
- Coding agents inside installed npm packages start at `AGENTS.md` and follow
  relative `docs/*.md` links.

This selective, link-following path is the default and preferred way to consume
docs because it pulls only the pages a task needs.

## When to use the `/llms-full.txt` monolithic fallback

`/llms.txt` instructs: *"Read the single all-docs full-context file when
task-specific context is needed."* So reach for `/llms-full.txt` when:

- You need **all docs content at once** as task-specific context and the
  structured link-following from `/llms.txt` / `/docs/llms.txt` is insufficient.
- You want a single flattened file containing every generated markdown page
  (e.g., broad cross-cutting questions, offline whole-corpus reasoning).

Avoid it as the default — it is a fallback for full-context needs, not the
primary routing mechanism. Note also that `/llms-full.txt` is a **website-only
artifact**: in bundle mode (`leadtype generate --bundle`) it is skipped, so
npm-bundled consumers rely on `AGENTS.md` + relative `docs/*.md` instead.

## Quick reference

| Need | Use |
| --- | --- |
| Agent-facing output API reference | `/docs/reference/llm.md` |
| Search subsystem (not output APIs) | `/docs/reference/search.md` |
| Default agent entry / routing map | `/llms.txt` → `/docs/llms.txt`, follow links |
| Whole-corpus, task-specific context fallback | `/llms-full.txt` |
| Offline npm package consumption | `AGENTS.md` + relative `docs/*.md` |
