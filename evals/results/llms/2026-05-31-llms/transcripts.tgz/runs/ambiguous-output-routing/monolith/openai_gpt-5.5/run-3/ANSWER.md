Use the **Reference → LLM files** docs area: `/docs/reference/llm.md`.

That is the agent-facing output API area. It covers:

- `generateLlmsTxt` for the product-level `/llms.txt` and docs-scoped `/docs/llms.txt` maps on hosted sites.
- `generateLLMFullContextFiles` for the root `/llms-full.txt` full-context artifact.
- `generateAgentsMd` for npm-bundled `AGENTS.md` docs.
- `isAgentReadabilityArtifactPath` for recognizing generated agent artifacts such as `llms.txt`, `llms-full.txt`, sitemap files, robots.txt, search JSON, and `agent-readability.json`.

Do **not** use the Search docs area for this question. `/docs/reference/search.md` is about the static local search index and runtime search behavior, not the agent-facing output files/APIs.

Use the monolithic `/llms-full.txt` fallback when the routed `llms.txt` map is not enough and task-specific full context is needed. It contains every generated markdown docs page in one root file. Groups organize `llms.txt` sections, navigation, search metadata, and `AGENTS.md`, but Leadtype does not publish per-group full-context files by default; groups are for routing, not sharding.