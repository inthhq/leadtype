# Agent-facing output APIs vs. search UI

## Which docs area to use

Use the **LLM files** area: **`/docs/reference/llm.md`**.

This is the agent-facing output API surface. It documents the generators that produce the artifacts agents consume:

- **`generateLlmsTxt`** — writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` map for hosted websites (the discovery/routing entry points).
- **`generateLLMFullContextFiles`** — writes the single root `/llms-full.txt` containing every generated markdown docs page flattened into one file.
- **`generateAgentsMd`** — writes `AGENTS.md` for npm-bundled (offline) docs.
- **`isAgentReadabilityArtifactPath`** — identifies artifact paths (llms.txt, llms-full.txt, sitemap files, robots.txt, search JSON, agent-readability.json) that should not be rewritten as missing markdown pages.

Do **not** use `/docs/reference/search.md` for this. That area describes the search/retrieval system — a static BM25-style lexical search index over the generated markdown. It is the search UI / query path (optionally feeding source-grounded answers), not the agent-facing output API for emitting docs artifacts.

If you need the CLI handles for these outputs, `/docs/reference/cli.md` shows that `leadtype generate --json` prints artifact paths including `llmsTxt`, `docsLlmsTxt`, `llmsFullTxt`, `agentReadabilityJson`, `sitemap*`, `robotsTxt`, `searchIndex`, and `searchContent`.

## When to use the monolithic `/llms-full.txt` fallback

`/llms-full.txt` is the **all-docs full-context** file: every generated markdown docs page flattened into one file.

Per `/llms.txt` guidance, **read the single all-docs full-context file when task-specific context is needed** — i.e., when you need broad, whole-corpus context in one shot rather than navigating page by page.

Prefer the normal, structured flow first:

- Start at **`/llms.txt`** and follow the markdown links / `/docs/llms.txt` routing map to the specific pages you need (HTTP/URL-based agents).
- Coding agents inside installed npm packages start at `AGENTS.md` and follow relative `docs/*.md` links.

Fall back to the monolithic `/llms-full.txt` only when:

- A task requires context spanning many or all docs pages and selective navigation is insufficient, or
- You cannot reliably resolve/route to the individual pages and need the complete flattened corpus.

Note: groups are used for routing/navigation/sectioning, **not** for sharding — there are no per-group full-context files by default, so `/llms-full.txt` is the single monolithic full-context fallback.
