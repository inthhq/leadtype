Use the **Reference → LLM files** docs area (`/docs/reference/llm.md`) for agent-facing output APIs, not the Search docs.

That area covers the relevant agent artifacts and API responsibilities:

- `generateLlmsTxt` for the hosted-site `/llms.txt` and `/docs/llms.txt` maps.
- `generateLLMFullContextFiles` for the root `/llms-full.txt` full-context artifact.
- `generateAgentsMd` for package-bundled `AGENTS.md` docs.
- `isAgentReadabilityArtifactPath` for recognizing agent/static artifacts such as `llms.txt`, `llms-full.txt`, sitemap files, robots.txt, search JSON, and `agent-readability.json`.

Use the **Search** docs only for Leadtype’s local search index and runtime search behavior; that is not the primary area for agent-facing output APIs.

Use the monolithic **`/llms-full.txt` fallback** when task-specific context requires reading the entire generated docs corpus in one flattened file, or when the `/llms.txt` routing map is not enough to decide which individual markdown pages to inspect. It is a root-level fallback containing every generated markdown docs page, not a per-group shard. For normal agent routing, start with `/llms.txt` and follow its markdown links instead of defaulting to the full-context file.