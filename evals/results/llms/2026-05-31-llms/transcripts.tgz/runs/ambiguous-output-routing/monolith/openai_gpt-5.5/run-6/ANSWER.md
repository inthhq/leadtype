# Answer

Use the **LLM files** reference area: `/docs/reference/llm.md`.

That page covers the agent-facing output APIs and artifacts, including:

- `generateLlmsTxt` for the product-level `/llms.txt` and docs-scoped `/docs/llms.txt` maps on hosted websites.
- `generateLLMFullContextFiles` for the root `/llms-full.txt` all-docs bundle.
- `generateAgentsMd` for `AGENTS.md` in npm-bundled docs.
- `isAgentReadabilityArtifactPath` for recognizing agent/readability artifacts such as `llms.txt`, `llms-full.txt`, sitemap files, robots.txt, search JSON, and `agent-readability.json`.

Do **not** use the Search reference as your primary docs area for this need. `/docs/reference/search.md` is about the local search index and query/ranking behavior, not the agent-facing output APIs.

Use the monolithic `/llms-full.txt` fallback when you need broad, task-specific context that cannot be confidently answered from the routed docs pages linked from `/llms.txt`, or when you need to inspect every generated markdown docs page in one place. It is a single root full-context file containing all generated markdown pages; groups organize routing and metadata, but Leadtype does not publish per-group full-context files by default.
