# Agent-Facing Output APIs in Leadtype Docs

## Docs Area to Use

For **agent-facing output APIs**, you should use the **`/docs/reference/llm.md`** documentation area.

This page documents the three primary agent-facing output functions:
- **generateLlmsTxt**: Writes the product-level `/llms.txt` and docs-scoped `/docs/llms.txt` map for hosted websites
- **generateLLMFullContextFiles**: Writes the `/llms-full.txt` file containing all generated markdown docs pages
- **generateAgentsMd**: Writes `AGENTS.md` for npm-bundled docs (for coding agents in node_modules)
- **isAgentReadabilityArtifactPath**: Identifies artifact paths that should not be rewritten as missing markdown pages

## When to Use the `/llms-full.txt` Fallback

According to the documentation, you should use the monolithic `/llms-full.txt` fallback in these scenarios:

1. **Task-specific context needed**: When you need the full context across all generated markdown docs pages in a single file
2. **No group-based organization**: When group-based routing (which organizes `/llms.txt` sections) is not suitable for your use case
3. **Offline/fallback scenario**: As a fallback when the grouped `/llms.txt` (which follows the group tree structure) is not available or appropriate

The `/llms-full.txt` file contains every generated markdown docs page flattened into one file, while groups continue to organize the primary `/llms.txt`, navigation, search metadata, and `AGENTS.md`.

## Key Distinction

- **Use `/llms.txt`**: For structured, group-organized agent routing (HTTP agents)
- **Use `/llms-full.txt`**: For comprehensive fallback access when full context across all pages is needed
- **Use `AGENTS.md`**: For offline docs in npm packages (coding agents in node_modules)
