# Agent-facing output APIs vs. search UI

## Which docs area to use

Use the **LLM files** reference at **`/docs/reference/llm.md`** (the "agent-readability" / LLM output area). That is the doc that describes the agent-facing output APIs, specifically:

- **`generateLlmsTxt`** — writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` routing map for hosted websites.
- **`generateLLMFullContextFiles`** — writes the single root `/llms-full.txt` containing every generated markdown docs page flattened into one file.
- **`generateAgentsMd`** — writes `AGENTS.md` for npm-bundled docs (ignores `product.agentGuidance`, which is meant for website URL routing).
- **`isAgentReadabilityArtifactPath`** — identifies artifact paths (llms.txt, llms-full.txt, sitemaps, robots.txt, search JSON, agent-readability.json) that should not be rewritten as missing markdown pages.

Supporting/related docs for emitting and serving these artifacts:

- **`/docs/reference/cli.md`** — `leadtype generate` writes the agent-readable artifacts; with `--json` it prints a JSON object exposing paths like `llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, `agentReadabilityJson`, etc.
- **`/docs/build/connect-docs-site.md`** — how to serve these files (website mode, `Accept: text/markdown`, static artifacts).
- **`/docs/package-docs/bundle.md`** — `AGENTS.md` + `docs/*.md` for npm-bundled (offline) consumption.

**Do NOT use** `/docs/reference/search.md` for this task. That covers the **search UI / retrieval index** (BM25 lexical ranking, optional embeddings), which is a different concern from agent-facing output APIs. Search output can *feed* answer generation, but it is not the output-API surface you want here.

## When to use the monolithic `/llms-full.txt` fallback

- **Per `/llms.txt` guidance:** read the single all-docs full-context file **only when task-specific context is needed** — i.e., when you need the full flattened body of every docs page in one fetch.
- It is the **fallback** for full context: prefer the structured routing path first — `/llms.txt` (product map) and `/docs/llms.txt` (docs-scoped map) to navigate to specific `/docs/*.md` pages. Fall back to `/llms-full.txt` when navigating per-page maps is insufficient and you need everything at once.
- **Note on availability/scope:**
  - `/llms-full.txt` is a **website-mode** artifact only. **Bundle mode (`--bundle`) skips it** (along with `llms.txt`, search JSON, sitemaps, robots.txt, agent-readability.json). In bundled npm docs, use `AGENTS.md` + relative `./docs/*.md` links instead.
  - Groups organize llms.txt sections/navigation/search metadata but are **not** published as per-group full-context files by default, so `/llms-full.txt` is the single source for "everything in one file."
