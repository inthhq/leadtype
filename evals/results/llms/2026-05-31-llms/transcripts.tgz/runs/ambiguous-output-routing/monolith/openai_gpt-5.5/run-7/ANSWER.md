Use the **LLM files** reference area: `/docs/reference/llm.md`.

That page covers Leadtype’s agent-facing output APIs/artifacts, including:

- `generateLlmsTxt` for the hosted-site `/llms.txt` and `/docs/llms.txt` maps
- `generateLLMFullContextFiles` for the root `/llms-full.txt`
- `generateAgentsMd` for npm-bundled `AGENTS.md`
- `isAgentReadabilityArtifactPath` for recognizing generated agent artifacts such as `llms.txt`, `llms-full.txt`, sitemap files, robots.txt, search JSON, and `agent-readability.json`

Do **not** use the Search reference area for this question. `/docs/reference/search.md` is about the static local search index and runtime search/query behavior, not the agent-facing output-file APIs.

Use the monolithic `/llms-full.txt` fallback when you need task-specific full-context coverage across the entire generated docs corpus, or when `/llms.txt` group routing is not enough. It contains every generated markdown docs page in one file. Groups are for routing and organization in `llms.txt`, navigation, search metadata, and `AGENTS.md`; Leadtype does not publish per-group full-context files by default.