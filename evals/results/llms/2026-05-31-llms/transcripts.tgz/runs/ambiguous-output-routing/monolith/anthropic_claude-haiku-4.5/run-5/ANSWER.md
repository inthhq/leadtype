# Agent-Facing Output APIs in Leadtype Docs

## Which Docs Area to Use

For agent-facing output APIs, use the **`/docs/reference/llm.md`** documentation area. This is the dedicated reference section that documents the LLM file generation APIs.

## Key Agent-Facing APIs

The main agent-facing output APIs documented are:

1. **generateLlmsTxt** - Writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` map for hosted websites
2. **generateLLMFullContextFiles** - Writes the root `/llms-full.txt` file containing every generated markdown docs page
3. **generateAgentsMd** - Writes `AGENTS.md` for npm-bundled docs (for offline use inside node_modules)
4. **isAgentReadabilityArtifactPath** - Identifies artifact paths that should not be rewritten as missing markdown pages

## When to Use the `/llms-full.txt` Fallback

Use the monolithic `/llms-full.txt` fallback when:

- **You need complete context across all docs groups** - Unlike the grouped `/llms.txt` which organizes content by sections, `/llms-full.txt` contains every generated markdown docs page flattened into one file
- **Groups don't provide the full picture** - Groups organize routing, navigation, search metadata, and AGENTS.md grouping, but they are not published as per-group full-context files by default
- **Task-specific context requires comprehensive coverage** - As stated in `/llms.txt`, "Read the single all-docs full-context file when task-specific context is needed"

## Context

The documentation distinguishes between:
- **Website mode**: Uses `/llms.txt` (product-level) and `/docs/llms.txt` (docs-scoped) for HTTP agent discovery
- **Package mode**: Uses `AGENTS.md` for npm packages accessed via relative links inside node_modules
- **Fallback**: `/llms-full.txt` for comprehensive single-file context when needed

This design allows agents to be efficient with targeted group-based navigation while maintaining the option for complete context when necessary.
