# Agent-facing output APIs vs. search UI in the Leadtype docs

## Which docs area to use

Use **`/docs/reference/llm.md`** (the "LLM files" reference). This is the area
that documents the agent-facing **output APIs** — the functions that emit
agent-readable artifacts:

- `generateLlmsTxt` — writes the product-level `/llms.txt` and the docs-scoped
  `/docs/llms.txt` map for hosted websites.
- `generateLLMFullContextFiles` — writes the single root `/llms-full.txt`
  containing every generated markdown docs page.
- `generateAgentsMd` — writes `AGENTS.md` for npm-bundled docs.
- `isAgentReadabilityArtifactPath` — identifies artifact paths (llms.txt,
  llms-full.txt, sitemaps, robots.txt, search JSON, agent-readability.json) that
  should not be rewritten as missing markdown pages.

Supporting/related areas:
- **`/docs/reference/cli.md`** — how `leadtype generate` produces these
  artifacts (e.g. `--json` reports `llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`,
  `agentReadabilityJson`, etc.).
- **`/docs/package-docs/bundle.md`** — the offline/npm agent path (`AGENTS.md`
  + relative `docs/*.md`).

**Do NOT use `/docs/reference/search.md` for this.** That area covers the
search index and query/ranking path (lexical BM25 over the corpus) — i.e. the
search UI / retrieval layer, not the agent output APIs you asked for.

## When to use the monolithic `/llms-full.txt` fallback

`/llms-full.txt` is the all-docs full-context file: every generated markdown
page flattened into one file. Per `/llms.txt`, you should read it **only when
task-specific context is needed** — i.e. as a fallback when navigating
individual pages isn't enough.

Concretely:

- **Default / preferred path:** Start at `/llms.txt`, follow its markdown links,
  and read only the specific pages you need (the normal HTTP-agent flow).
- **Use `/llms-full.txt` when:** you need broad, task-specific context across
  the whole corpus and can't get it efficiently by following links — for
  example when you don't yet know which pages are relevant, or you need to
  cross-reference many pages at once. It is the single, monolithic fallback;
  Leadtype does **not** publish per-group full-context files by default (groups
  organize sections, navigation, search metadata, and AGENTS.md — they are for
  routing, not sharding).
- **Don't use it when:** you're working offline inside an installed npm package
  — that flow starts at `AGENTS.md` and follows relative `docs/*.md` links, and
  bundle mode intentionally skips website-only artifacts like `llms-full.txt`.
