Use the **LLM files** reference area: `/docs/reference/llm.md`.

That is the agent-facing output API documentation. It covers the generated files and helpers for hosted agent consumption, including:

- `/llms.txt` and `/docs/llms.txt` via `generateLlmsTxt`
- `/llms-full.txt` via `generateLLMFullContextFiles`
- `AGENTS.md` for bundled npm/package docs via `generateAgentsMd`
- artifact handling such as `llms.txt`, `llms-full.txt`, sitemaps, robots.txt, search JSON, and `agent-readability.json`

Do **not** use the Search docs area if your goal is agent-facing output APIs rather than search UI or ranking behavior. `/docs/reference/search.md` is about the static local search index and query path.

Use the monolithic root **`/llms-full.txt` fallback** when task-specific context is needed and the routing map is not enough, or when you need the complete generated markdown corpus in one file. It contains every generated markdown docs page flattened together. Groups are for routing and organization in `llms.txt`, navigation, search metadata, and `AGENTS.md`; they are not published as separate per-group full-context bundles by default.