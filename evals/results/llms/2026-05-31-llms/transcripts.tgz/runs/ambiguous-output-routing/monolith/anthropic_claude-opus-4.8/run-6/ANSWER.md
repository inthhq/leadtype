# Agent-facing output APIs in the Leadtype docs

## Which docs area to use

Use the **`/docs/reference/llm.md`** ("LLM files") page. This is the reference that documents the agent-facing output APIs — the functions/artifacts that produce agent-readable bundles:

- **`generateLlmsTxt`** — writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` map for hosted websites.
- **`generateLLMFullContextFiles`** — writes the single root `/llms-full.txt` file containing every generated markdown docs page.
- **`generateAgentsMd`** — writes `AGENTS.md` for npm-bundled docs (ignores `product.agentGuidance`, which is for website URL routing).
- **`isAgentReadabilityArtifactPath`** — identifies artifact paths that must not be rewritten as missing markdown pages (covers `llms.txt`, `llms-full.txt`, sitemap files, `robots.txt`, search JSON, and `agent-readability.json`).

If you also need the CLI surface for emitting these artifacts, see `/docs/reference/cli.md`: `leadtype generate --json` prints an object with the relevant artifact paths (`llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, `agentReadabilityJson`, `searchIndex`, `searchContent`, etc.).

### Not the search UI

Do **not** use `/docs/reference/search.md` for this. That page covers the search index / query path (BM25-style lexical ranking, optional embeddings). It is the search retrieval surface, not the agent-facing output (bundle-generation) APIs you asked for.

## When to use the monolithic `/llms-full.txt` fallback

`/llms-full.txt` is the all-docs full-context bundle: every generated markdown docs page flattened into one file (produced by `generateLLMFullContextFiles`).

Use it as a **fallback** when:

- You need **task-specific context that spans the whole corpus** and the structured entry points aren't enough. Per the docs site's own guidance, read the single all-docs full-context file "when task-specific context is needed."
- The normal navigation flow (start at `/llms.txt`, follow markdown links to individual `/docs/*.md` pages) doesn't give you the full context you need, or you want everything in one request rather than crawling many pages.

Prefer the **structured path first**: HTTP agents should start at `/llms.txt` and follow markdown links to specific `/docs/*.md` pages; coding agents in npm packages start at `AGENTS.md` and follow relative `./docs/*.md` links. Reach for the monolithic `/llms-full.txt` only when that targeted navigation is insufficient and you genuinely need the entire docs set at once.

### Note on availability

`/llms-full.txt` is a **website-mode** artifact. In **bundle mode** (`leadtype generate --bundle` for npm packages) it is skipped along with `llms.txt`, search JSON, sitemaps, `robots.txt`, and `agent-readability.json`; bundled packages instead expose `AGENTS.md` + relative `docs/*.md`. So the `/llms-full.txt` fallback only applies to the hosted docs site, not to offline node_modules docs.
