# Agent-Facing Output APIs in Leadtype Docs

## Which Docs Area to Use

For agent-facing output APIs (not search UI), use the **`/docs/reference/llm.md`** section. This is the primary resource documenting the LLM file generation APIs.

Additionally, you may find relevant information in:

- **`/docs/reference/cli.md`** - For CLI flags and JSON output artifacts configuration
- **`/docs/how-it-works.md`** - For understanding the agent flow and entry points
- **`/docs/build/connect-docs-site.md`** - For configuring agent-friendly output on a hosted website

## When to Use `/llms-full.txt` Fallback

Use the monolithic **`/llms-full.txt`** fallback file when you need:

1. **Complete context across all doc sections** - `/llms-full.txt` contains every generated markdown docs page flattened into a single file for comprehensive, all-at-once reference
2. **Task-specific context requiring broad documentation understanding** - When your task needs to synthesize information from multiple doc areas simultaneously
3. **Offline or bulk processing** - When you want all docs in one file for easier parsing or processing without multiple requests

## Key API Resources

The `/docs/reference/llm.md` file documents the primary agent-facing APIs:

- **`generateLlmsTxt`** - Writes product-level `/llms.txt` and docs-scoped `/docs/llms.txt` map for hosted websites
- **`generateLLMFullContextFiles`** - Writes the `/llms-full.txt` fallback file containing every generated markdown docs page
- **`generateAgentsMd`** - Writes `AGENTS.md` for npm-bundled docs (for coding agents inside node_modules)
- **`isAgentReadabilityArtifactPath`** - Identifies artifact paths that should not be rewritten as missing markdown pages

## API Output Artifacts

According to `/docs/reference/cli.md`, when using the `--json` flag, the CLI outputs a JSON object with paths to generated artifacts for website mode:
- `llmsFullTxt`
- `docsLlmsTxt`
- `llmsTxt`
- `agentReadabilityJson`
- `sitemapXml`
- `sitemapMd`
- `robotsTxt`
- `searchIndex`
- `searchContent`

These are the agent-facing output APIs you should integrate with, not the search UI.
