# Leadtype: Agent-Facing Output APIs vs. the `/llms-full.txt` Fallback

## Which docs area to use

Use **`/docs/reference/llm.md`** ("LLM files"). This is the agent-facing output API reference. It describes the generator functions that produce the artifacts agents consume:

- **`generateLlmsTxt`** — writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` map for hosted websites.
- **`generateLLMFullContextFiles`** — writes the single root `/llms-full.txt` containing every generated markdown docs page.
- **`generateAgentsMd`** — writes `AGENTS.md` for npm-bundled docs (relative `docs/*.md` links for offline/node_modules use). It deliberately ignores `product.agentGuidance`, which is meant for website URL routing.
- **`isAgentReadabilityArtifactPath`** — identifies artifact paths that must not be rewritten as missing markdown pages (covers `llms.txt`, `llms-full.txt`, sitemap files, `robots.txt`, search JSON, and `agent-readability.json`).

This is the right area precisely because the question is about **agent-facing output APIs, not the search UI**. The search behavior lives separately in `/docs/reference/search.md` (the BM25-style query/ranking path and optional embeddings), which is the search/retrieval surface — not what you want here.

### Supporting / related docs
- **`/docs/build/connect-docs-site.md`** — website mode: serve `/llms.txt` and `/docs/*.md`, return markdown for `Accept: text/markdown` or known AI user agents, and keep `llms-full.txt`, sitemaps, `robots.txt`, search JSON, and `agent-readability.json` as static artifacts.
- **`/docs/package-docs/bundle.md`** — bundle mode (`--bundle`): writes `AGENTS.md` + `docs/*.md` for offline reads in `node_modules`; intentionally **skips** website-only artifacts including `llms.txt` and `llms-full.txt`.
- **`/docs/reference/cli.md`** — `leadtype generate --json` reports the produced artifact paths, including `llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, `agentReadabilityJson`, `sitemap*`, `robotsTxt`, `searchIndex`, and `searchContent`.

## When to use the monolithic `/llms-full.txt` fallback

`/llms-full.txt` is the single flattened file containing **every** generated markdown docs page. Per `/llms.txt` itself, you should:

> Read the single all-docs full-context file when task-specific context is needed.

So use `/llms-full.txt` as a **fallback for full context** when:

- You need broad, task-specific context and following individual markdown links from `/llms.txt` (and `/docs/llms.txt`) is not enough or is impractical.
- You want the entire corpus in one place rather than navigating the group-routed structure.

Prefer the normal navigation path first: HTTP agents should **start at `/llms.txt` and follow markdown links** (coding agents inside npm packages start at `AGENTS.md`). Reach for `/llms-full.txt` only when you need everything at once.

### Important caveat
Groups are for **routing, not sharding**. There are **no per-group full-context files** published by default — groups only organize `llms.txt` sections, navigation, search metadata, and `AGENTS.md`. That means `/llms-full.txt` is the *one* monolithic, all-docs option; if a single group's full text were desired, it isn't generated separately, so the whole-corpus `/llms-full.txt` is the available fallback.

## Summary
- **Use:** `/docs/reference/llm.md` for the agent-facing output APIs (`generateLlmsTxt`, `generateLLMFullContextFiles`, `generateAgentsMd`, `isAgentReadabilityArtifactPath`). Avoid `/docs/reference/search.md`, which is the search/query surface.
- **Fallback to `/llms-full.txt`:** when task-specific full context is needed and link-following from `/llms.txt` is insufficient — it's the single all-docs flattened file, and no per-group full-context files exist by default.
