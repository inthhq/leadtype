Use the **Reference → LLM files** docs area (`/docs/reference/llm.md`) for agent-facing output APIs.

That area covers the files and generators intended for agents, including:

- `generateLlmsTxt`: writes the hosted-site `/llms.txt` and `/docs/llms.txt` maps.
- `generateLLMFullContextFiles`: writes the root `/llms-full.txt` full-context file.
- `generateAgentsMd`: writes `AGENTS.md` for npm-bundled/package docs.
- `isAgentReadabilityArtifactPath`: identifies agent/static artifacts such as `llms.txt`, `llms-full.txt`, sitemap files, robots.txt, search JSON, and `agent-readability.json`.

Do **not** use the Search docs area for this purpose. `/docs/reference/search.md` is about the static local search index and runtime search ranking; search output may support answer generation, but it is not the primary docs area for agent-facing output APIs.

Use the monolithic **`/llms-full.txt` fallback** when task-specific context requires the entire generated documentation set in one file, or when the normal `/llms.txt`/group routing and individual markdown links are insufficient. It contains every generated markdown docs page and is not split by group. Groups should be used for routing/navigation hints, not as full-context shards.