# Agent-Facing Output APIs - Leadtype Docs Guide

## Which Docs Area to Use

For **agent-facing output APIs** (not search UI), use the **`/docs/reference/`** section of the Leadtype docs. Specifically:

### Primary Reference: `/docs/reference/llm.md`
This is the authoritative guide for agent-facing output APIs. It covers:
- **generateLlmsTxt**: Produces `/llms.txt` (product-level) and `/docs/llms.txt` (docs-scoped) for hosted websites
- **generateLLMFullContextFiles**: Generates the full-context file `/llms-full.txt`
- **generateAgentsMd**: Writes `AGENTS.md` for npm-bundled packages
- **isAgentReadabilityArtifactPath**: Identifies artifact paths that should be treated as static agent-readable assets

### Secondary Reference: `/docs/reference/cli.md`
Provides CLI interface details for generating these outputs:
- The `leadtype generate` command with `--json` flag outputs artifact paths
- Website-mode outputs include: llmsFullTxt, docsLlmsTxt, llmsTxt, agentReadabilityJson, sitemapXml, sitemapMd, robotsTxt, searchIndex, and searchContent

### Supporting Reference: `/docs/build/connect-docs-site.md`
Shows which files to serve as static artifacts for agents:
- `/llms.txt` - main entry point for HTTP agents
- `/llms-full.txt` - fallback with all pages
- `/docs/*.md` - markdown mirrors of individual pages
- Search JSON, sitemap files, robots.txt, and agent-readability.json

## When to Use `/llms-full.txt` Fallback

Use the **monolithic `/llms-full.txt` fallback** in these scenarios:

1. **Task-specific full context needed**: When an agent task requires comprehensive documentation context across all pages without needing to follow links
2. **No group-based organization**: When you don't need the organized, group-separated sections provided by `/llms.txt`
3. **Offline or comprehensive context**: When building source-grounded responses that benefit from having all documentation in one flattened file
4. **Unknown or cross-group queries**: When a query spans multiple documentation areas not cleanly separated by the group structure

As stated in `/llms.txt`:
> "Read the single all-docs full-context file when task-specific context is needed."

## Key Distinction

- **`/llms.txt`**: Entry point for agents, organized by groups with routing hints
- **`/llms-full.txt`**: Complete fallback containing every generated markdown page, not split by group
- **`AGENTS.md`**: For coding agents working inside installed npm packages (offline, relative links)
- **Search APIs**: For queries over indexed content (separate from agent-facing output APIs)

The agent-facing output APIs are **not** the search UI—they are the structured markdown delivery mechanisms for intelligent agent consumption.
