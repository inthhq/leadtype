# Agent-Facing Output APIs in Leadtype Docs

## Recommended Docs Area

For agent-facing output APIs that are **not search UI**, use the following documentation areas:

### Primary Areas:

1. **`/docs/reference/llm.md`** - LLM Files
   - Explains `generateLlmsTxt()` and `generateLLMFullContextFiles()` functions
   - Covers the output format and structure of agent-readable artifacts
   - Documents AGENTS.md generation for npm-bundled docs
   - Details artifact path identification for agent readability

2. **`/docs/reference/cli.md`** - CLI Reference
   - Documents `leadtype generate` with flags like `--bundle` and `--json`
   - Explains JSON output object structure for website-mode artifacts:
     - `llmsFullTxt`
     - `docsLlmsTxt`
     - `llmsTxt`
     - `agentReadabilityJson`
     - Plus sitemap, robots.txt, and search index paths
   - Details artifact generation and output paths

3. **`/docs/build/connect-docs-site.md`** - Connection Guide
   - Explains how to expose agent files via HTTP
   - Documents which artifacts to serve statically
   - Provides verification checks for agent integration

## When to Use `/llms-full.txt` Fallback

Use the monolithic `/llms-full.txt` fallback in these scenarios:

1. **Group-independent context needed**: When you need complete documentation context that spans all groups without filtering by routing
   
2. **Task-specific full context**: When your task requires understanding the complete documentation set in one file

3. **No group-based sharding required**: Since `/llms-full.txt` contains every generated markdown page flattened into a single file, use it when you don't need group-organized sections

4. **Offline/comprehensive reference**: When you need the entire docs corpus without needing to follow multiple navigation links

## Architecture Summary

- **HTTP agents** start at `/llms.txt` (routing map) and follow markdown links to specific pages
- **Coding agents** (npm packages) start at `AGENTS.md` and follow relative links to `docs/*.md`
- **Full-context fallback** is `/llms-full.txt` containing all generated markdown pages when complete context is needed upfront
