# Agent-Facing Output APIs in Leadtype Docs

## Which Docs Area to Use

For agent-facing output APIs, you should use the **`/docs/reference/`** area, specifically:

- **`/docs/reference/llm.md`** - Documents the LLM file generation APIs:
  - `generateLlmsTxt` - writes product-level `/llms.txt` and docs-scoped `/docs/llms.txt` map
  - `generateLLMFullContextFiles` - writes the `/llms-full.txt` file
  - `generateAgentsMd` - writes `AGENTS.md` for npm-bundled docs
  - `isAgentReadabilityArtifactPath` - identifies artifact paths for agent readability

- **`/docs/reference/cli.md`** - Documents the CLI with the `--json` flag output that lists generated artifact paths including:
  - llmsFullTxt
  - docsLlmsTxt
  - llmsTxt
  - agentReadabilityJson
  - And other agent-facing artifacts

## When to Use `/llms-full.txt` Fallback

Use the monolithic `/llms-full.txt` fallback when:

1. **You need task-specific full context** - The `/llms.txt` file mentions: "Read the single all-docs full-context file when task-specific context is needed."

2. **You need all documentation at once** - `/llms-full.txt` contains every generated markdown docs page flattened into one file, whereas `/llms.txt` is organized by groups for routing purposes.

3. **Groups are not providing adequate scope** - While `/llms.txt` and `/docs/llms.txt` organize content by groups for HTTP agent routing, `/llms-full.txt` bypasses group organization and provides complete, unsharded documentation.

4. **You are working offline or need a single-file reference** - Similar to how bundle mode publishes `AGENTS.md` for npm packages with relative links, `/llms-full.txt` provides a single comprehensive reference file for the entire docs site.

## Summary

- **Primary API reference**: `/docs/reference/llm.md` and `/docs/reference/cli.md`
- **Fallback**: `/llms-full.txt` when you need comprehensive full-context documentation
- **Flow distinction**: HTTP agents use `/llms.txt` (group-organized), npm agents use `AGENTS.md` (relative links)
