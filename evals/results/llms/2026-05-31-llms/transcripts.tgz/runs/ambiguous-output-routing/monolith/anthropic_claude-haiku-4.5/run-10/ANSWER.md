# Leadtype Docs Site: Agent-Facing Output APIs

## Which Docs Area to Use

For agent-facing output APIs (not search UI), use the **`/docs/package-docs/bundle.md`** documentation area. This section specifically covers:

- **AGENTS.md**: The primary agent-facing output API that uses relative links for docs inside node_modules
- **Bundle mode documentation**: Instructions for publishing agent-readable docs packages to npm
- How agents can read docs without network requests

### Alternative Resources
- **`/docs/reference/llm.md`**: Reference documentation for all LLM file generation, including AGENTS.md format and product-level llms.txt/llms-full.txt files
- **`/docs/build/connect-docs-site.md`**: For website mode setup with agent file exposure via HTTP

## When to Use the `/llms-full.txt` Fallback

Use the monolithic `/llms-full.txt` fallback in these scenarios:

1. **Task-specific context needed**: When your agent task requires comprehensive, full-context information across all docs
2. **Missing individual files**: As a fallback when specific markdown pages under `/docs/*.md` are unavailable
3. **Complete corpus analysis**: When analyzing the entire documentation corpus in a single request is more efficient than multiple file reads

According to the `/llms.txt` header: *"Read the single all-docs full-context file when task-specific context is needed."*

### When NOT to Use `/llms-full.txt`
- For production agent API implementations (use AGENTS.md with relative links instead)
- When you only need specific API documentation (use individual `/docs/*.md` files)
- For npm bundled packages (use AGENTS.md for relative link resolution in node_modules)
