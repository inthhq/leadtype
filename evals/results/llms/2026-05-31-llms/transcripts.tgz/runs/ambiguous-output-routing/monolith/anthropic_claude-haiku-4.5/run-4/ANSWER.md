# Agent-Facing Output APIs in Leadtype Docs

## Which Docs Area to Use

For **agent-facing output APIs** (not search UI), you should use:

### **Primary: `/docs/reference/llm.md`**
This is the main documentation area that describes the agent-readable output APIs that Leadtype generates:
- `generateLlmsTxt` - writes `/llms.txt` and `/docs/llms.txt` map files
- `generateLLMFullContextFiles` - writes the `/llms-full.txt` full-context file
- `generateAgentsMd` - writes `AGENTS.md` for npm-bundled docs
- `isAgentReadabilityArtifactPath` - identifies agent-readability artifact paths

### **Secondary: `/docs/build/connect-docs-site.md`**
This covers how to properly expose agent files for HTTP-discoverable agents:
- How to serve markdown via `Accept: text/markdown` headers
- Proper artifact handling for `/llms.txt`, `/llms-full.txt`, sitemap files, robots.txt, search JSON, and agent-readability.json

### **Context: `/docs/how-it-works.md`**
Explains the two agent flows:
- **HTTP agents** start at `/llms.txt` and follow markdown links
- **Coding agents** (in npm packages) start at `AGENTS.md` and follow relative `docs/*.md` links

---

## When to Use the `/llms-full.txt` Fallback

Use the monolithic **`/llms-full.txt`** fallback when:

1. **Task-specific context is needed** - When you need complete docs in one file for comprehensive understanding
2. **Groups are not relevant** - The full-context file contains all generated markdown pages flattened into one file, regardless of group organization
3. **Offline or complete reference** - When you need every page without making multiple requests
4. **Development/testing** - For verification and understanding the complete documentation structure

### When NOT to Use `/llms-full.txt`

- **Production agent navigation** - Agents should start with `/llms.txt` for proper routing
- **Specific topic lookup** - Use group-scoped `/docs/llms.txt` or individual markdown pages
- **Package agents** - Use `AGENTS.md` for npm bundle agents
- **Search queries** - Use the search index APIs, not the full context file

### Key Distinction

- `/llms.txt` - **Grouped, navigation-organized** - for initial agent discovery and routing
- `/llms-full.txt` - **Flat, comprehensive** - for complete context when group structure is not relevant
- `AGENTS.md` (bundle mode) - **Relative links** - for offline agents in node_modules
