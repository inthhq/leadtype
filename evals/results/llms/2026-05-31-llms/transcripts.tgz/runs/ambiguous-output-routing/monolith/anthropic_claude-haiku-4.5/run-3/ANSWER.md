# Agent-Facing Output APIs - Which Docs Area to Use

## Primary Documentation Area

Use the **`/docs/reference/llm.md`** documentation section for agent-facing output APIs.

This section documents the programmatic APIs that generate agent-readable artifacts:
- `generateLlmsTxt` - Generates `/llms.txt` and `/docs/llms.txt` routing maps
- `generateLLMFullContextFiles` - Generates the `/llms-full.txt` full-context file
- `generateAgentsMd` - Generates `AGENTS.md` for npm-bundled docs
- `isAgentReadabilityArtifactPath` - Identifies agent artifact paths

## When to Use the `/llms-full.txt` Fallback

Use the monolithic `/llms-full.txt` fallback in these scenarios:

1. **Task-Specific Full Context Needed**: When you need comprehensive context across all documentation pages for a complex task that spans multiple docs sections

2. **Group-Agnostic Queries**: When you don't need routing through group-organized sections and want every generated markdown page in a single flattened file

3. **Offline or Out-of-Band Processing**: When processing documentation without relying on the group-based routing structure that `/llms.txt` provides

## Key Distinction

- **`/llms.txt`** - Organized routing map split by groups with descriptions (recommended for normal agent navigation)
- **`/llms-full.txt`** - All generated markdown pages flattened into one file (fallback for comprehensive context needs)

## Relevant Secondary References

For complete context on agent-facing outputs, also reference:
- `/docs/reference/cli.md` - CLI flags including `--json` for programmatic artifact output
- `/docs/how-it-works.md` - Overview of HTTP agents starting at `/llms.txt` vs. coding agents using `AGENTS.md`
- `/docs/build/connect-docs-site.md` - Website mode configuration and agent artifact serving guidance
