Use the **Reference → LLM files** docs area: `/docs/reference/llm.md`.

That page covers the agent-facing output APIs/artifacts, including:

- `generateLlmsTxt` for product-level `/llms.txt` and docs-scoped `/docs/llms.txt` maps on hosted websites.
- `generateLLMFullContextFiles` for the root `/llms-full.txt` full-context file.
- `generateAgentsMd` for npm-bundled `AGENTS.md` docs.
- `isAgentReadabilityArtifactPath` for recognizing agent artifacts such as `llms.txt`, `llms-full.txt`, sitemap files, robots.txt, search JSON, and `agent-readability.json`.

Do **not** use the Search reference area for this; `/docs/reference/search.md` is about the static local search index and query behavior, not the agent-facing output APIs.

Use `/llms-full.txt` as a **monolithic fallback** when the task needs broad or task-specific context across the generated docs and the normal routing map/pages are not enough. It contains every generated markdown docs page in one file. It is not split by group, and groups should be used for routing/navigation hints rather than as full-context shards.