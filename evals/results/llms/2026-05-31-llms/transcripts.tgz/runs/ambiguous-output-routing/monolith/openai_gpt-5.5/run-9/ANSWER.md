# Leadtype docs area to use

Use **Reference → LLM files** (`/docs/reference/llm.md`) for the agent-facing output APIs. That area covers the artifacts agents consume, including:

- `generateLlmsTxt` for the hosted-site `/llms.txt` and `/docs/llms.txt` maps.
- `generateLLMFullContextFiles` for the root `/llms-full.txt` file.
- `generateAgentsMd` for npm-bundled `AGENTS.md` docs.
- Agent-readability artifact handling for files such as `llms.txt`, `llms-full.txt`, sitemaps, robots, search JSON, and `agent-readability.json`.

Do **not** treat the Search reference as the primary area for this need. `/docs/reference/search.md` is about Leadtype’s static local search index and query path; search output can support source-grounded generation, but it is not the main documentation for the agent-facing output files.

For a hosted docs site, agents should normally start at `/llms.txt`, use its routing hints/groups, and follow links to the relevant markdown mirrors under `/docs/*.md`. Groups are for routing and organization, not separate full-context shards.

Use the monolithic **`/llms-full.txt` fallback** only when you need task-specific full context across the entire docs corpus or the targeted `/llms.txt` → `/docs/*.md` path is not enough. It contains every generated markdown docs page in one root file and is not split by group.