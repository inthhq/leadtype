# Answer

Use the **LLM files** docs area: `/docs/reference/llm.md`.

That page covers the agent-facing generated outputs, including:

- `generateLlmsTxt`, which writes the hosted website routing maps: `/llms.txt` and `/docs/llms.txt`.
- `generateLLMFullContextFiles`, which writes the root `/llms-full.txt` file.
- `generateAgentsMd`, which writes `AGENTS.md` for npm-bundled docs.
- `isAgentReadabilityArtifactPath`, which identifies agent/readability artifacts such as `llms.txt`, `llms-full.txt`, sitemap files, robots.txt, search JSON, and `agent-readability.json`.

Do **not** use the Search docs area for this question unless you are working on the search UI or runtime search behavior. `/docs/reference/search.md` is about the static local search index and query path, not the primary agent-facing output APIs.

Use `/llms.txt` and grouped docs links for normal agent routing. Use the monolithic `/llms-full.txt` fallback when you need full task-specific context across the entire generated docs corpus, or when the grouped routing map is not enough. It contains every generated markdown docs page in one root file and is not split into per-group full-context files by default.