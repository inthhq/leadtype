# Agent-Facing Output APIs in Leadtype Docs

## Which Docs Area to Use

For **agent-facing output APIs** (not search UI), use the **`/docs/reference/llm.md`** documentation area.

This page covers:
- **generateLlmsTxt**: Writes the product-level `/llms.txt` and docs-scoped `/docs/llms.txt` map for hosted websites
- **generateLLMFullContextFiles**: Writes the `/llms-full.txt` fallback file containing every generated markdown docs page
- **generateAgentsMd**: Writes `AGENTS.md` for npm-bundled docs (for package installations)
- **isAgentReadabilityArtifactPath**: Identifies artifact paths that should not be rewritten

## When to Use `/llms-full.txt`

Use the **`/llms-full.txt` monolithic fallback** in these scenarios:

1. **Task-specific context needed**: When you need comprehensive context that requires seeing all documentation pages together
2. **Full corpus access**: When your agent task benefits from having every generated markdown page flattened into one file for complete reference
3. **Fallback routing**: The `/llms-full.txt` file serves as a fallback when the grouped `/llms.txt` routing structure doesn't fit your use case

### Key Distinction

- **`/llms.txt`**: Organized by groups and navigation sections, optimized for structured routing and navigation hints
- **`/llms-full.txt`**: Contains all generated markdown pages flattened without group sharding, better for comprehensive context when groups don't match your task structure

## Related APIs

For context, the other agent-related APIs documented include:
- **Search API** (`/docs/reference/search.md`): Static search index over generated markdown (not for output API use)
- **AGENTS.md**: For npm-bundled docs in node_modules (not website-routed)
