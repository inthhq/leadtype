# Leadtype Agent-Facing Output APIs

## Which Docs Area to Use

For agent-facing output APIs, use the **[Reference](/docs/reference/llms.txt)** section, specifically the **[LLM files](/docs/reference/llm.md)** page.

This page documents the agent-readable generation APIs:
- `generateLlmsTxt`: Writes the product-level `/llms.txt` and docs-scoped `/docs/llms.txt` map for hosted websites
- `generateLLMFullContextFiles`: Writes the root `/llms-full.txt` monolithic fallback file
- `generateAgentsMd`: Writes `AGENTS.md` for npm-bundled docs
- `isAgentReadabilityArtifactPath`: Identifies artifact paths that should not be rewritten as missing markdown pages

## When to Use `/llms-full.txt` Fallback

Use the monolithic `/llms-full.txt` fallback when:

1. **Page links are insufficient**: When an agent needs broader section context beyond individual markdown pages
2. **Full-context requirement**: When you need every generated markdown docs page in a single file for complete context
3. **Section bundle fallback**: Each section (e.g., Reference, Build, Get Started) offers an optional full-context bundle at URLs like `/docs/llms-full/reference.txt`

As stated in the `/llms.txt` guide: "Choose the smallest section index that matches the task, then read the linked page markdown. Use a section full-context bundle only when page links are not enough."

## Agent Flow Summary

- **HTTP agents**: Start at `/llms.txt` and follow markdown links, falling back to `/llms-full.txt` only when needed
- **Coding agents in packages**: Start at `AGENTS.md` and follow relative `docs/*.md` links
- **Search**: Use the static search index at `/docs/reference/search.md` for lexical ranking queries over titles, headings, body text, and code
