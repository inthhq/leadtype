# Answer

Use the **Reference** docs area, specifically **Reference → LLM files** (`/docs/reference/llm.md`), for the agent-facing output APIs. That page covers the APIs/artifacts for agent-readable output:

- `generateLlmsTxt` for the product-level `/llms.txt` and docs-scoped `/docs/llms.txt` maps.
- `generateLLMFullContextFiles` for the root `/llms-full.txt` full-context fallback.
- `generateAgentsMd` for npm-bundled `AGENTS.md`.
- `isAgentReadabilityArtifactPath` for recognizing static agent-readability artifacts.

Do **not** use the Search docs area if your need is the agent-facing output APIs rather than search UI or retrieval behavior. The Search page is about the static search index, ranking, source-grounded answers, and optional embeddings.

Use the monolithic **`/llms-full.txt` fallback** only when you need whole-site generated markdown context in one file and the normal routed approach is not enough. The preferred flow is to start from `/llms.txt`, choose the smallest relevant section index, and read the linked page markdown first. Use a section full-context bundle if page links are insufficient; reserve the root `/llms-full.txt` as the broad fallback containing every generated markdown docs page. It is not split by group by default; groups organize routing, navigation, search metadata, and `AGENTS.md`, not per-group full-context files.
