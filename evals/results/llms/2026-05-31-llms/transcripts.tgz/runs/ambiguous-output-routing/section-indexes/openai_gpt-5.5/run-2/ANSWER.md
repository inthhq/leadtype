Use the **Reference** docs area, specifically **Reference → LLM files** (`/docs/reference/llm.md`), for the agent-facing output APIs. That page covers the APIs that generate the agent-readable artifacts:

- `generateLlmsTxt` for `/llms.txt` and `/docs/llms.txt`
- `generateLLMFullContextFiles` for `/llms-full.txt`
- `generateAgentsMd` for npm-bundled `AGENTS.md`
- `isAgentReadabilityArtifactPath` for recognizing agent-readability artifacts

If you need CLI output paths for these artifacts, also use **Reference → CLI** (`/docs/reference/cli.md`), where `leadtype generate --json` reports paths such as `llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, and `agentReadabilityJson`.

Do **not** start with the Search page for this task. `/docs/reference/search.md` is about the static local search index and source-grounded answers, not the primary agent-facing output APIs.

Use the monolithic **`/llms-full.txt`** fallback only when the normal routing path is not enough: start at `/llms.txt`, choose the smallest matching section index, and read the linked page markdown first. Fall back to `/llms-full.txt` when you need all generated markdown docs in one root full-context file rather than targeted page or section context.