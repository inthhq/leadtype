# Agent-facing output APIs vs. search, and when to use `/llms-full.txt`

## Which docs area to use

Use the **Reference → LLM files** page: `/docs/reference/llm.md`.

That page documents the agent-facing *output* APIs that generate the agent-readable artifacts:

- `generateLlmsTxt` — writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` map for hosted websites.
- `generateLLMFullContextFiles` — writes the single root `/llms-full.txt` file containing every generated markdown docs page.
- `generateAgentsMd` — writes `AGENTS.md` for npm-bundled docs (intentionally ignores `product.agentGuidance`, which is for website URL routing).
- `isAgentReadabilityArtifactPath` — identifies artifact paths (llms.txt, llms-full.txt, sitemap files, robots.txt, search JSON, agent-readability.json) that should not be rewritten as missing markdown pages.

**Not the area you want:** the Reference → **Search** page (`/docs/reference/search.md`) is about the static search index, BM25 ranking, and source-grounded answer generation — i.e., the search path, not the agent-facing output APIs. The prompt explicitly excludes the search UI, so skip Search.

(For wiring these artifacts into a hosted build so agents can fetch markdown, see Build → "Connect a docs site," `/docs/build/connect-docs-site.md`.)

## When to use the monolithic `/llms-full.txt` fallback

`/llms-full.txt` is the **root, whole-corpus** bundle: one file flattening *every* generated markdown docs page. Per the docs' own guidance ("Choose the smallest section index that matches the task, then read the linked page markdown. Use a section full-context bundle only when page links are not enough"), treat it as a last-resort fallback in this order:

1. Start at the relevant **section index** (e.g., `/docs/reference/llms.txt`) and read the specific **page markdown** it links (the smallest unit that matches the task).
2. If individual page links aren't enough context, use the relevant **section full-context bundle** (e.g., `/docs/llms-full/reference.txt`) — all pages in one section flattened together.
3. Only use the monolithic **root `/llms-full.txt`** when even section-level bundles aren't sufficient — i.e., when you need every page across all sections in a single document and can't scope the task to one section.

### Important detail

Groups are used for routing only (llms.txt sections, navigation, search metadata, AGENTS.md), not for sharding. By default Leadtype does **not** publish per-group full-context files — the only full-corpus full-context output is the single root `/llms-full.txt` (section bundles like `/docs/llms-full/reference.txt` are the intermediate, optional fallback). So reach for `/llms-full.txt` deliberately, since it pulls in the entire docs set rather than a targeted slice.
