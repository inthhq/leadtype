# Agent-Facing Output APIs in Leadtype Docs

## Which Docs Area to Use

Use the **[Reference: LLM files](/docs/reference/llm.md)** section for agent-facing output APIs. This is found in the **Reference** section of the docs.

## The APIs

Leadtype provides three main agent-facing output APIs:

1. **`generateLlmsTxt`** - Writes the product-level `/llms.txt` and docs-scoped `/docs/llms.txt` map for hosted websites. This is the primary agent-readable index.

2. **`generateLLMFullContextFiles`** - Writes the `/llms-full.txt` file containing every generated markdown docs page as a monolithic fallback.

3. **`generateAgentsMd`** - Writes `AGENTS.md` for npm-bundled docs (used for package documentation).

## When to Use the `/llms-full.txt` Fallback

Use the **monolithic `/llms-full.txt` fallback** when:

- You need **complete section context** in a single file, rather than following individual page links
- The hierarchical page structure from `/llms.txt` and individual markdown pages is insufficient
- You require all generated markdown docs pages consolidated into one bundle

The routing philosophy is: **Start with the smallest section index that matches your task**, then read linked page markdown. Only use the full-context bundle (`/llms-full.txt`) when page links alone are not enough for the agent to understand the broader context.

## How It Integrates

For hosted docs sites:
- Serve `/llms.txt` at the site root as a navigation index
- Serve markdown at `/docs/*.md` endpoints (with `Accept: text/markdown` support)
- Optionally serve `/llms-full.txt` as a complete fallback for agents requiring monolithic context
- Keep all these as static artifacts alongside `sitemap.xml`, `robots.txt`, and search JSON
