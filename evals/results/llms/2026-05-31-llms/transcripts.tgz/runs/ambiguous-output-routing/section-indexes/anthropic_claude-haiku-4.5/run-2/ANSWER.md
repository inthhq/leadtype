# Agent-Facing Output APIs in Leadtype Docs

## Which Docs Area to Use

Use the **[Reference](/docs/reference/llms.txt)** docs area, specifically the **[LLM files](/docs/reference/llm.md)** page for agent-facing output APIs.

This page documents the APIs that generate agent-readable artifacts:
- `generateLlmsTxt` - writes /llms.txt and /docs/llms.txt
- `generateLLMFullContextFiles` - writes /llms-full.txt
- `generateAgentsMd` - writes AGENTS.md for npm bundles

The [Connect a docs site](/docs/build/connect-docs-site.md) page in the **Build** section also provides agent integration details for serving these artifacts.

## When to Use /llms-full.txt Fallback

The `/llms-full.txt` file is the monolithic full-context fallback. Use it when:

1. **Page links are not enough**: The llms.txt file explicitly states "Use a section full-context bundle only when page links are not enough."

2. **You need complete section context**: Each section in /llms.txt provides links to individual pages. The full-context files (e.g., `/docs/llms-full/reference.txt`) flatten all pages in that section into one document.

3. **You need root-level full context**: The root `/llms-full.txt` file contains every generated markdown docs page when section-level context isn't sufficient.

## Agent-Facing Output APIs Summary

Leadtype generates these agent-facing artifacts in **website mode**:
- `/llms.txt` - root index with section links
- `/docs/llms.txt` - docs-scoped section map
- `/llms-full.txt` - complete fallback with all pages
- `/docs/*.md` - markdown mirrors of pages
- `/docs/sitemap.xml` and `/docs/sitemap.md` - discovery
- `/docs/agent-readability.json` - artifact metadata
- `/docs/robots.txt` - agent guidance
- `/docs/search-index.json` and `/docs/search-content.json` - search APIs

These are **not search UI** — they are static artifacts for agents to fetch and process via HTTP or bundled in npm packages (AGENTS.md format).
