# Answer

Use the **Reference** docs area, specifically **Reference → LLM files** (`/docs/reference/llm.md`), for the agent-facing output APIs. That page covers the LLM/agent artifacts and APIs such as:

- `generateLlmsTxt` for `/llms.txt` and `/docs/llms.txt`
- `generateLLMFullContextFiles` for `/llms-full.txt`
- `generateAgentsMd` for npm-bundled `AGENTS.md`
- `isAgentReadabilityArtifactPath` for recognizing agent-readability/static artifact paths

Do **not** use the Search reference for this need unless you are working on the static search index or search-driven answer generation. Search is about BM25-style local search and optional embeddings, not the primary agent-facing output files.

Use the monolithic **`/llms-full.txt`** fallback only when the normal routed approach is not enough: start with `/llms.txt`, choose the smallest relevant section/page, and read the linked markdown first. Fall back to `/llms-full.txt` when an agent needs the entire generated markdown corpus or cannot resolve the answer from the indexed page-level docs. It is a single root full-context file containing every generated markdown docs page; groups organize routing and metadata, but Leadtype does not publish separate per-group full-context files by default.