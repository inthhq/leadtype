# Agent-Facing Output APIs in Leadtype Docs

## Which docs area to use

You should use the **[Reference](/docs/reference/llms.txt)** section, specifically the **[LLM files](/docs/reference/llm.md)** page.

This page documents the agent-facing output APIs, including:
- `generateLlmsTxt`: Generates the product-level `/llms.txt` and docs-scoped `/docs/llms.txt` map for hosted websites
- `generateLLMFullContextFiles`: Generates the `/llms-full.txt` file containing all generated markdown docs pages
- `generateAgentsMd`: Generates `AGENTS.md` for npm-bundled docs
- `isAgentReadabilityArtifactPath`: Identifies artifact paths for agent-readable outputs

## When to use the `/llms-full.txt` fallback

According to the documentation, use the full-context fallback `/llms-full.txt` **when section-level page links are not enough** and you need broader context across multiple pages.

The architectural principle is: **"Choose the smallest section index that matches the task, then read the linked page markdown. Use a section full-context bundle only when page links are not enough."**

For the Reference section specifically, the optional full-context bundle is `/docs/llms-full/reference.txt`, which flattens all Reference pages into one section bundle.

## Key architectural points

- `/llms.txt` at the root serves as the primary agent-facing navigation and discovery mechanism
- Individual `/docs/*.md` files are served to agents via HTTP when they request `Accept: text/markdown`
- The `/llms-full.txt` is a static fallback for monolithic context needs, not the primary agent interface
- The primary agent interface is the hierarchical section-based structure with `llms.txt` files at each level
