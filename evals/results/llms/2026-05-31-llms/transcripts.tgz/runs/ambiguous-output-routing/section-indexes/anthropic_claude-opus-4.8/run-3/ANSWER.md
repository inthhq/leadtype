# Agent-facing output APIs vs. search UI

## Which docs area to use

Use **Reference → [LLM files](/docs/reference/llm.md)** (`docs/reference/llm.md`).

This is the page that documents the agent-facing output APIs that produce the
agent-readable artifacts:

- `generateLlmsTxt` — writes the product-level `/llms.txt` and the docs-scoped
  `/docs/llms.txt` section maps for hosted websites.
- `generateLLMFullContextFiles` — writes the single root `/llms-full.txt`
  containing every generated markdown docs page.
- `generateAgentsMd` — writes `AGENTS.md` for npm-bundled docs.
- `isAgentReadabilityArtifactPath` — identifies artifact paths (e.g. `llms.txt`,
  `llms-full.txt`, sitemaps, `robots.txt`, search JSON, `agent-readability.json`)
  that should not be rewritten as missing markdown pages.

**Do not use the Search area for this.** Reference → [Search](/docs/reference/search.md)
covers the static search index, lexical BM25-style ranking, source-grounded
answers, and when to add embeddings. That is the search/query path, not the
APIs that emit agent-facing output files.

## When to use the monolithic `/llms-full.txt` fallback

`/llms-full.txt` is the **root full-context fallback** — one file flattening
every generated markdown docs page, produced by `generateLLMFullContextFiles`.

Per the docs' own navigation guidance, prefer the smallest scope first:

1. Start at `/llms.txt` and pick the smallest matching section index.
2. Read the linked page-level markdown (e.g. `docs/reference/llm.md`).
3. If page links aren't enough, use an **optional per-section full-context
   bundle** (e.g. `/docs/llms-full/reference.txt`).
4. Use the **monolithic root `/llms-full.txt`** only as a last-resort fallback —
   when you need broad context spanning multiple sections and neither the
   page-level markdown nor a single section bundle is sufficient.

Note: groups are used for routing/organization, not sharding, so there are no
per-group full-context files by default — the section bundles and the single
root `/llms-full.txt` are the full-context options.
