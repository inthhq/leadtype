# Agent-Facing Output APIs in the Leadtype Docs

## Which docs area to use

Use **Reference → [LLM files](/docs/reference/llm.md)** (`docs/reference/llm.md`).

This is the page that documents the *agent-facing output APIs* — the functions
that generate the artifacts agents consume:

- **`generateLlmsTxt`** — writes the product-level `/llms.txt` and the
  docs-scoped `/docs/llms.txt` section map for hosted websites.
- **`generateLLMFullContextFiles`** — writes the single root `/llms-full.txt`
  bundle containing every generated markdown docs page.
- **`generateAgentsMd`** — writes `AGENTS.md` for npm-bundled docs (it ignores
  `product.agentGuidance`, which is meant for website URL routing).
- **`isAgentReadabilityArtifactPath`** — identifies artifact paths
  (`llms.txt`, `llms-full.txt`, sitemap files, `robots.txt`, search JSON,
  `agent-readability.json`) that should not be rewritten as missing markdown.

### Not the area you want
Do **not** use **Reference → [Search](/docs/reference/search.md)**. That page
covers the static search **index/UI** path (BM25-style lexical ranking,
source-grounded answers, optional embeddings) — i.e. the search experience, not
the agent-readable output APIs you asked about.

## When to use the monolithic `/llms-full.txt` fallback

`/llms-full.txt` is the **root full-context fallback**: one file flattening
*every* generated markdown docs page. Follow the docs' own retrieval guidance:

1. **Start narrow.** Choose the smallest section index that matches the task
   (e.g. `/docs/reference/llms.txt`) and read the **page-level markdown links**
   first (e.g. `/docs/reference/llm.md`).
2. **Escalate to a section bundle** (e.g. `/docs/llms-full/reference.txt`) only
   when individual page links don't give enough context.
3. **Fall back to the monolithic `/llms-full.txt`** only when even
   section-scoped context is insufficient — i.e. when you need broad,
   cross-section context spanning the whole docs set and the per-page and
   per-section bundles aren't enough.

In short: prefer the smallest index/page that answers the question; reach for
`/llms-full.txt` last, as a whole-corpus fallback when narrower sources fall
short.
