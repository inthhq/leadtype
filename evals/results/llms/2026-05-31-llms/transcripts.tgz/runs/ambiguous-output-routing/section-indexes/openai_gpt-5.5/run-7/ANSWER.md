Use the **Reference** docs area, specifically **Reference → LLM files** (`/docs/reference/llm.md`). That page covers the agent-facing output APIs:

- `generateLlmsTxt` for product-level `/llms.txt` and docs-scoped `/docs/llms.txt`
- `generateLLMFullContextFiles` for the root full-context fallback
- `generateAgentsMd` for npm-bundled docs
- `isAgentReadabilityArtifactPath` for recognizing generated agent/readability artifacts

Do **not** use the Search page for this task; it documents the static search index and source-grounded search/answer path, not the LLM/agent output APIs.

Use the monolithic **`/llms-full.txt`** fallback only when the normal `llms.txt` routing and linked page markdown are not enough and you need the entire generated markdown docs corpus in one file. It is a root fallback containing every generated markdown docs page; groups organize navigation, `llms.txt`, search metadata, and `AGENTS.md`, but they are not published as per-group full-context files by default.