# Agent-Facing Output APIs in Leadtype Docs

## Which Docs Area to Use

For agent-facing output APIs, use the **[Reference](/docs/reference/llms.txt)** section, specifically the **[LLM files](/docs/reference/llm.md)** page.

This page documents the three primary agent-readable outputs that Leadtype generates:

1. **llms.txt** - Product-level root file and docs-scoped section maps for hosted websites
2. **llms-full.txt** - Full-context fallback containing every generated markdown docs page
3. **AGENTS.md** - For npm-bundled docs (ignores product.agentGuidance)

## When to Use `/llms-full.txt` Fallback

According to the guidance in `/llms.txt`:

> "Choose the smallest section index that matches the task, then read the linked page markdown. Use a section full-context bundle only when page links are not enough."

**Use `/llms-full.txt` when:**
- Page-level markdown links from `llms.txt` are insufficient to answer a query
- You need comprehensive, flattened context across all docs pages in a section
- The section is organized in a way where individual pages don't provide enough cross-referenced context

In the Reference section specifically, the optional full-context bundle is documented as:
- [Reference Full Context](/docs/llms-full/reference.txt): All Reference pages flattened into one section bundle

## Key Implementation Detail

For hosted sites, agents should:
1. Start with `/llms.txt` to discover available documentation sections
2. Follow linked page markdown from section indexes (like `/docs/reference/llm.md`)
3. Fall back to `/llms-full.txt` only when broader context is needed
4. Serve markdown when `Accept` requests `text/markdown` or from known AI user agents
