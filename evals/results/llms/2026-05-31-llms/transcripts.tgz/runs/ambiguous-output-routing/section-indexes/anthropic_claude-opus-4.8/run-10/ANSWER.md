# Agent-facing output APIs vs. search UI in the Leadtype docs

## Which docs area to use

Use the **Reference → "LLM files"** page: `/docs/reference/llm.md`.

That page documents the agent-facing *output* APIs (the functions that
produce agent-readable artifacts), not the search UI:

- **`generateLlmsTxt`** — writes the product-level `/llms.txt` and the
  docs-scoped `/docs/llms.txt` map for hosted websites.
- **`generateLLMFullContextFiles`** — writes the single root
  `/llms-full.txt` file containing every generated markdown docs page.
- **`generateAgentsMd`** — writes `AGENTS.md` for npm-bundled docs
  (it intentionally ignores `product.agentGuidance`, which is for website
  URL routing).
- **`isAgentReadabilityArtifactPath`** — identifies artifact paths
  (`llms.txt`, `llms-full.txt`, sitemaps, `robots.txt`, search JSON,
  `agent-readability.json`) that should not be rewritten as missing
  markdown pages.

### What NOT to use for this question

The **Reference → "Search"** page (`/docs/reference/search.md`) is about
the static search index and query/answer path (BM25-style lexical ranking,
optional embeddings). That is the search functionality, not the
agent-facing output APIs you asked about, so it is the wrong area here.

## When to use the monolithic `/llms-full.txt` fallback

Follow the docs' stated navigation discipline (from `/llms.txt` and each
section index): **choose the smallest matching index, then read the linked
page markdown first.** Reach for a flattened bundle only when those page
links are not enough.

So the order of preference is:

1. Start at the relevant **section index** (e.g. `/docs/reference/llms.txt`)
   and read the specific **page markdown** (`/docs/reference/llm.md`).
2. If page-level links don't give enough context, use the **section
   full-context bundle** (e.g. `/docs/llms-full/reference.txt`), which
   flattens all pages in that one section.
3. Use the **monolithic root `/llms-full.txt`** only as a last-resort
   fallback — when you genuinely need *every* generated markdown page in a
   single bundle and the per-page links plus the per-section bundle are
   still insufficient (e.g. cross-section context spanning the whole docs
   set).

Note: per the "LLM files" page, full-context output is produced as one root
`/llms-full.txt` file (every page). Groups organize the `llms.txt`
sections, navigation, search metadata, and `AGENTS.md`, but they are **not**
published as per-group full-context files by default — so don't expect a
group-sharded full-context artifact.
