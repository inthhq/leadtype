# Leadtype Agent-Facing Output APIs

## Which Docs Area to Use

Use the **[Reference](/docs/reference/llms.txt)** section, specifically the **[LLM files](/docs/reference/llm.md)** page for agent-facing output APIs (not search UI).

The Reference section covers:
- CLI flags and JSON output
- **LLM bundle APIs** (the agent-readable output formats)
- Search capabilities
- Lint reference

## When to Use the Monolithic `/llms-full.txt` Fallback

Use the optional **[Reference Full Context](/docs/llms-full/reference.txt)** (the monolithic section bundle) when you need broader section context beyond what individual page links provide.

### API Overview

The key agent-facing output APIs are:

1. **generateLlmsTxt**: Writes the product-level `/llms.txt` and docs-scoped `/docs/llms.txt` map for hosted websites. This is the primary entry point for HTTP agents.

2. **generateLLMFullContextFiles**: Writes one root `/llms-full.txt` file containing every generated markdown docs page. Use this as a comprehensive fallback when you need complete context.

3. **generateAgentsMd**: Writes `AGENTS.md` for npm-bundled docs (package mode, not website mode).

4. **Agent discovery artifacts**: Also includes sitemap files, robots.txt, search JSON, and agent-readability.json.

### Recommendation

- **Start with individual pages**: Read `/docs/reference/llm.md` and `/docs/reference/cli.md` for specific API details
- **Use the fallback when needed**: Only use `/docs/llms-full/reference.txt` if you need comprehensive context across all Reference pages
