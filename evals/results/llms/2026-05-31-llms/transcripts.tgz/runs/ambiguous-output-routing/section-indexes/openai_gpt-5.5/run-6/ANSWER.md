# Leadtype docs area to use

Use the **Reference** docs area, specifically **Reference → LLM files** (`/docs/reference/llm.md`), for agent-facing output APIs. That page covers the APIs/artifacts that expose docs to agents:

- `generateLlmsTxt` for the product-level `/llms.txt` and docs-scoped `/docs/llms.txt` maps.
- `generateLLMFullContextFiles` for the root `/llms-full.txt` fallback.
- `generateAgentsMd` for npm-bundled `AGENTS.md`.
- `isAgentReadabilityArtifactPath` for recognizing static agent-readability artifacts.

If the task is about wiring these artifacts into a hosted docs site, use **Build → Connect a docs site** (`/docs/build/connect-docs-site.md`) as the companion area. It explains serving markdown to agents and keeping `/llms.txt`, `/llms-full.txt`, sitemap files, robots.txt, search JSON, and `agent-readability.json` as static artifacts.

Do **not** use the Search docs as the primary area for this need. Search is for Leadtype’s static local search index and source-grounded answer retrieval behavior, not for the agent-facing output-file APIs.

# When to use `/llms-full.txt`

Use `/llms-full.txt` only as a broad fallback when the normal routing flow is not enough:

1. Start at `/llms.txt`.
2. Pick the smallest relevant section index, such as `/docs/reference/llms.txt`.
3. Read the linked page markdown, such as `/docs/reference/llm.md`.
4. Use `/llms-full.txt` only when an agent needs the entire generated markdown corpus in one file, or when page-level links/section indexes do not provide enough context.

`/llms-full.txt` is monolithic: it contains every generated markdown docs page. It is not a per-group shard, and groups should be treated as routing/organization hints rather than as separate full-context bundles.