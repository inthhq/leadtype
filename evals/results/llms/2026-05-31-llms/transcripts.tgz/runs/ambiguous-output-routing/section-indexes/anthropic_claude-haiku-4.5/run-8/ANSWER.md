# Leadtype Docs Site: Agent-Facing Output APIs

## Which Docs Area to Use

For agent-facing output APIs, consult the **[Reference](/docs/reference/llms.txt)** docs section, specifically the **[LLM files](/docs/reference/llm.md)** page.

This page documents:
- **generateLlmsTxt**: Writes the product-level `/llms.txt` and docs-scoped `/docs/llms.txt` map for hosted websites
- **generateLLMFullContextFiles**: Writes the `/llms-full.txt` full-context fallback file
- **generateAgentsMd**: Writes AGENTS.md for npm-bundled docs
- **isAgentReadabilityArtifactPath**: Identifies artifact paths that should not be rewritten

## When to Use the `/llms-full.txt` Fallback

The monolithic `/llms-full.txt` fallback should be used when:

1. **Page links are insufficient**: You need broader context than what individual pages linked in `/llms.txt` can provide
2. **Comprehensive section understanding required**: You need all docs pages from a section flattened into one bundle for complete context
3. **Context window optimization**: When page-by-page navigation isn't practical and a single full-context bundle is more efficient

As stated in the main `/llms.txt` guidance: "Choose the smallest section index that matches the task, then read the linked page markdown. Use a section full-context bundle only when page links are not enough."

## Deployment Pattern

For hosted docs sites, the agent-facing outputs are deployed as:
- `/llms.txt` at the site root (section index for HTTP discovery)
- `/llms-full.txt` at the root (fallback full-context)
- Markdown mirrors under `/docs/*.md` (served with `Accept: text/markdown` or for known AI user agents)
- Static artifacts: `/docs/sitemap.xml`, `/robots.txt`, `/search` JSON, and `agent-readability.json`
