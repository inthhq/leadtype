# Answer

Use the **Reference** docs area, specifically **Reference → LLM files** (`/docs/reference/llm.md`), for the agent-facing output APIs. That page covers the APIs that generate and identify agent-readable artifacts:

- `generateLlmsTxt` for `/llms.txt` and `/docs/llms.txt`
- `generateLLMFullContextFiles` for the root `/llms-full.txt`
- `generateAgentsMd` for bundled `AGENTS.md`
- `isAgentReadabilityArtifactPath` for recognizing agent-readability artifacts

Do **not** use the Search docs area if you need output APIs rather than search UI or query behavior; `/docs/reference/search.md` is about the static search index, lexical ranking, source-grounded answer generation, and embeddings.

Use the monolithic **`/llms-full.txt`** fallback only when the normal routing flow is insufficient: start from `/llms.txt`, choose the smallest relevant section index, and read the linked page markdown first. Fall back to `/llms-full.txt` when those targeted page links or section context are not enough and you need one file containing every generated markdown docs page.