# Agent-facing output APIs in the Leadtype docs

## Which docs area to use

Use the **Reference → LLM files** page (`/docs/reference/llm.md`). This is the docs area that documents the agent-facing output APIs that generate the agent-readable bundles, and it deliberately excludes the search UI:

- `generateLlmsTxt` — writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` map for hosted websites.
- `generateLLMFullContextFiles` — writes the single root `/llms-full.txt` file containing every generated markdown docs page.
- `generateAgentsMd` — writes `AGENTS.md` for npm-bundled docs (it ignores `product.agentGuidance`, which is meant for website URL routing).
- `isAgentReadabilityArtifactPath` — identifies artifact paths (llms.txt, llms-full.txt, sitemap files, robots.txt, search JSON, agent-readability.json) that should not be rewritten as missing markdown pages.

If you need broader context across all Reference pages at once, the section bundle `/docs/llms-full/reference.txt` is available as an optional full-context bundle.

> Note: deliberately **not** the search area. `/docs/reference/search.md` describes the static search index / source-grounded answers and the runtime query path — that is the search behavior, not the agent output APIs. (There is no "search UI" doc per se; just avoid the search reference when you want the output APIs.)

The **Build → Connect a docs site** page (`/docs/build/connect-docs-site.md`) is complementary: it covers how these generated artifacts are served (website mode, serving markdown on `Accept: text/markdown` or known AI user agents, and keeping `/llms.txt`, `/llms-full.txt`, sitemap, robots.txt, search JSON, and agent-readability.json as static artifacts).

## When to use the monolithic `/llms-full.txt` fallback

`/llms-full.txt` is the **root, whole-corpus** full-context fallback produced by `generateLLMFullContextFiles` — one file containing every generated markdown docs page.

Follow the site's stated navigation strategy: **choose the smallest section index that matches the task, read the linked page markdown first, and only fall back to a full-context bundle when page links are not enough.**

So the order of preference is:

1. The relevant **section index** (`llms.txt`) → linked **page markdown** (e.g. `/docs/reference/llm.md`).
2. A **section-level full-context bundle** (e.g. `/docs/llms-full/reference.txt`) when one section's pages don't give enough context.
3. The **monolithic `/llms-full.txt`** only as a last resort — when you genuinely need the entire docs corpus in one bundle and narrower page/section reads are insufficient.

Note that groups are used for routing, not sharding: per-group full-context files are **not** published by default, so the only whole-corpus full-context artifact is the single root `/llms-full.txt`.
