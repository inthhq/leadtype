# Agent-Facing Output APIs in Leadtype

## Which docs area to use

Use the **Reference** section, and specifically the **LLM files** page:
`/docs/reference/llm.md`.

That page documents the agent-facing output APIs (the generators that emit
agent-readable artifacts), not the search UI:

- **`generateLlmsTxt`** — writes the product-level `/llms.txt` and the
  docs-scoped `/docs/llms.txt` map for hosted websites.
- **`generateLLMFullContextFiles`** — writes the single root `/llms-full.txt`
  file containing every generated markdown docs page.
- **`generateAgentsMd`** — writes `AGENTS.md` for npm-bundled docs (it
  intentionally ignores `product.agentGuidance`, which is meant for website
  URL routing).
- **`isAgentReadabilityArtifactPath`** — identifies artifact paths that should
  not be rewritten as missing markdown pages (covers `llms.txt`,
  `llms-full.txt`, sitemap files, `robots.txt`, search JSON, and
  `agent-readability.json`).

Avoid the **Search** page (`/docs/reference/search.md`) for this need — it
covers the static search index, BM25 ranking, source-grounded answers, and
embeddings, i.e. the search path rather than the output APIs you want.

(For deployment/wiring of these artifacts into a hosted site, see the **Build**
section's `connect-docs-site.md`, but the API surface itself lives in
Reference → LLM files.)

## When to use the monolithic `/llms-full.txt` fallback

The docs site is designed for **progressive, smallest-scope retrieval**:

1. Start at `/llms.txt` and pick the **smallest section index** that matches
   the task (here, `/docs/reference/llms.txt`).
2. Read the **linked page markdown** first (e.g. `/docs/reference/llm.md`).
3. Use a **section full-context bundle** (e.g.
   `/docs/llms-full/reference.txt`) only when the individual page links are
   not enough.

The **root monolithic `/llms-full.txt`** is the broadest fallback — one file
containing *every* generated markdown page. Reach for it only as a **last
resort**, when neither the targeted page markdown nor a single section's
full-context bundle gives you enough context (for example, a question that
spans multiple sections of the docs). For a focused question about the output
APIs, the page `/docs/reference/llm.md` is sufficient and you should not need
`/llms-full.txt`.

Note: full-context output is produced at the **root** level (`/llms-full.txt`)
and optionally per **section** (`/docs/llms-full/*.txt`). Groups organize
`llms.txt` sections, navigation, search metadata, and `AGENTS.md`, but are
**not** published as per-group full-context files by default — so don't expect
a per-group full-context fallback.
