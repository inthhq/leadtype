# Agent-facing output APIs vs. search UI

## Which docs area to use

Use the **Reference → "LLM files"** page: `/docs/reference/llm.md`.

Navigation path: start at `/llms.txt` → **Reference** section index (`/docs/reference/llms.txt`) → **LLM files** (`/docs/reference/llm.md`).

This page documents the agent-facing *output* APIs that produce agent-readable artifacts:

- `generateLlmsTxt` — writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` map for hosted websites.
- `generateLLMFullContextFiles` — writes the single root `/llms-full.txt` containing every generated markdown docs page.
- `generateAgentsMd` — writes `AGENTS.md` for npm-bundled docs (intentionally ignores `product.agentGuidance`, which is for website URL routing).
- `isAgentReadabilityArtifactPath` — identifies artifact paths (e.g. `llms.txt`, `llms-full.txt`, sitemaps, `robots.txt`, search JSON, `agent-readability.json`) that should not be rewritten as missing markdown pages.

### What NOT to use for this

Do **not** use the **Search** page (`/docs/reference/search.md`). That covers the static local search index, BM25-style lexical ranking, source-grounded answer generation, and optional embeddings — i.e., the search/query path, not the agent-facing output APIs you asked for.

## When to use the monolithic `/llms-full.txt` fallback

`/llms-full.txt` is the **root full-context fallback** produced by `generateLLMFullContextFiles`: one file flattening *every* generated markdown docs page.

Per the docs' guidance ("Choose the smallest section index that matches the task, then read the linked page markdown. Use a section full-context bundle only when page links are not enough."), the preferred flow is:

1. Read the relevant **section index** (`llms.txt`).
2. Read the linked **page-level markdown** (e.g. `/docs/reference/llm.md`).
3. If broader context is needed, use the **optional per-section full-context bundle** (e.g. `/docs/llms-full/reference.txt`).

Use the monolithic root `/llms-full.txt` only as a **last-resort fallback** — when neither the targeted page markdown nor a single section's full-context bundle gives enough context and you need the entire corpus in one file. Note that groups organize sections/navigation/search/AGENTS.md but are **not** published as per-group full-context files by default, so the choices are a per-section bundle or the one root `/llms-full.txt`.
