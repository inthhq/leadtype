# Agent-Facing Output APIs for Leadtype Docs

## Which Docs Area to Use

For **agent-facing output APIs** (not search UI), use the **[Reference](/docs/reference/llms.txt)** docs area, specifically:

- **[LLM files](/docs/reference/llm.md)** - Details on generating llms.txt, the root full-context fallback (/llms-full.txt), and AGENTS.md
- **[CLI](/docs/reference/cli.md)** - JSON output paths for generated artifacts in website mode, including llmsFullTxt, docsLlmsTxt, llmsTxt, agentReadabilityJson, sitemapXml, sitemapMd, robotsTxt, searchIndex, and searchContent

Alternative for broader context: **[Reference Full Context](/docs/llms-full/reference.txt)** - All Reference pages flattened into one section bundle.

## When to Use the Monolithic `/llms-full.txt` Fallback

Use the `/llms-full.txt` fallback in these scenarios:

1. **When page links are insufficient** - The root /llms-full.txt contains every generated markdown docs page not split by group, providing complete context when following individual page links is not enough.

2. **Handling unknown group declarations** - If a page declares an unknown group, it may need the full-context bundle to be accessed. The /llms-full.txt fallback ensures all pages remain discoverable regardless of group configuration.

3. **Full-context agent requests** - When an agent needs comprehensive knowledge of the entire docs structure without following the hierarchical section indexes from /llms.txt.

4. **As a static artifact to serve** - Per the deployment guidance, keep /llms-full.txt as a static artifact alongside /llms.txt, markdown mirrors, sitemaps, robots.txt, search JSON, and agent-readability.json.

**Key principle**: Start with the smallest section index that matches the task (following /llms.txt page links), and only use the monolithic /llms-full.txt when page links alone are not sufficient.
