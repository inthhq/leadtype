# Agent-facing output APIs in the Leadtype docs

## Which docs area to use

Use **Reference → LLM files** at `/docs/reference/llm.md`.

That page documents the agent-facing output APIs that generate the agent-readable artifacts:

- **`generateLlmsTxt`** — writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` map for hosted websites.
- **`generateLLMFullContextFiles`** — writes the single root `/llms-full.txt` containing every generated markdown docs page.
- **`generateAgentsMd`** — writes `AGENTS.md` for npm-bundled docs (it intentionally ignores `product.agentGuidance`, which is written for website URL routing).
- **`isAgentReadabilityArtifactPath`** — identifies artifact paths (e.g. `llms.txt`, `llms-full.txt`, sitemap, `robots.txt`, search JSON, `agent-readability.json`) that should not be rewritten as missing markdown pages.

### Why not Search

`/docs/reference/search.md` covers the static search index, BM25-style lexical ranking, source-grounded answers, and when embeddings help — i.e., the search/retrieval path, not the output-generation APIs. The question explicitly asks for the **output APIs, not the search UI**, so Search is the wrong area here.

## When to use the monolithic `/llms-full.txt` fallback

Follow the navigation discipline that the docs site itself prescribes:

1. **Default:** Choose the smallest section index that matches your task, then read the linked page-level markdown (e.g., start at `/llms.txt`, drill into a section index like `/docs/reference/llms.txt`, then read `/docs/reference/llm.md`).
2. **Fallback:** Use a full-context bundle **only when the page-level links are not enough** — when you need broader context than the targeted page markdown provides.

For `/llms-full.txt` specifically:

- `/llms-full.txt` is the **root, monolithic** bundle: one file flattening *every* generated markdown docs page (produced by `generateLLMFullContextFiles`).
- Prefer the smaller, **per-section** full-context bundles first (e.g., `/docs/llms-full/reference.txt`, `/docs/llms-full/build.txt`) when a single section's broader context suffices.
- Reach for the monolithic root `/llms-full.txt` only as a last resort — when you genuinely need the entire corpus in one place and neither the page links nor a single section bundle is sufficient. Note that groups organize sections/navigation/search/AGENTS.md but are **not** published as per-group full-context files by default, so cross-section needs fall back to the root bundle.

### Quick summary

- **Output APIs:** Reference → LLM files (`/docs/reference/llm.md`).
- **`/llms-full.txt` fallback:** Use it only when page-level markdown (and section bundles) cannot give you enough context — the monolithic all-pages bundle is the broadest, last-resort option.
