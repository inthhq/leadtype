# Answer

Use the **Reference** docs area, specifically **Reference → LLM files** (`/docs/reference/llm.md`), for the agent-facing output APIs. That page covers the APIs/artifacts for agent-readable output:

- `generateLlmsTxt` for the product-level `/llms.txt` and docs-scoped `/docs/llms.txt` maps
- `generateLLMFullContextFiles` for the root `/llms-full.txt`
- `generateAgentsMd` for npm-bundled docs
- `isAgentReadabilityArtifactPath` for recognizing generated agent-readability/static artifact paths

Do **not** use the Search docs area for this unless you are working on the static search index or source-grounded answer generation path. Search is separate from the agent-facing LLM file outputs.

Use the monolithic **`/llms-full.txt`** fallback only when the normal routing flow is not enough: start from `/llms.txt`, pick the smallest relevant section/page links, and read the linked markdown first. Reach for `/llms-full.txt` when an agent needs one all-docs bundle or cannot get sufficient context from the section indexes and page-level markdown. It contains every generated markdown docs page and is not split per group; groups are for routing/organization, not sharding full-context files.
