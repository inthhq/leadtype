# Agent-Facing Output APIs in Leadtype Docs

## Which docs area to use

For agent-facing output APIs, use the **[Reference](/docs/reference/llms.txt)** section, specifically the **[LLM files page](/docs/reference/llm.md)**.

This page documents the agent-readable APIs:
- `generateLlmsTxt` - Generates the product-level `/llms.txt` and docs-scoped `/docs/llms.txt` map
- `generateLLMFullContextFiles` - Generates the fallback `/llms-full.txt` file
- `generateAgentsMd` - Generates `AGENTS.md` for npm-bundled docs
- `isAgentReadabilityArtifactPath` - Identifies artifact paths for agents

## When to use the `/llms-full.txt` fallback

Use the monolithic `/llms-full.txt` full-context bundle in these scenarios:

1. **When you need broader section context** - The Reference section index recommends using `/docs/llms-full/reference.txt` (the full-context version) when "the answer needs broader section context" beyond individual page links.

2. **As a fallback for agents** - `/llms-full.txt` is generated as "one root file containing every generated markdown docs page" and serves as the full-context fallback when agents need comprehensive content.

3. **When pages alone aren't sufficient** - Use the full-context bundle only after trying the targeted page-level markdown links first, as recommended by the Leadtype design philosophy.

The general guidance from Leadtype is: **Choose the smallest section index that matches the task, then read the linked page markdown. Use a section full-context bundle only when page links are not enough.**
