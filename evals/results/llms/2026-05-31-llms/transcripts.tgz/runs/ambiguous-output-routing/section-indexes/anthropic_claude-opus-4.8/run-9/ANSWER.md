# Agent-facing output APIs in the Leadtype docs

## Which docs area to use

Use **Reference → LLM files** (`/docs/reference/llm.md`).

That page documents the agent-facing output APIs that produce agent-readable bundles:

- `generateLlmsTxt` — writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` map for hosted sites.
- `generateLLMFullContextFiles` — writes the single root `/llms-full.txt` containing every generated markdown docs page.
- `generateAgentsMd` — writes `AGENTS.md` for npm-bundled docs (intentionally ignores `product.agentGuidance`, which is for website URL routing).
- `isAgentReadabilityArtifactPath` — identifies artifact paths (llms.txt, llms-full.txt, sitemaps, robots.txt, search JSON, agent-readability.json) that shouldn't be rewritten as missing markdown pages.

**Not** the Search area (`/docs/reference/search.md`). That page covers the static search index, BM25 lexical ranking, source-grounded answer generation, and when embeddings help — i.e., the search/query path, not the agent-facing output/generation APIs you're asking about.

(If you need the deployment/wiring perspective rather than the API surface, see **Build → Connect a docs site**, but for the output APIs themselves the Reference LLM files page is the right area.)

## When to use the monolithic `/llms-full.txt` fallback

`/llms-full.txt` is the **root full-context fallback** — one file flattening every generated markdown docs page. Per the docs' own usage guidance, prefer the smallest matching index and read the linked page markdown first; reach for a full-context bundle only when the page links are not enough.

So use `/llms-full.txt` only as a fallback when:

- The narrower, more targeted artifacts are insufficient: the section indexes (`/llms.txt`, `/docs/llms.txt`), the individual page markdown, or an optional per-section full-context bundle (e.g. `/docs/llms-full/reference.txt`).
- You genuinely need the entire corpus in one context rather than a specific section or page.

Note that groups are used for routing/navigation/search metadata and `AGENTS.md` organization — they are **not** published as per-group full-context files by default. The single root `/llms-full.txt` is the all-pages monolithic bundle, intended as the broadest, last-resort context source.
