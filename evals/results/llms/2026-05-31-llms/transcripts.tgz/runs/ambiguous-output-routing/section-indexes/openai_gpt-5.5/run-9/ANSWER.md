# Answer

Use the **Reference** docs area, specifically **Reference → LLM files** (`/docs/reference/llm.md`), for the agent-facing output APIs/artifacts. That page covers the APIs that generate or identify agent-readable outputs:

- `generateLlmsTxt` for `/llms.txt` and `/docs/llms.txt`
- `generateLLMFullContextFiles` for the root full-context fallback `/llms-full.txt`
- `generateAgentsMd` for npm-bundled `AGENTS.md`
- `isAgentReadabilityArtifactPath` for recognizing agent-readability/static artifact paths

Do **not** start with the Search docs if you are not building search UI or retrieval behavior. The Search page is about the static search index and source-grounded answer generation, not the primary agent-facing output files.

Use the monolithic **`/llms-full.txt`** fallback only when the normal routing path is not enough: start from `/llms.txt`, choose the smallest relevant section index, and read the linked page markdown first. Fall back to `/llms-full.txt` when you need whole-site context in one file or the targeted page/section links do not provide enough context. It contains every generated markdown docs page; groups organize routing and metadata, but are not published as per-group full-context files by default.