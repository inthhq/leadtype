# Frontmatter `group` and Combined All-Docs Output

## How `group` controls navigation

In Leadtype, each MDX page carries YAML frontmatter. The `group` field is
**optional** and, when present, should match a slug defined in
`docs.config.ts`. If a page declares an unknown group, the build fails.

The `group` value drives several navigation and metadata behaviors at once:

- **Sidebar position** — determines where the page appears in the navigation tree.
- **`llms.txt` section** — groups organize the sections of the generated `llms.txt` map.
- **Search metadata** — group is included in the page's search metadata.
- **`AGENTS.md` grouping** — used to organize the npm-bundled `AGENTS.md`.

A page may belong to more than one group using list syntax, e.g.
`group: [a, b]`.

Guidance from the docs: use groups for **routing, not sharding**, and write
group descriptions as routing hints rather than marketing copy.

## How `group` relates to the combined all-docs output

The combined full-context output behaves differently from navigation:

- `generateLLMFullContextFiles` writes **one** root `/llms-full.txt` file that
  contains **every** generated markdown docs page.
- This combined file is the fallback containing all generated markdown pages
  and is **not split by group**.
- Groups still organize `llms.txt` sections, navigation, search metadata, and
  `AGENTS.md`, but they are **not** published as per-group full-context files
  by default.

In short: `group` shapes how docs are organized for navigation and discovery,
but the combined all-docs output (`/llms-full.txt`) ignores grouping and emits
the complete set of pages in a single file.

## Optional frontmatter fields

`title` is the only required field. `description` is optional but recommended,
because it becomes the routing hint in `llms.txt`. `group` itself is optional.

Other optional fields include:

- `icon`
- `deprecated`
- `deprecatedReason`
- `experimental`
- `canary`
- `new`
- `draft`
- `tags`
- `availableIn`
- `full`
- `lastModified` — populated when `--enrich-git` is enabled
- `lastAuthor` — populated when `--enrich-git` is enabled

(At least two optional fields, e.g. `description` and `tags`, are shown above.)
