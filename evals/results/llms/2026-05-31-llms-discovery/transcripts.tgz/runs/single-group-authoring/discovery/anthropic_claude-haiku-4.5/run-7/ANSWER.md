# Frontmatter Group and Combined Output in Leadtype

## The `group` Field

In the Leadtype library, the frontmatter `group` field is a crucial control mechanism that drives multiple aspects of documentation organization and output:

### Navigation and Organization
The `group` value is **optional** and should match a slug from `docs.config.ts`. It controls:
- **Sidebar position**: Determines where pages appear in the documentation sidebar
- **Section organization**: Organizes content into logical groupings
- **Multiple groups support**: Pages can belong to multiple groups using the syntax `group: [a, b]`

### Combined Output Control
The `group` field manages how content is distributed across different outputs:
- **llms.txt sections**: Splits the product-level `/llms.txt` and docs-scoped `/docs/llms.txt` map by group sections
- **Search metadata**: Groups influence search result categorization and metadata
- **AGENTS.md grouping**: Controls how content is organized in the `AGENTS.md` file for npm-bundled documentation
- **Full context fallback**: The root `/llms-full.txt` file contains all generated markdown pages and serves as a fallback that is not split by group

### Important Consideration
If a page declares an unknown group, the build fails. Groups are designed for **routing and organization**, not for sharding the full-context files.

## Optional Frontmatter Fields

Beyond the required `title` field and the optional `group` field, Leadtype supports numerous optional frontmatter fields:

1. **`icon`**: Specifies an icon to display alongside the page in navigation and UI elements.

2. **`deprecated`**: A boolean field marking whether a page or feature is deprecated. When used with `deprecatedReason`, it provides clear guidance to users about outdated content.

3. **`experimental`**: Marks content as experimental or in development.

4. **`description`**: Recommended optional field that becomes the routing hint in `llms.txt` and enhances discoverability.

5. **`tags`**: Allows categorization of content beyond groups for flexible filtering.

6. **`lastModified`** and **`lastAuthor`**: Populated automatically when the `--enrich-git` flag is enabled during generation, tracking documentation maintenance.

These fields work together with the `group` field to create a comprehensive metadata system that controls navigation, output generation, and agent guidance across both website-mode and bundled documentation artifacts.
