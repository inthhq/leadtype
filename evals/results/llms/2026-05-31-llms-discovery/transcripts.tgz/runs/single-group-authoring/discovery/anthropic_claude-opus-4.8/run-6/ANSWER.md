# Frontmatter `group` and Combined All-Docs Output

## What `group` is

In Leadtype, every MDX page has YAML frontmatter. The `title` field is
required, `description` is optional (but recommended, since it becomes the
routing hint in `llms.txt`), and `group` is optional. When present, `group`
should match a slug defined in `docs.config.ts`. If a page declares an unknown
group, the build fails.

(Source: `docs/authoring/frontmatter.md`.)

## How `group` controls navigation

The `group` value drives several navigation and metadata surfaces at once:

- **Sidebar position** — the page's placement in the docs site sidebar.
- **`llms.txt` section** — which section the page is listed under in the
  generated `llms.txt` map.
- **Search metadata** — the grouping used for search indexing.
- **`AGENTS.md` grouping** — how the page is organized in npm-bundled agent docs.

A page can belong to more than one group by using a list, e.g.
`group: [a, b]`. During the build, Leadtype "resolves the group tree" while
processing pages (see `docs/how-it-works.md`).

The guidance is to **use groups for routing, not sharding**, and group
descriptions should be routing hints rather than marketing copy
(`docs/reference/llm.md`).

## How `group` relates to the combined all-docs output

The combined output is the root **`/llms-full.txt`** file, written by
`generateLLMFullContextFiles`. Key points:

- `/llms-full.txt` is a single root file containing **every generated markdown
  docs page**.
- It is a fallback that is **not split by group** — groups do not produce
  per-group full-context files by default.
- Groups still organize the `llms.txt` sections, navigation, search metadata,
  and `AGENTS.md`, but they do not affect what goes into the combined
  `llms-full.txt` (which always includes all pages).

(Sources: `docs/authoring/frontmatter.md`, `docs/reference/llm.md`.)

## Optional frontmatter fields

Besides `description` and `group`, optional frontmatter fields include:

`icon`, `deprecated`, `deprecatedReason`, `experimental`, `canary`, `new`,
`draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor`.

Two examples:

- **`tags`** — additional labels/metadata for the page.
- **`deprecated`** — marks a page as deprecated (often paired with
  `deprecatedReason`).

Note: `lastModified` and `lastAuthor` are populated only when `--enrich-git`
is enabled (`docs/authoring/frontmatter.md`). The `leadtype lint` command can
fail the build on unknown frontmatter fields when run with `--error-unknown`
and `--max-warnings 0` (`docs/reference/cli.md`).
