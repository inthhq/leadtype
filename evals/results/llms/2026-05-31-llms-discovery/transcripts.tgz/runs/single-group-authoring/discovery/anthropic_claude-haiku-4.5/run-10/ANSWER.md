# Frontmatter Group and Combined Output in Leadtype

## The `group` Field

The `group` field in frontmatter is a **required reference that controls multiple aspects of documentation organization and output** in the Leadtype library.

### How Group Controls Navigation

The `group` field drives four key navigation and organization features:

1. **Sidebar Position**: The group value determines where a page appears in the sidebar hierarchy
2. **LLMs.txt Section Organization**: Pages are grouped within the `/llms.txt` file based on their group assignment
3. **Search Metadata**: Group information is included in search index metadata for categorized discovery
4. **AGENTS.md Grouping**: In bundled output, pages are grouped within the `AGENTS.md` file according to their group values

### How Group Controls Combined Output

The `group` field influences the generation of combined documentation output:

- **Website Mode**: Pages are organized into group-specific sections within `/llms.txt` (group-specific output) and `/llms-full.txt` (all-docs combined output without group splitting)
- **Bundle Mode**: Pages are organized in `AGENTS.md` with group-based structure for offline npm package distribution
- **Multi-group Support**: A single page can declare multiple groups using `group: [a, b]`, allowing it to appear in multiple organizational contexts

### The Fallback Combined Output

The **`/llms-full.txt` file serves as the root fallback containing all generated markdown pages and is not split by group**. This ensures complete documentation is always available when agents don't need group-specific filtering.

### Validation Requirements

The group value must match a slug from `docs.config.ts`. If a page declares an unknown group, the build fails, ensuring group references are always valid and properly configured.

## Optional Frontmatter Fields

Beyond the required `title` and optional `group`, Leadtype supports several optional frontmatter fields:

### Field 1: `icon`
Used to assign a visual icon to represent the page in navigation and documentation listings.

### Field 2: `deprecated`
A boolean flag that marks a page as deprecated, signaling to users and agents that the content is outdated and may be replaced.

### Additional Optional Fields

The complete set of optional fields also includes:
- `deprecatedReason`: Explains why a page is deprecated
- `experimental`: Marks features or pages as experimental
- `canary`: Indicates unstable/pre-release features
- `new`: Highlights newly added pages
- `draft`: Marks pages as work-in-progress
- `tags`: Adds searchable tags for categorization
- `availableIn`: Specifies where content is available
- `full`: Controls inclusion in full documentation output
- `lastModified`: Timestamp of last modification (auto-filled with `--enrich-git`)
- `lastAuthor`: Author of last modification (auto-filled with `--enrich-git`)

The `description` field, while technically optional, is recommended as it becomes the routing hint in `llms.txt` for improved agent navigation.
