# Frontmatter Group Field and Combined Output in Leadtype

## Overview
The `group` field in MDX page frontmatter is a key control mechanism in the Leadtype library that governs navigation structure and documentation output organization.

## How the `group` Field Controls Navigation and Combined Output

### Navigation Control
The `group` value drives the **sidebar position**, determining how pages are organized in the navigation hierarchy. The group must match a slug from `docs.config.ts`, and pages are positioned in the sidebar according to their assigned group.

### Combined Output Control
The `group` field controls organization across multiple generated outputs:

1. **llms.txt Section**: The group determines how pages are segmented in the `llms.txt` file, which is used by HTTP agents to navigate documentation. Each group gets its own section in the output.

2. **Search Metadata**: Group information is embedded in search metadata, allowing search functionality to filter and organize results by documentation section.

3. **AGENTS.md Grouping**: Pages are grouped together in the `AGENTS.md` file based on their group assignment, providing offline documentation structure for npm package-based agents.

4. **Full Fallback Output**: The root `/llms-full.txt` file contains all generated markdown pages and serves as a fallback. Unlike group-specific outputs, it is **not split by group** and provides a comprehensive view of all documentation.

### Multi-group Support
Pages can belong to multiple groups using the syntax `group: [a, b]`, allowing single documents to appear in multiple navigation sections and outputs simultaneously.

### Build Validation
If a page declares an unknown group (a group not defined in `docs.config.ts`), the build fails, ensuring referential integrity in the documentation structure.

## Optional Frontmatter Fields

While `title` is required and `description` is recommended, Leadtype supports the following optional frontmatter fields:

1. **`icon`**: Specifies an icon for visual representation in navigation and UI elements.

2. **`deprecated`**: Boolean flag indicating whether a page or feature is deprecated, affecting how it appears in documentation and search results.

3. **`deprecatedReason`**: Provides context for why content is deprecated.

4. **`experimental`**: Marks content as experimental or beta, signaling to users that it may change.

5. **`canary`**: Indicates content related to canary releases or features.

6. **`new`**: Flags newly added content.

7. **`draft`**: Marks pages as draft status, potentially excluding them from certain outputs.

8. **`tags`**: Array of tags for categorization and filtering.

9. **`availableIn`**: Specifies which versions or environments this content applies to.

10. **`full`**: Boolean field related to full documentation output.

11. **`lastModified`**: Automatically filled when `--enrich-git` flag is enabled; captures the last modification date.

12. **`lastAuthor`**: Automatically filled when `--enrich-git` flag is enabled; captures the last author's name.

## Summary

The `group` field is fundamental to Leadtype's architecture, serving as the primary organizational unit for both navigation structures and generated outputs. It ensures consistency across multiple output formats (llms.txt, search metadata, AGENTS.md) while supporting flexible multi-group assignment. The comprehensive set of optional metadata fields enables sophisticated documentation management, including lifecycle indicators (deprecated, experimental, new), version targeting, and git-based automation.
