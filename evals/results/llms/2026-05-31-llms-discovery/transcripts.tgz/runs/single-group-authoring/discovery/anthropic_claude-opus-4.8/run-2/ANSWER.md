# Frontmatter `group` and the Combined All-Docs Output

## What `group` does

In Leadtype, each MDX page carries YAML frontmatter. The `group` field is **optional**, and when present its value should match a slug defined in `docs.config.ts`. If a page declares a group that does not exist there, **the build fails**.

The `group` value is the central organizing key for several derived artifacts. It drives:

- **Navigation / sidebar** — the group determines the page's sidebar position.
- **`llms.txt` sections** — pages are bucketed into sections by group.
- **Search metadata** — group is included in search index data.
- **`AGENTS.md` grouping** — the npm-bundled `AGENTS.md` is organized by group.

A page can belong to **multiple groups** by using a list, e.g. `group: [a, b]`.

Guidance from the docs: use groups for **routing, not sharding**, and write group descriptions as routing hints rather than marketing copy.

## How `group` relates to the combined all-docs output

The combined all-docs file is the root **`/llms-full.txt`**, produced by `generateLLMFullContextFiles`. Key behavior:

- It contains **every generated markdown docs page** as a single fallback file.
- It is **not split by group** — there is no per-group full-context file by default.
- Groups still organize the *other* artifacts (`llms.txt` sections, navigation, search metadata, and `AGENTS.md`), but they do not shard the combined output.

In short: `group` controls how docs are organized for navigation, section maps, and search/agent metadata, while the combined `/llms-full.txt` ignores grouping and bundles all pages together.

## Required vs. optional frontmatter fields

- **Required:** `title`.
- **Recommended:** `description` (becomes the routing hint in `llms.txt`).

### Optional frontmatter fields (at least two)

The following fields are optional:

- `group` — assigns the page to one or more navigation/section groups.
- `icon` — an icon for the page.
- `deprecated` and `deprecatedReason` — mark a page as deprecated and explain why.
- `experimental`, `canary`, `new`, `draft` — lifecycle/status flags.
- `tags` — metadata tags.
- `availableIn` — version/availability info.
- `full` — full-content flag.
- `lastModified` and `lastAuthor` — git enrichment fields, populated when `--enrich-git` is enabled.

(Two clear examples of optional fields: **`icon`** and **`tags`**; both `deprecated`/`deprecatedReason` and the `experimental`/`canary`/`new`/`draft` status flags are also optional.)

## Lint behavior

`leadtype lint` validates frontmatter, group references, links, and schema rules. In CI, use `--format github`, and combine `--error-unknown` with `--max-warnings 0` so that unknown frontmatter fields fail the build.
