# Frontmatter Group Field and Combined Output in Leadtype

## How the `group` Field Controls Navigation and Combined Output

The `group` frontmatter field is a key routing mechanism in the Leadtype library that controls multiple aspects of documentation organization and output generation:

### Navigation and Organization
- **Sidebar Position**: The `group` value determines where a page appears in the sidebar navigation structure
- **Multiple Groups Support**: Pages can belong to multiple groups using the syntax `group: [a, b]`, allowing flexible categorization
- **llms.txt Organization**: The group value organizes sections in the product-level `/llms.txt` and docs-scoped `/docs/llms.txt` files for hosted websites
- **Search Metadata**: Group information is included in search metadata for better categorization and filtering
- **AGENTS.md Grouping**: Groups also determine how pages are organized in the AGENTS.md file for npm-bundled documentation

### Combined Output
- **Root Fallback**: The root `/llms-full.txt` file contains all generated markdown pages regardless of group assignment and is not split by group—it serves as a complete reference containing every documented page
- **Group Validation**: If a page declares an unknown group (one that doesn't match a slug from `docs.config.ts`), the build will fail, ensuring consistency

### Best Practice
Groups should be used for routing purposes, not for sharding output. Group descriptions should serve as routing hints to help organize navigation, not as marketing copy.

---

## Two Optional Frontmatter Fields

### 1. **`deprecated` and `deprecatedReason`**
These fields work together to mark pages or features as deprecated. The `deprecated` field is a boolean flag indicating the page is no longer actively maintained, while `deprecatedReason` provides context explaining why the feature is deprecated and what alternatives users should consider.

### 2. **`tags`**
The `tags` field allows authors to assign multiple metadata tags to pages for enhanced searchability, filtering, and organization. This enables more granular categorization beyond the group structure, helping users discover related content through shared tags.

---

## Summary

The `group` field is a foundational organizational mechanism in Leadtype that drives sidebar navigation, content organization in llms.txt files, search metadata, and AGENTS.md grouping. The combined `/llms-full.txt` output ensures that all documentation pages are accessible in a single complete reference file, regardless of their group assignments. Optional fields like `deprecated`/`deprecatedReason` and `tags` provide additional metadata for content lifecycle management and improved discoverability.
