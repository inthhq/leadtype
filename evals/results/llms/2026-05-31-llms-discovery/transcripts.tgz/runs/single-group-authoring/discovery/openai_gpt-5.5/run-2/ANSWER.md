# Frontmatter `group` and combined all-docs output

In Leadtype, each MDX page can define a frontmatter `group` value. The field is optional, but when present it should match a group slug from `docs.config.ts`; an unknown group causes the build to fail.

The `group` field is used for organization and routing:

- It determines where the page appears in the sidebar/navigation.
- It determines which section of `llms.txt` the page appears under.
- It is included in search metadata.
- It controls grouping in generated `AGENTS.md` package docs.
- A page can be assigned to multiple groups with `group: [a, b]`.

Groups do **not** split the combined all-docs output. The root `/llms-full.txt` file is a full-context fallback that contains every generated markdown docs page in one file, regardless of group. In other words, groups organize navigation, routing, search metadata, `llms.txt`, and `AGENTS.md`, but Leadtype does not publish per-group full-context files by default.

Other frontmatter fields include:

- `title` — required.
- `description` — optional but recommended; used as the routing hint in `llms.txt`.
- `icon`, `deprecated`, `deprecatedReason`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor` are also optional.
- `lastModified` and `lastAuthor` can be filled automatically when `--enrich-git` is enabled.
