# Frontmatter Group and Combined Output in Leadtype

## How the `group` Field Controls Navigation and Output

In the Leadtype library, the frontmatter `group` field is a critical control mechanism for organizing documentation. The `group` value (which should match a slug from `docs.config.ts`) drives multiple aspects of the documentation system:

### Navigation and Organization Control
- **Sidebar positioning**: The group value determines where a page appears in the sidebar navigation structure
- **AGENTS.md grouping**: Groups organize the structure of AGENTS.md, which is used for npm-bundled offline documentation for coding agents
- **Search metadata**: Group information is included in search metadata, allowing users to filter results by documentation section

### Combined All-Docs Output Control
- **llms.txt section organization**: The group value organizes sections within the product-level `/llms.txt` and docs-scoped `/docs/llms.txt` files
- **llms-full.txt fallback**: While groups organize the split output files (llms.txt and search), the root `/llms-full.txt` file provides a fallback containing all generated markdown pages without group splitting
- **Group flexibility**: Pages can belong to multiple groups using `group: [a, b]` syntax, allowing cross-section organization

## Optional Frontmatter Fields

### Field 1: `deprecated`
This field marks a page or feature as deprecated and controls how it appears in documentation. When enabled, it signals to users and agents that the content is no longer recommended for use.

### Field 2: `icon`
This optional field allows developers to associate a visual icon with a documentation page, enhancing navigation and visual organization in the documentation site.

### Additional Notable Optional Fields
- `tags`: For categorizing and filtering documentation content
- `experimental`: Marks features still under development
- `draft`: Indicates incomplete documentation
- `lastModified` and `lastAuthor`: Git-enriched metadata (when `--enrich-git` flag is enabled)

## Build Validation

If a page declares an unknown group value that doesn't exist in `docs.config.ts`, the Leadtype build will fail, ensuring referential integrity in the documentation structure.
