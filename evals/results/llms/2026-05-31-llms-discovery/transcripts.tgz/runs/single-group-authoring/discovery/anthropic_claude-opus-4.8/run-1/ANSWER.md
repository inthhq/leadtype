# Frontmatter `group` and Combined All-Docs Output

## What the `group` field is

In Leadtype, every MDX page carries YAML frontmatter. `title` is required, while
`group` is **optional**. When provided, its value should match a slug defined in
`docs.config.ts`. A page may belong to multiple groups using list syntax:

```yaml
group: [a, b]
```

If a page declares a group that is **not** defined in `docs.config.ts`, the build
**fails**.

## How `group` controls navigation (and related metadata)

The `group` value drives several aspects of the generated output:

- **Sidebar position / navigation** — determines where the page appears in the docs
  navigation.
- **`llms.txt` section** — the page is placed in the section corresponding to its group.
- **Search metadata** — group is recorded as part of the search index metadata.
- **`AGENTS.md` grouping** — used to organize the bundled agent guidance.

Guidance from the reference docs: **use groups for routing, not sharding**, and group
descriptions should read as routing hints rather than marketing copy.

## How `group` relates to the combined all-docs output

The combined output is the root **`/llms-full.txt`** file, produced by
`generateLLMFullContextFiles`. Key points:

- `/llms-full.txt` is a single root file that contains **every generated markdown docs
  page**.
- It is the **fallback** that is **not split by group** — groups do not produce per-group
  full-context files by default.
- Groups still organize the `llms.txt` sections, navigation, search metadata, and
  `AGENTS.md`, but they do **not** shard the combined full-context output.

(Related: `generateLlmsTxt` writes the product-level `/llms.txt` and the docs-scoped
`/docs/llms.txt` routing map, which *is* organized by group section.)

In **bundle mode** (`leadtype generate --bundle`), website-only artifacts—including
`llms-full.txt` and `llms.txt`—are skipped entirely; bundle mode instead writes
`AGENTS.md` plus `docs/*.md`.

## At least two optional frontmatter fields

Besides `group`, optional frontmatter fields include:

- `description` — optional but recommended; it becomes the routing hint in `llms.txt`.
- `icon`
- `deprecated` / `deprecatedReason`
- `experimental`
- `canary`
- `new`
- `draft`
- `tags`
- `availableIn`
- `full`
- `lastModified` and `lastAuthor` — populated only when `--enrich-git` is enabled.
