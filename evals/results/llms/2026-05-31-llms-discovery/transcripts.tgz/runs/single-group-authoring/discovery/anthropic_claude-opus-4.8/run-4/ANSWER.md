# Frontmatter `group` and Combined All-Docs Output in Leadtype

## How the `group` field controls navigation

Each MDX page in Leadtype carries YAML frontmatter. The `group` field is **optional**, and when present it should match a slug defined in `docs.config.ts`. The `group` value is the central piece that drives a page's placement across multiple surfaces:

- **Sidebar / navigation position** — the group determines where the page appears in the docs navigation tree.
- **`llms.txt` section** — pages are grouped into the corresponding section of the generated `llms.txt` map.
- **Search metadata** — group is included in the page's search index data.
- **`AGENTS.md` grouping** — pages are organized by group in the npm-bundled `AGENTS.md`.

A page can belong to **multiple groups** by using a list, e.g. `group: [a, b]`. If a page declares an **unknown group** (one not defined in `docs.config.ts`), the build **fails**. Lint (`leadtype lint`) validates frontmatter and group references; with `--error-unknown` and `--max-warnings 0`, unknown frontmatter fields can fail the build.

Guidance: use groups for **routing, not sharding**, and write group descriptions as routing hints rather than marketing copy.

## The combined all-docs (full-context) output

The combined output is produced by `generateLLMFullContextFiles`, which writes **one root `/llms-full.txt` file containing every generated markdown docs page**.

Key points about how `group` relates to this combined output:

- The root `/llms-full.txt` fallback contains **all** generated markdown pages and is **not split by group**.
- Groups still organize `llms.txt` sections, navigation, search metadata, and `AGENTS.md`, but they are **not** published as per-group full-context files by default.

(Related: `generateLlmsTxt` writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` map for hosted websites.)

## Optional frontmatter fields (examples)

`title` is the only **required** field. `description` is optional but recommended, since it becomes the routing hint in `llms.txt`. `group` itself is optional. Other optional fields include:

- `icon`
- `deprecated`
- `deprecatedReason`
- `experimental`
- `canary`
- `new`
- `draft`
- `tags`
- `availableIn`
- `full`
- `lastModified` — filled in when `--enrich-git` is enabled
- `lastAuthor` — filled in when `--enrich-git` is enabled
