# Frontmatter Group and Combined Output in Leadtype

## The `group` Field

The `group` frontmatter field is a **routing and organization mechanism** that controls how documentation pages are organized and presented across multiple outputs in the Leadtype library.

### How `group` Controls Navigation

The `group` field drives four key navigation and organization aspects:

1. **Sidebar Position**: The group value determines where a page appears in the documentation sidebar navigation
2. **LLMs.txt Sections**: Groups organize the `/llms.txt` file structure, creating sections for different documentation areas
3. **Search Metadata**: Group information is used to structure and categorize search results
4. **AGENTS.md Grouping**: Pages are grouped in the `AGENTS.md` file for npm-bundled docs based on their group assignment

### Combined All-Docs Output

The `group` field also controls the combined documentation output:

- **Multiple Group Membership**: Pages can belong to multiple groups using `group: [a, b]` syntax, allowing flexible organization
- **Fallback Behavior**: The `/llms-full.txt` file serves as a root-level combined output that contains **all generated markdown pages**. This fallback is **not split by group** and provides a comprehensive view of all documentation
- **Group-Based Routing**: While groups organize `/llms.txt` sections and navigation, the full-context file (`/llms-full.txt`) ensures all documentation is accessible for agents regardless of group boundaries

## Two Optional Frontmatter Fields

In addition to the `group` field, Leadtype supports several optional frontmatter fields that enhance documentation:

### 1. `icon`
Used to assign a visual icon to a documentation page, improving navigation UI and visual organization in the sidebar and search results.

### 2. `deprecated`
A boolean field that marks a page or feature as deprecated, signaling to users that this documentation may be outdated or superseded. Can be paired with `deprecatedReason` for additional context on why the page is no longer recommended.

Other notable optional fields include: `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor` (filled when `--enrich-git` is enabled).
