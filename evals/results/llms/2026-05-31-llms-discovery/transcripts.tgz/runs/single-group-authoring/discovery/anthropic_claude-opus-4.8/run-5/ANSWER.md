# Frontmatter `group` and Combined All-Docs Output

## What `group` is
In the Leadtype library, every MDX page carries YAML frontmatter. The `title`
field is required, `description` is optional but recommended, and `group` is an
**optional** field that should match a slug defined in `docs.config.ts`. If a
page declares a group that does not exist in the config, the build fails.

A page can also belong to **multiple groups** by using a list:
`group: [a, b]`.

## How `group` controls navigation (and more)
The `group` value drives several outputs at build time:

- **Sidebar position** — determines where the page appears in navigation.
- **`llms.txt` section** — groups organize the sections of the generated
  `llms.txt` map.
- **Search metadata** — group is included in search indexing data.
- **`AGENTS.md` grouping** — group structures the npm-bundled `AGENTS.md`.

Guidance from the LLM-files reference: use groups **for routing, not sharding**,
and write group descriptions as routing hints rather than marketing copy.

## How `group` relates to the combined all-docs output
The combined, all-docs output is the root `/llms-full.txt` file, produced by
`generateLLMFullContextFiles`. Key behavior:

- It is a **single root file containing every generated markdown docs page**.
- It is the **fallback** full-context file and is **not split by group**.
- Groups still organize `llms.txt` sections, navigation, search metadata, and
  `AGENTS.md`, but they are **not** published as per-group full-context files by
  default.

In short: groups shape routing/navigation and the per-section `llms.txt`, while
the combined `/llms-full.txt` ignores group boundaries and aggregates all pages.

## Optional frontmatter fields (at least two)
Besides `description` and `group`, optional frontmatter fields include:

- `icon`
- `deprecated`
- `deprecatedReason`
- `experimental`
- `canary`
- `new`
- `draft`
- `tags`
- `availableIn`
- `full`
- `lastModified` — populated only when `--enrich-git` is enabled.
- `lastAuthor` — populated only when `--enrich-git` is enabled.

(For example, two such optional fields are `icon` and `tags`; `lastModified`
and `lastAuthor` are filled in automatically when git enrichment is turned on.)
