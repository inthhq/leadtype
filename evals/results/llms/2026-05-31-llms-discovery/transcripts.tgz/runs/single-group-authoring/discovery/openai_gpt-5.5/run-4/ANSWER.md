# Frontmatter `group` and combined docs output

In Leadtype, each MDX page has YAML frontmatter. `title` is required, while `group` is optional. When present, `group` should match a group slug defined in `docs.config.ts`; an unknown group causes the build/lint validation to fail.

The `group` value is used for navigation and routing metadata:

- It determines where the page appears in the sidebar/group tree.
- It controls which section the page appears under in `llms.txt`.
- It contributes to search metadata.
- It controls grouping in generated `AGENTS.md` for package docs.
- A page can be assigned to multiple groups with an array, for example `group: [authoring, reference]`.

Groups do **not** shard the combined all-docs output. Website mode generates one root `/llms-full.txt` file containing every generated markdown docs page. That full-context fallback is not split into per-group files by default, so groups should be treated as routing/navigation hints rather than a way to partition the full combined output.

Optional frontmatter fields include `description`, `icon`, `deprecated`, `deprecatedReason`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor`. `description` is recommended because it becomes the routing hint in `llms.txt`; `lastModified` and `lastAuthor` can be filled when `--enrich-git` is enabled.
