# Frontmatter `group` field: navigation and combined output

## What `group` does

In Leadtype, each MDX page carries YAML frontmatter. While `title` is
required, the **`group` field is optional** and, when present, should match a
slug defined in `docs.config.ts`. During the build Leadtype reads the
frontmatter and *resolves the group tree* to organize the docs.

The `group` value drives several outputs at once:

- **Sidebar position / navigation** — group determines where the page appears
  in the navigation tree.
- **`llms.txt` section** — the page is placed under its group's section in the
  generated `llms.txt` routing map.
- **Search metadata** — group is recorded for search indexing.
- **`AGENTS.md` grouping** — used when generating the npm-bundled `AGENTS.md`.

A page may belong to **multiple groups** by using a list, e.g. `group: [a, b]`.
If a page declares an **unknown group, the build fails** (and `leadtype lint`
also validates group references).

> Guidance: use groups for routing, not sharding. Group descriptions should be
> routing hints rather than marketing copy.

## Combined all-docs output

The combined full-context output is **not split by group**:

- `generateLLMFullContextFiles` writes a single root `/llms-full.txt` file
  containing **every generated markdown docs page**.
- This root `/llms-full.txt` acts as a fallback that includes all generated
  markdown pages, regardless of group.
- Groups still organize the `llms.txt` sections, navigation, search metadata,
  and `AGENTS.md`, but they are **not published as per-group full-context
  files by default**.

In other words, `group` shapes the *organized, routed* artifacts, while the
*combined* `/llms-full.txt` ignores grouping and bundles everything together.

## Optional frontmatter fields (examples)

Besides `group`, optional frontmatter fields include:

- **`description`** — recommended, since it becomes the routing hint in
  `llms.txt`.
- **`icon`** — an icon for the page.
- **`deprecated`** / **`deprecatedReason`** — mark a page as deprecated and
  explain why.
- **`experimental`**, **`canary`**, **`new`**, **`draft`** — page status flags.
- **`tags`**, **`availableIn`**, **`full`** — additional metadata.
- **`lastModified`** / **`lastAuthor`** — populated automatically when
  `--enrich-git` is enabled.
