# Frontmatter `group` Field in Leadtype

## Overview

The frontmatter `group` field is an optional but powerful field that controls how documentation pages are organized and presented to LLMs and users. The `group` value must match a slug from `docs.config.ts`, and if an unknown group is declared, the build will fail.

## How `group` Controls Navigation and Combined Output

### Navigation and Sidebar Organization
The `group` field drives the **sidebar position**, determining how pages are organized hierarchically in the documentation sidebar. Pages are grouped together based on their group assignment, creating logical sections within the navigation structure.

### LLM Context Files (`llms.txt`)
The `group` field controls the **section organization in `llms.txt`**. Rather than being split by group in the final output, groups organize how the routing hints and product-level context are provided to LLMs. Pages with the same group are organized together in LLM-readable sections.

### Combined All-Docs Output (`llms-full.txt`)
While the **root `/llms-full.txt` fallback contains all generated markdown pages and is not split by group**, the group field still organizes pages for search metadata and AGENTS.md grouping. This means the combined output includes everything but maintains group-based organization metadata.

### Multi-Group Support
Pages can belong to **multiple groups** by using the syntax `group: [a, b]`, allowing a single page to appear in multiple navigation contexts and be referenced across different LLM sections.

### Additional Organization Uses
The `group` value drives:
- **Search metadata** organization
- **AGENTS.md grouping** for npm-bundled documentation
- Routing structure for hosted websites

## Optional Frontmatter Fields

The Leadtype library supports several optional frontmatter fields beyond `title` and `description`:

### 1. `icon`
Allows specification of an icon to represent the page in navigation and UI elements.

### 2. `deprecated`
A boolean flag indicating whether the page content is deprecated. Works in conjunction with `deprecatedReason` to communicate that content is no longer recommended.

### Additional Optional Fields
Other available optional fields include:
- `deprecatedReason` - Explains why content is deprecated
- `experimental` - Marks content as experimental
- `canary` - Marks content as canary/beta
- `new` - Marks content as newly added
- `draft` - Indicates draft status
- `tags` - Allows tagging pages with keywords
- `availableIn` - Specifies where feature is available
- `full` - Controls full-context inclusion
- `lastModified` - Last modification timestamp (populated with `--enrich-git`)
- `lastAuthor` - Author of last modification (populated with `--enrich-git`)

## Summary

The `group` field is a critical organizational tool that shapes how documentation is presented across multiple outputs: sidebar navigation, LLM routing hints, search indexing, and agent guidance. While the combined `/llms-full.txt` contains all pages regardless of group, groups remain essential for organizing how LLMs perceive and navigate the documentation structure.
