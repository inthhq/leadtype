# Frontmatter `group` and Combined All-Docs Output in Leadtype

## How the `group` field controls navigation

In Leadtype, each MDX page has YAML frontmatter. The `title` field is required, while
`group` is **optional** and, when present, should match a slug defined in `docs.config.ts`.

The `group` value drives several aspects of how a page is organized and routed:

- **Sidebar position** — it determines where the page appears in the navigation tree.
- **`llms.txt` section** — it controls which section of the generated `llms.txt` the page is listed under.
- **Search metadata** — it informs the search index grouping.
- **`AGENTS.md` grouping** — it organizes the npm-bundled agent guidance.

A page can belong to **multiple groups** by using a list, e.g. `group: [a, b]`.

During the build, Leadtype reads frontmatter, flattens MDX into markdown, and then
**resolves the group tree** before emitting website or package artifacts. If a page
declares an **unknown group** (one that does not match a slug in `docs.config.ts`),
**the build fails**. The CLI's `leadtype lint` command validates frontmatter and group
references, and `--error-unknown` with `--max-warnings 0` can be used to fail the build
on unknown frontmatter fields.

Guidance from the docs: use groups for **routing, not sharding**, and group descriptions
should be routing hints rather than marketing copy.

## How `group` relates to the combined all-docs output

The combined "all docs" output is the root `/llms-full.txt` file, produced by
`generateLLMFullContextFiles`. Key behavior:

- It writes **one root `/llms-full.txt`** file that contains **every generated markdown
  docs page**.
- This combined output is **not split or sharded by group** — it is a single fallback
  file with all content.
- Groups still organize the `llms.txt` sections, navigation, search metadata, and
  `AGENTS.md`, but they are **not published as per-group full-context files** by default.

By contrast, `generateLlmsTxt` writes the product-level `/llms.txt` and the docs-scoped
`/docs/llms.txt` maps, which *are* organized into sections by group.

## Optional frontmatter fields (examples)

Besides `group`, the following frontmatter fields are optional. At least two examples:

- **`description`** — optional but recommended, because it becomes the routing hint in `llms.txt`.
- **`icon`** — optional display icon for the page.
- **`deprecated`** / **`deprecatedReason`** — mark a page as deprecated and explain why.
- **`experimental`**, **`canary`**, **`new`**, **`draft`** — lifecycle/status flags.
- **`tags`**, **`availableIn`**, **`full`** — metadata fields.
- **`lastModified`** and **`lastAuthor`** — populated automatically when `--enrich-git` is enabled.
