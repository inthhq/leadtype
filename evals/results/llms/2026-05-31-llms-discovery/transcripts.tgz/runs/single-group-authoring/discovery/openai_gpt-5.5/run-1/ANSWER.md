# Frontmatter `group` field

In Leadtype, each MDX page uses YAML frontmatter. `title` is required, while `group` is optional. When used, `group` should match a group slug defined in `docs.config.ts`; an unknown group causes the build to fail.

The `group` field controls how a page is organized across generated outputs:

- **Navigation/sidebar:** the page is placed according to its group, so the group affects sidebar position and navigation structure.
- **`llms.txt`:** the page appears under the corresponding section in the generated `llms.txt` map.
- **Search and package-agent metadata:** the group is included in search metadata and used for `AGENTS.md` grouping.
- **Multiple groups:** a page can be assigned to more than one group, for example `group: [a, b]`.

For the combined all-docs output, grouping does **not** split the full context file. The root `/llms-full.txt` fallback contains every generated markdown docs page in one combined file; Leadtype does not publish per-group full-context files by default.

Optional frontmatter fields include `description`, `icon`, `deprecated`, `deprecatedReason`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor`. `description` is recommended because it becomes the routing hint in `llms.txt`; `lastModified` and `lastAuthor` can be filled when `--enrich-git` is enabled.
