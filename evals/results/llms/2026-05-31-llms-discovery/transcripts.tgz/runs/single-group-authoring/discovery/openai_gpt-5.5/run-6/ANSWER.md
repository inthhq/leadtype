# Frontmatter `group` and combined docs output

In Leadtype, each MDX page has YAML frontmatter. `title` is required, while `group` is optional. When present, `group` should match a group slug from `docs.config.ts`; if a page declares an unknown group, the build fails.

The `group` field is used for organization and routing:

- It determines the page’s sidebar/navigation position.
- It controls which section the page appears in within `llms.txt`.
- It is included in search metadata.
- It controls grouping in bundled `AGENTS.md` output.
- A page can appear in more than one group with array syntax, for example `group: [a, b]`.

Groups do **not** shard the combined all-docs output. The root `/llms-full.txt` file is a single full-context fallback containing every generated markdown docs page, and it is not split into per-group files by default. In other words, use groups for navigation and routing sections, not for dividing the combined full-docs artifact.

Optional frontmatter fields include `description`, `icon`, `deprecated`, `deprecatedReason`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor`. `description` is recommended because it becomes the routing hint in `llms.txt`; `lastModified` and `lastAuthor` can be filled automatically when `--enrich-git` is enabled.
