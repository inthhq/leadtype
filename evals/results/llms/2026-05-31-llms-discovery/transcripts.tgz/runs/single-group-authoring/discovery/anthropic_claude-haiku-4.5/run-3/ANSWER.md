# Frontmatter `group` Field in Leadtype

## Overview

In the Leadtype library, the frontmatter `group` field is an optional but powerful field that controls how documentation is organized, navigated, and output across multiple artifact formats.

## How `group` Controls Navigation and Combined Output

### Navigation Control
The `group` value directly drives **sidebar position** in the generated documentation site. It must match a slug from `docs.config.ts`, and when properly configured, it organizes pages into a hierarchical navigation structure that helps users find related content.

### Combined Output Control
The `group` field controls the output in several key ways:

1. **llms.txt Section Organization**: The group value determines how pages are split and organized within the generated `llms.txt` file, which is the entry point for HTTP-based AI agents.

2. **Search Metadata**: Pages are tagged and categorized by their group for search functionality, allowing agents to filter and discover content by topic.

3. **AGENTS.md Grouping**: For offline documentation in npm packages, the group value controls how pages are organized in the AGENTS.md file that coding agents use.

4. **Full Fallback Output**: The `/llms-full.txt` file contains all generated markdown pages without group-based splitting, serving as a complete reference when group-specific organization isn't needed.

### Multiple Group Support
Pages can belong to multiple groups using the syntax `group: [a, b]`, allowing flexible organization where a single page can appear in multiple navigational and output contexts.

### Build Validation
If a page declares an unknown group that doesn't exist in `docs.config.ts`, the build fails with an error, ensuring referential integrity in the documentation structure.

## Optional Frontmatter Fields

The Leadtype library supports several optional frontmatter fields alongside the `group` field:

1. **`description`**: While technically optional, it is recommended because it becomes the routing hint in `llms.txt`, helping AI agents understand page content and relevance.

2. **`icon`**: Specifies an icon to display alongside the page in navigation and UI elements.

3. **`deprecated`**: A boolean flag marking a page as deprecated in the documentation.

4. **`deprecatedReason`**: Provides context for why a page or feature is deprecated.

5. **`experimental`**: Marks content as experimental and subject to change.

6. **`tags`**: Allows categorization of content with custom tags for filtering and organization.

7. **`lastModified`**: Automatically filled in when `--enrich-git` is enabled during the build process, showing when content was last updated.

These optional fields provide rich metadata for the documentation system to better organize, categorize, and present content to both human users and AI agents.
