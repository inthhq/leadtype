# Frontmatter `group` in Leadtype

In Leadtype, each MDX page can define YAML frontmatter. `title` is required; `group` is optional.

The `group` field should match a group slug from `docs.config.ts`. It is used for organization and routing-oriented metadata:

- places the page in the appropriate sidebar/navigation position
- determines the section where the page appears in `llms.txt`
- contributes group metadata to search output
- groups pages in generated `AGENTS.md`

A page can belong to more than one group by using an array:

```yaml
group: [authoring, reference]
```

If a page declares a group that is not known in `docs.config.ts`, the build fails.

For the combined all-docs output, groups do **not** create separate full-context files. Leadtype writes one root `/llms-full.txt` file containing every generated markdown docs page. Groups still organize navigation, `llms.txt`, search metadata, and `AGENTS.md`, but they are not used to shard the combined output into per-group full-context files by default. In other words, use groups for routing and organization, not for splitting the all-docs file.

Optional frontmatter fields include `description`, `icon`, `deprecated`, `deprecatedReason`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor`. `description` is recommended because it becomes the routing hint in `llms.txt`; `lastModified` and `lastAuthor` can be filled when `--enrich-git` is enabled.
