# Frontmatter Group Field and Combined Output in Leadtype

## Overview of the `group` Field

The `group` field in Leadtype frontmatter is an optional field that plays a crucial role in controlling how documentation is organized, navigated, and aggregated across multiple output formats.

## How `group` Controls Navigation

The `group` field drives several navigation and organizational aspects:

1. **Sidebar Position** - The group value determines where a page appears in the sidebar navigation structure
2. **llms.txt Sections** - Pages are organized into their respective group sections within the llms.txt file
3. **Search Metadata** - Group information is used to organize and categorize search results
4. **AGENTS.md Grouping** - Groups determine how pages are organized in the AGENTS.md output file used by offline agents

## How `group` Affects Combined All-Docs Output

The `/llms-full.txt` file is the root fallback containing all generated markdown docs pages. While groups are NOT split by group in this combined output, they remain active for organizing the other artifacts:

- The `/llms-full.txt` file contains **every generated markdown docs page** without being split or grouped
- Groups still organize llms.txt sections, navigation, search metadata, and AGENTS.md
- Per-group full-context files are not published by default; only the single combined `/llms-full.txt` exists

## Multi-Group Support

Pages can belong to multiple groups using the syntax: `group: [a, b]`. This allows a single page to appear in multiple navigation contexts and be indexed under different group sections.

## Build Behavior

If a page declares an unknown group (a group that doesn't match a slug from docs.config.ts), the build fails, ensuring consistency and preventing orphaned pages.

## Two Optional Frontmatter Fields

Beyond the `group` field, here are two important optional frontmatter fields:

### 1. **`description`**
- Optional but recommended
- Becomes the routing hint in llms.txt
- Used to provide context about page content for navigation and search purposes

### 2. **`deprecated` and `deprecatedReason`**
- `deprecated`: A boolean flag indicating whether a page or feature is deprecated
- `deprecatedReason`: Explains why something is deprecated and potentially what should be used instead
- Other related optional fields: `experimental`, `canary`, `new`, and `draft` provide status indicators for documentation pages

### Additional Optional Fields Available
The frontmatter also supports: `icon`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor` (the latter two are populated when `--enrich-git` is enabled).

## Summary

The `group` field is a powerful organizational mechanism in Leadtype that enables:
- Structured navigation and sidebar organization
- Logical grouping in agent-readable outputs (llms.txt and AGENTS.md)
- Search result organization
- While `/llms-full.txt` provides a complete, ungrouped view of all documentation, groups remain essential for all other navigation and discovery mechanisms
