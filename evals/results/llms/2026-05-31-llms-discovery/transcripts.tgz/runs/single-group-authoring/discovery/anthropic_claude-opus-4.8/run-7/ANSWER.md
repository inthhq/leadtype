# Frontmatter `group` and Combined All-Docs Output

## The `group` field

Each Leadtype MDX page carries YAML frontmatter. `title` is required, `description`
is optional but recommended (it becomes the routing hint in `llms.txt`), and
`group` is **optional**. When present, `group` should match a slug defined in
`docs.config.ts`. If a page declares an unknown group, the build fails.

## How `group` controls navigation

The `group` value drives several navigation/discovery surfaces at once:

- **Sidebar position** – determines where the page appears in the navigation tree.
- **`llms.txt` section** – organizes the product-level/docs-scoped link maps.
- **Search metadata** – influences search indexing/grouping.
- **AGENTS.md grouping** – organizes the npm-bundled agent docs.

A page may belong to multiple groups using list syntax: `group: [a, b]`.

The guidance is to **use groups for routing, not sharding**, and to keep group
descriptions as routing hints rather than marketing copy.

## How `group` relates to the combined all-docs output

The combined all-docs file is the root **`/llms-full.txt`** fallback, produced by
`generateLLMFullContextFiles`. Key points:

- `/llms-full.txt` contains **every generated markdown docs page**.
- It is the **fallback** output and is **not split by group**. Groups still
  organize `llms.txt` sections, navigation, search metadata, and AGENTS.md, but
  they are **not published as per-group full-context files by default**.

In other words, `group` shapes *navigation and section organization*, while the
combined `/llms-full.txt` ignores grouping and simply aggregates all pages.

## Optional frontmatter fields (examples)

In addition to `description` and `group`, optional frontmatter fields include:

- `icon`
- `deprecated`
- `deprecatedReason`
- `experimental`
- `canary`
- `new`
- `draft`
- `tags`
- `availableIn`
- `full`
- `lastModified` *(populated when `--enrich-git` is enabled)*
- `lastAuthor` *(populated when `--enrich-git` is enabled)*

> Note: `leadtype lint` validates frontmatter and group references. Run it with
> `--error-unknown --max-warnings 0` to fail the build on unknown frontmatter fields.
