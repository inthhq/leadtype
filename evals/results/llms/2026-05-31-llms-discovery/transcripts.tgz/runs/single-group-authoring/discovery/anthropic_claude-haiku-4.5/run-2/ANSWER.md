# Frontmatter `group` Field in Leadtype Library

## How the `group` Field Controls Navigation and Combined Output

The `group` field is an optional frontmatter field in Leadtype that plays a crucial role in organizing documentation:

### Navigation and Structure Control
- The `group` value drives the **sidebar position**, determining where pages appear in the documentation navigation hierarchy
- Groups must match a slug from `docs.config.ts`, and if a page declares an unknown group, the build fails
- Pages can belong to multiple groups using the syntax `group: [a, b]`, allowing flexible organization

### Combined All-Docs Output Control
- The `group` value controls the **llms.txt section**, splitting generated markdown into group-specific sections
- It drives the **AGENTS.md grouping**, organizing agent-readable artifacts by group
- The root `/llms-full.txt` fallback contains all generated markdown pages and is NOT split by group, providing a comprehensive combined output of all documentation regardless of group assignment
- It also influences **search metadata**, allowing users to filter and discover content by group

## Optional Frontmatter Fields

Two important optional frontmatter fields in Leadtype are:

1. **`description`** - While optional, it is recommended because it becomes the routing hint in llms.txt, helping AI agents understand and navigate the documentation more effectively

2. **`deprecated`** - An optional boolean field used to mark pages or features as deprecated. It is typically paired with `deprecatedReason` to provide context about why something is no longer recommended

Additional optional fields include `icon`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor` (the latter two are populated when `--enrich-git` is enabled).
