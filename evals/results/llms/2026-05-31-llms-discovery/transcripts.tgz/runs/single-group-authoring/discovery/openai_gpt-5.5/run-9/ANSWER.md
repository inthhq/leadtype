# Frontmatter `group` behavior in Leadtype

In Leadtype, every MDX page has YAML frontmatter. `title` is required, while `group` is optional. When provided, `group` should match a group slug defined in `docs.config.ts`; if a page references an unknown group, the build fails.

The `group` field controls organization rather than content splitting:

- It determines where the page appears in the sidebar/navigation.
- It determines which section the page appears under in `llms.txt`.
- It contributes to search metadata.
- It controls grouping in generated `AGENTS.md` for bundled package docs.
- A page can be assigned to multiple groups with array syntax, for example `group: [a, b]`.

For the combined all-docs output, groups do **not** create separate full-context files by default. Leadtype writes one root `/llms-full.txt` file that contains every generated markdown docs page. In other words, groups are used for routing and navigation, not for sharding the combined output.

Optional frontmatter fields include `description`, `icon`, `deprecated`, `deprecatedReason`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor`. `description` is recommended because it becomes the routing hint in `llms.txt`; `lastModified` and `lastAuthor` can be filled automatically when `--enrich-git` is enabled.
