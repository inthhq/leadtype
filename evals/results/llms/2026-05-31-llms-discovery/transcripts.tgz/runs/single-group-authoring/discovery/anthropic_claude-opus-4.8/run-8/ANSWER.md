# Frontmatter `group` and Combined All-Docs Output in Leadtype

## The `group` field

Each MDX page in Leadtype carries YAML frontmatter. `title` is the only required
field; `group` is **optional** and, when present, should match a slug defined in
`docs.config.ts`. If a page declares an unknown group, the build fails (this is
also validated by `leadtype lint`, which checks group references).

### What `group` controls

The `group` value drives several parts of the generated output:

- **Sidebar / navigation position** — it determines where the page appears in the
  navigation tree (Leadtype resolves the group tree during the build).
- **`llms.txt` section** — pages are organized into sections by group in the
  product-level `/llms.txt` and docs-scoped `/docs/llms.txt` maps
  (`generateLlmsTxt`).
- **Search metadata** — group is part of the search index metadata.
- **`AGENTS.md` grouping** — the npm-bundled `AGENTS.md` (`generateAgentsMd`) uses
  groups to organize its content.

A page can belong to **multiple groups** using list syntax: `group: [a, b]`.

Guidance from the docs: use groups for *routing*, not sharding, and write group
descriptions as routing hints rather than marketing copy.

## The combined all-docs (full-context) output

`generateLLMFullContextFiles` writes a single root `/llms-full.txt` file that
contains **every** generated markdown docs page. Key points:

- This combined file is the all-docs fallback and is **not split by group** — all
  pages are emitted into one file regardless of their `group`.
- Groups still organize the `llms.txt` sections, navigation, search metadata, and
  `AGENTS.md`, but they are **not** published as per-group full-context files by
  default.
- Artifact paths such as `llms.txt`, `llms-full.txt`, sitemap files, `robots.txt`,
  search JSON, and `agent-readability.json` are recognized by
  `isAgentReadabilityArtifactPath` so they are not rewritten as missing markdown
  pages.

## Optional frontmatter fields (examples)

Besides `group` and `description` (optional but recommended, since it becomes the
routing hint in `llms.txt`), Leadtype supports many optional frontmatter fields,
including:

- `icon`
- `deprecated`
- `deprecatedReason`
- `experimental`
- `canary`
- `new`
- `draft`
- `tags`
- `availableIn`
- `full`
- `lastModified`
- `lastAuthor`

Note: `lastModified` and `lastAuthor` are filled in automatically only when
`--enrich-git` is enabled. When you want unknown frontmatter fields to fail the
build, run `leadtype lint` with `--error-unknown` (combined with `--max-warnings 0`).
