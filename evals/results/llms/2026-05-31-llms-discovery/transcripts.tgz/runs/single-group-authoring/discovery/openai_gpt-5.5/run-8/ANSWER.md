# Frontmatter `group` and combined docs output

In Leadtype, each MDX page has YAML frontmatter. `title` is required, while `group` is optional. When present, `group` should match a group slug defined in `docs.config.ts`; an unknown group causes the build to fail.

The `group` field is used for organization and routing:

- It determines where the page appears in the sidebar/navigation.
- It determines which section the page appears under in `llms.txt` and `/docs/llms.txt`.
- It contributes to search metadata.
- It controls grouping in generated `AGENTS.md` for bundled package docs.
- A page can be assigned to multiple groups with an array, for example `group: [a, b]`.

For the combined all-docs output, groups do **not** split or shard the full-context file. Website mode generates one root `/llms-full.txt` file containing every generated markdown docs page. Groups may organize navigation, `llms.txt`, search metadata, and `AGENTS.md`, but they are not emitted as separate per-group full-context files by default.

Optional frontmatter fields include `description`, `icon`, `deprecated`, `deprecatedReason`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor`. `description` is recommended because it becomes the routing hint in `llms.txt`; `lastModified` and `lastAuthor` can be filled automatically when `--enrich-git` is enabled.
