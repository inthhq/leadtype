# Frontmatter `group` and all-docs output in Leadtype

In Leadtype, each MDX page has YAML frontmatter. `title` is required, while `group` is optional. When used, `group` should match a group slug defined in `docs.config.ts`; if a page declares an unknown group, the build fails.

The `group` field controls how a page is organized across generated navigation and agent-facing indexes:

- It determines the page's sidebar position.
- It places the page into the corresponding section of `llms.txt`.
- It contributes group metadata for search.
- It controls grouping in generated `AGENTS.md` for bundled package docs.
- A page can appear in more than one group with array syntax, for example `group: [a, b]`.

Groups do **not** split the combined all-docs output. The root `/llms-full.txt` file is a single full-context fallback that contains every generated markdown docs page, regardless of group. Leadtype uses groups for routing and organization, not for sharding full-context files.

Optional frontmatter fields include `description`, `icon`, `deprecated`, `deprecatedReason`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor`. `description` is recommended because it becomes the routing hint in `llms.txt`; `lastModified` and `lastAuthor` can be filled automatically when `--enrich-git` is enabled.
