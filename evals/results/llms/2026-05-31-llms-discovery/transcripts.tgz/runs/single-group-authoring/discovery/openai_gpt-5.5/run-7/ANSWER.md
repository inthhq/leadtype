# Frontmatter `group` and combined docs output

In Leadtype, each MDX page has YAML frontmatter. `title` is required; `group` is optional, but when present it should match a group slug defined in `docs.config.ts`.

The `group` field is used for organization and routing:

- It controls where the page appears in the sidebar/navigation.
- It determines the page's section in `llms.txt`.
- It is included in search metadata.
- It controls grouping in generated `AGENTS.md` package docs.
- A page can appear in more than one group with array syntax, for example `group: [guide, reference]`.
- If a page names an unknown group, the build fails.

Groups do **not** shard the combined all-docs output. Leadtype's root `/llms-full.txt` is a single full-context fallback containing every generated markdown docs page. It is not split into one file per group by default, even though groups still organize navigation, `llms.txt`, search metadata, and `AGENTS.md`.

Optional frontmatter fields include `description`, `icon`, `deprecated`, `deprecatedReason`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor`. `description` is recommended because it becomes the routing hint in `llms.txt`; `lastModified` and `lastAuthor` can be filled in automatically when `--enrich-git` is enabled.
