# Frontmatter `group` and combined output

In Leadtype, each MDX page uses YAML frontmatter. `title` is required, while `group` is optional. When present, `group` should match a group slug defined in `docs.config.ts`; an unknown group causes the build or lint validation to fail.

The `group` field is used for organization and routing, not for splitting content into separate full-context bundles. It controls:

- where the page appears in the sidebar/navigation,
- which section the page appears under in `llms.txt`,
- search metadata grouping,
- grouping in generated `AGENTS.md` for bundled package docs.

A page may belong to more than one group by using an array, for example:

```yaml
group: [guides, reference]
```

For combined all-docs output, Leadtype writes one root `/llms-full.txt` containing every generated markdown docs page. This file is not split per group by default. Groups still shape navigation, `llms.txt` sections, search metadata, and `AGENTS.md`, but they do not shard the full-context output.

Optional frontmatter fields include `description`, `icon`, `deprecated`, `deprecatedReason`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor`. `description` is recommended because it becomes a routing hint in `llms.txt`; `lastModified` and `lastAuthor` can be filled when generation runs with `--enrich-git`.
