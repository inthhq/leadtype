# Preventing agent-readability artifacts from being rewritten

## Helper

`isAgentReadabilityArtifactPath`

## What it does

It identifies artifact paths that should **not** be rewritten as missing
markdown pages. This keeps the generated agent-readability/support files
served as static artifacts rather than being mistaken for absent docs pages.

## What it covers

The helper covers the following artifact paths:

- `llms.txt`
- `llms-full.txt`
- sitemap files
- `robots.txt`
- search JSON
- `agent-readability.json`

## Source

Documented in `docs/reference/llm.md`:

> isAgentReadabilityArtifactPath identifies artifact paths that should not be
> rewritten as missing markdown pages. It covers llms.txt, llms-full.txt,
> sitemap files, robots.txt, search JSON, and agent-readability.json.
