# Agent-Readability Artifact Protection

## Helper: `isAgentReadabilityArtifactPath`

The helper `isAgentReadabilityArtifactPath` is the function in the Leadtype library that prevents agent-readability artifacts from being rewritten as missing markdown pages.

## What It Covers

This helper identifies and protects the following artifact paths:

- **llms.txt** - Product-level and docs-scoped LLM context files
- **llms-full.txt** - Full-context file containing all generated markdown docs pages
- **Sitemap files** - XML and markdown sitemaps
- **robots.txt** - Standard robots exclusion protocol file
- **search JSON** - Search index and related search artifacts
- **agent-readability.json** - Agent readability metadata file

By identifying these paths, the helper ensures that when Leadtype processes documentation, these special agent-oriented artifacts are treated as static files and not overwritten or reprocessed as missing markdown pages.
