# Preventing agent-readability artifacts from being rewritten

## Helper

**`isAgentReadabilityArtifactPath`**

## What it does

This helper identifies artifact paths that should **not** be rewritten as
missing markdown pages. By recognizing these special generated files, it keeps
them treated as static artifacts rather than being mistaken for absent docs
pages.

## What it covers

It covers the following agent-readability artifacts:

- `llms.txt`
- `llms-full.txt`
- sitemap files
- `robots.txt`
- search JSON
- `agent-readability.json`

## Source

Documented in `docs/reference/llm.md` (LLM files reference).
