# Preventing agent-readability artifacts from being rewritten

## Helper

**`isAgentReadabilityArtifactPath`**

## What it does

This helper identifies artifact paths that should **not** be rewritten as
missing markdown pages. By recognizing these paths, Leadtype keeps the special
agent/LLM-readability files serving as static artifacts instead of being
treated as ordinary docs pages that get redirected to a missing-markdown route.

## What it covers

`isAgentReadabilityArtifactPath` covers the following artifact paths:

- `llms.txt`
- `llms-full.txt`
- sitemap files
- `robots.txt`
- search JSON
- `agent-readability.json`

## Source

Documented in `docs/reference/llm.md` (LLM files reference).
