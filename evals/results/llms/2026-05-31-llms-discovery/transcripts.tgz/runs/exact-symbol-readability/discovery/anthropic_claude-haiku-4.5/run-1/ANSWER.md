# Agent-Readability Artifact Prevention Helper

## Helper Name
`isAgentReadabilityArtifactPath`

## Description
`isAgentReadabilityArtifactPath` is a helper function that identifies artifact paths that should not be rewritten as missing markdown pages.

## Coverage
It covers the following agent-readable artifacts:
- `llms.txt`
- `llms-full.txt`
- Sitemap files (XML and markdown formats)
- `robots.txt`
- Search JSON files (search-index.json, search-content.json)
- `agent-readability.json`

This helper ensures that these essential agent-readable artifacts maintain their integrity and are not accidentally overwritten or rewritten as placeholder markdown pages.
