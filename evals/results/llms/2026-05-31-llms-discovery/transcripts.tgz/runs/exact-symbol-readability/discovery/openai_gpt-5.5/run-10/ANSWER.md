The helper is `isAgentReadabilityArtifactPath`.

It identifies Leadtype’s agent-readability output artifacts so they are not rewritten as missing Markdown pages. It covers `llms.txt`, `llms-full.txt`, sitemap files, `robots.txt`, search JSON files, and `agent-readability.json`.
