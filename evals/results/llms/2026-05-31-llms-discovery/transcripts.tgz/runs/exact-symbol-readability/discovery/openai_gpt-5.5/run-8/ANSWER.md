The helper is `isAgentReadabilityArtifactPath`.

It identifies generated agent-readability artifact paths that should be served as static artifacts instead of being rewritten as missing markdown pages. It covers `llms.txt`, `llms-full.txt`, sitemap files, `robots.txt`, search JSON files, and `agent-readability.json`.
