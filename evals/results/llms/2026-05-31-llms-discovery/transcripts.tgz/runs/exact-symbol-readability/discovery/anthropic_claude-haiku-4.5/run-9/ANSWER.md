# Helper for Preventing Agent-Readability Artifacts from Being Rewritten

## Helper Name
**`isAgentReadabilityArtifactPath`**

## Description
`isAgentReadabilityArtifactPath` is a helper function in the Leadtype library that identifies artifact paths that should not be rewritten as missing markdown pages. 

It covers the following artifacts:
- llms.txt
- llms-full.txt
- sitemap files (sitemap.xml, sitemap.md)
- robots.txt
- search JSON files (search-index.json, search-content.json)
- agent-readability.json

These artifacts are protected from being treated as missing markdown pages and should be served as static files to AI agents and other consumers requesting documentation.
