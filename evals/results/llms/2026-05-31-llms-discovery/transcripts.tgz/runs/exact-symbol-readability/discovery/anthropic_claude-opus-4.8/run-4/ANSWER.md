# Preventing agent-readability artifacts from being rewritten

## Helper

**`isAgentReadabilityArtifactPath`**

This helper identifies artifact paths that should **not** be rewritten as missing
markdown pages.

## What it covers

It recognizes the following agent-readability artifacts:

- `llms.txt`
- `llms-full.txt`
- sitemap files
- `robots.txt`
- search JSON (e.g. `search-index.json`, `search-content.json`)
- `agent-readability.json`

These are static, website-only artifacts produced for AI/agent consumption, so
they are excluded from the markdown-mirror rewriting that would otherwise treat a
non-markdown request as a missing `*.md` page.

Source: `docs/reference/llm.md` (LLM files reference).
