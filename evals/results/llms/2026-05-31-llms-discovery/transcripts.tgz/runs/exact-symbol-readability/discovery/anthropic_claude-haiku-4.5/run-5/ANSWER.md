# Agent-Readability Artifact Protection Helper

## Helper: `isAgentReadabilityArtifactPath`

The `isAgentReadabilityArtifactPath` helper prevents agent-readability artifacts from being rewritten as missing markdown pages.

## Coverage

It covers the following artifact paths:
- `llms.txt`
- `llms-full.txt`
- Sitemap files (sitemaps.xml, sitemap.md)
- `robots.txt`
- Search JSON files (search-index.json, search-content.json)
- `agent-readability.json`

These artifacts are protected from being overwritten or rewritten as missing markdown pages during the documentation generation and processing pipeline.
