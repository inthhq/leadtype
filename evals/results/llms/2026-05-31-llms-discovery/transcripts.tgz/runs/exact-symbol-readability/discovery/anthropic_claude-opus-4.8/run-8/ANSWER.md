# Preventing agent-readability artifacts from being rewritten

The helper is **`isAgentReadabilityArtifactPath`**.

It identifies artifact paths that should **not** be rewritten as missing markdown pages.

## What it covers

`isAgentReadabilityArtifactPath` covers the following artifact paths:

- `llms.txt`
- `llms-full.txt`
- sitemap files
- `robots.txt`
- search JSON
- `agent-readability.json`

These are the static agent-readability artifacts that the library serves as-is,
rather than treating them as documentation pages eligible for markdown
rewriting/fallback.

Source: `docs/reference/llm.md`
