# Agent-Readability Artifact Prevention Helper

## Helper Name
**`isAgentReadabilityArtifactPath`**

## Description
`isAgentReadabilityArtifactPath` is a helper function that identifies artifact paths that should not be rewritten as missing markdown pages. 

It covers the following artifacts:
- `llms.txt`
- `llms-full.txt`
- Sitemap files (sitemap.xml, sitemap.md)
- `robots.txt`
- Search JSON files (search-index.json, search-content.json)
- `agent-readability.json`

This helper ensures that these special agent-readable artifacts are preserved as static files during the Leadtype documentation generation process, preventing them from being incorrectly rewritten as missing markdown pages.
