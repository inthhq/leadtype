# Agent-Readability Artifact Protection Helper

## Helper Name
`isAgentReadabilityArtifactPath`

## Description
`isAgentReadabilityArtifactPath` is a helper function in the Leadtype library that identifies artifact paths which should not be rewritten as missing markdown pages.

## What It Covers
The helper protects the following agent-readability artifacts from being rewritten:
- llms.txt
- llms-full.txt
- Sitemap files (sitemap.xml, sitemap.md)
- robots.txt
- Search JSON files (search-index.json, search-content.json)
- agent-readability.json
