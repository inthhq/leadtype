# Helper: isAgentReadabilityArtifactPath

## Summary

The helper that prevents agent-readability artifacts from being rewritten as missing markdown pages is **`isAgentReadabilityArtifactPath`**.

## What It Covers

This helper identifies artifact paths that should not be rewritten as missing markdown pages. It covers the following artifacts:

- `llms.txt`
- `llms-full.txt`
- Sitemap files (sitemap.xml, sitemap.md)
- `robots.txt`
- Search JSON files (search-index.json, search-content.json)
- `agent-readability.json`

These artifacts are critical for LLM and agent interactions, and the helper ensures they remain static and are not inadvertently converted to markdown page redirects.
