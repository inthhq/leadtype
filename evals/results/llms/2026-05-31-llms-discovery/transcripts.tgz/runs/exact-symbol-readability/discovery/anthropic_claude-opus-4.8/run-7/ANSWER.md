# Preventing agent-readability artifacts from being rewritten

## Helper

**`isAgentReadabilityArtifactPath`**

## What it does

This helper identifies artifact paths that should **not** be rewritten as missing
markdown pages. In other words, it recognizes the special agent/LLM-readability
output files so the docs system leaves them alone instead of treating them as
absent `.md` documents to regenerate or redirect.

## What it covers

It covers the following agent-readability artifacts:

- `llms.txt`
- `llms-full.txt`
- sitemap files
- `robots.txt`
- search JSON (e.g. `search-index.json`, `search-content.json`)
- `agent-readability.json`

## Source

Documented in `docs/reference/llm.md` (LLM files reference) of the Leadtype docs.
