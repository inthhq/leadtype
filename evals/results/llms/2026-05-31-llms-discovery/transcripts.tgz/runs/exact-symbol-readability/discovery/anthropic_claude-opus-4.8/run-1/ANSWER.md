# Preventing agent-readability artifacts from being rewritten

The helper is **`isAgentReadabilityArtifactPath`**.

## What it does

It identifies artifact paths that should **not** be rewritten as missing
markdown pages. In other words, it lets the docs system recognize special
machine-readable files so they are treated as static artifacts rather than
being mistaken for absent `*.md` documentation pages.

## What it covers

`isAgentReadabilityArtifactPath` covers the following artifact paths:

- `llms.txt`
- `llms-full.txt`
- sitemap files
- `robots.txt`
- search JSON
- `agent-readability.json`

Source: `docs/reference/llm.md` (LLM files reference).
