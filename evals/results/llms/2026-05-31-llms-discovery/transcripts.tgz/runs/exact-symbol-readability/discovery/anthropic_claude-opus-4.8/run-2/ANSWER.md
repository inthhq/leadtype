# Preventing agent-readability artifacts from being rewritten

## Helper

**`isAgentReadabilityArtifactPath`**

This is the helper in the Leadtype library that identifies artifact paths which should **not** be rewritten as missing markdown pages.

## What it covers

`isAgentReadabilityArtifactPath` recognizes the following agent-readability/static
artifact paths:

- `llms.txt`
- `llms-full.txt`
- sitemap files (e.g. `sitemap.xml`, `sitemap.md`)
- `robots.txt`
- search JSON (`search-index.json`, `search-content.json`)
- `agent-readability.json`

By matching these paths, the helper ensures that requests for these static
artifacts are served as-is rather than being treated as missing docs pages and
rewritten to a markdown mirror.

## Source

`docs/reference/llm.md` (LLM files reference).
