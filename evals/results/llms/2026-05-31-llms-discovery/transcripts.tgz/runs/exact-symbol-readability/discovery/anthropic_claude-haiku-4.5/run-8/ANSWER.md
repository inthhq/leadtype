# Agent-Readability Artifact Prevention Helper

## Helper Name
`isAgentReadabilityArtifactPath`

## Description
`isAgentReadabilityArtifactPath` identifies artifact paths that should not be rewritten as missing markdown pages. 

It covers the following artifacts:
- llms.txt
- llms-full.txt
- sitemap files (sitemap.xml, sitemap.md)
- robots.txt
- search JSON (search-index.json, search-content.json)
- agent-readability.json

This helper prevents these special agent-readable artifacts from being incorrectly treated as missing markdown pages that need to be rewritten, ensuring they are served as static artifacts in their proper format.
