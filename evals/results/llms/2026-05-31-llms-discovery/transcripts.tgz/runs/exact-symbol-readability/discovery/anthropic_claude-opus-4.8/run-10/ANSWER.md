# Preventing agent-readability artifacts from being rewritten

## Helper

`isAgentReadabilityArtifactPath`

## What it does

In the Leadtype library, `isAgentReadabilityArtifactPath` identifies artifact
paths that should **not** be rewritten as missing markdown pages. These are
static agent-readability artifacts rather than regular docs pages, so the
helper protects them from being treated as absent markdown content.

## What it covers

- `llms.txt`
- `llms-full.txt`
- sitemap files
- `robots.txt`
- search JSON
- `agent-readability.json`

## Source

- `docs/reference/llm.md` (LLM files reference)
