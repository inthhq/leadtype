The helper is `isAgentReadabilityArtifactPath`.

It identifies Leadtype’s agent-readability/static artifact paths so they are not treated as missing markdown pages and rewritten. It covers `llms.txt`, `llms-full.txt`, sitemap files, `robots.txt`, search JSON artifacts, and `agent-readability.json`.
