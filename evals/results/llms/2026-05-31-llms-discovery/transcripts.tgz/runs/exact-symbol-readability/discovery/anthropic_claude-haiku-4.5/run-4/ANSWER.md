# Agent-Readability Artifact Protection Helper

## Helper Name
**isAgentReadabilityArtifactPath**

## Description
`isAgentReadabilityArtifactPath` is a helper function in the Leadtype library that identifies artifact paths which should not be rewritten as missing markdown pages.

## Coverage
The helper covers the following static artifacts that must be preserved:
- llms.txt
- llms-full.txt
- Sitemap files (sitemap.xml, sitemap.md)
- robots.txt
- Search JSON files (search-index.json, search-content.json)
- agent-readability.json

These artifacts are essential for agent/LLM accessibility and search indexing, and should be served as-is without being replaced by markdown page 404 responses.
