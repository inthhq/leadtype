# Preventing agent-readability artifacts from being rewritten

## Helper

**`isAgentReadabilityArtifactPath`**

## What it does

This helper identifies artifact paths that should **not** be rewritten as
missing markdown pages. When the docs system would otherwise treat an unknown
path as a missing `.md` page, this helper recognizes the path as a legitimate
static agent-readability artifact and leaves it alone.

## What it covers

It covers the following artifact paths:

- `llms.txt`
- `llms-full.txt`
- sitemap files
- `robots.txt`
- search JSON
- `agent-readability.json`

## Source

Documented in `docs/reference/llm.md` (LLM files reference):

> `isAgentReadabilityArtifactPath` identifies artifact paths that should not be
> rewritten as missing markdown pages. It covers llms.txt, llms-full.txt,
> sitemap files, robots.txt, search JSON, and agent-readability.json.
