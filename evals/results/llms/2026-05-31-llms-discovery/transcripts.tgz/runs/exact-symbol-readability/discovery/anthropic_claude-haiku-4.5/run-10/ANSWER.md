# Agent-Readability Artifact Prevention Helper

## Helper Name
**`isAgentReadabilityArtifactPath`**

## Description
`isAgentReadabilityArtifactPath` is a helper that identifies artifact paths that should not be rewritten as missing markdown pages. 

## Coverage
It covers the following artifacts:
- `llms.txt`
- `llms-full.txt`
- Sitemap files
- `robots.txt`
- Search JSON files
- `agent-readability.json`

These artifacts are preserved as static files and prevented from being incorrectly rewritten as missing markdown pages in the Leadtype library's website mode.
