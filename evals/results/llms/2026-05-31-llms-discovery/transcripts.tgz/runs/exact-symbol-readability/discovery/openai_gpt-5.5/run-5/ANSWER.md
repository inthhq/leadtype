The helper is `isAgentReadabilityArtifactPath`.

It identifies generated agent-readability/static artifact paths so they are not treated as missing Markdown pages and rewritten. The covered artifacts include `llms.txt`, `llms-full.txt`, sitemap files, `robots.txt`, search JSON files, and `agent-readability.json`.
