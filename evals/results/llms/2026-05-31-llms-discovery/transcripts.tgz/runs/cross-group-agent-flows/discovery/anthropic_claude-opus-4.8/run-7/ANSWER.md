# Cross-group agent flows: hosted website vs npm bundle

Leadtype builds one MDX source into two complementary agent-facing flows. Both
start from MDX pages (read frontmatter, flatten MDX components, resolve the group
tree), but they emit different artifacts and agents enter through different files.

## Hosted website flow

**Docs sources:** `/docs/build/connect-docs-site.md` (with supporting detail in
`/docs/how-it-works.md` and `/docs/reference/llm.md`).

**Entry file for agents:** HTTP agents start at **`/llms.txt`** at the site root
and follow markdown links to mirrored pages under **`/docs/*.md`**.

**How it serves agents:** Markdown is served when the request's `Accept` header
asks for `text/markdown`, or when a known AI user agent requests a docs page.

**Website artifacts produced (kept as static files):**

- `/llms.txt` (product-level) and `/docs/llms.txt` (docs-scoped map) — via `generateLlmsTxt`
- `/llms-full.txt` — single root full-context file with every markdown page — via `generateLLMFullContextFiles`
- `/docs/*.md` markdown mirrors
- sitemap files (e.g. `/docs/sitemap.xml`)
- `robots.txt` (should allow `/llms.txt`)
- search JSON
- `agent-readability.json`

**Verification checks:** fetch `/llms.txt`, fetch a docs page with
`Accept: text/markdown`, check `/docs/sitemap.xml`, and confirm `/robots.txt`
allows `/llms.txt`.

## npm package bundle flow

**Docs source:** `/docs/package-docs/bundle.md` (plus
`/docs/reference/llm.md` and `/docs/how-it-works.md`).

**Command:** `leadtype generate --bundle`, used when publishing an npm package.

**Entry file for agents:** Coding agents working inside installed npm packages
(`node_modules`) start at **`AGENTS.md`** at the package root and follow
**relative** `./docs/reference/...` style links to `docs/*.md` — no network
request required.

**Artifacts produced:**

- `AGENTS.md` at the package root — via `generateAgentsMd`
  (intentionally ignores `product.agentGuidance`, since that text targets website
  URL routing)
- `docs/*.md` beneath the package root, using relative links

## Which website artifacts bundle mode skips

Bundle mode writes only `AGENTS.md` and `docs/*.md`. It **skips the
website-only artifacts**:

- `llms.txt`
- `llms-full.txt`
- search JSON
- sitemap files
- `robots.txt`
- `agent-readability.json`

(These same paths are the ones `isAgentReadabilityArtifactPath` recognizes as
artifact paths so they are not rewritten as missing markdown pages.)

## How the two flows relate

They complement each other rather than compete: a single package can publish
bundled offline docs for `node_modules` (entry: `AGENTS.md`, relative links) **and**
a hosted docs website with `llms.txt` (entry: `/llms.txt`, URL links) for
URL-based agents. The key difference is the entry file (`AGENTS.md` vs
`/llms.txt`), link style (relative vs URL), and whether the network-oriented
website artifacts above are emitted.
