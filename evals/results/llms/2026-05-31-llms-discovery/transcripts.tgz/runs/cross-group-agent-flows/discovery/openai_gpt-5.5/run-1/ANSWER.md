# Cross-group agent flows: hosted website vs npm bundle

Leadtype supports two complementary agent-readable flows from the same MDX source and group metadata.

## Hosted website flow

- **Entry point:** HTTP/URL-based agents start at the site-root **`/llms.txt`**.
- **Navigation:** Agents follow the markdown links from `llms.txt` into generated markdown mirrors under **`/docs/*.md`**. Hosted sites may also expose **`/docs/llms.txt`** as a docs-scoped map.
- **Groups:** Page `group` frontmatter organizes `llms.txt` sections, navigation, search metadata, and routing hints. A page can appear in multiple groups. The full-context fallback, **`/llms-full.txt`**, contains all generated markdown pages and is not split into per-group full-context files.
- **Typical website artifacts:** Website mode writes `/llms.txt`, `/docs/llms.txt`, `/llms-full.txt`, markdown mirrors under `/docs/*.md`, sitemap files, `robots.txt`, `agent-readability.json`, and static search JSON.

## npm package bundle flow

- **Entry point:** Coding agents working inside an installed npm package start at package-root **`AGENTS.md`**.
- **Navigation:** `AGENTS.md` links to bundled markdown files with relative paths such as **`./docs/reference/cli.md`**, so agents can read docs from `node_modules` without fetching the hosted website.
- **Groups:** The same group metadata is used to organize `AGENTS.md`, so cross-group pages can still be discoverable in the package bundle.
- **Generated files:** `leadtype generate --bundle` writes **`AGENTS.md`** plus bundled **`docs/*.md`** files.

## Website artifacts skipped by bundle mode

Bundle mode intentionally omits hosted-site-only artifacts, including:

- `llms.txt` artifacts, including the hosted `/llms.txt` flow and docs map such as `/docs/llms.txt`
- `/llms-full.txt`
- search JSON, such as `search-index.json` and `search-content.json`
- sitemap files, such as `sitemap.xml` and `sitemap.md`
- `robots.txt`
- `agent-readability.json`

In short: hosted agents begin with `/llms.txt` and traverse URL-based `/docs/*.md`; package-local coding agents begin with `AGENTS.md` and traverse relative `docs/*.md`. Bundle mode keeps only the package-local guide and markdown docs, skipping the website discovery, search, sitemap, robots, readability, and full-context artifacts.
