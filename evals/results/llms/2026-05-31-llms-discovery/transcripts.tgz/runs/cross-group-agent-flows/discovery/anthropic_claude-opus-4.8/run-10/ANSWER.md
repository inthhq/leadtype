# Cross-group agent flows: hosted website vs npm package bundle

Leadtype turns one MDX source into multiple outputs and supports two distinct
agent-consumption flows. They complement each other: a single package can both
publish a hosted docs site (for URL-based agents) and ship offline bundled docs
(for coding agents working inside `node_modules`).

## The two flows

### 1. Hosted website flow (HTTP agents)

- **Where the agent starts:** `/llms.txt` at the site root.
  (Source: `docs/how-it-works.md` — "HTTP agents start at /llms.txt and follow markdown links.")
- **How it navigates:** Follows markdown links to per-page mirrors under
  `/docs/*.md`. The docs-scoped `/docs/llms.txt` map is also generated.
- **Mode/command:** Website mode — `leadtype generate` (no `--bundle`).
- **Serving rule:** Serve markdown when `Accept: text/markdown` is requested,
  or when a known AI user agent requests a docs page.

### 2. npm package bundle flow (coding agents offline)

- **Where the agent starts:** `AGENTS.md` at the package root.
  (Source: `docs/how-it-works.md` — "Coding agents working inside installed npm
  packages start at AGENTS.md and follow relative docs/*.md links.")
- **How it navigates:** Follows **relative** links such as
  `./docs/reference/cli.md`, so docs can be read inside `node_modules` with no
  network request.
- **Mode/command:** Bundle mode — `leadtype generate --bundle`.
- **Note:** `generateAgentsMd` intentionally ignores `product.agentGuidance`,
  because that guidance text is written for website URL routing.

## Files each flow starts from

| Flow | Entry file | Link style | Target audience |
|------|-----------|------------|-----------------|
| Hosted website | `/llms.txt` (+ `/docs/llms.txt`) | Absolute markdown URLs to `/docs/*.md` | HTTP / URL-based agents |
| npm bundle | `AGENTS.md` (package root) | Relative paths like `./docs/reference/cli.md` | Coding agents inside `node_modules` |

Both flows include the per-page markdown mirrors under `docs/*.md`.

## Website artifacts that bundle mode skips

Bundle mode writes only `AGENTS.md` plus `docs/*.md`. It **skips all
website-only artifacts** (Source: `docs/package-docs/bundle.md`):

- `llms.txt`
- `llms-full.txt`
- search JSON (the static search index + content)
- sitemap files (`sitemap.xml` / `sitemap.md`)
- `robots.txt`
- `agent-readability.json`

These same artifacts are the static website-mode outputs. In website mode the
`--json` output lists them as `llmsTxt`, `docsLlmsTxt`, `llmsFullTxt`,
`agentReadabilityJson`, `sitemapXml`, `sitemapMd`, `robotsTxt`, `searchIndex`,
and `searchContent` (Source: `docs/reference/cli.md`). The same set is what
`isAgentReadabilityArtifactPath` recognizes as artifact paths that should not be
rewritten as missing markdown pages (Source: `docs/reference/llm.md`).

## Why the split makes sense

- Website artifacts (`llms.txt`, `llms-full.txt`, search JSON, sitemaps,
  `robots.txt`, `agent-readability.json`) exist to support HTTP discovery,
  full-context fallback, and search at a hosted URL — none of which a coding
  agent reading files on disk needs.
- The bundle ships a self-contained, version-matched set: an `AGENTS.md` entry
  point and relative-linked markdown, so offline agents never make a network
  request.

### Sources
- `docs/how-it-works.md`
- `docs/build/connect-docs-site.md`
- `docs/package-docs/bundle.md`
- `docs/reference/cli.md`
- `docs/reference/llm.md`
- `docs/reference/search.md`
