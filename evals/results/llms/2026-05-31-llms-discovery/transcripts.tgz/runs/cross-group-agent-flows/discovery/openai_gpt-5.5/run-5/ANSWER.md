# Hosted website flow vs npm package bundle flow for agents

Leadtype supports two complementary agent flows from the same MDX docs source.

## Hosted website flow

Hosted, URL-based/HTTP agents start at the site-root ` /llms.txt` map, then follow the page-level markdown links it lists, such as `/docs/reference/cli.md`.

In website mode, `leadtype generate` emits the agent-readable website artifacts, including:

- `/llms.txt` — product-level agent entry point
- `/docs/llms.txt` — docs-scoped map
- `/llms-full.txt` — one root full-context fallback containing all generated markdown docs pages
- `/docs/*.md` — markdown mirrors of docs pages
- `docs/sitemap.xml` and `docs/sitemap.md`
- `docs/robots.txt`
- `docs/agent-readability.json`
- `docs/search-index.json` and `docs/search-content.json`

For hosted sites, these files are served as static artifacts; docs pages can also return markdown for `Accept: text/markdown` or known AI user agents.

## npm package bundle flow

Coding agents working inside an installed npm package start at `AGENTS.md` in the package root. From there they follow relative links to bundled markdown files, for example `./docs/reference/cli.md`, so the docs can be read from `node_modules` without a network request.

Bundle mode is produced with:

```sh
leadtype generate --bundle
```

It writes:

- `AGENTS.md` at the package root
- `docs/*.md` beneath it, linked relatively from `AGENTS.md`

## Group behavior across both flows

Groups are routing and organization metadata, not separate shards. A page can belong to multiple groups, and groups organize `llms.txt` sections, navigation/search metadata, and `AGENTS.md` grouping. The hosted `/llms-full.txt` remains one root full-context file containing all generated markdown pages; Leadtype does not publish per-group full-context files by default.

## Website artifacts skipped by bundle mode

Bundle mode skips website-only artifacts. It does not emit the hosted-site files such as:

- `llms.txt` files, including the website `/llms.txt` / docs map flow
- `/llms-full.txt`
- search JSON, including `docs/search-index.json` and `docs/search-content.json`
- sitemap files, including `docs/sitemap.xml` and `docs/sitemap.md`
- `robots.txt`
- `agent-readability.json`

In short: hosted agents enter through `/llms.txt` and website URLs; npm-bundled coding agents enter through `AGENTS.md` and relative `docs/*.md` files.