# Cross-group agent flows: hosted website vs npm bundle

Leadtype produces two agent-facing flows from the same source material: MDX docs pages plus frontmatter and the resolved group tree.

## Hosted website flow

- **Use case:** HTTP-discoverable docs for agents that browse a deployed website.
- **Agent entry point:** the site-root `llms.txt` (`/llms.txt`).
- **How agents continue:** agents follow the markdown links from `/llms.txt` into markdown mirrors under `/docs/*.md`. A docs-scoped `/docs/llms.txt` is also generated as a map for hosted websites.
- **Generated website artifacts:** website mode writes `/llms.txt`, `/docs/llms.txt`, `/llms-full.txt`, markdown mirrors under `/docs/*.md`, sitemap files, `robots.txt`, `agent-readability.json`, and search JSON files.
- **Groups:** groups organize `llms.txt` sections, navigation, search metadata, and routing hints. The root `/llms-full.txt` contains every generated markdown docs page and is **not** split into per-group full-context files.

## npm package bundle flow

- **Use case:** offline docs bundled into an npm package, readable from inside `node_modules` without network access.
- **Command:** `leadtype generate --bundle`.
- **Agent entry point:** `AGENTS.md` at the package root.
- **How agents continue:** `AGENTS.md` links relatively to bundled markdown files, for example `./docs/reference/cli.md`, so coding agents can follow `docs/*.md` paths inside the installed package.
- **Generated bundle artifacts:** bundle mode writes `AGENTS.md` and `docs/*.md` beneath the package root.
- **Groups:** groups still drive `AGENTS.md` grouping. A page can belong to multiple groups, and those group assignments are used for organization rather than as separate full-context shards.

## Website artifacts skipped by bundle mode

Bundle mode intentionally skips website-only artifacts:

- `llms.txt`
- `llms-full.txt`
- search JSON files, including `search-index.json` and `search-content.json`
- sitemap files, including `sitemap.xml` and `sitemap.md`
- `robots.txt`
- `agent-readability.json`

In short: hosted agents start from `/llms.txt` and traverse URL-based markdown mirrors; npm-package coding agents start from package-root `AGENTS.md` and traverse relative `docs/*.md` files. Bundle mode keeps only the package-local agent docs and omits the hosted-site discovery, search, sitemap, robots, readability, and full-context website artifacts.
