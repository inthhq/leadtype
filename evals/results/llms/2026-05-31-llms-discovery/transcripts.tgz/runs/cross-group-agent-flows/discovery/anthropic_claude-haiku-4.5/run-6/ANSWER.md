# Cross-Group Agent Flows: Hosted vs NPM Bundle

## Overview

Leadtype supports two complementary agent flows for accessing documentation:

1. **Hosted Website Flow** - For HTTP agents accessing documentation via URLs
2. **NPM Bundle Flow** - For coding agents working inside installed npm packages

These two flows complement each other, allowing a package to publish bundled offline docs for node_modules and a hosted docs website with llms.txt for URL-based agents.

## Hosted Website Flow

**Starting Point:** `/llms.txt`

HTTP agents start at `/llms.txt` and follow markdown links to access documentation hosted on a website.

**Artifacts Generated:**
- `/llms.txt`
- `/docs/llms.txt`
- `/llms-full.txt`
- Markdown mirrors under `/docs/*.md`
- `docs/sitemap.xml`
- `docs/sitemap.md`
- `docs/robots.txt`
- `docs/agent-readability.json`
- `docs/search-index.json`
- `docs/search-content.json`

## NPM Bundle Flow

**Starting Point:** `AGENTS.md` (at package root)

Coding agents working inside installed npm packages start at `AGENTS.md` and follow relative `docs/*.md` links.

**Artifacts Generated:**
- `AGENTS.md` (at package root)
- `docs/*.md` (relative documentation files)

## Website Artifacts Skipped in Bundle Mode

When using `leadtype generate --bundle`, the following website-only artifacts are **skipped**:

1. `llms.txt`
2. `llms-full.txt`
3. Search JSON files (search-index.json, search-content.json)
4. Sitemap files (sitemap.xml, sitemap.md)
5. `robots.txt`
6. `agent-readability.json`

## Key Difference

The critical difference is **link style**:

- **Website Mode:** Uses absolute URLs suitable for HTTP agents
- **Bundle Mode:** Uses relative links (e.g., `./docs/reference/cli.md`) so coding agents can read docs inside node_modules without requiring a network request

This design allows the same source MDX pages to generate both website artifacts for URL-based agents and bundled offline docs for package-based coding agents.
