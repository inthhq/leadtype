# Cross-group agent flows: hosted website vs npm package bundle

Leadtype turns one MDX source into multiple agent-readable outputs. Two distinct flows exist for agents, each documented in a different docs group. They are complementary: a single package can publish bundled offline docs *and* a hosted docs website.

## The two flows at a glance

| | Hosted website flow | npm package bundle flow |
|---|---|---|
| Docs group | Build → [Connect a docs site](/docs/build/connect-docs-site.md) | Ship Package Docs → [Bundle docs into a package](/docs/package-docs/bundle.md) |
| How it's built | Default `leadtype generate` (website mode) | `leadtype generate --bundle` |
| Agent type served | HTTP / URL-based agents | Coding agents working inside installed `node_modules` |
| Entry/start file | `/llms.txt` at the site root | `AGENTS.md` at the package root |
| How agents navigate | Follow markdown links to `/docs/*.md` mirrors | Follow **relative** links like `./docs/reference/cli.md` |
| Network needed? | Yes — fetched over HTTP | No — read directly inside `node_modules` |

## Which file each flow starts from

Per [How it works](/docs/how-it-works.md):

- **HTTP agents start at `/llms.txt`** and follow markdown links to the `/docs/*.md` mirrors.
- **Coding agents inside installed npm packages start at `AGENTS.md`** and follow relative `docs/*.md` links.

Note: `AGENTS.md` (written by `generateAgentsMd`) intentionally ignores `product.agentGuidance`, because that guidance text is written for website URL routing, not for offline relative-link navigation.

## What the website (default) flow produces

In website mode the build generates:

- `/llms.txt` at the site root (product-level), plus the docs-scoped `/docs/llms.txt` map (`generateLlmsTxt`)
- `/llms-full.txt` — one root full-context file containing every generated markdown page (`generateLLMFullContextFiles`)
- Markdown mirrors under `/docs/*.md`
- Sitemap files (e.g. `/docs/sitemap.xml`), `robots.txt`
- Search JSON (static search index + content)
- `agent-readability.json`

With `--json`, website mode reports paths for: `llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, `agentReadabilityJson`, `sitemapXml`, `sitemapMd`, `robotsTxt`, `searchIndex`, and `searchContent`.

Website mode also adds HTTP serving behavior: markdown is served when `Accept: text/markdown` is requested or when a known AI user agent requests a docs page, while `/llms.txt`, `/llms-full.txt`, sitemap files, `robots.txt`, search JSON, and `agent-readability.json` are kept as static artifacts.

## What bundle mode writes

`leadtype generate --bundle` writes only the offline-relevant files:

- `AGENTS.md` at the package root
- `docs/*.md` beneath it, linked with relative paths (`./docs/...`)

## Website artifacts that bundle mode skips

Bundle mode is offline-only, so it **skips all website-only artifacts**:

- `llms.txt`
- `llms-full.txt`
- search JSON
- sitemap files
- `robots.txt`
- `agent-readability.json`

(These are exactly the agent-readability artifact paths recognized by `isAgentReadabilityArtifactPath`, which is why a hosted site keeps them static rather than rewriting them as missing markdown pages.)

## Summary

- **Hosted website flow**: built by default `leadtype generate`; agents start at `/llms.txt` and follow links to `/docs/*.md`; produces the full set of HTTP-discoverable artifacts (`llms.txt`, `llms-full.txt`, sitemaps, `robots.txt`, search JSON, `agent-readability.json`).
- **npm package bundle flow**: built with `--bundle`; agents start at `AGENTS.md` and follow relative `./docs/*.md` links with no network; writes only `AGENTS.md` + `docs/*.md` and skips every website-only artifact listed above.
