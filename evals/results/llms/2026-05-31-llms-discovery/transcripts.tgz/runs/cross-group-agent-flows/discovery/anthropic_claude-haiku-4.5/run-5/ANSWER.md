# Cross-group Agent Flows: Hosted vs npm Bundle

## Overview

Leadtype supports two complementary agent flows for serving documentation to different types of agents:

1. **Hosted Website Flow**: For HTTP agents accessing a docs site over the network
2. **npm Bundle Flow**: For coding agents working inside installed npm packages

These flows have different starting points and generate different sets of artifacts.

---

## Hosted Website Flow

### Starting File
HTTP agents start at **/llms.txt** at the site root and follow markdown links from there.

### Generated Artifacts
Website mode generates the following agent-related artifacts:

- **/llms.txt** - Product-level agent index at the root
- **/docs/llms.txt** - Docs-scoped agent index
- **/llms-full.txt** - Complete context file with every generated markdown page
- **/docs/*.md** - Markdown mirrors of all documentation pages
- **docs/sitemap.xml** - XML sitemap for agent discovery
- **docs/sitemap.md** - Markdown sitemap
- **docs/robots.txt** - Robots.txt file for agent guidelines
- **docs/agent-readability.json** - Agent readability metadata
- **docs/search-index.json** - Search index for agents
- **docs/search-content.json** - Search content data

### Configuration
Use the standard `leadtype generate` command (no flags) for website mode.

---

## npm Bundle Flow

### Starting File
Coding agents start at **AGENTS.md** in the package root and follow relative docs/*.md links (like ./docs/reference/cli.md).

### Generated Artifacts
Bundle mode generates only package-relevant artifacts:

- **AGENTS.md** - Agent entry point at the package root
- **docs/*.md** - Markdown documentation with relative links

### Key Characteristics
- Uses relative links (./docs/...) so agents can work inside node_modules without network requests
- Simpler artifact footprint focused only on offline access

### Configuration
Use `leadtype generate --bundle` when publishing an npm package.

---

## Artifacts Skipped in Bundle Mode

Bundle mode explicitly skips all website-only artifacts:

- **llms.txt** files (both /llms.txt and /docs/llms.txt)
- **llms-full.txt** - Full context file
- **sitemap files** (sitemap.xml, sitemap.md)
- **robots.txt** - Not needed for npm packages
- **search JSON files** (search-index.json, search-content.json)
- **agent-readability.json** - Website metadata

These are all HTTP/web-specific artifacts designed for URL-based routing and agent discovery on hosted sites.

---

## Summary Table

| Aspect | Hosted Website | npm Bundle |
|--------|---|---|
| **Starting File** | /llms.txt | AGENTS.md |
| **Link Type** | Absolute/HTTP URLs | Relative (./docs/...) |
| **Access Pattern** | HTTP requests to site | File system access in node_modules |
| **Entry Point Count** | 2 (/llms.txt + /docs/llms.txt) | 1 (AGENTS.md) |
| **Full Context File** | /llms-full.txt | None |
| **Navigation/Metadata** | Sitemaps, robots.txt, search JSON | None |
| **Use Case** | Web agents discovering docs via URLs | Coding agents accessing bundled offline docs |

---

## Complementary Strategy

The two flows are designed to complement each other. A single package can:
- Publish **bundled offline docs** in node_modules for developers and coding agents
- Simultaneously provide a **hosted docs website** with llms.txt for URL-based HTTP agents

This allows maximum flexibility for different agent types and access patterns.
