# Cross-group agent flows: hosted website vs npm package bundle

Leadtype supports two complementary agent flows from the same MDX source.

## Hosted website flow

- **Entry point:** HTTP/URL-based agents start at the site-root **`/llms.txt`**.
- **Docs map:** Hosted generation also writes **`/docs/llms.txt`** for a docs-scoped map.
- **Page content:** Agents follow markdown links from those maps to markdown mirrors under **`/docs/*.md`**.
- **Full fallback:** Website mode writes one root **`/llms-full.txt`** containing every generated markdown docs page.
- **Groups:** Groups organize `llms.txt` sections, navigation, search metadata, and routing hints. They are not separate full-context shards; `/llms-full.txt` is not split per group.
- **Other website artifacts:** Website mode also emits sitemap files, robots.txt, agent-readability metadata, and static search JSON.

## npm package bundle flow

- **Entry point:** Coding agents inside an installed npm package start at package-root **`AGENTS.md`**.
- **Page content:** `AGENTS.md` links relatively to bundled markdown pages under **`docs/*.md`**, for example `./docs/reference/cli.md`, so agents can work inside `node_modules` without network access.
- **Groups:** The same frontmatter `group` values organize the `AGENTS.md` grouping. A page can appear in multiple groups when its frontmatter uses multiple groups.
- **Website-specific guidance:** `generateAgentsMd` intentionally ignores `product.agentGuidance` because that guidance is written for website URL routing.

## What bundle mode skips

When using `leadtype generate --bundle`, Leadtype writes only **`AGENTS.md`** and bundled **`docs/*.md`**. It skips the website-only artifacts:

- `llms.txt`
- `llms-full.txt`
- search JSON, including `search-index.json` and `search-content.json`
- sitemap files, including `sitemap.xml` and `sitemap.md`
- `robots.txt`
- `agent-readability.json`

In short: hosted agents enter through `/llms.txt` and traverse URL-based markdown artifacts; package-local coding agents enter through `AGENTS.md` and traverse relative `docs/*.md` files bundled in the npm tarball.