# Cross-group Agent Flows: Hosted vs NPM Bundle

## Overview

Leadtype supports two distinct agent flows for different deployment scenarios:
1. **Hosted Website Flow** - For HTTP/URL-based agents accessing docs on a hosted website
2. **NPM Bundle Flow** - For coding agents working inside installed npm packages

These flows complement each other, allowing a package to publish both bundled offline docs for node_modules and a hosted docs website.

---

## Starting Points

### Hosted Website Flow
- **Starting File**: `/llms.txt` (product-level entry point)
- **Secondary Entry**: `/docs/llms.txt` (docs-scoped map for hosted websites)
- **Agent Type**: HTTP agents that follow markdown links

### NPM Bundle Flow
- **Starting File**: `AGENTS.md` (package root entry point)
- **Agent Type**: Coding agents running inside installed npm packages that follow relative docs/*.md links

---

## Generated Artifacts by Mode

### Website Mode Generates:
- `/llms.txt` - Product-level agent map
- `/docs/llms.txt` - Docs-scoped map for hosted websites
- `/llms-full.txt` - Root full-context file containing every generated markdown docs page
- `/docs/*.md` - Markdown mirrors of all pages
- `/docs/sitemap.xml` - XML sitemap
- `/docs/sitemap.md` - Markdown sitemap
- `/docs/robots.txt` - Robots file
- `/docs/agent-readability.json` - Agent readability metadata
- `/docs/search-index.json` - Search index
- `/docs/search-content.json` - Search content

### Bundle Mode Generates:
- `AGENTS.md` - NPM package root entry point with relative links like `./docs/reference/cli.md`
- `docs/*.md` - Markdown pages with relative links for node_modules

---

## Website Artifacts Bundle Mode Skips

Bundle mode intentionally skips these website-only artifacts:
1. **llms.txt** - Not needed since agents read AGENTS.md from package root
2. **llms-full.txt** - Not needed for bundled docs
3. **Search JSON files** - `search-index.json` and `search-content.json`
4. **Sitemap files** - `sitemap.xml` and `sitemap.md`
5. **robots.txt** - Not relevant for offline npm packages
6. **agent-readability.json** - Not needed for bundled artifacts

---

## Key Design Details

- **Group Organization**: Groups organize both llms.txt sections (hosted) and AGENTS.md grouping (bundled), but per-group full-context files are not published by default
- **Product Guidance**: `product.agentGuidance` is intentionally ignored in bundle mode since that text is written for website URL routing, not for npm package relative links
- **Relative Links**: Bundle mode uses relative links like `./docs/reference/cli.md` so coding agents can read docs inside node_modules without network requests
- **Complementary Flows**: The two flows are designed to work together - a single package can support both hosted website agents and offline npm package agents
