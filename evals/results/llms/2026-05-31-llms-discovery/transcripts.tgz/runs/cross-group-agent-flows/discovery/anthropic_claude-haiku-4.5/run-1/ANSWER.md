# Cross-Group Agent Flows: Hosted vs NPM Bundle

## Overview

Leadtype supports two complementary flows for delivering documentation to agents: a hosted website flow for HTTP agents and an npm bundle flow for coding agents working with installed packages.

## The Two Flows

### 1. Hosted Website Flow (HTTP Agents)

**Starting File:** `/llms.txt`

HTTP agents discover and navigate documentation through the hosted website by:
- Starting at `/llms.txt` (the root entry point)
- Following markdown links from there to additional docs pages

**Website Artifacts Generated:**
- `/llms.txt` - Product-level file for agent discovery
- `/docs/llms.txt` - Docs-scoped map for hosted websites
- `/llms-full.txt` - Root full-context fallback containing every generated markdown docs page
- `/docs/*.md` - Markdown mirrors of all documentation pages
- `docs/sitemap.xml` - XML sitemap for agent navigation
- `docs/sitemap.md` - Markdown sitemap
- `docs/robots.txt` - Robots configuration
- `docs/agent-readability.json` - Agent readability metadata
- `docs/search-index.json` - Search index
- `docs/search-content.json` - Search content

### 2. NPM Bundle Flow (Coding Agents)

**Starting File:** `AGENTS.md` (at package root)

Coding agents working inside installed npm packages:
- Start at `AGENTS.md` located at the package root
- Follow relative links like `./docs/reference/cli.md`
- Read documentation locally without requiring network requests

**Package Artifacts Generated:**
- `AGENTS.md` - Root entry point with relative links
- `docs/*.md` - Documentation pages beneath the docs directory (with relative links)

## Key Differences

### Bundle Mode Skips Website-Only Artifacts

When using `leadtype generate --bundle` for npm packages, the following website-specific artifacts are **intentionally skipped**:

1. **llms.txt** - Product and docs-scoped maps not needed for local package access
2. **llms-full.txt** - Full-context fallback for websites
3. **Search JSON files** - `search-index.json` and `search-content.json` (website search functionality)
4. **Sitemap files** - `sitemap.xml` and `sitemap.md` (XML and markdown sitemaps)
5. **robots.txt** - Web server configuration
6. **agent-readability.json** - Agent readability metadata specific to hosted sites

### Relative Links in Bundle Mode

Bundle mode uses relative links (e.g., `./docs/reference/cli.md`) so that:
- Agents can read docs inside `node_modules` without network requests
- Documentation works offline within installed packages
- No URL-based routing is required

### Product Guidance Ignored in Bundle Mode

`generateAgentsMd` intentionally ignores `product.agentGuidance` text because that guidance is written specifically for website URL routing and is not applicable to bundled package agents.

## Complementary Approach

The two flows are designed to complement each other:
- A single package can publish **bundled offline docs for node_modules** (via `AGENTS.md`)
- The same package can publish a **hosted docs website with llms.txt** for URL-based agents
- Both flows organize content using the same group-based system for consistent navigation and routing

## Group-Based Organization

Both flows leverage the `group` frontmatter value to:
- Drive sidebar positioning
- Organize llms.txt sections
- Provide search metadata
- Group pages in AGENTS.md
- Pages can belong to multiple groups with `group: [a, b]`
- The root `/llms-full.txt` fallback contains all pages and is not split by group

## Summary Table

| Aspect | Hosted Website Flow | NPM Bundle Flow |
|--------|-------------------|-----------------|
| Starting File | `/llms.txt` | `AGENTS.md` (root) |
| Agent Type | HTTP agents | Coding agents in node_modules |
| Link Type | Absolute URLs | Relative paths |
| Network Required | Yes | No |
| Search Files | Yes (JSON) | No |
| Sitemaps | Yes | No |
| Robots.txt | Yes | No |
| Agent Readability JSON | Yes | No |
| Full Context File | `/llms-full.txt` | N/A |
| Group Organization | Yes (with llms.txt sections) | Yes (in AGENTS.md) |
