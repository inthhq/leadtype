# Hosted website flow vs npm package bundle flow

Leadtype can emit agent-readable docs for two complementary agent flows.

## Hosted website flow

Use normal website mode for an HTTP-discoverable docs site. The build emits website artifacts such as:

- `/llms.txt` at the site root
- `/docs/llms.txt` as a docs-scoped map
- `/llms-full.txt` as a full-context fallback containing all generated markdown docs pages
- markdown mirrors under `/docs/*.md`
- sitemap files, robots.txt, search JSON, and `agent-readability.json`

Agents in this flow start at **`/llms.txt`** and follow the markdown links from there. For docs pages, the site should serve markdown when the request asks for `Accept: text/markdown` or comes from a known AI user agent.

Groups are used for routing and organization: they shape `llms.txt` sections, navigation/search metadata, and page placement. A page can belong to multiple groups, while `/llms-full.txt` remains a single root fallback and is not split into per-group full-context files.

## npm package bundle flow

Use bundle mode when publishing an npm package:

```sh
leadtype generate --bundle
```

Bundle mode writes:

- **`AGENTS.md`** at the package root
- `docs/*.md` beneath it

Coding agents working inside an installed package start at **`AGENTS.md`**, then follow relative links such as `./docs/reference/cli.md`. This lets agents read docs from `node_modules` without making network requests.

`AGENTS.md` is grouped using the same group metadata as the website flow, but it is tailored for local package docs. In particular, `generateAgentsMd` ignores `product.agentGuidance` because that guidance is intended for website URL routing.

## Website artifacts skipped by bundle mode

Bundle mode does not emit the website-only artifacts. It skips:

- `llms.txt` files, including the hosted `/llms.txt` and docs map `/docs/llms.txt`
- `/llms-full.txt`
- search JSON, such as `search-index.json` and `search-content.json`
- sitemap files, such as `sitemap.xml` and `sitemap.md`
- `robots.txt`
- `agent-readability.json`

In short: hosted agents begin at `/llms.txt` and navigate URL-based markdown docs; package-local coding agents begin at `AGENTS.md` and navigate relative `docs/*.md` files.