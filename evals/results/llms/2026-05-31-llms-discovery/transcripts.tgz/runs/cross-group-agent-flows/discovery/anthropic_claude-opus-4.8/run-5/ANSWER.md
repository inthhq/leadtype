# Cross-group agent flows: hosted website vs npm package bundle

Leadtype turns one MDX source into artifacts for two distinct agent flows. They are
described across `/docs/how-it-works.md`, `/docs/build/connect-docs-site.md`,
`/docs/package-docs/bundle.md`, and `/docs/reference/llm.md`.

## The two flows at a glance

| | Hosted website flow | npm package bundle flow |
|---|---|---|
| Mode | website mode | `leadtype generate --bundle` |
| Consumer | HTTP / URL-based agents | coding agents inside installed `node_modules` |
| Entry file | `/llms.txt` (at the site root) | `AGENTS.md` (at the package root) |
| Doc pages | markdown mirrors under `/docs/*.md` | `docs/*.md` beneath the package root |
| Link style | markdown links to URLs/paths | relative links like `./docs/reference/cli.md` |
| Network needed | yes (HTTP fetch) | no (read from disk, offline) |

## Which file each flow starts from

- **Hosted website flow:** HTTP agents **start at `/llms.txt`** and follow the markdown
  links from there. The site exposes the product-level `/llms.txt` plus a docs-scoped
  `/docs/llms.txt` map (`generateLlmsTxt`), and serves markdown when `Accept: text/markdown`
  is requested or when a known AI user agent fetches a docs page.

- **npm package bundle flow:** Coding agents working inside an installed npm package
  **start at `AGENTS.md`** (written by `generateAgentsMd`) and follow its relative
  `./docs/*.md` links so they can read docs inside `node_modules` without a network
  request. Note `generateAgentsMd` intentionally ignores `product.agentGuidance`, because
  that guidance text is written for website URL routing.

## Website artifacts that bundle mode skips

Bundle mode writes only `AGENTS.md` and the `docs/*.md` pages. It **skips the
website-only artifacts**:

- `llms.txt`
- `llms-full.txt` (the root full-context fallback from `generateLLMFullContextFiles`)
- search JSON (the static search index)
- sitemap files (e.g. `sitemap.xml` / `/docs/sitemap.xml`)
- `robots.txt`
- `agent-readability.json`

These same paths are what the website flow keeps as static artifacts, and what
`isAgentReadabilityArtifactPath` recognizes so they are never rewritten as missing
markdown pages.

## How they relate

The flows are complementary, not exclusive. A single product can publish **bundled
offline docs** (`AGENTS.md` + `docs/*.md`) for consumption inside `node_modules`, while
also serving a **hosted docs website** with `llms.txt` and the full set of static
artifacts for URL-based agents. Groups are used for routing (llms.txt sections,
navigation, search metadata, AGENTS.md organization) in both flows — not for sharding
into per-group full-context files.
