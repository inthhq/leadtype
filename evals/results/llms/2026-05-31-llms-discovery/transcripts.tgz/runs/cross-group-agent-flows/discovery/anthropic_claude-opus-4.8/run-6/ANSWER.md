# Cross-group agent flows: hosted website vs npm package bundle

Leadtype turns one MDX source into multiple artifacts, and it defines **two distinct
agent flows**. Each flow has a different entry point and a different set of artifacts.

## The two flows at a glance

| Aspect | Hosted website flow | npm package bundle flow |
| --- | --- | --- |
| Audience | HTTP / URL-based agents | Coding agents working inside installed npm packages |
| Entry file | `/llms.txt` | `AGENTS.md` (at package root) |
| Link style followed | Absolute markdown links (e.g. `/docs/*.md`) | Relative links (e.g. `./docs/reference/cli.md`) |
| Network needed | Yes (fetched over HTTP) | No (read from `node_modules` offline) |
| How it's produced | Website build / website mode | `leadtype generate --bundle` |

(Source: `docs/how-it-works.md`.)

## Which files each flow starts from

### Hosted website flow
- Agents **start at `/llms.txt`** and follow its markdown links into `/docs/*.md`
  mirrors (`docs/how-it-works.md`, `docs/build/connect-docs-site.md`).
- Website mode generates `/llms.txt` at the site root plus markdown mirrors under
  `/docs/*.md`. `generateLlmsTxt` writes both the product-level `/llms.txt` and the
  docs-scoped `/docs/llms.txt` map (`docs/reference/llm.md`).
- For agent requests, the site serves markdown when `Accept: text/markdown` is sent
  or when a known AI user agent requests a docs page.

### npm package bundle flow
- Coding agents **start at `AGENTS.md`** and follow relative `docs/*.md` links
  (`docs/how-it-works.md`).
- `leadtype generate --bundle` writes `AGENTS.md` at the package root and `docs/*.md`
  beneath it (`docs/package-docs/bundle.md`).
- `AGENTS.md` uses relative links like `./docs/reference/cli.md` so agents can read
  docs inside `node_modules` without a network request.
- `generateAgentsMd` writes this `AGENTS.md` and intentionally ignores
  `product.agentGuidance`, because that guidance text is written for website URL
  routing rather than offline bundles (`docs/reference/llm.md`).

## Website artifacts that bundle mode skips

Bundle mode is deliberately offline-oriented, so it **skips the website-only
artifacts** (`docs/package-docs/bundle.md`):

- `llms.txt`
- `llms-full.txt`
- search JSON
- sitemap files
- `robots.txt`
- `agent-readability.json`

These are exactly the static artifacts the hosted website flow keeps and serves
(`docs/build/connect-docs-site.md`), and the same set that
`isAgentReadabilityArtifactPath` recognizes as artifact paths that must not be
rewritten as missing markdown pages (`docs/reference/llm.md`).

## How the two flows complement each other

The flows are complementary, not exclusive: a single package can publish bundled
offline docs for `node_modules` (AGENTS.md + relative `docs/*.md`) **and** a hosted
docs website with `llms.txt` and the full set of website artifacts for URL-based
agents (`docs/how-it-works.md`). Note also that groups are used for routing within
both flows (llms.txt sections, navigation, search metadata, AGENTS.md) and are not
published as separate per-group full-context files by default; `llms-full.txt` is a
single root full-context file in the website flow only (`docs/reference/llm.md`).
