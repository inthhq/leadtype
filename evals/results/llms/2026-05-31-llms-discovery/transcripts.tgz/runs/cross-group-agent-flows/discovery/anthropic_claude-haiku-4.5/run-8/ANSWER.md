# Cross-Group Agent Flows: Hosted vs NPM Bundle

## Overview

Leadtype supports two complementary agent flows for accessing documentation:

1. **Hosted Website Flow** - For HTTP agents accessing documentation via URLs
2. **NPM Bundle Flow** - For coding agents accessing documentation inside installed packages

Both flows start from different entry points and generate different sets of artifacts.

## Hosted Website Flow

**Starting Point:** `/llms.txt` (product-level root file)

HTTP agents start at `/llms.txt` and follow markdown links to navigate the documentation tree. This flow:

- Generates a product-level `/llms.txt` file at the site root
- Generates a docs-scoped `/docs/llms.txt` map for hosted websites
- Creates markdown mirrors under `/docs/*.md`
- Produces additional website artifacts for discoverability and navigation
- Uses group-based organization for routing

**Generated Artifacts:**
- `/llms.txt` - Product-level navigation file
- `/docs/llms.txt` - Docs-scoped map
- Markdown pages at `/docs/*.md`
- `/llms-full.txt` - Full context file containing all generated markdown docs
- Sitemap files (e.g., `/docs/sitemap.xml`)
- `robots.txt` - For search engine indexing
- `search JSON` - For search functionality
- `agent-readability.json` - For agent readability metadata

## NPM Bundle Flow

**Starting Point:** `AGENTS.md` (at package root)

Coding agents working inside installed npm packages start at `AGENTS.md` and follow relative links. This flow:

- Writes `AGENTS.md` at the package root
- Generates documentation files in `docs/*.md` beneath the root
- Uses relative links like `./docs/reference/cli.md` for node_modules access
- Allows agents to read docs without network requests
- Intentionally ignores `product.agentGuidance` (designed for website URL routing)

**Generated Artifacts:**
- `AGENTS.md` - Package root entry point with relative links
- `docs/*.md` - Relative documentation files

## Key Differences

| Aspect | Hosted Website | NPM Bundle |
|--------|---|---|
| **Starting File** | `/llms.txt` | `AGENTS.md` |
| **Access Pattern** | HTTP/URL-based | File system / node_modules |
| **Link Type** | Absolute URLs | Relative paths |
| **Network Required** | Yes | No |
| **Respects agentGuidance** | Yes | No (ignored) |

## Artifacts Skipped in Bundle Mode

When generating with `--bundle` mode, Leadtype intentionally **skips the following website-only artifacts**:

- `llms.txt` - Product-level and scoped navigation files
- `llms-full.txt` - Full context file
- `search JSON` - Search index files
- Sitemap files - XML sitemaps for discoverability
- `robots.txt` - Search engine instructions
- `agent-readability.json` - Agent readability metadata

These artifacts are only relevant for hosted websites and would be unnecessary overhead in an npm package.

## Complementary Design

The two flows are designed to complement each other. A single package can:

1. Publish bundled offline docs (AGENTS.md + docs/*.md) for developers using `node_modules`
2. Simultaneously host a docs website with `/llms.txt` for URL-based AI agents

This allows maximum flexibility for different agent types and access patterns.
