# Cross-group agent flows: hosted website vs npm package bundle

Leadtype turns one MDX source into multiple agent-readable outputs. Two distinct
agent flows exist, defined in different documentation groups:

- **Hosted website flow** — the *Build* group
  ([/docs/build/connect-docs-site.md](/docs/build/connect-docs-site.md))
- **npm package bundle flow** — the *Ship Package Docs* group
  ([/docs/package-docs/bundle.md](/docs/package-docs/bundle.md))

Both are produced by the same `leadtype generate` command; bundle mode is opted
into with the `--bundle` flag.

## Where each flow starts

Per [/docs/how-it-works.md](/docs/how-it-works.md):

| Flow | Agent type | Entry file | How agents navigate |
|------|-----------|-----------|---------------------|
| Hosted website | HTTP / URL-based agents | `/llms.txt` at the site root | Follow markdown links to `/docs/*.md` mirrors |
| npm bundle | Coding agents inside installed `node_modules` packages | `AGENTS.md` at the package root | Follow **relative** links like `./docs/reference/cli.md` (no network request) |

- **Website mode** (`connect-docs-site.md`) generates `/llms.txt` at the site
  root and markdown mirrors under `/docs/*.md`. The site serves markdown when the
  request `Accept`s `text/markdown` or comes from a known AI user agent.
- **Bundle mode** (`bundle.md`, `leadtype generate --bundle`) writes `AGENTS.md`
  at the package root and `docs/*.md` beneath it. `AGENTS.md` is written
  specifically for offline node_modules reading via relative links.

A note from [/docs/reference/llm.md](/docs/reference/llm.md): `generateAgentsMd`
(used for npm bundles) intentionally ignores `product.agentGuidance`, because
that guidance text is written for **website URL routing**, not offline package
reading. Website `llms.txt`/`docs/llms.txt` come from `generateLlmsTxt`, and the
single root `llms-full.txt` from `generateLLMFullContextFiles`.

## Website artifacts that bundle mode skips

Bundle mode produces only `AGENTS.md` + `docs/*.md`. It deliberately **skips all
website-only artifacts** (per `bundle.md`, confirmed by `connect-docs-site.md`,
`llm.md`, and the `--json` output list in
[/docs/reference/cli.md](/docs/reference/cli.md)):

- `llms.txt` (and the docs-scoped `docs/llms.txt` map)
- `llms-full.txt` (root full-context fallback)
- search JSON (the static search index / search content)
- sitemap files (`sitemap.xml` / `sitemap.md`)
- `robots.txt`
- `agent-readability.json`

In website mode these are kept as static artifacts so agents can fetch them over
HTTP, and the `generate --json` website object reports them as `llmsTxt`,
`docsLlmsTxt`, `llmsFullTxt`, `searchIndex`, `searchContent`, `sitemapXml`,
`sitemapMd`, `robotsTxt`, and `agentReadabilityJson`. None of these are emitted
in bundle mode because an offline agent reading inside `node_modules` cannot (and
need not) make network requests for them — it relies on `AGENTS.md` and the
relative-linked `docs/*.md` files instead.

## Summary

- **Hosted website flow**: starts at `/llms.txt`, mirrors docs at `/docs/*.md`,
  and keeps `llms.txt`, `llms-full.txt`, search JSON, sitemap files, `robots.txt`,
  and `agent-readability.json` as static HTTP-discoverable artifacts.
- **npm bundle flow** (`--bundle`): starts at `AGENTS.md`, ships `docs/*.md` with
  relative links for offline use, and skips every website-only artifact listed
  above.
- The flows are complementary: a single package can publish both a bundled
  offline copy for `node_modules` and a hosted docs website with `llms.txt`.
