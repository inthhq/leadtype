# Cross-group Agent Flows: Hosted vs NPM Bundle

## Overview
Leadtype supports two complementary agent flows for serving documentation to different contexts:

1. **Hosted Website Flow** - For HTTP-based agents accessing docs via URLs
2. **NPM Bundle Flow** - For coding agents working inside installed npm packages

## Hosted Website Flow

### Starting Point
HTTP agents start at **/llms.txt** and follow markdown links to navigate through documentation.

### Files Generated
The hosted website mode generates the following agent-readable artifacts:
- `/llms.txt` - Product-level entry point for agents
- `/docs/llms.txt` - Docs-scoped map for hosted websites
- `/llms-full.txt` - Root file containing every generated markdown docs page
- `/docs/*.md` - Markdown mirrors of documentation
- `sitemap.xml` / `sitemap.md` - Site maps for discovery
- `robots.txt` - Robot exclusion rules
- `search JSON` - Static search index
- `agent-readability.json` - Readability metadata

### Usage
Run `leadtype generate` (without `--bundle` flag) to produce website artifacts.

## NPM Bundle Flow

### Starting Point
Coding agents working inside installed npm packages start at **AGENTS.md** (at the package root) and follow relative `./docs/*.md` links.

### Files Generated
Bundle mode writes:
- `AGENTS.md` - Package root entry point with relative links
- `docs/*.md` - Documentation files organized by group

### Key Characteristics
- Uses **relative links** (e.g., `./docs/reference/cli.md`) so agents can read docs inside node_modules without network requests
- Intentionally ignores `product.agentGuidance` (which is written for website URL routing)
- Operates offline - no HTTP requests needed

### Usage
Run `leadtype generate --bundle` when publishing an npm package.

## Website Artifacts Skipped in Bundle Mode

Bundle mode explicitly skips the following website-only artifacts:
- `llms.txt` - Product and docs-level entry points
- `llms-full.txt` - Full context file
- `search JSON` - Search index
- `sitemap.xml` / `sitemap.md` - Sitemap files
- `robots.txt` - Robot exclusion rules
- `agent-readability.json` - Readability metadata

## Complementary Design

The two flows are designed to complement each other. A single package can:
- Publish **bundled offline docs** with AGENTS.md and relative links for use inside node_modules (for coding agents)
- Simultaneously publish a **hosted docs website** with llms.txt for URL-based HTTP agents

This allows both types of agents (HTTP-based and npm-based) to access the same documentation through their respective optimal channels.
