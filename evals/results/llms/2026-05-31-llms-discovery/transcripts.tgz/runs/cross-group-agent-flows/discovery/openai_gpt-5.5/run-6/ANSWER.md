# Hosted website vs npm bundle agent flows

Leadtype has two complementary agent flows that can be produced from the same MDX source.

## Hosted website flow

- **Starts from:** the site-root `/llms.txt` for HTTP/URL-based agents.
- **Then follows:** markdown links to generated markdown mirrors, typically under `/docs/*.md`.
- **Related hosted artifacts:** website mode also emits a docs-scoped `/docs/llms.txt`, a root `/llms-full.txt` full-context fallback, sitemap files, `robots.txt`, `agent-readability.json`, and static search JSON (`search-index.json` and `search-content.json`).
- **Groups:** page `group` frontmatter controls the `llms.txt` sections and routing hints. Groups organize discovery, navigation, search metadata, and agent maps; they are not meant to shard the corpus. `/llms-full.txt` remains one root fallback containing all generated markdown pages rather than per-group full-context files.

## npm package bundle flow

- **Starts from:** `AGENTS.md` at the package root inside the published npm package.
- **Then follows:** relative markdown links such as `./docs/reference/cli.md` to bundled `docs/*.md` files.
- **Purpose:** coding agents working inside `node_modules` can read version-matched docs offline, without making network requests to the hosted docs site.
- **Groups:** the same page grouping can be reflected in `AGENTS.md` organization, but the bundle is still navigated through local relative files rather than URL routes. `generateAgentsMd` also ignores `product.agentGuidance` because that guidance is for website URL routing.

## What bundle mode skips

When running `leadtype generate --bundle`, Leadtype writes only the npm-oriented `AGENTS.md` plus bundled `docs/*.md`. It skips the website-only artifacts:

- `llms.txt` files, including the hosted root/docs maps
- `/llms-full.txt`
- search JSON (`search-index.json`, `search-content.json`)
- sitemap files (`sitemap.xml`, `sitemap.md`)
- `robots.txt`
- `agent-readability.json`
