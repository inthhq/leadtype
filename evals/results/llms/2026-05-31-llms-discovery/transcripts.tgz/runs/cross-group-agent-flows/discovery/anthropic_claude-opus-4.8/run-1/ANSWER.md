# Cross-group agent flows: hosted website vs npm package bundle

Leadtype produces one MDX source that can serve two distinct agent flows. Both are described across the *How it works*, *Connect a docs site*, *Bundle docs into a package*, and *LLM files* pages.

## The two flows at a glance

| Aspect | Hosted website flow | npm package bundle flow |
| --- | --- | --- |
| Audience | HTTP / URL-based agents | Coding agents working inside installed npm packages (`node_modules`) |
| Entry / start file | `/llms.txt` | `AGENTS.md` (package root) |
| Link style followed | Markdown links to `/docs/*.md` URLs | Relative links like `./docs/reference/cli.md` |
| Generator mode | website mode | `leadtype generate --bundle` |
| Network needed? | Yes (HTTP-discoverable) | No (offline, read from `node_modules`) |

## Which file each flow starts from

- **Hosted website flow:** HTTP agents start at **`/llms.txt`** at the site root and follow markdown links to the `/docs/*.md` mirrors. The build serves markdown when `Accept: text/markdown` is requested or when a known AI user agent requests a docs page.
- **npm bundle flow:** Coding agents inside an installed package start at **`AGENTS.md`** at the package root and follow relative `./docs/*.md` links so they can read docs without any network request.

Per *How it works*, the flows complement each other: a single package can publish both bundled offline docs for `node_modules` and a hosted docs website with `llms.txt` for URL-based agents.

## Files generated per flow

**Website mode generates / keeps as static artifacts:**
- `/llms.txt` (product-level) and `/docs/llms.txt` (docs-scoped map) — via `generateLlmsTxt`
- `/llms-full.txt` (one root full-context file with every markdown page) — via `generateLLMFullContextFiles`
- Markdown mirrors under `/docs/*.md`
- `sitemap` files (e.g. `/docs/sitemap.xml`)
- `robots.txt`
- search JSON
- `agent-readability.json`

**Bundle mode generates:**
- `AGENTS.md` at the package root — via `generateAgentsMd` (it intentionally ignores `product.agentGuidance`, since that text is written for website URL routing)
- `docs/*.md` beneath the package root, linked relatively from `AGENTS.md`

## Which website artifacts bundle mode skips

Bundle mode is offline-oriented, so it omits all website-only / HTTP-discovery artifacts. Per *Bundle docs into a package*, bundle mode **skips**:

- `llms.txt`
- `llms-full.txt`
- search JSON
- sitemap files
- `robots.txt`
- `agent-readability.json`

This set is the same group of "agent-readability artifact" paths that `isAgentReadabilityArtifactPath` recognizes (llms.txt, llms-full.txt, sitemap files, robots.txt, search JSON, and agent-readability.json) — the artifacts that only make sense for the hosted website flow and have no role in the offline npm bundle flow.
