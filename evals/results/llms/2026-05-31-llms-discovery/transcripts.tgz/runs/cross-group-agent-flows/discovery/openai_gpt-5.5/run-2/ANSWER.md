# Hosted website flow vs npm bundle flow for agents

Leadtype supports two complementary agent-reading flows from the same MDX source.

## Hosted website flow

- **Entry point:** HTTP/URL-based agents start at the site-root `/llms.txt`.
- **Navigation:** The hosted `llms.txt` points agents to markdown mirrors such as `/docs/*.md`; Leadtype also writes a docs-scoped `/docs/llms.txt` map.
- **Cross-group behavior:** Frontmatter `group` values organize sections in `llms.txt`, navigation, search metadata, and other indexes. Groups are routing hints, not separate shards. A page may belong to multiple groups, and the root `/llms-full.txt` contains all generated markdown pages rather than one full-context file per group.
- **Website artifacts:** Website mode emits `/llms.txt`, `/docs/llms.txt`, `/llms-full.txt`, markdown mirrors under `/docs/*.md`, sitemap files, `robots.txt`, `agent-readability.json`, and static search JSON.

## npm package bundle flow

- **Entry point:** Coding agents inside an installed npm package start at `AGENTS.md` in the package root.
- **Navigation:** `AGENTS.md` uses relative links such as `./docs/reference/cli.md`, so agents can read bundled `docs/*.md` files from `node_modules` without a network request.
- **Cross-group behavior:** The same group metadata still organizes `AGENTS.md`, but bundle mode is intended for offline, version-matched package docs rather than HTTP discovery.
- **Bundle output:** `leadtype generate --bundle` writes only `AGENTS.md` plus the bundled `docs/*.md` markdown files.

## Website artifacts skipped by bundle mode

Bundle mode skips the hosted-site-only artifacts:

- `llms.txt` files, including the hosted `/llms.txt` and `/docs/llms.txt` maps
- `/llms-full.txt`
- search JSON, such as `search-index.json` and `search-content.json`
- sitemap files, such as `sitemap.xml` and `sitemap.md`
- `robots.txt`
- `agent-readability.json`
