# Cross-group agent flows: hosted website vs npm bundle

Leadtype supports two complementary agent flows.

## Hosted website flow

- **Agent entry point:** HTTP/URL-based agents start at the site-root **`/llms.txt`**.
- **Next files:** Agents follow markdown links from that map into the generated markdown mirrors under **`/docs/*.md`**. Leadtype also writes a docs-scoped **`/docs/llms.txt`** map for hosted sites.
- **Group behavior:** Groups are used as routing and organization hints. They organize `llms.txt` sections, navigation, search metadata, and `AGENTS.md` grouping. They are **not** separate full-context shards: Leadtype writes one root **`/llms-full.txt`** containing every generated markdown docs page.

## npm package bundle flow

- **Agent entry point:** Coding agents working inside an installed npm package start from package-root **`AGENTS.md`**.
- **Next files:** `AGENTS.md` links to bundled markdown docs using relative paths such as **`./docs/reference/cli.md`**, so agents can read docs inside `node_modules` without a network request.
- **Generated files:** `leadtype generate --bundle` writes **`AGENTS.md`** and bundled **`docs/*.md`** files beneath the package root.

## Website artifacts skipped by bundle mode

Bundle mode skips hosted-website-only artifacts, including:

- `llms.txt` files, including the hosted maps such as `/llms.txt` and `/docs/llms.txt`
- `/llms-full.txt`
- search JSON, such as `docs/search-index.json` and `docs/search-content.json`
- sitemap files, such as `docs/sitemap.xml` and `docs/sitemap.md`
- `robots.txt`
- `agent-readability.json`

In short: hosted agents begin with URL-discoverable `llms.txt` files and follow website markdown links, while npm-bundled agents begin with `AGENTS.md` and follow relative `docs/*.md` links packaged with the library.