# Cross-group agent flows: hosted website vs npm bundle

Leadtype supports two complementary agent flows from the same MDX source.

## Hosted website flow

- **Entry point:** HTTP/URL-based agents start at the site-root `/llms.txt`.
- **How agents continue:** They follow the markdown links from `llms.txt` into the generated markdown mirrors under `/docs/*.md`.
- **Hosted artifacts:** Website mode generates the URL-discoverable files needed by a docs site, including:
  - `/llms.txt`
  - `/docs/llms.txt`
  - `/llms-full.txt`
  - markdown mirrors under `/docs/*.md`
  - sitemap files such as `/docs/sitemap.xml` and `/docs/sitemap.md`
  - `/docs/robots.txt`
  - `/docs/agent-readability.json`
  - `/docs/search-index.json`
  - `/docs/search-content.json`

Groups are used as routing structure: they organize `llms.txt` sections, navigation, search metadata, and related agent-facing maps. They are not separate full-context shards; the root `/llms-full.txt` contains all generated markdown pages.

## npm package bundle flow

- **Entry point:** Coding agents working inside an installed npm package start at `AGENTS.md` in the package root.
- **How agents continue:** `AGENTS.md` links to bundled markdown docs with relative links such as `./docs/reference/cli.md`, so agents can read docs inside `node_modules` without making network requests.
- **Bundle artifacts:** `leadtype generate --bundle` writes:
  - `AGENTS.md`
  - bundled `docs/*.md` files

Groups still matter in bundle mode because they drive `AGENTS.md` grouping, but the bundle is optimized for offline, package-local traversal rather than HTTP discovery.

## What bundle mode skips

Bundle mode skips the website-only artifacts:

- `llms.txt` maps, including the hosted root `/llms.txt` and docs-scoped `/docs/llms.txt`
- `/llms-full.txt`
- search JSON files, such as `search-index.json` and `search-content.json`
- sitemap files, such as `sitemap.xml` and `sitemap.md`
- `robots.txt`
- `agent-readability.json`

In short: hosted agents begin with `/llms.txt` on the website and traverse URL-based markdown; package-local coding agents begin with `AGENTS.md` and traverse relative bundled `docs/*.md` files.