# Cross-group agent flows: hosted vs npm bundle

Leadtype supports two complementary agent flows over the same generated markdown content.

## Hosted website flow

For a hosted docs site, HTTP/URL-based agents start at the site-root `llms.txt` file:

- Entry point: `/llms.txt`
- Also generated: `/docs/llms.txt`
- Agents then follow the markdown links to mirrored docs pages under `/docs/*.md`.

In website mode, Leadtype also emits website/static artifacts such as `/llms-full.txt`, sitemap files, `robots.txt`, search JSON, and `agent-readability.json`. Groups organize `llms.txt` sections, navigation, search metadata, and routing hints, but the full-context fallback is one root `/llms-full.txt`, not one file per group.

## npm package bundle flow

For an npm package, coding agents working inside an installed package start from `AGENTS.md` at the package root:

- Entry point: `AGENTS.md`
- Agents then follow relative links such as `./docs/reference/cli.md` to bundled markdown files under `docs/*.md`.

This flow is intended to work offline inside `node_modules`, without requiring a network request. `AGENTS.md` preserves grouping for package docs, but it is generated for local package navigation rather than website URL routing.

## Website artifacts skipped by bundle mode

When using `leadtype generate --bundle`, Leadtype writes only the package-oriented files (`AGENTS.md` and `docs/*.md`) and skips website-only artifacts:

- `llms.txt`
- `llms-full.txt`
- search JSON, including search index/content files
- sitemap files
- `robots.txt`
- `agent-readability.json`
