# Cross-Group Agent Flows: Hosted vs npm Bundle

## Overview

Leadtype supports two complementary agent flows for discovering and reading documentation:

1. **Hosted Website Flow** - for HTTP agents accessing docs via URLs
2. **npm Bundle Flow** - for coding agents reading docs inside node_modules

## Flow Comparison

### Hosted Website Flow

**Starting Point:** `/llms.txt`

HTTP agents begin at the product-level `/llms.txt` file at the site root and follow markdown links to discover and read documentation. This flow generates artifacts for a hosted docs website.

**Generated Artifacts:**
- `/llms.txt` (product-level entry point)
- `/docs/llms.txt` (docs-scoped map)
- `/llms-full.txt` (comprehensive context file)
- `/docs/*.md` (markdown mirrors of all pages)
- `docs/sitemap.xml` (XML sitemap)
- `docs/sitemap.md` (markdown sitemap)
- `docs/robots.txt` (robots file)
- `docs/agent-readability.json` (readability metadata)
- `docs/search-index.json` (search index)
- `docs/search-content.json` (search content)

### npm Bundle Flow

**Starting Point:** `AGENTS.md`

Coding agents working inside installed npm packages start at `AGENTS.md` in the package root and follow relative `docs/*.md` links. This flow generates artifacts for bundled offline documentation.

**Generated Artifacts:**
- `AGENTS.md` (package root entry point with relative links)
- `docs/*.md` (markdown files with relative links like `./docs/reference/cli.md`)

## Key Differences

### Entry Points
- **Hosted:** `/llms.txt` (absolute URL-based)
- **Bundle:** `AGENTS.md` (relative path-based)

### Link Style
- **Hosted:** Absolute URLs like `/docs/reference/cli.md`
- **Bundle:** Relative links like `./docs/reference/cli.md`

### Use Cases
- **Hosted:** Network-based discovery via HTTP agents
- **Bundle:** Offline access inside node_modules without network requests

## Skipped Artifacts in Bundle Mode

Bundle mode intentionally skips website-only artifacts because they are not applicable to offline package distribution:

1. **llms.txt** - Product-level entry point (not needed for relative linking)
2. **llms-full.txt** - Full context file (single comprehensive file)
3. **Search artifacts** - search-index.json, search-content.json
4. **Sitemap files** - sitemap.xml, sitemap.md
5. **robots.txt** - Not applicable for offline packages
6. **agent-readability.json** - Website-specific metadata

## Complementary Use

The two flows are designed to complement each other. A single package can:
- Publish bundled offline docs (AGENTS.md + docs/*.md) for use inside node_modules by coding agents
- Publish hosted docs with llms.txt on a website for HTTP-based agents

This allows the same documentation source to serve both types of agent scenarios without duplication or conversion overhead.
