# Cross-Group Agent Flows: Hosted vs NPM Bundle

## Overview

Leadtype supports two complementary agent flows for accessing documentation: one for HTTP-based agents accessing a hosted website, and another for coding agents working with npm-bundled offline docs. Both flows use the group value to organize and route content, but they start from different entry points and generate different artifacts.

## Hosted Website Flow

### Entry Point
HTTP agents start at **/llms.txt** (the root HTTP-discoverable agent file) and follow markdown links to navigate the documentation.

### Generated Artifacts
Website mode writes the following files:
- **/llms.txt** - Root agent discovery and routing file at the site root
- **/docs/llms.txt** - Docs-scoped navigation map
- **/llms-full.txt** - Full-context file containing all generated markdown pages (not split by group)
- **markdown mirrors** - Generated markdown files under /docs/*.md (e.g., /docs/reference/cli.md)
- **docs/sitemap.xml** - XML sitemap for agent discovery
- **docs/sitemap.md** - Markdown sitemap for agent discovery
- **docs/robots.txt** - Robots.txt file to allow agent crawling
- **docs/agent-readability.json** - Agent readability metadata
- **docs/search-index.json** - Static search index
- **docs/search-content.json** - Search content data

### How Groups Function
The group value drives:
- Sidebar position
- llms.txt sections (cross-group navigation structure)
- Search metadata
- AGENTS.md grouping
- Pages can belong to multiple groups with `group: [a, b]`
- /llms-full.txt contains all pages but is not split by group

## NPM Bundle Flow

### Entry Point
Coding agents working inside installed npm packages start at **AGENTS.md** (at the package root) and follow relative markdown links to navigate docs/*.md files.

### Generated Artifacts
Bundle mode writes:
- **AGENTS.md** - Root agent entry point at package root
- **docs/*.md** - Relative markdown files beneath the docs directory (e.g., ./docs/reference/cli.md)

Links use relative paths (like ./docs/reference/cli.md) so agents can read docs inside node_modules without network requests.

### How Groups Function
Same as hosted mode:
- Drives AGENTS.md grouping
- Sidebar position
- Search metadata
- /llms-full.txt organization (when generated for reference)
- Pages can belong to multiple groups

## Website Artifacts Skipped in Bundle Mode

When using `leadtype generate --bundle`, the following website-only artifacts are **not generated**:

1. **llms.txt** - Root HTTP-discoverable agent file
2. **llms-full.txt** - Full-context compilation
3. **search JSON** - search-index.json and search-content.json
4. **sitemap files** - sitemap.xml and sitemap.md
5. **robots.txt** - Robot crawling directives
6. **agent-readability.json** - Agent readability metadata

## Key Differences Summary

| Aspect | Hosted Website | NPM Bundle |
|--------|---|---|
| **Entry Point** | /llms.txt (HTTP) | AGENTS.md (relative) |
| **Link Type** | Absolute/HTTP URLs | Relative paths |
| **Access Method** | HTTP requests | Local file system |
| **Use Case** | URL-based agents | Coding agents in node_modules |
| **Key Artifacts** | llms.txt, sitemap, search JSON, robots.txt | AGENTS.md, relative docs/*.md |
| **Group Usage** | Organizes sections across files | Organizes within AGENTS.md |

## Complementary Nature

A package can publish bundled offline docs for node_modules (using bundle mode) while simultaneously hosting a website with llms.txt for URL-based agents (using website mode). This dual approach serves both offline and online agent access patterns seamlessly.
