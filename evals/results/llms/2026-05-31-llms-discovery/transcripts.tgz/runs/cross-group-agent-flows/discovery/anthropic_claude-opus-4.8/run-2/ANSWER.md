# Cross-group agent flows: hosted website vs npm package bundle

Leadtype turns one MDX source into two complementary agent-facing flows. They live in
different doc groups: the **Build** group (`/docs/build/connect-docs-site.md`) covers the
hosted website flow, and the **Ship Package Docs** group (`/docs/package-docs/bundle.md`)
covers the npm bundle flow. `/docs/how-it-works.md` and `/docs/reference/llm.md` describe
how each flow is entered.

## Hosted website flow

**Purpose:** expose HTTP-discoverable agent files on a docs site so URL-based / HTTP agents
can fetch markdown over the network.

**Where the agent starts:**
- HTTP agents **start at `/llms.txt`** and follow the markdown links it lists.
- A docs-scoped map (`/docs/llms.txt`) plus the markdown mirrors under `/docs/*.md` are the
  pages those links resolve to.
- A full-context fallback lives at the root `/llms-full.txt` (every generated markdown page
  concatenated into one file).

**How it is built/served:**
- The build generates `/llms.txt` at the site root and markdown mirrors under `/docs/*.md`.
- For agent requests, the server returns markdown when `Accept: text/markdown` is sent or
  when a known AI user agent requests a docs page.
- These website artifacts are served as **static** files:
  `/llms.txt`, `/llms-full.txt`, sitemap files, `robots.txt`, search JSON, and
  `agent-readability.json`.
- API entry points: `generateLlmsTxt` (writes `/llms.txt` and `/docs/llms.txt`) and
  `generateLLMFullContextFiles` (writes the single root `/llms-full.txt`).

**Verification:** fetch `/llms.txt`, fetch a docs page with `Accept: text/markdown`, check
`/docs/sitemap.xml`, and confirm `/robots.txt` allows `/llms.txt`.

## npm package bundle flow

**Purpose:** ship version-matched docs inside an npm tarball so coding agents can read docs
from inside `node_modules` **without any network request** (offline).

**Where the agent starts:**
- Coding agents working inside an installed npm package **start at `AGENTS.md`** at the
  package root and follow **relative** `./docs/*.md` links (e.g. `./docs/reference/cli.md`).

**How it is built:**
- Run `leadtype generate --bundle` when publishing an npm package.
- Bundle mode writes `AGENTS.md` at the package root and `docs/*.md` beneath it, with
  relative links so the docs are readable directly inside `node_modules`.
- API entry point: `generateAgentsMd`, which intentionally ignores `product.agentGuidance`
  because that guidance text is written for website URL routing, not for the bundle.

## Side-by-side summary

| Aspect | Hosted website flow | npm bundle flow |
| --- | --- | --- |
| Doc group | Build / Connect a docs site | Ship Package Docs / Bundle |
| Command/API | `generateLlmsTxt`, `generateLLMFullContextFiles` | `leadtype generate --bundle`, `generateAgentsMd` |
| Agent entry file | `/llms.txt` (then `/docs/llms.txt`) | `AGENTS.md` at package root |
| Link style | HTTP URLs `/docs/*.md` | relative links `./docs/*.md` |
| Network needed | Yes (fetch over HTTP) | No (read from `node_modules`) |
| `product.agentGuidance` | Used (website URL routing) | Ignored |

## Website artifacts that bundle mode skips

Bundle mode produces only `AGENTS.md` plus `docs/*.md`. It **skips all website-only
artifacts**:

- `llms.txt`
- `llms-full.txt`
- search JSON
- sitemap files
- `robots.txt`
- `agent-readability.json`

(These are exactly the static artifacts the hosted website flow serves, and the same set
`isAgentReadabilityArtifactPath` treats as artifact paths rather than missing markdown
pages.)

## How the two flows relate

The flows complement each other rather than compete: a single package can publish bundled
offline docs (entered via `AGENTS.md`) for `node_modules` **and** a hosted docs website
(entered via `/llms.txt`) for URL-based agents. Groups are used for routing/navigation in
both flows — they are not sharded into per-group full-context files; the website still emits
one root `/llms-full.txt`.
