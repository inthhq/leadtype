# Cross-Group Agent Flows: Hosted vs NPM Bundle

## Overview

Leadtype supports two complementary flows for agent access to documentation:

1. **Hosted Website Flow** - HTTP agents accessing a docs website
2. **NPM Bundle Flow** - Coding agents working inside installed npm packages

These flows are designed to be complementary: a package can publish bundled offline docs for node_modules while simultaneously maintaining a hosted docs website with llms.txt for URL-based agents.

## Hosted Website Flow

### Starting Point
HTTP agents start at `/llms.txt` at the site root and follow markdown links.

### Generated Artifacts
The hosted website mode generates the following artifacts:
- **Primary index files:**
  - `/llms.txt` (product-level index at site root)
  - `/docs/llms.txt` (docs-scoped index map)
  
- **Content files:**
  - `/docs/*.md` (markdown mirrors of documentation)

- **Support artifacts:**
  - `/llms-full.txt` (complete root file containing every generated markdown docs page)
  - `/docs/sitemap.xml` (sitemap files)
  - `/robots.txt` (robots instructions)
  - `/sitemap.xml` (root sitemap)
  - Search JSON (search metadata)
  - `agent-readability.json` (agent readability information)

### Key Characteristics
- Groups organize llms.txt sections, navigation, search metadata
- Serve markdown when Accept headers ask for `text/markdown` or when known AI user agents request docs pages
- Product-level agent guidance is written for website URL routing

## NPM Bundle Flow

### Starting Point
Coding agents working inside installed npm packages start at `AGENTS.md` at the package root and follow relative `docs/*.md` links.

### Generated Artifacts
The bundle mode generates:
- **`AGENTS.md`** at the package root
- **`docs/*.md`** files beneath the package root (with relative links)

### Key Characteristics
- AGENTS.md uses relative links like `./docs/reference/cli.md` so coding agents can read docs inside node_modules without a network request
- Groups still organize the structure, navigation, search metadata, and AGENTS.md
- Intentionally ignores `product.agentGuidance` because that text is written for website URL routing

## Website Artifacts Skipped in Bundle Mode

When using `leadtype generate --bundle`, the following website-only artifacts are **not** generated:

1. **llms.txt** - Product-level index (specific to hosted websites)
2. **llms-full.txt** - Complete context file
3. **Search JSON** - Search metadata and indexes
4. **Sitemap files** - /sitemap.xml and /docs/sitemap.xml
5. **robots.txt** - Web crawler instructions
6. **agent-readability.json** - Agent readability information

These artifacts are all considered "website-only" because they either:
- Rely on HTTP/URL-based discovery (llms.txt, sitemap, robots.txt)
- Support web-specific functionality (search JSON, agent-readability.json)
- Are designed for online context (llms-full.txt is for hosted environments)

## Summary Table

| Aspect | Hosted Website Flow | NPM Bundle Flow |
|--------|-------------------|-----------------|
| **Starting Point** | `/llms.txt` (HTTP agents) | `AGENTS.md` (in node_modules) |
| **Content Access** | HTTP requests via markdown links | Relative file paths `./docs/*.md` |
| **Network Required** | Yes (HTTP-based) | No (offline, local) |
| **Index Files** | `/llms.txt`, `/docs/llms.txt` | `AGENTS.md` |
| **Content Directory** | `/docs/*.md` | `docs/*.md` (relative) |
| **Skipped Artifacts** | None | llms.txt, llms-full.txt, search JSON, sitemap files, robots.txt, agent-readability.json |
| **Agent Guidance** | Uses `product.agentGuidance` | Ignores `product.agentGuidance` |
