# Cross-group agent flows: hosted website vs npm bundle

Leadtype turns one MDX source into two complementary agent-facing delivery flows. Both are described across the *How it works*, *Connect a docs site*, *Bundle docs into a package*, and *LLM files* pages.

## The two flows at a glance

| | Hosted website flow | npm package bundle flow |
|---|---|---|
| Triggered by | Website mode build (docs site wiring) | `leadtype generate --bundle` |
| Audience | HTTP / URL-based agents (and humans) | Coding agents reading inside `node_modules` |
| Entry file | `/llms.txt` at the site root | `AGENTS.md` at the package root |
| Link style | Markdown links to `/docs/*.md` URLs | Relative links like `./docs/reference/cli.md` |
| Network needed | Yes (fetched over HTTP) | No (offline, read from disk) |

## Which file each flow starts from

- **Hosted website flow:** HTTP agents **start at `/llms.txt`** and follow its markdown links to pages mirrored under `/docs/*.md`. The site can also serve markdown when a request sends `Accept: text/markdown` or comes from a known AI user agent.
- **npm bundle flow:** Coding agents working inside an installed package **start at `AGENTS.md`** (written at the package root) and follow relative `./docs/*.md` links so they can read docs inside `node_modules` without any network request.

These two starting points are deliberately different: `generateLlmsTxt` produces the website's `/llms.txt` (and a docs-scoped `/docs/llms.txt` map), while `generateAgentsMd` produces `AGENTS.md` for the bundle. Notably, `generateAgentsMd` intentionally ignores `product.agentGuidance`, because that guidance text is written for website URL routing, not offline package use.

## Which website artifacts bundle mode skips

Bundle mode writes only `AGENTS.md` plus `docs/*.md` beneath the package root. It **skips all website-only artifacts**:

- `llms.txt`
- `llms-full.txt`
- search JSON
- sitemap files (e.g. `/docs/sitemap.xml`)
- `robots.txt`
- `agent-readability.json`

These are exactly the static artifacts the hosted website flow keeps (and that `isAgentReadabilityArtifactPath` recognizes so they aren't rewritten as missing markdown pages). The website flow serves them over HTTP; the bundle flow omits them because an offline agent reaches everything it needs through `AGENTS.md` and relative `docs/*.md` links.

## How they complement each other

The flows are not mutually exclusive. A single product can publish **bundled offline docs** (`AGENTS.md` + `docs/*.md`) for consumers reading from `node_modules`, **and** a **hosted docs website** exposing `/llms.txt` and HTTP-discoverable markdown for URL-based agents. Same MDX source, two tailored delivery targets.
