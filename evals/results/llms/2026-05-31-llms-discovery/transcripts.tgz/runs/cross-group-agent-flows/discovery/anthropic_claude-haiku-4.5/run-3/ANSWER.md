# Cross-group Agent Flows: Hosted vs NPM Bundle

## Overview

Leadtype supports two complementary flows for agents to access documentation: a hosted website flow and an npm bundle flow. These flows allow the same generated markdown docs to be consumed by different agent types.

## Hosted Website Flow

**Starting Point:** `/llms.txt`

The hosted website flow is designed for HTTP agents (agents that make network requests to a documentation website). 

- **Entry file:** Agents start at `/llms.txt` at the site root
- **Navigation:** Agents follow markdown links from `/llms.txt` to explore the documentation
- **Related artifacts:** `/docs/llms.txt` (docs-scoped map), markdown mirrors under `/docs/*.md`
- **Additional supporting files:** `/llms-full.txt` (root full-context file containing all pages), sitemap files (`docs/sitemap.xml`, `docs/sitemap.md`), `robots.txt`, `agent-readability.json`, and search JSON files (`search-index.json`, `search-content.json`)

## NPM Bundle Flow

**Starting Point:** `AGENTS.md`

The npm bundle flow is designed for coding agents working inside installed npm packages (in node_modules). 

- **Entry file:** Agents start at `AGENTS.md` at the package root
- **Navigation:** Agents follow relative markdown links like `./docs/reference/cli.md`
- **Key advantage:** Works offline without network requests
- **Related artifacts:** Markdown files under `docs/*.md` with relative links

## Files Each Flow Starts From

| Flow Type | Starting File | Agent Type |
|-----------|---------------|-----------|
| **Hosted Website** | `/llms.txt` | HTTP agents (URL-based) |
| **NPM Bundle** | `AGENTS.md` (package root) | Coding agents (inside node_modules) |

## Website Artifacts Skipped by Bundle Mode

Bundle mode (`leadtype generate --bundle`) intentionally skips these website-only artifacts:

1. **llms.txt** - The product-level and docs-scoped maps (only needed for URL routing)
2. **llms-full.txt** - The root full-context file with all pages
3. **Search JSON files** - `search-index.json` and `search-content.json`
4. **Sitemap files** - `docs/sitemap.xml` and `docs/sitemap.md`
5. **robots.txt** - Web crawler directive file
6. **agent-readability.json** - Artifact metadata for web servers

These artifacts are skipped because they are specifically designed for HTTP-based discovery and web server routing, not for offline package consumption.

## How Groups Function in Both Flows

Groups organize content in both flows:
- In website mode: Groups organize `llms.txt` sections, navigation, search metadata
- In bundle mode: Groups organize the structure of `AGENTS.md` and `docs/*.md` files
- Groups are used for routing, not sharding across separate files

Note: The `product.agentGuidance` text, which is written for website URL routing, is intentionally ignored when generating `AGENTS.md` for bundle mode.

## Complementary Nature

The two flows complement each other, allowing a single package to:
- Publish bundled offline docs for inclusion in `node_modules` (bundle mode)
- Simultaneously publish a hosted docs website with `llms.txt` for URL-based HTTP agents (website mode)

This dual approach maximizes accessibility for different agent types and use cases.
