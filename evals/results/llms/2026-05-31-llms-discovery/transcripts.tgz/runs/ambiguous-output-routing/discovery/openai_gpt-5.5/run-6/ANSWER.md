# Agent-facing output APIs in Leadtype

Use Leadtype’s **LLM files** functionality for agent-facing outputs, not the search UI.

For hosted docs sites, generate and expose:

- `/llms.txt` — the product-level map that HTTP agents start from.
- `/docs/llms.txt` — the docs-scoped map.
- `/docs/*.md` — page-level markdown mirrors that agents should follow for normal context.
- `/llms-full.txt` — the root full-context fallback containing every generated markdown docs page.

The relevant APIs are:

- `generateLlmsTxt` — writes `/llms.txt` and `/docs/llms.txt` for hosted websites.
- `generateLLMFullContextFiles` — writes the single root `/llms-full.txt` all-docs fallback.
- `generateAgentsMd` — writes `AGENTS.md` for npm-bundled docs, where coding agents start when working inside installed packages.
- `isAgentReadabilityArtifactPath` — recognizes generated agent/static artifacts such as `llms.txt`, `llms-full.txt`, sitemap files, `robots.txt`, search JSON, and `agent-readability.json` so they are not treated as missing markdown pages.

For npm package docs, use bundle mode instead: `leadtype generate --bundle` writes `AGENTS.md` and relative `docs/*.md` links for offline agents inside `node_modules`.

## Page-level context vs. all-docs fallback

Prefer **page-level markdown context** by default. Agents should start at `/llms.txt` or `AGENTS.md`, use the routing/group hints, and follow the smallest relevant `/docs/*.md` page or pages. Groups are meant for routing and navigation, not for sharding full-context bundles.

Reach for the broad **`/llms-full.txt` all-docs fallback** only when page-level routing is insufficient, for example when:

- the agent cannot determine which page is relevant;
- the task spans many unrelated docs pages;
- a retrieval/routing step failed or lacks enough context;
- a model or workflow explicitly needs the entire generated docs corpus in one file.

Do not use the search UI as the primary agent output surface. Leadtype’s search artifacts are for static local search and can feed source-grounded answer generation, but the agent-facing discovery and context path is the LLM files plus markdown mirrors.