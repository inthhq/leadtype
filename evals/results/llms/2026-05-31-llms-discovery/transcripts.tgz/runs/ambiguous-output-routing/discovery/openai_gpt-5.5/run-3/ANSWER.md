# Agent-facing output APIs in Leadtype

Use Leadtype’s **LLM files** functionality, not the search UI, for agent-facing output.

## What to use

For hosted docs sites, use the LLM-file generation path:

- `generateLlmsTxt` writes the product-level `/llms.txt` and docs-scoped `/docs/llms.txt` maps. HTTP agents start at `/llms.txt` and follow the markdown links.
- Serve markdown mirrors under `/docs/*.md` for the actual page-level context.
- `generateLLMFullContextFiles` writes the root `/llms-full.txt` file containing every generated markdown docs page.

For npm packages, use the bundled-docs path:

- `generateAgentsMd` writes `AGENTS.md` for package-bundled docs.
- Coding agents inside `node_modules` start at `AGENTS.md` and follow relative `docs/*.md` links.

If you are using the CLI, `leadtype generate` produces these agent-readable artifacts. In website mode, the JSON output includes paths such as `llmsTxt`, `docsLlmsTxt`, `llmsFullTxt`, `agentReadabilityJson`, `searchIndex`, and `searchContent`.

## How this differs from search

Leadtype’s search functionality builds a static local search index over generated markdown. That is useful for lexical retrieval or for feeding source-grounded answer generation, but it is not the primary agent-facing output API. For agents, expose the LLM artifacts and markdown pages.

## Page-level context vs. all-docs fallback

Prefer **page-level context** by default:

1. Agents should start from `/llms.txt` or `AGENTS.md`.
2. They should follow the smallest relevant markdown page links.
3. Groups and descriptions should be treated as routing hints, not as separate full-context shards.

Reach for the broad all-docs fallback, `/llms-full.txt`, only when page-level routing is not enough—for example, when an agent cannot determine which specific pages are relevant, needs a complete corpus snapshot, or must answer a question that genuinely spans the whole docs set. `/llms-full.txt` is one root file containing all generated markdown pages; Leadtype does not publish per-group full-context files by default.
