# Agent-facing output APIs in Leadtype

## Which functionality to use

For **agent-facing output**, use the **LLM files** functionality (`docs/reference/llm.md`), *not* the **Search** functionality (`docs/reference/search.md`).

Search builds a static local search index (lexical BM25-style ranking) that powers the search UI and source-grounded answers. It is a query/retrieval surface, not the markdown-output API agents consume directly.

The agent-facing output APIs are the LLM-file generators:

- **`generateLlmsTxt`** — writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` map for hosted websites. This is the entry point HTTP agents follow (they start at `/llms.txt` and follow markdown links).
- **`generateLLMFullContextFiles`** — writes a single root `/llms-full.txt` containing **every** generated markdown docs page (the broad all-docs fallback).
- **`generateAgentsMd`** — writes `AGENTS.md` for npm-bundled docs. Coding agents inside installed packages start here and follow relative `docs/*.md` links. (It intentionally ignores `product.agentGuidance`, which is meant for website URL routing.)
- **`isAgentReadabilityArtifactPath`** — identifies artifact paths (llms.txt, llms-full.txt, sitemap files, robots.txt, search JSON, agent-readability.json) that should not be rewritten as missing markdown pages.

## Page-level context vs. the broad all-docs fallback

**Default: prefer page-level context.** Per the guidance in `llms.txt` and `how-it-works.md`, agents should follow the page-level markdown links (via `llms.txt` / `AGENTS.md`) and read the *smallest* page or pages that answer the task. This keeps context focused and avoids loading unnecessary material.

**Reach for the broad all-docs fallback (`llms-full.txt`)** when page-level context isn't sufficient — i.e., when:

- You can't determine which specific page(s) answer the task from the `llms.txt` routing map.
- The task spans many pages and needs the full corpus in one shot.
- You want a single root file with **every** generated markdown page rather than navigating link-by-link.

Note that groups organize `llms.txt` sections, navigation, search metadata, and `AGENTS.md`, and are used for **routing, not sharding** — they are *not* published as per-group full-context files by default. So the full-context fallback is the single root `llms-full.txt`, not a per-group bundle.

## Summary

- Use the **LLM file APIs** (`generateLlmsTxt`, `generateLLMFullContextFiles`, `generateAgentsMd`) for agent-facing output — not the search index/UI.
- **Default to page-level context** via `llms.txt`/`AGENTS.md` links, reading the smallest relevant pages.
- **Fall back to the broad all-docs `llms-full.txt`** only when page-level routing isn't enough or the task needs the entire corpus at once.
