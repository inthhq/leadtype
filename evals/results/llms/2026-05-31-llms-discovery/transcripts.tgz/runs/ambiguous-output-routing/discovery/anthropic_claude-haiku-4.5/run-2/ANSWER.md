# Agent-Facing Output APIs in Leadtype

## Overview

Leadtype provides different agent-facing output APIs depending on your deployment context:

### 1. **HTTP-Based Agents (Website Mode)**
For agents that access your documentation over HTTP, use the **website-mode APIs**:

- **`/llms.txt`** - The primary routing file for HTTP agents. Organized by document groups with descriptions and links
- **`/docs/llms.txt`** - A docs-scoped variant of the routing file
- **Individual `/docs/*.md` pages** - Markdown mirrors of your MDX pages that agents can follow via links
- **Supporting artifacts**: `robots.txt`, `sitemap.xml`, `sitemap.md`, `agent-readability.json`, search JSON files

**When to use:** When your docs site is publicly hosted and agents discover documentation through HTTP requests starting from `/llms.txt`.

### 2. **Coding Agents (Bundle Mode)**
For agents working inside installed npm packages, use the **bundle-mode APIs**:

- **`AGENTS.md`** - Entry point for coding agents working offline in node_modules
- **Relative `docs/*.md` links** - Documentation files linked relatively so they work without network requests
- **No full-context file** - Bundle mode intentionally skips `/llms-full.txt` and other website-only artifacts

**When to use:** When publishing npm packages and want agents to access bundled offline documentation without network requests.

---

## When to Use the All-Docs Fallback (`/llms-full.txt`)

Use the **`/llms-full.txt` fallback** when:

1. **Page-level context is insufficient** - An agent needs comprehensive documentation coverage beyond what individual pages provide
2. **Group navigation fails** - When a page's declared `group` is unknown or doesn't match your docs configuration
3. **Breadth over depth required** - The agent needs all documentation content flattened into one file rather than following linked pages

### Key Characteristics of `/llms-full.txt`:
- Contains **every generated markdown page** flattened into one file
- **Not split by group** - Groups still organize `llms.txt` sections, navigation, and search metadata, but the full-context file contains everything
- Website-mode only (not in bundle mode)
- Acts as a complete fallback when page-level routing is unavailable

**Note:** Groups drive routing and organization, but should be treated as routing hints rather than shards. Use page-level context and group-based navigation first; only fall back to the all-docs file when an agent cannot follow individual page links or needs exhaustive context.

---

## Summary

| Scenario | API | Use Case |
|----------|-----|----------|
| Public website with HTTP agents | `/llms.txt` + individual `/docs/*.md` pages | Start at `/llms.txt`, follow markdown links |
| Hosted site comprehensive fallback | `/llms-full.txt` | When page-level context insufficient or group unknown |
| npm package with offline access | `AGENTS.md` + relative `docs/*.md` | Agents in node_modules, no network required |

The two flows complement each other: a package can publish both bundled offline docs for `node_modules` (via `--bundle`) and a hosted website with `llms.txt` for URL-based agents (website mode).
