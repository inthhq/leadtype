# Agent-facing output APIs in Leadtype

Use Leadtype’s **LLM files** functionality, not the search UI, when you need agent-facing outputs.

The relevant APIs/artifacts are:

- `generateLlmsTxt` — writes the hosted website maps:
  - `/llms.txt`
  - `/docs/llms.txt`
- `generateLLMFullContextFiles` — writes the broad fallback:
  - `/llms-full.txt`
- `generateAgentsMd` — writes `AGENTS.md` for npm-bundled/package docs, with relative links into `docs/*.md`.
- `isAgentReadabilityArtifactPath` — identifies agent/readability artifacts such as `llms.txt`, `llms-full.txt`, sitemap files, robots.txt, search JSON, and `agent-readability.json` so they are not treated like missing markdown pages.

For hosted docs sites, generate website-mode artifacts and expose `/llms.txt` plus markdown mirrors under `/docs/*.md`. HTTP agents should start at `/llms.txt`, use the grouped routing hints, and follow the smallest relevant page-level markdown links.

For package/offline usage inside `node_modules`, use bundle mode instead: `leadtype generate --bundle`. That writes `AGENTS.md` and relative `docs/*.md` links for coding agents.

## Page-level context vs. `/llms-full.txt`

Prefer **page-level context by default**:

1. Start from `/llms.txt`.
2. Use group/page descriptions as routing hints.
3. Fetch only the markdown page or small set of pages needed for the task.

Reach for the broad all-docs fallback, `/llms-full.txt`, only when page-level routing is not enough, for example:

- the request is ambiguous and you cannot identify the right page from `/llms.txt`;
- the answer likely spans many unrelated docs pages;
- you need a whole-corpus fallback for an agent/model rather than a focused retrieval path;
- page-level context was tried and is insufficient.

Do not use groups as context shards. Groups organize navigation, `llms.txt` sections, search metadata, and `AGENTS.md`; Leadtype publishes one root `/llms-full.txt` containing all generated markdown pages, not per-group full-context files.
