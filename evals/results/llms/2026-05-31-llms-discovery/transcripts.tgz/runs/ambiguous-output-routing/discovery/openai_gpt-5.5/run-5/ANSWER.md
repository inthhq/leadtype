# Agent-facing output APIs in Leadtype

Use Leadtype’s **LLM/agent-readable artifact generation**, not the search UI, when you want output meant for agents.

## What to use

For hosted docs, use the LLM file generation path:

- `generateLlmsTxt` — writes the root `/llms.txt` and `/docs/llms.txt` maps. HTTP agents start at `/llms.txt` and follow the markdown links to the relevant page-level docs.
- Markdown mirrors under `/docs/*.md` — these are the normal page-level context targets for agents.
- `generateLLMFullContextFiles` — writes the root `/llms-full.txt` all-docs fallback.
- `isAgentReadabilityArtifactPath` — identifies agent/static artifacts such as `llms.txt`, `llms-full.txt`, sitemap files, robots.txt, search JSON, and `agent-readability.json` so they are not treated as missing markdown pages.

For package docs, use the bundled-docs path:

- `generateAgentsMd` or `leadtype generate --bundle` — writes `AGENTS.md` plus relative `docs/*.md` links for coding agents reading docs inside `node_modules` without network access.

If you are wiring a website, run `leadtype generate` in website mode and serve `/llms.txt`, `/docs/*.md`, `/llms-full.txt`, sitemap/robots artifacts, search JSON, and `agent-readability.json` as static outputs. For agent requests to docs pages, serve markdown when `Accept` asks for `text/markdown` or when a known AI user agent requests the page.

## How this differs from search

Leadtype’s search functionality builds a static local search index with lexical BM25-style ranking over titles, headings, body text, and code. That is useful for a search UI or for source-grounded answer generation, but it is not the primary agent-facing output API. For agents, prefer the generated markdown maps and files: `/llms.txt`, page-level `/docs/*.md`, `/llms-full.txt`, and `AGENTS.md` for bundled package docs.

## When to use `/llms-full.txt`

Default to **page-level context**. Agents should start from `/llms.txt` or `AGENTS.md`, follow the smallest relevant markdown links, and read only the page or pages needed for the task.

Reach for the broad `/llms-full.txt` fallback only when page-level routing is not enough, for example:

- the task is genuinely cross-cutting and may depend on many docs pages;
- the relevant page cannot be determined from `/llms.txt` routing hints;
- a page-level answer is incomplete or contradictory and needs corpus-wide context;
- an integration needs a single all-docs artifact rather than following links.

Do not treat groups as separate full-context shards. Groups organize navigation, `llms.txt` sections, search metadata, and `AGENTS.md`; the generated all-docs fallback is one root `/llms-full.txt` file containing every generated markdown docs page.