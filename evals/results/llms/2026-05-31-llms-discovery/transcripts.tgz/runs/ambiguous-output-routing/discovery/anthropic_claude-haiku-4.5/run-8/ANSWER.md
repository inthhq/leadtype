# Agent-Facing Output APIs in Leadtype

## Overview

Leadtype provides two main agent-facing output APIs, depending on your deployment context:

### 1. **For HTTP Agents (Website Mode): llms.txt**
- **Primary entry point**: `/llms.txt` at the site root
- **Scope**: Page-level context organized by group
- **Format**: Markdown sections grouped by the `group` field in frontmatter
- **When to use**: When agents can make HTTP requests to your hosted docs site
- **Key feature**: Groups provide routing hints and organize context by topic area

**Generated files in Website Mode:**
- `/llms.txt` - Docs-scoped grouped navigation
- `/docs/llms.txt` - Markdown mirrors 
- `/llms-full.txt` - **All-docs fallback** (see below)
- Markdown mirrors under `/docs/*.md`

### 2. **For Coding Agents (Bundle Mode): AGENTS.md**
- **Primary entry point**: `AGENTS.md` at the package root
- **Scope**: Page-level context with relative links (works offline in node_modules)
- **Format**: Grouped navigation using relative links like `./docs/reference/cli.md`
- **When to use**: When bundling docs in an npm package for offline use
- **Key feature**: Agents can read docs without network requests

## When to Reach for the Broad All-Docs Fallback

Use `/llms-full.txt` (the all-docs fallback) instead of page-level grouped context in these situations:

1. **Unknown or Multiple Groups**: When a page declares an unknown group, or when agents cannot identify which group section to start from
2. **Comprehensive Context Needed**: When broad context across the entire documentation is required
3. **Group Coverage Gaps**: When page-level grouping doesn't provide sufficient routing information
4. **Discovery Across Domains**: When agents need access to all generated markdown pages regardless of organization

**Key characteristics of llms-full.txt:**
- Contains every generated markdown docs page
- **Not split by group** - provides complete, unpartitioned context
- Groups still organize llms.txt sections, navigation, search metadata, and AGENTS.md
- Serves as the comprehensive fallback when page-level context is insufficient

## Quick Reference

| Use Case | Use This | Output Mode |
|----------|----------|-------------|
| HTTP agents on hosted site | `/llms.txt` | Website |
| HTTP agents need all docs | `/llms-full.txt` | Website |
| npm package docs | `AGENTS.md` | Bundle |
| Unknown routing group | `/llms-full.txt` | Website |

## Important Note on Configuration

The `group` field in page frontmatter drives:
- Sidebar position
- llms.txt section organization
- Search metadata
- AGENTS.md grouping

Declaring unknown groups will fail the build, so ensure all group values match slugs from your `docs.config.ts`.
