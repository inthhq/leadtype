# Agent-facing output APIs in Leadtype

Use Leadtype’s **LLM files / agent-readable artifacts**, not the search UI layer, when you want output for agents.

## What to use

- **Hosted docs / HTTP agents:** use `generateLlmsTxt` and website-mode output.
  - This writes the product-level `/llms.txt` and docs-scoped `/docs/llms.txt` maps.
  - Agents start at `/llms.txt`, then follow links to the generated markdown mirrors under `/docs/*.md`.
  - Serve markdown for agent requests, especially when `Accept: text/markdown` is present or a known AI user agent requests a docs page.

- **npm package / coding agents inside `node_modules`:** use bundle mode / `generateAgentsMd`.
  - `leadtype generate --bundle` writes `AGENTS.md` and relative `docs/*.md` files.
  - Coding agents start at `AGENTS.md` and follow relative links without needing the network.

- **All-docs fallback:** use `generateLLMFullContextFiles`.
  - This writes one root `/llms-full.txt` containing every generated markdown docs page.

The search reference is separate: Leadtype’s search index is a static BM25-style retrieval path over generated markdown. It can support source-grounded answer generation, but the primary agent-facing discovery/output surface is the LLM files and markdown mirrors.

## When to use page-level context vs. `/llms-full.txt`

Prefer **page-level context** by default:

1. Start from `/llms.txt` or `AGENTS.md`.
2. Use group descriptions and page descriptions as routing hints.
3. Read the smallest relevant generated markdown page or pages under `/docs/*.md`.

Reach for the broad **`/llms-full.txt` all-docs fallback** only when page-level routing is not enough, such as when:

- the agent cannot determine which page is relevant;
- the question is cross-cutting and spans many pages or groups;
- you need a whole-documentation audit, migration, or summary;
- page-level context is too fragmented or misses required background.

`/llms-full.txt` is intentionally broad and noisier: it contains all generated markdown pages and is not split by group. Use groups for routing, not for sharding full-context files.