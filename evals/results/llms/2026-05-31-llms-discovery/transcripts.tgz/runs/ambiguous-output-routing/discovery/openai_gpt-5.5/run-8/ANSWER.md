# Agent-facing output APIs in Leadtype

Use Leadtype’s **LLM/agent-readable artifact generation**, not the search UI.

For a hosted docs site, use the LLM files functionality:

- `generateLlmsTxt` — writes the product-level `/llms.txt` and docs-scoped `/docs/llms.txt` maps. HTTP agents start here and follow markdown links.
- `generateLLMFullContextFiles` — writes the root `/llms-full.txt` fallback containing every generated markdown docs page.
- Markdown mirrors under `/docs/*.md` — the page-level context agents should normally fetch after discovering links from `/llms.txt`.
- `isAgentReadabilityArtifactPath` — useful in site routing so artifacts such as `llms.txt`, `llms-full.txt`, sitemap files, robots.txt, search JSON, and `agent-readability.json` are treated as static agent artifacts instead of missing markdown pages.

For npm/package distribution, use bundle mode instead:

- `leadtype generate --bundle` or the corresponding bundle flow writes `AGENTS.md` plus `docs/*.md`.
- Coding agents inside `node_modules` start at `AGENTS.md` and follow relative links like `./docs/reference/cli.md` without needing the network.

Do **not** treat the search UI as the agent-facing API. Leadtype does build static search JSON with lexical BM25-style ranking, and that can feed source-grounded answer generation, but the agent-oriented entry points are `llms.txt`, `llms-full.txt`, `AGENTS.md`, and the markdown page mirrors.

## Page-level context vs. `/llms-full.txt`

Prefer **page-level context** by default:

1. Start from `/llms.txt` for hosted docs, or `AGENTS.md` for bundled package docs.
2. Follow the smallest relevant markdown links under `/docs/*.md`.
3. Read only the page or pages needed to answer the task.

Reach for the broad all-docs fallback, `/llms-full.txt`, only when page-level routing is not enough, for example:

- the request spans many parts of the documentation and no small set of pages is clearly sufficient;
- the agent cannot determine the right page from `/llms.txt` or the page links;
- you need a complete root-level snapshot of all generated markdown docs;
- a retrieval/routing step failed and you need a safe fallback.

`/llms-full.txt` is intentionally broad: it contains every generated markdown docs page in one root file. Groups still organize navigation, `llms.txt` sections, search metadata, and `AGENTS.md`, but Leadtype does not publish per-group full-context files by default. Use groups for routing hints, not as shards for full-context retrieval.
