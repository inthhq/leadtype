# Agent-facing output APIs in Leadtype

Use Leadtype’s **LLM/agent-readable output** functionality, not the search UI, when you want artifacts for agents to consume.

## What to use

For a hosted docs site, generate and serve the website-mode agent artifacts:

- `generateLlmsTxt` / `/llms.txt` and `/docs/llms.txt` — the entry-point maps that agents use to discover the right markdown docs page.
- Markdown mirrors under `/docs/*.md` — the page-level context agents should normally read after following links from `llms.txt`.
- `generateLLMFullContextFiles` / `/llms-full.txt` — a root, full-context fallback containing every generated markdown docs page.
- `agent-readability.json`, sitemap files, and `robots.txt` as static supporting artifacts.

For an npm package, use bundle mode instead:

- `leadtype generate --bundle`
- `generateAgentsMd` / `AGENTS.md`
- relative `docs/*.md` links that work inside `node_modules` without a network request.

## How agents should consume it

Prefer **page-level context first**:

1. Start at `/llms.txt` for hosted docs, or `AGENTS.md` for bundled package docs.
2. Follow the relevant markdown link, such as `/docs/reference/cli.md`.
3. Read the smallest page or set of pages that answers the task.

Use groups for routing and organization, not for sharding full context. Group descriptions and page descriptions should help agents choose the right page.

## When to use the broad all-docs fallback

Reach for `/llms-full.txt` only as a fallback when page-level context is not enough, for example when:

- the agent cannot confidently choose the right page from `/llms.txt`,
- the question spans many unrelated docs pages,
- the selected page-level markdown does not answer the task,
- or you need a single whole-corpus context file for a model/tool that cannot follow links.

`/llms-full.txt` is intentionally broad: it contains all generated markdown docs pages and is not split per group. For normal agent workflows, `llms.txt` plus specific `/docs/*.md` pages should be the primary path.