# Agent-facing output APIs in Leadtype

## Short answer

Reach for Leadtype's **LLM files** functionality (the agent-readable output
APIs), **not** the search functionality. Within the LLM files:

- Use the **per-page markdown** + **`llms.txt` map** as your default,
  page-level context.
- Reach for **`llms-full.txt`** (the broad all-docs fallback) only when
  page-level context isn't enough.

Search (`/docs/reference/search.md`) is the lexical/semantic retrieval layer
and search UI — it's a separate concern from emitting agent-readable output.

## Which part to use

The agent-facing output APIs live in **LLM files**
(`/docs/reference/llm.md`). The relevant generators are:

| API | What it emits | Audience |
| --- | --- | --- |
| `generateLlmsTxt` | Product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` map | HTTP agents that start at `/llms.txt` and follow markdown links |
| `generateLLMFullContextFiles` | A single root `/llms-full.txt` containing **every** generated markdown docs page | Broad all-docs fallback |
| `generateAgentsMd` | `AGENTS.md` for npm-bundled docs (ignores `product.agentGuidance`, which is for website URL routing) | Coding agents inside installed npm packages, following relative `docs/*.md` links |
| `isAgentReadabilityArtifactPath` | Identifies artifact paths (llms.txt, llms-full.txt, sitemap, robots.txt, search JSON, agent-readability.json) so they aren't rewritten as missing markdown pages | Build pipeline guard |

These complement two flows (per `how-it-works.md`):
- **HTTP agents** start at `/llms.txt` and follow page-level markdown links.
- **Coding agents** in `node_modules` start at `AGENTS.md` and follow relative
  `docs/*.md` links.

## Page-level context vs. the broad all-docs fallback

**Default to page-level context.** Per `llms.txt`'s own guidance: *"Use the
page-level markdown links below. Read the smallest page or pages that answer
the task."* So:

- Start from `llms.txt` (or `AGENTS.md` for bundled packages) and fetch only the
  specific markdown page(s) that answer the task. This keeps context focused and
  small.
- Groups are for **routing** (navigation hints), not for sharding into
  per-group full-context files — by default groups are **not** published as
  per-group full-context files.

**Reach for the broad all-docs fallback (`llms-full.txt`) when:**

- You don't know which specific page(s) you need, or a task spans many pages and
  page-by-page link following would be too lossy or inefficient.
- You want the entire corpus in one fetch — `generateLLMFullContextFiles` emits
  one root `/llms-full.txt` containing every generated markdown page.

In other words: page-level markdown (via `llms.txt`/`AGENTS.md`) is the
precise, low-context default; `llms-full.txt` is the whole-corpus fallback for
when targeted page selection isn't practical.

## What *not* to use here

Don't use Search for agent output. The search functionality
(`/docs/reference/search.md`) provides a static, edge-safe BM25-style lexical
index (optionally feeding source-grounded answers, with embeddings only added
when vocabulary mismatches or corpus size demand it). That's a retrieval/UI
concern — distinct from the agent-facing **output** APIs above.
