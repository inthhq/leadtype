# Agent-facing output APIs in Leadtype

## Which functionality to use

For **agent-facing output** (as opposed to the search UI), use the **LLM file generation APIs** documented in `/docs/reference/llm.md`. These produce the artifacts that agents consume:

- **`generateLlmsTxt`** — writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` map for hosted websites. This is the entry point/map that HTTP agents start from and follow markdown links out of.
- **`generateLLMFullContextFiles`** — writes a single root `/llms-full.txt` file containing **every** generated markdown docs page (the broad, all-docs bundle).
- **`generateAgentsMd`** — writes `AGENTS.md` for npm-bundled docs (the entry point for coding agents working inside installed packages, following relative `docs/*.md` links). It deliberately ignores `product.agentGuidance`, since that text is meant for website URL routing.
- **`isAgentReadabilityArtifactPath`** — identifies artifact paths (llms.txt, llms-full.txt, sitemap files, robots.txt, search JSON, agent-readability.json) that should not be rewritten as missing markdown pages.

These are distinct from **Search** (`/docs/reference/search.md`), which is the static, BM25-style lexical search index / query path (the "search UI" / runtime retrieval path). Search can *feed* source-grounded answers, but it is not the output-bundle API.

## Default behavior: page-level context

The intended default is **page-level (per-page) markdown context**. As `llms.txt` itself states: "Use the page-level markdown links below. Read the smallest page or pages that answer the task." Agents start at `/llms.txt` (HTTP) or `AGENTS.md` (npm package) and follow links to the **smallest page(s)** that answer the task. Groups are used for routing/navigation hints, **not** for sharding into per-group full-context files.

## When to reach for the broad all-docs fallback

Reach for the **`/llms-full.txt`** root file (produced by `generateLLMFullContextFiles`) only as a **fallback** — when page-level context is insufficient. It concatenates every generated markdown page into one bundle, so it is the right choice when:

- The task spans many pages or you cannot determine which individual page(s) answer it from the `llms.txt` map.
- You need the full corpus in one shot rather than navigating page-by-page links.
- Page-level retrieval/links don't surface the needed content.

Note that full-context output exists **only at the root level** (`/llms-full.txt`). Per-group full-context files are **not** published by default; groups organize `llms.txt` sections, navigation, search metadata, and `AGENTS.md`, but they are not emitted as separate full-context bundles.

## Summary

| Need | Use |
|------|-----|
| Agent entry map (web) | `generateLlmsTxt` → `/llms.txt`, `/docs/llms.txt` |
| Agent entry (npm package) | `generateAgentsMd` → `AGENTS.md` |
| Targeted answer (default) | Page-level markdown links from the map — read the smallest page(s) |
| Broad fallback (whole corpus) | `generateLLMFullContextFiles` → `/llms-full.txt` |
| Artifact-path detection | `isAgentReadabilityArtifactPath` |
| Search UI / retrieval (not output API) | Search index (`/docs/reference/search.md`) |
