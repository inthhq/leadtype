# Agent-facing output APIs in Leadtype

## Which functionality to use

For agent-facing output, use Leadtype's **LLM file generation APIs** (documented in
`/docs/reference/llm.md`), **not** the Search functionality. Search builds a
static, lexical (BM25-style) index that feeds a query UI / source-grounded
answer generation. The LLM file APIs, by contrast, produce the artifacts agents
consume directly:

- **`generateLlmsTxt`** — writes the product-level `/llms.txt` and the
  docs-scoped `/docs/llms.txt` map for hosted websites. This is the entry point
  HTTP agents start from before following the page-level markdown links.
- **`generateLLMFullContextFiles`** — writes one root `/llms-full.txt` file
  containing **every** generated markdown docs page (the broad all-docs
  fallback).
- **`generateAgentsMd`** — writes `AGENTS.md` for npm-bundled docs (the entry
  point for coding agents working inside installed packages). It intentionally
  ignores `product.agentGuidance`, which is written for website URL routing.
- **`isAgentReadabilityArtifactPath`** — identifies artifact paths (llms.txt,
  llms-full.txt, sitemap files, robots.txt, search JSON, agent-readability.json)
  that should not be rewritten as missing markdown pages.

So the agent flow is: HTTP agents start at `/llms.txt` and follow markdown
links; coding agents in npm packages start at `AGENTS.md` and follow relative
`docs/*.md` links.

## Page-level context vs. the broad all-docs fallback

**Default to page-level context.** Per `llms.txt`'s own guidance ("Read the
smallest page or pages that answer the task"), the normal path is to follow the
page-level markdown links from `llms.txt` / `AGENTS.md` and read only the
smallest page(s) that answer the task. The group tree is for **routing**, not
sharding — group descriptions are routing hints that point you at the right
page.

**Reach for the broad all-docs fallback (`llms-full.txt`, produced by
`generateLLMFullContextFiles`) only when page-level context is insufficient**,
i.e. when:

- the task spans many pages and you genuinely need the whole corpus in one
  shot, or
- you can't determine which page(s) are relevant from the `llms.txt`/group
  routing hints and need full context to find the answer.

Note that `llms-full.txt` is a **single root file containing all docs**; groups
are not published as per-group full-context files by default. Because it pulls
in every page, prefer the targeted page-level links first and treat
`llms-full.txt` as the fallback for the cases above.
