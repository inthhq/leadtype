# Agent-facing output APIs in Leadtype

Use Leadtype’s **LLM files / agent-readable artifact generation** functionality, not the search UI, when you want outputs for agents.

The relevant APIs are in the LLM files area:

- `generateLlmsTxt` — writes the hosted-site maps:
  - `/llms.txt`
  - `/docs/llms.txt`
- `generateLLMFullContextFiles` — writes the root all-docs fallback:
  - `/llms-full.txt`
- `generateAgentsMd` — writes `AGENTS.md` for npm-bundled package docs.
- `isAgentReadabilityArtifactPath` — recognizes agent/static artifacts such as `llms.txt`, `llms-full.txt`, sitemap files, `robots.txt`, search JSON, and `agent-readability.json` so they are not treated like missing markdown pages.

For a hosted docs site, use **website mode**: expose `/llms.txt` and markdown mirrors under `/docs/*.md`. HTTP agents start at `/llms.txt` and follow links to the smallest relevant page-level markdown files.

For package/offline coding-agent use, use **bundle mode**: `leadtype generate --bundle` writes `AGENTS.md` plus `docs/*.md` with relative links that work inside `node_modules`.

## Page-level context vs. the broad fallback

Prefer **page-level context first**:

1. Start from `/llms.txt` or `/docs/llms.txt`.
2. Use group descriptions and page descriptions as routing hints.
3. Fetch only the relevant `/docs/*.md` pages.

Reach for the broad all-docs fallback, `/llms-full.txt`, only when page-level routing is not enough, for example:

- the agent cannot confidently identify the right page,
- the question spans many unrelated pages,
- the answer depends on cross-doc context,
- page-level context produced an incomplete answer,
- or you need a single file containing every generated markdown docs page.

Do not use groups as hard shards. Groups organize navigation, `llms.txt` sections, search metadata, and `AGENTS.md` grouping, but the full-context fallback is one root `/llms-full.txt` file containing all generated markdown pages, not one full-context file per group.

The search index is separate: Leadtype can build static search JSON and BM25-style search output, but the agent-facing documentation outputs are the LLM files, markdown mirrors, and bundled `AGENTS.md` flow.