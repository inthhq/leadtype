# Agent-facing output APIs in Leadtype

## Which functionality to use

For agent-facing output, use Leadtype's **LLM files** APIs (documented at `/docs/reference/llm.md`), **not** the Search functionality (`/docs/reference/search.md`). The Search index powers a query/search UI and source-grounded answer generation; it is a different surface than the agent-readable output artifacts.

The agent-facing output APIs are:

- **`generateLlmsTxt`** — writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` map for hosted websites. This is the entry point HTTP agents use: they start at `/llms.txt` and follow the page-level markdown links.
- **`generateLLMFullContextFiles`** — writes a single root `/llms-full.txt` file containing **every** generated markdown docs page (the broad all-docs fallback). Groups organize `llms.txt` sections, navigation, search metadata, and `AGENTS.md`, but are not published as per-group full-context files by default.
- **`generateAgentsMd`** — writes `AGENTS.md` for npm-bundled docs (the entry point coding agents use inside installed packages, following relative `docs/*.md` links). It intentionally ignores `product.agentGuidance`, since that text is written for website URL routing.
- **`isAgentReadabilityArtifactPath`** — identifies artifact paths that should not be rewritten as missing markdown pages (covers `llms.txt`, `llms-full.txt`, sitemap files, `robots.txt`, search JSON, and `agent-readability.json`).

## Page-level context vs. the broad all-docs fallback

Prefer **page-level context** by default:

- Start from `/llms.txt` (HTTP agents) or `AGENTS.md` (coding agents in npm packages) and follow the per-page markdown links.
- Read the **smallest page or pages** that answer the task. The `llms.txt` map and group descriptions exist as routing hints to send you to the right page.

Reach for the **broad all-docs fallback** (`/llms-full.txt` via `generateLLMFullContextFiles`) only when page-level routing is insufficient — for example, when:

- The task spans many pages and you genuinely need the entire corpus in one bundle.
- You cannot resolve which page answers the task from the `llms.txt` map / group routing hints.
- You need a single self-contained context blob (e.g., one-shot, offline, or no-fetch-loop scenarios) rather than following links page by page.

In short: route to the narrowest page(s) first via the `llms.txt`/`AGENTS.md` map; fall back to the full `llms-full.txt` bundle only when whole-corpus context is actually required. Use the Search APIs only for query-driven search/answer use cases, not as the agent output surface.
