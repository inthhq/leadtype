# Agent-facing output APIs in Leadtype

## Which functionality to use

For agent-facing output (as opposed to the search UI), reach for Leadtype's **LLM file APIs** documented in `/docs/reference/llm.md`. These generate the artifacts that agents actually consume:

- **`generateLlmsTxt`** — writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` map for hosted websites. This is the entry point for HTTP/URL-based agents: they start at `/llms.txt` and follow the page-level markdown links.
- **`generateLLMFullContextFiles`** — writes a single root `/llms-full.txt` file containing **every** generated markdown docs page concatenated together. This is the broad, all-docs fallback.
- **`generateAgentsMd`** — writes `AGENTS.md` for npm-bundled (offline) docs. Coding agents inside installed packages start at `AGENTS.md` and follow relative `docs/*.md` links. Note it intentionally ignores `product.agentGuidance`, which is written for website URL routing.
- **`isAgentReadabilityArtifactPath`** — helper that identifies artifact paths (`llms.txt`, `llms-full.txt`, sitemap files, `robots.txt`, search JSON, `agent-readability.json`) so they aren't rewritten as missing markdown pages.

These are distinct from **Search** (`/docs/reference/search.md`), which is the static BM25 search index / query UI path — not the agent output API you want here.

## Page-level context vs. the broad all-docs fallback

The recommended default is **page-level context**:

- `llms.txt` is a *map* of page-level markdown links. The guidance is to read the **smallest page or pages that answer the task** rather than ingesting everything. Groups exist for routing/navigation hints, not for sharding content.
- This keeps context focused and avoids loading unrelated docs.

Reach for the **broad all-docs fallback** — `/llms-full.txt` produced by `generateLLMFullContextFiles` — only when page-level context is insufficient, for example:

- The task spans many pages or you don't know which page(s) are relevant.
- You want the entire corpus in one shot as a single full-context file.
- You need a complete fallback rather than navigating individual links.

Note that full-context output is published as **one root `llms-full.txt`**, not as per-group full-context files by default; groups only organize `llms.txt` sections, navigation, search metadata, and `AGENTS.md`.

## Quick decision guide

| Situation | Use |
|---|---|
| Hosted/URL agent, targeted task | `generateLlmsTxt` → follow page-level `.md` links (read the smallest page) |
| Offline agent inside an npm package | `generateAgentsMd` → `AGENTS.md` + relative `docs/*.md` |
| Task spans the whole corpus / unknown location / need a complete fallback | `generateLLMFullContextFiles` → `/llms-full.txt` |
| Keyword/semantic lookup UI | Search index (not the agent output API) |
