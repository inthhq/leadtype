# Agent-facing output APIs in Leadtype

## Which functionality to use

For **agent-facing output**, use the **LLM files** functionality (documented at
`/docs/reference/llm.md`) — not the **Search** functionality
(`/docs/reference/search.md`).

Search builds a static, edge-safe local index over generated markdown for
*query/answer retrieval* (BM25-style lexical ranking, optionally feeding
source-grounded answer generation). It's the search UI/runtime path — that's
exactly what you said you do *not* want.

The agent-facing output APIs are the `generate*` LLM file functions:

| API | What it produces | Who consumes it |
|-----|------------------|-----------------|
| `generateLlmsTxt` | The product-level `/llms.txt` **and** the docs-scoped `/docs/llms.txt` link map for hosted websites | HTTP agents that start at `/llms.txt` and follow markdown links |
| `generateLLMFullContextFiles` | One root `/llms-full.txt` containing **every** generated markdown docs page concatenated together | Agents that need the whole corpus as a single context blob |
| `generateAgentsMd` | `AGENTS.md` for npm-bundled docs (it deliberately ignores `product.agentGuidance`, since that text is for website URL routing) | Coding agents working inside installed npm packages, following relative `docs/*.md` links |
| `isAgentReadabilityArtifactPath` | Helper that flags artifact paths (`llms.txt`, `llms-full.txt`, sitemap files, `robots.txt`, search JSON, `agent-readability.json`) so they aren't rewritten as missing markdown pages | Build pipeline plumbing |

## Page-level context vs. the broad all-docs fallback

These two reflect the two complementary agent flows described in "How it works":

- **Prefer page-level context (the default).** `llms.txt` (via
  `generateLlmsTxt`) gives a curated map of links; the agent reads the
  *smallest page or pages* that answer the task. This is the recommended path
  for both HTTP agents (start at `/llms.txt`, follow markdown links) and
  package-bundled coding agents (start at `AGENTS.md`, follow relative
  `docs/*.md` links). It keeps the context window focused and relevant.

- **Reach for the broad all-docs fallback (`generateLLMFullContextFiles` →
  `/llms-full.txt`) only when page-level navigation isn't enough**, i.e. when
  the agent genuinely needs the entire docs corpus in one shot rather than a
  targeted page. It is a single root file containing every page. Note that
  groups are used only to organize `llms.txt` sections, navigation, search
  metadata, and `AGENTS.md` — they are **not** published as per-group
  full-context files by default, so `/llms-full.txt` is an all-or-nothing,
  whole-corpus dump.

### Rule of thumb
Default to `llms.txt` + page-level markdown links for normal, scoped tasks.
Fall back to `llms-full.txt` only when you deliberately want the complete
corpus as one context blob (e.g., broad cross-cutting questions, or an agent
that can't navigate link-by-link). Use Search/embeddings only for the query
UI / source-grounded answer path, not as your agent output API.
