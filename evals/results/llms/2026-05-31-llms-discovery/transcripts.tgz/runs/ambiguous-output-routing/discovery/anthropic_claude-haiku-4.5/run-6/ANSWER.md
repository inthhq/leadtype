# Leadtype Agent-Facing Output APIs

## Overview

Leadtype provides two complementary agent-facing output formats designed for different integration contexts:

1. **HTTP/URL-based agents** (hosted docs sites)
2. **Coding agents** (installed npm packages)

## Agent-Facing Output APIs

### For HTTP/URL-Based Agents (Websites)

Use the **`/llms.txt`** format with hierarchical scoping:

- **`/llms.txt`** (root level) - The entry point for HTTP agents. Contains sections organized by groups from your docs configuration. Agents start here and follow markdown links.
- **`/docs/llms.txt`** (scoped) - Docs-only routing map, also organized by groups
- **`/llms-full.txt`** (fallback) - Complete all-docs context file containing every generated markdown page

### For Coding Agents (npm Packages)

Use **`AGENTS.md`** which:
- Is written specifically for npm-bundled docs
- Uses relative links (docs/*.md) that work inside node_modules
- Ignores product.agentGuidance (which targets website URL routing)
- Works alongside bundled docs/*.md files when run with `--bundle` flag

## When to Use Page-Level Context vs. All-Docs Fallback

### Use Page-Level Context (llms.txt sections by group)

**When:**
- Agents need **focused, scoped information** within a specific documentation area
- Your groups represent distinct feature areas, modules, or product sections
- You want to minimize context and improve relevance
- The agent can discover related pages through markdown links

**How it works:**
- The `group` frontmatter field organizes pages into llms.txt sections
- Pages can belong to multiple groups: `group: [a, b]`
- Each section provides navigation hints and describes its scope
- Agents follow markdown links to discover related content

### Use All-Docs Fallback (`/llms-full.txt`)

**When:**
- An agent needs **comprehensive coverage** of all documentation
- A page declares an unknown group and falls back to the root context
- You're building general-purpose agent assistance that spans multiple feature areas
- Cross-cutting concerns require seeing the full documentation scope
- The agent performs broad retrieval or relationship discovery across the entire docs

**Key characteristics:**
- Contains every generated markdown docs page in one file
- Groups still organize the file with sections, navigation, and search metadata
- Not split by individual groups—a catch-all for comprehensive context
- Automatically used as fallback for pages with unknown groups

## Implementation

When building with Leadtype:

```bash
# Website mode (generates llms.txt with grouping + llms-full.txt fallback)
leadtype generate

# Package mode (generates AGENTS.md with relative links)
leadtype generate --bundle
```

The JSON output from `--json` flag specifies all generated artifacts:
```
{
  "llmsFullTxt": "/llms-full.txt",
  "docsLlmsTxt": "/docs/llms.txt",
  "llmsTxt": "/llms.txt",
  "agentReadabilityJson": "/docs/agent-readability.json",
  ...
}
```

## Best Practices

1. **Define clear groups** in docs.config.ts that represent your product's logical areas
2. **Use group descriptions as routing hints**, not marketing copy
3. **Always declare group** in frontmatter—unknown groups trigger fallback to /llms-full.txt
4. **Structure markdown links** to guide agent discovery within focused contexts
5. **Choose between llms.txt (websites) and AGENTS.md (packages)** based on deployment model
