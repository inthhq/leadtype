# Agent-Facing Output APIs in Leadtype

## Overview

Leadtype generates agent-readable output artifacts through two complementary deployment models:

1. **HTTP-based agents** (web requests)
2. **Code-based agents** (npm packages)

The agent-facing APIs are produced by the LLM generation functions and deployed through different channels depending on your use case.

## Agent-Facing Output APIs

### For HTTP Agents (Website/Hosted Deployment)

When you need agents to discover and follow markdown links over HTTP, use the **website mode** output APIs:

#### Primary Routing Entry Point
- **`/llms.txt`** - The product-level navigation map that HTTP agents start at. It provides:
  - Section-organized group structure
  - Page-level routing hints (descriptions)
  - Markdown links that agents follow to read specific pages

#### Page-Level Context (Recommended)
- **Individual markdown pages** under `/docs/*.md` - Use these for agent reading. The llms.txt structure guides agents to the smallest pages that answer their specific questions, which is the preferred approach.
- **`/docs/llms.txt`** - A docs-scoped variant for additional granular navigation

#### Full Context Fallback
- **`/llms-full.txt`** - The broad all-docs fallback containing every generated markdown page flattened into one file. This is useful for agents needing comprehensive context when page-level routing isn't sufficient.

#### Supporting Artifacts
- `/docs/sitemap.xml` and `/docs/sitemap.md` - Discovery and routing
- `/robots.txt` - Crawler guidance
- `/docs/agent-readability.json` - Agent capability metadata
- `/docs/search-index.json` and `/docs/search-content.json` - Static search indexes for semantic discovery

### For Code-Based Agents (npm Package Bundling)

When you need agents working inside installed npm packages to access docs offline:

#### Primary Routing Entry Point
- **`AGENTS.md`** - Located at the package root, this is where coding agents start. It organizes documentation with:
  - Group-based structure
  - Relative links like `./docs/reference/cli.md` that work inside `node_modules`
  - No dependencies on network requests

#### Page-Level Context
- **`docs/*.md` files** - Markdown documents bundled with the package, using relative links for offline navigation

## When to Use Page-Level Context vs. All-Docs Fallback

### Use Page-Level Context (Recommended)
- **For targeted queries**: When the agent has a specific question or task (e.g., "How do I use the CLI?" → `/docs/reference/cli.md`)
- **For better performance**: Smaller, focused pages load faster and reduce context window usage
- **As the primary pattern**: The llms.txt/AGENTS.md structures guide agents to the smallest pages that answer questions
- **For HTTP agents**: Follow the markdown links in `/llms.txt` to specific `/docs/*.md` pages
- **For bundled agents**: Follow relative links in `AGENTS.md` to specific `docs/*.md` files

### Use All-Docs Fallback
- **When context is needed broadly**: When the agent needs comprehensive product knowledge to understand relationships across multiple doc sections
- **For exploratory tasks**: When the agent is learning the overall structure and architecture
- **For complex queries spanning multiple topics**: When answering the question requires information from several different pages
- **As a fallback only**: Reach for `/llms-full.txt` only when page-level routing doesn't provide sufficient context
- **For one-shot requests**: When you have only one opportunity to provide context and broad coverage is critical

## The Dual Flow Model

The two flows complement each other:

```
Website/Hosted Agents:
  /llms.txt → /docs/*.md (page-level) → /llms-full.txt (fallback)

Code-Based Agents:
  AGENTS.md → docs/*.md (relative links) → (no fallback needed)
```

A package can publish both: bundled offline docs for `node_modules` (AGENTS.md + docs/*.md) AND a hosted docs website with `/llms.txt` for URL-based agents.

## Related APIs

### Generation Functions
- **`generateLlmsTxt()`** - Creates `/llms.txt` and `/docs/llms.txt`
- **`generateLLMFullContextFiles()`** - Creates `/llms-full.txt` with all markdown pages
- **`generateAgentsMd()`** - Creates `AGENTS.md` for npm-bundled docs

### Deployment Modes
- **Website mode** (default): `leadtype generate`
  - Outputs all HTTP-accessible artifacts
  - Agents start at `/llms.txt` and follow links
  
- **Bundle mode**: `leadtype generate --bundle`
  - Outputs `AGENTS.md` and relative-linked docs
  - Agents start at `AGENTS.md` in installed packages

## Best Practices

1. **Organize with groups**: Use group-based structure in frontmatter to organize both llms.txt sections and AGENTS.md
2. **Write routing descriptions**: Page descriptions become routing hints in llms.txt—make them clear and actionable
3. **Prefer specific pages**: Route agents to the smallest page that answers their question (the page-level context model)
4. **Serve markdown appropriately**: When agents request docs pages, serve markdown when they ask for `Accept: text/markdown` or identify as an AI user agent
5. **Use search for discovery**: Complement page routing with the static search index for agent-driven semantic discovery
