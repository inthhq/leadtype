# Agent-facing output APIs in Leadtype

## Which functionality to use

For **agent-facing output**, use Leadtype's **LLM file generation APIs** (documented in `/docs/reference/llm.md`), *not* the Search functionality. Search (`/docs/reference/search.md`) is the lexical/BM25 query-and-retrieval path that powers the search UI and source-grounded answers — it is a different concern from emitting agent-readable output.

The LLM-file APIs are:

- **`generateLlmsTxt`** — writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` link maps for the hosted website. These give agents a curated index of page-level markdown links to follow.
- **`generateLLMFullContextFiles`** — writes the single root `/llms-full.txt` file that concatenates *every* generated markdown docs page into one broad, all-docs bundle.
- **`generateAgentsMd`** — writes `AGENTS.md` for npm-bundled (offline) docs. It deliberately ignores `product.agentGuidance`, since that guidance text is meant for website URL routing rather than package bundles.
- **`isAgentReadabilityArtifactPath`** — identifies artifact paths (`llms.txt`, `llms-full.txt`, sitemap files, `robots.txt`, search JSON, `agent-readability.json`) so they aren't mistakenly rewritten as missing markdown pages.

## Page-level context vs. the broad all-docs fallback

Leadtype's guidance is to **prefer page-level context by default**: an agent should start at the `llms.txt`/`/docs/llms.txt` map (or `AGENTS.md` for npm packages), follow the page-level markdown links, and read the *smallest* page or pages that answer the task. This keeps the working context focused and cheap.

**Reach for the broad all-docs fallback (`/llms-full.txt`, produced by `generateLLMFullContextFiles`) only when page-level context is not enough**, for example when:

- you can't tell which individual page(s) hold the answer from the `llms.txt` link map, or the answer spans many pages, and
- you want the entire corpus in one file as a single full-context dump rather than navigating page by page.

Note that this full-context fallback is intentionally a **single root file**. Groups in Leadtype are used to organize `llms.txt` sections, navigation, search metadata, and `AGENTS.md` — they are used for **routing, not sharding**, and are *not* published as per-group full-context files by default. So the choice is essentially: page-level markdown links for targeted work, and the one root `llms-full.txt` as the broad fallback.

## Quick summary

| Need | Use |
|------|-----|
| Curated index / routing for agents | `generateLlmsTxt` → `/llms.txt`, `/docs/llms.txt` |
| Targeted, focused context (default) | Follow page-level `*.md` links from `llms.txt` |
| Broad, whole-corpus fallback | `generateLLMFullContextFiles` → `/llms-full.txt` |
| Offline docs in npm packages | `generateAgentsMd` → `AGENTS.md` |
| Search / query + source-grounded answers (the search UI) | Search index APIs — *not* the agent output path |
