# Agent-Facing Output APIs in Leadtype

## Overview

Leadtype provides two distinct agent-facing output APIs designed for different deployment scenarios:

1. **HTTP-based agents** - Use `/llms.txt` for website deployments
2. **Coding agents in npm packages** - Use `AGENTS.md` for bundled offline docs

Both APIs are designed specifically for agent consumption, not the search UI.

## Which API to Use

### Use `/llms.txt` (and `/docs/llms.txt`) When:
- Your docs are hosted on a website with HTTP access
- Agents will make HTTP requests to fetch markdown pages
- You're in **website mode** (the default)
- Generated via `generateLlmsTxt()` function

**Website mode artifacts include:**
- `/llms.txt` - product-level navigation map
- `/docs/llms.txt` - docs-scoped navigation map
- Markdown mirrors under `/docs/*.md`
- Page-level context organized by groups

### Use `AGENTS.md` When:
- Publishing an npm package for distribution
- Agents will read docs from inside `node_modules` offline
- You're in **bundle mode** (`leadtype generate --bundle`)
- Generated via `generateAgentsMd()` function

**Bundle mode artifacts include:**
- `AGENTS.md` at the package root with relative links
- `docs/*.md` files beneath it
- Relative links like `./docs/reference/cli.md` that work inside node_modules

## The All-Docs Fallback

### When to Use `/llms-full.txt`

Use the **broad all-docs fallback** (`/llms-full.txt`) instead of page-level context when:

- An agent has **exhausted page-level routing** through `/llms.txt` and individual markdown links
- The agent needs **complete docs coverage** without following multiple page links
- **Groups cannot provide sufficient organization** for the agent's navigation
- You want a **single-file full-context retrieval** as a fallback strategy

**Important characteristics:**
- Contains **every generated markdown docs page flattened into one file**
- Groups still organize the content's internal sections and navigation metadata
- NOT published as per-group full-context files (only as one root file)
- Available only in website mode (skipped in bundle mode)

### When NOT to Use All-Docs

Prefer **page-level context** (from `/llms.txt` links) when:
- The agent is following structured navigation through groups
- Answering a task that matches a specific documentation page
- Working within token/context size constraints
- The docs corpus is large and can be efficiently navigated

## API Comparison

| Aspect | `/llms.txt` + Pages | `AGENTS.md` | `/llms-full.txt` |
|--------|------------------|-----------|-----------------|
| **Deployment** | Website (HTTP) | npm package | Website fallback |
| **Agent Type** | HTTP agents | Coding agents | HTTP agents |
| **Link Format** | Absolute URLs | Relative paths | Single file |
| **Use Case** | Primary navigation | Offline bundled docs | Complete context fallback |
| **Mode** | Website | Bundle | Website |

## Implementation Guidance

1. **Default approach**: Use page-level markdown links from `/llms.txt` and follow navigation through groups
2. **Fallback strategy**: When page-level context is insufficient, reach for `/llms-full.txt`
3. **Bundle distribution**: For npm packages, ensure agents start at `AGENTS.md` with relative doc links
4. **Group semantics**: Use groups for routing hints, not as sharding boundaries—groups organize llms.txt sections, navigation, search metadata, and AGENTS.md

## Summary

- **Choose `/llms.txt`** as your primary agent-facing API for website deployments
- **Choose `AGENTS.md`** for npm package bundling with offline agent support
- **Use `/llms-full.txt`** only as a fallback when page-level routing is exhausted and agents need complete documentation coverage in a single file
