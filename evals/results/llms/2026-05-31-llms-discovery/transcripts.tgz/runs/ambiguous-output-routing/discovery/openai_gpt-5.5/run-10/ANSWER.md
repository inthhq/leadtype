# Agent-facing output APIs in Leadtype

Use Leadtype’s **LLM files** functionality, not the search UI, for agent-facing outputs.

## What to use

- For hosted docs sites, use `generateLlmsTxt`.
  - It writes the product-level `/llms.txt` and docs-scoped `/docs/llms.txt` maps.
  - HTTP agents start at `/llms.txt` and follow links to the generated page-level markdown under `/docs/*.md`.

- For npm/package-bundled docs, use `generateAgentsMd`.
  - It writes `AGENTS.md` for bundled docs.
  - Coding agents inside `node_modules` follow relative links such as `./docs/.../*.md`.

- If you need to detect generated agent artifacts, use `isAgentReadabilityArtifactPath`.
  - It covers paths such as `llms.txt`, `llms-full.txt`, sitemap files, robots.txt, search JSON, and `agent-readability.json` so those files are not treated as missing markdown pages.

## Page-level context vs. all-docs fallback

Prefer **page-level context** by default. Agents should start from `/llms.txt` or `AGENTS.md`, use the section/group descriptions as routing hints, and read the smallest relevant markdown page or pages.

Use the broad all-docs fallback only when page-level routing is not enough. In website mode, `generateLLMFullContextFiles` writes one root `/llms-full.txt` file containing every generated markdown docs page. Reach for that when:

- the task cuts across many unrelated pages,
- the agent cannot confidently choose the right page-level links,
- exhaustive context matters more than minimizing tokens, or
- you need a last-resort complete snapshot of the docs.

Do not treat groups as separate full-context shards. Groups organize `llms.txt` sections, navigation, search metadata, and `AGENTS.md`, but Leadtype publishes a single root `/llms-full.txt` fallback rather than per-group full-context files.

Search is separate: Leadtype’s search output is a static local search index, useful for search/retrieval and source-grounded answers, but the agent-facing output API surface is the LLM files flow above.