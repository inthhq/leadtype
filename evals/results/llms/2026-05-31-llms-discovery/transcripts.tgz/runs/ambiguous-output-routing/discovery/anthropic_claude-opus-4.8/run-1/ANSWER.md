# Agent-facing output APIs in Leadtype

## Use the LLM files functionality (not Search)

For agent-facing output, reach for the **LLM files** APIs documented at `/docs/reference/llm.md`. These are the artifacts and generator functions that produce agent-readable bundles. Search (`/docs/reference/search.md`) is the lexical (BM25-style) query/index path that backs the search UI and source-grounded answers — it is *not* the agent output API you want here.

### The relevant generator functions / artifacts

- **`generateLlmsTxt`** — writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` map for hosted websites. This is the entry point HTTP/URL-based agents start from, then follow the page-level markdown links.
- **`generateLLMFullContextFiles`** — writes one root `/llms-full.txt` file that contains **every** generated markdown docs page concatenated together (the broad "all-docs" bundle). Note: groups organize `llms.txt` sections/navigation/search metadata/AGENTS.md, but they are *not* published as per-group full-context files by default.
- **`generateAgentsMd`** — writes `AGENTS.md` for npm-bundled docs (coding agents inside installed packages start here and follow relative `docs/*.md` links). It intentionally ignores `product.agentGuidance`, which is meant for website URL routing.
- **`isAgentReadabilityArtifactPath`** — identifies artifact paths that should not be rewritten as missing markdown pages (covers `llms.txt`, `llms-full.txt`, sitemap files, `robots.txt`, search JSON, and `agent-readability.json`).

## Page-level context vs. the broad all-docs fallback

The intended default is **page-level**: start at `/llms.txt`, follow the markdown links, and read the **smallest page (or pages) that answer the task**. This keeps context focused and cheap.

Reach for the **broad all-docs fallback** — the single root `/llms-full.txt` produced by `generateLLMFullContextFiles` — only when page-level context is not enough, i.e.:

- You need the **entire corpus** in one place (full root context), not a targeted page.
- The task spans many pages or you cannot tell in advance which page(s) hold the answer, so the per-page navigation via `llms.txt` won't reliably scope it.

In short:

| Need | Use |
|------|-----|
| Targeted answer from one/few pages | `llms.txt` page-level markdown links (default) |
| Whole-corpus / can't scope to a page | `llms-full.txt` (root full-context fallback) |
| Offline docs inside an npm package | `AGENTS.md` + relative `docs/*.md` links |
| Query/ranking + source-grounded answers (the search UI) | Search index — *not* the agent output API |
