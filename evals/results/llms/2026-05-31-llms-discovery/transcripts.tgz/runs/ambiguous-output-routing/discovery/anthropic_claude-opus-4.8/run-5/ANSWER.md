# Agent-facing output APIs in Leadtype

## Short answer

Use the **LLM files** family of generators (documented in `/docs/reference/llm.md`) for
agent-facing output — *not* the search functionality. Search (`/docs/reference/search.md`)
is the static query/UI path; it is for source-grounded retrieval and answer generation,
not for handing docs to an agent as context.

Reach for the **broad all-docs fallback** (`llms-full.txt`) only when an agent needs the
*entire* corpus in one shot and page-level links are not enough. For normal use, prefer
**page-level context**: let the agent start from the map and read the smallest page(s)
that answer the task.

## Which APIs to use

The agent-facing output APIs are the LLM/bundle generators:

- **`generateLlmsTxt`** — writes the product-level `/llms.txt` and the docs-scoped
  `/docs/llms.txt` map for hosted websites. This is the page-level entry point: HTTP
  agents start at `/llms.txt` and follow the markdown links to the smallest relevant page.
- **`generateLLMFullContextFiles`** — writes the single root `/llms-full.txt` containing
  *every* generated markdown docs page. This is the broad all-docs fallback.
- **`generateAgentsMd`** — writes `AGENTS.md` for npm-bundled (offline) docs. Coding
  agents inside installed packages start here and follow relative `docs/*.md` links.
  It intentionally ignores `product.agentGuidance` (that text is for website URL routing).
- **`isAgentReadabilityArtifactPath`** — identifies artifact paths that must not be
  rewritten as missing markdown pages (covers `llms.txt`, `llms-full.txt`, sitemap files,
  `robots.txt`, search JSON, and `agent-readability.json`).

These artifacts are also surfaced by the CLI: `leadtype generate --json` prints paths
including `llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, and `agentReadabilityJson`.

## Page-level context vs. the all-docs fallback

| Need | Use | API / artifact |
| --- | --- | --- |
| Default: answer a specific task | **Page-level context** — start at the map, read the smallest page(s) | `generateLlmsTxt` → `/llms.txt`, `/docs/llms.txt` |
| Offline/coding agent inside an npm package | Package entry point + relative links | `generateAgentsMd` → `AGENTS.md` + `docs/*.md` |
| Agent needs the whole corpus at once / page links insufficient | **Broad all-docs fallback** | `generateLLMFullContextFiles` → `/llms-full.txt` |
| Query/retrieval & source-grounded answers (not raw agent context) | Static search index (separate concern) | search index/content, `/docs/reference/search.md` |

### When to reach for `llms-full.txt`
- The task spans many pages or you can't predict which page is relevant.
- The agent has no good way to follow links and needs everything inline.
- You want a single full-context dump as a safety net.

Otherwise, follow Leadtype's own guidance: "Read the smallest page or pages that answer
the task." Prefer the `llms.txt` map and page-level markdown links, and treat
`llms-full.txt` as a fallback rather than the default.

> Note: groups organize `llms.txt` sections, navigation, search metadata, and `AGENTS.md`,
> but are **not** published as per-group full-context files by default — there is one root
> `llms-full.txt`, not one per group. Use groups for routing, not sharding.
