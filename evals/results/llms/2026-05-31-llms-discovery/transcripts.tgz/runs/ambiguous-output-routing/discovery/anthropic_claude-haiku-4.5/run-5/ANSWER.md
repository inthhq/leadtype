# Agent-Facing Output APIs in Leadtype

## Overview

Leadtype provides two main agent-facing output APIs that generate different artifacts depending on your deployment scenario:

### 1. **Website Mode** (HTTP Agents)
For agent requests to hosted documentation sites.

**Key API Functions:**
- `generateLlmsTxt()` - Generates `/llms.txt` (product-level) and `/docs/llms.txt` (docs-scoped) map
- `generateLLMFullContextFiles()` - Generates `/llms-full.txt` (root full-context fallback with all markdown pages)

**Artifacts Generated:**
- `/llms.txt` - Entry point for HTTP agents
- `/docs/llms.txt` - Docs-scoped navigation map
- `/llms-full.txt` - Complete fallback with all pages
- Markdown mirrors under `/docs/*.md`
- Additional files: `sitemap.xml`, `sitemap.md`, `robots.txt`, `agent-readability.json`, `search-index.json`, `search-content.json`

**How It Works:**
HTTP agents start at `/llms.txt` and follow markdown links to discover pages.

---

### 2. **Bundle Mode** (Coding Agents in npm Packages)
For agents working with code inside installed npm packages.

**Key API Function:**
- `generateAgentsMd()` - Generates `AGENTS.md` for npm-bundled docs

**Artifacts Generated:**
- `AGENTS.md` - Entry point at package root with relative links (e.g., `./docs/reference/cli.md`)
- `docs/*.md` - Markdown files for offline reading

**How It Works:**
Coding agents read `AGENTS.md` and follow relative links to access docs inside `node_modules` without network requests.

**Note:** Bundle mode intentionally ignores `product.agentGuidance` since that text is written for website URL routing.

---

## When to Use the Broad All-Docs Fallback

**Use `/llms-full.txt` instead of page-level context when:**

1. **Complete Context Required** - When an agent needs to understand the entire documentation structure at once
2. **Group Routing Not Applicable** - When page-level routing through `/llms.txt` sections is insufficient
3. **Full Reference Needed** - When an agent requires all generated markdown pages in a single fallback

**Important:** Groups still organize `llms.txt` sections, navigation, search metadata, and `AGENTS.md` grouping. However, `/llms-full.txt` is the root fallback that **contains all generated markdown pages and is not split by group**.

---

## Key Distinctions

| Aspect | Website Mode | Bundle Mode |
|--------|--------------|------------|
| **Entry Point** | `/llms.txt` | `AGENTS.md` |
| **Use Case** | Hosted docs sites | npm packages |
| **Agent Type** | HTTP agents | Coding agents |
| **Links** | Absolute URLs | Relative paths |
| **Full Fallback** | `/llms-full.txt` | Not generated |
| **Search Artifacts** | Included | Not included |

---

## Summary

- **For page-level context:** Use the routing established by `/llms.txt` or `AGENTS.md` with individual markdown pages
- **For broad all-docs fallback:** Use `/llms-full.txt` when agents need complete documentation context independent of group routing
- Choose **Website Mode** for HTTP-discoverable agent files on hosted sites
- Choose **Bundle Mode** for offline agent access inside npm packages
