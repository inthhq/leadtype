# Agent-Facing Output APIs in Leadtype

## Overview

Leadtype provides two complementary agent-facing output APIs depending on your deployment context:

### 1. **HTTP Agents (Website Mode)**: `/llms.txt` and Page-Level Context
**Use this when**: Your documentation is hosted on a website accessible via HTTP.

- **Primary entry point**: `/llms.txt` (product-level routing map)
- **Group-scoped routing**: `/docs/llms.txt` (docs-scoped map)
- **Page-level context**: `/docs/*.md` (individual markdown pages)
- **Full-context fallback**: `/llms-full.txt` (all docs combined)

**How it works**: HTTP agents start at `/llms.txt` and follow markdown links to discover and consume documentation. Each page is independently queryable at its canonical URL.

### 2. **Coding Agents (Bundle Mode)**: `AGENTS.md` for npm Packages
**Use this when**: Your library is published as an npm package that users install locally.

- **Primary entry point**: `AGENTS.md` (at package root)
- **Page-level context**: `./docs/*.md` (relative links for offline access)
- **No full-context fallback**: Uses relative navigation within node_modules

**How it works**: Coding agents working inside installed npm packages start at `AGENTS.md` and follow relative `docs/*.md` links without requiring network access.

## When to Use the All-Docs Fallback

Use `/llms-full.txt` (the broad all-docs fallback) instead of page-level context when:

- **Agents request broad context**: When an HTTP agent needs complete documentation context rather than following link-based navigation
- **Groups don't apply**: The full-context file contains all generated markdown pages and is **not split by group**—it's a complete reference
- **Initial discovery**: As a fallback when agents need to understand the entire documentation structure at once
- **Semantic queries**: When agents need access to all content to perform search or semantic reasoning across the full corpus

## Generation Commands

**Website mode** (creates all HTTP agent APIs):
```bash
leadtype generate --src docs --out dist
```

**Bundle mode** (creates offline package docs):
```bash
leadtype generate --src docs --out dist --bundle
```

## Key Differences

| Aspect | HTTP Agents (llms.txt) | Coding Agents (AGENTS.md) |
|--------|------------------------|--------------------------|
| **Entry point** | `/llms.txt` | `AGENTS.md` |
| **Navigation** | HTTP links to `/docs/*.md` | Relative links to `./docs/*.md` |
| **Full context** | `/llms-full.txt` | N/A (uses relative navigation) |
| **Network required** | Yes | No |
| **Best for** | Website-hosted docs | Installed npm packages |

## Routing and Organization

Both APIs respect the **group structure** defined in your docs configuration:
- Groups organize `llms.txt` sections, navigation, search metadata, and `AGENTS.md` grouping
- Use groups for routing hints, not marketing copy
- Pages can belong to multiple groups: `group: [a, b]`
- The full-context fallback transcends group boundaries

## Summary

Choose page-level context APIs for typical agent navigation, and reach for the broad all-docs fallback when you need complete corpus access without following link chains.
