# Agent-Facing Output APIs in Leadtype

## Overview

Leadtype provides agent-facing output APIs through several generated files. The specific functionality you should use depends on your deployment context—whether agents are accessing your docs via HTTP URLs or working with bundled offline docs inside npm packages.

## Two Primary Flows

### 1. **HTTP Agents (Website Mode)**

Use this for agents accessing your docs site via URLs.

**Key API:**
- **`/llms.txt`** - The product-level routing entry point. HTTP agents start here and follow markdown links.
- **Page-level markdown** - Agents follow links from llms.txt to individual markdown pages (e.g., `/docs/reference/cli.md`)
- **`/docs/llms.txt`** - A docs-scoped version for hosted websites

**Generated via:** `leadtype generate` (default website mode)

**Learn more:** `/docs/reference/llm.md`

### 2. **Coding Agents (Bundle Mode)**

Use this for agents working with npm packages, accessing docs offline inside `node_modules`.

**Key API:**
- **`AGENTS.md`** - The package-root entry point using relative links like `./docs/reference/cli.md`
- **`docs/*.md`** - Markdown files linked relatively within the package

**Generated via:** `leadtype generate --bundle`

**Learn more:** `/docs/package-docs/bundle.md`

## When to Use the All-Docs Fallback

The **all-docs fallback** is `/llms-full.txt` in website mode.

### Use Page-Level Context (Default)

- When you have **well-organized groups** that route agents to the right section
- When users have **clear task-specific needs** that map to individual pages
- When your **docs vocabulary matches user vocabulary** (lexical search is sufficient)
- In general, for **most documentation use cases**

**Strategy:** Start agents at llms.txt, which provides routing hints via group descriptions. Agents follow markdown links to the smallest pages that answer the task.

### Reach for the All-Docs Fallback (`/llms-full.txt`)

- When agents need **unrestricted access** to everything at once
- When **page-level routing hints are insufficient** because docs vocabulary doesn't match user vocabulary
- When you're using **semantic retrieval** or embeddings that benefit from seeing all content upfront
- As a **broadest-possible context** option when specificity fails

**Important:** `/llms-full.txt` contains every generated markdown page flattened into one file. Groups still organize routing in llms.txt sections, but the full-context file bypasses that organization.

## Generated Artifacts Summary

**Website Mode (HTTP agents):**
- `/llms.txt` and `/docs/llms.txt` (routing entry points)
- Markdown mirrors under `/docs/*.md`
- `/llms-full.txt` (broadest fallback)
- Search index, sitemap, robots.txt, and agent-readability metadata

**Bundle Mode (offline package docs):**
- `AGENTS.md` (relative-link entry point)
- `docs/*.md` (relative-linked pages)
- No llms.txt, full-context, or web artifacts

## Key Principle

> Use groups for routing, not sharding. Group descriptions should be routing hints, not marketing copy.

Start with page-level markdown links organized by group. Only use the all-docs fallback when page-level context is inadequate.

---

**References:**
- `/docs/reference/llm.md` - LLM file generation details
- `/docs/how-it-works.md` - Pipeline architecture
- `/docs/package-docs/bundle.md` - Bundle mode details
- `/docs/build/connect-docs-site.md` - Website mode deployment
