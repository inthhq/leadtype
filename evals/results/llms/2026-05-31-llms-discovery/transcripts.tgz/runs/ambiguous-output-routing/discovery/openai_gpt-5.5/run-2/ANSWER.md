# Agent-facing output APIs in Leadtype

Use Leadtype’s **LLM files** functionality, not the search UI, for agent-facing outputs.

## What to use

For hosted docs websites, use:

- `generateLlmsTxt` — writes the product-level `/llms.txt` and docs-scoped `/docs/llms.txt` maps.
- Markdown mirrors under `/docs/*.md` — agents follow these page-level links from `llms.txt`.
- `generateLLMFullContextFiles` — writes the root `/llms-full.txt` all-docs fallback.

For npm/package-bundled docs, use:

- `generateAgentsMd` — writes `AGENTS.md` for coding agents working inside an installed package.
- Bundled `docs/*.md` files — linked relatively from `AGENTS.md`.

Leadtype’s search artifacts (`search-index.json` and `search-content.json`) are for local/static search and can feed source-grounded answer generation, but they are not the primary agent-facing navigation surface.

## Page-level context vs. all-docs fallback

Prefer **page-level context** by default:

1. HTTP agents start at `/llms.txt`.
2. They use the routing hints and groups there to choose the smallest relevant markdown page or pages.
3. They fetch those `/docs/*.md` pages directly.

Reach for the broad **all-docs fallback**, `/llms-full.txt`, only when page-level routing is not enough — for example:

- the agent cannot confidently identify the right page from `/llms.txt`;
- the question is broad or cross-cutting across many docs pages;
- the task needs a complete corpus view rather than targeted page context;
- a consumer explicitly wants one file containing every generated markdown docs page.

Groups should help with routing and organization, not with sharding full-context bundles: Leadtype publishes one root `/llms-full.txt` fallback rather than per-group full-context files by default.