# What `leadtype generate --json` Reports

According to the Leadtype documentation, when the `--json` flag is enabled with the `leadtype generate` command, it prints a JSON object containing paths for the generated artifacts.

The JSON object includes the following fields for website-mode:

- **llmsFullTxt** - Path to the full LLMs text file
- **docsLlmsTxt** - Path to the docs LLMs text file
- **llmsTxt** - Path to the LLMs text file
- **agentReadabilityJson** - Path to the agent readability JSON file
- **sitemapXml** - Path to the sitemap XML file
- **sitemapMd** - Path to the sitemap Markdown file
- **robotsTxt** - Path to the robots.txt file
- **searchIndex** - Path to the search index
- **searchContent** - Path to the search content

These artifacts are generated from the documentation and are formatted to be readable by AI agents. The JSON output provides a structured way to reference all the generated files for further processing or integration.
