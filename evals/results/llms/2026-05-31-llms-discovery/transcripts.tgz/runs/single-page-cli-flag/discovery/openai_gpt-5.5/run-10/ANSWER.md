# `leadtype generate --json`

According to the Leadtype CLI docs, `leadtype generate` converts docs and writes agent-readable artifacts. When the `--json` flag is enabled, it prints a JSON object that reports the paths of the generated artifacts.

In website mode, that JSON object includes paths for:

- `llmsFullTxt`
- `docsLlmsTxt`
- `llmsTxt`
- `agentReadabilityJson`
- `sitemapXml`
- `sitemapMd`
- `robotsTxt`
- `searchIndex`
- `searchContent`
