# What `leadtype generate --json` Reports

When the `--json` flag is enabled with `leadtype generate`, the command prints a JSON object containing **paths for the generated artifacts**.

## Website-Mode Artifacts

When using website mode, the JSON output includes paths for the following artifacts:

- **llmsFullTxt** - Full LLMs text file
- **docsLlmsTxt** - Documentation LLMs text file
- **llmsTxt** - LLMs text file
- **agentReadabilityJson** - Agent readability JSON
- **sitemapXml** - XML sitemap
- **sitemapMd** - Markdown sitemap
- **robotsTxt** - Robots.txt file
- **searchIndex** - Search index
- **searchContent** - Search content

This JSON output makes it easy for build systems and tools to programmatically identify and reference the generated artifacts produced by the `leadtype generate` command.
