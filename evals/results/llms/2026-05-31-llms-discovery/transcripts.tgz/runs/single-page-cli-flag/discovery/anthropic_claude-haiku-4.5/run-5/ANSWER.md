# What `leadtype generate --json` Reports

According to the Leadtype docs site, when `--json` is enabled with the `leadtype generate` command, it prints a JSON object with paths for the generated artifacts. 

The website-mode object includes the following fields:
- `llmsFullTxt`
- `docsLlmsTxt`
- `llmsTxt`
- `agentReadabilityJson`
- `sitemapXml`
- `sitemapMd`
- `robotsTxt`
- `searchIndex`
- `searchContent`

In essence, the `--json` flag provides structured output containing the file paths of all the agent-readable artifacts that were generated during the documentation conversion process.
