# What `leadtype generate --json` Reports

According to the Leadtype docs site, when the `--json` flag is enabled with the `leadtype generate` command, it prints a JSON object with paths for the generated artifacts.

## Generated Artifact Paths

The JSON output includes the following keys for website-mode:

- `llmsFullTxt` - Full LLMs text output
- `docsLlmsTxt` - Documentation LLMs text output
- `llmsTxt` - LLMs text output
- `agentReadabilityJson` - Agent readability JSON file
- `sitemapXml` - XML sitemap
- `sitemapMd` - Markdown sitemap
- `robotsTxt` - Robots.txt file
- `searchIndex` - Search index file
- `searchContent` - Search content file

These paths represent the agent-readable artifacts generated from the documentation source files specified with the `--src` flag.

**Source:** [Leadtype CLI Documentation](/docs/reference/cli.md)
