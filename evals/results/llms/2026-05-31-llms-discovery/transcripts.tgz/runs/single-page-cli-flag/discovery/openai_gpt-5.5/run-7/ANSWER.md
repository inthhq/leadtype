# What `leadtype generate --json` reports

According to the Leadtype CLI docs, `leadtype generate` converts docs and writes agent-readable artifacts. When the `--json` flag is enabled, it prints a JSON object containing the filesystem paths of the artifacts it generated.

In website mode, that JSON object includes paths for:

- `llmsFullTxt` — the root `/llms-full.txt` full-context file
- `docsLlmsTxt` — the docs-scoped `/docs/llms.txt` map
- `llmsTxt` — the product-level `/llms.txt`
- `agentReadabilityJson` — `agent-readability.json`
- `sitemapXml` — the generated XML sitemap
- `sitemapMd` — the generated Markdown sitemap
- `robotsTxt` — the generated `robots.txt`
- `searchIndex` — the static search index JSON
- `searchContent` — the static search content JSON

So, `leadtype generate --json` is mainly a machine-readable summary of where Leadtype wrote the generated agent-readable website artifacts.