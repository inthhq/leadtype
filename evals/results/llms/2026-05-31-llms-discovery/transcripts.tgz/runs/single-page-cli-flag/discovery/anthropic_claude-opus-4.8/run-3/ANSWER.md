# What `leadtype generate --json` reports

According to the Leadtype docs ([/docs/reference/cli.md](docs/reference/cli.md)),
`leadtype generate` converts docs and writes agent-readable artifacts. It accepts
flags including `--src`, `--out`, `--base-url`, `--bundle`, `--json`, `--enrich-git`,
and `--strict`.

## The `--json` output

When `--json` is enabled, `generate` **prints a JSON object containing the paths to
the generated artifacts** (rather than human-readable log output). This makes the
result easy to consume programmatically — for example, in CI pipelines or tooling
that needs to know where each artifact was written.

## Fields in the website-mode JSON object

In website mode, the printed JSON object includes paths for the following artifacts:

| Field | Artifact it points to |
|-------|-----------------------|
| `llmsFullTxt` | The root `/llms-full.txt` file containing every generated markdown docs page. |
| `docsLlmsTxt` | The docs-scoped `/docs/llms.txt` map. |
| `llmsTxt` | The product-level `/llms.txt` map. |
| `agentReadabilityJson` | The `agent-readability.json` artifact (an agent-readability metadata file). |
| `sitemapXml` | The XML sitemap (`sitemap.xml`). |
| `sitemapMd` | The Markdown sitemap. |
| `robotsTxt` | The `robots.txt` file. |
| `searchIndex` | The static local search index built over the generated markdown. |
| `searchContent` | The search content JSON that backs the search index. |

## Notes / related context

- The `llms.txt` and `llms-full.txt` files are produced by `generateLlmsTxt` and
  `generateLLMFullContextFiles` respectively (see [/docs/reference/llm.md](docs/reference/llm.md)).
- The `searchIndex` / `searchContent` artifacts back Leadtype's static, edge-safe
  search using BM25-style lexical ranking (see [/docs/reference/search.md](docs/reference/search.md)).
- These artifact paths (llms.txt, llms-full.txt, sitemap files, robots.txt, search
  JSON, and agent-readability.json) are recognized as agent-readability artifacts and
  are not rewritten as missing markdown pages.

In short: `leadtype generate --json` reports a machine-readable JSON object listing
the file paths of all the artifacts the build produced — the LLM map files, the
full-context file, the sitemaps, robots.txt, the agent-readability JSON, and the
search index/content files.
