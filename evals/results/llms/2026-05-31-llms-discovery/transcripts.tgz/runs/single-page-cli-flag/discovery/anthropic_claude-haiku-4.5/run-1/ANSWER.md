# What `leadtype generate --json` Reports

According to the Leadtype docs site, when the `--json` flag is enabled with `leadtype generate`, the command prints a JSON object with paths for the generated artifacts.

The website-mode object includes the following artifact paths:

- **llmsFullTxt** - Full LLM text artifact
- **docsLlmsTxt** - Documentation LLM text artifact
- **llmsTxt** - LLM text artifact
- **agentReadabilityJson** - Agent readability JSON artifact
- **sitemapXml** - XML sitemap
- **sitemapMd** - Markdown sitemap
- **robotsTxt** - Robots.txt file
- **searchIndex** - Search index
- **searchContent** - Search content

In summary, `leadtype generate --json` reports the file paths of all the agent-readable artifacts that were generated from the documentation.
