# What `leadtype generate --json` reports

Source: [CLI reference](/docs/reference/cli.md)

`leadtype generate` converts docs and writes agent-readable artifacts. When the
`--json` flag is enabled, `generate` prints a **JSON object containing the file
paths of the generated artifacts** (instead of, or in addition to, plain output).
This makes the command easy to consume programmatically, for example in CI or
build scripts.

## Reported fields (website mode)

In website mode, the printed JSON object includes paths for the following
generated artifacts:

- `llmsFullTxt` — the root full-context file (`/llms-full.txt`) containing every generated markdown docs page.
- `docsLlmsTxt` — the docs-scoped `/docs/llms.txt` map.
- `llmsTxt` — the product-level `/llms.txt`.
- `agentReadabilityJson` — agent-readability metadata JSON.
- `sitemapXml` — the XML sitemap.
- `sitemapMd` — the markdown sitemap.
- `robotsTxt` — the `robots.txt` file.
- `searchIndex` — the static local search index.
- `searchContent` — the search content used by the index.

## Notes

- `--json` reports *paths* to artifacts, not their contents.
- The fields listed above are the **website-mode** outputs. Bundle mode
  (`--bundle`) instead writes `AGENTS.md` and `docs/*.md` for npm packages, so
  its reported artifacts differ.
