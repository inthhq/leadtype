# What `leadtype generate --json` Reports

According to the Leadtype docs site, when the `--json` flag is enabled with the `leadtype generate` command, it **prints a JSON object with paths for the generated artifacts**.

The JSON object includes the following artifact paths for website-mode:

- `llmsFullTxt` - Full LLM context text file
- `docsLlmsTxt` - Docs-specific LLM text file
- `llmsTxt` - LLM text file
- `agentReadabilityJson` - Agent readability JSON file
- `sitemapXml` - XML sitemap
- `sitemapMd` - Markdown sitemap
- `robotsTxt` - Robots.txt file
- `searchIndex` - Search index
- `searchContent` - Search content

This JSON output makes it easy for tools and scripts to programmatically discover the locations of all generated artifacts from the `leadtype generate` command.
