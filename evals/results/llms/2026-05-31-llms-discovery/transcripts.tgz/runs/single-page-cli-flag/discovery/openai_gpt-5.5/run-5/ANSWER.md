# What `leadtype generate --json` reports

According to the Leadtype CLI docs, `leadtype generate` converts docs and writes agent-readable artifacts. When the `--json` flag is enabled, the command prints a JSON object containing the paths of the artifacts it generated.

In website mode, that JSON object includes paths for:

- `llmsFullTxt` — the root `/llms-full.txt` full-context file
- `docsLlmsTxt` — the docs-scoped `/docs/llms.txt`
- `llmsTxt` — the site-root `/llms.txt`
- `agentReadabilityJson` — `agent-readability.json`
- `sitemapXml` — the XML sitemap
- `sitemapMd` — the markdown sitemap
- `robotsTxt` — `robots.txt`
- `searchIndex` — the generated search index JSON
- `searchContent` — the generated search content JSON

So, `leadtype generate --json` is mainly a machine-readable report of where Leadtype wrote each generated output artifact.