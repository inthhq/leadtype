# What `leadtype generate --json` reports

According to the Leadtype CLI docs, `leadtype generate` converts documentation and writes agent-readable artifacts. When the `--json` flag is enabled, it prints a JSON object containing the paths of the generated artifacts, rather than just normal human-oriented CLI output.

In website mode, that JSON object includes paths for:

- `llmsFullTxt` — the root `/llms-full.txt` full-context file containing all generated markdown docs pages.
- `docsLlmsTxt` — the docs-scoped `/docs/llms.txt` map.
- `llmsTxt` — the product-level `/llms.txt` entry point for agents.
- `agentReadabilityJson` — the generated `agent-readability.json` artifact.
- `sitemapXml` — the generated XML sitemap.
- `sitemapMd` — the generated markdown sitemap.
- `robotsTxt` — the generated robots.txt file.
- `searchIndex` — the generated static search index JSON.
- `searchContent` — the generated search content JSON.

So, `leadtype generate --json` is primarily a machine-readable summary of where Leadtype wrote its generated files. This is useful in scripts or CI because tools can parse the JSON and locate the generated agent, sitemap, robots, and search artifacts directly.
