# What `leadtype generate --json` reports

According to the Leadtype docs ([/docs/reference/cli.md](docs/reference/cli.md)),
`leadtype generate` converts docs and writes agent-readable artifacts. The
`--json` flag changes how the command reports its results.

## Behavior

When `--json` is enabled, `generate` prints a **JSON object containing the
file paths of the generated artifacts** (rather than ordinary human-readable
output). This makes the command's output easy to consume programmatically,
for example in build pipelines or by other tooling.

## What the JSON object contains (website mode)

In website mode, the printed JSON object includes paths for the following
generated artifacts:

| Key | Artifact |
| --- | --- |
| `llmsFullTxt` | The full `llms-full.txt` file |
| `docsLlmsTxt` | The docs-scoped `llms.txt` file |
| `llmsTxt` | The `llms.txt` file |
| `agentReadabilityJson` | Agent-readability JSON metadata |
| `sitemapXml` | The XML sitemap (`sitemap.xml`) |
| `sitemapMd` | The Markdown sitemap |
| `robotsTxt` | The `robots.txt` file |
| `searchIndex` | The generated search index |
| `searchContent` | The generated search content |

## Summary

`leadtype generate --json` does not change *what* is generated — it changes the
*reporting format*. Instead of plain output, it emits a single JSON object that
maps each generated artifact to its output path, so downstream automation can
reliably locate the produced files.
