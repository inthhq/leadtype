# What `leadtype generate --json` reports

According to the Leadtype docs ([CLI reference](/docs/reference/cli.md)), `leadtype generate` converts docs and writes agent-readable artifacts. The `--json` flag controls the command's output format.

## Summary

When `--json` is enabled, `leadtype generate` **prints a JSON object containing the file paths for the generated artifacts**. In other words, it doesn't change *what* is generated — it gives you a machine-readable manifest of *where* each generated artifact was written, which is useful for scripting and CI pipelines.

## What the JSON object contains (website mode)

In website mode, the JSON object includes paths for the following artifacts:

| Field | Artifact |
| --- | --- |
| `llmsFullTxt` | The root `/llms-full.txt` file containing every generated markdown docs page |
| `docsLlmsTxt` | The docs-scoped `/docs/llms.txt` map |
| `llmsTxt` | The product-level `/llms.txt` map |
| `agentReadabilityJson` | The `agent-readability.json` artifact |
| `sitemapXml` | The XML sitemap |
| `sitemapMd` | The Markdown sitemap |
| `robotsTxt` | The `robots.txt` file |
| `searchIndex` | The static local search index built over generated markdown |
| `searchContent` | The search content used by the search index |

## Related context

- The LLM map and full-context files (`llmsTxt`, `docsLlmsTxt`, `llmsFullTxt`) come from Leadtype's LLM-file generation. `/llms-full.txt` is a single root file containing every generated markdown docs page, and the `llms.txt` files are routing maps for product- and docs-level navigation. (See [LLM files](/docs/reference/llm.md).)
- The `searchIndex`/`searchContent` artifacts back Leadtype's static, edge-safe local search built at build time, using lexical BM25-style ranking. (See [Search](/docs/reference/search.md).)

## Notes

- These artifact paths (llms.txt, llms-full.txt, sitemap files, robots.txt, search JSON, and agent-readability.json) are recognized as agent-readability artifacts and are not rewritten as missing markdown pages.
- Other useful `generate` flags include `--src`, `--out`, `--base-url`, `--bundle`, `--enrich-git`, and `--strict`.
