# What `leadtype generate --json` reports

According to the Leadtype docs ([/docs/reference/cli.md](docs/reference/cli.md)),
`leadtype generate` converts docs and writes agent-readable artifacts. The
`--json` flag changes its output behavior:

> When `--json` is enabled, `generate` prints a **JSON object with paths for the
> generated artifacts**.

So `--json` doesn't change *what* is generated — it makes the command emit a
machine-readable summary of *where* each generated artifact was written. This is
handy for scripting and CI pipelines that need to locate the outputs.

## The website-mode JSON object

In website mode, the emitted object includes paths to the following artifacts:

| Field | Artifact |
|-------|----------|
| `llmsFullTxt` | The root `/llms-full.txt` file containing every generated markdown docs page |
| `docsLlmsTxt` | The docs-scoped `/docs/llms.txt` map |
| `llmsTxt` | The product-level `/llms.txt` map |
| `agentReadabilityJson` | The `agent-readability.json` artifact |
| `sitemapXml` | The XML sitemap |
| `sitemapMd` | The Markdown sitemap |
| `robotsTxt` | The `robots.txt` file |
| `searchIndex` | The static, build-time search index (lexical BM25-style ranking) |
| `searchContent` | The search content used by the query path |

## Notes

- The `--json` output is purely informational about generated paths; related
  flags such as `--src`, `--out`, `--base-url`, `--bundle`, `--enrich-git`, and
  `--strict` control how generation actually runs.
- The artifacts referenced (llms.txt, llms-full.txt, sitemap files, robots.txt,
  search JSON, and agent-readability.json) are recognized as agent-readability
  artifact paths and are not rewritten as missing markdown pages
  (see [/docs/reference/llm.md](docs/reference/llm.md)).
- The search-related outputs (`searchIndex`, `searchContent`) back Leadtype's
  static local search index built over generated markdown at build time
  (see [/docs/reference/search.md](docs/reference/search.md)).
