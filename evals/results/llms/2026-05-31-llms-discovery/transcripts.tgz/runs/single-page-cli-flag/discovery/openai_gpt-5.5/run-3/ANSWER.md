# What `leadtype generate --json` reports

According to the Leadtype CLI reference, `leadtype generate --json` makes `leadtype generate` print a JSON object describing the paths of the artifacts it generated.

In website mode, that JSON object includes paths for:

- `llmsFullTxt` — the root `/llms-full.txt` full-context file containing generated markdown docs pages.
- `docsLlmsTxt` — the docs-scoped `/docs/llms.txt` map.
- `llmsTxt` — the product-level root `/llms.txt` entry point for agents.
- `agentReadabilityJson` — `/docs/agent-readability.json`.
- `sitemapXml` — the XML sitemap artifact.
- `sitemapMd` — the markdown sitemap artifact.
- `robotsTxt` — the robots.txt artifact.
- `searchIndex` — the static search index JSON.
- `searchContent` — the generated search content JSON.

So, `--json` is a machine-readable summary of where Leadtype wrote the generated website artifacts, rather than only human-oriented console output.