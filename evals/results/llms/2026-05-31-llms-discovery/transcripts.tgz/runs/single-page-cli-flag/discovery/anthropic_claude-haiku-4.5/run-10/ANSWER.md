# What `leadtype generate --json` Reports

According to the Leadtype documentation, when `--json` is enabled with the `leadtype generate` command, it prints a JSON object with paths for the generated artifacts.

Specifically, the JSON output includes a website-mode object that contains the following file paths:

- **llmsFullTxt** - Full text content for LLMs
- **docsLlmsTxt** - Documentation-specific LLM text
- **llmsTxt** - LLM text format
- **agentReadabilityJson** - Agent readability in JSON format
- **sitemapXml** - XML sitemap file path
- **sitemapMd** - Markdown sitemap file path
- **robotsTxt** - Robots.txt file path
- **searchIndex** - Search index file path
- **searchContent** - Search content file path

This JSON output provides a convenient way to reference all the generated artifacts programmatically, making it useful for automation and integration with other tools.
