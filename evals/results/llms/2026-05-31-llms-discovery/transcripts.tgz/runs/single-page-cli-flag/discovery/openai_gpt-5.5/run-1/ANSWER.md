# What `leadtype generate --json` reports

According to the Leadtype CLI reference, `leadtype generate` converts docs and writes agent-readable artifacts. When the `--json` flag is enabled, it prints a JSON object containing the paths of the generated artifacts.

In website mode, that JSON object includes paths for:

- `llmsFullTxt` — the generated `llms-full.txt`
- `docsLlmsTxt` — the docs-scoped LLM text artifact
- `llmsTxt` — the generated `llms.txt`
- `agentReadabilityJson` — the generated `agent-readability.json`
- `sitemapXml` — the generated XML sitemap
- `sitemapMd` — the generated Markdown sitemap
- `robotsTxt` — the generated `robots.txt`
- `searchIndex` — the generated search index
- `searchContent` — the generated search content

So, `leadtype generate --json` is primarily a machine-readable summary of where Leadtype wrote each generated output file.