# What `leadtype generate --json` reports

Source: [/docs/reference/cli.md](docs/reference/cli.md)

## Summary

`leadtype generate` converts docs and writes agent-readable artifacts. When the
`--json` flag is enabled, instead of (or in addition to) running silently,
`generate` **prints a JSON object whose values are the file paths of the
artifacts it generated**. This makes the command machine-readable so build
scripts, CI pipelines, and agents can discover exactly where each output file
was written.

## What the JSON object contains (website mode)

In website mode the printed JSON object includes the following keys, each
pointing at a generated artifact path:

| Key | Artifact it points to |
| --- | --- |
| `llmsFullTxt` | The root `/llms-full.txt` file containing every generated markdown docs page |
| `docsLlmsTxt` | The docs-scoped `/docs/llms.txt` map |
| `llmsTxt` | The product-level `/llms.txt` map |
| `agentReadabilityJson` | The `agent-readability.json` artifact |
| `sitemapXml` | The XML sitemap (`sitemap.xml`) |
| `sitemapMd` | The Markdown sitemap |
| `robotsTxt` | The `robots.txt` file |
| `searchIndex` | The static local search index built over the generated markdown |
| `searchContent` | The search content file feeding the index |

## Why it's useful

- **Automation/CI:** Downstream tooling can parse the JSON to locate generated
  files rather than guessing their paths.
- **Agent integration:** The same paths identified here are the
  "agent-readability artifacts" (llms.txt, llms-full.txt, sitemap files,
  robots.txt, search JSON, and agent-readability.json) that should not be
  treated as ordinary missing markdown pages.

## Related flags

Other important `generate` flags mentioned alongside `--json` are `--src`,
`--out`, `--base-url`, `--bundle`, `--enrich-git`, and `--strict`.
