# What `leadtype generate --json` Reports

When the `--json` flag is enabled with `leadtype generate`, it prints a JSON object containing paths for the generated artifacts.

The website-mode object includes the following properties:
- **llmsFullTxt** - Full LLM text file
- **docsLlmsTxt** - Docs-specific LLM text file
- **llmsTxt** - General LLM text file
- **agentReadabilityJson** - Agent readability JSON data
- **sitemapXml** - XML sitemap
- **sitemapMd** - Markdown sitemap
- **robotsTxt** - Robots.txt file
- **searchIndex** - Search index data
- **searchContent** - Search content data

In essence, `leadtype generate --json` provides a structured JSON output that reports the file paths of all generated agent-readable artifacts from the documentation conversion process.
