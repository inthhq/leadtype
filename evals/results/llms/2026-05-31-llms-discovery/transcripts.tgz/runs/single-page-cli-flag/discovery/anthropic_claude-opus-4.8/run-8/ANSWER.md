# What `leadtype generate --json` reports

Source: [/docs/reference/cli.md](docs/reference/cli.md) (cross-referenced with [/docs/quickstart.md](docs/quickstart.md) and [/docs/reference/llm.md](docs/reference/llm.md)).

## Summary

`leadtype generate` converts docs and writes agent-readable artifacts. When you add the
`--json` flag, `generate` **prints a JSON object containing the paths of the artifacts it
generated**. This makes the run machine-readable, so CI jobs and tooling can locate each
output without guessing at filenames.

## What the JSON object contains (website mode)

In website mode, the emitted JSON object includes a path for each generated artifact:

| Field | Artifact it points to |
|-------|----------------------|
| `llmsFullTxt` | The root `/llms-full.txt` full-context bundle (every generated markdown page in one file) |
| `docsLlmsTxt` | The docs-scoped `/docs/llms.txt` map |
| `llmsTxt` | The product-level `/llms.txt` map |
| `agentReadabilityJson` | `docs/agent-readability.json` |
| `sitemapXml` | `docs/sitemap.xml` |
| `sitemapMd` | `docs/sitemap.md` |
| `robotsTxt` | `docs/robots.txt` |
| `searchIndex` | `docs/search-index.json` (the static local search index) |
| `searchContent` | `docs/search-content.json` (the search content payload) |

These correspond to the website-mode outputs described in the Quickstart: `/llms.txt`,
`/docs/llms.txt`, `/llms-full.txt`, the markdown mirrors under `/docs/*.md`,
`docs/sitemap.xml`, `docs/sitemap.md`, `docs/robots.txt`, `docs/agent-readability.json`,
`docs/search-index.json`, and `docs/search-content.json`.

## Notes

- `--json` reports **paths**, not the contents of the artifacts.
- The fields listed above are specifically the **website-mode** object. Bundle mode
  (`leadtype generate --bundle`) is a different output shape — it writes `AGENTS.md` and
  `docs/*.md` with relative links for npm packages.
- `--json` pairs well with other flags such as `--src`, `--out`, `--base-url`,
  `--bundle`, `--enrich-git`, and `--strict`.
