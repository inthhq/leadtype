# What `leadtype generate --json` reports

According to the Leadtype docs ([CLI reference](/docs/reference/cli.md)), the
`leadtype generate` command converts docs and writes agent-readable artifacts.

When the `--json` flag is enabled, `generate` **prints a JSON object containing
the paths to the generated artifacts** (rather than just running silently).

## Website-mode output

In website mode, the printed JSON object includes paths for the following
generated artifacts:

| Key | Artifact |
| --- | --- |
| `llmsFullTxt` | The root `/llms-full.txt` file (every generated markdown docs page in one file) |
| `docsLlmsTxt` | The docs-scoped `/docs/llms.txt` map |
| `llmsTxt` | The product-level `/llms.txt` map |
| `agentReadabilityJson` | The `agent-readability.json` artifact |
| `sitemapXml` | The XML sitemap |
| `sitemapMd` | The Markdown sitemap |
| `robotsTxt` | The `robots.txt` file |
| `searchIndex` | The static local search index |
| `searchContent` | The search content data |

## In short

`--json` makes `generate` emit a machine-readable summary of where each
build artifact was written. This is useful for scripting and CI, where a
downstream step needs to locate the generated LLM files (`llms.txt`,
`llms-full.txt`), sitemaps, `robots.txt`, the agent-readability metadata, and
the search index/content.

> Note: the keys listed above are the ones documented for **website mode**.
> Related flags on `generate` include `--src`, `--out`, `--base-url`,
> `--bundle`, `--enrich-git`, and `--strict`.
