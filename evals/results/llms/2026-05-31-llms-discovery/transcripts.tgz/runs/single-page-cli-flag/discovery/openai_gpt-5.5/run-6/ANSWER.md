# What `leadtype generate --json` reports

According to the Leadtype CLI reference, `leadtype generate` converts docs and writes agent-readable artifacts. When the `--json` flag is enabled, the command prints a JSON object instead of only normal console output.

That JSON object reports the paths of the artifacts that Leadtype generated. In website mode, the reported fields include:

- `llmsFullTxt` — path to `llms-full.txt`
- `docsLlmsTxt` — path to the docs-local `llms.txt`
- `llmsTxt` — path to the site-level `llms.txt`
- `agentReadabilityJson` — path to `agent-readability.json`
- `sitemapXml` — path to `sitemap.xml`
- `sitemapMd` — path to `sitemap.md`
- `robotsTxt` — path to `robots.txt`
- `searchIndex` — path to the search index JSON
- `searchContent` — path to the search content JSON

In short, `leadtype generate --json` reports where the generated Leadtype/agent-readability files were written.