# What does `leadtype generate --json` report?

Based on the Leadtype docs site (`/docs/reference/cli.md`):

`leadtype generate` converts docs and writes agent-readable artifacts. The
`--json` flag changes its output: instead of (or in addition to) human-readable
logging, `generate` **prints a JSON object containing the paths of the generated
artifacts**.

## Website mode

When running in the default website mode, the printed JSON object includes
paths for the following artifacts:

- `llmsFullTxt`
- `docsLlmsTxt`
- `llmsTxt`
- `agentReadabilityJson`
- `sitemapXml`
- `sitemapMd`
- `robotsTxt`
- `searchIndex`
- `searchContent`

This makes `--json` useful for scripting and CI, where a build step can read the
JSON output to discover exactly where each generated file was written.

## A note on bundle mode

Bundle mode (`leadtype generate --bundle`, used when publishing an npm package)
writes a different set of files — `AGENTS.md` at the package root and `docs/*.md`
beneath it — and **skips the website-only artifacts** (`llms.txt`,
`llms-full.txt`, search JSON, sitemap files, `robots.txt`, and
`agent-readability.json`). The website-mode JSON keys listed above therefore
correspond to the website-mode artifact set, not bundle mode.

## Sources

- `/docs/reference/cli.md` — describes `generate`, the `--json` flag, and the
  website-mode JSON object fields.
- `/docs/package-docs/bundle.md` — describes bundle mode and the artifacts it
  skips.
