# What `leadtype generate --json` reports

`leadtype generate` converts docs and writes agent-readable artifacts. Among its
flags (`--src`, `--out`, `--base-url`, `--bundle`, `--json`, `--enrich-git`,
`--strict`), the `--json` flag controls the command's output format.

## Behavior

When `--json` is enabled, `generate` prints a **JSON object containing the paths
of the generated artifacts**. In other words, it reports *where* each produced
file was written rather than printing human-readable progress output — which is
ideal for scripting and CI pipelines.

## Reported fields (website mode)

In website mode, the emitted JSON object includes paths for the following
artifacts:

| Field | Artifact it points to |
|---------------------|-----------------------|
| `llmsFullTxt` | The root `/llms-full.txt` file containing every generated markdown docs page |
| `docsLlmsTxt` | The docs-scoped `/docs/llms.txt` map |
| `llmsTxt` | The product-level `/llms.txt` map |
| `agentReadabilityJson` | The `agent-readability.json` artifact |
| `sitemapXml` | The XML sitemap |
| `sitemapMd` | The markdown sitemap |
| `robotsTxt` | The `robots.txt` file |
| `searchIndex` | The static local search index |
| `searchContent` | The search content JSON |

## Notes / caveats

- The field set above describes **website mode**. If you instead run
  `leadtype generate --bundle` (for publishing an npm package), bundle mode
  writes `AGENTS.md` and `docs/*.md` and **skips the website-only artifacts**
  (`llms.txt`, `llms-full.txt`, search JSON, sitemap files, `robots.txt`, and
  `agent-readability.json`) — so those paths would not be part of the reported
  output in that mode.

## Sources

- `/docs/reference/cli.md` — describes `generate`, its flags, and the `--json` output object.
- `/docs/reference/llm.md` — describes the `llms.txt`, `llms-full.txt`, and `agent-readability.json` artifacts.
- `/docs/reference/search.md` — describes the static local search index/content.
- `/docs/package-docs/bundle.md` — describes which artifacts bundle mode skips.
