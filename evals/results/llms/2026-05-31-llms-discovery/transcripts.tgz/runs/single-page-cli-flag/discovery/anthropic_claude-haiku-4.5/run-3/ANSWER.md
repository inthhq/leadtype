# What `leadtype generate --json` Reports

According to the Leadtype documentation, when the `--json` flag is enabled with the `leadtype generate` command, it prints a JSON object with paths for the generated artifacts.

The JSON output includes the following fields in the website-mode object:

- **llmsFullTxt** - Full LLMs text artifact
- **docsLlmsTxt** - Documentation LLMs text artifact
- **llmsTxt** - LLMs text artifact
- **agentReadabilityJson** - Agent readability JSON artifact
- **sitemapXml** - XML sitemap
- **sitemapMd** - Markdown sitemap
- **robotsTxt** - Robots.txt file
- **searchIndex** - Search index artifact
- **searchContent** - Search content artifact

These artifacts are agent-readable files generated from the documentation source, along with various supporting files for SEO and search functionality.
