# Leadtype Vector Index and Embeddings

## Does Leadtype include a hosted database-backed vector index by default?

No. **Leadtype does not include a hosted database-backed vector index by default.**

## What does it use by default?

By default, Leadtype builds a **static local search index** over generated markdown at build time. The default search path uses **lexical BM25-style ranking** over titles, headings, body text, and code. This search index:
- Is generated at build time
- Does not require a database
- Has an edge-safe runtime query path

## When would embeddings be added?

According to the documentation, embeddings should be added only when:
1. **Docs vocabulary does not match user vocabulary**, OR
2. **The corpus grows large enough to need semantic retrieval**

In other words, embeddings are an optional enhancement to add to the default lexical search when semantic capabilities become necessary for better retrieval quality.
