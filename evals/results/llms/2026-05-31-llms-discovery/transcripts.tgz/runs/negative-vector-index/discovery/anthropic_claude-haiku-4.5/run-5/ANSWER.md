# Leadtype Vector Index Question

## Does Leadtype include a hosted database-backed vector index by default?

**No.** Leadtype does not include a hosted database-backed vector index by default.

## What does it use by default?

By default, Leadtype builds a **static local search index** over generated markdown at build time. The default search path uses **lexical BM25-style ranking** over titles, headings, body text, and code.

## Key characteristics of the default approach:

- **Static**: Built at build time, not at runtime
- **Local**: Does not require a database
- **Edge-safe**: The runtime query path is edge-safe and does not require a database
- **Based on lexical ranking**: Uses BM25-style ranking algorithm

## When would embeddings be added?

According to the documentation, embeddings should be added **only when**:

1. **Docs vocabulary does not match user vocabulary** - When the terminology and language used in the documentation differs significantly from what users search for, or
2. **The corpus grows large enough to need semantic retrieval** - When the documentation becomes large enough that semantic (meaning-based) search becomes necessary for better results

In other words, embeddings are an optional enhancement to be added when the lexical search approach is insufficient for your specific use case.
