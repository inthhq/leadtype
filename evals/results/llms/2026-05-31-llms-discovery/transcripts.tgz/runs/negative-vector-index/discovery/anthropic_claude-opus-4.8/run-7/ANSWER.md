# Does Leadtype include a hosted database-backed vector index by default?

**No.** According to the Leadtype docs, Leadtype does **not** include a hosted database-backed vector index by default.

## What it uses by default

Leadtype builds a **static local search index** over the generated markdown at build time. The runtime query path is **edge-safe and does not require a database**.

The default search path uses **lexical, BM25-style ranking** over titles, headings, body text, and code. This search output can feed source-grounded answer generation.

## When would embeddings be added?

Embeddings (semantic retrieval) should be added **only when**:

- The docs vocabulary does not match the user's vocabulary, **or**
- The corpus grows large enough to need semantic retrieval.

In other words, embeddings are an opt-in enhancement for cases where simple lexical matching is insufficient — not part of the default setup.

## Source

- `/docs/reference/search.md` (Search reference)
