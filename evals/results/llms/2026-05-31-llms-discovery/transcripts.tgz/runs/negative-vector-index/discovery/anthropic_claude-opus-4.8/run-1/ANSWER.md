# Does Leadtype include a hosted database-backed vector index by default?

**No.** According to the Leadtype Search reference (`/docs/reference/search.md`), Leadtype does **not** include a hosted database-backed vector index by default.

## What it uses by default

Leadtype builds a **static local search index** over the generated markdown at build time. Key characteristics:

- The default search path uses **lexical BM25-style ranking** over titles, headings, body text, and code.
- The runtime query path is **edge-safe and does not require a database**.
- Search output can feed **source-grounded answer generation**.

## When would embeddings be added?

Embeddings (semantic/vector retrieval) should be added **only when needed**, specifically:

- When the **docs vocabulary does not match the user vocabulary**, or
- When the **corpus grows large enough to need semantic retrieval**.

In other words, embeddings are an opt-in enhancement layered on top of the default lexical search, not a built-in default.

## Source

- `/docs/reference/search.md` ("Search")
