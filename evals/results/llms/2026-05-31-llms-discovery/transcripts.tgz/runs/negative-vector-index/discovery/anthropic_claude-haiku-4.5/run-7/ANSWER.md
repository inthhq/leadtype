# Leadtype Vector Index and Embeddings

## Does Leadtype include a hosted database-backed vector index by default?

**No**, Leadtype does not include a hosted database-backed vector index by default.

## What does it use by default?

Leadtype builds a **static local search index** over generated markdown at build time. This default search implementation:
- Uses **lexical BM25-style ranking** over titles, headings, body text, and code
- Is **edge-safe** and does not require a database at runtime
- Can feed source-grounded answer generation

## When would embeddings be added?

According to the documentation, embeddings should be added only when:
1. **Docs vocabulary does not match user vocabulary**, OR
2. **The corpus grows large enough to need semantic retrieval**

In other words, embeddings are an optional enhancement that should be added when the default lexical search approach is insufficient for your specific use case.
