# Leadtype Vector Index and Embeddings

## Does Leadtype include a hosted database-backed vector index by default?

**No.** Leadtype does not include a hosted database-backed vector index by default.

## What does it use by default?

By default, Leadtype builds a **static local search index** over generated markdown at build time. The default search path uses **lexical BM25-style ranking** over titles, headings, body text, and code. The runtime query path is edge-safe and does not require a database.

## When would embeddings be added?

According to the documentation, embeddings should be added **only when**:
1. The docs vocabulary does not match user vocabulary, OR
2. The corpus grows large enough to need semantic retrieval

In other words, embeddings are an optional enhancement that should be added when the static lexical search approach proves insufficient for the specific use case.

---

**Source**: [Leadtype Search Reference Documentation](/docs/reference/search.md)
