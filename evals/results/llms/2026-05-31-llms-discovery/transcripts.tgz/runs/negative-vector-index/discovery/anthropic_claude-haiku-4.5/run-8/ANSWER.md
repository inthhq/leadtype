# Does Leadtype Include a Hosted Database-Backed Vector Index by Default?

No, Leadtype does not include a hosted database-backed vector index by default.

## What Does It Use by Default?

Leadtype builds a **static local search index** over generated markdown at build time. The default search approach uses **lexical BM25-style ranking** over titles, headings, body text, and code. This runtime query path is edge-safe and does not require a database.

## When Would Embeddings Be Added?

Embeddings should be added only when:
1. **Docs vocabulary does not match user vocabulary** - When the terms users search for differ significantly from the terminology used in the documentation
2. **The corpus grows large enough to need semantic retrieval** - When the documentation becomes so large that semantic search becomes necessary for good results

In other words, embeddings are an optional enhancement that should be added based on specific needs, rather than being included by default.
