No. Leadtype does **not** include a hosted database-backed vector index by default.

By default, it builds a **static local search index** over generated Markdown at build time, and queries it with an edge-safe runtime path that does not require a database. The default ranking is **lexical BM25-style search** over titles, headings, body text, and code.

Embeddings would be added only when the docs vocabulary does not match user vocabulary, or when the corpus grows large enough to need semantic retrieval.
