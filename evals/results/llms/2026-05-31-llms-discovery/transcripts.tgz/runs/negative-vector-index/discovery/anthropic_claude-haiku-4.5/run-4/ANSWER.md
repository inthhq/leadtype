# Leadtype Vector Index Configuration

## Answer

**No**, Leadtype does **not** include a hosted database-backed vector index by default.

## What It Uses By Default

By default, Leadtype builds a **static local search index** over generated markdown at build time. This search uses **lexical BM25-style ranking** over:
- Titles
- Headings
- Body text
- Code

The runtime query path is edge-safe and does not require a database.

## When Embeddings Would Be Added

According to the Leadtype documentation, embeddings should be added only when:

1. **Docs vocabulary does not match user vocabulary**, OR
2. **The corpus grows large enough to need semantic retrieval**

In other words, embeddings should be considered when the lexical search approach becomes insufficient for finding relevant content, either because of vocabulary mismatch or scale considerations.

---

**Source**: [/docs/reference/search.md](docs/reference/search.md)
