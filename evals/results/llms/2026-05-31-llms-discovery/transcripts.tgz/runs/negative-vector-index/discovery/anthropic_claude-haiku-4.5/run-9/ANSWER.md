# Leadtype Vector Index Implementation

## Answer

**No, Leadtype does not include a hosted database-backed vector index by default.**

## What It Uses By Default

Leadtype builds a **static local search index** at build time using **lexical BM25-style ranking** over:
- Titles
- Headings
- Body text
- Code

This search index:
- Is built at build time during the documentation generation process
- Has an edge-safe runtime query path
- Does not require a database

## When Embeddings Would Be Added

According to the Leadtype documentation, embeddings should be added **only when:**

1. **Docs vocabulary does not match user vocabulary** - If the terminology in your docs doesn't align with how users search for information, or
2. **The corpus grows large enough to need semantic retrieval** - When your documentation becomes substantial enough that keyword-based search becomes insufficient

This is a pragmatic approach that avoids unnecessary complexity and infrastructure overhead for most documentation sites.
