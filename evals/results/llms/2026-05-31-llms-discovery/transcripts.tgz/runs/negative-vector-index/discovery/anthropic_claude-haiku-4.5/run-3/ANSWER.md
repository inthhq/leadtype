# Leadtype Vector Index and Embeddings

## Does Leadtype include a hosted database-backed vector index by default?

No. Leadtype does not include a hosted database-backed vector index by default.

## What does it use by default?

Leadtype builds a **static local search index** over generated markdown at build time. The default search mechanism uses **lexical BM25-style ranking** over titles, headings, body text, and code. This approach:

- Is edge-safe and does not require a database
- Operates at runtime with a local static index
- Can feed into source-grounded answer generation

## When would embeddings be added?

Embeddings should only be added when:

1. **Docs vocabulary does not match user vocabulary** - When semantic understanding is needed to bridge the gap between how documentation is written and how users search for information
2. **The corpus grows large enough to need semantic retrieval** - When the volume of documentation becomes too large for efficient lexical search alone

This design philosophy prioritizes simplicity and performance by default while allowing optional semantic search capabilities when specifically needed.
