# Agent-facing output APIs on the Leadtype docs site

## Which docs area to use

Use the **Reference → LLM files** page: [`/docs/reference/llm.md`](/docs/reference/llm.md) (reached via the Reference topic in `/llms-full.txt`).

That page documents the agent-facing output APIs (not the search UI):

- `generateLlmsTxt` — writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` map for hosted websites.
- `generateLLMFullContextFiles` — writes the single root `/llms-full.txt` containing every generated markdown docs page. Groups organize `llms.txt` sections, navigation, search metadata, and AGENTS.md, but are **not** published as per-group full-context files by default.
- `generateAgentsMd` — writes `AGENTS.md` for npm-bundled docs. It intentionally ignores `product.agentGuidance` because that text is for website URL routing.
- `isAgentReadabilityArtifactPath` — identifies artifact paths that should not be rewritten as missing markdown pages (covers `llms.txt`, `llms-full.txt`, sitemap files, `robots.txt`, search JSON, and `agent-readability.json`).

Guidance from the same page: **use groups for routing, not sharding**; group descriptions should be routing hints, not marketing copy.

The sibling page `/docs/reference/search.md` is about the static search index / ranking and source-grounded answers — that is the search surface, so skip it for this task.

## When to use the monolithic `/llms-full.txt` fallback

`/llms.txt` itself tells agents to "read the full-context router, then choose the smallest topic file that matches the task." So the intended flow is:

1. Start at `/llms.txt`.
2. Follow it to the **Full Context Router** at `/llms-full.txt`, which routes to topic-specific deep-context files under `/docs/llms-full/*.txt` (Get Started, Authoring, Build, Ship Package Docs, Reference).
3. Pick the smallest topic file that matches the task.

The **monolithic root `/llms-full.txt`** (produced by `generateLLMFullContextFiles`, containing every generated markdown docs page) is a **fallback**. Use it only when:

- The topic-specific full-context files are not sufficient or not available, and you need every docs page in one document.
- An agent cannot do multi-hop fetching and needs a single concatenated bundle.
- You are doing a broad cross-topic task where narrowing to one topic file would lose needed context.

For any task that maps cleanly to one topic (Get Started, Authoring, Build, Ship Package Docs, Reference), prefer the smallest matching `/docs/llms-full/<topic>.txt` over the monolithic bundle. Likewise, Leadtype does not publish per-group full-context files by default — don't try to shard via groups; reach for the root `/llms-full.txt` only as the catch-all fallback.
