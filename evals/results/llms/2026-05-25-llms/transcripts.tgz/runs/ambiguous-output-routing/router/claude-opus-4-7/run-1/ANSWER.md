# Agent-Facing Output APIs in Leadtype Docs

## Which docs area to use

Use the **Reference** area, specifically **`/docs/reference/llm.md`** (LLM files). It is the section dedicated to the agent-facing output APIs:

- `generateLlmsTxt` — writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` routing map for hosted websites.
- `generateLLMFullContextFiles` — writes the single root `/llms-full.txt` containing every generated markdown docs page.
- `generateAgentsMd` — writes `AGENTS.md` for npm-bundled docs (intentionally ignores `product.agentGuidance`, which is for website URL routing).
- `isAgentReadabilityArtifactPath` — identifies artifact paths (llms.txt, llms-full.txt, sitemap files, robots.txt, search JSON, agent-readability.json) that should not be rewritten as missing markdown pages.

Explicitly **not** the search area: `/docs/reference/search.md` covers the static BM25 search index and source-grounded answers — that is the search UI/retrieval surface, not the agent output API surface.

Related supporting docs:
- `/docs/reference/cli.md` — the `leadtype generate` flags and `--json` output that emit these artifacts (`llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, `agentReadabilityJson`, …).
- `/docs/build/connect-docs-site.md` — how to serve these artifacts as static files in website mode.

## When to use the monolithic `/llms-full.txt` fallback

`/llms-full.txt` is the **full-context router / fallback**. Per `llms.txt` and `llms-full.txt`, the intended flow is:

1. **Start at `/llms.txt`** for the product-level entry point.
2. **Read `/llms-full.txt`** as the router that points to topic-specific deep-context files (`/docs/llms-full/*.txt`).
3. **Choose the smallest topic file** that matches the task (e.g., `reference.txt` for API surface).

So use the monolithic `/llms-full.txt` as a fallback when:

- You don't yet know which topic file to read, and you need it to **route you** to the right deep-context bundle.
- A topic-scoped bundle doesn't sufficiently cover the task and you need every generated markdown page in one document.
- You are an agent loading the whole corpus in one fetch (single-file ingestion).

Do **not** default to `/llms-full.txt` when a smaller topic file (e.g., `/docs/llms-full/reference.txt`) already answers the task — the docs explicitly direct you to prefer the smallest matching topic file. Groups exist for routing, not sharding, and per-group full-context files are not published by default; the monolithic file is the single root catch-all.
