# Leadtype: Agent-Facing Output APIs & When to Use `/llms-full.txt`

## Which docs area covers the agent-facing output APIs?

Use the **Reference** area, specifically the **LLM files** page:

- **`/docs/reference/llm.md`** — This is the primary reference for the agent-facing output APIs. It documents:
  - `generateLlmsTxt` — writes `/llms.txt` (product-level) and `/docs/llms.txt` (docs-scoped map) for hosted websites.
  - `generateLLMFullContextFiles` — writes the single root `/llms-full.txt` containing every generated markdown docs page.
  - `generateAgentsMd` — writes `AGENTS.md` for npm-bundled docs (intentionally ignores `product.agentGuidance`, which is intended for website URL routing).
  - `isAgentReadabilityArtifactPath` — identifies artifact paths (e.g. `llms.txt`, `llms-full.txt`, sitemap files, `robots.txt`, search JSON, `agent-readability.json`) that should not be rewritten as missing markdown pages.

The **Build** area (`/docs/build/connect-docs-site.md`) is complementary: it explains how to wire the site so agents can discover and fetch these artifacts (serving markdown on `Accept: text/markdown`, keeping static artifacts at the correct paths, etc.).

The **Search** reference (`/docs/reference/search.md`) covers the *search index* pipeline — that is the search UI / lexical BM25 index, **not** the agent-facing LLM bundles — so it is out of scope for agent-facing output APIs.

---

## When should you use the monolithic `/llms-full.txt` fallback?

According to the docs, `/llms-full.txt` is the **full-context router fallback**: it contains *every* generated markdown docs page in one file. Use it when:

1. **No smaller topic file covers your task.** The recommended workflow (per `llms.txt` and `llms-full.txt`) is to start at `/llms-full.txt` to identify the smallest matching topic file, then fetch only that file. Only fall back to consuming `llms-full.txt` itself if none of the topic-specific files (Get Started, Authoring, Build, Package Docs, Reference) are sufficient.

2. **You need cross-cutting context across multiple topics at once.** Because `/llms-full.txt` is not split by group (groups organize navigation and `llms.txt` sections, but the root full-context file always contains all pages), it is the right choice when a task spans several docs areas and loading individual topic files would be more expensive or incomplete.

3. **Agent token budget allows it.** Since it is the largest single artifact, prefer a topic file first to stay within context limits; reach for `/llms-full.txt` only when breadth is required or when the topic routing is ambiguous.

> **Key rule from the docs:** *"Choose the smallest topic file that matches the task."* `/llms-full.txt` is the last resort, not the starting point.
