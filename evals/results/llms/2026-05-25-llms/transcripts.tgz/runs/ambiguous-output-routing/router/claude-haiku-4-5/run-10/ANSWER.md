# Agent-Facing Output APIs in Leadtype Docs

## Which Docs Area to Use

For agent-facing output APIs, use the **[Reference](/docs/reference/llm.md)** documentation area, specifically the **LLM files** section.

## Agent-Facing APIs

The Leadtype docs site exposes the following agent-readable APIs:

1. **`/llms.txt`** - The primary product-level discovery file and root router
2. **`/docs/llms.txt`** - The docs-scoped map for hosted websites
3. **`/docs/sitemap.xml`** - Static XML sitemap for structured discovery
4. **Markdown mirrors** - Generated markdown files served under `/docs/*.md` with text/markdown content-type negotiation
5. **Search artifacts** - Static search index and search content JSON
6. **`agent-readability.json`** - Metadata about which artifacts are agent-facing

These are **NOT** search UI APIs—they are structured, machine-readable output files designed for agents to discover and navigate documentation content.

## When to Use `/llms-full.txt` Fallback

Use the monolithic **`/llms-full.txt`** fallback in these situations:

- **When you need complete context without multiple requests**: `/llms-full.txt` contains every generated markdown docs page in a single file
- **When scoped routing fails**: If the topic-specific `/llms.txt` routing doesn't cover your needs, fall back to the full context
- **For comprehensive deep-context tasks**: When building complex agent workflows that benefit from seeing all documentation at once

In contrast, the primary `/llms.txt` uses **groups to organize routing**, following the principle "use groups for routing, not sharding." This means you should start with `/llms.txt` for intelligent routing and only use `/llms-full.txt` when you need the monolithic complete-context fallback.

## Summary

- **Primary approach**: Use `/llms.txt` for routing → topic-specific markdown pages
- **Fallback approach**: Use `/llms-full.txt` when you need complete context in a single file
