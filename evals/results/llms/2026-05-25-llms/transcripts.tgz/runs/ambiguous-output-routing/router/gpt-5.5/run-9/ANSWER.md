Use the **Reference** docs area, specifically **LLM files**: `/docs/reference/llm.md`.

That page covers the agent-facing output APIs and artifacts:

- `generateLlmsTxt` for root `/llms.txt` and `/docs/llms.txt`
- `generateLLMFullContextFiles` for `/llms-full.txt`
- `generateAgentsMd` for bundled `AGENTS.md`
- `isAgentReadabilityArtifactPath` for recognizing agent-readability artifacts

Do **not** use the Search docs area for this task unless you are working on Leadtype’s static search index or source-grounded search/answer behavior. Search is about query/index behavior, not the agent-facing output file APIs.

Use the monolithic `/llms-full.txt` fallback only when the router cannot point you to a smaller, task-specific context file, or when you genuinely need all generated markdown docs in one file. Prefer the smallest matching topic/page first; for these APIs, that is `/docs/reference/llm.md`.