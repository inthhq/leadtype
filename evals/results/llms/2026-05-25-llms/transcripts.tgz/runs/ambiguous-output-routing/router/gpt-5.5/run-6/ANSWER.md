# Which Leadtype docs area to use

Use **Reference → LLM files**: `/docs/reference/llm.md`.

That is the agent-facing output API area. It covers APIs and artifacts such as:

- `generateLlmsTxt` for `/llms.txt` and `/docs/llms.txt`
- `generateLLMFullContextFiles` for the root `/llms-full.txt`
- `generateAgentsMd` for npm-bundled `AGENTS.md`
- `isAgentReadabilityArtifactPath` for recognizing generated agent/readability artifacts

Do **not** use the Search docs for this task. `/docs/reference/search.md` is about the static search index, source-grounded answers, and embeddings—not the agent-facing output artifact APIs.

If you also need hosted-site serving behavior, pair this with **Build → Connect a docs site** (`/docs/build/connect-docs-site.md`), which explains serving `/llms.txt`, `/llms-full.txt`, markdown mirrors, sitemaps, robots, search JSON, and `agent-readability.json` as static/markdown-friendly artifacts.

## When to use `/llms-full.txt`

Prefer the smallest relevant routed file first: start at `/llms.txt`, follow the router, and read the narrowest topic/page that matches the task.

Use the monolithic root `/llms-full.txt` fallback only when:

- you cannot determine the right smaller topic from `/llms.txt`,
- the task genuinely spans many docs areas, or
- an agent/tool needs the entire generated markdown corpus in one file.

Do not treat groups as separate full-context shards by default. In Leadtype, groups are routing/navigation hints; the full-context fallback is the single root `/llms-full.txt`.