# Which Leadtype docs area to use for agent-facing output APIs

## Use: `/docs/reference/llm.md` (the "LLM files" reference page)

Per `/llms.txt` → `/llms-full.txt`, the Reference topic (`/docs/llms-full/reference.txt`) explicitly covers "CLI flags, conversion APIs, **LLM bundle APIs**, search, and lint reference." Within that topic, the page dedicated to agent-facing output APIs is:

- **`/docs/reference/llm.md`** — "Generate llms.txt, the root full-context fallback, and AGENTS.md."

That page documents the agent-output APIs you want:

- `generateLlmsTxt` — writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` map for hosted websites.
- `generateLLMFullContextFiles` — writes the single root `/llms-full.txt` containing every generated markdown docs page. (Groups organize `llms.txt` sections, nav, search metadata, and AGENTS.md — they are **not** published as per-group full-context files by default.)
- `generateAgentsMd` — writes `AGENTS.md` for npm-bundled docs. It intentionally ignores `product.agentGuidance` (that text is for website URL routing).
- `isAgentReadabilityArtifactPath` — identifies artifact paths (llms.txt, llms-full.txt, sitemaps, robots.txt, search JSON, agent-readability.json) so they aren't rewritten as missing markdown pages.

**Do not** use `/docs/reference/search.md` for this — that page covers the static BM25 search index, source-grounded answers, and optional embeddings (i.e., the search UI/retrieval path, not agent output APIs).

Supporting context: `/docs/build/connect-docs-site.md` confirms these are served as static artifacts at the site root in website mode (`/llms.txt`, `/llms-full.txt`, sitemaps, `robots.txt`, search JSON, `agent-readability.json`), and `/docs/reference/cli.md` shows that `leadtype generate --json` emits the resulting paths (`llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, `agentReadabilityJson`, etc.).

## When to use the monolithic `/llms-full.txt` fallback

`/llms.txt` itself instructs: *"Read the full-context router, then choose the smallest topic file that matches the task."* The router at `/llms-full.txt` then routes to topic-specific deep-context files (Get Started, Authoring, Build, Ship Package Docs, Reference).

So the routing discipline is:

1. **Prefer the smallest topic file** that matches the task — e.g., `/docs/llms-full/reference.txt`, or an even narrower page like `/docs/reference/llm.md`.
2. **Fall back to the monolithic root `/llms-full.txt`** only when:
   - The task spans multiple topics and no single topic file is sufficient, or
   - You don't yet know which topic applies and need the router/index of available deep-context files, or
   - You explicitly need every generated markdown docs page in one bundle (which is what `generateLLMFullContextFiles` produces — the whole-corpus artifact, not per-group shards).

The guiding principle from `/docs/reference/llm.md`: **"Use groups for routing, not sharding."** Treat `/llms-full.txt` as the routing fallback / whole-corpus bundle, not as your default entry point.
