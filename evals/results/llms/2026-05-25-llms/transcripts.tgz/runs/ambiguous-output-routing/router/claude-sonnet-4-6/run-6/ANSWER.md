# Using Leadtype Docs for Agent-Facing Output APIs

## Which docs area to use

For **agent-facing output APIs** (not search UI), use the **Reference** topic:

**`/docs/llms-full/reference.txt`** → and specifically the **LLM files** page at `/docs/reference/llm.md`.

This page documents the three core agent-output APIs:

| API | Purpose |
|-----|---------|
| `generateLlmsTxt` | Writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` map for hosted websites. |
| `generateLLMFullContextFiles` | Writes the root `/llms-full.txt` file containing every generated markdown docs page. |
| `generateAgentsMd` | Writes `AGENTS.md` for npm-bundled docs. |

Also relevant in Reference is the **CLI** page (`/docs/reference/cli.md`), which covers the `--bundle`, `--json`, and related flags that control how those artifacts are produced at build time (the `--json` output object includes `llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, `agentReadabilityJson`, etc.).

The **Search** page in the same Reference section (`/docs/reference/search.md`) covers the *static search index*, which is a build-time, lexical/BM25-style artifact—**not** an agent-output API. Skip it if you only need the LLM/agent bundle APIs.

## When to use the monolithic `/llms-full.txt` fallback

Use `/llms-full.txt` when:

- You need the **full content of every generated markdown page in one request** and cannot (or do not want to) determine which smaller topic file matches the task.
- The task spans **multiple topics at once** (e.g., authoring + build + reference), making a single topic file insufficient.
- You are working in a context where **routing hints in `/llms.txt` are ambiguous** or the topic-specific files are unavailable.

In all other cases, prefer the **smallest matching topic file** from the Full Context Router (`/llms-full.txt` lists them). This keeps token usage low and context focused. The docs themselves state:

> "Read the full-context router, then choose the smallest topic file that matches the task."

The monolithic file is explicitly a **fallback** for when that narrower routing is not possible.
