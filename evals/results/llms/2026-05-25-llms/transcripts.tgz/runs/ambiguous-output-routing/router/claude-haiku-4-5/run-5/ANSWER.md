# Agent-Facing Output APIs for Leadtype

## Which Docs Area to Use

Use the **[/docs/reference/llm.md](/docs/reference/llm.md)** documentation page for agent-facing output APIs.

This page covers the APIs that generate agent-readable artifacts:
- `generateLlmsTxt` - Generates the product-level `/llms.txt` and docs-scoped `/docs/llms.txt` map for hosted websites
- `generateLLMFullContextFiles` - Generates the root `/llms-full.txt` file
- `generateAgentsMd` - Generates `AGENTS.md` for npm-bundled docs
- `isAgentReadabilityArtifactPath` - Identifies artifact paths for agent-readable outputs

## When to Use the `/llms-full.txt` Fallback

Use the monolithic **`/llms-full.txt`** fallback when:

1. **You need the complete context** - When you want every generated markdown docs page in a single file for comprehensive understanding
2. **You need full-context routing** - The `/llms-full.txt` serves as a router that helps you choose the smallest topic-specific file that matches your task
3. **You don't yet know which specific topic you need** - Start at `/llms.txt`, then if you need deeper context about a specific topic, consult `/llms-full.txt` to find the right reference section

According to the Leadtype documentation, the workflow is: "Read the full-context router, then choose the smallest topic file that matches the task."

For agent-facing APIs specifically, however, you should use the **specific reference documentation** at `/docs/reference/llm.md` rather than the full monolithic fallback, as it contains the focused API documentation you need.
