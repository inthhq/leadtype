# Leadtype: Agent-Facing Output APIs — Which Docs Area to Use

## The Right Docs Area: **Reference → LLM files**

For agent-facing output APIs (not search UI), use the **Reference** section, specifically the **[LLM files](/docs/reference/llm.md)** page (`/docs/reference/llm.md`).

This page documents the three core agent-output APIs:

| API | What it does |
|-----|-------------|
| `generateLlmsTxt` | Writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` map for hosted websites. |
| `generateLLMFullContextFiles` | Writes one root `/llms-full.txt` file containing every generated markdown docs page. Groups organize sections but are **not** published as per-group full-context files by default. |
| `generateAgentsMd` | Writes `AGENTS.md` for npm-bundled docs. Intentionally ignores `product.agentGuidance` because that text is written for website URL routing. |

Also useful from Reference: the **[CLI](/docs/reference/cli.md)** page, which documents the `--json` flag for `leadtype generate`. When `--json` is enabled, the generator prints a JSON object listing the paths of all generated artifacts (`llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, `agentReadabilityJson`, `sitemapXml`, `sitemapMd`, `robotsTxt`, `searchIndex`, `searchContent`).

The **[Build → Connect a docs site](/docs/build/connect-docs-site.md)** page is also relevant if you need to know *how* those artifacts are wired and served (e.g. serving markdown on `Accept: text/markdown`, keeping artifact paths static, etc.).

---

## When to Use the Monolithic `/llms-full.txt` Fallback

Use `/llms-full.txt` when **no single topic file is small enough to cover your task**, i.e. when the task spans multiple topic areas simultaneously and you cannot narrow it to one of the topic-specific files:

- [`/docs/llms-full/get-started.txt`](/docs/llms-full/get-started.txt) — install, quickstart, how it works
- [`/docs/llms-full/authoring.txt`](/docs/llms-full/authoring.txt) — frontmatter, groups, MDX components
- [`/docs/llms-full/build.txt`](/docs/llms-full/build.txt) — docs-site wiring, deployment artifacts
- [`/docs/llms-full/package-docs.txt`](/docs/llms-full/package-docs.txt) — npm tarball / AGENTS.md bundling
- [`/docs/llms-full/reference.txt`](/docs/llms-full/reference.txt) — CLI, LLM bundle APIs, search, lint

The canonical guidance from `/llms.txt` is:

> *"Read the full-context router, then choose the **smallest topic file** that matches the task."*

So `/llms-full.txt` itself is just the **router** — it lists the topic files and their descriptions so an agent can pick the right one. Reach for a monolithic full-context dump only as a last resort when:

1. The task genuinely cuts across all topics (e.g. a full audit of the entire pipeline).
2. The relevant topic file has been read but is insufficient and you need to cross-reference multiple areas at once.
3. A specific topic file is unavailable or not granular enough for the question.

In practice, for agent-facing output APIs specifically, `/docs/llms-full/reference.txt` is the right starting point — it is the smallest file that contains the LLM bundle APIs, CLI flags, and search reference all in one place, without pulling in unrelated authoring or get-started content.
