# Answer

Use the **Reference** docs area, specifically **Reference → LLM files** (`/docs/reference/llm.md`), for the agent-facing output APIs. That page covers the APIs/artifacts meant for agents:

- `generateLlmsTxt` for `/llms.txt` and `/docs/llms.txt`
- `generateLLMFullContextFiles` for the root `/llms-full.txt` fallback
- `generateAgentsMd` for package-bundled `AGENTS.md`
- `isAgentReadabilityArtifactPath` for recognizing generated agent-readability/static artifact paths

Do **not** use the Search docs area if your goal is agent-facing output APIs. Search is about the static search index and source-grounded answer/search behavior, not the primary agent-readable routing/output files.

For hosted docs-site wiring, pair that with **Build → Connect a docs site** (`/docs/build/connect-docs-site.md`), which explains serving `/llms.txt`, `/llms-full.txt`, markdown mirrors, sitemaps, robots, search JSON, and `agent-readability.json` as static artifacts.

Use the monolithic **`/llms-full.txt`** fallback only when a smaller routed context is not enough: start at `/llms.txt`, follow the full-context router, and choose the smallest topic-specific file that matches the task. Fall back to the root `/llms-full.txt` when the task is broad, crosses topic boundaries, or the agent/client needs one complete file containing all generated markdown docs.