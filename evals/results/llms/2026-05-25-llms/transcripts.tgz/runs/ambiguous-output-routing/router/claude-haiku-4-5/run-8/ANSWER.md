# Agent-Facing Output APIs in Leadtype Docs

## Which docs area to use

For **agent-facing output APIs**, use the **[Reference](/docs/reference/)** documentation area, specifically:

- **[LLM files](/docs/reference/llm.md)** - Documents the agent-readable output APIs:
  - `generateLlmsTxt()` - Generates product-level `/llms.txt` and docs-scoped `/docs/llms.txt` maps
  - `generateLLMFullContextFiles()` - Generates the root `/llms-full.txt` file
  - `generateAgentsMd()` - Generates `AGENTS.md` for npm-bundled docs
  - `isAgentReadabilityArtifactPath()` - Identifies artifact paths for agent consumption

- **[CLI](/docs/reference/cli.md)** - Documents the CLI commands and JSON output for agent-readable artifacts

This is the **not search UI** — these are the programmatic output APIs that agents consume.

## When to use `/llms-full.txt` fallback

Use the **monolithic `/llms-full.txt` fallback** in these scenarios:

1. **When context-aware routing is unavailable** - The `/llms-full.txt` file contains every generated markdown docs page as a single document, making it useful when agents cannot follow topic-specific routing

2. **For bootstrapping** - Agents can start at `/llms.txt` (the full-context router) which then directs them to topic-specific files like `/docs/llms-full/reference.txt`. If that routing fails, they fall back to `/llms-full.txt` for complete context

3. **As documented in `/llms.txt`** - The root `llms.txt` itself states: "Read the full-context router, then choose the smallest topic file that matches the task" with `/llms-full.txt` as the comprehensive fallback option

## Summary

- **Use `/docs/reference/llm.md`** for agent-facing output API documentation
- **Use `/llms-full.txt` fallback** when the agent cannot navigate the topic-specific router structure or needs complete unscoped context
