# Leadtype docs: Agent-facing output APIs

## Which docs area to use

Use the **Reference** area, specifically **`/docs/reference/llm.md`** (LLM files). It documents the agent-facing output APIs that produce agent-readable artifacts:

- **`generateLlmsTxt`** — writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` map for hosted websites.
- **`generateLLMFullContextFiles`** — writes the single root `/llms-full.txt` containing every generated markdown docs page. (Groups organize `llms.txt` sections, navigation, search metadata, and AGENTS.md — they are not published as per-group full-context files by default.)
- **`generateAgentsMd`** — writes `AGENTS.md` for npm-bundled docs. It deliberately ignores `product.agentGuidance` (that field is for website URL routing).
- **`isAgentReadabilityArtifactPath`** — identifies artifact paths that should not be rewritten as missing markdown pages (covers `llms.txt`, `llms-full.txt`, sitemap files, `robots.txt`, search JSON, and `agent-readability.json`).

The neighboring `/docs/reference/cli.md` page covers how these artifacts are emitted by `leadtype generate` (e.g. the `--json` output includes `llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, `agentReadabilityJson`, etc.).

Explicitly **not** this area: `/docs/reference/search.md`. That page covers the search index / search UI side (BM25 ranking, optional embeddings), which is the search UI concern, not the agent output APIs.

## When to use the monolithic `/llms-full.txt` fallback

The intended flow from `/llms.txt` is:

1. Read `/llms.txt` (the entry point).
2. Follow it to `/llms-full.txt`, which is the **Full Context Router** — it routes to topic-specific deep-context files (Get Started, Authoring, Build, Ship Package Docs, Reference).
3. Pick the **smallest topic file** that matches the task (e.g. `/docs/llms-full/reference.txt` for the agent output APIs above).

Use the monolithic `/llms-full.txt` as a **fallback** only when:

- The agent/client cannot follow the router to per-topic files, or you need a single self-contained bundle to hand to a model.
- You genuinely need every generated markdown docs page in one place (it contains the full corpus by design via `generateLLMFullContextFiles`).
- You're verifying or debugging the full agent-readable artifact set produced by `leadtype generate` (the `llmsFullTxt` path in `--json` output).

In normal use, prefer the routed topic file over the monolithic bundle — the docs explicitly tell agents to "choose the smallest topic file that matches the task."
