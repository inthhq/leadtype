# Agent-Facing Output APIs in Leadtype

## Which docs area to use

For agent-facing output APIs (not search UI), use the **Reference → LLM files** section:

**`/docs/reference/llm.md`** (also surfaced in `/docs/llms-full/reference.txt`)

This page documents the four key agent-output APIs:

| API | What it does |
|---|---|
| `generateLlmsTxt` | Writes the product-level `/llms.txt` **and** the docs-scoped `/docs/llms.txt` routing map for hosted websites. |
| `generateLLMFullContextFiles` | Writes the single root `/llms-full.txt` file that concatenates every generated markdown docs page into one bundle. Groups organise `llms.txt` sections, navigation, search metadata, and `AGENTS.md`, but are **not** published as per-group full-context files by default. |
| `generateAgentsMd` | Writes `AGENTS.md` for npm-bundled docs. Intentionally ignores `product.agentGuidance` because that text is written for website URL routing, not package consumption. |
| `isAgentReadabilityArtifactPath` | Identifies artifact paths (`llms.txt`, `llms-full.txt`, sitemap files, `robots.txt`, search JSON, `agent-readability.json`) that must **not** be rewritten as missing markdown pages. |

> **Tip:** Group descriptions in `llms.txt` are routing hints for agents, not marketing copy. Use groups for routing, not sharding.

The **Search** reference (`/docs/reference/search.md`) describes the *search index* (BM25-style lexical ranking, edge-safe, no database), which is a separate concern from agent-readable file generation. Avoid it unless you are wiring up source-grounded answer generation or deciding whether to add embeddings.

---

## When to use the monolithic `/llms-full.txt` fallback

Use `/llms-full.txt` when:

1. **No topic file is a clear match.** The router at `/llms-full.txt` lists five topic-specific files (Get Started, Authoring, Build, Ship Package Docs, Reference). If the task spans several of those topics or doesn't fit any single one, fall back to the full-context file rather than guessing a topic file.
2. **You need cross-cutting context in a single pass.** `/llms-full.txt` contains every generated markdown docs page concatenated, so it is useful when the agent needs to reason across multiple topics simultaneously without making multiple fetches.
3. **Topic files are unavailable or the routing map is stale.** If a specific topic `.txt` file can't be resolved, `/llms-full.txt` is the safe fallback because it is always kept in sync with the full build output.

The docs explicitly instruct: *"Read the full-context router, then choose the **smallest** topic file that matches the task."* In other words, prefer a small topic file for efficiency; use `/llms-full.txt` only when no single topic file is sufficient.
