Use the **Reference** docs area, specifically **LLM files**:

- Deep-context topic: `/docs/llms-full/reference.txt`
- Page: `/docs/reference/llm.md`

That area covers the agent-facing output APIs and artifacts, including `generateLlmsTxt`, `generateLLMFullContextFiles`, `generateAgentsMd`, and `isAgentReadabilityArtifactPath`. Do **not** use the Search area for this need; Search is about the static search index and source-grounded answer/search behavior, not the agent-readable output APIs.

Use the monolithic `/llms-full.txt` only as a fallback/router when you cannot identify a smaller matching topic file, or when you truly need the root full-context bundle containing every generated markdown docs page. The preferred workflow is to start at `/llms.txt`, consult `/llms-full.txt` to route, and then read the smallest relevant topic file—in this case, the Reference topic and its LLM files page.