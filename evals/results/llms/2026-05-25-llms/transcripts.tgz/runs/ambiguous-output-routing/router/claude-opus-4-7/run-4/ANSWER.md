# Leadtype docs: agent-facing output APIs vs. the `/llms-full.txt` fallback

## TL;DR

- **Use the Reference area** — specifically [`/docs/reference/llm.md`](/docs/reference/llm.md) (with [`/docs/reference/cli.md`](/docs/reference/cli.md) for invocation). That is where the agent-facing output APIs live.
- **Avoid `/docs/reference/search.md`** for this task; it covers the search index / query UI, not agent output.
- **Reach for the monolithic `/llms-full.txt`** only as a router/fallback when you cannot narrow to a single topic file, or when a tool needs every generated markdown page in one document.

## Which docs area to use

Per `/llms.txt`, the intended workflow is:

> Read the full-context router, then choose the **smallest topic file** that matches the task.

The router at `/llms-full.txt` lists five topic bundles. For "agent-facing output APIs," the right topic is **Reference** (`/docs/llms-full/reference.txt`), and within Reference the relevant pages are:

| Page | Why it matters for agent output APIs |
|---|---|
| `/docs/reference/llm.md` | Documents the actual agent-output APIs: `generateLlmsTxt`, `generateLLMFullContextFiles`, `generateAgentsMd`, and `isAgentReadabilityArtifactPath`. |
| `/docs/reference/cli.md` | Documents `leadtype generate` flags (`--bundle`, `--json`, etc.) and the JSON output object listing artifact paths: `llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, `agentReadabilityJson`, `sitemapXml`, `sitemapMd`, `robotsTxt`, `searchIndex`, `searchContent`. |
| ~~`/docs/reference/search.md`~~ | **Skip** — this is the search index / BM25 / embeddings page (search UI concern), not an agent output API. |

The **Build** topic (`/docs/llms-full/build.txt`) is also relevant if you need wiring/deployment context for the agent-readable artifacts, but the API surface itself is documented under Reference.

## When to use the monolithic `/llms-full.txt` fallback

`/llms-full.txt` is the **Full Context Router** — it points to topic-specific deep-context files rather than being the primary read. Use it as a fallback when:

1. **You don't yet know which topic file applies.** Read it first to route to the smallest matching topic file (per the guidance in `/llms.txt`).
2. **A task spans multiple topics** (e.g., authoring + build + reference) and narrowing to one topic file would drop necessary context.
3. **A tool/agent needs the entire corpus in one document.** Per `/docs/reference/llm.md`, `generateLLMFullContextFiles` writes "one root `/llms-full.txt` file containing every generated markdown docs page." Groups are routing hints, **not** shards — there are no per-group full-context files by default, so `/llms-full.txt` is the single monolithic bundle when you need everything.
4. **Topic files are unavailable or stale** — fall back to the root bundle as the canonical, comprehensive source.

For the specific question (agent-facing output APIs), you do **not** need the monolithic fallback: go straight to `/docs/reference/llm.md` (and `/docs/reference/cli.md`).
