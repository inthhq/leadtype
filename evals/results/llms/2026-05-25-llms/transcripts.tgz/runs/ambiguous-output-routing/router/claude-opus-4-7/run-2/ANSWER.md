# Agent-facing output APIs on the Leadtype docs site

## Which docs area to use

Use **`/docs/reference/llm.md`** (the "LLM files" reference page). It is the section dedicated to the agent-facing output APIs, covering:

- `generateLlmsTxt` — writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` map for hosted websites.
- `generateLLMFullContextFiles` — writes the single root `/llms-full.txt` containing every generated markdown docs page.
- `generateAgentsMd` — writes `AGENTS.md` for npm-bundled docs (intentionally ignores `product.agentGuidance`, which is written for website URL routing).
- `isAgentReadabilityArtifactPath` — identifies artifact paths (`llms.txt`, `llms-full.txt`, sitemap files, `robots.txt`, search JSON, `agent-readability.json`) that should not be rewritten as missing markdown pages.

Explicitly **not** what you want here: `/docs/reference/search.md`. That page documents the static BM25 search index, runtime query path, and embeddings guidance — i.e., the search UI / retrieval surface, not the agent output artifacts.

If you want broader context for the same area, the topic bundle is `/docs/llms-full/reference.txt` ("CLI flags, conversion APIs, LLM bundle APIs, search, and lint reference"), but the smallest topic file matching the task is `/docs/reference/llm.md` — which is what the site's own guidance ("choose the smallest topic file that matches the task") tells you to prefer.

## When to use the monolithic `/llms-full.txt` fallback

Per `/llms.txt` and `/llms-full.txt`, the intended flow is:

1. Start at `/llms.txt`.
2. Read the full-context router at `/llms-full.txt` to find topic-specific deep-context files.
3. Pick the smallest topic file (e.g., `/docs/llms-full/reference.txt`, or an individual page like `/docs/reference/llm.md`) that matches the task.

So `/llms-full.txt` is a **router/fallback**, not the default reading target. Use the monolithic root `/llms-full.txt` only when:

- You need every generated markdown docs page in a single bundle (it contains all of them, per `generateLLMFullContextFiles`).
- No single topic file or per-page file covers the task — e.g., the task spans multiple topics, or you don't yet know which topic applies.
- You're doing whole-corpus operations (broad grep/ingest) where routing to the smallest file would miss cross-topic content.
- You specifically need the root-level fallback artifact itself (note: there are no per-group full-context files by default; groups organize `llms.txt` sections, navigation, search metadata, and `AGENTS.md` only).

Otherwise, prefer the topic file (`/docs/llms-full/reference.txt`) or the individual page (`/docs/reference/llm.md`) to keep context small and on-task.
