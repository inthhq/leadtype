# Leadtype: Agent-Facing Output APIs — Where to Look & When to Fall Back

## Which Docs Area to Use

For **agent-facing output APIs** (not search UI), use the **Reference → LLM files** section:

- **URL:** `/docs/reference/llm.md`
- **Reached via:** `/llms-full.txt` → **Reference** topic (`/docs/llms-full/reference.txt`) → "LLM files" page

This page documents the three core agent-output APIs:

| API | Purpose |
|---|---|
| `generateLlmsTxt` | Writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` map for hosted websites. |
| `generateLLMFullContextFiles` | Writes the single root `/llms-full.txt` file containing every generated markdown docs page. |
| `generateAgentsMd` | Writes `AGENTS.md` for npm-bundled docs (intentionally ignores `product.agentGuidance`, which is written for website URL routing). |

A supporting helper, `isAgentReadabilityArtifactPath`, identifies artifact paths (e.g. `llms.txt`, `llms-full.txt`, sitemap files, `robots.txt`, search JSON, `agent-readability.json`) that should **not** be rewritten as missing markdown pages.

> **Guidance from the docs:** Use groups for routing, not sharding. Group descriptions should be routing hints, not marketing copy.

The **Build → Connect a docs site** page (`/docs/build/connect-docs-site.md`) is complementary: it describes how those artifacts are wired into a hosted deployment (static files served at the site root, markdown served on `Accept: text/markdown`, etc.), but it does not document the API surface itself.

The **Search** reference (`/docs/reference/search.md`) covers the static BM25 search index and optional embeddings — this is the search-UI / search-index path, **not** what you need for agent output.

---

## When to Use the Monolithic `/llms-full.txt` Fallback

The recommended workflow (per `/llms.txt`) is:

1. Start at `/llms.txt`.
2. Open `/llms-full.txt` to read the **Full Context Router**.
3. Choose the **smallest topic file** that matches your task (e.g. `/docs/llms-full/reference.txt` for APIs).

Use `/llms-full.txt` as a **fallback** in these situations:

- **No single topic file fits** — the task spans multiple areas (e.g. authoring + build + reference) and loading individual topic files would require many round-trips.
- **Context window is not a concern** — you can afford to load the entire corpus in one shot and want to avoid the routing step entirely.
- **Topic routing is ambiguous** — you are unsure which topic file applies and need to scan all content before deciding.

In normal agent operation, prefer the smaller per-topic files (e.g. `/docs/llms-full/reference.txt`) to stay within token/context limits and reduce noise.
