# Leadtype: Agent-Facing Output APIs — Which Docs Area to Use

## The Right Docs Area: **Reference → LLM files**

For agent-facing output APIs (not the search UI), use the **Reference** section, specifically the **[LLM files](/docs/reference/llm.md)** page. This covers the three core generation APIs that produce the agent-readable artifacts:

| API | What it does |
|---|---|
| `generateLlmsTxt` | Writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` map for hosted websites. These are the entry-point discovery files HTTP agents start from. |
| `generateLLMFullContextFiles` | Writes one root `/llms-full.txt` containing every generated markdown docs page in a single file. Groups organize `llms.txt` sections and navigation but are **not** published as per-group full-context files by default. |
| `generateAgentsMd` | Writes `AGENTS.md` for npm-bundled docs (ignores `product.agentGuidance` because that text is written for website URL routing). |

There is also `isAgentReadabilityArtifactPath`, which identifies artifact paths (e.g. `llms.txt`, `llms-full.txt`, sitemap files, `robots.txt`, search JSON, `agent-readability.json`) that must **not** be rewritten as missing markdown pages.

The complementary **Build → [Connect a docs site](/docs/build/connect-docs-site.md)** page covers how to wire these artifacts into a hosted build (serving markdown on `Accept: text/markdown`, keeping the static files at their canonical paths, etc.), and the **Reference → CLI** page documents the `--json` flag that prints artifact paths (including `llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, etc.) after `leadtype generate` runs.

---

## When to Use the Monolithic `/llms-full.txt` Fallback

Use `/llms-full.txt` **only when a smaller, topic-specific file is not sufficient**. The guidance in `llms.txt` itself is explicit:

> "Choose the **smallest** topic file that matches the task."

Concretely, fall back to `/llms-full.txt` when:

1. **The task spans multiple topics** — e.g., you need authoring rules, build wiring, *and* reference APIs in a single context window pass, and loading each topic file separately is impractical.
2. **The correct topic file is unclear** — `/llms-full.txt` acts as a full-context router that contains every generated markdown page and can be scanned to locate the right section before narrowing down.
3. **An agent has no prior routing signal** — HTTP agents that cannot yet determine which topic applies start here to orient themselves before following a more targeted link.

For focused tasks (e.g., "what flags does `generateLlmsTxt` accept?"), prefer the targeted file (`/docs/llms-full/reference.txt` → `/docs/reference/llm.md`) to keep the context window small and reduce noise.
