Use the **Reference** docs area, specifically **Reference → LLM files** (`/docs/reference/llm.md`), for the agent-facing output APIs.

That page covers the APIs/artifacts intended for agents:

- `generateLlmsTxt` for the product `/llms.txt` and docs-scoped `/docs/llms.txt` maps.
- `generateLLMFullContextFiles` for the root `/llms-full.txt` fallback.
- `generateAgentsMd` for npm-bundled `AGENTS.md`.
- `isAgentReadabilityArtifactPath` for recognizing agent/readability artifacts that should not be treated as missing markdown pages.

Do **not** use the Search docs area for this need; `/docs/reference/search.md` is about the static search index, source-grounded answer generation, and optional embeddings, not the primary agent-facing output files.

Use the monolithic **`/llms-full.txt` fallback** only when you need a single full-context file containing every generated markdown docs page, or when the `/llms.txt` router cannot get you to a smaller matching topic/page. In normal agent workflows, start at `/llms.txt` and choose the smallest relevant routed topic instead of loading the monolithic fallback.