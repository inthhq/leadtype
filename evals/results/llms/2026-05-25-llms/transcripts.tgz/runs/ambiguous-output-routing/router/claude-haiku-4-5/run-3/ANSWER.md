# Agent-Facing Output APIs for Leadtype Docs

## Which docs area to use

For agent-facing output APIs (not search UI), use the **Reference documentation area**, specifically:

- **[`/docs/reference/llm.md`](/docs/reference/llm.md)** - The primary reference for all LLM bundle APIs

This document covers:
- `generateLlmsTxt` - Writes the product-level `/llms.txt` and docs-scoped `/docs/llms.txt` map for hosted websites
- `generateLLMFullContextFiles` - Writes the root `/llms-full.txt` file
- `generateAgentsMd` - Writes `AGENTS.md` for npm-bundled docs
- `isAgentReadabilityArtifactPath` - Identifies artifact paths that should not be rewritten as missing markdown pages

You may also want to consult:
- **[`/docs/reference/cli.md`](/docs/reference/cli.md)** - For CLI flags that control artifact generation (--json, --bundle, etc.)
- **[`/docs/build/connect-docs-site.md`](/docs/build/connect-docs-site.md)** - For practical guidance on serving the agent-readable artifacts in website mode

## When to use the `/llms-full.txt` fallback

Use the **monolithic `/llms-full.txt` fallback** in these scenarios:

1. **Starting point for LLM context** - The full router at `/llms-full.txt` provides comprehensive context when you need overview of all available APIs and topics
2. **When the Reference page links are insufficient** - `/llms-full.txt` contains the complete text of all reference documentation inline
3. **As a comprehensive backup** - If you need every available detail about all LLM APIs in one monolithic document

However, **prefer topic-specific files** (`/docs/reference/llm.md` and related pages) when you:
- Know your specific task (e.g., "I need to use generateLlmsTxt")
- Want focused, minimal context rather than the entire docs corpus
- Are building agents or tools that reference specific APIs

The Leadtype philosophy is: **Choose the smallest topic file that matches the task** - use `/llms-full.txt` only as a fallback when the focused approach isn't sufficient.
