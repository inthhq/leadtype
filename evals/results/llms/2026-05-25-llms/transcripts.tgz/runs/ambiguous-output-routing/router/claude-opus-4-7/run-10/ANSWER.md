# Agent-Facing Output APIs on the Leadtype Docs Site

## Which docs area to use

Use the **Reference → LLM files** page: [`/docs/reference/llm.md`](/docs/reference/llm.md).

That page (surfaced under the Reference topic in `/llms-full.txt` via [`/docs/llms-full/reference.txt`](/docs/llms-full/reference.txt)) documents the agent-facing output APIs:

- `generateLlmsTxt` — writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` map for hosted websites.
- `generateLLMFullContextFiles` — writes the single root `/llms-full.txt` containing every generated markdown docs page.
- `generateAgentsMd` — writes `AGENTS.md` for npm-bundled docs (intentionally ignores `product.agentGuidance`, which is website-URL-routing copy).
- `isAgentReadabilityArtifactPath` — identifies artifact paths (e.g. `llms.txt`, `llms-full.txt`, sitemap files, `robots.txt`, search JSON, `agent-readability.json`) that should not be rewritten as missing markdown pages.

Explicitly **not** what you want here: `/docs/reference/search.md`. That page covers the static BM25 search index, source-grounded answers, and when to add embeddings — i.e. the search UI / retrieval path, not the agent-facing output APIs.

CLI surface for these artifacts (flags like `--bundle`, `--json` output keys `llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, `agentReadabilityJson`, etc.) lives in [`/docs/reference/cli.md`](/docs/reference/cli.md) as a companion.

## When to use the monolithic `/llms-full.txt` fallback

`/llms.txt` itself instructs: "Read the full-context router, then choose the smallest topic file that matches the task." The router (`/llms-full.txt`) points to per-topic deep-context files under `/docs/llms-full/*.txt` (get-started, authoring, build, package-docs, reference).

So the intended flow is:

1. **Default path:** Start at `/llms.txt`, follow it to the `/llms-full.txt` router, then load the single smallest topic file that matches the task (e.g. `/docs/llms-full/reference.txt` for output-API questions).
2. **Monolithic `/llms-full.txt` fallback:** Use the root `/llms-full.txt` (which `generateLLMFullContextFiles` produces and which contains every generated markdown docs page, not split by group) when:
   - The task spans multiple topics and you cannot pick a single smallest topic file.
   - You need every page in one context window (e.g. cross-cutting audits, link checks, full-corpus reasoning).
   - You are operating in a client that cannot follow links from `/llms.txt` to per-topic `/docs/llms-full/*.txt` files and needs one self-contained bundle.

Per `/docs/reference/llm.md` and `/docs/authoring/frontmatter.md`, groups organize `llms.txt` sections, navigation, search metadata, and `AGENTS.md` — but the root `/llms-full.txt` is deliberately not sharded by group, which is exactly why it works as the catch-all fallback rather than the first choice.
