# Leadtype: Agent-Facing Output APIs vs. the Monolithic `/llms-full.txt` Fallback

## Which docs area to use

Use the **Reference → LLM files** area: [`/docs/reference/llm.md`](/docs/reference/llm.md) (rolled up in [`/docs/llms-full/reference.txt`](/docs/llms-full/reference.txt)).

This page documents the agent-facing *output* APIs — the functions that produce the agent-readable artifacts a docs site exposes over HTTP. Specifically:

- **`generateLlmsTxt`** — writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` map for hosted websites. This is the routing entry point agents should hit first.
- **`generateLLMFullContextFiles`** — writes the single root `/llms-full.txt` containing every generated markdown docs page. Note: groups are used for routing (llms.txt sections, navigation, search metadata, AGENTS.md) and are **not** published as per-group full-context files by default.
- **`generateAgentsMd`** — writes `AGENTS.md` for npm-bundled docs. It intentionally ignores `product.agentGuidance`, because that guidance targets website URL routing rather than in-package consumption.
- **`isAgentReadabilityArtifactPath`** — identifies artifact paths (llms.txt, llms-full.txt, sitemap files, robots.txt, search JSON, agent-readability.json) that should not be rewritten as missing markdown pages.

Do **not** use the Search area (`/docs/reference/search.md`) for this — that page covers the search index/query path and source-grounded answer generation (the search UI plumbing), not the output APIs that emit agent artifacts.

Supporting deployment wiring lives in **Build → Connect a docs site** (`/docs/build/connect-docs-site.md`), which describes serving these artifacts statically and content-negotiating markdown for AI user agents.

## When to use the monolithic `/llms-full.txt` fallback

The intended flow, per `/llms.txt` and `/llms-full.txt`, is:

> "Read the full-context router, then choose the smallest topic file that matches the task."

So the preference order is:

1. **Start at `/llms.txt`** to discover the routing map.
2. **Follow the router in `/llms-full.txt`** to pick the smallest topic-specific deep-context file under `/docs/llms-full/*.txt` (e.g., `get-started`, `authoring`, `build`, `package-docs`, `reference`).
3. **Drill into the individual page** referenced inside that topic file (e.g., `/docs/reference/llm.md`) when you need just one concept.

Use the **monolithic full-context file** only as a **fallback** when:

- You cannot determine which topic file applies (the task spans multiple topics or the routing hint isn't specific enough).
- You need *every* generated docs page in one fetch — remember `generateLLMFullContextFiles` emits one root `/llms-full.txt` containing the full corpus; there are no per-group full-context files by default.
- The agent runtime cannot make multiple sequential fetches and needs a single bundle.
- You're verifying or debugging the agent-readable deployment as a whole (it's one of the static artifacts listed in Build → Connect a docs site).

In normal agent operation, prefer the smallest matching topic file over `/llms-full.txt`, since groups are designed as routing hints, not sharding — the monolithic file is the catch-all, not the default.
