# Leadtype: Agent-Facing Output APIs — Which Docs Area & When to Use the Fallback

## Which Docs Area to Use

For agent-facing output APIs (not search UI), use the **Reference** section of the Leadtype docs, specifically the **LLM files** page:

> **`/docs/reference/llm.md`** — *LLM files reference*

This page documents the three core agent-output APIs:

| API | What it does |
|---|---|
| `generateLlmsTxt` | Writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` map for hosted websites. |
| `generateLLMFullContextFiles` | Writes the root `/llms-full.txt` file containing every generated markdown docs page (the monolithic fallback). |
| `generateAgentsMd` | Writes `AGENTS.md` for npm-bundled docs (intentionally ignores `product.agentGuidance`, which is written for website URL routing). |

Also relevant in the Reference section is **`/docs/reference/cli.md`**, which documents the `--bundle` and `--json` flags for `leadtype generate`. When `--json` is enabled, the CLI prints a JSON object listing paths for all generated artifacts, including `llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, `agentReadabilityJson`, and others.

The **Search** reference (`/docs/reference/search.md`) covers the *search index* (lexical BM25 ranking, edge-safe runtime query path, optional embeddings) — that is the search UI / retrieval side, **not** the agent output APIs.

---

## When to Use the Monolithic `/llms-full.txt` Fallback

Use `/llms-full.txt` when you **cannot** (or do not want to) choose a specific topic file. Concretely:

- **No matching topic file** — if none of the per-topic files in the Full Context Router covers your task, fall back to `/llms-full.txt`, which contains *every* generated markdown docs page in one bundle.
- **Unknown or cross-cutting task** — when the task spans multiple topics and it is unclear which smallest topic file applies.
- **Routing hint not helpful** — group descriptions in `llms.txt`/`llms-full.txt` are routing hints; if those hints do not point clearly to one topic file, use the monolithic fallback rather than guessing.

The guidance from `llms-full.txt` itself is explicit:

> *"Read the full-context router, then choose the **smallest topic file** that matches the task."*

`/llms-full.txt` is the **last-resort, largest-context option** — prefer a specific topic file (e.g., `/docs/llms-full/reference.txt`) whenever possible, because it is smaller and more focused.

---

## Summary

| Goal | Resource |
|---|---|
| Agent-facing output APIs | **Reference › LLM files** — `/docs/reference/llm.md` |
| CLI flags for generating those artifacts | **Reference › CLI** — `/docs/reference/cli.md` |
| Search UI / retrieval (not agent output) | Reference › Search — `/docs/reference/search.md` |
| Monolithic fallback (all docs, one file) | `/llms-full.txt` — use only when no single topic file is sufficient |
