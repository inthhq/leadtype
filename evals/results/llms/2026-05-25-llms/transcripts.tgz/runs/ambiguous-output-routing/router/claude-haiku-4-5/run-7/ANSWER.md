# Agent-Facing Output APIs in Leadtype Docs

## Recommended Docs Area

For agent-facing output APIs, use the **[Reference](/docs/reference/)** section, specifically:

- **[LLM files](/docs/reference/llm.md)** - Details the APIs for generating agent-readable artifacts:
  - `generateLlmsTxt()` - Generates /llms.txt and /docs/llms.txt
  - `generateLLMFullContextFiles()` - Generates /llms-full.txt
  - `generateAgentsMd()` - Generates AGENTS.md for npm-bundled docs
  - `isAgentReadabilityArtifactPath()` - Identifies artifact paths for agents

- **[CLI](/docs/reference/cli.md)** - Documents command-line arguments and JSON output format for the `leadtype generate` command, including the `--json` flag that outputs paths to all generated agent-readable artifacts.

## When to Use `/llms-full.txt` Fallback

Use the monolithic `/llms-full.txt` fallback when:

1. **You need complete context** - `/llms-full.txt` contains every generated markdown docs page in one file, providing comprehensive reference material.

2. **You don't have routing capability** - When you can't navigate to specific topic files within `/docs/llms-full/`, the full context file gives you all content at once.

3. **You need all reference information together** - `/llms-full.txt` aggregates CLI flags, LLM bundle APIs, search reference, and other complete documentation in a single artifact.

4. **Initial exploration** - If you're unfamiliar with the docs structure, `/llms-full.txt` serves as a complete starting point before drilling into specific topic files like `/docs/llms-full/reference.txt`.

## Key Agent-Readable Artifacts Produced

The generated artifacts include:
- `/llms.txt` - Product-level root file
- `/docs/llms.txt` - Docs-scoped map for hosted websites
- `/llms-full.txt` - Complete context fallback
- `/docs/*/md` - Markdown mirrors of docs pages
- `/docs/sitemap.xml` - XML sitemap for discovery
- `/docs/agent-readability.json` - Agent readability metadata
- `/docs/search/index.json` - Static search index
