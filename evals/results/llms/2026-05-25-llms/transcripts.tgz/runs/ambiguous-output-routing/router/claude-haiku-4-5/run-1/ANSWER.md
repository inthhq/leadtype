# Leadtype Agent-Facing Output APIs

## Which Docs Area to Use

For agent-facing output APIs in the Leadtype docs site, use the **Reference section** at `/docs/reference/`. This section contains three key API-focused documents:

1. **[CLI](/docs/reference/cli.md)** - For `leadtype generate` and `leadtype lint` command-line APIs, flags, exit codes, and JSON output
2. **[LLM files](/docs/reference/llm.md)** - For LLM bundle generation APIs (`generateLlmsTxt`, `generateLLMFullContextFiles`, `generateAgentsMd`, `isAgentReadabilityArtifactPath`)
3. **[Search](/docs/reference/search.md)** - For static search index APIs and query runtime APIs

## When to Use the `/llms-full.txt` Fallback

Use the monolithic **/llms-full.txt** fallback in these situations:

1. **Full Context Requirements**: When you need complete context across all documentation topics at once
2. **No Topic Match**: When your query doesn't clearly map to one of the specific Reference topics (CLI, LLM files, or Search)
3. **Cross-Cutting Concerns**: When understanding relationships between the CLI output APIs, file generation APIs, and search APIs together
4. **Fallback for Exploration**: As mentioned in the root `/llms.txt`, the full-context router (llms-full.txt) is the general-purpose fallback when topic-specific files don't suffice

The key principle is: **Choose the smallest topic file that matches your task.** Only reach for `/llms-full.txt` when you need holistic context across multiple API domains.
