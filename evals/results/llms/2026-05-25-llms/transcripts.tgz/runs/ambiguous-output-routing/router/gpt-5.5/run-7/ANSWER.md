Use the **Reference** docs area, specifically **Reference → LLM files** (`/docs/reference/llm.md`), for the agent-facing output APIs. That page covers the APIs that generate and classify agent-readable artifacts:

- `generateLlmsTxt` for the product-level `/llms.txt` and docs-scoped `/docs/llms.txt` maps.
- `generateLLMFullContextFiles` for the root `/llms-full.txt` full-context artifact.
- `generateAgentsMd` for npm-bundled `AGENTS.md`.
- `isAgentReadabilityArtifactPath` for recognizing agent artifacts such as `llms.txt`, `llms-full.txt`, sitemaps, robots.txt, search JSON, and `agent-readability.json`.

If you need generated output paths from the CLI, also use **Reference → CLI** (`/docs/reference/cli.md`), especially `leadtype generate --json`, which reports paths such as `llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, and `agentReadabilityJson`.

Do **not** start with the Search docs for this need. **Reference → Search** is about the static local search index and source-grounded answer generation, not the primary agent-facing output APIs.

Use the monolithic **`/llms-full.txt` fallback** only when a smaller routed file is not enough: for example, when an agent needs exhaustive context across the docs, cannot determine the right topic from `/llms.txt`, or needs a single all-docs artifact. The normal pattern is to start at `/llms.txt`, choose the smallest matching topic or page, and reserve `/llms-full.txt` as the broad fallback rather than the default source.