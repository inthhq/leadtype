Use the **Reference** docs area, specifically **LLM files**:

- Router/topic: `/docs/llms-full/reference.txt`
- Exact page: `/docs/reference/llm.md`

That area covers the agent-facing output APIs: `generateLlmsTxt`, `generateLLMFullContextFiles`, `generateAgentsMd`, and `isAgentReadabilityArtifactPath`. Do not use the Search docs area unless you are working on the static search index/query path; search is separate from the LLM/agent-readable output files.

Use `/llms-full.txt` only as the broad fallback/router when you cannot identify a smaller matching topic from `/llms.txt`, or when you truly need complete generated-docs context. For this question, the smaller matching topic is Reference → LLM files, so prefer that over the monolithic fallback.