# Answer

Use the **Reference → LLM files** docs area: `/docs/reference/llm.md`.

That page covers the agent-facing output APIs/artifacts:

- `generateLlmsTxt` for `/llms.txt` and `/docs/llms.txt`
- `generateLLMFullContextFiles` for `/llms-full.txt`
- `generateAgentsMd` for npm-bundled `AGENTS.md`
- `isAgentReadabilityArtifactPath` for recognizing generated agent-readability artifacts

Do **not** use the **Search** docs area unless you are working on Leadtype’s static search index, lexical ranking, source-grounded answer generation, or embeddings. Search is not the primary API surface for agent-facing output files.

Use the monolithic **`/llms-full.txt` fallback** only when you need the whole generated docs corpus in one file, or when routing through `/llms.txt`/topic-specific docs is insufficient. For normal agent use, start at `/llms.txt` and choose the smallest relevant docs/topic file instead of loading the full fallback.