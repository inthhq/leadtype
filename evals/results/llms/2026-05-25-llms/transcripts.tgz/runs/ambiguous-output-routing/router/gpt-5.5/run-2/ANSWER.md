# Answer

Use the **Reference** docs area, specifically **Reference → LLM files** (`/docs/reference/llm.md`), for the agent-facing output APIs. That page covers the APIs that produce and identify agent-readable artifacts:

- `generateLlmsTxt` for the site-level `/llms.txt` and docs-scoped `/docs/llms.txt` maps.
- `generateLLMFullContextFiles` for the root `/llms-full.txt` full-context fallback.
- `generateAgentsMd` for npm-bundled `AGENTS.md`.
- `isAgentReadabilityArtifactPath` for recognizing artifacts such as `llms.txt`, `llms-full.txt`, sitemaps, `robots.txt`, search JSON, and `agent-readability.json`.

If you are wiring these outputs into a hosted docs site, also use **Build → Connect a docs site** (`/docs/build/connect-docs-site.md`). That page explains website mode: generate `/llms.txt` at the site root, expose markdown mirrors under `/docs/*.md`, and serve markdown for agent requests.

Do **not** use the **Search** docs area for this need. Search is about the static local search index, query ranking, and optional answer generation over search results; it is not the primary reference for the agent-facing output files/APIs.

Use the monolithic `/llms-full.txt` fallback only as a last resort when you cannot answer from the smaller routed files. The intended flow is: start at `/llms.txt`, follow the full-context router, and choose the smallest topic file that matches the task. Fall back to `/llms-full.txt` when the narrower routed topic files are unavailable or insufficient and you need all generated markdown docs pages in one root full-context file.