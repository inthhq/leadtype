# Agent-Facing Output APIs in Leadtype Docs

## Which Docs Area to Use

For agent-facing output APIs (not search UI), use the **[Reference](/docs/reference/llm.md)** docs area, specifically the **LLM files** page.

The Reference section covers:
- **LLM files** (`/docs/reference/llm.md`): Describes the APIs for generating agent-readable artifacts
- **CLI** (`/docs/reference/cli.md`): Documents CLI output including the `--json` flag that provides paths to generated artifacts
- **Search** (`/docs/reference/search.md`): Covers static search index APIs (when search output feeds agent use cases)

## When to Use `/llms-full.txt` Fallback

Use the monolithic `/llms-full.txt` fallback when you need:

1. **Complete context across all topics** - When you're working on something that spans multiple documentation areas beyond just APIs
2. **Reference to all generated markdown pages** - Since `/llms-full.txt` contains every generated markdown docs page in one file
3. **A single, comprehensive file** - When you don't want to navigate the topic-specific router files

The routing approach is:
- **Start with `/llms.txt`** - The root router that guides you to topic files
- **Choose the smallest matching topic file** - For APIs specifically, that would be `/docs/llms-full/reference.txt` which routes to `/docs/reference/llm.md`
- **Fall back to `/llms-full.txt`** - Only when you need complete context across unrelated areas or want monolithic completeness

For agent-facing APIs specifically, the `/docs/reference/llm.md` file (routed from `/docs/llms-full/reference.txt`) is the right destination—not `/llms-full.txt`.
