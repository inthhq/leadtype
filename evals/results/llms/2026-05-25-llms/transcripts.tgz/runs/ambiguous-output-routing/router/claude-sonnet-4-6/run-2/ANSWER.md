# Leadtype: Agent-Facing Output APIs vs Search UI

## Which docs area to use

For **agent-facing output APIs** (not search UI), use the **Reference → LLM files** section:

- **Doc page:** `/docs/reference/llm.md`
- **Full-context topic file:** `/docs/llms-full/reference.txt`

This area documents the three core agent-output APIs:

| API | What it does |
|---|---|
| `generateLlmsTxt` | Writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` routing map for hosted websites. |
| `generateLLMFullContextFiles` | Writes the single `/llms-full.txt` file containing every generated markdown docs page. |
| `generateAgentsMd` | Writes `AGENTS.md` for npm-bundled docs (intentionally ignores `product.agentGuidance`, which is meant for website URL routing). |
| `isAgentReadabilityArtifactPath` | Identifies artifact paths (`llms.txt`, `llms-full.txt`, sitemap files, `robots.txt`, search JSON, `agent-readability.json`) that must not be rewritten as missing markdown pages. |

The **Search** reference (`/docs/reference/search.md`) covers the static BM25 search index and source-grounded answer generation — that is the search UI/index pipeline, not agent output APIs, so it should be treated separately.

---

## When to use the monolithic `/llms-full.txt` fallback

Use `/llms-full.txt` when:

1. **No topic file is a close match.** `/llms-full.txt` is the *full-context router* and contains every generated markdown docs page in one file. Start with the smallest matching topic file (e.g. `/docs/llms-full/reference.txt`) and fall back to `/llms-full.txt` only when the task spans multiple topics or no single topic file covers it.
2. **You need cross-topic context in a single fetch.** Because `llms-full.txt` bundles all topics, it is useful when an agent task requires understanding how authoring, build, and reference APIs interact end-to-end.
3. **Routing is ambiguous.** The `llms.txt` instruction is explicit: *"Read the full-context router, then choose the smallest topic file that matches the task."* If the topic router (`llms-full.txt`) cannot point you to a specific topic file that fits, load the full monolith.

> **Note on groups vs sharding:** Groups in Leadtype organize `llms.txt` sections, navigation, search metadata, and `AGENTS.md`. They are routing hints — `llms-full.txt` is *not* sharded per group; there is only one root monolith.

---

## Quick decision guide

```
Need agent output APIs?
  └─ Yes → /docs/reference/llm.md  (via /docs/llms-full/reference.txt)
  
Need search index / UI?
  └─ Yes → /docs/reference/search.md

Task spans multiple topics or no topic file fits?
  └─ Yes → /llms-full.txt  (monolithic fallback)
```
