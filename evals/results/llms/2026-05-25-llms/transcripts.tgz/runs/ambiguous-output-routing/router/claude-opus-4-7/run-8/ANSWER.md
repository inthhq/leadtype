# Agent-facing output APIs on the Leadtype docs site

## Which docs area to use

Use the **Reference → LLM files** page: [`/docs/reference/llm.md`](/docs/reference/llm.md).

That page documents the agent-facing *output* APIs (the code that emits the artifacts agents consume), specifically:

- `generateLlmsTxt` — writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` map for hosted websites.
- `generateLLMFullContextFiles` — writes the single root `/llms-full.txt` containing every generated markdown docs page.
- `generateAgentsMd` — writes `AGENTS.md` for npm-bundled docs (intentionally ignores `product.agentGuidance`, which is for website URL routing).
- `isAgentReadabilityArtifactPath` — identifies artifact paths (llms.txt, llms-full.txt, sitemap files, robots.txt, search JSON, agent-readability.json) that should not be rewritten as missing markdown pages.

Do **not** use `/docs/reference/search.md` for this — that page covers the search index / BM25 ranking / optional embeddings (the search UI/query path), not the agent output APIs. Related but distinct wiring (serving these artifacts, `Accept: text/markdown` handling) lives in `/docs/build/connect-docs-site.md`.

## When to use the monolithic `/llms-full.txt` fallback

`/llms-full.txt` is the **root full-context router / fallback**. Per `llms.txt` and the LLM files reference, the intended flow is:

1. Start at `/llms.txt`.
2. Read the full-context router (`/llms-full.txt`) to find the smallest topic-specific deep-context file (e.g. `/docs/llms-full/reference.txt`).
3. **Choose the smallest topic file that matches the task.**

Use the monolithic `/llms-full.txt` as a **fallback** when:

- You cannot resolve a single best topic file from the router (the task spans multiple topics, or routing hints don't clearly match).
- You need every generated markdown docs page in one fetch — it contains the full corpus concatenated.
- You're operating in an environment where following per-topic links isn't practical and you want one self-contained context blob.

Note from the reference: groups are used for routing in `llms.txt` / navigation / search metadata / `AGENTS.md`, but they are **not** published as per-group full-context files by default. The only full-context file written at the root is the single `/llms-full.txt`. So prefer the topic files under `/docs/llms-full/*.txt` first, and fall back to `/llms-full.txt` only when a narrower file won't do.
