# Leadtype: Agent-Facing Output APIs vs. the Monolithic Fallback

## Which docs area to use

Use the **Reference** area, specifically **`/docs/reference/llm.md`** (the "LLM files" reference). That page documents the agent-facing output APIs — the functions that emit the artifacts agents actually consume:

- **`generateLlmsTxt`** — writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` map for hosted websites.
- **`generateLLMFullContextFiles`** — writes the single root `/llms-full.txt` containing every generated markdown docs page. (Groups organize sections in `llms.txt`, nav, search metadata, and AGENTS.md; they are *not* published as per-group full-context files by default.)
- **`generateAgentsMd`** — writes `AGENTS.md` for npm-bundled docs. It intentionally ignores `product.agentGuidance`, since that text is written for website URL routing.
- **`isAgentReadabilityArtifactPath`** — identifies artifact paths (llms.txt, llms-full.txt, sitemap files, robots.txt, search JSON, agent-readability.json) so they aren't rewritten as missing markdown.

Supporting reference pages:

- **`/docs/reference/cli.md`** — `leadtype generate` flags and the `--json` output object (`llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, `agentReadabilityJson`, `sitemapXml`, `sitemapMd`, `robotsTxt`, `searchIndex`, `searchContent`).
- **`/docs/build/connect-docs-site.md`** — how to serve these artifacts (static `/llms.txt`, `/llms-full.txt`, sitemap, robots, search JSON, agent-readability.json) and content-negotiate markdown for agents.

**Do not** use `/docs/reference/search.md` for this — that is the search-index / retrieval surface (BM25 lexical index, optional embeddings), i.e. the search UI/runtime path, not the agent-readable output APIs.

## When to use the monolithic `/llms-full.txt` fallback

Per `/llms.txt` and `/llms-full.txt` themselves, the intended flow is:

> Read the full-context router, then choose the **smallest topic file that matches the task**.

So:

- **Preferred path:** Start at `/llms.txt`, then follow `/llms-full.txt` as a *router* into the topic-specific deep-context files under `/docs/llms-full/*.txt` (`get-started`, `authoring`, `build`, `package-docs`, `reference`). These topic bundles are smaller and focused.
- **Use the monolithic root `/llms-full.txt` as a fallback when:**
  - The consuming agent cannot follow links / cannot make a second fetch, and needs the whole corpus inlined in one request.
  - You don't yet know which topic applies and want one document containing every generated markdown docs page.
  - You're verifying or debugging the full agent-readable bundle (it's the artifact emitted by `generateLLMFullContextFiles`, surfaced as `llmsFullTxt` in the `leadtype generate --json` output).

In short: route through `/llms.txt` → topic file in `/docs/llms-full/*.txt` whenever possible; fall back to the root `/llms-full.txt` only when a single inlined dump of all docs is required.
