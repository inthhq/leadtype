Use the **Reference** docs area, specifically **Reference → LLM files** (`/docs/reference/llm.md`, or the bundled topic file `/docs/llms-full/reference.txt`) for agent-facing output APIs.

That is where Leadtype documents the APIs/artifacts for agent-readable outputs:

- `generateLlmsTxt` for `/llms.txt` and `/docs/llms.txt`
- `generateLLMFullContextFiles` for the root `/llms-full.txt`
- `generateAgentsMd` for packaged `AGENTS.md`
- `isAgentReadabilityArtifactPath` for recognizing generated agent/static artifacts

Do **not** use the Search docs area if you need agent-facing output APIs. Search covers the static search index and query/answer-generation path, not the LLM bundle/output APIs.

Use the monolithic root **`/llms-full.txt` fallback** only when a smaller routed file is not enough: start from `/llms.txt`, follow the full-context router, and choose the smallest matching topic file first. The root `/llms-full.txt` is the all-generated-markdown fallback; it is not split per group. Groups organize routing/navigation/search metadata/AGENTS.md, but they are not separate full-context shards by default.
