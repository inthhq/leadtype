# Leadtype: Agent-Facing Output APIs — Which Docs Area & When to Use the Fallback

## Which docs area to use

For **agent-facing output APIs** (not search UI), use the **Reference → LLM files** section:

> **`/docs/reference/llm.md`** — *"Generate llms.txt, the root full-context fallback, and AGENTS.md."*

This page documents the three core agent-output APIs:

| API | What it does |
|---|---|
| `generateLlmsTxt` | Writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` map for hosted websites. |
| `generateLLMFullContextFiles` | Writes one root `/llms-full.txt` file containing every generated markdown docs page. |
| `generateAgentsMd` | Writes `AGENTS.md` for npm-bundled docs (intentionally ignores `product.agentGuidance`, which is meant for website URL routing). |

There is also a helper, `isAgentReadabilityArtifactPath`, which identifies artifact paths (llms.txt, llms-full.txt, sitemap files, robots.txt, search JSON, agent-readability.json) that should **not** be rewritten as missing markdown pages.

The **Search** reference (`/docs/reference/search.md`) covers the static search index and query path — that is the search UI / lexical ranking side, which you said you don't need.

---

## When to use the monolithic `/llms-full.txt` fallback

Use `/llms-full.txt` when **no single topic file is small enough** to cover your task, i.e. when you need cross-cutting context spanning multiple topic areas in one request.

From the site's own routing guidance:

> *"Read the full-context router, then choose the **smallest topic file** that matches the task."*  
> (`/llms.txt`)

> *"Choose the smallest topic file that matches the task."*  
> (`/llms-full.txt` header)

In practice, prefer `/llms-full.txt` when:

1. **The task spans multiple topics** — e.g. you need authoring, build wiring, and LLM-file generation details all at once and fetching three separate topic files would be unwieldy.
2. **You can't determine which topic file is relevant** from the topic titles alone and need the entire corpus to orient yourself.
3. **A topic file turns out to be insufficient** — it links out or references concepts explained elsewhere, so you need the combined document for complete context.

For a focused task like "agent-facing output APIs", the right call is to go directly to the **Reference topic file** (`/docs/llms-full/reference.txt`) rather than loading the full monolithic fallback, keeping the context window as small as possible.
