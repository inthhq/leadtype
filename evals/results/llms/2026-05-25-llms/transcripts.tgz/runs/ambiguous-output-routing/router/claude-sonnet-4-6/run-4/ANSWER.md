# Leadtype: Agent-Facing Output APIs — Where to Look and When to Fall Back

## Which docs area to use

For **agent-facing output APIs** (not search UI), use the **Reference** section, specifically:

### [`/docs/reference/llm.md`](/docs/reference/llm.md) — LLM Bundle APIs
This is the primary area for agent-facing output. It covers:
- **`generateLlmsTxt`** — writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` map for hosted websites.
- **`generateLLMFullContextFiles`** — writes the root `/llms-full.txt` file containing every generated markdown docs page.
- **`generateAgentsMd`** — writes `AGENTS.md` for npm-bundled docs (intentionally ignores `product.agentGuidance`, which is meant for website URL routing).
- **`isAgentReadabilityArtifactPath`** — identifies artifact paths (e.g. `llms.txt`, `llms-full.txt`, sitemap files, `robots.txt`, search JSON, `agent-readability.json`) that should **not** be rewritten as missing markdown pages.

> **Key guidance from the docs:** Use groups for routing, not sharding. Group descriptions should be routing hints, not marketing copy.

### [`/docs/reference/cli.md`](/docs/reference/cli.md) — CLI flags for generating artifacts
When `--json` is enabled, `leadtype generate` prints a JSON object with paths for all generated artifacts, including: `llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, `agentReadabilityJson`, `sitemapXml`, `sitemapMd`, `robotsTxt`, `searchIndex`, and `searchContent`.

The **Search** reference (`/docs/reference/search.md`) covers the static local search index and source-grounded answer generation — that is the search UI / retrieval side, **not** the agent output APIs.

---

## When to use the monolithic `/llms-full.txt` fallback

Use `/llms-full.txt` when no single topic file is small enough to match the task. Per the docs:

> *"Read the full-context router, then choose the **smallest topic file** that matches the task."*

`/llms-full.txt` is the **root full-context fallback** — it contains every generated markdown docs page in one bundle. It is intended as a last resort when a specific topic file (e.g. `/docs/llms-full/reference.txt`) does not cover the scope of what you need, or when you need cross-cutting context across multiple topics simultaneously.

In practice:
| Situation | What to use |
|---|---|
| Task maps clearly to one topic (e.g. LLM output APIs) | Use the matching topic file, e.g. `/docs/llms-full/reference.txt` |
| Task spans multiple topics or topic is unclear | Use `/llms-full.txt` as the monolithic fallback |
| Routing/discovery only | Use `/llms.txt` (the lightweight root map) |

---

## Summary

- **Use `/docs/llms-full/reference.txt`** (and its underlying pages `/docs/reference/llm.md` and `/docs/reference/cli.md`) for all agent-facing output API work.
- **Fall back to `/llms-full.txt`** only when the task is too broad or cross-cutting for any single topic file to cover.
