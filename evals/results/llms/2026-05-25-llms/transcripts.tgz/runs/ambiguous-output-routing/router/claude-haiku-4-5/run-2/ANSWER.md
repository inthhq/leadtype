# Agent-Facing Output APIs in Leadtype Docs

## Which Docs Area to Use

Use the **[LLM files reference](/docs/reference/llm.md)** documentation area for agent-facing output APIs.

This section documents the programmatic APIs that generate agent-readable artifacts:

- **`generateLlmsTxt`**: Writes the product-level `/llms.txt` and docs-scoped `/docs/llms.txt` map for hosted websites
- **`generateLLMFullContextFiles`**: Writes the root `/llms-full.txt` file containing every generated markdown docs page
- **`generateAgentsMd`**: Writes `AGENTS.md` for npm-bundled docs
- **`isAgentReadabilityArtifactPath`**: Identifies artifact paths that should not be rewritten as missing markdown pages

## When to Use the `/llms-full.txt` Fallback

According to the Leadtype documentation, use the **monolithic `/llms-full.txt` fallback** when:

1. **You need complete context across all documentation** - `generateLLMFullContextFiles` writes one comprehensive root file containing every generated markdown docs page
2. **You're working with agent implementations that prefer single-file context** - The full-context file bundles all docs in one place for agents that can't efficiently route across multiple topic files
3. **Group routing is not sufficient for your use case** - The router at the top level (`/llms.txt`) uses groups for routing to topic-specific files, but if you need everything at once, use the full context version

The key guidance from Leadtype is: **"Read the full-context router, then choose the smallest topic file that matches the task."** The `/llms-full.txt` fallback is the safety net when you can't identify a smaller, specific topic file that suits your needs.

For agent integration, you'd typically:
1. Start with `/docs/reference/cli.md` to understand the `--json` flag output
2. Use the JSON output paths (including `llmsFullTxt` and `docsLlmsTxt`) to locate the appropriate agent-readable artifacts
3. Fall back to `/llms-full.txt` if you need complete context in a single file
