# Agent-Facing Output APIs in Leadtype Docs

## Which Docs Area to Use

For agent-facing output APIs, use the **[/docs/reference/llm.md](/docs/reference/llm.md)** documentation.

This page covers:
- `generateLlmsTxt` - writes the product-level `/llms.txt` and docs-scoped `/docs/llms.txt` map for hosted websites
- `generateLLMFullContextFiles` - writes the root `/llms-full.txt` file containing every generated markdown docs page
- `generateAgentsMd` - writes `AGENTS.md` for npm-bundled docs
- `isAgentReadabilityArtifactPath` - identifies artifact paths that should not be rewritten as missing markdown pages

## When to Use the Monolithic `/llms-full.txt` Fallback

Use the `/llms-full.txt` fallback in these scenarios:

1. **Full context needed**: When you need every generated markdown docs page in a single file for comprehensive context
2. **Deep-dive reference**: When routing through `/llms.txt` (which is topic-specific) doesn't give you enough detail for your task
3. **Fallback routing**: According to the Leadtype instructions, read the full-context router first (/llms-full.txt), then choose the smallest topic file that matches your task

The `/llms-full.txt` file is a monolithic router that points you to topic-specific deep-context files organized by category:
- Get Started
- Authoring
- Build
- Ship Package Docs
- Reference (which includes the llm.md page)

### When NOT to Use `/llms-full.txt`

Prefer the targeted `/docs/reference/llm.md` page when you specifically need information about:
- LLM bundle APIs
- How output files are generated
- Artifact path handling

This follows Leadtype's own design principle: "Choose the smallest topic file that matches the task."
