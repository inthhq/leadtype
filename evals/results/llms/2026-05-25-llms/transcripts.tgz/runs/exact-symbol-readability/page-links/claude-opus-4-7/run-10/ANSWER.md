# Preventing agent-readability artifact rewrites

## Helper

**`isAgentReadabilityArtifactPath`**

Documented in [`/docs/reference/llm.md`](docs/reference/llm.md).

## What it does

It identifies artifact paths that should **not** be rewritten as missing markdown pages. This protects agent-readable files from being mistakenly treated as docs pages that need a markdown mirror generated.

## What it covers

According to the LLM files reference, the helper covers:

- `llms.txt`
- `llms-full.txt`
- sitemap files
- `robots.txt`
- search JSON
- `agent-readability.json`

These are the static agent-readability artifacts a hosted docs site exposes alongside the `/docs/*.md` mirrors, and they must be served as-is rather than routed through the missing-markdown-page rewrite path.
