# Preventing Agent-Readability Artifacts from Being Rewritten

## Helper

**`isAgentReadabilityArtifactPath`**

## What It Does

`isAgentReadabilityArtifactPath` identifies artifact paths that should **not** be rewritten as missing markdown pages. It covers the following files:

- `llms.txt`
- `llms-full.txt`
- Sitemap files
- `robots.txt`
- Search JSON
- `agent-readability.json`

By recognising these paths as known static artifacts, the helper prevents the docs pipeline from treating them as absent documentation pages and mistakenly generating (or returning) a "missing page" markdown response for them.

> Source: [LLM files reference](/docs/reference/llm.md)
