# Helper for Preventing Agent-Readability Artifacts

## Helper Name
**`isAgentReadabilityArtifactPath`**

## Description
`isAgentReadabilityArtifactPath` is a helper function that identifies artifact paths that should not be rewritten as missing markdown pages. 

It covers the following agent-readability artifacts:
- `llms.txt` - Product-level agent-readable file
- `llms-full.txt` - Root full-context file containing all generated markdown docs
- Sitemap files (sitemap.xml, sitemap.md)
- `robots.txt`
- Search JSON files
- `agent-readability.json`

This helper prevents the Leadtype build system from incorrectly treating these special agent-readability artifacts as missing markdown pages that need to be created or rewritten.
