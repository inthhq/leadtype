# Agent-Readability Artifact Prevention Helper

## Helper Name
`isAgentReadabilityArtifactPath`

## Description
`isAgentReadabilityArtifactPath` identifies artifact paths that should not be rewritten as missing markdown pages. It covers:

- llms.txt
- llms-full.txt
- sitemap files
- robots.txt
- search JSON
- agent-readability.json

This helper prevents these special agent-readability artifacts from being incorrectly processed as missing markdown pages during the docs generation pipeline.
