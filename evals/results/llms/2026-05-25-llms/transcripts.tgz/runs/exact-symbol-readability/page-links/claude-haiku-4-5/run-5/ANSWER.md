# Agent-Readability Artifacts Prevention

## Helper: `isAgentReadabilityArtifactPath`

The helper that prevents agent-readability artifacts from being rewritten as missing markdown pages is **`isAgentReadabilityArtifactPath`**.

## What It Covers

`isAgentReadabilityArtifactPath` identifies artifact paths that should not be rewritten as missing markdown pages. It covers:

- `llms.txt` - The root agent-readable index
- `llms-full.txt` - The root full-context fallback containing all markdown docs pages
- Sitemap files (`sitemap.xml`, `sitemap.md`)
- `robots.txt` - Robot exclusion rules
- Search JSON files
- `agent-readability.json` - Agent readability configuration

This helper ensures that these critical agent-readable artifacts are preserved as static files during the docs generation process and are not inadvertently rewritten as missing markdown pages.
