# Preventing agent-readability artifacts from being rewritten as missing markdown

## Helper

**`isAgentReadabilityArtifactPath`**

Documented in [`/docs/reference/llm.md`](docs/reference/llm.md):

> `isAgentReadabilityArtifactPath` identifies artifact paths that should not be rewritten as missing markdown pages.

## What it covers

It recognizes the following agent-readability artifact paths so they are served as-is rather than treated as absent markdown documents:

- `llms.txt`
- `llms-full.txt`
- sitemap files
- `robots.txt`
- search JSON
- `agent-readability.json`

These are the static artifacts a Leadtype-powered docs site exposes alongside its markdown mirrors (see also `/docs/build/connect-docs-site.md`), and the helper ensures the markdown-rewriting layer leaves them alone.
