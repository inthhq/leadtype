# Agent-Readability Artifact Prevention Helper

## Helper: `isAgentReadabilityArtifactPath`

The helper `isAgentReadabilityArtifactPath` prevents agent-readability artifacts from being rewritten as missing markdown pages.

## Coverage

This helper covers the following artifact types:

- `llms.txt`
- `llms-full.txt`
- Sitemap files
- `robots.txt`
- Search JSON files
- `agent-readability.json`

By identifying these paths, the helper ensures they are not incorrectly processed as missing markdown pages during the docs site generation process.
