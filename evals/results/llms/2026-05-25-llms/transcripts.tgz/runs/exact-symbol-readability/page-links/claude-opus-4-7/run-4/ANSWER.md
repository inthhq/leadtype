# Preventing agent-readability artifacts from being rewritten

## Helper

**`isAgentReadabilityArtifactPath`**

Documented in [`/docs/reference/llm.md`](/docs/reference/llm.md), this helper identifies artifact paths that should **not** be rewritten as missing markdown pages.

## What it covers

The helper recognizes the following static, agent-readability artifacts:

- `llms.txt`
- `llms-full.txt`
- sitemap files
- `robots.txt`
- search JSON
- `agent-readability.json`

These files are served as static artifacts (see `/docs/build/connect-docs-site.md`), so the missing-markdown rewrite logic must skip them — that's the role `isAgentReadabilityArtifactPath` plays.
