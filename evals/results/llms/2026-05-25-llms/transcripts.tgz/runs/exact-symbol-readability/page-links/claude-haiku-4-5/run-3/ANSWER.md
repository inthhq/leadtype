# Agent-Readability Artifact Helper

## Helper Name
`isAgentReadabilityArtifactPath`

## Description
The `isAgentReadabilityArtifactPath` helper identifies artifact paths that should not be rewritten as missing markdown pages. It covers:

- `llms.txt`
- `llms-full.txt`
- Sitemap files
- `robots.txt`
- Search JSON files
- `agent-readability.json`

This helper ensures that these important agent-readable artifacts and technical files are preserved and not mistakenly processed as markdown page requests.
