# Preventing Agent-Readability Artifacts from Being Rewritten

## Helper

**`isAgentReadabilityArtifactPath`**

## Description

`isAgentReadabilityArtifactPath` identifies artifact paths that should **not** be rewritten as missing markdown pages. It covers the following files/paths:

- `llms.txt`
- `llms-full.txt`
- Sitemap files
- `robots.txt`
- Search JSON
- `agent-readability.json`

By recognizing these paths as known static artifacts, the helper ensures they are served as-is rather than being incorrectly treated as missing documentation pages and rewritten.

> Source: [LLM files reference](/docs/reference/llm.md)
