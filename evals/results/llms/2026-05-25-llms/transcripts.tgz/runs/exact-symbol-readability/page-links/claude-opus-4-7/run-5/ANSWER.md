# Preventing agent-readability artifacts from being rewritten as missing markdown pages

## Helper

**`isAgentReadabilityArtifactPath`**

Documented in [`/docs/reference/llm.md`](/docs/reference/llm.md).

## What it does

It identifies artifact paths that should **not** be rewritten as missing markdown pages. These are static agent-readability artifacts that a docs site serves directly rather than treating as docs routes.

## What it covers

- `llms.txt`
- `llms-full.txt`
- sitemap files
- `robots.txt`
- search JSON
- `agent-readability.json`

## Why it matters

Per `/docs/build/connect-docs-site.md`, these files are kept as static artifacts at known site locations (e.g., `/llms.txt` at the root, `/llms-full.txt`, sitemaps, `robots.txt`). Without this helper guarding them, an Accept-based or AI-user-agent-based markdown rewriter could treat requests for those paths as missing `.md` pages and produce broken responses. `isAgentReadabilityArtifactPath` lets the docs-site integration short-circuit such rewriting so the artifacts are served as-is.
