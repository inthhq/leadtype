# Preventing Agent-Readability Artifacts from Being Rewritten

## Helper Function

The helper that prevents agent-readability artifacts from being rewritten as missing markdown pages is:

**`isAgentReadabilityArtifactPath`**

## What It Covers

`isAgentReadabilityArtifactPath` identifies artifact paths that should **not** be rewritten as missing markdown pages. It covers:

- `llms.txt`
- `llms-full.txt`
- Sitemap files
- `robots.txt`
- Search JSON
- `agent-readability.json`

These static artifacts are kept as-is so that agents and crawlers can discover and consume them correctly, rather than having them incorrectly treated as absent or broken markdown documentation pages.

**Source:** [LLM files reference](/docs/reference/llm.md)
