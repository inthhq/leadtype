The helper is `isAgentReadabilityArtifactPath`.

It identifies agent-readability artifact paths that should be treated as static files instead of being rewritten as missing markdown pages. It covers `llms.txt`, `llms-full.txt`, sitemap files, `robots.txt`, search JSON files, and `agent-readability.json`.
