# Agent-Readability Artifact Prevention Helper

## Helper Name
**`isAgentReadabilityArtifactPath`**

## Description
`isAgentReadabilityArtifactPath` is a helper that identifies artifact paths that should not be rewritten as missing markdown pages. It covers the following artifacts:

- `llms.txt`
- `llms-full.txt`
- Sitemap files
- `robots.txt`
- Search JSON files
- `agent-readability.json`

This helper prevents these special agent-readability artifacts from being incorrectly treated as missing markdown pages during the docs pipeline processing.
