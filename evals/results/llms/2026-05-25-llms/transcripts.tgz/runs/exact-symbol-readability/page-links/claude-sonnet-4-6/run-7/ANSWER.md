# Preventing Agent-Readability Artifacts from Being Rewritten

## Helper

**`isAgentReadabilityArtifactPath`**

## Description

`isAgentReadabilityArtifactPath` identifies artifact paths that should **not** be rewritten as missing markdown pages. It covers the following files:

- `llms.txt`
- `llms-full.txt`
- Sitemap files
- `robots.txt`
- Search JSON
- `agent-readability.json`

These are static artifacts that must be served as-is. Without this guard, a docs site's "missing page" handler could inadvertently overwrite or replace them with a generated (and incorrect) markdown 404-style page.
