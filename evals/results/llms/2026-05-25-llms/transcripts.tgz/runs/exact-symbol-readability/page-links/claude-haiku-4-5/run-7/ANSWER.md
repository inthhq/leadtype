# Agent-Readability Artifact Prevention

## Helper
**`isAgentReadabilityArtifactPath`**

## Description
`isAgentReadabilityArtifactPath` identifies artifact paths that should not be rewritten as missing markdown pages. It covers:
- `llms.txt`
- `llms-full.txt`
- Sitemap files
- `robots.txt`
- Search JSON
- `agent-readability.json`

This helper ensures that critical agent-readability artifacts are preserved as static files during the build process and are not incorrectly treated as missing documentation pages.
