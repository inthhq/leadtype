# Prevent Agent-Readability Artifacts

## Helper: `isAgentReadabilityArtifactPath`

The `isAgentReadabilityArtifactPath` helper identifies artifact paths that should not be rewritten as missing markdown pages.

## What It Covers

It covers the following artifact types:
- `llms.txt`
- `llms-full.txt`
- Sitemap files
- `robots.txt`
- Search JSON
- `agent-readability.json`

These artifacts are essential agent-readability files that must be preserved and not treated as missing markdown pages that need to be rewritten.
