# Preventing Agent-Readability Artifacts from Being Rewritten

## Helper

**`isAgentReadabilityArtifactPath`**

## What It Does

`isAgentReadabilityArtifactPath` identifies artifact paths that should **not** be rewritten as missing markdown pages.

## What It Covers

It covers the following static artifact paths:

- `llms.txt`
- `llms-full.txt`
- Sitemap files
- `robots.txt`
- Search JSON
- `agent-readability.json`

By recognising these paths as known agent-readability artifacts, the helper prevents the docs site from mistakenly treating them as absent documentation pages and serving a 404-style "missing markdown page" response in their place.

> Source: [LLM files reference](/docs/reference/llm.md) and [Connect a docs site](/docs/build/connect-docs-site.md)
