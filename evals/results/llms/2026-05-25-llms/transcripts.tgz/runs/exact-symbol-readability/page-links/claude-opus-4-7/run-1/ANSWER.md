# Preventing agent-readability artifacts from being rewritten as missing markdown pages

## Helper

**`isAgentReadabilityArtifactPath`**

Per the Leadtype docs (`/docs/reference/llm.md`), `isAgentReadabilityArtifactPath` identifies artifact paths that should **not** be rewritten as missing markdown pages.

## What it covers

The helper recognizes the following agent-readability artifact paths:

- `llms.txt`
- `llms-full.txt`
- sitemap files
- `robots.txt`
- search JSON
- `agent-readability.json`

These are served as static artifacts (see `/docs/build/connect-docs-site.md`), so the markdown-rewriting layer must skip them rather than treat them as missing `.md` pages.

## Source

- `/docs/reference/llm.md` — defines `isAgentReadabilityArtifactPath` and the artifact list.
- `/docs/build/connect-docs-site.md` — corroborates that these same files are kept as static artifacts in website mode.
