# Preventing agent-readability artifacts from being rewritten

## Helper

**`isAgentReadabilityArtifactPath`**

Per [`/docs/reference/llm.md`](/docs/reference/llm.md):

> `isAgentReadabilityArtifactPath` identifies artifact paths that should not be rewritten as missing markdown pages.

## What it covers

The helper recognizes the following agent-readability artifact paths so they are not treated as missing markdown pages:

- `llms.txt`
- `llms-full.txt`
- sitemap files
- `robots.txt`
- search JSON
- `agent-readability.json`

These are the same static artifacts that the [Connect a docs site](/docs/build/connect-docs-site.md) guide says should be served as-is at the site root, rather than being routed through the markdown-mirror logic used for `/docs/*.md` pages.
