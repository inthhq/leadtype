# Agent-Readability Artifact Prevention

**Helper:** `isAgentReadabilityArtifactPath`

**Description:** This helper identifies artifact paths that should not be rewritten as missing markdown pages. It covers:
- `llms.txt`
- `llms-full.txt`
- Sitemap files
- `robots.txt`
- Search JSON
- `agent-readability.json`

By using this helper, Leadtype prevents these special agent-readability artifacts from being incorrectly treated as missing markdown pages during the docs pipeline.
