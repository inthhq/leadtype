# Preventing agent-readability artifacts from being rewritten as missing markdown pages

## Helper

**`isAgentReadabilityArtifactPath`**

Source: [/docs/reference/llm.md](docs/reference/llm.md)

## What it covers

`isAgentReadabilityArtifactPath` identifies artifact paths that should **not** be rewritten as missing markdown pages. It covers:

- `llms.txt`
- `llms-full.txt`
- sitemap files
- `robots.txt`
- search JSON
- `agent-readability.json`

These are the static artifacts a docs site is expected to serve as-is (per the [Connect a docs site](docs/build/connect-docs-site.md) guidance), so the helper prevents the markdown-mirroring layer from treating them as missing `/docs/*.md` pages.
