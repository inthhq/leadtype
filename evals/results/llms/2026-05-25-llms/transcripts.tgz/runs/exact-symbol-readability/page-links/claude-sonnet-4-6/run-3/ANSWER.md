# Preventing Agent-Readability Artifacts from Being Rewritten

## Helper

**`isAgentReadabilityArtifactPath`**

## What It Does

`isAgentReadabilityArtifactPath` identifies artifact paths that should **not** be rewritten as missing markdown pages. It covers the following files:

- `llms.txt`
- `llms-full.txt`
- Sitemap files
- `robots.txt`
- Search JSON
- `agent-readability.json`

By recognizing these paths as known static artifacts, the helper ensures they are served as-is rather than being treated as absent markdown content and erroneously overwritten or replaced with a 404/missing-page response.

## Source

Documented in [LLM files reference](/docs/reference/llm.md) and cross-referenced in [Connect a docs site](/docs/build/connect-docs-site.md).
