# Preventing agent-readability artifacts from being treated as missing markdown pages

## Helper

**`isAgentReadabilityArtifactPath`**

Documented in [`/docs/reference/llm.md`](/docs/reference/llm.md), this helper identifies artifact paths that should **not** be rewritten as missing markdown pages.

## What it covers

It recognizes the following agent-readability artifact paths:

- `llms.txt`
- `llms-full.txt`
- sitemap files
- `robots.txt`
- search JSON
- `agent-readability.json`

These paths are expected to be served as static artifacts at the docs-site root (see [`/docs/build/connect-docs-site.md`](/docs/build/connect-docs-site.md)), so a docs-site integration should consult `isAgentReadabilityArtifactPath` before applying any "missing markdown page" rewrite logic — otherwise these legitimate artifacts could be mistakenly routed as 404s or rewritten into `.md` lookups.
