# Preventing Agent-Readability Artifacts from Being Rewritten as Missing Markdown Pages

## Helper

**`isAgentReadabilityArtifactPath`**

This helper is documented in the [LLM files reference](/docs/reference/llm.md).

## What It Covers

`isAgentReadabilityArtifactPath` identifies artifact paths that should **not** be rewritten as missing markdown pages. It covers the following files:

- `llms.txt`
- `llms-full.txt`
- Sitemap files
- `robots.txt`
- Search JSON
- `agent-readability.json`

These are static artifacts that must be served as-is; the helper prevents any doc-serving middleware from incorrectly treating them as absent markdown pages and returning a 404 or a generated fallback page.
