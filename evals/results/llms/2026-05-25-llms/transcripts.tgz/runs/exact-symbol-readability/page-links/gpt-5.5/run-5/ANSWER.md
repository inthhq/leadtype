The helper is `isAgentReadabilityArtifactPath`.

It identifies agent-readability/static artifact paths that should be served as-is instead of being rewritten to missing markdown pages. It covers `llms.txt`, `llms-full.txt`, sitemap files, `robots.txt`, search JSON, and `agent-readability.json`.
