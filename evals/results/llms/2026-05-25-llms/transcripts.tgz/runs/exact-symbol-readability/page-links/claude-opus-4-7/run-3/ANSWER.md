# Preventing Agent-Readability Artifact Rewrites

## Helper

**`isAgentReadabilityArtifactPath`**

Documented in [`docs/reference/llm.md`](/docs/reference/llm.md).

## What it does

`isAgentReadabilityArtifactPath` identifies artifact paths that should **not** be rewritten as missing markdown pages. Without it, an agent-aware docs site could mistake these static, non-MDX files for missing `/docs/*.md` pages and try to serve a "not found" markdown rewrite in their place.

## What it covers

The helper flags the following agent-readability artifacts as legitimate static files:

- `llms.txt`
- `llms-full.txt`
- sitemap files (e.g. `sitemap.xml`, `sitemap.md`)
- `robots.txt`
- search JSON (e.g. `search-index.json`, `search-content.json`)
- `agent-readability.json`

These are the same files that the "Connect a docs site" guide says must be kept as static artifacts at the site root / under `/docs/`, so they remain HTTP-discoverable for agents rather than being intercepted by the markdown-rewrite path.
