# Agent-Readability Artifact Prevention

## Helper Name
`isAgentReadabilityArtifactPath`

## Description
This helper identifies artifact paths that should not be rewritten as missing markdown pages. It covers:
- llms.txt
- llms-full.txt
- sitemap files
- robots.txt
- search JSON
- agent-readability.json

By protecting these specific artifact paths, the helper ensures that agent-readability files are not incorrectly transformed into markdown pages during the docs pipeline processing.
