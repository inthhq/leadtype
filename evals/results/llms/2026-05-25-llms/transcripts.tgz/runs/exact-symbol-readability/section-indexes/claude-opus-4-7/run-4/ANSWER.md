# Helper that prevents agent-readability artifact rewrites

## Helper

**`isAgentReadabilityArtifactPath`**

Documented in [`/docs/reference/llm.md`](docs/reference/llm.md):

> `isAgentReadabilityArtifactPath` identifies artifact paths that should not be rewritten as missing markdown pages.

## What it covers

The helper recognizes the following agent-readable / site-meta artifacts so a docs build (or request handler) won't try to treat them as missing `.md` pages and rewrite them:

- `llms.txt`
- `llms-full.txt`
- sitemap files
- `robots.txt`
- search JSON (e.g. `search-index.json`, `search-content.json`)
- `agent-readability.json`

These are the same static artifacts that the Build section ([`/docs/build/connect-docs-site.md`](docs/build/connect-docs-site.md)) instructs hosts to serve as-is alongside the `/docs/*.md` markdown mirrors.

## Source

- `/docs/reference/llm.md` (reference page for LLM file generation APIs)
- Cross-referenced in `/docs/llms-full/reference.txt`
