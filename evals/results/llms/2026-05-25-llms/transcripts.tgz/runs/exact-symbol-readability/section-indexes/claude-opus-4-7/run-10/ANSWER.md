# Preventing Agent-Readability Artifacts from Being Rewritten

## Helper

**`isAgentReadabilityArtifactPath`**

Documented in [`/docs/reference/llm.md`](docs/reference/llm.md).

## What it does

`isAgentReadabilityArtifactPath` identifies artifact paths that should **not** be rewritten as missing markdown pages. This protects HTTP-discoverable agent files that the docs site serves as static artifacts so they aren't mistaken for absent `/docs/*.md` content.

## What it covers

- `llms.txt`
- `llms-full.txt`
- sitemap files
- `robots.txt`
- search JSON
- `agent-readability.json`
