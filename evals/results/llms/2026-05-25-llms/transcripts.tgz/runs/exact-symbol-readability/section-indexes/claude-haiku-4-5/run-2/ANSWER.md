# Helper to Prevent Agent-Readability Artifacts

## Helper: `isAgentReadabilityArtifactPath`

The `isAgentReadabilityArtifactPath` helper identifies artifact paths that should not be rewritten as missing markdown pages.

### What It Covers

This helper protects the following agent-readability artifacts from being rewritten:

1. **llms.txt** - The root-level LLM bundle index
2. **llms-full.txt** - The full-context bundle containing all generated markdown pages
3. **Sitemap files** - Docs site sitemaps (sitemap.xml, sitemap.md)
4. **robots.txt** - Robots exclusion file
5. **Search JSON** - Search index and search content JSON files
6. **agent-readability.json** - Agent readability configuration file

By identifying these paths, the helper ensures they remain as static artifacts during the docs-site build process rather than being treated as missing pages that need markdown generation.
