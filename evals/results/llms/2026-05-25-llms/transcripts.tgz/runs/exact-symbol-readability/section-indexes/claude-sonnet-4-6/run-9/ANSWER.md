# Preventing Agent-Readability Artifacts from Being Rewritten

## The Helper

**`isAgentReadabilityArtifactPath`**

Source: [LLM files reference](/docs/reference/llm.md)

## What It Does

`isAgentReadabilityArtifactPath` identifies artifact paths that should **not** be rewritten as missing markdown pages. It is the guard that keeps static, agent-readable files from being incorrectly treated as 404 / missing-page content during docs-site routing.

## What It Covers

The helper covers the following artifact paths:

- `llms.txt`
- `llms-full.txt`
- Sitemap files (e.g. `sitemap.xml`, `sitemap.md`)
- `robots.txt`
- Search JSON (search index / search content files)
- `agent-readability.json`

Any path matched by this helper should be served as-is (as a static artifact) rather than falling through to missing-page or markdown-rewrite logic.
