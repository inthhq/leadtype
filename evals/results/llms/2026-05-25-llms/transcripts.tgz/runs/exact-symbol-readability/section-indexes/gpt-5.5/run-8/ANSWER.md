The helper is `isAgentReadabilityArtifactPath`.

It identifies agent-readability/static artifact paths that should be served as-is rather than rewritten as missing markdown pages. It covers `llms.txt`, `llms-full.txt`, sitemap files, `robots.txt`, search JSON files, and `agent-readability.json`.
