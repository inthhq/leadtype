# Answer

## Helper that prevents agent-readability artifacts from being rewritten as missing markdown pages

The helper is **`isAgentReadabilityArtifactPath`**, documented in the [LLM files reference](/docs/reference/llm.md).

### What it covers

`isAgentReadabilityArtifactPath` identifies known static artifact paths that must **not** be treated as missing markdown pages and therefore must not be rewritten or 404'd by the docs site's routing layer. It covers:

| Artifact | Description |
|---|---|
| `llms.txt` | Product-level agent index |
| `llms-full.txt` | Root full-context bundle of every docs page |
| Sitemap files | e.g. `sitemap.xml`, `sitemap.md` |
| `robots.txt` | Crawl-permission declarations |
| Search JSON | Static search index / search content |
| `agent-readability.json` | Agent-readability metadata manifest |

By recognising these paths as legitimate static artifacts, the helper ensures they are served as-is rather than being intercepted and erroneously rendered as "page not found" markdown responses.
