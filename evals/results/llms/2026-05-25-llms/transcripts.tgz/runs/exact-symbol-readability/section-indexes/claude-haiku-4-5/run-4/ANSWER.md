# Agent-Readability Artifact Prevention Helper

## Helper: `isAgentReadabilityArtifactPath`

The helper that prevents agent-readability artifacts from being rewritten as missing markdown pages is **`isAgentReadabilityArtifactPath`**.

## What It Covers

`isAgentReadabilityArtifactPath` identifies artifact paths that should not be rewritten as missing markdown pages. It covers:

- llms.txt
- llms-full.txt
- sitemap files (sitemap.xml, sitemap.md)
- robots.txt
- search JSON files (search-index.json, search-content.json)
- agent-readability.json

These artifacts are static files used for agent-readability and SEO purposes, and the helper ensures they are preserved as-is rather than being incorrectly processed as missing markdown pages during the docs build process.
