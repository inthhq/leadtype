# Answer

## Helper: `isAgentReadabilityArtifactPath`

The helper that prevents agent-readability artifacts from being rewritten as missing markdown pages is **`isAgentReadabilityArtifactPath`**.

### What it covers

`isAgentReadabilityArtifactPath` identifies known static artifact paths so that the docs server does **not** treat them as missing or unresolved markdown pages. It covers the following paths:

- `llms.txt`
- `llms-full.txt`
- Sitemap files (e.g. `sitemap.xml`, `sitemap.md`)
- `robots.txt`
- Search JSON
- `agent-readability.json`

These files are intentionally served as static artifacts — not converted or rewritten — ensuring agents and crawlers can discover and fetch them reliably.

> Source: [LLM files reference](/docs/reference/llm.md)
