# Preventing agent-readability artifact rewrites

## Helper

**`isAgentReadabilityArtifactPath`**

Documented in [`/docs/reference/llm.md`](docs/reference/llm.md).

## What it does

`isAgentReadabilityArtifactPath` identifies artifact paths that should **not** be rewritten as missing markdown pages. Without it, agent-only files (which are not MDX-sourced docs pages) would be mistaken for absent `.md` pages and get rewritten or 404'd by the docs-site's markdown fallback.

## What it covers

The helper recognizes the following agent-readability artifacts:

- `llms.txt`
- `llms-full.txt`
- sitemap files
- `robots.txt`
- search JSON
- `agent-readability.json`

These are the same static artifacts that `/docs/build/connect-docs-site.md` says should be served as-is in website mode, and that bundle (package-docs) mode skips.
