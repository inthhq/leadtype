# Preventing Agent-Readability Artifacts from Being Rewritten

## The Helper

**`isAgentReadabilityArtifactPath`**

This is the helper function documented in the Leadtype Reference under [LLM files](/docs/reference/llm.md) that prevents agent-readability artifacts like `llms.txt` and `llms-full.txt` from being incorrectly rewritten as missing markdown pages.

## What It Covers

`isAgentReadabilityArtifactPath` identifies the following static artifact paths that must be kept as-is and never treated as missing (404) markdown pages:

- `llms.txt`
- `llms-full.txt`
- Sitemap files (e.g., `sitemap.xml`, `sitemap.md`)
- `robots.txt`
- Search JSON
- `agent-readability.json`

These files are intentional, static deployment artifacts that should be served directly rather than being intercepted and rewritten as not-found markdown responses.
