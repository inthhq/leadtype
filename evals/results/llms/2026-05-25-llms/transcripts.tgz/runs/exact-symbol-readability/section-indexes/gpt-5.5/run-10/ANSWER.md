The helper is `isAgentReadabilityArtifactPath`.

It identifies agent-readability/static artifact paths that should be served as artifacts rather than rewritten as missing markdown pages. It covers `llms.txt`, `llms-full.txt`, sitemap files, `robots.txt`, search JSON, and `agent-readability.json`.
