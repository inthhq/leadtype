# Helper That Prevents Agent-Readability Artifacts from Being Rewritten

## Helper Name
`isAgentReadabilityArtifactPath`

## Description
`isAgentReadabilityArtifactPath` identifies artifact paths that should not be rewritten as missing markdown pages. It covers:
- llms.txt
- llms-full.txt
- sitemap files
- robots.txt
- search JSON
- agent-readability.json

This helper ensures that these special agent-readable files are preserved during the docs build process and not treated as missing pages that need to be converted to markdown.
