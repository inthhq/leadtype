# Preventing Agent-Readability Artifacts from Being Rewritten

## Helper

**`isAgentReadabilityArtifactPath`**

## What It Covers

This helper identifies artifact paths that should **not** be rewritten as missing markdown pages. It covers the following static files:

- `llms.txt`
- `llms-full.txt`
- Sitemap files
- `robots.txt`
- Search JSON
- `agent-readability.json`

## Source

Documented in the [LLM files reference](/docs/reference/llm.md).
