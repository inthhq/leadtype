# Agent-Readability Artifact Prevention Helper

## Helper Name
**`isAgentReadabilityArtifactPath`**

## Description
`isAgentReadabilityArtifactPath` is the helper function that prevents agent-readability artifacts from being rewritten as missing markdown pages.

## What It Covers
This helper identifies and protects the following artifact paths from being rewritten:
- `llms.txt`
- `llms-full.txt`
- Sitemap files (`sitemap.xml`, `sitemap.md`)
- `robots.txt`
- Search JSON files (`search-index.json`, `search-content.json`)
- `agent-readability.json`

These static artifacts are essential for agent discovery and navigation of the documentation site and should not be treated as missing markdown pages during the build process.
