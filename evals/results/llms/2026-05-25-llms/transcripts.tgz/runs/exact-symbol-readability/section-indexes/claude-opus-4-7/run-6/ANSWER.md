# Helper that prevents agent-readability artifacts from being rewritten as missing markdown pages

**Helper:** `isAgentReadabilityArtifactPath`

**Source:** [`/docs/reference/llm.md`](/docs/reference/llm.md)

## What it does

`isAgentReadabilityArtifactPath` identifies artifact paths that should **not** be rewritten as missing markdown pages. This matters because docs sites typically rewrite requests for non-existent `.md` URLs, but agent-readability artifacts are static, top-level files that must be served as-is.

## What it covers

The helper recognizes the following agent-readability artifact paths:

- `llms.txt`
- `llms-full.txt`
- sitemap files
- `robots.txt`
- search JSON
- `agent-readability.json`

These are the same static artifacts that the Build guide (`/docs/build/connect-docs-site.md`) instructs sites to expose at fixed URLs so agents can discover and fetch them directly.
