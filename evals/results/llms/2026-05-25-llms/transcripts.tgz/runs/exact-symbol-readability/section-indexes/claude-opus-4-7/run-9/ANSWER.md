# Preventing agent-readability artifacts from being rewritten as missing markdown

## Helper

**`isAgentReadabilityArtifactPath`**

Documented in [`/docs/reference/llm.md`](docs/reference/llm.md), this helper identifies artifact paths that should **not** be rewritten as missing markdown pages.

## What it covers

It recognizes the following agent-readability artifacts:

- `llms.txt`
- `llms-full.txt`
- sitemap files
- `robots.txt`
- search JSON
- `agent-readability.json`

## Why it matters

Per [`/docs/build/connect-docs-site.md`](docs/build/connect-docs-site.md), in website mode a docs site serves markdown mirrors under `/docs/*.md` and may translate requests with `Accept: text/markdown` (or known AI user agents) into markdown lookups. Without this helper, requests for static artifacts like `/llms.txt` or `/llms-full.txt` could be misrouted through the markdown-page resolver and reported as missing pages. `isAgentReadabilityArtifactPath` short-circuits that rewrite so these files continue to be served as static artifacts.
