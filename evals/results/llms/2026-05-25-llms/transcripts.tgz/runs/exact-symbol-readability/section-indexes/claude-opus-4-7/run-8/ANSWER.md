# Preventing agent-readability artifacts from being rewritten as missing markdown pages

## Helper

**`isAgentReadabilityArtifactPath`**

Documented in [`docs/reference/llm.md`](docs/reference/llm.md):

> `isAgentReadabilityArtifactPath` identifies artifact paths that should not be rewritten as missing markdown pages.

## What it covers

The helper recognizes the following agent-readability artifact paths so they are served as-is (static artifacts) rather than being treated as missing docs pages and rewritten:

- `llms.txt`
- `llms-full.txt`
- sitemap files (e.g. `sitemap.xml`, `sitemap.md`)
- `robots.txt`
- search JSON (search index / search content)
- `agent-readability.json`

These are the same files the build's "connect a docs site" guidance keeps as static artifacts alongside the markdown mirrors under `/docs/*.md`.
