# Answer

## Helper: `isAgentReadabilityArtifactPath`

The helper that prevents agent-readability artifacts from being rewritten as missing markdown pages is **`isAgentReadabilityArtifactPath`**, documented in the [LLM files reference](/docs/reference/llm.md).

### What it covers

`isAgentReadabilityArtifactPath` identifies known static artifact paths so that the docs server/router does **not** treat them as missing or broken markdown pages. The paths it covers are:

- `llms.txt`
- `llms-full.txt`
- Sitemap files (e.g. `sitemap.xml`, `sitemap.md`)
- `robots.txt`
- Search JSON
- `agent-readability.json`

By recognising these paths as intentional static artifacts, the helper ensures they are served as-is rather than triggering a "missing page" error or being incorrectly rewritten by the docs pipeline.
