# Helper that prevents agent-readability artifacts from being rewritten as missing markdown

**Helper:** `isAgentReadabilityArtifactPath`

This helper, documented in [`/docs/reference/llm.md`](docs/reference/llm.md), identifies artifact paths that should **not** be rewritten as missing markdown pages by the docs-site routing layer.

## What it covers

`isAgentReadabilityArtifactPath` recognizes the following static, agent-readability artifacts:

- `llms.txt`
- `llms-full.txt`
- sitemap files (e.g. `sitemap.xml`, `sitemap.md`)
- `robots.txt`
- search JSON (e.g. `search-index.json`, `search-content.json`)
- `agent-readability.json`

By matching these paths, the helper ensures the build/serving layer leaves them as-is rather than treating them as missing markdown docs pages and rewriting them.

## Source

> "isAgentReadabilityArtifactPath identifies artifact paths that should not be rewritten as missing markdown pages. It covers llms.txt, llms-full.txt, sitemap files, robots.txt, search JSON, and agent-readability.json."
>
> — `docs/reference/llm.md`
