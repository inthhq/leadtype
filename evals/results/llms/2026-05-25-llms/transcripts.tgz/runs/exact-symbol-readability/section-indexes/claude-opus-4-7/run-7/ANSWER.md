# Preventing agent-readability artifacts from being rewritten as missing markdown pages

## Helper

**`isAgentReadabilityArtifactPath`**

## What it does

Per the Leadtype docs (`docs/reference/llm.md`):

> `isAgentReadabilityArtifactPath` identifies artifact paths that should not be rewritten as missing markdown pages.

## What it covers

The helper covers the following agent-readability artifacts:

- `llms.txt`
- `llms-full.txt`
- sitemap files
- `robots.txt`
- search JSON
- `agent-readability.json`

These paths are static deployment artifacts (not MDX-derived markdown pages), so the helper prevents a docs-site request handler from treating them as missing markdown and rewriting them.

## Source

- `/docs/reference/llm.md` (also surfaced in `/docs/llms-full/reference.txt`)
