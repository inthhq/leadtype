# Preventing Agent-Readability Artifacts from Being Rewritten

## Helper

**`isAgentReadabilityArtifactPath`**

Defined in the [LLM files reference](/docs/reference/llm.md), this helper identifies artifact paths that should **not** be rewritten as missing markdown pages.

## What it covers

It covers the following static artifacts:

- `llms.txt`
- `llms-full.txt`
- Sitemap files (e.g. `sitemap.xml`, `sitemap.md`)
- `robots.txt`
- Search JSON
- `agent-readability.json`

By recognising these paths as known agent-readability artifacts, the helper prevents the docs site from mistakenly treating them as absent markdown content and serving a 404-style "missing page" response in their place.
