# Agent-Readability Artifact Protection

## Helper: `isAgentReadabilityArtifactPath`

The **`isAgentReadabilityArtifactPath`** helper prevents agent-readability artifacts from being rewritten as missing markdown pages.

### Coverage

This helper covers the following artifact paths:
- `llms.txt`
- `llms-full.txt`
- Sitemap files
- `robots.txt`
- Search JSON
- `agent-readability.json`

These static artifacts are identified and protected so they are not accidentally rewritten as missing markdown pages during the docs build process.

**Source:** [LLM files Reference](/docs/reference/llm.md)
