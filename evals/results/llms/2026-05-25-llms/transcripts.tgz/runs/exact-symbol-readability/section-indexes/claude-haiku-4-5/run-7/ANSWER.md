# Agent-Readability Artifact Prevention Helper

## Helper Name
`isAgentReadabilityArtifactPath`

## Description
`isAgentReadabilityArtifactPath` is the helper that prevents agent-readability artifacts from being rewritten as missing markdown pages. 

It covers:
- llms.txt
- llms-full.txt
- sitemap files
- robots.txt
- search JSON
- agent-readability.json

This helper ensures that these special artifact files are preserved during the docs build process and are not incorrectly treated as missing markdown pages that need to be generated.
