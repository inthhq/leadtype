# Agent-Readability Artifact Prevention

## Helper: `isAgentReadabilityArtifactPath`

The `isAgentReadabilityArtifactPath` helper identifies artifact paths that should not be rewritten as missing markdown pages.

## Coverage

It covers the following agent-readability artifacts:
- `llms.txt`
- `llms-full.txt`
- Sitemap files
- `robots.txt`
- Search JSON files
- `agent-readability.json`

This helper ensures that these essential agent-readable files are protected from being treated as standard markdown pages that might be missing or need to be rewritten by the docs pipeline.
