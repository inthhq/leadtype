# Preventing agent-readability artifact rewrites

## Helper

**`isAgentReadabilityArtifactPath`**

Documented in [`/docs/reference/llm.md`](docs/reference/llm.md), this helper identifies artifact paths that should **not** be rewritten as missing markdown pages. It is what a docs-site build/serve layer calls before applying any "rewrite to `.md`" or 404-fallback logic, so that agent-readability files are served as-is rather than treated as absent docs pages.

## What it covers

According to the Reference page, `isAgentReadabilityArtifactPath` covers the following static agent-readability artifacts:

- `llms.txt`
- `llms-full.txt`
- sitemap files (e.g. `docs/sitemap.xml`, `docs/sitemap.md`)
- `robots.txt`
- search JSON (`search-index.json`, `search-content.json`)
- `agent-readability.json`

## Why it matters

These files are produced by Leadtype's website mode (see `docs/quickstart.md` and `docs/build/connect-docs-site.md`) and must be kept as static artifacts at the site root / under `/docs/`. Without this guard, a generic "rewrite unknown paths to markdown" handler could turn requests for, say, `/llms.txt` or `/llms-full.txt` into lookups for non-existent markdown pages, breaking discovery for HTTP-based agents.
