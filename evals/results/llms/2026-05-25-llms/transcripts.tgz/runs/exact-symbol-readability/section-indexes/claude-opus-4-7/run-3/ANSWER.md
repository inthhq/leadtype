# Preventing agent-readability artifacts from being rewritten as missing markdown

**Helper:** `isAgentReadabilityArtifactPath`

**Source:** [`/docs/reference/llm.md`](/docs/reference/llm.md) (LLM files reference)

## What it does

`isAgentReadabilityArtifactPath` identifies artifact paths that should **not** be rewritten as missing markdown pages. It is the guard used by docs-site wiring so that requests for agent-readability artifacts are served as the static files Leadtype generates, rather than being treated as docs pages whose `.md` mirror is missing.

## What it covers

According to the Reference docs, the helper covers the following artifact paths:

- `llms.txt`
- `llms-full.txt`
- sitemap files
- `robots.txt`
- search JSON (e.g. `search-index.json`, `search-content.json`)
- `agent-readability.json`

These match the static artifacts that the Build section ([`/docs/build/connect-docs-site.md`](/docs/build/connect-docs-site.md)) says should be kept as-is when serving a hosted docs site.
