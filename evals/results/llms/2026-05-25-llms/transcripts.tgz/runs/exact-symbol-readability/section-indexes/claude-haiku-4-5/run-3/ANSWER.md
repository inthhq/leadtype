# Agent-Readability Artifact Prevention Helper

## Helper: `isAgentReadabilityArtifactPath`

The `isAgentReadabilityArtifactPath` helper prevents agent-readability artifacts like `llms.txt` and `llms-full.txt` from being rewritten as missing markdown pages.

## Coverage

This helper covers the following artifact paths:
- `llms.txt`
- `llms-full.txt`
- Sitemap files (sitemap.xml, sitemap.md)
- `robots.txt`
- Search JSON files (search-index.json, search-content.json)
- `agent-readability.json`

These are static artifacts that must be preserved and not rewritten as standard markdown pages during the docs site generation process.
