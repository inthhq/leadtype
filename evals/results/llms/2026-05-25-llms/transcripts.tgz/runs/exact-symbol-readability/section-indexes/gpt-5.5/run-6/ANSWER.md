The helper is `isAgentReadabilityArtifactPath`.

It identifies agent-readability artifact paths that should remain static and not be rewritten as missing markdown pages. It covers `llms.txt`, `llms-full.txt`, sitemap files, `robots.txt`, search JSON, and `agent-readability.json`.
