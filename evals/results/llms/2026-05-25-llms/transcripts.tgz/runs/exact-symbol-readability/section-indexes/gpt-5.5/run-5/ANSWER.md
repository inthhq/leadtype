The helper is `isAgentReadabilityArtifactPath`.

It identifies generated agent-readability artifact paths so the docs-site routing layer does not rewrite them as missing markdown pages. It covers `llms.txt`, `llms-full.txt`, sitemap files, `robots.txt`, search JSON files, and `agent-readability.json`.
