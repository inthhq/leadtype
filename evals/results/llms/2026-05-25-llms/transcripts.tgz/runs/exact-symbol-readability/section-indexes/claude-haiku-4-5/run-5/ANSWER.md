# Agent-Readability Artifact Prevention Helper

## Helper Name
**isAgentReadabilityArtifactPath**

## Description
`isAgentReadabilityArtifactPath` is a helper that identifies artifact paths that should not be rewritten as missing markdown pages. 

It covers the following agent-readability artifacts:
- llms.txt
- llms-full.txt
- sitemap files (robots.txt, sitemap.xml, sitemap.md)
- robots.txt
- search JSON files
- agent-readability.json

By protecting these artifacts from being rewritten as missing markdown pages, the helper ensures that critical agent-readable deployment artifacts remain intact and properly served on hosted docs sites.
