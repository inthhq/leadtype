# Helper: `isAgentReadabilityArtifactPath`

The helper that prevents agent-readability artifacts from being rewritten as missing markdown pages is **`isAgentReadabilityArtifactPath`**.

## What It Covers

`isAgentReadabilityArtifactPath` identifies static artifact paths that must not be treated as missing-page errors or rewritten into markdown 404 responses. It covers:

- `llms.txt`
- `llms-full.txt`
- Sitemap files
- `robots.txt`
- Search JSON
- `agent-readability.json`

These files are kept as-is (static artifacts) so that agents and crawlers can always discover and fetch them directly without interference from the docs site's markdown-routing logic.

> Source: [LLM files reference](/docs/reference/llm.md)
