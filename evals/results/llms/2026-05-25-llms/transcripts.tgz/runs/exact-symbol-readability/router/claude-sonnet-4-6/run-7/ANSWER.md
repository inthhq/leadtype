# Preventing Agent-Readability Artifacts from Being Rewritten

## Helper: `isAgentReadabilityArtifactPath`

The helper that prevents agent-readability artifacts from being rewritten as missing markdown pages is **`isAgentReadabilityArtifactPath`**.

### What it covers

`isAgentReadabilityArtifactPath` identifies artifact paths that must be served as static files rather than treated as missing (404) markdown pages. It covers the following paths:

- `llms.txt`
- `llms-full.txt`
- Sitemap files (e.g., `sitemap.xml`, `sitemap.md`)
- `robots.txt`
- Search JSON
- `agent-readability.json`

By recognising these paths, the helper ensures that any request matching one of these well-known agent/crawler artifacts is passed through to the static file rather than being incorrectly handled as a missing docs page.

> Source: [LLM files reference](/docs/reference/llm.md) via the [Reference full-context file](/docs/llms-full/reference.txt).
