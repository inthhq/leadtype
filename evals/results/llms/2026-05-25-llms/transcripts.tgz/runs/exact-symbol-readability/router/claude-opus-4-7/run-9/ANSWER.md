# Preventing Agent-Readability Artifacts from Being Rewritten

## Helper

**`isAgentReadabilityArtifactPath`**

Documented in [`/docs/reference/llm.md`](/docs/reference/llm.md) (surfaced via the Reference full-context router at `/docs/llms-full/reference.txt`).

## What it does

`isAgentReadabilityArtifactPath` identifies artifact paths that should **not** be rewritten as missing markdown pages. These are the static agent-readability files a Leadtype-powered docs site serves directly, rather than treating them as `/docs/*.md` content that could be flagged as missing.

## What it covers

The helper covers the following artifact paths:

- `llms.txt`
- `llms-full.txt`
- sitemap files
- `robots.txt`
- search JSON
- `agent-readability.json`

These match the static artifacts the build emits and that the docs site is expected to serve as-is (per `/docs/build/connect-docs-site.md`), so request-rewriting logic that maps unknown URLs to markdown pages must skip them.
