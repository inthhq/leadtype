# Agent-Readability Artifact Prevention

## Helper: `isAgentReadabilityArtifactPath`

The helper **`isAgentReadabilityArtifactPath`** prevents agent-readability artifacts from being rewritten as missing markdown pages.

## What It Covers

This helper identifies and protects the following artifact paths:
- `llms.txt` - Product-level agent routing file
- `llms-full.txt` - Full-context fallback containing all generated markdown docs pages
- Sitemap files (`sitemap.xml`, `sitemap.md`)
- `robots.txt` - Search engine and agent directives
- Search JSON files (search-index.json, search-content.json)
- `agent-readability.json` - Agent readability metadata

By identifying these paths, `isAgentReadabilityArtifactPath` ensures they are preserved as static artifacts rather than being replaced with generated markdown page mirrors during the build process.
