# Preventing agent-readability artifacts from being rewritten as missing markdown

## Helper

**`isAgentReadabilityArtifactPath`**

## What it does

Per the Leadtype docs (`/docs/reference/llm.md`, also surfaced in `/docs/llms-full/reference.txt`):

> `isAgentReadabilityArtifactPath` identifies artifact paths that should not be rewritten as missing markdown pages.

In other words, when a docs site's routing/rewrite layer would otherwise treat an unknown path as a missing `*.md` page and rewrite it accordingly, this helper flags the path as an agent-readability artifact that must be served as-is (static) instead.

## What it covers

The helper covers these static, agent-readable artifacts:

- `llms.txt`
- `llms-full.txt`
- sitemap files (e.g. `docs/sitemap.xml`, `docs/sitemap.md`)
- `robots.txt`
- search JSON (e.g. `search-index.json`, `search-content.json`)
- `agent-readability.json`

These are the same files that `/docs/build/connect-docs-site.md` says should "be kept as static artifacts" alongside the markdown mirrors under `/docs/*.md`.

## Source pages

- `/llms.txt` → `/llms-full.txt` → `/docs/llms-full/reference.txt`
- `/docs/reference/llm.md`
- Corroborated by `/docs/build/connect-docs-site.md`
