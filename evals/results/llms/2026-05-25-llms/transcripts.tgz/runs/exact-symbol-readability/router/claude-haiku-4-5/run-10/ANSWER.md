# Agent-Readability Artifact Prevention

## Helper: `isAgentReadabilityArtifactPath`

The `isAgentReadabilityArtifactPath` helper identifies artifact paths that should not be rewritten as missing markdown pages.

## Coverage

It covers:
- `llms.txt`
- `llms-full.txt`
- Sitemap files
- `robots.txt`
- Search JSON files
- `agent-readability.json`

This helper ensures that these critical agent-readability artifacts remain static and are not mistakenly treated as missing markdown pages that need to be rewritten.
