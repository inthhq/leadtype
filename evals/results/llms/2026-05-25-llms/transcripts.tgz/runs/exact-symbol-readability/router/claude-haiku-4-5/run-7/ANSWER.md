# Helper That Prevents Agent-Readability Artifacts

The helper is **`isAgentReadabilityArtifactPath`**.

## What It Covers

`isAgentReadabilityArtifactPath` identifies artifact paths that should not be rewritten as missing markdown pages. It covers:

- `llms.txt`
- `llms-full.txt`
- Sitemap files
- `robots.txt`
- Search JSON files
- `agent-readability.json`

This helper ensures that these agent-readability artifacts are protected from being incorrectly processed as missing markdown pages during the documentation build pipeline.
