# Agent-Readability Artifact Protection Helper

## Helper Function

**`isAgentReadabilityArtifactPath`** is the helper that prevents agent-readability artifacts from being rewritten as missing markdown pages.

## What It Covers

The `isAgentReadabilityArtifactPath` function identifies and protects the following artifact paths:

- `llms.txt` - The root HTTP agent entry point
- `llms-full.txt` - The full-context fallback containing all generated markdown pages
- Sitemap files (sitemap.xml, sitemap.md)
- `robots.txt` - Robot directives
- Search JSON files (search-index.json, search-content.json)
- `agent-readability.json` - Agent readability metadata

These artifacts should remain as static files and not be rewritten as missing markdown pages in the hosted docs site pipeline.
