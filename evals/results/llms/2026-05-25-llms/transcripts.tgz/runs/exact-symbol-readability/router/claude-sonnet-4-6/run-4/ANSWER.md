# Preventing Agent-Readability Artifacts from Being Rewritten

## Helper

**`isAgentReadabilityArtifactPath`**

This helper, documented in the [LLM files reference](/docs/reference/llm.md), identifies artifact paths that should **not** be rewritten as missing markdown pages.

## What It Covers

`isAgentReadabilityArtifactPath` covers the following static artifacts:

- `llms.txt`
- `llms-full.txt`
- Sitemap files (e.g., `sitemap.xml`, `sitemap.md`)
- `robots.txt`
- Search JSON
- `agent-readability.json`

By recognising these paths as known agent-readability artifacts, the helper ensures they are served as-is rather than being treated as missing pages and rewritten as 404 markdown responses.
