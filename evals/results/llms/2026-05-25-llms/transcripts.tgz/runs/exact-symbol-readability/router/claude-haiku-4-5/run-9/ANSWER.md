# Helper for Preventing Agent-Readability Artifacts Rewrite

## Helper Name
`isAgentReadabilityArtifactPath`

## Description
The `isAgentReadabilityArtifactPath` helper identifies artifact paths that should not be rewritten as missing markdown pages. It covers the following agent-readable artifacts:

- `llms.txt` - The product-level routing file for HTTP agents
- `llms-full.txt` - The root full-context fallback containing all generated markdown docs pages
- Sitemap files (`sitemap.xml`, `sitemap.md`)
- `robots.txt` - Search engine directives
- Search JSON files (`search-index.json`, `search-content.json`)
- `agent-readability.json` - Agent readability metadata

This helper prevents these static artifacts from being incorrectly overwritten or treated as missing markdown pages during the build process, ensuring they remain intact and functional for agent discovery and navigation.
