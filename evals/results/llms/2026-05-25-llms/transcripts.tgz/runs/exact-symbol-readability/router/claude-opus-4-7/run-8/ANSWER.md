# Preventing agent-readability artifacts from being rewritten as missing markdown pages

## Helper

**`isAgentReadabilityArtifactPath`**

Documented in [`/docs/reference/llm.md`](/docs/reference/llm.md) (reached via `/llms.txt` → `/llms-full.txt` → `/docs/llms-full/reference.txt`).

## What it does

`isAgentReadabilityArtifactPath` identifies artifact paths that should **not** be rewritten as missing markdown pages. It is the guard used by hosted docs-site routing so that requests for these static, agent-readability files are served as-is rather than being treated as docs pages that need a markdown fallback.

## What it covers

The helper recognizes the following agent-readability artifact paths:

- `llms.txt`
- `llms-full.txt`
- sitemap files (e.g. `sitemap.xml`, `sitemap.md`)
- `robots.txt`
- search JSON (search index / search content)
- `agent-readability.json`

These are exactly the artifacts the build step emits as static files for HTTP discovery by agents (see `/docs/build/connect-docs-site.md`), so they must bypass the "rewrite as markdown" path used for normal docs pages.
