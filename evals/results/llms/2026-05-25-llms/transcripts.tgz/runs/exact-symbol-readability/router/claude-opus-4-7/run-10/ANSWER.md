# Preventing agent-readability artifacts from being rewritten as missing markdown pages

## Helper

**`isAgentReadabilityArtifactPath`**

Source: [`docs/reference/llm.md`](/docs/reference/llm.md) (also surfaced in the reference router at [`docs/llms-full/reference.txt`](/docs/llms-full/reference.txt)).

## What it does

`isAgentReadabilityArtifactPath` identifies artifact paths that should **not** be rewritten as missing markdown pages. Without it, requests for these static agent-readability files could be incorrectly treated as missing `/docs/*.md` routes and rewritten/404'd.

## What it covers

The helper recognizes the following agent-readability artifacts:

- `llms.txt`
- `llms-full.txt`
- sitemap files
- `robots.txt`
- search JSON (e.g. `search-index.json`, `search-content.json`)
- `agent-readability.json`

These are the static artifacts a Leadtype website-mode build emits at the site root / under `/docs/`, and they must be served as-is rather than routed through the markdown-page rewrite logic.
