# Helper That Prevents Agent-Readability Artifact Rewrites

The helper is **`isAgentReadabilityArtifactPath`**.

## What it covers

`isAgentReadabilityArtifactPath` identifies artifact paths that should **not** be rewritten as missing markdown pages. It covers the following well-known static artifacts:

- `llms.txt`
- `llms-full.txt`
- Sitemap files (e.g. `sitemap.xml`, `sitemap.md`)
- `robots.txt`
- Search JSON
- `agent-readability.json`

By recognising these paths, the helper ensures that requests to those files are served as-is (static artifacts), rather than being misinterpreted as broken or missing documentation pages and rewritten to error/404 markdown responses.

> Source: [LLM files reference](/docs/reference/llm.md) in the Leadtype docs.
