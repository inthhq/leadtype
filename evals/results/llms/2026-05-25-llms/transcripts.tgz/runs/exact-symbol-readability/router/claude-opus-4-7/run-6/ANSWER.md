# Prevent agent-readability artifacts from being rewritten

## Helper

**`isAgentReadabilityArtifactPath`**

## What it does

Per the Leadtype docs (`/docs/reference/llm.md`, also referenced in `/docs/llms-full/reference.txt`):

> `isAgentReadabilityArtifactPath` identifies artifact paths that should not be rewritten as missing markdown pages.

## What it covers

The helper recognizes these agent-readability artifact paths so they are served as-is rather than treated as missing markdown docs:

- `llms.txt`
- `llms-full.txt`
- sitemap files
- `robots.txt`
- search JSON
- `agent-readability.json`

These are the same static artifacts that `/docs/build/connect-docs-site.md` says hosted docs sites should serve directly, and that bundle mode (`/docs/package-docs/bundle.md`) deliberately skips.
