# Preventing agent-readability artifacts from being rewritten

## Helper

**`isAgentReadabilityArtifactPath`**

Documented in [`docs/reference/llm.md`](docs/reference/llm.md), this helper identifies artifact paths that should **not** be rewritten as missing markdown pages.

## What it covers

It covers the following agent-readability artifacts:

- `llms.txt`
- `llms-full.txt`
- sitemap files
- `robots.txt`
- search JSON
- `agent-readability.json`

These files are served as static artifacts by a hosted docs site (per the build guidance in `docs/build/connect-docs-site.md`), so the markdown-fallback logic uses `isAgentReadabilityArtifactPath` to recognize them and avoid treating their paths as missing `.md` documentation pages.
