# Agent-Readability Artifact Prevention Helper

## Helper: `isAgentReadabilityArtifactPath`

The `isAgentReadabilityArtifactPath` helper identifies artifact paths that should not be rewritten as missing markdown pages.

## Coverage

This helper covers the following artifact types:
- llms.txt
- llms-full.txt
- Sitemap files
- robots.txt
- Search JSON files
- agent-readability.json

These static artifacts are critical for agent-readability and discovery on hosted documentation sites, and the helper ensures they are preserved and not accidentally converted into missing markdown pages during the site build process.
