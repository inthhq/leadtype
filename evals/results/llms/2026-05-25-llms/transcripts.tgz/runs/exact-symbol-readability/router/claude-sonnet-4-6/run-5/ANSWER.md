# Preventing Agent-Readability Artifacts from Being Rewritten

## Helper

**`isAgentReadabilityArtifactPath`**

## Description

`isAgentReadabilityArtifactPath` identifies artifact paths that should **not** be rewritten as missing markdown pages. It covers the following static artifacts:

- `llms.txt`
- `llms-full.txt`
- Sitemap files (e.g., `sitemap.xml`, `sitemap.md`)
- `robots.txt`
- Search JSON
- `agent-readability.json`

By recognizing these paths as known agent-readability artifacts, the helper ensures they are treated as static files and pass through unchanged, rather than being incorrectly handled as absent or broken markdown documentation pages.

> Source: [`/docs/reference/llm.md`](/docs/reference/llm.md)
