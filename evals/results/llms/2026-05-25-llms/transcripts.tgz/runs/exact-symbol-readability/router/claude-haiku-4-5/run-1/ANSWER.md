# Answer: Prevent Agent-Readability Artifacts

The helper that prevents agent-readability artifacts from being rewritten as missing markdown pages is **`isAgentReadabilityArtifactPath`**.

## What It Covers

`isAgentReadabilityArtifactPath` identifies artifact paths that should not be rewritten as missing markdown pages. It covers:

- `llms.txt` - Product-level routing file
- `llms-full.txt` - Full-context file containing all generated markdown docs pages
- Sitemap files - XML and markdown sitemaps
- `robots.txt` - Robot exclusion file
- Search JSON - Search index and content files
- `agent-readability.json` - Agent readability configuration file

This helper is essential for website mode to ensure these critical agent-facing artifacts are preserved and not inadvertently rewritten by missing page handlers in the docs site build process.
