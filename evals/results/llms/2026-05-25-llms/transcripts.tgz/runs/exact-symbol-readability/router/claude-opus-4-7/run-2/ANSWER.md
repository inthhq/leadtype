# Preventing Agent-Readability Artifacts from Being Rewritten as Missing Markdown Pages

## Helper

**`isAgentReadabilityArtifactPath`**

Per the Leadtype docs (`/docs/reference/llm.md`, surfaced via `/llms-full.txt` → Reference topic), this helper identifies artifact paths that should **not** be rewritten as missing markdown pages.

## What it covers

It covers the static agent-readability artifacts that a docs site serves alongside the markdown mirrors:

- `llms.txt`
- `llms-full.txt`
- sitemap files
- `robots.txt`
- search JSON
- `agent-readability.json`

## Why it matters

In website mode, Leadtype serves markdown for `/docs/*.md` requests (e.g. when `Accept: text/markdown` or a known AI user agent asks for a docs page). Without this guard, the markdown-rewrite layer could treat the agent artifacts above as missing docs pages. `isAgentReadabilityArtifactPath` excludes them so they are served as the static artifacts they are, keeping `/llms.txt`, `/llms-full.txt`, sitemap files, `robots.txt`, the search index JSON, and `agent-readability.json` intact for agent discovery.

## Source

- `/llms.txt` → `/llms-full.txt` → `/docs/llms-full/reference.txt` (inlined content of `/docs/reference/llm.md`)
