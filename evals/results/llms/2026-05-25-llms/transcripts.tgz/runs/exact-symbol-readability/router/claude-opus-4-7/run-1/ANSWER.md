# Preventing agent-readability artifacts from being rewritten as missing markdown pages

## Helper

**`isAgentReadabilityArtifactPath`**

Documented in [`/docs/reference/llm.md`](docs/reference/llm.md) (surfaced via `docs/llms-full/reference.txt`).

## What it does

`isAgentReadabilityArtifactPath` identifies artifact paths that should **not** be rewritten as missing markdown pages. This prevents the docs site's markdown-rewriting layer (which normally serves `.md` mirrors for agent requests) from treating these static agent-readability files as missing docs pages.

## What it covers

The helper covers the following static artifacts:

- `llms.txt`
- `llms-full.txt`
- Sitemap files
- `robots.txt`
- Search JSON
- `agent-readability.json`

These are the same artifacts that the "Connect a docs site" guide says should be kept as static files at the site root (alongside serving markdown mirrors under `/docs/*.md` for agent requests).
