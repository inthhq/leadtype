# Preventing Agent-Readability Artifact Rewrites

## Helper

**`isAgentReadabilityArtifactPath`**

Documented in [`/docs/reference/llm.md`](/docs/reference/llm.md) (surfaced via `/docs/llms-full/reference.txt`).

## What it does

`isAgentReadabilityArtifactPath` identifies artifact paths that should **not** be rewritten as missing markdown pages. In other words, when a request comes in for one of these static agent-readability artifacts, the helper flags it so the docs site does not try to treat it as a regular `/docs/*.md` page and fall through to a "missing markdown" rewrite.

## What it covers

The helper recognizes the following artifact paths:

- `llms.txt`
- `llms-full.txt`
- sitemap files (e.g. `sitemap.xml`, `sitemap.md`)
- `robots.txt`
- search JSON (the static search index/content files)
- `agent-readability.json`

These are the same static artifacts the build documentation (`/docs/build/connect-docs-site.md`) says should be served as-is alongside the markdown mirrors under `/docs/*.md`.
