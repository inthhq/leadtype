# Helper That Prevents Agent-Readability Artifacts from Being Rewritten

## Helper: `isAgentReadabilityArtifactPath`

Documented in the [LLM files reference](/docs/reference/llm.md), `isAgentReadabilityArtifactPath` is the helper that prevents agent-readability artifacts from being incorrectly rewritten as missing markdown pages.

## What It Covers

It identifies the following artifact paths as protected static files that must **not** be treated as absent or missing docs pages:

- `llms.txt`
- `llms-full.txt`
- Sitemap files (e.g., `sitemap.xml`, `sitemap.md`)
- `robots.txt`
- Search JSON
- `agent-readability.json`

By recognising these paths, the framework ensures they are served as-is (static artifacts) rather than triggering any "page not found" or markdown-generation fallback logic.
