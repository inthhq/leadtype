# Preventing Agent-Readability Artifacts from Being Rewritten

## The Helper

**`isAgentReadabilityArtifactPath`**

Documented in the [LLM files reference](/docs/reference/llm.md), this helper identifies artifact paths that should **not** be rewritten as missing markdown pages.

## What It Covers

It covers the following static artifact paths:

- `llms.txt`
- `llms-full.txt`
- Sitemap files (e.g., `sitemap.xml`, `sitemap.md`)
- `robots.txt`
- Search JSON
- `agent-readability.json`

By recognising these paths as known agent-readability artifacts, the helper ensures a docs site's router or middleware skips the "missing page" rewrite logic for them, serving them as their intended static files instead.
