# Agent-Readability Artifact Helper

## Helper Name
**isAgentReadabilityArtifactPath**

## Description
`isAgentReadabilityArtifactPath` identifies artifact paths that should not be rewritten as missing markdown pages. 

## Coverage
This helper covers the following agent-readability artifacts:
- `llms.txt`
- `llms-full.txt`
- Sitemap files
- `robots.txt`
- Search JSON
- `agent-readability.json`

These artifacts are protected from being incorrectly converted into markdown pages during the docs generation process.
