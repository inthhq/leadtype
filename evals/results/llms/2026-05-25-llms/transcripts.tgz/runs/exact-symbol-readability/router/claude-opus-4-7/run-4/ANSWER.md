# Preventing agent-readability artifact rewrites

## Helper

**`isAgentReadabilityArtifactPath`**

(Documented in [`/docs/reference/llm.md`](/docs/reference/llm.md), surfaced via the Reference full-context router at `/docs/llms-full/reference.txt`.)

## What it does

`isAgentReadabilityArtifactPath` identifies artifact paths that should **not** be rewritten as missing markdown pages. Without it, a docs server's markdown-fallback logic could mistake these static agent files for absent `/docs/*.md` pages and try to rewrite or 404 them.

## What it covers

The helper recognizes the following agent-readability artifacts:

- `llms.txt`
- `llms-full.txt`
- sitemap files
- `robots.txt`
- search JSON
- `agent-readability.json`

These are the static artifacts that a Leadtype-powered docs site serves at the site root (see `/docs/build/connect-docs-site.md`), so the helper ensures the markdown-rewrite layer leaves them alone.
