# Helper That Prevents Agent-Readability Artifacts

## Helper Name
**`isAgentReadabilityArtifactPath`**

## Description
`isAgentReadabilityArtifactPath` is a helper function that identifies artifact paths that should not be rewritten as missing markdown pages. 

It covers the following agent-readability artifacts:
- `llms.txt`
- `llms-full.txt`
- Sitemap files (e.g., `sitemap.xml`, `sitemap.md`)
- `robots.txt`
- Search JSON files
- `agent-readability.json`

This helper ensures that these critical agent-discovery and metadata files are preserved as static artifacts during the docs site build process and are not accidentally treated as missing markdown pages that need to be generated.
