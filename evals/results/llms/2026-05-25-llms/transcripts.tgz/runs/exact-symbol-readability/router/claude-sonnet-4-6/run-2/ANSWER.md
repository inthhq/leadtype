# Preventing Agent-Readability Artifacts from Being Rewritten

## Helper

**`isAgentReadabilityArtifactPath`**

## Description

`isAgentReadabilityArtifactPath` is a helper that identifies artifact paths which should **not** be rewritten as missing markdown pages. It covers the following files:

- `llms.txt`
- `llms-full.txt`
- Sitemap files
- `robots.txt`
- Search JSON
- `agent-readability.json`

By recognising these paths as known static artifacts, the helper prevents a docs site's routing or middleware from mistakenly treating them as absent content and returning a "missing page" markdown response instead of serving the actual static file.

> Source: [LLM files reference](/docs/reference/llm.md)
