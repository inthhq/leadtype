# Agent-Readability Artifact Prevention

## Helper: `isAgentReadabilityArtifactPath`

The helper that prevents agent-readability artifacts from being rewritten as missing markdown pages is **`isAgentReadabilityArtifactPath`**.

### What It Covers

This helper identifies artifact paths that should be protected from being rewritten as missing markdown pages. It covers the following artifacts:

- `llms.txt` - Product-level agent routing file
- `llms-full.txt` - Full context router with all markdown pages
- Sitemap files (e.g., `sitemap.xml`, `sitemap.md`)
- `robots.txt` - Robots exclusion/routing file
- Search JSON files (search index and content)
- `agent-readability.json` - Agent readability metadata file

By protecting these files from rewriting, the helper ensures that these critical agent-readable artifacts remain static and are not inadvertently converted into missing markdown page entries during the docs generation process.
