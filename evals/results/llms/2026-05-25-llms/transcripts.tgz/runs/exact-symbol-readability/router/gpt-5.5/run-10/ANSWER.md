The helper is `isAgentReadabilityArtifactPath`.

It identifies generated agent-readability artifacts that should stay as static files rather than being rewritten as missing markdown pages. It covers `llms.txt`, `llms-full.txt`, sitemap files, `robots.txt`, search JSON files, and `agent-readability.json`.
