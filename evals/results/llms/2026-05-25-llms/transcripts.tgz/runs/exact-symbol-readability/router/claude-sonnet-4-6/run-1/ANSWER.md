# Preventing Agent-Readability Artifacts from Being Rewritten

## Helper

**`isAgentReadabilityArtifactPath`**

## Description

`isAgentReadabilityArtifactPath` is a helper that identifies artifact paths which should **not** be rewritten as missing markdown pages. It covers the following static files:

- `llms.txt`
- `llms-full.txt`
- Sitemap files (e.g. `sitemap.xml`, `sitemap.md`)
- `robots.txt`
- Search JSON
- `agent-readability.json`

By recognising these paths as known agent-readability artifacts, the helper ensures that requests to them are served as their intended static files rather than being incorrectly treated as absent or broken markdown documentation pages.

*(Source: [LLM files reference](/docs/reference/llm.md))*
