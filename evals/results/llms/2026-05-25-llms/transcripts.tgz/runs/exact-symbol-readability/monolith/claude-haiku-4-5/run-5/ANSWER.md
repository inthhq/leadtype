# Agent-Readability Artifact Prevention Helper

## Helper: `isAgentReadabilityArtifactPath`

The `isAgentReadabilityArtifactPath` helper identifies artifact paths that should not be rewritten as missing markdown pages.

## What It Covers

It covers the following agent-readability artifacts:

- `llms.txt` - The product-level agent discovery file
- `llms-full.txt` - The root full-context file containing all generated markdown docs pages
- Sitemap files (`sitemap.xml`, `sitemap.md`)
- `robots.txt` - The robots exclusion file
- Search JSON files (`search-index.json`, `search-content.json`)
- `agent-readability.json` - The agent readability metadata

By protecting these static artifacts from being rewritten as missing markdown pages, the helper ensures that agent-accessible documentation remains stable and properly discoverable.
