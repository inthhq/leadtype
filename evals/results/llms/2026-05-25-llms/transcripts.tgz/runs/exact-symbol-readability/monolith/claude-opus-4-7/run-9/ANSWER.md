# Preventing agent-readability artifacts from being rewritten as missing markdown pages

## Helper

**`isAgentReadabilityArtifactPath`**

Documented in [`/docs/reference/llm.md`](docs/reference/llm.md), this helper identifies artifact paths that should **not** be rewritten as missing markdown pages.

## What it covers

The helper recognizes the following agent-readability artifact paths:

- `llms.txt`
- `llms-full.txt`
- sitemap files (e.g. `sitemap.xml`, `sitemap.md`)
- `robots.txt`
- search JSON (e.g. `search-index.json`, `search-content.json`)
- `agent-readability.json`

These are static, build-emitted artifacts (not MDX-derived pages), so request handlers and rewriters should use `isAgentReadabilityArtifactPath` to skip them rather than treating a request for, say, `/llms.txt` as a missing markdown page that needs to be generated or 404'd.

## Source

- `/llms.txt` → `/llms-full.txt` → section "LLM files" (`/docs/reference/llm.md`)
