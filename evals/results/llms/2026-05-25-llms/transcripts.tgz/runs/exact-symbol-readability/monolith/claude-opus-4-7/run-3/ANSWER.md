# Preventing agent-readability artifacts from being rewritten as missing markdown pages

## Helper

**`isAgentReadabilityArtifactPath`**

Documented in [`/docs/reference/llm.md`](docs/reference/llm.md), this helper identifies artifact paths that should not be rewritten as missing markdown pages.

## What it covers

It covers the following agent-readability / site-level artifact paths:

- `llms.txt`
- `llms-full.txt`
- sitemap files (e.g. `sitemap.xml`, `sitemap.md`)
- `robots.txt`
- search JSON (e.g. `search-index.json`, `search-content.json`)
- `agent-readability.json`

These are static artifacts emitted by website-mode builds (alongside markdown mirrors under `/docs/*.md`), so a docs server should serve them as-is rather than treating a request for them as a missing markdown page to rewrite.
