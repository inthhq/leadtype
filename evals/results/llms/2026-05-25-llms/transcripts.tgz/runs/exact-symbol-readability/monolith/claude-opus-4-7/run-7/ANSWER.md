# Preventing Agent-Readability Artifact Rewrites

The helper is **`isAgentReadabilityArtifactPath`**.

Per `docs/reference/llm.md`, it identifies artifact paths that should not be rewritten as missing markdown pages. It covers:

- `llms.txt`
- `llms-full.txt`
- sitemap files
- `robots.txt`
- search JSON
- `agent-readability.json`
