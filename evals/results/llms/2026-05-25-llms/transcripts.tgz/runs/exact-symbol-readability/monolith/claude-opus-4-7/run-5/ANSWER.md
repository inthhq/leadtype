# Preventing agent-readability artifact rewrites

## Helper

**`isAgentReadabilityArtifactPath`** — documented in `/docs/reference/llm.md`.

## What it does

It identifies artifact paths that should **not** be rewritten as missing markdown pages, so the docs pipeline doesn't treat them like absent `/docs/*.md` content.

## What it covers

The helper recognizes the following agent-readability artifacts:

- `llms.txt`
- `llms-full.txt`
- sitemap files (e.g. `sitemap.xml`, `sitemap.md`)
- `robots.txt`
- search JSON (`search-index.json`, `search-content.json`)
- `agent-readability.json`

These are the static, HTTP-discoverable files emitted by website mode, and they must be served as-is rather than redirected through the "missing markdown page" fallback.
