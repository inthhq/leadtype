# Agent-Readability Artifact Prevention Helper

## Helper: `isAgentReadabilityArtifactPath`

The `isAgentReadabilityArtifactPath` helper identifies artifact paths that should not be rewritten as missing markdown pages.

## Coverage

It covers the following agent-readability artifacts:
- `llms.txt`
- `llms-full.txt`
- Sitemap files
- `robots.txt`
- Search JSON files
- `agent-readability.json`

This helper prevents these special artifacts from being incorrectly processed as missing markdown pages during the docs generation pipeline, ensuring they remain as static artifacts served to agents.
