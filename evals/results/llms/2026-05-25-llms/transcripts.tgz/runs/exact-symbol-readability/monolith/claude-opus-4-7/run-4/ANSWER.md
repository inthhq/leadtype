# Preventing Agent-Readability Artifact Rewrites

## Helper

**`isAgentReadabilityArtifactPath`**

Per the Leadtype docs (`/docs/reference/llm.md`), this helper identifies artifact paths that should **not** be rewritten as missing markdown pages.

## What it covers

It covers the following agent-readability artifact paths:

- `llms.txt`
- `llms-full.txt`
- sitemap files
- `robots.txt`
- search JSON
- `agent-readability.json`

These are static artifacts produced by the Leadtype website-mode build, so the helper ensures requests for them aren't mistaken for missing `/docs/*.md` pages and incorrectly rewritten.

## Source

- `/llms-full.txt` → section "LLM files" (`/docs/reference/llm.md`)
