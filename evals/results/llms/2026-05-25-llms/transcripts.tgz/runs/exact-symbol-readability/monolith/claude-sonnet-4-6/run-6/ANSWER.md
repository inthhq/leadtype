# Preventing Agent-Readability Artifacts from Being Rewritten

## Helper: `isAgentReadabilityArtifactPath`

Sourced from the Leadtype docs at [`/docs/reference/llm.md`](/docs/reference/llm.md):

> `isAgentReadabilityArtifactPath` identifies artifact paths that should not be rewritten as missing markdown pages.

### What It Covers

It covers the following static artifact paths:

- `llms.txt`
- `llms-full.txt`
- Sitemap files (e.g., `sitemap.xml`, `sitemap.md`)
- `robots.txt`
- Search JSON files (e.g., `search-index.json`, `search-content.json`)
- `agent-readability.json`

By recognising these paths as known agent-readability artifacts, the helper ensures they are served as-is rather than being incorrectly treated as missing pages and rewritten (e.g., returning a 404 markdown error page in their place).
