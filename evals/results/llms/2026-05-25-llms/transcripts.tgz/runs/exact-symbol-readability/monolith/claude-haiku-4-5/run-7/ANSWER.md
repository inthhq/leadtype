# Agent-Readability Artifact Prevention

## Helper Function: `isAgentReadabilityArtifactPath`

The `isAgentReadabilityArtifactPath` helper identifies artifact paths that should not be rewritten as missing markdown pages.

## What It Covers

This helper covers the following agent-readability artifacts:
- `llms.txt` - Product-level LLM navigation file
- `llms-full.txt` - Full-context file containing all markdown docs pages
- Sitemap files (sitemap.xml, sitemap.md)
- `robots.txt` - Search engine directives
- Search JSON files (search index and content)
- `agent-readability.json` - Agent readability metadata

By identifying these paths, the helper prevents the build system from incorrectly treating them as missing markdown pages that need to be generated, ensuring these critical agent-readable artifacts remain as static files.
