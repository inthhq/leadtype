# Preventing Agent-Readability Artifacts from Being Rewritten as Missing Markdown Pages

## The Helper

The helper responsible for this is **`isAgentReadabilityArtifactPath`**, found in the LLM files reference (`/docs/reference/llm.md`).

## What It Covers

`isAgentReadabilityArtifactPath` identifies artifact paths that are known agent-readability or site-infrastructure files so that the server/router does **not** attempt to rewrite or serve them as missing markdown pages (e.g., a 404 markdown stub).

It covers the following static artifact paths:

- `llms.txt`
- `llms-full.txt`
- Sitemap files (`sitemap.xml`, `sitemap.md`)
- `robots.txt`
- Search JSON files (`search-index.json`, `search-content.json`)
- `agent-readability.json`

By recognising these paths as intentional, pre-generated artifacts, `isAgentReadabilityArtifactPath` ensures they are served as-is rather than being intercepted by any "missing page" fallback logic.
