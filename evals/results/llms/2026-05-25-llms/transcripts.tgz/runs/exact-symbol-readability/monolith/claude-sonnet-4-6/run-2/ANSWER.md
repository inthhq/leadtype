# Answer

## Helper: `isAgentReadabilityArtifactPath`

The helper that prevents agent-readability artifacts from being rewritten as missing markdown pages is **`isAgentReadabilityArtifactPath`**, documented in the [LLM files reference](/docs/reference/llm.md).

### What it covers

`isAgentReadabilityArtifactPath` identifies the following artifact paths, marking them as known static files that must **not** be treated as missing or 404 markdown pages:

- `llms.txt` (and `/docs/llms.txt`)
- `llms-full.txt`
- Sitemap files (`sitemap.xml`, `sitemap.md`)
- `robots.txt`
- Search JSON files (`search-index.json`, `search-content.json`)
- `agent-readability.json`

By checking a path against this helper, the docs server (or middleware) can bypass any "missing page" rewrite logic for these special artifacts and serve them as-is.
