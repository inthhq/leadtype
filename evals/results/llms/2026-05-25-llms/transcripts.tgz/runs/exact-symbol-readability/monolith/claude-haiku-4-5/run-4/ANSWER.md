# Agent-Readability Artifact Prevention Helper

## Helper Name
`isAgentReadabilityArtifactPath`

## Description
`isAgentReadabilityArtifactPath` is a helper function that identifies artifact paths that should not be rewritten as missing markdown pages. 

It covers the following agent-readability artifacts:
- `llms.txt`
- `llms-full.txt`
- Sitemap files
- `robots.txt`
- Search JSON files
- `agent-readability.json`

This helper ensures that these important machine-readable artifacts are preserved as static files rather than being treated as missing pages that need markdown equivalents.
