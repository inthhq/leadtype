# Preventing Agent-Readability Artifacts from Being Rewritten

## Helper: `isAgentReadabilityArtifactPath`

The helper that prevents agent-readability artifacts from being rewritten as missing markdown pages is **`isAgentReadabilityArtifactPath`**, documented in the [LLM files reference](/docs/reference/llm.md).

## What It Covers

`isAgentReadabilityArtifactPath` identifies the following artifact paths so that they are **not** mistakenly treated as missing or broken markdown pages:

- `llms.txt`
- `llms-full.txt`
- Sitemap files (e.g., `sitemap.xml`, `sitemap.md`)
- `robots.txt`
- Search JSON files (e.g., `search-index.json`, `search-content.json`)
- `agent-readability.json`

These are all static, pre-generated artifacts that must be served as-is. By flagging them with `isAgentReadabilityArtifactPath`, the build/serve layer knows to leave them alone rather than attempting to render them as markdown documentation pages.
