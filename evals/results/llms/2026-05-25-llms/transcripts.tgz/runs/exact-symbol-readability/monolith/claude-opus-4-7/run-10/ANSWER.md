# Preventing Agent-Readability Artifacts from Being Rewritten

## Helper

**`isAgentReadabilityArtifactPath`**

## What it does

Per the Leadtype docs (`docs/reference/llm.md`), `isAgentReadabilityArtifactPath` identifies artifact paths that should **not** be rewritten as missing markdown pages.

## What it covers

The helper covers these agent-readability artifact paths:

- `llms.txt`
- `llms-full.txt`
- sitemap files
- `robots.txt`
- search JSON
- `agent-readability.json`

Source: `/docs/reference/llm.md`
