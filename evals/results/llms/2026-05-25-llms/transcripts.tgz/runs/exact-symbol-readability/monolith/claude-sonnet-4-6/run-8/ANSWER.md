# Preventing Agent-Readability Artifacts from Being Rewritten

## Helper

**`isAgentReadabilityArtifactPath`**

Found in the [LLM files reference](/docs/reference/llm.md).

## What it does

`isAgentReadabilityArtifactPath` identifies artifact paths that should **not** be rewritten as missing markdown pages. It covers the following static artifacts:

- `llms.txt` (and `/docs/llms.txt`)
- `llms-full.txt`
- Sitemap files (`sitemap.xml`, `sitemap.md`)
- `robots.txt`
- Search JSON files (`search-index.json`, `search-content.json`)
- `agent-readability.json`

By recognising these paths as known agent-readability artifacts, the helper prevents the docs pipeline (or a serving layer) from mistakenly treating them as non-existent pages and serving a "missing page" response in their place.
