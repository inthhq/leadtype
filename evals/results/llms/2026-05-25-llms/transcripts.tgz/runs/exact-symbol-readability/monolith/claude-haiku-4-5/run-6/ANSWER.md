# Agent-Readability Artifact Prevention Helper

## Helper Name
**`isAgentReadabilityArtifactPath`**

## Description
`isAgentReadabilityArtifactPath` is a helper that identifies artifact paths that should not be rewritten as missing markdown pages. It covers the following artifacts:

- `llms.txt` - The product-level routing map for HTTP agents
- `llms-full.txt` - The full-context file containing every generated markdown docs page
- Sitemap files (`sitemap.xml`, `sitemap.md`)
- `robots.txt` - Robot exclusion rules
- Search JSON files (`search-index.json`, `search-content.json`)
- `agent-readability.json` - Metadata about agent-readable resources

By protecting these files, the helper ensures that critical agent-discovery and metadata artifacts are preserved and not inadvertently rewritten as missing markdown pages during the docs generation pipeline.
