# Answer: Helper That Prevents Agent-Readability Artifacts

## Helper Name
**`isAgentReadabilityArtifactPath`**

## Description
`isAgentReadabilityArtifactPath` is a helper function that identifies artifact paths that should not be rewritten as missing markdown pages. It prevents the following agent-readability artifacts from being converted into markdown pages:

- `llms.txt` - The product-level LLM context file
- `llms-full.txt` - The full context file containing every generated markdown docs page
- Sitemap files (XML and markdown versions)
- `robots.txt` - The robots exclusion file
- Search JSON files (search index and search content)
- `agent-readability.json` - The agent readability metadata file

This helper ensures that these static agent-readable artifacts are preserved as-is and not processed as missing documentation pages during the build pipeline.
