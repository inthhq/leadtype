# Preventing Agent-Readability Artifact Rewrites

## Helper

**`isAgentReadabilityArtifactPath`**

## What it does

Per the Leadtype docs (`/docs/reference/llm.md`), `isAgentReadabilityArtifactPath` identifies artifact paths that should **not** be rewritten as missing markdown pages.

## What it covers

The helper covers the following agent-readability artifacts:

- `llms.txt`
- `llms-full.txt`
- Sitemap files (e.g., `sitemap.xml`, `sitemap.md`)
- `robots.txt`
- Search JSON files (e.g., `search-index.json`, `search-content.json`)
- `agent-readability.json`

By recognizing these paths as legitimate static artifacts, the helper prevents the docs pipeline from treating them as missing markdown docs pages and erroneously rewriting them.

## Source

- `/docs/reference/llm.md` ("LLM files")
