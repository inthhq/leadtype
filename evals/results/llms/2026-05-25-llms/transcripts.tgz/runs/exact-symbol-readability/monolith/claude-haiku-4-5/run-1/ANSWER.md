# Agent-Readability Artifact Prevention Helper

## Helper Name
`isAgentReadabilityArtifactPath`

## Description
`isAgentReadabilityArtifactPath` is a helper that identifies artifact paths that should not be rewritten as missing markdown pages. It covers the following artifacts:

- `llms.txt`
- `llms-full.txt`
- Sitemap files
- `robots.txt`
- Search JSON (search-index.json and search-content.json)
- `agent-readability.json`

This helper ensures that these special agent-readability artifacts are preserved as static files and not mistakenly treated as missing markdown pages that need to be generated or rewritten.
