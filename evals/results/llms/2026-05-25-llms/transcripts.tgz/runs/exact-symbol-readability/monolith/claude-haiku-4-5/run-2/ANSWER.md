# Agent-Readability Artifact Prevention

The helper that prevents agent-readability artifacts from being rewritten as missing markdown pages is **`isAgentReadabilityArtifactPath`**.

## What It Covers

The `isAgentReadabilityArtifactPath` helper identifies and protects the following artifact paths from being rewritten as missing markdown pages:

- `llms.txt` - The product-level LLM map file
- `llms-full.txt` - The full-context file containing every generated markdown docs page
- Sitemap files (sitemap.xml, sitemap.md)
- `robots.txt` - The robots exclusion file
- Search JSON files (search-index.json, search-content.json)
- `agent-readability.json` - The agent readability configuration file

By identifying these paths, the helper ensures they remain as static artifacts and are not incorrectly rewritten as missing markdown pages during the build process.
