# Preventing agent-readability artifacts from being rewritten as missing markdown pages

## Helper

**`isAgentReadabilityArtifactPath`**

Documented in [`/docs/reference/llm.md`](docs/reference/llm.md), this helper identifies artifact paths that should **not** be rewritten as missing markdown pages.

## What it covers

According to the LLM files reference, `isAgentReadabilityArtifactPath` covers the following artifact paths:

- `llms.txt`
- `llms-full.txt`
- sitemap files (e.g. `sitemap.xml`, `sitemap.md`)
- `robots.txt`
- search JSON (e.g. `search-index.json`, `search-content.json`)
- `agent-readability.json`

These are static, agent-discoverable artifacts emitted by website-mode builds, so a request for one of them must be served as-is rather than treated as a missing `*.md` page and rewritten by the markdown-mirror fallback.
