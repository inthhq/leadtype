# Preventing Agent-Readability Artifacts from Being Rewritten as Missing Markdown Pages

## Helper

**`isAgentReadabilityArtifactPath`** (documented in `/docs/reference/llm.md`)

## What it does

This helper identifies artifact paths that should **not** be rewritten as missing markdown pages. In other words, it lets the docs pipeline (and the hosting layer) recognize that certain files are agent-readability artifacts rather than ordinary docs pages, so they aren't mistakenly treated as missing `*.md` pages and rewritten/redirected.

## What it covers

According to the LLM files reference, `isAgentReadabilityArtifactPath` covers:

- `llms.txt`
- `llms-full.txt`
- Sitemap files (e.g. `docs/sitemap.xml`, `docs/sitemap.md`)
- `robots.txt`
- Search JSON (`docs/search-index.json`, `docs/search-content.json`)
- `agent-readability.json`

These are the static, HTTP-discoverable artifacts that website mode emits alongside the markdown mirrors — keeping them out of the "missing markdown page" rewrite path ensures HTTP agents can fetch them directly at their canonical URLs.

## Source

- `/docs/reference/llm.md` — "LLM files" section
