# Agent-Readability Artifact Prevention Helper

## Helper Name
`isAgentReadabilityArtifactPath`

## Description
The `isAgentReadabilityArtifactPath` helper identifies artifact paths that should not be rewritten as missing markdown pages.

## What It Covers
- `llms.txt`
- `llms-full.txt`
- Sitemap files
- `robots.txt`
- Search JSON files
- `agent-readability.json`

This helper prevents these agent-readability artifacts from being incorrectly treated as missing markdown pages during the docs pipeline build process.
