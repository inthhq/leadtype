# Helper That Prevents Agent-Readability Artifacts from Being Rewritten

## Helper: `isAgentReadabilityArtifactPath`

Documented in the **LLM files** reference page (`/docs/reference/llm.md`), the helper `isAgentReadabilityArtifactPath` identifies artifact paths that should **not** be rewritten as missing markdown pages.

### What It Covers

It covers the following static artifact paths:

- `llms.txt`
- `llms-full.txt`
- Sitemap files (e.g., `sitemap.xml`, `sitemap.md`)
- `robots.txt`
- Search JSON files (e.g., `search-index.json`, `search-content.json`)
- `agent-readability.json`

By recognising these paths as known agent-readability artifacts, the helper ensures they are served as-is rather than being misidentified as missing documentation pages and rewritten or replaced with 404/missing-page markdown responses.
