# Preventing Agent-Readability Artifacts from Being Rewritten

## Helper

**`isAgentReadabilityArtifactPath`**

Documented in the [LLM files reference](/docs/reference/llm.md).

## What It Does

`isAgentReadabilityArtifactPath` identifies artifact paths that should **not** be rewritten as missing markdown pages. It covers the following static artifacts:

- `llms.txt` (and `/docs/llms.txt`)
- `llms-full.txt`
- Sitemap files (`sitemap.xml`, `sitemap.md`)
- `robots.txt`
- Search JSON files (`search-index.json`, `search-content.json`)
- `agent-readability.json`

By recognising these paths as known agent-readability artifacts, the helper prevents the docs pipeline from mistakenly treating them as absent or unresolved markdown documentation pages and attempting to generate/overwrite them as such.
