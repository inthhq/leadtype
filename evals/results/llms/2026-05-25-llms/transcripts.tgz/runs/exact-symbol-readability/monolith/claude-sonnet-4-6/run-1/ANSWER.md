# Preventing Agent-Readability Artifacts from Being Rewritten

## The Helper

**`isAgentReadabilityArtifactPath`**

Found in the [LLM files reference](/docs/reference/llm.md), this helper identifies artifact paths that should **not** be rewritten as missing markdown pages.

## What It Covers

`isAgentReadabilityArtifactPath` guards the following static artifacts:

- `llms.txt` (and `/docs/llms.txt`)
- `llms-full.txt`
- Sitemap files (e.g., `sitemap.xml`, `sitemap.md`)
- `robots.txt`
- Search JSON files (e.g., `search-index.json`, `search-content.json`)
- `agent-readability.json`

By recognising these paths as known agent-readability artifacts, the helper ensures the docs pipeline does not mistakenly treat them as absent markdown documentation pages and attempt to regenerate or overwrite them.
