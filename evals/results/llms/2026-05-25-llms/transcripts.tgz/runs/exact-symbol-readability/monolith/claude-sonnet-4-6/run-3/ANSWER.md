# Preventing Agent-Readability Artifacts from Being Rewritten as Missing Markdown Pages

## Helper: `isAgentReadabilityArtifactPath`

The helper responsible for preventing agent-readability artifacts from being rewritten as missing markdown pages is **`isAgentReadabilityArtifactPath`**, documented in the [LLM files reference](/docs/reference/llm.md).

## What It Covers

`isAgentReadabilityArtifactPath` identifies the following artifact paths that should **not** be treated as missing markdown pages:

- `llms.txt`
- `llms-full.txt`
- Sitemap files (e.g., `sitemap.xml`, `sitemap.md`)
- `robots.txt`
- Search JSON files (e.g., `search-index.json`, `search-content.json`)
- `agent-readability.json`

By recognising these paths as known static artifacts, the helper ensures that requests to them are served as-is rather than being incorrectly handled as 404/missing page scenarios that would be rewritten with a markdown page.
