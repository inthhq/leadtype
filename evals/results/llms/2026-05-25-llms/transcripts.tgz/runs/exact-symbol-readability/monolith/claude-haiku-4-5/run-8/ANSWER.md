# Agent-Readability Artifact Prevention Helper

## Helper Name
`isAgentReadabilityArtifactPath`

## Description
The `isAgentReadabilityArtifactPath` helper identifies artifact paths that should not be rewritten as missing markdown pages. It covers:

- `/llms.txt`
- `/llms-full.txt`
- Sitemap files (XML and markdown)
- `robots.txt`
- Search JSON
- `agent-readability.json`

This helper ensures that agent-readability artifacts remain as static files and are not incorrectly processed as missing markdown pages during the docs generation pipeline.
