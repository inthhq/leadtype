# Preventing agent-readability artifact rewrites

The helper is **`isAgentReadabilityArtifactPath`**, documented in `/docs/reference/llm.md`.

## What it does

`isAgentReadabilityArtifactPath` identifies artifact paths that should **not** be rewritten as missing markdown pages. This prevents the docs pipeline from treating agent/SEO artifacts as broken `.md` routes.

## What it covers

The helper recognizes these agent-readability and site artifacts:

- `llms.txt`
- `llms-full.txt`
- sitemap files (e.g., `sitemap.xml`, `sitemap.md`)
- `robots.txt`
- search JSON (e.g., `search-index.json`, `search-content.json`)
- `agent-readability.json`

These are static artifacts emitted by website-mode `leadtype generate`, so requests for them should be served as-is rather than routed through the missing-markdown-page rewrite path.
