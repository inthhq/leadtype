# Agent-Readability Artifact Protection

The helper that prevents agent-readability artifacts from being rewritten as missing markdown pages is **`isAgentReadabilityArtifactPath`**.

## Coverage

This helper identifies and protects the following artifact paths from being rewritten as missing markdown pages:

- `llms.txt`
- `llms-full.txt`
- Sitemap files (sitemap.xml, sitemap.md)
- `robots.txt`
- Search JSON files
- `agent-readability.json`

These artifacts are kept as static files and not converted to markdown pages, ensuring that agent-readable bundles and deployment artifacts remain intact and properly served.
