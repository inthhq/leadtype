# Preventing Agent-Readability Artifacts from Being Rewritten

## Helper

**`isAgentReadabilityArtifactPath`**

Source: [`/docs/reference/llm.md`](/docs/reference/llm.md) (via the Reference full-context bundle, `/docs/llms-full/reference.txt`).

## What it does

`isAgentReadabilityArtifactPath` identifies artifact paths that should **not** be rewritten as missing markdown pages. This protects the static agent-readable deployment artifacts from being treated as docs pages by the markdown-mirror routing logic.

## What it covers

The helper recognizes the following artifact paths:

- `llms.txt`
- `llms-full.txt`
- sitemap files
- `robots.txt`
- search JSON
- `agent-readability.json`

These are exactly the kinds of files that the build is expected to serve as static artifacts (per the "Connect a docs site" guidance), rather than as markdown documents fetched via `Accept: text/markdown` or `/docs/*.md` routes.
