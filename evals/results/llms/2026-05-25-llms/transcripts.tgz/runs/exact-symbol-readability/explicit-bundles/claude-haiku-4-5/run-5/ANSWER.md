# Helper That Prevents Agent-Readability Artifacts

The helper is **`isAgentReadabilityArtifactPath`**.

## What It Does

`isAgentReadabilityArtifactPath` identifies artifact paths that should not be rewritten as missing markdown pages. It covers the following agent-readability artifacts:

- llms.txt
- llms-full.txt
- sitemap files
- robots.txt
- search JSON (search-index.json and search-content.json)
- agent-readability.json

By identifying these paths, this helper ensures that these static deployment artifacts are preserved and not treated as missing markdown pages that need to be rewritten during the docs site build process.
