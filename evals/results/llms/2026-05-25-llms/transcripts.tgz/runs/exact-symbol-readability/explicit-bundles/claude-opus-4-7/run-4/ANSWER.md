# Preventing agent-readability artifacts from being rewritten as missing markdown

## Helper

**`isAgentReadabilityArtifactPath`**

Documented in [`docs/reference/llm.md`](docs/reference/llm.md) (and surfaced in the [Reference full-context bundle](docs/llms-full/reference.txt)).

## What it does

`isAgentReadabilityArtifactPath` identifies artifact paths that should **not** be rewritten as missing markdown pages. Without it, a docs site's "serve markdown to agents" middleware could mistake these special static files for missing `/docs/*.md` pages and try to redirect or 404 them.

## What it covers

The helper recognizes the full set of agent-readability / website-mode static artifacts:

- `llms.txt`
- `llms-full.txt`
- sitemap files
- `robots.txt`
- search JSON (e.g., `search-index.json`, `search-content.json`)
- `agent-readability.json`

These are the same artifacts that `docs/build/connect-docs-site.md` says to "keep as static artifacts" when wiring a hosted docs site in website mode.
