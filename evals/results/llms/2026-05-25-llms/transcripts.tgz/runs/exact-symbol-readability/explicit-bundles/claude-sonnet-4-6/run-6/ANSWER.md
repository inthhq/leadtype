# Preventing Agent-Readability Artifacts from Being Rewritten

## The Helper

The helper that prevents agent-readability artifacts from being rewritten as missing markdown pages is:

**`isAgentReadabilityArtifactPath`**

(Documented in the [LLM files reference](/docs/reference/llm.md).)

## What It Covers

`isAgentReadabilityArtifactPath` identifies artifact paths that should be treated as static files — not as missing or unresolved markdown pages. It covers the following artifacts:

- `llms.txt`
- `llms-full.txt`
- Sitemap files (e.g., `sitemap.xml`, `sitemap.md`)
- `robots.txt`
- Search JSON
- `agent-readability.json`

By recognising these paths, the helper ensures that requests for these well-known agent-readability and site-infrastructure files are served as-is, rather than being mistakenly handled as 404/missing-page scenarios that would generate erroneous markdown error pages.
