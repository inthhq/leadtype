The helper is `isAgentReadabilityArtifactPath`.

It identifies generated agent-readability/static artifact paths that should be served as artifacts instead of being rewritten as missing markdown pages. It covers `llms.txt`, `llms-full.txt`, sitemap files, `robots.txt`, search JSON files, and `agent-readability.json`.
