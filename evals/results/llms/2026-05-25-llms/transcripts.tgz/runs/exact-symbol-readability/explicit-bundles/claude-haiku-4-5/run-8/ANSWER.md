# Agent-Readability Artifact Prevention

## Helper Name
`isAgentReadabilityArtifactPath`

## Description
`isAgentReadabilityArtifactPath` identifies artifact paths that should not be rewritten as missing markdown pages. It covers:

- `llms.txt`
- `llms-full.txt`
- Sitemap files (sitemap.xml, sitemap.md)
- `robots.txt`
- Search JSON files
- `agent-readability.json`

This helper prevents these special agent-readable artifacts from being incorrectly handled as missing markdown pages during the Leadtype docs build process.
