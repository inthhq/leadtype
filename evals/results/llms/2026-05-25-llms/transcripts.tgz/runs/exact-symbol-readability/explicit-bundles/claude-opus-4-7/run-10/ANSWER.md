# Preventing Agent-Readability Artifacts from Being Rewritten

## Helper

**`isAgentReadabilityArtifactPath`**

Source: [`/docs/reference/llm.md`](/docs/reference/llm.md) (via the Reference full-context bundle).

## What it does

`isAgentReadabilityArtifactPath` identifies artifact paths that should **not** be rewritten as missing markdown pages. This keeps Leadtype's static, agent-facing files from being treated as ordinary docs URLs (which would otherwise be redirected/regenerated as missing `.md` pages) when a docs site is serving markdown to agents.

## What it covers

Per the docs, the helper covers the following artifact paths:

- `llms.txt`
- `llms-full.txt`
- sitemap files
- `robots.txt`
- search JSON
- `agent-readability.json`

These match the static artifacts that `/docs/build/connect-docs-site.md` says should be served as-is alongside the markdown mirrors under `/docs/*.md`.
