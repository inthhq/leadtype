# Helper That Prevents Agent-Readability Artifacts from Being Rewritten

## Helper: `isAgentReadabilityArtifactPath`

**Source:** [`/docs/reference/llm.md`](/docs/reference/llm.md)

`isAgentReadabilityArtifactPath` is the helper that identifies artifact paths that should **not** be rewritten as missing markdown pages.

### What It Covers

It covers the following static artifacts:

- `llms.txt`
- `llms-full.txt`
- Sitemap files (e.g., `sitemap.xml`, `sitemap.md`)
- `robots.txt`
- Search JSON
- `agent-readability.json`

By recognising these paths as known agent-readability artifacts rather than absent content pages, the helper ensures that the docs site serves them as-is instead of treating them as 404/missing-page candidates and attempting to rewrite or replace them with markdown page responses.
