`isAgentReadabilityArtifactPath` is the helper that prevents agent-readability artifacts from being rewritten as missing markdown pages.

It covers `llms.txt`, `llms-full.txt`, sitemap files, `robots.txt`, search JSON, and `agent-readability.json`.
