# Agent-Readability Artifact Helper

## Helper: `isAgentReadabilityArtifactPath`

The `isAgentReadabilityArtifactPath` helper identifies artifact paths that should not be rewritten as missing markdown pages.

## Coverage

It covers the following agent-readability artifacts:
- `llms.txt`
- `llms-full.txt`
- Sitemap files (sitemap.xml, sitemap.md)
- `robots.txt`
- Search JSON files (search-index.json, search-content.json)
- `agent-readability.json`

This helper prevents these critical agent-discovery and metadata files from being mistakenly treated as missing documentation pages that need to be auto-generated or rewritten.
