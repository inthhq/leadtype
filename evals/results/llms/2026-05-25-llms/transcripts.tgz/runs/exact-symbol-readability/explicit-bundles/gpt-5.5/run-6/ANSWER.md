The helper is `isAgentReadabilityArtifactPath`.

It identifies generated agent-readability artifact paths that should remain static and not be rewritten as missing markdown pages. Its coverage includes `llms.txt`, `llms-full.txt`, sitemap files, `robots.txt`, search JSON files, and `agent-readability.json`.
