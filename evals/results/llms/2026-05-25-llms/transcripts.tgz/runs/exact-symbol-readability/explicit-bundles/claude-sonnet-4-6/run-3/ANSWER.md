# Preventing Agent-Readability Artifacts from Being Rewritten

## Helper

**`isAgentReadabilityArtifactPath`**

This helper, documented in the [LLM files reference](/docs/reference/llm.md), identifies artifact paths that should **not** be rewritten as missing markdown pages.

## What It Covers

It covers the following static artifacts:

- `llms.txt`
- `llms-full.txt`
- Sitemap files
- `robots.txt`
- Search JSON
- `agent-readability.json`

By recognising these paths as known agent-readability artifacts, the helper ensures the build pipeline leaves them intact rather than treating them as missing documentation pages that need to be generated or replaced.
