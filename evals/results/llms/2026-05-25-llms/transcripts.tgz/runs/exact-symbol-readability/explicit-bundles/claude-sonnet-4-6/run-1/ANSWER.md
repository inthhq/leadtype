# Preventing Agent-Readability Artifacts from Being Rewritten

## Helper

**`isAgentReadabilityArtifactPath`**

## Description

`isAgentReadabilityArtifactPath` is a helper that identifies artifact paths that should **not** be rewritten as missing markdown pages. It covers the following static agent-readability artifacts:

- `llms.txt`
- `llms-full.txt`
- Sitemap files (e.g., `sitemap.xml`, `sitemap.md`)
- `robots.txt`
- Search JSON
- `agent-readability.json`

By recognising these paths, the helper ensures that requests to these well-known agent/discovery files are served as-is rather than being incorrectly treated as absent documentation pages and rewritten or replaced.

> Source: [LLM files reference](/docs/reference/llm.md)
