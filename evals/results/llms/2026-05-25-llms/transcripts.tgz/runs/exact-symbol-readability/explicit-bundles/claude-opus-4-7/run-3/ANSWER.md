# Preventing Agent-Readability Artifacts from Being Rewritten

## Helper

**`isAgentReadabilityArtifactPath`**

Source: [`/docs/reference/llm.md`](/docs/reference/llm.md) (via `/docs/llms-full/reference.txt`).

## What it does

`isAgentReadabilityArtifactPath` identifies artifact paths that should **not** be rewritten as missing markdown pages. This prevents the docs pipeline from treating these special, statically-served files as broken/missing `.md` routes.

## What it covers

The helper recognizes the following agent-readability artifacts:

- `llms.txt`
- `llms-full.txt`
- sitemap files
- `robots.txt`
- search JSON
- `agent-readability.json`

These are the same static artifacts that the build step (see `/docs/build/connect-docs-site.md`) recommends serving as-is alongside the markdown mirrors under `/docs/*.md`.
