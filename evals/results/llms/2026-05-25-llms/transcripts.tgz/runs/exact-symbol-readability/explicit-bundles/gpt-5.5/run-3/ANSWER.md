The helper is `isAgentReadabilityArtifactPath`.

It identifies generated/static agent-readability artifact paths that should be served as artifacts instead of being rewritten as missing markdown pages. It covers `llms.txt`, `llms-full.txt`, sitemap files, `robots.txt`, search JSON, and `agent-readability.json`.
