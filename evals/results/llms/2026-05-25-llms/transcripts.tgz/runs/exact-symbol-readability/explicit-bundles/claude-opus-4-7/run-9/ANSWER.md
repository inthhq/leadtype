# Preventing agent-readability artifact rewrites

## Helper

**`isAgentReadabilityArtifactPath`**

Documented in [`/docs/reference/llm.md`](docs/reference/llm.md), this helper identifies artifact paths that should **not** be rewritten as missing markdown pages.

## What it covers

It recognizes the following agent-readability / website-mode artifact paths:

- `llms.txt`
- `llms-full.txt`
- sitemap files
- `robots.txt`
- search JSON
- `agent-readability.json`

By flagging these paths, the helper ensures the docs build/server treats them as the static artifacts they are, rather than attempting to serve or generate a corresponding missing markdown page for them.

## Source

> "isAgentReadabilityArtifactPath identifies artifact paths that should not be rewritten as missing markdown pages. It covers llms.txt, llms-full.txt, sitemap files, robots.txt, search JSON, and agent-readability.json."
> — `docs/reference/llm.md`
