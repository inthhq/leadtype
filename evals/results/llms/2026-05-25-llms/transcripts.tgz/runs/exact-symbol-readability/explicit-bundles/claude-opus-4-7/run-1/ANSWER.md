# Preventing Agent-Readability Artifacts from Being Rewritten

## Helper

**`isAgentReadabilityArtifactPath`**

## What it does

Per the Leadtype docs (`docs/reference/llm.md`), `isAgentReadabilityArtifactPath` identifies artifact paths that should **not** be rewritten as missing markdown pages. Without it, a docs site's "rewrite to `.md`" logic could turn requests for files like `/llms.txt` into requests for nonexistent markdown pages, producing 404s for files that actually exist as static artifacts.

## What it covers

The helper covers the following agent-readability artifact paths:

- `llms.txt`
- `llms-full.txt`
- sitemap files
- `robots.txt`
- search JSON (e.g., `search-index.json`, `search-content.json`)
- `agent-readability.json`

These files are emitted by website mode as static artifacts and should be served as-is rather than routed through the markdown-mirror rewrite logic.

## Source

- `/docs/reference/llm.md`
- `/docs/llms-full/reference.txt`
