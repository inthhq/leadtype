# Preventing Agent-Readability Artifacts From Being Rewritten

## Helper

**`isAgentReadabilityArtifactPath`**

## Source

Documented in [`docs/reference/llm.md`](docs/reference/llm.md) (line 12), and mirrored in the Reference full-context bundle [`docs/llms-full/reference.txt`](docs/llms-full/reference.txt) (line 34).

## What it does

`isAgentReadabilityArtifactPath` identifies artifact paths that should **not** be rewritten as missing markdown pages. This protects agent-readability deployment artifacts from being treated like missing `/docs/*.md` content when a docs site rewrites requests based on the `Accept: text/markdown` header or a known AI user agent.

## What it covers

The helper recognizes the following static artifact paths:

- `llms.txt` — product-level routing index served at the site root
- `llms-full.txt` — root full-context fallback bundle containing every generated markdown page
- Sitemap files (e.g. `sitemap.xml`, `sitemap.md`)
- `robots.txt`
- Search JSON files (e.g. `search-index.json`, `search-content.json`)
- `agent-readability.json`

These are the same artifacts that the "Connect a docs site" build guide ([`docs/build/connect-docs-site.md`](docs/build/connect-docs-site.md)) instructs hosts to serve as static files rather than route through the markdown rewrite path.
