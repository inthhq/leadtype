# Preventing Agent-Readability Artifacts from Being Rewritten

## The Helper

**`isAgentReadabilityArtifactPath`**

This helper identifies artifact paths that should **not** be rewritten as missing markdown pages.

## What It Covers

It covers the following static artifacts:

- `llms.txt`
- `llms-full.txt`
- Sitemap files
- `robots.txt`
- Search JSON
- `agent-readability.json`

By recognising these paths as known agent-readability artifacts, the helper ensures they are served as-is rather than being treated as missing documentation pages and incorrectly rewritten or replaced.

> Source: [LLM files reference](/docs/reference/llm.md)
