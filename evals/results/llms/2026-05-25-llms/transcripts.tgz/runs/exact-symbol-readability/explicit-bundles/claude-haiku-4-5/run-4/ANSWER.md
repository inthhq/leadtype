# Agent-Readability Artifacts Prevention

## Helper Function
**`isAgentReadabilityArtifactPath`**

## Description
This helper function identifies artifact paths that should not be rewritten as missing markdown pages. It prevents the following agent-readability artifacts from being treated as broken routes:

- `llms.txt`
- `llms-full.txt`
- Sitemap files (`sitemap.xml`, `sitemap.md`)
- `robots.txt`
- Search JSON files (`search-index.json`, `search-content.json`)
- `agent-readability.json`

By protecting these artifacts, the helper ensures that critical agent-accessible resources remain intact and are served as static files rather than being converted to placeholder markdown pages when routes are not explicitly defined.
