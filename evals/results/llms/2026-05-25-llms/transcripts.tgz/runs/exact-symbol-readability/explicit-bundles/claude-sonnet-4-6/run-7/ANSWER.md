# Preventing Agent-Readability Artifacts from Being Rewritten

## The Helper

**`isAgentReadabilityArtifactPath`**

This helper, documented in the [LLM files reference](/docs/reference/llm.md), identifies artifact paths that should **not** be rewritten as missing markdown pages.

## What It Covers

It covers the following static artifact paths:

- `llms.txt`
- `llms-full.txt`
- Sitemap files (e.g., `sitemap.xml`, `sitemap.md`)
- `robots.txt`
- Search JSON
- `agent-readability.json`

By recognising these paths as known agent-readability artifacts, the helper ensures that a docs framework won't mistake them for absent documentation pages and attempt to serve or generate a "404 / missing page" response in their place.
