# Helper That Prevents Agent-Readability Artifact Rewrites

## Helper: `isAgentReadabilityArtifactPath`

Defined in the [LLM files reference](/docs/reference/llm.md), `isAgentReadabilityArtifactPath` is the helper that identifies artifact paths which **should not be rewritten as missing markdown pages**.

### What It Covers

It covers the following static artifacts:

- `llms.txt`
- `llms-full.txt`
- Sitemap files (e.g. `sitemap.xml`, `sitemap.md`)
- `robots.txt`
- Search JSON
- `agent-readability.json`

By recognising these paths as known agent-readability artifacts, the helper ensures they are served as-is rather than being mishandled as absent or broken markdown documentation pages.
