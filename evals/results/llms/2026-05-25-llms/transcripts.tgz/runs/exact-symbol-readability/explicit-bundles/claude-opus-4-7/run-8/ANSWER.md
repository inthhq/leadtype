# Helper That Prevents Agent-Readability Artifacts From Being Rewritten

## Helper

**`isAgentReadabilityArtifactPath`**

Source: [`/docs/reference/llm.md`](/docs/reference/llm.md) (via the Reference full-context bundle).

## What it does

`isAgentReadabilityArtifactPath` identifies artifact paths that should **not** be rewritten as missing markdown pages. This prevents the markdown-fallback / rewriting logic from treating these well-known agent-readability files as docs pages that need to be generated or 404-handled as missing `.md` content.

## What it covers

The helper recognizes the following artifact paths:

- `llms.txt`
- `llms-full.txt`
- sitemap files (e.g. `sitemap.xml`, `sitemap.md`)
- `robots.txt`
- search JSON (the static search index/content)
- `agent-readability.json`

These match the static artifacts that the Build guide says should be served as-is at the site root (see `/docs/build/connect-docs-site.md`), keeping them discoverable to agents without being mistaken for missing markdown docs pages.
