# Preventing Agent-Readability Artifacts from Being Rewritten

## Helper

**`isAgentReadabilityArtifactPath`**

Documented in [`/docs/reference/llm.md`](/docs/reference/llm.md) (surfaced via [`/docs/llms-full/reference.txt`](/docs/llms-full/reference.txt)).

## What it does

`isAgentReadabilityArtifactPath` identifies artifact paths that should **not** be rewritten as missing markdown pages. This matters because a Leadtype-connected docs site serves markdown for agent requests (e.g., when `Accept: text/markdown` is set or a known AI user agent fetches a docs page) — but certain root-level agent files are static artifacts, not docs pages, and must be passed through as-is rather than treated as missing `.md` content.

## What it covers

The helper recognizes the following artifact paths:

- `llms.txt`
- `llms-full.txt`
- sitemap files
- `robots.txt`
- search JSON
- `agent-readability.json`

These are the same static artifacts the build emits for agent discovery (see "Connect a docs site" in `/docs/llms-full/build.txt`), so the helper keeps the markdown-rewrite layer from clobbering them.
