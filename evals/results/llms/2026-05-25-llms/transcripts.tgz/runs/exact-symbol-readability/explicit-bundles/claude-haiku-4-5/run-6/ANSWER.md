# Helper That Prevents Agent-Readability Artifacts

## Helper Name
**`isAgentReadabilityArtifactPath`**

## What It Does
The `isAgentReadabilityArtifactPath` helper identifies artifact paths that should not be rewritten as missing markdown pages.

## What It Covers
- `llms.txt` - The primary agent-readable index
- `llms-full.txt` - The full-context fallback containing all generated markdown pages
- Sitemap files (sitemap.xml, sitemap.md)
- `robots.txt`
- Search JSON files (search-index.json, search-content.json)
- `agent-readability.json`

This helper ensures that these special agent-readability artifacts are treated as static content that should not trigger 404 or "missing page" rewrites, allowing them to be properly served to agents and HTTP clients.
