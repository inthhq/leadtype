# Agent-Readability Artifact Prevention Helper

## Helper Name
**isAgentReadabilityArtifactPath**

## Description
`isAgentReadabilityArtifactPath` is a helper function that identifies artifact paths that should not be rewritten as missing markdown pages. 

## Coverage
The helper covers the following agent-readability artifacts:
- `llms.txt`
- `llms-full.txt`
- Sitemap files (`sitemap.xml`, `sitemap.md`)
- `robots.txt`
- Search JSON files (`search-index.json`, `search-content.json`)
- `agent-readability.json`

This function ensures these critical agent-readable files are preserved and not treated as missing pages that need to be converted to markdown during the build process.
