# Preventing Agent-Readability Artifacts From Being Rewritten

## Helper

**`isAgentReadabilityArtifactPath`**

## What it does

Per the Leadtype docs (`docs/reference/llm.md`), `isAgentReadabilityArtifactPath` identifies artifact paths that should **not** be rewritten as missing markdown pages.

## What it covers

It covers the following agent-readability artifacts:

- `llms.txt`
- `llms-full.txt`
- sitemap files
- `robots.txt`
- search JSON
- `agent-readability.json`

These are static deployment artifacts that hosted docs sites serve directly, so the helper ensures the docs pipeline does not mistake them for markdown pages that need to be regenerated or treated as missing.

## Source

- `/docs/reference/llm.md` (also surfaced via `/docs/llms-full/reference.txt`)
