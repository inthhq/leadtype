# Helper That Prevents Agent-Readability Artifacts from Being Rewritten

## Helper: `isAgentReadabilityArtifactPath`

**Source:** [`/docs/reference/llm.md`](/docs/reference/llm.md)

`isAgentReadabilityArtifactPath` is the helper that identifies artifact paths that should **not** be rewritten as missing markdown pages.

### What It Covers

It covers the following static artifact paths:

- `llms.txt`
- `llms-full.txt`
- Sitemap files (e.g., `sitemap.xml`, `sitemap.md`)
- `robots.txt`
- Search JSON
- `agent-readability.json`

By flagging these paths, the helper ensures that requests to these well-known agent-readability and site-infrastructure files are served as-is rather than treated as missing content and rewritten to a 404/missing-page response.
