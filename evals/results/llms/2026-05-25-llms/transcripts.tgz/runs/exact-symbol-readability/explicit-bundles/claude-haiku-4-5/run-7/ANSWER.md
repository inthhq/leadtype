# Agent-Readability Artifact Prevention

## Helper Function

**`isAgentReadabilityArtifactPath`** is the helper that prevents agent-readability artifacts from being rewritten as missing markdown pages.

## Coverage

This helper covers the following artifact paths:
- `llms.txt`
- `llms-full.txt`
- Sitemap files (sitemap.xml, sitemap.md)
- `robots.txt`
- Search JSON files (search-index.json, search-content.json)
- `agent-readability.json`

By identifying these paths, the helper ensures they are preserved as static artifacts and not inadvertently converted to markdown pages during the docs generation process.
