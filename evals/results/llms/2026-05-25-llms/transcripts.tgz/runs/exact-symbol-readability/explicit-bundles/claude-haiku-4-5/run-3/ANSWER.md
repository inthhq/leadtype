# Agent-Readability Artifact Prevention Helper

## Helper Name
`isAgentReadabilityArtifactPath`

## Description
`isAgentReadabilityArtifactPath` is a helper function that identifies artifact paths that should not be rewritten as missing markdown pages. It covers:

- `llms.txt`
- `llms-full.txt`
- Sitemap files
- `robots.txt`
- Search JSON
- `agent-readability.json`

This helper ensures that critical agent-readable deployment artifacts remain protected during the build process and are not inadvertently converted to missing markdown page entries.
