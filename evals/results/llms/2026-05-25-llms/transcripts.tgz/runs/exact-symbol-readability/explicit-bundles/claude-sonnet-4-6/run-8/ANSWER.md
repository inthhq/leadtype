# Preventing Agent-Readability Artifacts from Being Rewritten

## Helper

**`isAgentReadabilityArtifactPath`**

## Description

`isAgentReadabilityArtifactPath` is a helper that identifies artifact paths which should **not** be rewritten as missing markdown pages. It covers the following static artifacts:

- `llms.txt`
- `llms-full.txt`
- Sitemap files (e.g. `sitemap.xml`, `sitemap.md`)
- `robots.txt`
- Search JSON
- `agent-readability.json`

By recognising these paths as known agent-readability artifacts rather than missing docs pages, it prevents the docs pipeline from incorrectly treating them as 404 or stub markdown content during the build or serving process.

> Source: [LLM files reference](/docs/reference/llm.md)
