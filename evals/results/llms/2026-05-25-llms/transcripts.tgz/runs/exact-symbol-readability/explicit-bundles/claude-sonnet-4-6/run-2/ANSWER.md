# Preventing Agent-Readability Artifacts from Being Rewritten

## Helper

**`isAgentReadabilityArtifactPath`**

## Description

`isAgentReadabilityArtifactPath` is the helper that identifies artifact paths which should **not** be rewritten as missing markdown pages. It covers the following static files:

- `llms.txt`
- `llms-full.txt`
- Sitemap files (e.g., `sitemap.xml`, `sitemap.md`)
- `robots.txt`
- Search JSON
- `agent-readability.json`

By recognising these paths as known agent-readability artifacts, the helper ensures they are served as-is rather than being treated as unresolved or missing documentation pages.

> Source: [LLM files reference](/docs/reference/llm.md)
