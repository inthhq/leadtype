# Helper for Preventing Agent-Readability Artifacts

## Helper: `isAgentReadabilityArtifactPath`

The helper that prevents agent-readability artifacts like `llms.txt` and `llms-full.txt` from being rewritten as missing markdown pages is **`isAgentReadabilityArtifactPath`**.

### What It Covers

This helper identifies artifact paths that should not be rewritten as missing markdown pages. It covers:

- llms.txt
- llms-full.txt
- Sitemap files (sitemap.xml, sitemap.md)
- robots.txt
- Search JSON files (search-index.json, search-content.json)
- agent-readability.json
