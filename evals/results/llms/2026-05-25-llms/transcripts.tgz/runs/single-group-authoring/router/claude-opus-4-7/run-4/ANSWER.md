# Frontmatter `group` and Monolithic Output in Leadtype

Sources consulted:
- `/llms.txt`
- `/llms-full.txt`
- `/docs/llms-full/authoring.txt` (which includes `/docs/authoring/frontmatter.md`)
- `/docs/llms-full/build.txt` (which includes `/docs/build/connect-docs-site.md`)

## How `group` controls navigation

Each MDX page declares YAML frontmatter. `title` is required; `group` is optional but, when supplied, must match a slug defined in `docs.config.ts` — if a page declares an unknown group, the build fails.

The `group` value is a single source of truth that drives several navigation surfaces at once:

- **Sidebar position** — pages are placed in the docs sidebar according to their group.
- **`llms.txt` section** — the routing file groups topic links under the matching section.
- **Search metadata** — the group is attached to each indexed page.
- **`AGENTS.md` grouping** — bundled agent-readable output is organized by group.

A page can also belong to more than one group by giving an array, e.g. `group: [a, b]`, and it will appear under each.

## How `group` relates to monolithic output (`/llms-full.txt`)

`/llms-full.txt` at the site root is the **monolithic fallback**: per the Frontmatter page, it "contains all generated markdown pages and is not split by group." In other words, while `group` partitions per-topic bundles (such as `/docs/llms-full/authoring.txt`, `/docs/llms-full/build.txt`, etc. listed in the Full Context Router), the root `/llms-full.txt` ignores `group` entirely and concatenates everything.

This gives agents two complementary entry points:
- `/llms.txt` — a small router whose sections come from `group`.
- `/llms-full.txt` — the ungrouped, full-context fallback served as a static artifact alongside `sitemap.xml`, `robots.txt`, the search JSON, and `agent-readability.json` (per the Connect a docs site page).

## Optional frontmatter fields

In addition to `group`, the Frontmatter page lists many optional fields. Examples include:

- **`description`** — optional but recommended; it becomes the routing hint shown in `llms.txt`.
- **`deprecated`** (with companion **`deprecatedReason`**) — marks a page as deprecated and explains why.
- **`experimental`**, **`canary`**, **`new`**, **`draft`** — lifecycle/status flags.
- **`icon`**, **`tags`**, **`availableIn`**, **`full`** — presentation and scoping metadata.
- **`lastModified`** and **`lastAuthor`** — automatically populated when the build runs with `--enrich-git`.

## Summary

`group` is the lever that organizes Leadtype's navigation: it controls sidebar order, section breaks in `/llms.txt`, search facets, and `AGENTS.md` grouping, and it must reference a slug from `docs.config.ts`. The monolithic `/llms-full.txt`, by contrast, deliberately ignores `group` and serves every generated markdown page as a single fallback bundle for agents that want full context in one request.
