# Frontmatter `group` and the Monolithic `/llms-full.txt`

Source: `/docs/authoring/frontmatter.md` (via `/llms.txt` → `/llms-full.txt` → `/docs/llms-full/authoring.txt`), with supporting context from `/docs/build/connect-docs-site.md`.

## How `group` controls navigation

Each MDX page declares YAML frontmatter. `title` is required; `group` is optional but, when present, must match a slug from `docs.config.ts`. The build fails if a page declares an unknown `group`.

A single `group` value drives several navigation surfaces at once:

- **Sidebar position** in the rendered docs site.
- **Section placement in `llms.txt`** (the routing hint file agents read first).
- **Search metadata** used by the generated search index.
- **AGENTS.md grouping** for the agent-readable bundle.

A page can belong to more than one group by using array syntax, e.g. `group: [a, b]`, in which case it appears under each of those groupings.

## How `group` interacts with monolithic output (`/llms-full.txt`)

The root `/llms-full.txt` is the **fallback monolithic bundle**: it contains *all* generated markdown pages concatenated together and is **not split by group**. In other words, while `group` partitions navigation, the sidebar, `llms.txt` sections, search metadata, and AGENTS.md, it does *not* partition the top-level `/llms-full.txt` — that file is intentionally a single, group-agnostic catch-all that routes agents to topic-specific deep-context files (e.g. `/docs/llms-full/authoring.txt`).

This is consistent with the build guidance in "Connect a docs site": `/llms.txt` and `/llms-full.txt` are served as static artifacts at the site root, alongside markdown mirrors under `/docs/*.md`.

## Optional frontmatter fields

In addition to the optional `group` and `description` (recommended because it becomes the routing hint in `llms.txt`), the following optional fields are documented:

- `icon`
- `deprecated`
- `deprecatedReason`
- `experimental`
- `canary`
- `new`
- `draft`
- `tags`
- `availableIn`
- `full`
- `lastModified` — populated automatically when `--enrich-git` is enabled.
- `lastAuthor` — also populated by `--enrich-git`.

Two concrete examples called out by the docs:

1. **`deprecated`** (with companion `deprecatedReason`) — marks a page as deprecated for both UI and agent consumers.
2. **`lastModified`** — filled in automatically when the build is run with `--enrich-git`, giving agents a freshness signal without manual maintenance.

## Summary

- `group` is an optional frontmatter field that must match a slug from `docs.config.ts`.
- It controls sidebar order, `llms.txt` sections, search metadata, and AGENTS.md grouping.
- Pages may belong to multiple groups via `group: [a, b]`.
- Unknown groups fail the build.
- `/llms-full.txt` is the monolithic fallback containing every generated markdown page and is explicitly **not** split by `group`; per-topic splits live under `/docs/llms-full/*.txt`.
