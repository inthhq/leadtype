# Frontmatter `group` and `/llms-full.txt`

In Leadtype, each MDX page uses YAML frontmatter. `title` is required, while `group` is optional. When present, `group` should match a group slug from `docs.config.ts`; if a page names an unknown group, the build fails.

`group` is a navigation and routing signal. It controls:

- the page’s sidebar position,
- which section the page appears under in `llms.txt`,
- search metadata,
- grouping in generated `AGENTS.md`.

A page can also belong to more than one group by using an array, for example:

```yaml
group: [authoring, reference]
```

However, `group` does **not** shard the full-context output. `/llms-full.txt` is a single root fallback that contains every generated markdown docs page. Leadtype does not publish separate per-group full-context files by default. In short: use groups for navigation, routing, and metadata—not for splitting `/llms-full.txt`.

Optional frontmatter fields include `description`, `icon`, `deprecated`, `deprecatedReason`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor`. `description` is recommended because it becomes the routing hint in `llms.txt`; `lastModified` and `lastAuthor` can be filled automatically when `--enrich-git` is enabled.
