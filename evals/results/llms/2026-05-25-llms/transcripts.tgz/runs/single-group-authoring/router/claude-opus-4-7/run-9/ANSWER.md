# Frontmatter `group` and Monolithic Output (`/llms-full.txt`)

Sources:
- `/docs/authoring/frontmatter.md` (via `/docs/llms-full/authoring.txt`)
- `/llms-full.txt` (the root router)
- `/docs/build/connect-docs-site.md` (via `/docs/llms-full/build.txt`)

## What `group` is

Every MDX page in Leadtype carries YAML frontmatter. `title` is required, `description` is optional (but recommended, because it becomes the routing hint in `llms.txt`), and `group` is optional. When present, `group` should match a slug defined in `docs.config.ts`. If a page declares an unknown group, **the build fails** — `group` is validated, not free-form.

## How `group` controls navigation

A single `group` value drives four surfaces simultaneously:

1. **Sidebar position** in the rendered docs site.
2. **The `llms.txt` section** the page is filed under (so agents can pick the smallest matching topic).
3. **Search metadata** attached to the page in the search index.
4. **AGENTS.md grouping** when docs are bundled for shipping with a package.

A page can belong to more than one group by using an array, e.g. `group: [a, b]`, in which case it appears under each of those groupings in all four surfaces.

## How `group` interacts with monolithic output (`/llms-full.txt`)

`/llms-full.txt` is the **full-context router** at the site root. Importantly, the docs explicitly state:

> The root `/llms-full.txt` fallback contains all generated markdown pages and is **not split by group**.

So `group` does *not* partition `/llms-full.txt` itself — that file is the catch-all monolith. Instead, `group` is what produces the per-topic deep-context files that `/llms-full.txt` links to (for example `/docs/llms-full/authoring.txt`, `/docs/llms-full/build.txt`, `/docs/llms-full/reference.txt`). Each of those topic bundles concatenates the pages belonging to a group, so agents can fetch the smallest topic that matches a task rather than downloading the entire monolith.

In short:
- `group` → which per-topic `llms-full` bundle a page joins, plus its sidebar/search/AGENTS placement.
- `/llms-full.txt` at the root → ungrouped fallback containing everything.

This is consistent with the build guidance to keep `/llms.txt`, `/llms-full.txt`, sitemaps, search JSON, and `agent-readability.json` as static artifacts at known URLs.

## Optional frontmatter fields (at least two)

The frontmatter doc lists the following optional fields: `icon`, `deprecated`, `deprecatedReason`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor`. Highlights:

- **`deprecated`** — marks a page as deprecated (typically paired with **`deprecatedReason`** to explain why or point at a replacement).
- **`tags`** — additional classification beyond `group`, which feeds search metadata.
- **`experimental` / `canary` / `new` / `draft`** — lifecycle flags that downstream surfaces can render as badges or filter on.
- **`availableIn`** — declares which versions/products the page applies to.
- **`lastModified`** and **`lastAuthor`** — populated automatically when the build runs with `--enrich-git`, so authors don't set them by hand.
