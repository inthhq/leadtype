# Frontmatter `group` and Monolithic Output in Leadtype

_Source: `/llms.txt` → `/llms-full.txt` → `/docs/llms-full/authoring.txt` (which embeds `/docs/authoring/frontmatter.md`), with a supporting note from `/docs/build/connect-docs-site.md`._

## What `group` is

In a Leadtype MDX page, frontmatter is YAML and only `title` is required. `description` is optional but recommended (it becomes the routing hint in `llms.txt`). `group` is optional and, when present, must match a slug defined in `docs.config.ts`. If a page declares an unknown `group`, the build fails — this is the lint guardrail that keeps navigation consistent.

A page can belong to a single group or to multiple groups using array syntax:

```yaml
---
title: Frontmatter
description: Required fields, group semantics, optional fields, and lint behavior.
group: [authoring, reference]
---
```

## How `group` controls navigation

The `group` value is the single input that fans out into four navigation/discovery surfaces:

1. **Sidebar position** on the rendered docs site.
2. **`llms.txt` section** — the routing index for agents groups its links by `group`.
3. **Search metadata** — entries in the search index are tagged with their group(s).
4. **AGENTS.md grouping** — the package-docs bundle organizes pages under their group headings.

Because the same slug drives all four, renaming or mis-typing a group would desynchronize navigation; the "unknown group ⇒ build fails" rule prevents that.

## How `group` relates to monolithic output (`/llms-full.txt`)

The root `/llms-full.txt` is the **fallback monolithic bundle**: it contains **all generated markdown pages** concatenated together and is **not split by group**. In other words, `group` does *not* partition `/llms-full.txt` — that file is intentionally the catch-all.

The per-topic "full context" files under `/docs/llms-full/*.txt` (e.g. `/docs/llms-full/authoring.txt`, `/docs/llms-full/reference.txt`) are the group-scoped monolithic bundles. `/llms-full.txt` itself acts as a router that points agents to the smallest of those topic files that fits the task, while still existing as the complete fallback.

On a connected docs site, `/llms.txt` and `/llms-full.txt` are served as static artifacts alongside the per-page markdown mirrors under `/docs/*.md`, so agents can fetch either the group-scoped topic bundle or the full monolith.

## At least two optional frontmatter fields

Optional fields documented for a Leadtype page include:

- `icon`
- `deprecated`
- `deprecatedReason`
- `experimental`
- `canary`
- `new`
- `draft`
- `tags`
- `availableIn`
- `full`
- `lastModified` — auto-filled when `--enrich-git` is enabled
- `lastAuthor` — auto-filled when `--enrich-git` is enabled

Two concrete examples:

- **`deprecated`** (with optional companion `deprecatedReason`) — marks a page as superseded so the sidebar, search, and AGENTS.md can flag it.
- **`lastModified`** — populated automatically from git history when the build is run with `--enrich-git`, giving agents a freshness signal without hand-maintained dates.

## TL;DR

- `title` required; `description` recommended; `group` optional but validated against `docs.config.ts`.
- `group` drives sidebar order, `llms.txt` sectioning, search metadata, and AGENTS.md grouping — and supports multi-group membership via `group: [a, b]`.
- Per-group monolithic bundles live at `/docs/llms-full/<group>.txt`; the root `/llms-full.txt` is the unsplit, all-pages fallback.
- Optional fields such as `deprecated` and `lastModified` (auto-filled with `--enrich-git`) enrich the same pipeline.
