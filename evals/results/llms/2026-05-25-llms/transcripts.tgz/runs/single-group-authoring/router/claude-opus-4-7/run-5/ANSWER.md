# Frontmatter `group` and the Monolithic `/llms-full.txt` Output

_Source: Leadtype docs — `/docs/authoring/frontmatter.md` (via `/docs/llms-full/authoring.txt`) and `/docs/build/connect-docs-site.md`._

## What `group` does

Every MDX page in Leadtype carries YAML frontmatter. `title` is required; `description` is optional but recommended because it becomes the routing hint in `llms.txt`. The `group` field is optional, and its value must match a slug defined in `docs.config.ts`.

When set, `group` drives four things at once:

1. **Sidebar position** in the rendered docs site (navigation).
2. **`llms.txt` section** — pages are bucketed under their group heading in the agent-readable router.
3. **Search metadata** attached to each page.
4. **AGENTS.md grouping** for package-shipped docs.

A page can belong to multiple groups by writing `group: [a, b]`, in which case it appears under each. If a page declares a group that is not registered in `docs.config.ts`, the **build fails** — this is the lint guardrail that keeps navigation consistent.

## How `group` interacts with `/llms-full.txt`

`/llms-full.txt` is the **monolithic fallback** bundle served at the site root. Per the authoring docs:

> "The root `/llms-full.txt` fallback contains all generated markdown pages and is **not split by group**."

In other words:

- The per-group `llms-full` topic files (e.g. `/docs/llms-full/authoring.txt`) are the *split*, group-scoped deep-context bundles that the router in `/llms-full.txt` points to.
- The root `/llms-full.txt` itself ignores `group` and aggregates every generated markdown page into one document. It is a static artifact alongside `/llms.txt`, sitemap files, `robots.txt`, search JSON, and `agent-readability.json`.

So `group` controls *navigation and the split bundles*, while the root monolithic output is intentionally group-agnostic so an agent can always grab "everything" in a single fetch.

## Optional frontmatter fields

Beyond `description` and `group`, the following optional fields are documented:

- `icon`
- `deprecated`
- `deprecatedReason`
- `experimental`
- `canary`
- `new`
- `draft`
- `tags`
- `availableIn`
- `full`
- `lastModified` — populated automatically when the build is run with `--enrich-git`.
- `lastAuthor` — also populated by `--enrich-git`.

Two concrete examples:

- **`deprecated`** (with the companion `deprecatedReason`) — marks a page as superseded so the docs site and agent bundles can flag it.
- **`tags`** — supplies extra search metadata that complements the `group`-derived bucket.

## TL;DR

`group` is the single knob that places a page in the sidebar, in a `llms.txt` section, in search metadata, and in AGENTS.md — and it must resolve to a slug from `docs.config.ts` or the build fails. The split `/docs/llms-full/<group>.txt` bundles are scoped by `group`, but the root `/llms-full.txt` deliberately is not: it is the complete, unsplit corpus.
