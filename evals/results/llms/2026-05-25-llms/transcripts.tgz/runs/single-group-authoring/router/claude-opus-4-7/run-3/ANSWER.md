# Frontmatter `group` and Monolithic Output in Leadtype

## How `group` Controls Navigation

Every MDX page in Leadtype carries YAML frontmatter. While `title` is required, `group` is an *optional* field that, when present, should match a slug defined in `docs.config.ts`. If a page declares an unknown group, the build fails.

The `group` value is a single source of truth that fans out into multiple navigation surfaces:

- **Sidebar position** — pages are ordered within their group.
- **`llms.txt` section** — the group becomes the section heading in the routing file consumed by agents.
- **Search metadata** — group is indexed alongside the page.
- **AGENTS.md grouping** — the same slug is used when AGENTS.md is generated for shipped package docs.

A page can belong to more than one group by using array syntax (`group: [a, b]`), which lets it appear under multiple sidebar/section headings simultaneously.

## How `group` Relates to Monolithic Output (`/llms-full.txt`)

Leadtype emits a root-level monolithic bundle at `/llms-full.txt`. This file acts as a **full-context router** — it is the agent-readable fallback that contains *all* generated markdown pages and is **not split by group**. In other words, `group` shapes the per-section views (sidebar, `llms.txt`, AGENTS.md), but the root `/llms-full.txt` deliberately ignores grouping so an agent can fetch one document and see everything.

Per-topic monolithic bundles do exist (e.g. `/docs/llms-full/authoring.txt`), and these *are* organized so each one corresponds to a topic area — but the root-level `/llms-full.txt` is the ungrouped, complete fallback.

As part of website-mode build wiring, `/llms-full.txt` is published as a static artifact alongside `/llms.txt`, sitemap files, `robots.txt`, the search JSON, and `agent-readability.json`.

## Optional Frontmatter Fields

Beyond `group`, Leadtype recognizes a number of optional frontmatter fields, including:

- **`description`** — optional but recommended; it becomes the routing hint shown next to the page link inside `llms.txt`.
- **`deprecated`** (with a companion **`deprecatedReason`**) — marks a page as deprecated and explains why.
- **`experimental`**, **`canary`**, **`new`**, **`draft`** — lifecycle/status flags surfaced to readers and agents.
- **`tags`** — additional classification orthogonal to `group`.
- **`availableIn`** — declares which product/version a page applies to.
- **`icon`** and **`full`** — presentation hints.
- **`lastModified`** and **`lastAuthor`** — auto-populated from git history when the build runs with `--enrich-git`.

## Summary

`group` is the optional frontmatter field that wires a page into navigation: the sidebar, `llms.txt` sections, search metadata, and AGENTS.md grouping — and pages can join several groups at once. The root `/llms-full.txt` is intentionally exempt from this grouping and serves as the complete, monolithic fallback containing every generated markdown page. Optional companion fields like `description`, `deprecated`/`deprecatedReason`, `experimental`, `tags`, `availableIn`, and the git-enriched `lastModified`/`lastAuthor` further annotate pages without affecting how they are grouped.
