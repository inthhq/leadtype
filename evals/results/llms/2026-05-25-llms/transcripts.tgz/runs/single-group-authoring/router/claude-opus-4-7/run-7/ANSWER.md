# Frontmatter `group` and Monolithic Output in Leadtype

Source: [`/docs/authoring/frontmatter.md`](/docs/authoring/frontmatter.md) (surfaced via [`/llms-full.txt`](/llms-full.txt) → [`/docs/llms-full/authoring.txt`](/docs/llms-full/authoring.txt)).

## What `group` is

Every MDX page in Leadtype carries YAML frontmatter. Only `title` is required; `description` is optional but recommended because it becomes the routing hint emitted into `llms.txt`. The `group` field is optional and, when set, must match a slug declared in `docs.config.ts` — an unknown `group` fails the build.

## How `group` controls navigation

A single `group` value fans out into four navigation-adjacent surfaces:

1. **Sidebar position** — the page is placed under the matching group in the rendered docs site.
2. **`llms.txt` section** — the page is listed in the section corresponding to its group, so agents see a grouped table of contents.
3. **Search metadata** — the group becomes a facet/tag attached to the search index entry.
4. **`AGENTS.md` grouping** — bundled agent guidance is organized by the same slug.

A page may belong to more than one group by using an array, e.g. `group: [a, b]`, in which case it appears under each group on all four surfaces.

## How `group` interacts with monolithic output (`/llms-full.txt`)

The per-topic deep-context files (e.g. `/docs/llms-full/authoring.txt`) are sliced by group. The root **`/llms-full.txt`** is intentionally different: it is the **fallback monolith that contains all generated markdown pages and is not split by group**. In other words, `group` partitions the per-topic bundles and navigation, but every page — regardless of its group(s) — still flows into the single root `/llms-full.txt` artifact so agents always have a complete-context option.

## Optional frontmatter fields

In addition to `description` and `group`, the documented optional fields include:

- `icon`
- `deprecated`
- `deprecatedReason`
- `experimental`
- `canary`
- `new`
- `draft`
- `tags`
- `availableIn`
- `full`
- `lastModified` — auto-populated when the build runs with `--enrich-git`
- `lastAuthor` — also auto-populated under `--enrich-git`

Two representative examples:

- **`deprecated`** (with the companion **`deprecatedReason`**) — marks a page as deprecated so the site, `llms.txt` hint, and agent bundles can warn consumers.
- **`tags`** — adds extra search/index metadata orthogonal to `group`, useful for cross-cutting topics.

## Summary

`group` is the single knob that ties a page's sidebar slot, its `llms.txt` section, its search facet, and its `AGENTS.md` placement to a slug defined in `docs.config.ts`. Group-scoped bundles live under `/docs/llms-full/*.txt`, while the root `/llms-full.txt` ignores grouping and ships every page as one monolithic context file.
