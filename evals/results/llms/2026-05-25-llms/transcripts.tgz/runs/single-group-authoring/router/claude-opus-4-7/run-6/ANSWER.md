# Frontmatter `group` and Monolithic Output in Leadtype

_Source: `/llms.txt` → `/llms-full.txt` → `/docs/llms-full/authoring.txt` (which embeds `/docs/authoring/frontmatter.md`)._

## What `group` is

Each MDX page in Leadtype carries YAML frontmatter. `title` is required; `group` is **optional** and, when present, must match a slug declared in `docs.config.ts`. If a page declares an unknown `group`, the build fails.

A page can belong to a single group (`group: foo`) or to multiple groups via an array (`group: [a, b]`).

## How `group` controls navigation

A single `group` value drives several navigation-adjacent surfaces simultaneously:

1. **Sidebar position** on the rendered docs site.
2. **Section placement in `/llms.txt`** — `group` decides which section a page is listed under in the routing index.
3. **Search metadata** — the group is attached to the page's search record.
4. **`AGENTS.md` grouping** — pages are clustered by group in the agent-facing manifest.

In other words, `group` is the single piece of frontmatter that wires a page into every navigation/discovery artifact at once, so authors do not have to maintain sidebar config, search facets, and agent manifests separately.

## How `group` interacts with the monolithic `/llms-full.txt`

The root `/llms-full.txt` is the **monolithic fallback** bundle: it contains **all generated markdown pages** and is explicitly **not split by `group`**. This makes it the safe, complete artifact for agents that want full context in a single fetch.

Group-scoped deep-context bundles live under `/docs/llms-full/<group>.txt` (e.g. `/docs/llms-full/authoring.txt`). Those per-group bundles are what `group` partitions content into; the root monolith is the union of everything. So:

- `group` → determines which per-group `llms-full` bundle (and which `llms.txt` section, sidebar slot, search facet, AGENTS.md cluster) a page lands in.
- Omitting/changing `group` does **not** remove a page from `/llms-full.txt` — the monolith always contains every generated markdown page.

## Optional frontmatter fields

Beyond `group` itself, Leadtype recognizes the following optional frontmatter fields:

- `description` — optional but recommended; becomes the page's routing hint in `llms.txt`.
- `icon`
- `deprecated` and `deprecatedReason`
- `experimental`
- `canary`
- `new`
- `draft`
- `tags`
- `availableIn`
- `full`
- `lastModified` and `lastAuthor` — populated automatically when the build is run with `--enrich-git`.

Two illustrative examples:

- **`description`** — purely optional, but if you set it, it is what agents read in the `/llms.txt` index when deciding whether to fetch the page, making it the most navigation-impactful optional field after `group`.
- **`deprecated`** (often paired with `deprecatedReason`) — flags a page as superseded so it can be styled/badged in the site and surfaced as deprecated in agent-readable artifacts without removing it from the monolithic `/llms-full.txt`.
