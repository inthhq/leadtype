# Frontmatter `group` and Monolithic Output (`/llms-full.txt`)

Sources:
- `/docs/authoring/frontmatter.md`
- `/docs/reference/llm.md`

## How `group` controls navigation

The `group` field in a page's YAML frontmatter is optional, and when set it must match a slug declared in `docs.config.ts`. If a page declares an unknown group, the build fails.

A page's `group` value drives four navigation/discovery surfaces at once:

1. **Sidebar position** – where the page appears in the docs-site navigation.
2. **`llms.txt` section** – which section of the root agent-readable router the page is listed under.
3. **Search metadata** – the group is attached to the search index entries.
4. **AGENTS.md grouping** – how pages are clustered inside the bundled `AGENTS.md`.

A page may belong to more than one group by using array syntax: `group: [a, b]`. It will then appear under each listed group in all four surfaces above.

## How `group` relates to monolithic output

The monolithic `/llms-full.txt` file is written by `generateLLMFullContextFiles`. It is a single root file containing every generated markdown docs page concatenated together. Key behavior:

- The root `/llms-full.txt` fallback is **not split by group** — it always contains all generated markdown pages.
- Groups still organize the per-section `llms.txt` listings, sidebar navigation, search metadata, and `AGENTS.md`, but they are **not published as per-group full-context files by default**.

In other words, `group` shapes how content is partitioned for humans and routers, while `/llms-full.txt` deliberately ignores `group` so an agent can grab the entire corpus in one request.

## Optional frontmatter fields

`title` is required, and `description` is optional but recommended (it becomes the routing hint shown in `llms.txt`). Beyond those, the optional frontmatter fields documented include:

- `icon`
- `deprecated`
- `deprecatedReason`
- `experimental`
- `canary`
- `new`
- `draft`
- `tags`
- `availableIn`
- `full`
- `lastModified` — populated automatically when `--enrich-git` is enabled.
- `lastAuthor` — populated automatically when `--enrich-git` is enabled.

At least two examples: `tags` (free-form classification metadata) and `deprecated` (flag a page as outdated, typically paired with `deprecatedReason`).
