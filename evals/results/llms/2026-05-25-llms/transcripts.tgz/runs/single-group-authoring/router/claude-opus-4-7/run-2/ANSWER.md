# Frontmatter `group` and Monolithic Output in Leadtype

Sources consulted (in this docs site):
- `/llms.txt`
- `/llms-full.txt`
- `/docs/llms-full/authoring.txt` (which embeds `/docs/authoring/frontmatter.md`)
- `/docs/llms-full/build.txt`

## How `group` controls navigation

Each MDX page in Leadtype has YAML frontmatter. `title` is required; `group` is optional but, when set, must match a slug declared in `docs.config.ts` (an unknown group fails the build).

The `group` value is a single source of truth that drives several navigation-related outputs at once:

- **Sidebar position** — where the page appears in the docs site navigation.
- **`/llms.txt` section** — which heading/section the page is listed under in the routing index that agents read first.
- **Search metadata** — group is attached as facetable metadata for the search index.
- **AGENTS.md grouping** — how the page is bucketed inside the AGENTS.md bundle shipped with packages.

A page can belong to more than one group by using an array, e.g. `group: [a, b]`, in which case it shows up in each group's navigation/section.

## How `group` interacts with monolithic output (`/llms-full.txt`)

`/llms-full.txt` is the "full context router" served at the site root. Importantly, the frontmatter docs state:

> "The root `/llms-full.txt` fallback contains all generated markdown pages and is not split by group."

So `group` does **not** subdivide the root monolithic bundle. `/llms-full.txt` is a single fallback that includes every generated markdown page regardless of group, and instead links out to per-topic deep-context files like `/docs/llms-full/authoring.txt`, `/docs/llms-full/build.txt`, etc. Those topic-level `llms-full` files are the per-area equivalents; the root file is intentionally the ungrouped, exhaustive artifact agents can fall back to.

In short:
- `group` partitions the human-facing navigation, the `/llms.txt` index, search metadata, and AGENTS.md.
- `group` does **not** partition `/llms-full.txt`; that file is monolithic by design.

## Optional frontmatter fields

Beyond `group`, the frontmatter reference lists many optional fields. Examples include:

- **`description`** — optional but recommended; it becomes the routing hint shown next to the page link in `/llms.txt`.
- **`deprecated`** (with companion **`deprecatedReason`**) — marks a page as deprecated and explains why.
- **`experimental`**, **`canary`**, **`new`**, **`draft`** — lifecycle/status flags surfaced in navigation and bundles.
- **`icon`**, **`tags`**, **`availableIn`**, **`full`** — display and scoping hints.
- **`lastModified`** and **`lastAuthor`** — git-derived metadata, populated automatically when the build runs with `--enrich-git`.

(At least two as requested: `description` and `deprecated` — plus several more above for completeness.)
