# Frontmatter `group` and `/llms-full.txt`

In Leadtype, every MDX page has YAML frontmatter. `title` is required, while `group` is optional. When used, `group` should match a slug defined in `docs.config.ts`; if a page declares an unknown group, the build fails.

The `group` value controls how the page is organized across the docs outputs:

- It determines the page's sidebar position/navigation grouping.
- It determines the section where the page appears in `llms.txt`.
- It is included in search metadata.
- It is used for `AGENTS.md` grouping.
- A page can belong to multiple groups with array syntax, for example `group: [a, b]`.

The monolithic `/llms-full.txt` output is different: it is a root fallback that contains all generated markdown pages and is not split by `group`. In other words, `group` affects navigation, grouped indexes, search metadata, and agent grouping, but `/llms-full.txt` remains an all-pages bundle.

Optional frontmatter fields include `description`, `icon`, `deprecated`, `deprecatedReason`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor`. `description` is recommended because it becomes the routing hint in `llms.txt`; `lastModified` and `lastAuthor` can be filled automatically when `--enrich-git` is enabled.
