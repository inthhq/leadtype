# Frontmatter Group and Monolithic Output

## How Frontmatter `group` Controls Navigation

The `group` frontmatter field is an optional parameter that should match a slug from `docs.config.ts`. It serves as a critical control for organizing documentation content:

- **Sidebar Position**: The group value determines where a page appears in the sidebar navigation
- **llms.txt Sections**: Pages are organized into sections within the `/llms.txt` file based on their group
- **Search Metadata**: The group influences search organization and metadata
- **AGENTS.md Grouping**: Related pages are grouped together in the `AGENTS.md` file based on their group assignment

Pages can belong to multiple groups by using the syntax `group: [a, b]`. If a page declares a group that doesn't exist in the configuration, the build fails.

## Monolithic Output (`/llms-full.txt`)

The root `/llms-full.txt` file is a comprehensive, monolithic fallback that contains **every generated markdown docs page**. The key distinction of this file is that:

- **Not Split by Group**: Unlike the segmented `/llms.txt` (which organizes content by group), the `llms-full.txt` file is a single, unified output containing all pages
- **Full-Context Fallback**: It serves as a complete reference when full context is needed
- **Groups Not Used for Sharding**: While groups organize the `/llms.txt` sections, navigation, search metadata, and `AGENTS.md`, groups are explicitly **not used to create per-group full-context files**

## Optional Frontmatter Fields

Two important optional frontmatter fields include:

1. **`description`**: While optional, this field is highly recommended because it becomes the routing hint in `llms.txt`, helping agents understand the page's purpose
2. **`deprecated`**: An optional field that marks pages as deprecated, with the companion field `deprecatedReason` providing context for why the page is no longer current

Other optional fields available include: `icon`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor` (the latter two are auto-populated when `--enrich-git` is enabled).
