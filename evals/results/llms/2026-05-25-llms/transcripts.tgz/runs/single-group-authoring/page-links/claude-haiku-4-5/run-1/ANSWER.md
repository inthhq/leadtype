# Frontmatter Group and Monolithic Output in Leadtype

## Overview
The frontmatter `group` field is a critical feature in Leadtype that controls both navigation organization and how content is aggregated in monolithic output files like `/llms-full.txt`.

## How Frontmatter `group` Controls Navigation

The `group` field in page-level YAML frontmatter drives multiple aspects of documentation organization:

1. **Sidebar Position**: The group value determines where a page appears in the sidebar navigation structure, grouping related pages together.

2. **llms.txt Sections**: Groups organize the content sections within `/docs/llms.txt`, creating a hierarchical map of documentation organized by group.

3. **Search Metadata**: The group assignment influences search indexing and categorization, allowing users to filter search results by documentation group.

4. **AGENTS.md Grouping**: Pages are grouped in the `AGENTS.md` file (used for npm-bundled offline docs) according to their group assignments.

## Monolithic Output: `/llms-full.txt`

The `/llms-full.txt` file is a root-level full-context fallback that contains **every generated markdown docs page in a single file**. A key distinction is:

- **Groups organize but do not shard**: While groups control sidebar position, llms.txt sections, search metadata, and AGENTS.md grouping, they are **not published as per-group full-context files by default**.
- The monolithic `/llms-full.txt` contains all pages regardless of their group assignments, serving as a comprehensive fallback for HTTP agents that start at `/llms.txt`.

This design allows agents to have both targeted, group-organized navigation (via `/llms.txt` and `/docs/llms.txt`) and comprehensive full-context access (via `/llms-full.txt`).

## Multiple Group Support

A single page can belong to multiple groups using array syntax: `group: [a, b]`. This enables pages to appear in multiple navigation contexts.

## Optional Frontmatter Fields

Beyond the required `title` field and the routing-critical `group` field, Leadtype supports several optional frontmatter fields:

1. **`description`**: Though optional, this is strongly recommended. It becomes the routing hint in llms.txt, providing context for agents navigating the documentation.

2. **`icon`**: Specifies an icon for the page in the sidebar navigation.

Additional optional fields include:
- `deprecated` / `deprecatedReason`: Mark pages as deprecated
- `experimental`: Flag experimental features
- `canary`: Indicate canary/preview features
- `new`: Mark newly added content
- `draft`: Indicate draft status
- `tags`: Add searchable tags to pages
- `availableIn`: Specify product/version availability
- `full`: Control full-context inclusion
- `lastModified` and `lastAuthor`: Git-enriched metadata (populated when `--enrich-git` is enabled)

## Group Validation

If a page declares a group that is unknown (not defined in `docs.config.ts`), the build fails, ensuring configuration consistency across the documentation site.

## Best Practice

Leadtype recommends: **Use groups for routing, not sharding.** Group descriptions should serve as routing hints to help navigation systems organize content, not as marketing copy.
