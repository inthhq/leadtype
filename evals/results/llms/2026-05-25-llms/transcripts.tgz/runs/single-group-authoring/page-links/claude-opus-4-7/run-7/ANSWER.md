# Frontmatter `group` and monolithic output (`/llms-full.txt`)

Sources consulted:
- `/docs/authoring/frontmatter.md`
- `/docs/reference/llm.md`

## What `group` controls

Each MDX page carries YAML frontmatter. `title` is required; `group` is **optional** and, when set, must match a slug declared in `docs.config.ts`. If a page declares an unknown `group`, the build fails.

A single `group` value drives four things at once:

1. **Sidebar / navigation position** — pages are ordered into the section corresponding to their group slug.
2. **`llms.txt` section** — the group determines which heading a page is listed under in the routing map.
3. **Search metadata** — group is attached to the search index entries.
4. **`AGENTS.md` grouping** — the npm-bundled agent file is organized by the same group slugs.

A page can belong to more than one group by giving `group` an array, e.g. `group: [a, b]`.

## How `group` relates to monolithic output

The monolithic output is the **root `/llms-full.txt`**, written by `generateLLMFullContextFiles`. Key behavior:

- `/llms-full.txt` contains **every generated markdown docs page** concatenated into a single file.
- It is **not split by group** — groups continue to organize the `llms.txt` map, navigation, search metadata, and `AGENTS.md`, but they are **not published as per-group full-context files by default**.
- The guidance from the LLM-files reference is explicit: "Use groups for routing, not sharding." Group descriptions should be routing hints, not marketing copy.

So `group` is a routing/organization signal for the human-facing site, the `llms.txt` index, search, and `AGENTS.md`, while `/llms-full.txt` deliberately ignores groups and ships as one flat fallback bundle for agents that want everything.

## Optional frontmatter fields (examples)

The frontmatter reference lists these optional fields: `icon`, `deprecated`, `deprecatedReason`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor`. Two examples:

- **`deprecated`** — marks a page as deprecated (often paired with `deprecatedReason` to explain why or point at a replacement).
- **`lastModified`** — a git-enrichment field populated automatically when the generator is run with `--enrich-git` (alongside `lastAuthor`).

Other commonly useful ones include `description` (optional but recommended, since it becomes the routing hint shown in `llms.txt`) and `tags` for additional search facets.
