# Frontmatter `group` and Monolithic Output in Leadtype

## The `group` Frontmatter Field

`group` is an **optional** frontmatter field in every MDX page. Its value must match a slug defined in `docs.config.ts`; if a page declares an unknown group the build fails.

### What `group` Controls

| Output / Feature | Effect |
|---|---|
| **Sidebar position** | Pages are sorted and nested under their group in site navigation. |
| **`llms.txt` sections** | The product-level `/llms.txt` (and docs-scoped `/docs/llms.txt`) is divided into sections by group, giving HTTP agents a structured map of the docs. |
| **Search metadata** | Group membership is embedded in the static search index so queries can be scoped by section. |
| **`AGENTS.md` grouping** | When docs are bundled inside an npm tarball, `AGENTS.md` organises links by group for offline coding agents. |

A page can belong to **multiple groups** by providing a YAML list:

```yaml
group: [authoring, reference]
```

> **Tip (from the docs):** "Use groups for routing, not sharding. Group descriptions should be routing hints, not marketing copy."

---

## Monolithic Output – `/llms-full.txt`

`generateLLMFullContextFiles` writes a single root file at **`/llms-full.txt`** that contains **every generated markdown docs page** concatenated together. Key characteristics:

- It is a **flat, unsplit file** — groups are *not* used to produce per-group full-context files by default.
- It acts as the **root full-context fallback**: an agent that needs everything in one request can fetch this URL instead of following individual page links.
- Groups still organise `llms.txt`, navigation, search metadata, and `AGENTS.md`; they simply have no effect on the shape of `llms-full.txt`.
- `isAgentReadabilityArtifactPath` recognises `llms-full.txt` as an agent-readability artifact so the build never rewrites it as a missing markdown page.

---

## Two Optional Frontmatter Fields

### 1. `description`
Optional but **recommended**. Becomes the routing hint (the indented line after the page link) in `llms.txt`, helping agents decide which page to fetch without reading the full content.

```yaml
description: "Required fields, group semantics, optional fields, and lint behavior."
```

### 2. `deprecated` / `deprecatedReason`
Mark a page as deprecated. `deprecated: true` flags the page; `deprecatedReason` provides a human-readable explanation that the pipeline can surface in navigation and lint output.

```yaml
deprecated: true
deprecatedReason: "Replaced by the new authoring guide."
```

### Other Notable Optional Fields
The full list from the docs also includes: `icon`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor`. The last two (`lastModified`, `lastAuthor`) are automatically populated when the CLI is run with the `--enrich-git` flag.

---

## Summary

`group` is the primary organisational primitive in Leadtype: it drives sidebar order, structures the agent-facing `llms.txt` map, enriches search metadata, and shapes `AGENTS.md`. However, it deliberately does **not** shard the monolithic `/llms-full.txt`, which always contains every page so that agents can retrieve the entire doc set in a single request.
