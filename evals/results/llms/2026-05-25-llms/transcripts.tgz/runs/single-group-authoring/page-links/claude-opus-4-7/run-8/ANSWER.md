# Frontmatter `group` and Monolithic Output in Leadtype

## How `group` controls navigation

Per [`docs/authoring/frontmatter.md`](/docs/authoring/frontmatter.md), every MDX page carries YAML frontmatter. The `group` field is optional, but when set it must match a slug declared in `docs.config.ts` — declaring an unknown group fails the build.

A single `group` value drives four downstream surfaces at once:

1. **Sidebar position** — where the page appears in site navigation.
2. **`llms.txt` section** — which heading the page is listed under in the routing map.
3. **Search metadata** — how the static search index tags the page.
4. **AGENTS.md grouping** — how pages are bucketed in the npm-bundled agent doc.

A page can belong to more than one group by using array syntax (`group: [a, b]`), in which case it appears under each section in all four surfaces.

## How `group` interacts with the monolithic `/llms-full.txt`

The frontmatter doc and [`docs/reference/llm.md`](/docs/reference/llm.md) make the split-vs-monolithic boundary explicit:

- `generateLLMFullContextFiles` writes **one** root `/llms-full.txt` file that contains **every** generated markdown docs page.
- That root fallback is **not split by group**. Groups still organize `llms.txt` sections, navigation, search metadata, and AGENTS.md, but they are **not** published as per-group full-context files by default.
- The guidance is therefore: "Use groups for routing, not sharding." Group descriptions should read as routing hints, not marketing copy.

In short, `group` is a routing/organization key for the human-facing sidebar, the agent-facing `llms.txt` map, search, and AGENTS.md — while `/llms-full.txt` deliberately ignores grouping and ships the complete corpus as a single fallback bundle.

## Optional frontmatter fields (examples)

Beyond the required `title` (and the recommended `description`, which becomes the routing hint inside `llms.txt`), Leadtype recognizes a number of optional fields, including:

- **`deprecated`** — marks a page as deprecated (commonly paired with `deprecatedReason` to explain the replacement path).
- **`experimental`** — flags content that describes unstable or in-progress functionality.

Other optional fields documented alongside these include `icon`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor`. The last two are populated automatically when the generator is run with `--enrich-git`.
