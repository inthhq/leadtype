# Frontmatter `group` and monolithic output in Leadtype

Sources consulted:
- `/docs/authoring/frontmatter.md`
- `/docs/reference/llm.md`

## What `group` controls

Each MDX page carries YAML frontmatter. `title` is required; `group` is optional and, when set, must match a slug from `docs.config.ts`. If a page declares an unknown group, the build fails.

A page's `group` value drives four things:

1. **Sidebar position** — where the page lands in the navigation tree.
2. **`llms.txt` section** — which heading the page is listed under in the product-level routing map produced by `generateLlmsTxt` (which also writes the docs-scoped `/docs/llms.txt`).
3. **Search metadata** — group is included as facet/metadata for the static search index.
4. **AGENTS.md grouping** — how pages are clustered in the bundle written by `generateAgentsMd`.

A page can belong to multiple groups using list syntax (`group: [a, b]`), which causes it to appear under each.

## How `group` relates to monolithic output (`/llms-full.txt`)

`generateLLMFullContextFiles` writes a single root `/llms-full.txt` containing **every** generated markdown docs page. This monolithic fallback is **not split by group** — groups still organize `llms.txt` sections, sidebar navigation, search metadata, and AGENTS.md, but Leadtype does not, by default, publish per-group full-context files.

The guidance from the LLM files reference is explicit: **use groups for routing, not sharding**, and group descriptions should be routing hints rather than marketing copy. The `description` frontmatter field becomes that routing hint inside `llms.txt`.

`isAgentReadabilityArtifactPath` recognizes `llms.txt`, `llms-full.txt`, sitemap files, `robots.txt`, search JSON, and `agent-readability.json` as artifacts so they aren't rewritten as missing markdown pages.

## Optional frontmatter fields (examples)

Besides the recommended `description`, optional fields include:

- `icon`
- `deprecated`
- `deprecatedReason`
- `experimental`
- `canary`
- `new`
- `draft`
- `tags`
- `availableIn`
- `full`
- `lastModified` — populated when `--enrich-git` is enabled
- `lastAuthor` — populated when `--enrich-git` is enabled

## Summary

`group` is the single knob that routes a page through the sidebar, `llms.txt`, search, and AGENTS.md. The `/llms-full.txt` artifact deliberately ignores groups and emits one monolithic file containing all markdown pages, serving as a full-context fallback for agents.
