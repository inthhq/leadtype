# Frontmatter Group and Monolithic Output

## Summary

The `group` frontmatter field is a key organizational mechanism in Leadtype that controls how documentation pages are structured and presented across different outputs.

### How `group` Controls Navigation

The `group` field drives navigation and organization in multiple ways:
- **Sidebar position**: Determines the order and hierarchy of pages in the documentation site's sidebar
- **llms.txt sections**: Controls how pages are grouped within the `/llms.txt` navigation file
- **Search metadata**: Groups pages for search organization
- **AGENTS.md grouping**: Organizes pages in the agent-readable bundle

Pages can belong to multiple groups by using an array syntax: `group: [a, b]`. The value must match a slug from `docs.config.ts`, and if an unknown group is declared, the build fails.

### Monolithic Output and Groups

The `/llms-full.txt` file is the **root full-context fallback** that contains every generated markdown docs page in a single, monolithic file. Importantly:
- **Not split by group**: Unlike the sectioned `/llms.txt`, the `/llms-full.txt` file is not organized or split by groups
- **Groups still matter**: Groups continue to organize the regular `/llms.txt` sections, navigation, search metadata, and `AGENTS.md`, but they are not published as per-group full-context files by default
- **Complete reference**: The monolithic `/llms-full.txt` provides a complete, all-in-one reference regardless of group membership

### Optional Frontmatter Fields

Two recommended optional frontmatter fields are:

1. **`description`**: Highly recommended because it becomes the routing hint in llms.txt, helping agents and search understand page context

2. **`deprecated`**: Marks a page as deprecated to signal to users and search that the content should not be relied upon

Additional optional fields include: `deprecatedReason`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `icon`, `lastModified`, and `lastAuthor`.
