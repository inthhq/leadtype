# Frontmatter `group` and monolithic output

In Leadtype, each MDX page can define YAML frontmatter. The only required field is `title`; `description` is optional but recommended because it becomes the routing hint shown in `llms.txt`.

The optional `group` field controls where a page is organized across the generated docs experience. Its value should match a group slug from `docs.config.ts`; if a page declares an unknown group, the build fails. A page may also belong to multiple groups by using an array, for example:

```yaml
title: Frontmatter
description: Required fields, group semantics, optional fields, and lint behavior.
group: [authoring, reference]
```

`group` affects:

- sidebar/navigation placement
- which section the page appears under in `llms.txt`
- search metadata
- `AGENTS.md` grouping

However, `group` does **not** shard the monolithic full-context output. Leadtype’s `/llms-full.txt` is a single root file containing every generated markdown docs page. Groups continue to organize navigation, `llms.txt`, search metadata, and `AGENTS.md`, but Leadtype does not publish per-group full-context files by default. In short: use groups for routing and organization, not for splitting `/llms-full.txt`.

Other optional frontmatter fields include `icon`, `deprecated`, `deprecatedReason`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor`. The `lastModified` and `lastAuthor` fields are filled automatically when `--enrich-git` is enabled.
