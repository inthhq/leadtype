# Frontmatter `group` and `/llms-full.txt`

In Leadtype, every MDX docs page has YAML frontmatter. `title` is required, while `description` is optional but recommended because it becomes the routing hint shown in `llms.txt`.

The optional `group` field assigns a page to one or more documentation groups. It should match a slug from `docs.config.ts`; if a page declares an unknown group, the build fails. A page can be in multiple groups with array syntax, for example:

```yaml
group: [authoring, reference]
```

`group` controls several organized outputs:

- sidebar/navigation placement
- the section where the page appears in `llms.txt`
- search metadata
- `AGENTS.md` grouping

However, `group` does **not** shard the monolithic full-context output. `/llms-full.txt` is generated as one root file containing every generated markdown docs page. Groups still organize routing-oriented artifacts such as `llms.txt`, navigation, search metadata, and `AGENTS.md`, but Leadtype does not publish per-group full-context files by default. In short: use groups for routing and organization, not for splitting `/llms-full.txt`.

Optional frontmatter fields include `icon`, `deprecated`, `deprecatedReason`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor`. `lastModified` and `lastAuthor` can be filled in automatically when `--enrich-git` is enabled.
