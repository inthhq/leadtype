# Frontmatter Group and Monolithic Output

## How Frontmatter `group` Controls Navigation

The `group` frontmatter field is a **required-style optional field** (should match a slug from `docs.config.ts`) that serves multiple critical functions:

1. **Sidebar Navigation**: The `group` value drives the sidebar position in the docs website, organizing pages into logical sections
2. **llms.txt Sections**: Pages are grouped and organized into distinct sections within the `/llms.txt` file based on their group assignment
3. **Search Metadata**: Groups provide metadata context for the search index
4. **AGENTS.md Grouping**: Pages are grouped together in the `AGENTS.md` bundle file
5. **Multi-group Support**: Pages can belong to multiple groups using array syntax: `group: [a, b]`

## Monolithic Output (`/llms-full.txt`)

The `/llms-full.txt` file is a **root-level, monolithic full-context file** that contains every generated markdown docs page. Key characteristics:

- **Not split by group**: While groups organize `llms.txt` sections, navigation, search metadata, and `AGENTS.md`, they are **not published as per-group full-context files** by default
- **Complete fallback**: The root `/llms-full.txt` serves as a complete fallback containing all generated markdown content
- **Generated via `generateLLMFullContextFiles()`**: This function writes the comprehensive single-file version of all docs

## Two Optional Frontmatter Fields

1. **`deprecated`** (boolean): Marks a page as deprecated, typically used alongside `deprecatedReason` to indicate the page is outdated or no longer maintained

2. **`experimental`** (boolean): Marks a page as experimental, indicating the feature or documentation is still under development and subject to change

Additional optional fields available include: `icon`, `deprecatedReason`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor`.
