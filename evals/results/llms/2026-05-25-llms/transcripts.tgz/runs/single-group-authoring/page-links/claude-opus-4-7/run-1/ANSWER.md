# Frontmatter `group` and monolithic output in Leadtype

## What `group` does

Each MDX page has YAML frontmatter. The `title` field is required, `description` is optional but recommended (it becomes the routing hint in `llms.txt`), and `group` is optional but must match a slug declared in `docs.config.ts`. If a page declares an unknown `group`, the build fails.

A page's `group` value simultaneously drives four things:

1. **Sidebar position** in the rendered docs site navigation.
2. **`llms.txt` section** — the routing map agents read first.
3. **Search metadata** attached to the page in the static search index.
4. **AGENTS.md grouping** for npm-bundled offline agent docs.

A page can belong to more than one group by using a list: `group: [a, b]`. The guidance from the LLM-files reference is explicit: **use groups for routing, not sharding**, and group descriptions should be routing hints rather than marketing copy.

## How `group` interacts with `/llms-full.txt` (monolithic output)

`generateLLMFullContextFiles` writes a single root `/llms-full.txt` file that contains **every generated markdown docs page**. This monolithic, full-context fallback is deliberately **not split by group**:

- Groups still organize `llms.txt` sections, sidebar navigation, search metadata, and AGENTS.md.
- Groups are **not** published as per-group full-context files by default.

So `group` controls how content is *discovered and routed* (via `llms.txt`, search, and the sidebar), while `/llms-full.txt` exists as a single concatenated fallback for agents that need the entire corpus in one fetch.

## Optional frontmatter fields (examples)

The following frontmatter fields are all optional:

- `icon`
- `deprecated`
- `deprecatedReason`
- `experimental`
- `canary`
- `new`
- `draft`
- `tags`
- `availableIn`
- `full`
- `lastModified` — populated automatically when `--enrich-git` is enabled.
- `lastAuthor` — populated automatically when `--enrich-git` is enabled.

Two concrete examples requested:

- **`deprecated`** — marks a page as deprecated (typically paired with `deprecatedReason` to explain why and point to a replacement).
- **`tags`** — supplies additional metadata used for cross-cutting categorization beyond the single `group` slug.

## Sources

- `/docs/authoring/frontmatter.md` — required vs. optional fields, group semantics, multi-group lists, and the unknown-group build failure.
- `/docs/reference/llm.md` — behavior of `generateLlmsTxt` and `generateLLMFullContextFiles`, and the rule that `/llms-full.txt` is not split by group.
