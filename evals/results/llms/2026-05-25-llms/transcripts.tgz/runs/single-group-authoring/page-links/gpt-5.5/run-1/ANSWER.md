# Frontmatter `group` and monolithic LLM output

In Leadtype, each MDX page has YAML frontmatter. `title` is required, while `group` is optional. When present, `group` should match a slug defined in `docs.config.ts`; an unknown group causes the build to fail.

`group` is used for organization and routing:

- It determines the page's sidebar position.
- It places the page into the appropriate section of `/llms.txt`.
- It contributes search metadata.
- It controls grouping in generated `AGENTS.md`.
- A page can appear in multiple groups with syntax like `group: [a, b]`.

`group` does **not** shard the monolithic LLM context output. Leadtype's `/llms-full.txt` is a single root fallback file that contains every generated markdown docs page. Groups may organize navigation, `/llms.txt`, search metadata, and `AGENTS.md`, but Leadtype does not publish separate per-group full-context files by default. In short: use groups for routing and navigation, not for splitting `/llms-full.txt`.

Optional frontmatter fields include `description`, `icon`, `deprecated`, `deprecatedReason`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor`. `description` is especially recommended because it becomes the routing hint in `/llms.txt`; `lastModified` and `lastAuthor` are filled in when `--enrich-git` is enabled.