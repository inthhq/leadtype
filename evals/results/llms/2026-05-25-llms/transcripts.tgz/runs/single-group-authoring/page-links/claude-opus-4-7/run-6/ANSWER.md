# Frontmatter `group` and Monolithic Output in Leadtype

Sources consulted:
- `/docs/authoring/frontmatter.md`
- `/docs/reference/llm.md`

## What `group` controls

Each MDX page in Leadtype carries YAML frontmatter. The `group` field is **optional**, and when present it must match a slug declared in `docs.config.ts`. If a page declares an unknown group, the build fails (so groups act as a closed vocabulary, not free-form tags).

A single `group` value drives four downstream surfaces of the docs pipeline:

1. **Sidebar / navigation position** — the page's location in the docs-site nav comes from its group.
2. **`llms.txt` section** — the per-group section a page is listed under in the agent-readable map.
3. **Search metadata** — group is attached to the static search index entries.
4. **AGENTS.md grouping** — the npm-bundled agent guide groups pages by the same slug.

A page may belong to more than one group by using an array, e.g. `group: [a, b]`.

> Guidance from `/docs/reference/llm.md`: *"Use groups for routing, not sharding. Group descriptions should be routing hints, not marketing copy."*

## How `group` relates to monolithic output (`/llms-full.txt`)

The root **`/llms-full.txt`** is the full-context fallback bundle. It is produced by `generateLLMFullContextFiles`, which writes a single root file containing **every generated markdown docs page**.

Key point: **`/llms-full.txt` is NOT split by group.**

- Groups continue to organize `llms.txt` sections, sidebar navigation, search metadata, and AGENTS.md.
- Groups are **not** published as per-group full-context files by default.

So `group` is a routing/organization signal for the curated surfaces, while `/llms-full.txt` is the monolithic "everything" bundle for agents that want the whole corpus in one fetch.

## Optional frontmatter fields (examples)

In addition to `group`, the frontmatter schema accepts several optional fields. From `/docs/authoring/frontmatter.md`, these include:

- **`description`** — optional but recommended; it becomes the routing hint shown in `llms.txt`.
- **`deprecated`** — flags a page as deprecated (typically paired with `deprecatedReason`).
- Others available: `icon`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor`. The last two are populated automatically when the CLI is run with `--enrich-git`.

Only `title` is required; `description` and `group` are the two most consequential optional fields because they directly shape how agents discover and route to the page.
