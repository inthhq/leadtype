# Frontmatter Group and Monolithic Output

## Group Control

The frontmatter `group` field is an optional parameter that must match a slug from `docs.config.ts`. The group value is the primary driver for multiple navigation and organizational features:

- **Sidebar Position**: Determines where a page appears in the sidebar navigation
- **Section Organization in llms.txt**: Controls how pages are grouped and organized in the `/llms.txt` routing file
- **Search Metadata**: Groups pages for search indexing and filtering purposes
- **AGENTS.md Grouping**: Organizes pages within the AGENTS.md bundle for npm-packaged docs

Pages can belong to multiple groups using array syntax (`group: [a, b]`), allowing flexible categorization. If a page declares an unknown group, the build fails.

## Monolithic Output

The `/llms-full.txt` fallback file is a root-level, monolithic output that contains **all generated markdown pages**. Unlike the segmented `/llms.txt` which is organized by groups, the full-context file is **not split by group**. This ensures a complete, unfiltered reference document for agents that need comprehensive context.

Importantly, groups still control routing, navigation, search metadata, and AGENTS.md organization even though the monolithic output ignores group boundaries. Groups are designed for routing and organizational purposes, not for sharding the full-context file.

## Optional Frontmatter Fields

Two key optional frontmatter fields are:

1. **`description`**: Recommended field that becomes the routing hint in llms.txt, helping agents understand the page's purpose and content

2. **`deprecated`**: Indicates a page is deprecated, with an optional companion field `deprecatedReason` that explains why the page is no longer current or recommended

Other optional fields include: `icon`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor` (the latter two populated when `--enrich-git` is enabled).
