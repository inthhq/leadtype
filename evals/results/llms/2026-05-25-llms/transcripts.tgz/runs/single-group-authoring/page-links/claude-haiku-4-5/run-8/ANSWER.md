# Frontmatter `group` and Monolithic Output in Leadtype

## How Frontmatter `group` Controls Navigation

The `group` frontmatter field is a required mapping to a slug from `docs.config.ts` that serves multiple critical functions in the Leadtype docs pipeline:

1. **Sidebar Navigation**: The group value drives the sidebar position in the website navigation, organizing pages hierarchically based on their assigned groups.

2. **LLM Bundles**: Groups organize the `/llms.txt` sections, which is the main entry point for HTTP agents navigating the documentation.

3. **Search Metadata**: Group assignments populate search index metadata, allowing agents to understand which section of the docs a page belongs to.

4. **AGENTS.md Grouping**: Groups organize content in `AGENTS.md`, the entry point for agents working with npm-bundled offline documentation.

5. **Flexible Assignment**: Pages can belong to multiple groups using `group: [a, b]`, providing flexibility in how content is organized across different navigation contexts.

If a page declares an unknown group, the build fails, ensuring all groups are properly configured in the documentation's configuration file.

## Monolithic Output (`/llms-full.txt`)

The root `/llms-full.txt` file serves as a comprehensive fallback containing **every generated markdown page from the documentation**. Unlike the group-organized `/llms.txt` files, the monolithic output **is not split by group**—it presents all documentation content in a single, unified file.

As documented in the LLM files reference: "Groups still organize llms.txt sections, navigation, search metadata, and AGENTS.md; they are not published as per-group full-context files by default." This means while groups control how content is segmented across various outputs, the monolithic `/llms-full.txt` maintains a complete, ungrouped representation of all documentation.

## Two Optional Frontmatter Fields

### 1. **`description`**
Although technically optional, `description` is recommended because it becomes the routing hint in `llms.txt`. This field helps agents understand the page's purpose and content at a glance.

### 2. **`deprecated`** (with associated `deprecatedReason`)
This boolean field marks pages as deprecated, allowing the documentation system to flag outdated content. The complementary `deprecatedReason` field provides context about why the page or feature is deprecated and what alternatives exist.

Other optional fields include: `icon`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor` (the latter two populated when `--enrich-git` is enabled).
