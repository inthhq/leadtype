# Frontmatter `group` and Monolithic Output in Leadtype

## How `group` Controls Navigation

The `group` frontmatter field is **optional** but plays a central role in organizing the generated site. According to the Leadtype docs:

- **`group` must match a slug** defined in `docs.config.ts`. If a page declares an **unknown group**, the **build fails**.
- A single page can belong to **multiple groups** by supplying an array:
  ```yaml
  group: [a, b]
  ```
- The `group` value simultaneously drives:
  1. **Sidebar position** — pages are ordered and nested under their group in the navigation.
  2. **`llms.txt` sections** — each group becomes a named section in the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` map.
  3. **Search metadata** — the group tag is attached to search index entries for filtering/ranking.
  4. **`AGENTS.md` grouping** — pages are clustered under their group when `AGENTS.md` is written for npm-bundled docs.

> **Key authoring tip (from the reference docs):** _Use groups for routing, not sharding._ Group descriptions should be routing hints, not marketing copy.

---

## Monolithic Output: `/llms-full.txt`

`/llms-full.txt` is written by `generateLLMFullContextFiles`. It is a **single, root-level file** that contains **every generated markdown docs page** concatenated together.

- It is **not split by group** — all pages appear in one flat bundle regardless of group membership.
- Groups still organize `llms.txt`, navigation, search metadata, and `AGENTS.md`, but they produce **no per-group full-context files** by default.
- The path `llms-full.txt` is recognized by `isAgentReadabilityArtifactPath`, which ensures it is **not rewritten as a missing markdown page** during site builds.

This makes `/llms-full.txt` a reliable full-context fallback for agents that need the entire documentation corpus in a single fetch.

---

## Two Optional Frontmatter Fields

Beyond `group`, the frontmatter spec lists many optional fields. Two notable examples:

| Field | Purpose |
|---|---|
| **`description`** | Optional but recommended. Becomes the **routing hint** shown next to the page link in `llms.txt`, helping agents decide which page to read. |
| **`deprecated`** / **`deprecatedReason`** | Marks a page as deprecated. `deprecatedReason` provides a human-readable explanation of the deprecation (e.g., pointing to the replacement page). |

Other available optional fields include: `icon`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor` (the last two are auto-populated when `--enrich-git` is enabled on the CLI).

---

## Summary

| Concern | Mechanism |
|---|---|
| Navigation order & sidebar | `group` slug matched to `docs.config.ts` |
| `llms.txt` sectioning | Driven by `group` |
| Agent full-corpus access | `/llms-full.txt` (all pages, no group sharding) |
| Build guard | Unknown `group` value → build failure |
| Routing hints for agents | `description` optional field |
| Deprecation signalling | `deprecated` + `deprecatedReason` optional fields |
