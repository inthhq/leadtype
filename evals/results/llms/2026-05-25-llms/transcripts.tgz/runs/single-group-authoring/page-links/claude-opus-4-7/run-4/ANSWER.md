# Frontmatter `group` and Monolithic Output

Sources consulted:
- `/docs/authoring/frontmatter.md`
- `/docs/reference/llm.md`

## What `group` does

Each MDX page carries YAML frontmatter. `title` is required, `description` is optional but recommended (it becomes the routing hint in `llms.txt`), and `group` is optional. When provided, the `group` value must match a slug declared in `docs.config.ts` — if a page declares an unknown group, the build fails.

A single `group` value drives four downstream artifacts at once:

1. **Sidebar position** — the page's location in site navigation.
2. **`llms.txt` section** — the section under which the page is listed in the routing map.
3. **Search metadata** — how the page is tagged in the static search index.
4. **AGENTS.md grouping** — how the page is organized in the npm-bundled agent guide.

A page can belong to multiple groups by using array syntax, e.g. `group: [a, b]`.

## Relationship to `/llms-full.txt` (the monolithic output)

`generateLLMFullContextFiles` writes a single root `/llms-full.txt` file that contains **every** generated markdown docs page. Key points from the docs:

- The root `/llms-full.txt` fallback is **not split by group**. It is one monolithic, full-context file.
- Groups still organize `llms.txt` sections, navigation, search metadata, and AGENTS.md — but they are **not published as per-group full-context files by default**.
- Guidance from the LLM files reference: *"Use groups for routing, not sharding. Group descriptions should be routing hints, not marketing copy."*

In short: `group` controls *routing and discovery surfaces* (sidebar, `llms.txt` map, search facets, AGENTS.md sections), while the monolithic `/llms-full.txt` ignores groups and ships the entire corpus as a single fallback bundle.

## Optional frontmatter fields (examples)

The frontmatter reference lists these optional fields: `icon`, `deprecated`, `deprecatedReason`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor`.

Two examples:

- **`deprecated`** — marks the page as deprecated (often paired with `deprecatedReason` to explain why).
- **`lastModified`** — a git-derived timestamp that is populated automatically when the `--enrich-git` CLI flag is enabled (as is `lastAuthor`).
