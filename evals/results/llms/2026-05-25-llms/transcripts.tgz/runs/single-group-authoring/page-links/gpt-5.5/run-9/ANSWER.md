# Frontmatter `group` and `/llms-full.txt`

In Leadtype, each MDX page uses YAML frontmatter. The required field is `title`; `group` is optional but should match a group slug defined in `docs.config.ts`.

`group` controls organization and routing:

- It drives the page’s sidebar/navigation position.
- It determines which section the page appears under in `llms.txt`.
- It is included in search metadata.
- It is also used for `AGENTS.md` grouping in bundled package docs.
- A page can belong to multiple groups with syntax such as `group: [a, b]`.
- If a page declares an unknown group, the build fails.

For monolithic output, groups do **not** shard the full-context artifact. Leadtype writes a single root `/llms-full.txt` containing every generated markdown docs page. Groups still organize navigation, `llms.txt`, search metadata, and `AGENTS.md`, but Leadtype does not publish per-group full-context files by default. In short: use groups for routing and organization, not for splitting `/llms-full.txt`.

Optional frontmatter fields include `description`, `icon`, `deprecated`, `deprecatedReason`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor`. For example, `description` is recommended because it becomes the routing hint in `llms.txt`, while `lastModified` and `lastAuthor` can be filled when `--enrich-git` is enabled.
