# Frontmatter `group` and Monolithic Output in Leadtype

This summary is grounded in the Leadtype docs at `/docs/authoring/frontmatter.md` and `/docs/reference/llm.md`.

## What `group` does

`group` is an **optional** frontmatter field whose value should match a slug declared in `docs.config.ts`. If a page declares an unknown `group`, the build fails. A page may belong to multiple groups via list syntax (`group: [a, b]`).

A single `group` value drives four navigation/discovery surfaces:

1. **Sidebar position** on the hosted docs site.
2. **`llms.txt` section** — pages are organized into sections by group, so `group` controls which heading a page appears under in `/llms.txt` and `/docs/llms.txt` (written by `generateLlmsTxt`).
3. **Search metadata** — the static search index carries group info.
4. **AGENTS.md grouping** — when `generateAgentsMd` writes AGENTS.md for npm-bundled docs, pages are grouped accordingly.

The docs guidance is explicit: **use groups for routing, not sharding**, and group descriptions should read as routing hints (not marketing copy).

## How `group` interacts with monolithic output (`/llms-full.txt`)

`generateLLMFullContextFiles` writes a **single root `/llms-full.txt`** that contains every generated markdown docs page. Key points:

- **`/llms-full.txt` is not split by group.** It is the root full-context fallback containing all pages.
- Groups still organize `llms.txt` sections, sidebar nav, search metadata, and AGENTS.md — but **not** per-group monolithic files.
- Per-group full-context files are **not published by default**.
- `isAgentReadabilityArtifactPath` recognizes `llms-full.txt` (along with `llms.txt`, sitemap files, `robots.txt`, search JSON, and `agent-readability.json`) so these artifact paths are not rewritten as missing markdown pages.

In short: `group` shapes *navigation and routing* across multiple surfaces, while `/llms-full.txt` deliberately ignores groups and serves as the unsharded full-context fallback.

## Required vs. optional frontmatter

- **Required:** `title`.
- **Recommended:** `description` (it becomes the routing hint in `llms.txt`).
- **Optional fields include:** `group`, `icon`, `deprecated`, `deprecatedReason`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor`. (`lastModified` and `lastAuthor` are populated when `--enrich-git` is enabled.)

### Two optional fields highlighted

- **`tags`** — optional metadata used alongside group for search/discovery.
- **`deprecated`** (paired with `deprecatedReason`) — marks a page as deprecated, with an accompanying reason string.

(Additional examples from the optional list: `experimental`, `canary`, `new`, `draft`, `icon`, `availableIn`, `full`, `lastModified`, `lastAuthor`.)
