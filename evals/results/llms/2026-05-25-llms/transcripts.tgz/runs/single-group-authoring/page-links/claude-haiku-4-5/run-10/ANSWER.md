# Frontmatter Group and Monolithic Output

## How Frontmatter `group` Controls Navigation

The `group` field in frontmatter is a critical organizational mechanism in Leadtype that controls multiple aspects of site structure:

1. **Sidebar Position**: The `group` value drives where pages appear in the sidebar navigation
2. **llms.txt Sections**: Pages are organized into sections within the `/llms.txt` file based on their group
3. **Search Metadata**: Group information is used to categorize and organize search results
4. **AGENTS.md Grouping**: Pages are grouped together in the offline AGENTS.md bundle for npm-packaged documentation

Pages can optionally belong to multiple groups by using the syntax `group: [a, b]`, allowing flexible categorization across different organizational contexts. The group value should match a slug from `docs.config.ts`, and if an unknown group is declared, the build fails.

## Monolithic Output and `/llms-full.txt`

The monolithic output is handled by `generateLLMFullContextFiles`, which writes a root `/llms-full.txt` file containing every generated markdown docs page in a single, unified file. This serves as a complete fallback context for LLM agents.

**Critical distinction**: While `group` organizes pages in `/llms.txt` sections, `/llms-full.txt` is **not split by group**. All pages appear in a single monolithic bundle. Groups continue to organize:
- llms.txt sections
- Navigation/sidebar
- Search metadata
- AGENTS.md grouping

But they are not published as per-group full-context files by default. This design allows groups to serve as routing hints rather than sharding mechanisms.

## Optional Frontmatter Fields

Leadtype supports several optional frontmatter fields beyond `title`, `description`, and `group`:

1. **`deprecated`** and **`deprecatedReason`**: Marks a page as deprecated with an optional explanation for why it's no longer recommended. This helps agents understand outdated content and why users should avoid it.

2. **`experimental`**: Marks a page as experimental or work-in-progress, indicating that the content may change or not be stable for production use.

3. **`tags`**: Allows custom tagging for organizational and search purposes.

4. **`lastModified`** and **`lastAuthor`**: Automatically populated when `--enrich-git` is enabled, tracking documentation maintenance history.

5. **`new`**, **`canary`**, **`draft`**: Status indicators for new, pre-release, or draft content.

6. **`availableIn`**: Specifies version or feature availability constraints.

7. **`full`**: Controls whether the page is included in full-context bundles.

8. **`icon`**: Associates a visual icon with the page for UI purposes.

These optional fields provide rich metadata to support navigation, search, versioning, and deprecation workflows in agent-readable documentation.
