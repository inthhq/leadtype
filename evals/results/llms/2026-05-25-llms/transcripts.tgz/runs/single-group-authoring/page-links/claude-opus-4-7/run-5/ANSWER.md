# Frontmatter `group` and monolithic output (`/llms-full.txt`)

Sources: [`/docs/authoring/frontmatter.md`](/docs/authoring/frontmatter.md), [`/docs/reference/llm.md`](/docs/reference/llm.md).

## What `group` does

Every MDX page has YAML frontmatter. `title` is required; `description` is optional but recommended because it becomes the routing hint in `llms.txt`. `group` is optional, and when present it must match a slug from `docs.config.ts` — if a page declares an unknown group, the build fails.

A single `group` value drives four things at once:

1. **Sidebar position** (navigation order on the docs site).
2. **`llms.txt` section** — pages are listed under their group's heading in the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` map (written by `generateLlmsTxt`).
3. **Search metadata** attached to the static search index.
4. **AGENTS.md grouping** for npm-bundled docs (written by `generateAgentsMd`).

A page can belong to multiple groups via `group: [a, b]`, and the same routing/sidebar/search/AGENTS effects apply for each group it appears in.

## How `group` interacts with `/llms-full.txt`

`generateLLMFullContextFiles` writes **one** root `/llms-full.txt` containing every generated markdown docs page. Key points:

- The monolithic file is **not split by group** — it is the root full-context fallback that bundles all pages together.
- Groups still organize `llms.txt` sections, navigation, search metadata, and AGENTS.md, but they are **not published as per-group full-context files by default**.
- The guidance in the LLM-files reference is explicit: "Use groups for routing, not sharding." Group descriptions should be routing hints, not marketing copy.
- `isAgentReadabilityArtifactPath` recognizes `llms-full.txt` (along with `llms.txt`, sitemaps, `robots.txt`, search JSON, and `agent-readability.json`) so the build does not treat it as a missing markdown page.

In short: `group` shapes **how agents and humans navigate** to the right page (via `llms.txt`, sidebar, search, AGENTS.md), while `/llms-full.txt` is the **ungrouped, monolithic fallback** that contains everything.

## Optional frontmatter fields (examples)

The frontmatter reference lists these optional fields: `icon`, `deprecated`, `deprecatedReason`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor`. Two examples:

- **`deprecated`** — marks a page as deprecated (typically paired with `deprecatedReason` to explain why or point at a replacement).
- **`tags`** — additional classification surfaced to search metadata alongside the page's group.

Note: `lastModified` and `lastAuthor` are only filled in when the generator is run with `--enrich-git` enabled.
