# Frontmatter `group` and Monolithic Output in Leadtype

## How Frontmatter `group` Controls Navigation

The `group` field in page-level YAML frontmatter is **optional**, but it is the primary mechanism Leadtype uses to organise pages across multiple surfaces:

| Surface | Effect of `group` |
|---|---|
| **Sidebar** | Drives the sidebar position of the page in the docs site. |
| **`llms.txt` sections** | Pages with the same group are clustered together as a named section in the generated `/llms.txt` index. |
| **Search metadata** | Group membership is embedded in the search index so results can be scoped to a section. |
| **`AGENTS.md` grouping** | Pages are gathered into their group sections when `AGENTS.md` is written for npm-bundled docs. |

### Matching a valid group slug

The `group` value **must match a slug defined in `docs.config.ts`**. If a page declares an unknown group the build fails—enforced at lint time by `leadtype lint`.

### Multi-group membership

A page may belong to more than one group by supplying an array:

```yaml
group: [a, b]
```

This lets a single page appear in multiple navigation sections, `llms.txt` sections, and `AGENTS.md` groups simultaneously.

---

## Monolithic Output: `/llms-full.txt`

`generateLLMFullContextFiles` writes a **single root `/llms-full.txt`** file that contains **every generated markdown docs page**—regardless of group membership.

Key characteristics:

- **Not split by group.** Even though groups organise `llms.txt` sections, navigation, search metadata, and `AGENTS.md`, they do **not** produce per-group full-context files by default.
- **Full-context fallback.** `/llms-full.txt` is the root fallback for agents or tools that need the entire docs corpus in one request.
- **Complements `llms.txt`.** Where `/llms.txt` (and `/docs/llms.txt`) are structured maps with routing hints, `/llms-full.txt` is the raw, concatenated content of all pages for deep reading.

The CLI flag `--json` causes `leadtype generate` to print a JSON object that includes the `llmsFullTxt` path alongside `llmsTxt`, `docsLlmsTxt`, and other artifacts, making it easy to locate the file in automated pipelines.

---

## Two Optional Frontmatter Fields

Beyond `group`, pages support many optional fields. Two notable examples:

### 1. `description`
Recommended even though it is optional. The `description` value becomes the **routing hint** printed next to each page link in `/llms.txt`. Good descriptions are concise routing phrases (e.g., "Required fields, group semantics, optional fields, and lint behavior"), not marketing copy, so agents know whether to follow the link.

### 2. `deprecated` / `deprecatedReason`
Setting `deprecated: true` flags a page as deprecated; `deprecatedReason` supplies a human-readable explanation. These are surfaced in lint output and can be used by the docs app to display a deprecation banner—without removing the page from the build or breaking existing links.

Other available optional fields include: `icon`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor` (the last two are populated automatically when `--enrich-git` is passed to `leadtype generate`).

---

## Summary

`group` is the single key that ties a page into sidebar order, `llms.txt` structure, search scoping, and `AGENTS.md` layout. The monolithic `/llms-full.txt` deliberately ignores group boundaries and concatenates every page into one file, giving agents a complete, unsharded view of the docs corpus when needed. Optional fields like `description` (routing hint) and `deprecated`/`deprecatedReason` (lifecycle signalling) extend per-page metadata without affecting group logic.
