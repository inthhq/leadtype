# Frontmatter `group` and `/llms-full.txt`

In Leadtype, each MDX page has YAML frontmatter. `title` is required, while `group` is optional but should match a group slug from `docs.config.ts`.

`group` is used for organization and routing:

- It controls where the page appears in the sidebar/navigation.
- It determines which section the page appears under in `llms.txt`.
- It is included in search metadata.
- It controls grouping in generated `AGENTS.md` for package docs.
- A page can belong to multiple groups with `group: [a, b]`.
- If a page declares an unknown group, the build fails.

For monolithic output, `group` does **not** shard or split the full-context file. Leadtype writes a single root `/llms-full.txt` containing every generated markdown docs page. Groups still organize navigation, `llms.txt`, search metadata, and `AGENTS.md`, but Leadtype does not publish per-group full-context files by default. In other words, use groups for routing and organization, not for splitting `/llms-full.txt`.

Optional frontmatter fields include `description`, `icon`, `deprecated`, `deprecatedReason`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor`. `description` is recommended because it becomes the routing hint in `llms.txt`; `lastModified` and `lastAuthor` are filled in when `--enrich-git` is enabled.