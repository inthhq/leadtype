# Frontmatter `group` and `/llms-full.txt`

In Leadtype, every MDX page has YAML frontmatter. `title` is required, while `group` is optional but should match a group slug defined in `docs.config.ts`.

The `group` field is a navigation and routing signal:

- It determines where the page appears in the sidebar.
- It controls which section of `llms.txt` the page is listed under.
- It contributes to search metadata.
- It controls grouping in generated `AGENTS.md` package docs.
- A page can appear in multiple groups with array syntax, for example `group: [a, b]`.
- If a page declares an unknown group, the build fails.

`group` does **not** shard or split the monolithic full-context output. Leadtype generates one root `/llms-full.txt` file containing every generated markdown docs page. Groups still organize navigation, `llms.txt`, search metadata, and `AGENTS.md`, but Leadtype does not publish per-group full-context files by default. In short: use groups for routing and organization, not for splitting `/llms-full.txt`.

Optional frontmatter fields include `description`, `icon`, `deprecated`, `deprecatedReason`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor`. `description` is recommended because it becomes the routing hint in `llms.txt`; `lastModified` and `lastAuthor` can be filled automatically when `--enrich-git` is enabled.
