# Frontmatter `group` and `/llms-full.txt`

In Leadtype, each MDX page can declare YAML frontmatter. `title` is required, while `group` is optional. When used, `group` should match a group slug defined in `docs.config.ts`; an unknown group fails the build.

`group` is primarily a routing and organization signal. It controls:

- the page’s sidebar/navigation position,
- which section the page appears under in `/llms.txt`,
- search metadata,
- grouping in generated `AGENTS.md` package docs.

A page can belong to more than one group by using an array, for example `group: [a, b]`.

`group` does **not** shard the monolithic full-context output. Leadtype’s full-context generator writes a single root `/llms-full.txt` file containing every generated markdown docs page. Groups may still organize navigation, `/llms.txt`, search metadata, and `AGENTS.md`, but Leadtype does not publish per-group full-context files by default. In short: use groups for routing and organization, not for splitting `/llms-full.txt`.

Optional frontmatter fields include `description`, `icon`, `deprecated`, `deprecatedReason`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor`. `description` is recommended because it becomes the routing hint in `/llms.txt`; `lastModified` and `lastAuthor` can be filled automatically when `--enrich-git` is enabled.
