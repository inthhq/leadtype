# Frontmatter `group` and `/llms-full.txt`

In Leadtype, every MDX page has YAML frontmatter. `title` is required, while `group` is optional. When used, `group` should match a slug defined in `docs.config.ts`; an unknown group causes the build to fail.

`group` is used for organization and routing metadata. It controls:

- the page’s sidebar position/navigation grouping
- the section where the page appears in `llms.txt`
- search metadata
- grouping in generated `AGENTS.md`

A page can belong to more than one group by using an array, for example `group: [a, b]`.

`group` does **not** shard the monolithic LLM output. `/llms-full.txt` is a single root fallback file containing every generated markdown docs page. Leadtype does not publish separate per-group full-context files by default, so groups should be treated as routing and navigation hints rather than full-context bundle partitions.

Optional frontmatter fields include `description`, `icon`, `deprecated`, `deprecatedReason`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor`. `description` is recommended because it becomes the routing hint in `llms.txt`; `lastModified` and `lastAuthor` are populated when `--enrich-git` is enabled.
