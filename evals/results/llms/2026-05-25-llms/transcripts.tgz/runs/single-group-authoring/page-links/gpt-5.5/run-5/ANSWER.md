# Frontmatter `group` and `/llms-full.txt`

In Leadtype, each MDX page has YAML frontmatter. The only required field is `title`; `group` is optional, but when used it should match a group slug from `docs.config.ts`. A page can also belong to more than one group with array syntax, for example `group: [a, b]`.

The `group` value is used for navigation and routing-related organization. It drives:

- the page's sidebar position,
- the section where the page appears in `llms.txt`,
- search metadata,
- grouping in generated `AGENTS.md`.

If a page declares an unknown group, the build fails.

`group` does **not** shard the full LLM context output. Leadtype's `generateLLMFullContextFiles` writes a single root `/llms-full.txt` file containing every generated markdown docs page. Groups still organize `llms.txt`, navigation, search metadata, and `AGENTS.md`, but they are not published as separate per-group full-context files by default. In short: use groups for routing and organization, not for splitting `/llms-full.txt`.

Optional frontmatter fields include `description`, `icon`, `tags`, `deprecated`, `deprecatedReason`, `experimental`, `canary`, `new`, `draft`, `availableIn`, `full`, `lastModified`, and `lastAuthor`. `description` is recommended because it becomes the routing hint in `llms.txt`; `lastModified` and `lastAuthor` are populated when `--enrich-git` is enabled.
