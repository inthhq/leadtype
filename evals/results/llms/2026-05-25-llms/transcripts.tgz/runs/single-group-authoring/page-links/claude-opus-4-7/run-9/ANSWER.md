# Frontmatter `group` and Monolithic Output in Leadtype

Sources: [/docs/authoring/frontmatter.md](docs/authoring/frontmatter.md), [/docs/reference/llm.md](docs/reference/llm.md)

## What `group` does

`group` is an **optional** frontmatter field on each MDX page. Its value should match a slug declared in `docs.config.ts`. A page may belong to a single group or to multiple groups via list syntax (`group: [a, b]`). If a page declares an unknown group, the build fails.

The `group` value is the single piece of metadata that drives several navigation and discovery surfaces at once:

- **Sidebar position** on the hosted docs site.
- **Section grouping in `/llms.txt`**, the small routing map agents read first.
- **Search metadata**, so result facets/filters reflect grouping.
- **AGENTS.md grouping** for the npm-bundled docs case.

In other words, `group` is for *routing* — it tells humans, agents, and search where a page lives. The Leadtype reference guidance is explicit: "Use groups for routing, not sharding. Group descriptions should be routing hints, not marketing copy."

## How `group` interacts with the monolithic `/llms-full.txt`

`generateLLMFullContextFiles` writes a **single** root file, `/llms-full.txt`, that contains every generated markdown docs page concatenated together. Key points:

- The root `/llms-full.txt` fallback is **not split by `group`** — it is one monolithic full-context file covering all pages.
- Groups still organize `llms.txt` sections, sidebar navigation, search metadata, and AGENTS.md, but Leadtype does **not** publish per-group full-context files by default.
- `isAgentReadabilityArtifactPath` recognizes `llms-full.txt` (along with `llms.txt`, sitemaps, `robots.txt`, the search JSON, and `agent-readability.json`) so these artifacts are not mistaken for missing markdown pages.

So `group` shapes how content is *indexed and navigated*, while `/llms-full.txt` is the group-agnostic fallback bundle for agents that want everything in one fetch.

## Required vs. optional frontmatter fields

- **Required:** `title`.
- **Recommended:** `description` — optional, but it becomes the routing hint shown in `/llms.txt`.
- **Optional (examples — at least two):**
  - `icon` — visual marker for the page in navigation.
  - `deprecated` — flags the page as deprecated (often paired with `deprecatedReason`).
  - Other optional fields include `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor`. The last two are populated automatically when the generator is run with `--enrich-git`.

## Summary

`group` is the routing knob: it controls sidebar order, `/llms.txt` sectioning, search metadata, and AGENTS.md grouping, and it must reference a slug from `docs.config.ts`. The monolithic `/llms-full.txt` ignores groups entirely and ships every generated markdown page as one fallback bundle for agents.
