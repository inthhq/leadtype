# Frontmatter `group` and Monolithic Output in Leadtype

Sources: [/docs/authoring/frontmatter.md](docs/authoring/frontmatter.md), [/docs/reference/llm.md](docs/reference/llm.md)

## What `group` controls

Each MDX page in Leadtype has YAML frontmatter. The `group` field is **optional**, but when set it must match a slug defined in `docs.config.ts` — if a page declares an unknown group, the build fails.

When present, a single `group` value drives several downstream artifacts at once:

- **Sidebar position** — determines where the page lives in the navigation.
- **`llms.txt` section** — groups become the section headings in the routing map.
- **Search metadata** — group is attached to the page in the static search index.
- **AGENTS.md grouping** — controls how pages are clustered in the bundled agent file.

A page can belong to more than one group by using a list, e.g. `group: [a, b]`, in which case it appears under each group in the surfaces above.

## How `group` relates to `/llms-full.txt` (the monolithic output)

`generateLLMFullContextFiles` writes a **single root `/llms-full.txt`** that contains every generated markdown docs page. Key points:

- The root `/llms-full.txt` fallback is **not split by group** — it is one monolithic file containing all pages.
- Groups continue to organize `llms.txt` sections, sidebar navigation, search metadata, and AGENTS.md.
- Groups are **not** published as per-group full-context files by default.

The guidance from the LLM reference is explicit: *"Use groups for routing, not sharding. Group descriptions should be routing hints, not marketing copy."* In other words, `group` is a routing/organization signal for the per-page map (`llms.txt`) and navigation, while `/llms-full.txt` is the ungrouped, complete fallback bundle.

## Optional frontmatter fields (examples)

Beyond `group`, Leadtype frontmatter accepts many optional fields. At least two of them:

- **`description`** — optional but recommended, because it becomes the routing hint shown in `llms.txt`.
- **`deprecated`** (with companion **`deprecatedReason`**) — flags a page as deprecated and supplies the reason.

Other optional fields documented in `frontmatter.md`: `icon`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor`. The last two (`lastModified`, `lastAuthor`) are populated automatically when the generator is run with `--enrich-git`.

## Summary

- `title` is the only required frontmatter field; `group` is optional but must be a known slug.
- `group` fans out to sidebar, `llms.txt` sections, search, and AGENTS.md.
- `/llms-full.txt` is a single, group-agnostic monolithic bundle of every page — groups organize routing, not sharding.
- Recommended/illustrative optional fields include `description` and `deprecated` (plus `deprecatedReason`, `tags`, `experimental`, etc.).
