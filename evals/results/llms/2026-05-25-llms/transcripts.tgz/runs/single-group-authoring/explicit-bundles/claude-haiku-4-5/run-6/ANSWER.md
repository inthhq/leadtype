# Frontmatter Group and Monolithic Output in Leadtype

## How Frontmatter `group` Controls Navigation

The `group` frontmatter field is a key organizational tool in Leadtype that drives multiple aspects of the documentation system:

1. **Sidebar Position**: The group value determines where a page appears in the sidebar navigation of the docs site.

2. **llms.txt Section Organization**: Groups organize how content is presented in the `/llms.txt` routing map for agents.

3. **Search Metadata**: The group classification becomes part of the search metadata, helping organize search results.

4. **AGENTS.md Grouping**: Groups determine how pages are organized in the generated `AGENTS.md` file for npm-bundled docs.

Pages can belong to multiple groups by using array syntax: `group: [a, b]`. The group value must match a slug from `docs.config.ts`, and if a page declares an unknown group, the build fails.

## Monolithic Output (`/llms-full.txt`)

The `/llms-full.txt` file is the root full-context fallback bundle that contains **every generated markdown docs page** in a single monolithic file. This provides a comprehensive context document for AI agents.

Key points about monolithic output:

- Groups still organize the `/llms.txt` sections, navigation, search metadata, and `AGENTS.md`, but they do **not** create per-group full-context files
- Groups are designed for **routing**, not sharding or splitting the full context
- The monolithic output is not split by group and serves as a complete reference

## Optional Frontmatter Fields

Leadtype includes several optional frontmatter fields beyond `group`:

1. **`icon`**: Specifies an icon to display alongside the page in navigation and listings

2. **`deprecated`**: A boolean field marking a page as deprecated, with an accompanying `deprecatedReason` field that explains why the page is no longer current

3. **`experimental`**: Marks features that are experimental and may change

4. **`tags`**: Allows categorization of pages with searchable tags

5. **`draft`**: Indicates work-in-progress pages that may not be ready for publication

6. **`lastModified`**: Timestamp of when the page was last modified (auto-filled when `--enrich-git` is enabled)

7. **`lastAuthor`**: Name of the last author to modify the page (auto-filled when `--enrich-git` is enabled)

8. **`canary`**, **`new`**, **`availableIn`**, **`full`**: Additional metadata fields for version and feature tracking

These optional fields enhance documentation metadata without being required, allowing for flexible and rich documentation management across different use cases.
