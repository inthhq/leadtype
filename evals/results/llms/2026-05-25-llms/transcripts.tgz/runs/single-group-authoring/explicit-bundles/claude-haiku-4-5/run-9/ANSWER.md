# Frontmatter Group and Monolithic Output

## How Frontmatter `group` Controls Navigation

The `group` field in frontmatter is optional and should match a slug from `docs.config.ts`. The group value has multiple critical functions in controlling navigation and documentation organization:

1. **Sidebar Position**: The group determines where a page appears in the sidebar navigation hierarchy
2. **llms.txt Sections**: Groups organize sections within the `/llms.txt` file, creating structured routing hints for AI agents
3. **Search Metadata**: Group information is embedded in search metadata, allowing search results to be filtered or categorized by group
4. **AGENTS.md Grouping**: Pages are grouped together in the `AGENTS.md` file based on their group assignment

Pages can belong to multiple groups using the syntax `group: [a, b]`, providing flexible organization across multiple navigation structures. If a page declares an unknown group, the build fails, ensuring data integrity.

## Monolithic Output (`/llms-full.txt`)

The `/llms-full.txt` file is the **root full-context fallback** that contains all generated markdown docs pages in a single monolithic bundle. This file is intentionally **not split by group** — instead, groups organize the individual `/llms.txt` sections, navigation, search metadata, and `AGENTS.md` grouping, but the full-context output remains unified.

The distinction is important: while groups structure how documentation is navigated and presented, the monolithic `/llms-full.txt` file ensures agents can access the complete documentation corpus without worrying about group-based sharding. This provides agents with maximum flexibility in accessing all documentation at once when needed, while still maintaining the structured organization provided by groups for targeted lookups.

## Optional Frontmatter Fields

Among the optional frontmatter fields available in Leadtype, two key examples are:

1. **`description`**: Optional but recommended. This field becomes the routing hint in `llms.txt`, helping agents understand the page's purpose and content at a glance.

2. **`icon`**: Optional field used to assign a visual icon to a page in the navigation interface, enhancing visual organization and helping users quickly identify page types or categories.

Other notable optional fields include `deprecated`, `deprecatedReason`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor` (with the latter two being populated when `--enrich-git` is enabled during the build process).
