# Frontmatter Group and Monolithic Output

## How Frontmatter `group` Controls Navigation

The `group` frontmatter field is optional and should match a slug from `docs.config.ts`. This field controls multiple aspects of the documentation structure:

1. **Sidebar Position**: The `group` value determines where a page appears in the sidebar navigation
2. **Section Organization in llms.txt**: Pages are organized into sections based on their group assignment
3. **Search Metadata**: The group is included in search indexing for better organization
4. **AGENTS.md Grouping**: Pages with the same group are grouped together in the AGENTS.md file

Pages can belong to multiple groups using the syntax `group: [a, b]`, allowing flexible categorization.

## Monolithic Output: /llms-full.txt

The `/llms-full.txt` file serves as a complete, monolithic fallback that contains **all generated markdown pages and is not split by group**. This means:

- It provides a comprehensive, unfiltered view of all documentation
- Agents can fetch the entire documentation in a single file when they don't need group-specific filtering
- It complements the group-based organization of regular llms.txt sections by providing a single complete bundle

## Optional Frontmatter Fields

The Leadtype documentation specifies numerous optional fields that can enhance page metadata and behavior:

1. **`icon`**: Specifies an icon for the page, used in navigation UI
2. **`deprecated`**: Boolean flag indicating whether a page or feature is deprecated
3. **`deprecatedReason`**: Provides an explanation for why something is deprecated
4. **`experimental`**: Marks features or pages as experimental (subject to change)
5. **`canary`**: Indicates alpha/beta stage features
6. **`new`**: Highlights newly added content
7. **`draft`**: Marks pages as work-in-progress
8. **`tags`**: Allows categorization with custom tags beyond groups
9. **`availableIn`**: Specifies which versions or environments the feature is available in
10. **`full`**: Controls whether the page appears in full-context bundles
11. **`lastModified`**: Timestamp of last modification (auto-filled with `--enrich-git`)
12. **`lastAuthor`**: Author of last modification (auto-filled with `--enrich-git`)

The `description` field, while optional, is recommended as it becomes the routing hint in llms.txt.

## Build Validation

If a page declares an unknown group (one that doesn't exist in `docs.config.ts`), the build fails, ensuring that all group references are valid and properly configured.
