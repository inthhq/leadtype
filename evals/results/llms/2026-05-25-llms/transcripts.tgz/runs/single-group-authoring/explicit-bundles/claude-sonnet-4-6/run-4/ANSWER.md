# Frontmatter `group` and Monolithic Output in Leadtype

## Frontmatter `group` — What It Is and How It Controls Navigation

Every MDX page in Leadtype may declare a `group` field in its YAML frontmatter. `group` is **optional**, but when present it must match a slug defined in `docs.config.ts`; if an unknown group is referenced the build fails immediately.

```yaml
---
title: My Page
group: reference          # single group
# — or —
group: [reference, api]   # multiple groups
---
```

### What `group` drives

| Surface | Effect |
|---------|--------|
| **Sidebar** | Pages are slotted into their group's position in the navigation tree. |
| **`/llms.txt` sections** | The product-level index file is divided into sections that correspond to groups; each page appears under its group's heading, and the group `description` becomes the routing hint that agents read. |
| **Search metadata** | Group membership is attached to each search document so results can be filtered or ranked by group. |
| **`AGENTS.md` grouping** | When generating an npm bundle, pages are grouped under their declared group in `AGENTS.md`. |

> **Important:** Group boundaries control *routing and organisation only* — they do **not** shard the full-context output. Use groups for routing, not sharding, and write group descriptions as routing hints, not marketing copy.

---

## Monolithic Output — `/llms-full.txt`

`/llms-full.txt` is the **root full-context fallback** produced by `generateLLMFullContextFiles`. It is a single file that concatenates **every generated markdown docs page** regardless of group membership.

Key characteristics:

- Written to the site root (alongside `/llms.txt`) as a static artifact.
- Contains all pages in one bundle so an agent can load the entire docs corpus in a single fetch.
- Groups still organise `/llms.txt` sections and navigation, but they are **not** published as individual per-group full-context files by default — the only full-context file is the single monolithic `/llms-full.txt`.
- It is identified by `isAgentReadabilityArtifactPath` and is therefore never rewritten as a missing markdown page.
- When `leadtype generate --json` is used, the path to this file is surfaced in the JSON output as `llmsFullTxt`.

In website mode the full set of generated static artifacts is:

```
/llms.txt
/llms-full.txt          ← monolithic full-context bundle
/docs/llms.txt
/docs/*.md              ← per-page markdown mirrors
/docs/sitemap.xml
/docs/sitemap.md
/docs/robots.txt
/docs/agent-readability.json
/docs/search-index.json
/docs/search-content.json
```

---

## Optional Frontmatter Fields (selection)

The complete list of optional fields is:
`icon`, `deprecated`, `deprecatedReason`, `experimental`, `canary`, `new`, `draft`, `tags`, `availableIn`, `full`, `lastModified`, and `lastAuthor`.

Two notable examples:

### 1. `deprecated` / `deprecatedReason`

```yaml
---
title: Old API
group: reference
deprecated: true
deprecatedReason: "Replaced by the new Conversion API in v3."
---
```

Marks a page as deprecated so the docs site can render a deprecation notice and tooling can surface the reason to users and agents.

### 2. `lastModified` / `lastAuthor`

```yaml
---
title: Quickstart
lastModified: "2024-11-01"
lastAuthor: "jane@example.com"
---
```

These fields are **automatically populated** when `leadtype generate --enrich-git` is enabled; they attach the most-recent commit date and author to each page for freshness signals in search and agent metadata.

---

## Summary

`group` is the single frontmatter value that ties a page into every navigation surface (sidebar, `/llms.txt` index, search, `AGENTS.md`). Despite controlling all of those surfaces, it never splits the full-context output — `/llms-full.txt` remains a single monolithic file containing every docs page, serving as the definitive whole-corpus bundle for agents that need complete context in one request.
