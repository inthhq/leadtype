# Frontmatter Group and Monolithic Output in Leadtype

## How Frontmatter `group` Controls Navigation

The `group` frontmatter field is optional and should match a slug from `docs.config.ts`. The group value drives multiple aspects of navigation and organization:

1. **Sidebar Position**: Groups determine where pages appear in the sidebar navigation
2. **llms.txt Section**: Groups organize content into separate sections in the routing-focused `/llms.txt` file
3. **Search Metadata**: Group information is included in search index metadata
4. **AGENTS.md Grouping**: Pages are grouped together in the generated `AGENTS.md` file
5. **Multiple Groups Support**: Pages can belong to multiple groups using the syntax `group: [a, b]`

## Monolithic Output and /llms-full.txt

The `/llms-full.txt` file is the root full-context fallback that contains **every generated markdown docs page** in a single, monolithic bundle. Unlike the group-organized `/llms.txt` file, the `/llms-full.txt` file:

- **Is not split by group**: All pages are consolidated into one comprehensive file regardless of their group assignments
- **Remains group-independent**: Groups still organize the llms.txt sections, navigation, search metadata, and AGENTS.md, but these groupings are not applied as per-group full-context files by default
- **Provides complete context**: Offers a complete view of all documentation for agents that need comprehensive context

## Optional Frontmatter Fields

In addition to required `title` and optional `description` and `group`, Leadtype supports numerous optional frontmatter fields:

1. **`icon`**: Specifies an icon to display for the page in navigation
2. **`deprecated`**: Boolean flag indicating if the page content is deprecated
3. **`deprecatedReason`**: Text explaining why the content is deprecated
4. **`experimental`**: Marks content as experimental/unstable
5. **`canary`**: Indicates canary/preview features
6. **`new`**: Marks recently added content
7. **`draft`**: Indicates draft status (not yet published)
8. **`tags`**: Array of searchable tags for the content
9. **`availableIn`**: Specifies product availability (versions, editions, etc.)
10. **`full`**: Controls full-context inclusion behavior
11. **`lastModified`**: Timestamp of last modification (auto-populated with `--enrich-git`)
12. **`lastAuthor`**: Author of last modification (auto-populated with `--enrich-git`)

## Key Design Principle

Groups are designed for **routing, not sharding**. Group descriptions should be routing hints (for navigation and section organization) rather than marketing copy. This separation of concerns ensures that while groups organize the browsable llms.txt and site navigation, the /llms-full.txt monolithic file remains a complete, unsplit reference for comprehensive agent context.
