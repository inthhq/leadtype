# Cross-group agent flows: hosted website vs. npm package bundle

Leadtype emits two complementary sets of agent-readable artifacts from one MDX source. Each flow has a different entry point and a different surface area.

## Hosted website flow (HTTP agents)

**Starts from:** `/llms.txt`

HTTP-based agents discover documentation by fetching `/llms.txt` at the site root and following its markdown links (e.g., into `/docs/*.md` mirrors and `/llms-full.txt`). The docs site is expected to serve markdown when `Accept: text/markdown` is requested or when a known AI user agent asks for a docs page.

Website mode (`leadtype generate`, no `--bundle`) writes:

- `/llms.txt` — product-level routing map (produced by `generateLlmsTxt`)
- `/docs/llms.txt` — docs-scoped map (also from `generateLlmsTxt`)
- `/llms-full.txt` — every generated markdown page flattened into one file (from `generateLLMFullContextFiles`)
- `/docs/*.md` — markdown mirrors of each MDX page
- `docs/sitemap.xml` and `docs/sitemap.md`
- `docs/robots.txt`
- `docs/agent-readability.json`
- `docs/search-index.json` and `docs/search-content.json`

When `--json` is set, the website-mode CLI output reports paths under the keys `llmsTxt`, `docsLlmsTxt`, `llmsFullTxt`, `agentReadabilityJson`, `sitemapXml`, `sitemapMd`, `robotsTxt`, `searchIndex`, and `searchContent`.

## npm package bundle flow (coding agents in `node_modules`)

**Starts from:** `AGENTS.md` (at the installed package root)

Coding agents working inside an installed npm package open `AGENTS.md` and follow relative links such as `./docs/reference/cli.md`. Because links are relative, no network request is required — the docs are readable directly from `node_modules`.

Bundle mode (`leadtype generate --bundle`) writes:

- `AGENTS.md` at the package root (produced by `generateAgentsMd`, which intentionally ignores `product.agentGuidance` because that text is meant for website URL routing)
- `docs/*.md` beneath it, with relative cross-links

## Website artifacts that bundle mode skips

Bundle mode deliberately omits all website-only, HTTP-discoverable artifacts:

- `llms.txt` (both the root `/llms.txt` and `/docs/llms.txt`)
- `llms-full.txt`
- `sitemap.xml` and `sitemap.md`
- `robots.txt`
- `agent-readability.json`
- `search-index.json` and `search-content.json` (the search JSON)

This is consistent with `isAgentReadabilityArtifactPath`, which lists exactly these files as agent-readability artifacts that exist only in the hosted-site surface.

## Why both flows coexist

The two flows complement each other rather than overlap. A single package can publish:

1. A bundled, offline copy of the docs into `node_modules` for coding agents (entry: `AGENTS.md`), and
2. A hosted docs website with `/llms.txt` for URL-based agents (entry: `/llms.txt`).

Groups defined in `docs.config.ts` drive sidebar position, `llms.txt` sections, search metadata, and `AGENTS.md` grouping in both flows — groups are used for routing, not for sharding the corpus into per-group full-context files.
