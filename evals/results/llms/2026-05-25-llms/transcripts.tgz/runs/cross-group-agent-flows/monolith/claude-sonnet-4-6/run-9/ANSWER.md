# Cross-group Agent Flows: Hosted Website vs npm Bundle

## Overview

Leadtype supports two distinct agent flows, each targeting a different runtime context: **HTTP agents** browsing a hosted website, and **coding agents** working inside an installed npm package. Both flows are generated from the same MDX source but produce different artifacts and follow different entry points.

---

## 1. Hosted Website Flow

### Entry Point
HTTP agents start at **`/llms.txt`** — the product-level file generated at the site root by `generateLlmsTxt`. There is also a docs-scoped **`/docs/llms.txt`** map for the docs section specifically. Agents follow markdown links from there to individual pages.

### How It Works
- `leadtype generate` (without `--bundle`) runs in **website mode**.
- The build reads MDX pages, flattens MDX components into portable markdown, resolves the group tree, and emits website artifacts.
- Agents discover content by fetching `/llms.txt`, then following links to **markdown mirrors** under `/docs/*.md`.
- For agent requests, the server serves markdown when the `Accept` header asks for `text/markdown` or when a known AI user agent requests a docs page.

### Artifacts Generated (Website Mode)

| Artifact | Path | Purpose |
|---|---|---|
| Product-level agent map | `/llms.txt` | Primary agent entry point |
| Docs-scoped agent map | `/docs/llms.txt` | Docs-section-specific routing map |
| Full context file | `/llms-full.txt` | All generated markdown pages flattened into one file |
| Markdown mirrors | `/docs/*.md` | Individual docs pages as plain markdown |
| Sitemap (XML) | `/docs/sitemap.xml` | Machine-readable sitemap |
| Sitemap (Markdown) | `/docs/sitemap.md` | Agent-readable sitemap |
| Robots file | `/docs/robots.txt` | Crawl permissions (must allow `/llms.txt`) |
| Agent readability metadata | `/docs/agent-readability.json` | Agent-readability hints |
| Search index | `/docs/search-index.json` | Static BM25-style lexical search index |
| Search content | `/docs/search-content.json` | Content backing search results |

The `--json` flag causes `leadtype generate` to print a JSON object naming all of these paths: `llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, `agentReadabilityJson`, `sitemapXml`, `sitemapMd`, `robotsTxt`, `searchIndex`, and `searchContent`.

---

## 2. npm Bundle Flow

### Entry Point
Coding agents working inside installed npm packages start at **`AGENTS.md`** — written at the **package root** — and follow **relative links** like `./docs/reference/cli.md` to individual docs pages under `docs/*.md`. No network request is required; everything resolves inside `node_modules`.

### How It Works
- `leadtype generate --bundle` runs in **bundle mode**.
- The same MDX source is processed, but output is limited to what is useful offline inside `node_modules`.
- `generateAgentsMd` writes `AGENTS.md`; it intentionally **ignores** `product.agentGuidance` because that guidance text is written for website URL routing, not offline package use.
- Links in `AGENTS.md` are relative (e.g., `./docs/reference/cli.md`) so they resolve correctly wherever the package is installed.

### Artifacts Generated (Bundle Mode)

| Artifact | Path | Purpose |
|---|---|---|
| Agent entry point | `AGENTS.md` | Primary entry for coding agents in node_modules |
| Docs pages | `docs/*.md` | Individual docs pages with relative links |

---

## What Bundle Mode Skips

Bundle mode explicitly **omits all website-only artifacts** because they require a live HTTP server or hosted infrastructure to be useful. The skipped artifacts are:

| Skipped Artifact | Why It's Skipped |
|---|---|
| `llms.txt` | Designed for HTTP discovery; meaningless as a local file |
| `llms-full.txt` | Full-context file for URL-based agents; not needed offline |
| `search-index.json` | Search infrastructure is not available inside node_modules |
| `search-content.json` | Backing data for hosted search; irrelevant offline |
| `sitemap.xml` | Web crawler artifact; not applicable to npm packages |
| `sitemap.md` | Agent-readable sitemap for hosted sites; not needed offline |
| `robots.txt` | HTTP crawl-control file; inapplicable in node_modules |
| `agent-readability.json` | Website-serving metadata; not needed in a package |

The function `isAgentReadabilityArtifactPath` identifies exactly these paths so they are never rewritten as missing markdown pages in either mode.

---

## Side-by-Side Comparison

| Dimension | Hosted Website Flow | npm Bundle Flow |
|---|---|---|
| **Trigger command** | `leadtype generate` | `leadtype generate --bundle` |
| **Agent entry file** | `/llms.txt` (HTTP URL) | `AGENTS.md` (relative path) |
| **Link style** | Absolute URLs | Relative paths (`./docs/…`) |
| **Network required** | Yes | No |
| **Full-context file** | `/llms-full.txt` | ✗ Skipped |
| **Search indexes** | ✓ Generated | ✗ Skipped |
| **Sitemap / robots** | ✓ Generated | ✗ Skipped |
| **agent-readability.json** | ✓ Generated | ✗ Skipped |
| **Individual docs pages** | `/docs/*.md` | `docs/*.md` |

---

## Key Takeaway

The two flows **complement each other**: a package can publish bundled offline docs so coding agents can read documentation directly inside `node_modules`, while the same content is also exposed through a hosted docs website with `/llms.txt` for URL-based HTTP agents. The website flow is richer in artifacts (search, sitemap, robots, full-context), while the bundle flow is intentionally lean — containing only `AGENTS.md` and `docs/*.md` — so it works anywhere without infrastructure.
