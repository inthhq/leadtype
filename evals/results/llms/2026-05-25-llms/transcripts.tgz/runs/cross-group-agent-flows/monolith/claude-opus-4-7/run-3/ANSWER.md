# Cross-group agent flows: hosted website vs npm package bundle

Leadtype emits two complementary sets of agent-readable artifacts from the same MDX sources. Each flow is designed for a different kind of agent and has a different entry point.

## Hosted website flow (HTTP agents)

**Starting file:** `/llms.txt` at the site root.

HTTP-based agents discover docs by fetching `/llms.txt` and following its markdown links. From there they can also reach:

- `/llms-full.txt` — every generated markdown docs page flattened into one file (the all-docs full-context fallback).
- `/docs/llms.txt` — the docs-scoped map written by `generateLlmsTxt`.
- `/docs/*.md` — markdown mirrors of each MDX page.
- `/docs/sitemap.xml` and `/docs/sitemap.md` — sitemaps.
- `/docs/robots.txt` (also served at `/robots.txt`) — must allow `/llms.txt`.
- `/docs/agent-readability.json` — agent-readability manifest.
- `/docs/search-index.json` and `/docs/search-content.json` — the static BM25 search index and content.

Sites should serve markdown when `Accept: text/markdown` is requested or when a known AI user-agent fetches a docs page. The CLI's `--json` output for website mode includes `llmsTxt`, `docsLlmsTxt`, `llmsFullTxt`, `agentReadabilityJson`, `sitemapXml`, `sitemapMd`, `robotsTxt`, `searchIndex`, and `searchContent`.

## npm package bundle flow (coding agents in `node_modules`)

**Starting file:** `AGENTS.md` at the package root.

Coding agents working inside an installed npm package start at `AGENTS.md` and follow relative `./docs/*.md` links (for example `./docs/reference/cli.md`). This lets them read docs from `node_modules` with no network request.

Bundle mode is produced with `leadtype generate --bundle` and writes only:

- `AGENTS.md` at the package root (written by `generateAgentsMd`, which intentionally ignores `product.agentGuidance` because that copy is written for URL routing).
- `docs/*.md` beneath the package root, with relative links that work inside `node_modules`.

## Website artifacts that bundle mode skips

Per `/docs/package-docs/bundle.md`, bundle mode deliberately omits the website-only artifacts:

- `llms.txt`
- `llms-full.txt`
- Search JSON (`search-index.json`, `search-content.json`)
- Sitemap files (`sitemap.xml`, `sitemap.md`)
- `robots.txt`
- `agent-readability.json`

These are the same artifact paths recognized by `isAgentReadabilityArtifactPath`, which exists so the website doesn't try to rewrite them as missing markdown pages.

## Summary

| Aspect | Hosted website flow | npm bundle flow |
|---|---|---|
| Audience | HTTP agents (URL-based) | Coding agents inside `node_modules` |
| Entry point | `/llms.txt` | `AGENTS.md` |
| Link style | Absolute URLs to `/docs/*.md` | Relative `./docs/*.md` |
| CLI invocation | `leadtype generate` | `leadtype generate --bundle` |
| Includes | llms.txt, docs/llms.txt, llms-full.txt, docs/*.md, sitemap.xml, sitemap.md, robots.txt, agent-readability.json, search-index.json, search-content.json | AGENTS.md, docs/*.md |
| Skipped in bundle | — | llms.txt, llms-full.txt, search JSON, sitemap files, robots.txt, agent-readability.json |

The two flows are intended to complement each other: one package can publish a bundled offline docs tree for `node_modules` consumers *and* host a website with `llms.txt` for URL-based agents.
