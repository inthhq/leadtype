# Cross-group agent flows: hosted vs npm bundle

Leadtype supports two complementary agent flows.

## Hosted website flow

For URL-based or HTTP agents, the entry point is the hosted site root:

- Start at `/llms.txt`.
- Follow the markdown links advertised there, including the all-docs fallback `/llms-full.txt` when broad task context is needed.
- Website mode also exposes markdown mirrors under `/docs/*.md` so agents can request docs pages directly as markdown.

This flow is produced by website mode, which writes hosted/static artifacts such as:

- `/llms.txt`
- `/docs/llms.txt`
- `/llms-full.txt`
- `/docs/*.md`
- sitemap files such as `docs/sitemap.xml` and `docs/sitemap.md`
- `robots.txt`
- `docs/agent-readability.json`
- search JSON such as `docs/search-index.json` and `docs/search-content.json`

## npm package bundle flow

For coding agents operating inside an installed npm package, the entry point is different:

- Start at `AGENTS.md` in the package root.
- Follow relative links from `AGENTS.md`, such as `./docs/reference/cli.md`.
- Read the bundled `docs/*.md` files locally inside `node_modules`, without requiring a network request.

This flow is produced with:

```sh
leadtype generate --bundle
```

Bundle mode writes only the package-oriented offline docs surface:

- `AGENTS.md`
- `docs/*.md`

## What bundle mode skips

Bundle mode skips the website-only artifacts. In particular, it does not emit the hosted `llms.txt` flow or the hosted discovery/search files:

- `llms.txt` / the hosted llms maps, including `/docs/llms.txt`
- `llms-full.txt`
- search JSON files
- sitemap files
- `robots.txt`
- `agent-readability.json`

In short: hosted agents discover docs from `/llms.txt` over HTTP, while npm-package coding agents discover docs from `AGENTS.md` and local relative `docs/*.md` links.