# Cross-group agent flows: hosted website vs npm bundle

Leadtype emits two complementary sets of agent-readable artifacts from the same MDX source. Each flow has a different entry point and a different artifact surface.

## Hosted website flow

**Entry point for agents:** `/llms.txt` at the site root.

Per `docs/how-it-works.md`, "HTTP agents start at /llms.txt and follow markdown links." The hosted flow assumes URL-based discovery — agents fetch over HTTP, and the server returns markdown when `Accept: text/markdown` or a known AI user-agent is detected (`docs/build/connect-docs-site.md`).

**Artifacts written in website mode** (from `docs/quickstart.md` and `docs/reference/cli.md`):

- `/llms.txt` — product-level routing map (`llmsTxt`)
- `/docs/llms.txt` — docs-scoped map (`docsLlmsTxt`)
- `/llms-full.txt` — every generated markdown page flattened into one file (`llmsFullTxt`)
- `/docs/*.md` — markdown mirrors of each MDX page
- `docs/sitemap.xml` and `docs/sitemap.md` (`sitemapXml`, `sitemapMd`)
- `docs/robots.txt` (`robotsTxt`)
- `docs/agent-readability.json` (`agentReadabilityJson`)
- `docs/search-index.json` and `docs/search-content.json` (`searchIndex`, `searchContent`)

The product-level `llms.txt` and `/docs/llms.txt` are produced by `generateLlmsTxt`; the root `llms-full.txt` is produced by `generateLLMFullContextFiles` (`docs/reference/llm.md`).

## npm package bundle flow

**Entry point for agents:** `AGENTS.md` at the package root.

Per `docs/how-it-works.md`, "Coding agents working inside installed npm packages start at AGENTS.md and follow relative docs/*.md links." Bundle mode is invoked with `leadtype generate --bundle` and is designed for offline reads from inside `node_modules` — no network request required (`docs/package-docs/bundle.md`).

**Artifacts written in bundle mode:**

- `AGENTS.md` at the package root (produced by `generateAgentsMd`)
- `docs/*.md` beneath the package root, linked from `AGENTS.md` using relative paths like `./docs/reference/cli.md`

Note: `generateAgentsMd` intentionally ignores `product.agentGuidance`, because that text is written for website URL routing rather than offline package consumption (`docs/reference/llm.md`).

## Website artifacts that bundle mode skips

Per `docs/package-docs/bundle.md`, bundle mode **skips website-only artifacts**:

- `llms.txt`
- `llms-full.txt`
- search JSON (`search-index.json`, `search-content.json`)
- sitemap files (`sitemap.xml`, `sitemap.md`)
- `robots.txt`
- `agent-readability.json`

These are the same paths that `isAgentReadabilityArtifactPath` recognizes as website artifacts (`docs/reference/llm.md`) — they only make sense on a hosted site where agents discover docs by URL, so the npm bundle omits them entirely and relies on `AGENTS.md` + relative `docs/*.md` links instead.

## Summary table

| Aspect | Hosted website | npm bundle (`--bundle`) |
|---|---|---|
| Entry file | `/llms.txt` | `AGENTS.md` |
| Link style | Absolute URLs | Relative paths (`./docs/...`) |
| Markdown pages | `/docs/*.md` | `docs/*.md` (package-relative) |
| Routing maps | `llms.txt`, `/docs/llms.txt` | (skipped) |
| Full context | `/llms-full.txt` | (skipped) |
| Sitemaps | `sitemap.xml`, `sitemap.md` | (skipped) |
| `robots.txt` | yes | (skipped) |
| Search JSON | `search-index.json`, `search-content.json` | (skipped) |
| `agent-readability.json` | yes | (skipped) |
| Discovery model | HTTP fetch + `Accept: text/markdown` | Offline read inside `node_modules` |

The two flows are designed to coexist: a single package can ship a bundled `AGENTS.md` for coding agents *and* publish a hosted docs website with `llms.txt` for URL-based agents (`docs/how-it-works.md`).
