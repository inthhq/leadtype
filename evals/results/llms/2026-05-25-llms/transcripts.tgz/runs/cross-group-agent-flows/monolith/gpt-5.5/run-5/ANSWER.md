# Cross-group agent flows: hosted website vs npm bundle

Leadtype supports two complementary agent flows:

## Hosted website flow

- **Starts from:** `/llms.txt` at the hosted site root.
- **How agents proceed:** HTTP/URL-based agents read `/llms.txt`, use its group sections and routing hints, then follow markdown links to generated docs pages such as `/docs/*.md`.
- **Full-context fallback:** When broader task context is needed, agents can read `/llms-full.txt`, which contains every generated markdown docs page flattened into one file.
- **Group behavior:** Groups organize `/llms.txt` sections, navigation, search metadata, and routing hints. They are not separate full-context shards; `/llms-full.txt` contains all generated docs across groups.

Website mode emits the hosted artifacts, including `/llms.txt`, `/docs/llms.txt`, `/llms-full.txt`, markdown mirrors under `/docs/*.md`, sitemap files, robots.txt, search JSON, and `agent-readability.json`.

## npm package bundle flow

- **Starts from:** `AGENTS.md` at the package root.
- **How agents proceed:** Coding agents working inside an installed npm package, such as under `node_modules`, read `AGENTS.md` and follow relative links like `./docs/reference/cli.md` to bundled `docs/*.md` files.
- **Network requirement:** None. The bundle is designed for offline/local package documentation access.
- **Group behavior:** Groups still organize the `AGENTS.md` layout, but the links are relative package paths instead of hosted URLs.

Bundle mode is invoked with `leadtype generate --bundle` and writes only the package-oriented agent docs: `AGENTS.md` plus `docs/*.md`.

## Website artifacts skipped by bundle mode

Bundle mode skips the website-only artifacts:

- `llms.txt`
- `llms-full.txt`
- search JSON
- sitemap files
- `robots.txt`
- `agent-readability.json`

In short: hosted agents start at `/llms.txt` and use URL-based markdown artifacts, while npm-package coding agents start at `AGENTS.md` and use relative bundled docs inside the package.