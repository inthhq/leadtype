# Cross-group Agent Flows: Hosted vs npm Bundle

## Overview

Leadtype supports two complementary agent flows: one for HTTP-based agents accessing hosted websites and another for coding agents working inside npm packages. Each flow generates different starting files and artifacts.

## Hosted Website Flow

**Starting File:** `/llms.txt` (product-level) and `/docs/llms.txt` (docs-scoped)

**How it works:**
- HTTP agents begin by fetching `/llms.txt` at the site root
- They follow markdown links within the generated documentation
- The `generateLlmsTxt` function writes both the product-level `/llms.txt` map and the docs-scoped `/docs/llms.txt` for hosted websites
- Groups organize llms.txt sections, navigation, search metadata, and agent guidance

**Generated Artifacts Include:**
- `/llms.txt` - Product-level agent map
- `/docs/llms.txt` - Docs-scoped agent map
- `/llms-full.txt` - Complete single-file context containing every generated markdown page
- `/docs/*.md` - Markdown mirrors of documentation
- `/docs/sitemap.xml` and `/docs/sitemap.md` - Sitemap files
- `/docs/robots.txt` - Robot directives
- `/docs/agent-readability.json` - Agent readability metadata
- `/docs/search-index.json` and `/docs/search-content.json` - Search indexes
- Full agent guidance text (from `product.agentGuidance`)

## npm Bundle Flow

**Starting File:** `AGENTS.md` (at package root)

**How it works:**
- Coding agents working inside installed npm packages start at `AGENTS.md`
- They follow relative links like `./docs/reference/cli.md` to read offline documentation
- The `generateAgentsMd` function writes AGENTS.md specifically for npm-bundled docs
- Relative links work inside node_modules without network requests
- Groups still organize AGENTS.md; they are not published as per-group files by default

**Generated Artifacts Include:**
- `AGENTS.md` - At the package root, using relative links for agent navigation
- `docs/*.md` - Markdown files beneath the docs directory

## Key Differences

| Aspect | Hosted Website | npm Bundle |
|--------|---|---|
| **Starting File** | `/llms.txt` | `AGENTS.md` |
| **Link Type** | Absolute URLs | Relative paths (e.g., `./docs/reference/cli.md`) |
| **Network Dependency** | Yes (HTTP requests) | No (offline, file-based) |
| **Agent Guidance** | Included (uses `product.agentGuidance`) | Excluded (intentionally ignored) |

## Website Artifacts Skipped in Bundle Mode

Bundle mode explicitly skips the following website-only artifacts:

1. **`llms.txt`** - Product-level and docs-scoped agent maps (only for hosted sites)
2. **`llms-full.txt`** - Complete context file (only for hosted sites)
3. **Search JSON files:**
   - `search-index.json`
   - `search-content.json`
4. **Sitemap files:**
   - `sitemap.xml`
   - `sitemap.md`
5. **`robots.txt`** - Robot directives for hosted sites
6. **`agent-readability.json`** - Agent readability metadata (website-specific)

## Why the Difference?

The two flows serve different use cases:
- **Hosted websites** need HTTP-discoverable entry points and rich agent guidance written for URL routing
- **npm packages** need offline-accessible documentation with relative links that work inside node_modules without network requests

A package can publish both: bundled offline docs for node_modules AND a hosted docs website with `/llms.txt` for URL-based agents, providing flexibility for different agent consumption patterns.
