# Cross-group agent flows: hosted vs npm bundle

Leadtype emits two complementary agent-readable flows from the same MDX source. The hosted website flow targets HTTP agents that fetch URLs, while the npm bundle flow targets coding agents that read files inside `node_modules` without a network request.

## Starting files

### Hosted website flow
- **Entry point:** `/llms.txt` (the product-level routing map at the site root).
- HTTP agents start there and follow markdown links — for example into `/docs/llms.txt` (the docs-scoped map), individual `/docs/*.md` mirrors, and `/llms-full.txt` when a single flattened all-docs context file is needed.
- Source: `docs/how-it-works.md` — "HTTP agents start at /llms.txt and follow markdown links."

### npm package bundle flow
- **Entry point:** `AGENTS.md` at the installed package root (e.g. `node_modules/<pkg>/AGENTS.md`).
- Coding agents follow relative links such as `./docs/reference/cli.md` to read bundled markdown directly from disk.
- Source: `docs/how-it-works.md` and `docs/package-docs/bundle.md` — "Coding agents working inside installed npm packages start at AGENTS.md and follow relative docs/*.md links."

## What each flow writes

Website mode (`leadtype generate`) writes:
- `/llms.txt`
- `/docs/llms.txt`
- `/llms-full.txt`
- markdown mirrors under `/docs/*.md`
- `docs/sitemap.xml`, `docs/sitemap.md`
- `docs/robots.txt`
- `docs/agent-readability.json`
- `docs/search-index.json`, `docs/search-content.json`

Bundle mode (`leadtype generate --bundle`) writes:
- `AGENTS.md` at the package root
- `docs/*.md` beneath it, with relative links that resolve inside `node_modules`

## Website artifacts that bundle mode skips

Per `docs/package-docs/bundle.md`, bundle mode intentionally omits the website-only artifacts:

1. `llms.txt`
2. `llms-full.txt`
3. Search JSON (`search-index.json`, `search-content.json`)
4. Sitemap files (`sitemap.xml`, `sitemap.md`)
5. `robots.txt`
6. `agent-readability.json`

Additional notes from `docs/reference/llm.md`:
- `generateLlmsTxt` is the website-only writer for `/llms.txt` and `/docs/llms.txt`.
- `generateLLMFullContextFiles` writes the website-only `/llms-full.txt`.
- `generateAgentsMd` writes `AGENTS.md` for bundles and **intentionally ignores `product.agentGuidance`**, because that guidance is written for website URL routing rather than offline `node_modules` reading.
- `isAgentReadabilityArtifactPath` enumerates the same skipped set (llms.txt, llms-full.txt, sitemap files, robots.txt, search JSON, agent-readability.json) as paths that should not be rewritten as missing markdown.

## Why two flows coexist

From `docs/how-it-works.md`: "A package can publish bundled offline docs for node_modules and a hosted docs website with llms.txt for URL-based agents." The same MDX source produces:
- a URL-discoverable surface (entry: `/llms.txt`) for HTTP agents, and
- an offline file-tree surface (entry: `AGENTS.md`) for coding agents reading installed packages.

Bundle mode strips the URL/discovery/search infrastructure because none of it is useful — or resolvable — from inside `node_modules`.
