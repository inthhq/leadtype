# Cross-group agent flows: hosted website vs npm bundle

Leadtype's docs pipeline emits two complementary flows from the same MDX source. Each flow is aimed at a different kind of agent, starts from a different entry file, and produces a different set of artifacts.

## The two flows at a glance

| Aspect | Hosted website flow | npm package bundle flow |
|---|---|---|
| Audience | HTTP agents fetching docs over the network | Coding agents reading files inside `node_modules` |
| Build command | `leadtype generate` (website mode) | `leadtype generate --bundle` |
| Entry file | `/llms.txt` | `AGENTS.md` (at the package root) |
| Link style | URL paths to markdown mirrors | Relative paths like `./docs/reference/cli.md` |
| Network required? | Yes (designed for URL-based discovery) | No (works offline inside `node_modules`) |

Sources: `docs/how-it-works.md`, `docs/quickstart.md`, `docs/package-docs/bundle.md`.

## Where each flow starts

- **Hosted website flow.** Per `docs/how-it-works.md`, "HTTP agents start at `/llms.txt` and follow markdown links." The product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` map are written by `generateLlmsTxt`, and a single flattened `/llms-full.txt` is written by `generateLLMFullContextFiles` (see `docs/reference/llm.md`). The current `/llms.txt` in this site points agents at `/llms-full.txt` as the all-docs full-context file.

- **npm package bundle flow.** Per the same page, "Coding agents working inside installed npm packages start at `AGENTS.md` and follow relative `docs/*.md` links." `AGENTS.md` is written by `generateAgentsMd`, which intentionally ignores `product.agentGuidance` because that text is written for website URL routing (`docs/reference/llm.md`).

## What each flow writes

### Website mode (`leadtype generate`)

From `docs/quickstart.md` and `docs/reference/cli.md`, website mode writes:

- `/llms.txt` (product-level entry point)
- `/docs/llms.txt` (docs-scoped map)
- `/llms-full.txt` (every generated markdown page flattened into one file)
- Markdown mirrors under `/docs/*.md`
- `docs/sitemap.xml` and `docs/sitemap.md`
- `docs/robots.txt`
- `docs/agent-readability.json`
- `docs/search-index.json` and `docs/search-content.json`

When `--json` is enabled, the CLI reports these as `llmsTxt`, `docsLlmsTxt`, `llmsFullTxt`, `agentReadabilityJson`, `sitemapXml`, `sitemapMd`, `robotsTxt`, `searchIndex`, and `searchContent` (`docs/reference/cli.md`).

### Bundle mode (`leadtype generate --bundle`)

From `docs/package-docs/bundle.md` and `docs/quickstart.md`, bundle mode writes only:

- `AGENTS.md` at the package root
- `docs/*.md` beneath it, linked with relative paths so they resolve inside `node_modules`

## Which website artifacts bundle mode skips

`docs/package-docs/bundle.md` is explicit: "Bundle mode skips website-only artifacts." Those skipped artifacts are:

1. `llms.txt`
2. `llms-full.txt`
3. Search JSON (`search-index.json` and `search-content.json`)
4. Sitemap files (`sitemap.xml` and `sitemap.md`)
5. `robots.txt`
6. `agent-readability.json`

This is consistent with `isAgentReadabilityArtifactPath` in `docs/reference/llm.md`, which lists exactly the same set as the "agent-readability artifact paths" that exist for hosted websites and that bundle mode therefore has no reason to emit.

## Why the split exists

Per `docs/how-it-works.md`, the two flows "complement each other. A package can publish bundled offline docs for `node_modules` and a hosted docs website with `llms.txt` for URL-based agents." Website artifacts (`llms.txt`, sitemaps, `robots.txt`, search JSON, agent-readability JSON) only make sense when there is an HTTP origin to serve them from; inside an installed npm package there is no origin, so an `AGENTS.md` plus relative-linked `docs/*.md` is sufficient and avoids shipping URL-oriented metadata that a coding agent cannot use.
