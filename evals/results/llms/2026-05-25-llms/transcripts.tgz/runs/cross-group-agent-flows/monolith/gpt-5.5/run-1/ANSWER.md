# Cross-group agent flows: hosted vs npm bundle

Leadtype supports two complementary agent documentation flows:

## Hosted website flow

- **Agent starting point:** `/llms.txt` at the site root.
- **How agents navigate:** HTTP agents fetch `/llms.txt` and follow the markdown links it exposes, including links to generated markdown mirrors such as `/docs/*.md` and the full-context fallback `/llms-full.txt`.
- **Generated website artifacts include:**
  - `/llms.txt`
  - `/docs/llms.txt`
  - `/llms-full.txt`
  - Markdown mirrors under `/docs/*.md`
  - `/docs/sitemap.xml`
  - `/docs/sitemap.md`
  - `/docs/robots.txt`
  - `/docs/agent-readability.json`
  - `/docs/search-index.json`
  - `/docs/search-content.json`

Groups organize the `llms.txt` sections, navigation, search metadata, and routing hints. They are not published as separate per-group full-context files by default; `/llms-full.txt` contains all generated markdown docs pages.

## npm package bundle flow

- **Agent starting point:** `AGENTS.md` at the package root.
- **How agents navigate:** Coding agents working inside an installed npm package read `AGENTS.md` and follow relative links such as `./docs/reference/cli.md`. This works offline inside `node_modules` without a network request.
- **Generated bundle artifacts include:**
  - `AGENTS.md`
  - `docs/*.md`

`AGENTS.md` uses the same group structure for organization, but it intentionally ignores `product.agentGuidance` because that guidance is meant for website URL routing.

## What bundle mode skips

When running `leadtype generate --bundle`, Leadtype skips website-only artifacts:

- `llms.txt`
- `llms-full.txt`
- Search JSON files, including `search-index.json` and `search-content.json`
- Sitemap files, including `sitemap.xml` and `sitemap.md`
- `robots.txt`
- `agent-readability.json`

In short: hosted website mode is for URL-based agents starting at `/llms.txt`; npm bundle mode is for coding agents inside packages starting at `AGENTS.md` with relative links to bundled markdown docs.