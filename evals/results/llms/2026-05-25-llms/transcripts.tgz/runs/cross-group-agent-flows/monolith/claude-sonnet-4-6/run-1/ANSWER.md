# Cross-group Agent Flows: Hosted Website vs npm Bundle

## Overview

Leadtype supports two distinct agent flows for consuming documentation. Both start from the same MDX source, but they produce different artifacts and are traversed in different ways depending on whether the agent is an HTTP-based agent or a coding agent working inside an installed npm package.

---

## 1. Hosted Website Flow

### Entry Point
HTTP agents start at **`/llms.txt`** — the product-level file generated at the site root by `generateLlmsTxt`. There is also a docs-scoped **`/docs/llms.txt`** map for finer-grained navigation.

### How the Flow Works
1. An agent fetches **`/llms.txt`** (or `/docs/llms.txt`) and reads the section-organized table of contents with routing hints derived from each page's frontmatter `description`.
2. The agent follows the markdown links to individual **`/docs/*.md`** mirror pages (served as `text/markdown` when requested with the appropriate `Accept` header or from a known AI user agent).
3. For full context in a single request, the agent can read **`/llms-full.txt`**, which contains every generated markdown docs page flattened into one file.

### Static Artifacts Produced (Website Mode)
| Artifact | Purpose |
|---|---|
| `/llms.txt` | Product-level agent entry point |
| `/docs/llms.txt` | Docs-scoped map |
| `/llms-full.txt` | All docs pages flattened into one file |
| `/docs/*.md` | Markdown mirrors of each MDX page |
| `docs/sitemap.xml` | XML sitemap |
| `docs/sitemap.md` | Markdown sitemap |
| `docs/robots.txt` | Crawler policy (must allow `/llms.txt`) |
| `docs/agent-readability.json` | Agent readability metadata |
| `docs/search-index.json` | Static search index |
| `docs/search-content.json` | Search content payload |

---

## 2. npm Bundle Flow

### Entry Point
Coding agents working inside an installed npm package start at **`AGENTS.md`** — written at the **package root** by `generateAgentsMd` when `leadtype generate --bundle` is run.

### How the Flow Works
1. The agent reads **`AGENTS.md`** at the package root (e.g., inside `node_modules/<package>/AGENTS.md`).
2. `AGENTS.md` uses **relative links** (e.g., `./docs/reference/cli.md`) so the agent can follow them to **`docs/*.md`** pages without any network request — everything is available offline inside `node_modules`.
3. Note: `generateAgentsMd` intentionally **ignores** `product.agentGuidance` because that text is written for website URL routing and is not relevant in the bundle context.

### Artifacts Produced (Bundle Mode)
| Artifact | Purpose |
|---|---|
| `AGENTS.md` | Package-root entry point with relative links |
| `docs/*.md` | Markdown docs pages, link-relative for offline use |

---

## 3. What Bundle Mode Skips

Bundle mode explicitly skips all **website-only artifacts** because they are meaningless without a hosted server or HTTP URLs:

| Skipped Artifact | Why It's Skipped |
|---|---|
| `llms.txt` | HTTP-discovery entry point; not needed inside `node_modules` |
| `llms-full.txt` | Full-context flat file for URL-based agents only |
| `search-index.json` | Static search index; no search runtime in a package |
| `search-content.json` | Search content; same reason |
| `sitemap.xml` | Web crawler artifact; irrelevant offline |
| `sitemap.md` | Markdown sitemap; irrelevant offline |
| `robots.txt` | Crawler policy; irrelevant offline |
| `agent-readability.json` | Hosted-site readability metadata; irrelevant offline |

These skipped paths are also identified by `isAgentReadabilityArtifactPath` internally, ensuring they are never rewritten as missing markdown pages.

---

## 4. Side-by-Side Comparison

| Dimension | Hosted Website Flow | npm Bundle Flow |
|---|---|---|
| **Entry file** | `/llms.txt` (HTTP URL) | `AGENTS.md` (relative path at package root) |
| **Secondary entry** | `/docs/llms.txt`, `/llms-full.txt` | `docs/*.md` (relative links) |
| **Link style** | Absolute URLs | Relative paths (`./docs/...`) |
| **Network required?** | Yes | No — works fully offline inside `node_modules` |
| **Triggered by** | `leadtype generate` (default) | `leadtype generate --bundle` |
| **Produces search index?** | Yes | No |
| **Produces sitemaps?** | Yes | No |
| **Produces robots.txt?** | Yes | No |
| **Produces agent-readability.json?** | Yes | No |

---

## Summary

The two flows are designed to **complement each other**. A package author can publish both: bundled offline docs (`AGENTS.md` + `docs/*.md`) for coding agents inside `node_modules`, and a hosted docs website (`/llms.txt` + all static artifacts) for HTTP URL-based agents. The hosted flow starts at `/llms.txt` and supports rich discovery through sitemaps, search indexes, and a full-context flat file. The bundle flow starts at `AGENTS.md` and is deliberately lean — it skips every website-only artifact (`llms.txt`, `llms-full.txt`, all search JSON, all sitemap files, `robots.txt`, and `agent-readability.json`) since none of those make sense in an offline, file-system-only context.
