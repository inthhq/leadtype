# Cross-group agent flows: hosted vs npm bundle

## Overview

Leadtype supports two distinct agent-readable output modes from the same MDX source:
**website (hosted) mode** and **bundle (npm package) mode**. Each flow targets a
different kind of agent and starts from a different entry-point file.

---

## 1. Hosted website flow

### Entry point
HTTP-based agents (URL-routing agents) start at **`/llms.txt`** — the product-level
file written at the site root by `generateLlmsTxt`. A second, docs-scoped map is
also written at **`/docs/llms.txt`**.

### How the flow works
1. An agent fetches `/llms.txt`, which lists sections and links to individual
   markdown mirror pages.
2. The agent follows those markdown links under `/docs/*.md` (generated mirrors of
   each MDX page).
3. When full context is needed, the agent can load **`/llms-full.txt`**, a single
   flat file containing every generated markdown docs page (written by
   `generateLLMFullContextFiles`).

### Artifacts produced (website mode)
| Artifact | Purpose |
|---|---|
| `/llms.txt` | Product-level agent entry point |
| `/docs/llms.txt` | Docs-scoped routing map |
| `/llms-full.txt` | All docs pages flattened into one file |
| `/docs/*.md` | Markdown mirrors of each MDX page |
| `docs/sitemap.xml` | XML sitemap |
| `docs/sitemap.md` | Markdown sitemap |
| `docs/robots.txt` | Robots file (allows `/llms.txt`) |
| `docs/agent-readability.json` | Agent-readability metadata |
| `docs/search-index.json` | Static BM25-style search index |
| `docs/search-content.json` | Search content payloads |

The `--json` CLI flag prints a JSON object whose keys correspond to all of the above
paths (`llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, `agentReadabilityJson`,
`sitemapXml`, `sitemapMd`, `robotsTxt`, `searchIndex`, `searchContent`).

---

## 2. npm bundle flow

### Entry point
Coding agents working **inside an installed npm package** (i.e. inside
`node_modules`) start at **`AGENTS.md`** — written at the package root by
`generateAgentsMd`.

### How the flow works
1. A coding agent reads `AGENTS.md` at the package root.
2. `AGENTS.md` uses **relative links** (e.g. `./docs/reference/cli.md`) so the
   agent can navigate to individual docs pages without any network request.
3. The agent follows those relative links to the **`docs/*.md`** files bundled
   alongside the package.

Bundle mode is invoked with `leadtype generate --bundle`.

### Artifacts produced (bundle mode)
| Artifact | Purpose |
|---|---|
| `AGENTS.md` | Coding-agent entry point (relative links, no URL routing) |
| `docs/*.md` | Individual markdown docs pages |

> **Note:** `generateAgentsMd` intentionally ignores `product.agentGuidance`
> because that text is written for website URL routing, which is irrelevant inside
> `node_modules`.

---

## 3. What bundle mode skips

Bundle mode **does not** produce any of the website-only artifacts. The following
files are written in hosted mode but are explicitly skipped by `--bundle`:

| Skipped artifact | Reason |
|---|---|
| `llms.txt` | HTTP-discovery entry point — not needed offline |
| `llms-full.txt` | Full-context flat file — not needed offline |
| `search-index.json` | Static search index — no search runtime in node_modules |
| `search-content.json` | Search content — same reason |
| `sitemap.xml` | Web crawler sitemap — irrelevant for npm packages |
| `sitemap.md` | Markdown sitemap — same reason |
| `robots.txt` | Web crawler directives — irrelevant for npm packages |
| `agent-readability.json` | Website agent-readability metadata — not applicable offline |

`isAgentReadabilityArtifactPath` identifies these artifact paths so they are never
rewritten as missing markdown pages.

---

## 4. Summary comparison

| Dimension | Hosted website flow | npm bundle flow |
|---|---|---|
| **Invocation** | `leadtype generate` | `leadtype generate --bundle` |
| **Agent entry point** | `/llms.txt` (HTTP URL) | `AGENTS.md` (relative file path) |
| **Secondary pages** | `/docs/*.md` via absolute URLs | `./docs/*.md` via relative links |
| **Full-context file** | `/llms-full.txt` | ✗ (skipped) |
| **Search index** | `search-index.json` + `search-content.json` | ✗ (skipped) |
| **Sitemaps** | `sitemap.xml`, `sitemap.md` | ✗ (skipped) |
| **robots.txt** | ✓ (allows `/llms.txt`) | ✗ (skipped) |
| **agent-readability.json** | ✓ | ✗ (skipped) |
| **Network required** | Yes — agents fetch URLs | No — all files local in node_modules |
| **Target agent type** | HTTP / URL-routing agents | Coding agents (e.g. in IDEs, CI) |

The two flows are complementary: a package can publish bundled offline docs for
`node_modules` **and** maintain a hosted docs website with `llms.txt` for
URL-based agents.
