# Hosted website flow vs npm package bundle flow for agents

## Hosted website flow

Use website mode when the docs are served over HTTP. URL-based agents start at the site-root file:

- `/llms.txt`

From there, agents follow the markdown links into the generated docs mirrors, and can use:

- `/docs/llms.txt` for the docs-scoped map
- `/llms-full.txt` when they need one full-context file containing every generated markdown docs page
- `/docs/*.md` markdown mirrors for individual pages

Groups are used as routing and organization hints in `llms.txt`, search metadata, navigation, and agent-facing grouping. They are not separate full-context shards by default: `/llms-full.txt` contains all generated markdown pages across groups.

## npm package bundle flow

Use bundle mode for docs shipped inside an npm package:

```bash
leadtype generate --bundle
```

Coding agents working inside an installed package start from:

- `AGENTS.md`

`AGENTS.md` uses relative links such as:

- `./docs/reference/cli.md`

Those relative links let agents read bundled docs inside `node_modules` without making network requests. Bundle mode writes:

- `AGENTS.md` at the package root
- `docs/*.md` beneath it

Groups still matter in bundle mode because they affect `AGENTS.md` grouping, but the flow is package-local rather than URL-based.

## Website artifacts skipped by bundle mode

Bundle mode skips website-only artifacts, including:

- `llms.txt`
- `llms-full.txt`
- search JSON, such as `search-index.json` and `search-content.json`
- sitemap files, such as `sitemap.xml` and `sitemap.md`
- `robots.txt`
- `agent-readability.json`

In short: hosted agents start from `/llms.txt` and navigate HTTP-discoverable website artifacts; package-local coding agents start from `AGENTS.md` and navigate relative `docs/*.md` files, while bundle mode omits the hosted-site discovery, search, sitemap, robots, and readability artifacts.