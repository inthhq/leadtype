# Cross-group Agent Flows: Hosted Website vs npm Bundle

## Overview

Leadtype supports two distinct agent-readable output flows from the same MDX source:
the **hosted website flow** and the **npm bundle flow**. They are designed to complement
each other — a package can publish bundled offline docs for `node_modules` **and** a
hosted docs website for URL-based agents.

---

## 1. Hosted Website Flow

### Entry-point file
HTTP agents start at **`/llms.txt`** (at the site root).  
From there they follow markdown links, including the docs-scoped **`/docs/llms.txt`**
and the flat full-context file **`/llms-full.txt`**, which contains every generated
markdown docs page flattened into one file.

### How to activate
Run `leadtype generate` (no extra flags needed — website mode is the default).

### Artifacts written
| Artifact | Path |
|---|---|
| Product-level agent index | `/llms.txt` |
| Docs-scoped agent index | `/docs/llms.txt` |
| Full-context flat file | `/llms-full.txt` |
| Markdown mirrors of each doc page | `/docs/*.md` |
| XML sitemap | `/docs/sitemap.xml` |
| Markdown sitemap | `/docs/sitemap.md` |
| Robots rules | `/docs/robots.txt` |
| Agent-readability metadata | `/docs/agent-readability.json` |
| Search index | `/docs/search-index.json` |
| Search content | `/docs/search-content.json` |

When `--json` is passed to the CLI, `leadtype generate` prints a JSON object
containing the paths for all of the above (`llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`,
`agentReadabilityJson`, `sitemapXml`, `sitemapMd`, `robotsTxt`, `searchIndex`,
`searchContent`).

### How agents traverse it
1. Fetch `/llms.txt` to discover the docs map and section routing hints.
2. Follow links to individual `/docs/*.md` pages (or request any docs HTML page with
   `Accept: text/markdown` to receive the markdown mirror).
3. Optionally fetch `/llms-full.txt` for single-request full-context access.

---

## 2. npm Bundle Flow

### Entry-point file
Coding agents working inside an installed npm package start at **`AGENTS.md`** at the
package root and follow **relative** links of the form `./docs/reference/cli.md`.
This means docs are fully readable inside `node_modules` **without any network request**.

### How to activate
Run `leadtype generate --bundle`.

### Artifacts written
| Artifact | Path |
|---|---|
| Agent entry point | `AGENTS.md` (package root) |
| Markdown doc pages | `docs/*.md` (relative paths) |

`AGENTS.md` intentionally ignores `product.agentGuidance` text because that copy is
written for website URL routing, which is irrelevant inside a local package.

### How agents traverse it
1. Open `AGENTS.md` at the package root.
2. Follow relative links (e.g. `./docs/reference/cli.md`) to individual doc pages.
3. No HTTP, no sitemap, no search index required.

---

## 3. What Bundle Mode Skips

Bundle mode deliberately omits every **website-only artifact** — those that require a
live server or are only meaningful for URL-based discovery:

| Skipped artifact | Why it is website-only |
|---|---|
| `llms.txt` | URL-based agent discovery; meaningless as a local file |
| `llms-full.txt` | Root-relative URL; not needed when all pages are local |
| `search-index.json` | Runtime search index for a hosted search endpoint |
| `search-content.json` | Same — feeds the hosted search/answer pipeline |
| `sitemap.xml` | For web crawlers; irrelevant inside `node_modules` |
| `sitemap.md` | Markdown sitemap for HTTP agents |
| `robots.txt` | HTTP crawler rules; has no meaning locally |
| `agent-readability.json` | Metadata artifact for hosted agent verification |

> `isAgentReadabilityArtifactPath` (internal helper) identifies exactly these paths so
> the build never tries to rewrite them as missing markdown pages.

---

## 4. Side-by-Side Summary

| Dimension | Hosted Website Flow | npm Bundle Flow |
|---|---|---|
| **Trigger** | `leadtype generate` | `leadtype generate --bundle` |
| **Agent entry point** | `/llms.txt` (HTTP) | `AGENTS.md` (filesystem) |
| **Link style** | Absolute URLs | Relative paths (`./docs/...`) |
| **Network required?** | Yes | No |
| **Full-context file** | `/llms-full.txt` | ✗ (skipped) |
| **Search index** | ✓ | ✗ (skipped) |
| **Sitemap / robots** | ✓ | ✗ (skipped) |
| **agent-readability.json** | ✓ | ✗ (skipped) |
| **Markdown doc pages** | `/docs/*.md` | `docs/*.md` (relative) |
