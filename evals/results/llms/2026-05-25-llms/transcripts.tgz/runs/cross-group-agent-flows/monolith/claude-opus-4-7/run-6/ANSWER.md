# Cross-group agent flows: hosted website vs npm package bundle

Leadtype produces two complementary agent-readable outputs from the same MDX sources. Each flow targets a different kind of agent and therefore starts from a different entry file and produces a different set of artifacts.

## The two starting files

From `docs/how-it-works.md`:

- **Hosted website flow** — HTTP agents start at **`/llms.txt`** and follow markdown links (the `.md` mirrors under `/docs/`). `/llms.txt` itself points at `/llms-full.txt` as the single all-docs full-context file (see `llms.txt`).
- **npm package bundle flow** — Coding agents working inside an installed npm package start at **`AGENTS.md`** at the package root and follow relative `./docs/*.md` links so docs can be read inside `node_modules` without a network request (`docs/package-docs/bundle.md`).

So the same docs tree has two front doors: a URL-rooted `llms.txt` for hosted access and a path-rooted `AGENTS.md` for offline access.

## What each flow generates

From `docs/quickstart.md` and `docs/reference/cli.md`:

### Website mode (`leadtype generate`)
Writes the full set of HTTP-discoverable artifacts:

- `/llms.txt` (product-level routing map)
- `/docs/llms.txt` (docs-scoped map)
- `/llms-full.txt` (every generated markdown page flattened into one file)
- Markdown mirrors under `/docs/*.md`
- `docs/sitemap.xml` and `docs/sitemap.md`
- `docs/robots.txt`
- `docs/agent-readability.json`
- `docs/search-index.json` and `docs/search-content.json`

With `--json`, the CLI reports these as `llmsTxt`, `docsLlmsTxt`, `llmsFullTxt`, `agentReadabilityJson`, `sitemapXml`, `sitemapMd`, `robotsTxt`, `searchIndex`, and `searchContent`.

### Bundle mode (`leadtype generate --bundle`)
Writes only what makes sense inside `node_modules`:

- `AGENTS.md` at the package root
- `docs/*.md` beneath it, with relative links like `./docs/reference/cli.md`

`generateAgentsMd` intentionally ignores `product.agentGuidance` because that text is written for website URL routing, not local file paths (`docs/reference/llm.md`).

## Website artifacts that bundle mode skips

Per `docs/package-docs/bundle.md`, bundle mode skips every website-only artifact, because none of them are useful when an agent is reading files directly from disk:

- `llms.txt`
- `llms-full.txt`
- Search JSON (`search-index.json`, `search-content.json`)
- Sitemap files (`sitemap.xml`, `sitemap.md`)
- `robots.txt`
- `agent-readability.json`

This list lines up with `isAgentReadabilityArtifactPath` in `docs/reference/llm.md`, which is the same set of paths the website treats as artifact paths that should not be rewritten as missing markdown pages.

## Why two flows instead of one

From `docs/how-it-works.md`: the two flows complement each other. A single package can publish bundled offline docs for consumers reading from `node_modules` **and** a hosted docs website with `llms.txt` for URL-based agents — same MDX sources, two delivery shapes:

| Aspect | Hosted website | npm bundle |
| --- | --- | --- |
| Entry file | `/llms.txt` | `AGENTS.md` |
| Link style | Absolute URL paths (`/docs/...md`) | Relative paths (`./docs/...md`) |
| Full-context file | `/llms-full.txt` | — (skipped) |
| Discovery | `sitemap.xml`, `robots.txt`, `agent-readability.json` | — (skipped) |
| Search | `search-index.json`, `search-content.json` | — (skipped) |
| Transport | HTTP, Accept: text/markdown content negotiation | Local filesystem read inside `node_modules` |

In short: the hosted flow optimizes for URL-discoverable, network-accessible agents; the bundle flow optimizes for a coding agent that already has the package on disk and just needs a stable on-disk entry point (`AGENTS.md`) and relative `.md` links.
