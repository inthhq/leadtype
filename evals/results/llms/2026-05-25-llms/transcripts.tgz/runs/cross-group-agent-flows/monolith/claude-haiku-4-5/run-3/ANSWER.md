# Cross-group Agent Flows: Hosted vs NPM Bundle

## Overview

Leadtype supports two distinct agent-readable artifact flows: a **website mode** for HTTP-based agents and a **bundle mode** for coding agents working inside npm packages. Each flow has a different starting point and generates different sets of artifacts.

## Website Mode (Hosted) Flow

### Starting Point
- **HTTP agents start at `/llms.txt`** and follow markdown links from there

### Generated Artifacts
Website mode (`leadtype generate` without `--bundle` flag) generates the following artifacts:

1. **Root-level agent files:**
   - `/llms.txt` - Product-level agent routing map
   - `/llms-full.txt` - Complete flattened context with all generated markdown docs pages

2. **Docs-scoped files:**
   - `/docs/llms.txt` - Docs-scoped routing map
   - `/docs/*.md` - Markdown mirrors of all MDX pages

3. **Website-specific artifacts:**
   - `docs/sitemap.xml` - XML sitemap
   - `docs/sitemap.md` - Markdown sitemap
   - `docs/robots.txt` - Robots exclusion file
   - `docs/agent-readability.json` - Agent readability metadata
   - `docs/search-index.json` - Static search index
   - `docs/search-content.json` - Search content data

## Bundle Mode (NPM Package) Flow

### Starting Point
- **Coding agents start at `AGENTS.md`** at the package root and follow relative markdown links from there

### Generated Artifacts
Bundle mode (`leadtype generate --bundle`) generates only:

1. **Package root file:**
   - `AGENTS.md` - npm-bundled docs entry point with relative links

2. **Docs files:**
   - `docs/*.md` - Markdown files beneath the package root

### Key Characteristic: Relative Links
Bundle mode uses relative links like `./docs/reference/cli.md` so coding agents can read docs inside `node_modules` without requiring any network requests.

## Artifacts Skipped in Bundle Mode

Bundle mode explicitly skips all website-only artifacts:

- ❌ `llms.txt`
- ❌ `llms-full.txt`
- ❌ `/docs/llms.txt`
- ❌ `docs/sitemap.xml`
- ❌ `docs/sitemap.md`
- ❌ `docs/robots.txt`
- ❌ `docs/agent-readability.json`
- ❌ `docs/search-index.json`
- ❌ `docs/search-content.json`

These are HTTP-specific artifacts that are not needed for offline npm package consumption and would be wasteful to include in node_modules.

## Complementary Flows

The two flows complement each other rather than compete:

- A **hosted docs website** serves HTTP agents that start at `/llms.txt` with full access to the search index, sitemaps, and routing metadata
- An **npm package** publishes bundled offline docs for coding agents that start at `AGENTS.md` with relative links for offline access within node_modules

This design allows a single MDX source to power both:
1. A web-based documentation site with agent discoverability and search
2. An npm package with self-contained, offline-accessible documentation for development environments

## Implementation Detail: Group Organization

Both flows use groups for routing and organization:
- Groups determine sidebar position, llms.txt sections, search metadata, and AGENTS.md grouping
- The root `/llms-full.txt` fallback contains all generated markdown pages and is not split by group
- Groups are routing hints, not marketing copy or per-group full-context files
