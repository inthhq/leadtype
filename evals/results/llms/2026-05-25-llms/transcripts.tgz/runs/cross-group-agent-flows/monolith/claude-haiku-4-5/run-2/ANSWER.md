# Cross-group Agent Flows: Hosted vs NPM Bundle

## Overview

Leadtype supports two distinct agent flows that complement each other, allowing a package to publish both bundled offline docs for node_modules and a hosted docs website for URL-based agents.

## Hosted Website Flow

**Starting File:** `/llms.txt`

HTTP agents start at the product-level `/llms.txt` file and follow markdown links to navigate the documentation. This flow is designed for agents accessing the documentation through HTTP requests.

### Generated Artifacts in Hosted Mode

Website mode generates the following artifacts:

1. **Core LLM Files:**
   - `/llms.txt` - Product-level entry point for HTTP agents
   - `/docs/llms.txt` - Docs-scoped map for hosted websites
   - `/llms-full.txt` - Comprehensive single file containing every generated markdown docs page

2. **Markdown Mirrors:**
   - `/docs/*.md` - Mirrored markdown files for all documentation pages

3. **Website-Specific Artifacts:**
   - `docs/sitemap.xml` - XML sitemap
   - `docs/sitemap.md` - Markdown sitemap
   - `docs/robots.txt` - Robots exclusion file
   - `docs/agent-readability.json` - Agent readability metadata
   - `docs/search-index.json` - Search index data
   - `docs/search-content.json` - Search content data

## NPM Bundle Flow

**Starting File:** `AGENTS.md`

Coding agents working inside installed npm packages start at `AGENTS.md` and follow relative markdown links (e.g., `./docs/reference/cli.md`). This allows agents to read documentation without requiring network requests.

### Generated Artifacts in Bundle Mode

Bundle mode generates only:

1. **Agent Entry Point:**
   - `AGENTS.md` (at package root) - Entry point for coding agents

2. **Relative Documentation:**
   - `docs/*.md` - Documentation files with relative links (no `./docs/` prefix in paths)

## Key Differences

### Files Each Flow Starts From

| Flow | Starting File | Context |
|------|---------------|---------|
| **Hosted** | `/llms.txt` | HTTP agents accessing docs via URLs |
| **Bundle** | `AGENTS.md` | Coding agents in installed npm packages |

### Website Artifacts Bundle Mode Skips

Bundle mode intentionally skips the following website-only artifacts:

1. **Product-level LLM files:**
   - `llms.txt` (HTTP agents don't apply in node_modules)
   - `llms-full.txt` (full context file for hosted docs)

2. **Website Navigation and Metadata:**
   - `sitemap.xml` (XML sitemap for web crawlers)
   - `sitemap.md` (Markdown sitemap)
   - `robots.txt` (Robot exclusion file)
   - `agent-readability.json` (Agent readability metadata)

3. **Search Infrastructure:**
   - `search-index.json` (Search index)
   - `search-content.json` (Search content)

### Link Format Differences

- **Hosted Flow:** Links point to absolute URLs (e.g., `/docs/reference/cli.md`)
- **Bundle Flow:** Links use relative paths (e.g., `./docs/reference/cli.md`) that work inside `node_modules`

### Configuration Note

Additionally, `generateAgentsMd` intentionally ignores `product.agentGuidance` during bundle generation because that guidance text is specifically written for website URL routing and does not apply to npm package installations.

## Complementary Nature

The two flows are designed to work together seamlessly:

- A package can publish **bundled offline docs** via the npm bundle flow for developers working with installed packages
- The same package can maintain a **hosted docs website** via the hosted flow for URL-based agents and documentation browsers
- Both flows start from different entry points (`AGENTS.md` vs `/llms.txt`) and generate different artifact sets optimized for their respective use cases
