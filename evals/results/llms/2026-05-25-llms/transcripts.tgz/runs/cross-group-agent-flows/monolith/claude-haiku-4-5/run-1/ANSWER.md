# Cross-Group Agent Flows: Hosted vs NPM Bundle

## Overview

Leadtype supports two complementary agent flows for accessing documentation: one for HTTP-based agents accessing a hosted website, and another for coding agents working inside installed npm packages.

## Hosted Website Flow

**Starting Point:** `/llms.txt`

The hosted website flow is designed for HTTP agents that access documentation through URLs:

1. Agents start at `/llms.txt` (the product-level LLM file)
2. Agents follow markdown links between pages
3. This flow generates the following artifacts:
   - `/llms.txt` - product-level entry point
   - `/docs/llms.txt` - docs-scoped map for hosted websites
   - `/llms-full.txt` - all generated markdown pages flattened into one file
   - `/docs/*.md` - markdown mirrors of all documentation pages
   - `/docs/sitemap.xml` - XML sitemap
   - `/docs/sitemap.md` - markdown sitemap
   - `/docs/robots.txt` - robots exclusion file
   - `/docs/agent-readability.json` - agent readability metadata
   - `/docs/search-index.json` - search index
   - `/docs/search-content.json` - search content

## NPM Bundle Flow

**Starting Point:** `AGENTS.md` (at package root)

The npm bundle flow is designed for coding agents working inside installed npm packages:

1. Agents start at `AGENTS.md` located at the package root
2. Agents follow relative links like `./docs/reference/cli.md` to access bundled documentation
3. This enables agents to read docs inside `node_modules` without making network requests
4. AGENTS.md uses relative links that work in offline environments
5. This flow generates the following artifacts:
   - `AGENTS.md` - entry point at package root
   - `docs/*.md` - markdown documentation files beneath the root

## Website Artifacts Skipped in Bundle Mode

Bundle mode intentionally skips the following website-only artifacts:

1. **llms.txt** - Product-level LLM file (used for hosted website entry point)
2. **llms-full.txt** - Full context flattened file (only needed for website)
3. **Search JSON files** - `/docs/search-index.json` and `/docs/search-content.json` (website search functionality)
4. **Sitemap files** - `/docs/sitemap.xml` and `/docs/sitemap.md` (website navigation)
5. **robots.txt** - Search engine directives (website-specific)
6. **agent-readability.json** - Agent readability metadata (website-specific)

## Key Differences

| Aspect | Hosted Website | NPM Bundle |
|--------|---|---|
| **Entry Point** | `/llms.txt` | `AGENTS.md` |
| **Link Style** | Absolute URLs | Relative paths (`./docs/`) |
| **Access Method** | HTTP requests | Offline (node_modules) |
| **Search Support** | Full search artifacts | None |
| **Sitemap** | Yes (XML and MD) | No |
| **Full Context File** | Yes (llms-full.txt) | No |
| **Agent Guidance** | Uses product.agentGuidance | Ignored (not applicable) |

## Complementary Nature

These two flows are designed to be complementary. A single documentation project can publish both:
- A hosted docs website with llms.txt for URL-based HTTP agents
- Bundled offline docs for node_modules with AGENTS.md for coding agents

This allows the same source MDX documentation to serve both use cases without duplication.
