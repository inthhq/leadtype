# Cross-group agent flows: hosted vs npm bundle

Leadtype supports two complementary agent flows:

## Hosted website flow

- **Starting file:** `/llms.txt` at the site root.
- **How agents navigate:** HTTP/URL-based agents read `/llms.txt`, then follow the markdown links it exposes. For broader task-specific context, `/llms.txt` can point agents to `/llms-full.txt`, which contains every generated markdown docs page flattened into one file.
- **Generated website artifacts:** Website mode emits root and docs-scoped agent maps plus website infrastructure, including:
  - `/llms.txt`
  - `/docs/llms.txt`
  - `/llms-full.txt`
  - markdown mirrors under `/docs/*.md`
  - sitemap files such as `/docs/sitemap.xml` and `/docs/sitemap.md`
  - `robots.txt`
  - `agent-readability.json`
  - `search-index.json`
  - `search-content.json`

Groups organize `llms.txt` sections, sidebar/search metadata, and routing hints, but `/llms-full.txt` is not split into per-group full-context files by default.

## npm package bundle flow

- **Starting file:** `AGENTS.md` at the npm package root.
- **How agents navigate:** Coding agents working inside an installed package, such as under `node_modules`, read `AGENTS.md` and follow relative links like `./docs/reference/cli.md` to bundled markdown files.
- **Generated bundle artifacts:** Bundle mode, via `leadtype generate --bundle`, writes:
  - `AGENTS.md`
  - `docs/*.md`

This flow is designed for offline/package-local documentation, so agents do not need a network request to use the docs.

## Website artifacts skipped by bundle mode

Bundle mode skips the website-only artifacts:

- `llms.txt`
- `llms-full.txt`
- search JSON files
- sitemap files
- `robots.txt`
- `agent-readability.json`

In short: hosted docs are discovered from `/llms.txt` over HTTP, while npm-bundled docs are discovered from `AGENTS.md` with relative links inside the package.