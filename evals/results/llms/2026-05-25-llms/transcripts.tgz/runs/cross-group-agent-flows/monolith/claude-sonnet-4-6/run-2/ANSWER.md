# Cross-group Agent Flows: Hosted Website vs npm Bundle

## Overview

Leadtype supports two distinct agent-facing flows, each targeting a different runtime context. The two flows are designed to **complement** each other: a package can publish bundled offline docs for `node_modules` *and* a hosted docs website with `llms.txt` for URL-based agents.

---

## 1. Hosted Website Flow

### Entry Point
HTTP agents (URL-based agents) start at **`/llms.txt`** — the product-level file at the site root. From there they follow markdown links. A docs-scoped **`/docs/llms.txt`** also exists as a group-organised map for agents that navigate within the docs section.

### How It Is Built
Running `leadtype generate` (without `--bundle`) triggers website mode. The pipeline:

1. Reads MDX source pages and their frontmatter.
2. Resolves the group tree for sections and navigation.
3. Flattens MDX components into portable markdown.
4. Writes all website artifacts.

### Artifacts Written
| Artifact | Description |
|---|---|
| `/llms.txt` | Product-level entry point for HTTP agents |
| `/docs/llms.txt` | Docs-scoped map, sectioned by group |
| `/llms-full.txt` | Every generated markdown page flattened into one file |
| `/docs/*.md` | Individual markdown mirrors of each docs page |
| `docs/sitemap.xml` | XML sitemap |
| `docs/sitemap.md` | Markdown sitemap |
| `docs/robots.txt` | Robots configuration (allows `/llms.txt`) |
| `docs/agent-readability.json` | Agent-readability metadata |
| `docs/search-index.json` | Static BM25-style search index |
| `docs/search-content.json` | Search content source |

### Serving Behaviour
The site should serve markdown (instead of HTML) when the `Accept` header contains `text/markdown` or when a known AI user-agent requests a docs page.

---

## 2. npm Package Bundle Flow

### Entry Point
Coding agents working **inside installed npm packages** (i.e., inside `node_modules`) start at **`AGENTS.md`** at the package root and follow **relative links** such as `./docs/reference/cli.md`.

### How It Is Built
Running `leadtype generate --bundle` triggers bundle mode. The `generateAgentsMd` function writes `AGENTS.md`; it intentionally **ignores** `product.agentGuidance` because that text is written for website URL routing, which is irrelevant in an offline `node_modules` context.

### Artifacts Written
| Artifact | Description |
|---|---|
| `AGENTS.md` | Package-root entry point for coding agents; uses relative links |
| `docs/*.md` | Markdown docs pages with relative links that work offline inside `node_modules` |

---

## 3. What Bundle Mode Skips

Bundle mode explicitly **skips all website-only artifacts** because they are meaningless without a live HTTP server:

| Skipped Artifact | Reason Skipped |
|---|---|
| `llms.txt` | HTTP-discovery mechanism; irrelevant inside `node_modules` |
| `llms-full.txt` | Full-context flat file for URL-based agents only |
| `search-index.json` / `search-content.json` | Static search index is for hosted site runtime queries |
| `sitemap.xml` / `sitemap.md` | Site navigation; requires a hosted URL space |
| `robots.txt` | HTTP crawler directive; not applicable offline |
| `agent-readability.json` | Hosted-site readability metadata; not needed offline |

These paths are also identified programmatically by `isAgentReadabilityArtifactPath`, which prevents them from being mistakenly rewritten as missing markdown pages during the build.

---

## Summary Table

| Aspect | Hosted Website Flow | npm Bundle Flow |
|---|---|---|
| **Triggered by** | `leadtype generate` | `leadtype generate --bundle` |
| **Agent entry point** | `/llms.txt` (HTTP URL) | `AGENTS.md` (relative file path) |
| **Link style** | Absolute URLs | Relative paths (`./docs/...`) |
| **Target agent type** | HTTP / URL-based agents | Coding agents in `node_modules` |
| **Markdown mirrors** | `/docs/*.md` | `docs/*.md` |
| **Full-context file** | `/llms-full.txt` ✅ | ❌ skipped |
| **Search index** | ✅ generated | ❌ skipped |
| **Sitemap files** | ✅ generated | ❌ skipped |
| **robots.txt** | ✅ generated | ❌ skipped |
| **agent-readability.json** | ✅ generated | ❌ skipped |
| **Network required** | Yes | No (fully offline) |
