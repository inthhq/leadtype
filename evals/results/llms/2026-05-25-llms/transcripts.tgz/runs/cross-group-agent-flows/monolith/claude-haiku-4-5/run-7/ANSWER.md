# Cross-group Agent Flows: Hosted vs NPM Bundle

## Overview

Leadtype generates two complementary agent flows for documentation: one for HTTP-based agents accessing a hosted website, and one for coding agents working inside installed npm packages. Both flows use groups to organize content, but they differ fundamentally in their starting points and which artifacts they generate.

## Hosted Website Flow

**Starting Point**: `/llms.txt`

The hosted website flow serves agents that discover and read documentation via HTTP requests:

1. HTTP agents start by fetching `/llms.txt` (the product-level index file)
2. From there, agents follow markdown links to explore documentation
3. Agents may also access `/docs/llms.txt` (docs-scoped map)
4. The full context fallback `/llms-full.txt` contains every generated markdown page flattened into a single file for comprehensive context

### Artifacts Generated in Website Mode

The website mode generates the following complete set of artifacts:

- `/llms.txt` - Product-level routing map for HTTP agents
- `/docs/llms.txt` - Docs-scoped routing map
- `/llms-full.txt` - Complete flattened context of all markdown docs pages
- Markdown mirrors under `/docs/*.md` - Generated markdown versions of all MDX pages
- `docs/sitemap.xml` - XML sitemap for web crawling
- `docs/sitemap.md` - Markdown sitemap
- `docs/robots.txt` - Robots exclusion file
- `docs/agent-readability.json` - Agent readability metadata
- `docs/search-index.json` - Search index data
- `docs/search-content.json` - Search content data

## NPM Bundle Flow

**Starting Point**: `AGENTS.md`

The bundle flow serves coding agents that read documentation from inside installed npm packages, without requiring network requests:

1. Coding agents start at `AGENTS.md` at the package root
2. From there, agents follow relative links like `./docs/reference/cli.md`
3. All links are relative paths that work inside `node_modules`
4. No external HTTP calls are needed

### Artifacts Generated in Bundle Mode

Bundle mode uses `leadtype generate --bundle` and writes a minimal set:

- `AGENTS.md` - Package-level entry point with relative links
- `docs/*.md` - Generated markdown files with relative links

## Key Differences: What Bundle Mode Skips

Bundle mode intentionally skips all website-only artifacts:

| Artifact | Website | Bundle | Purpose |
|----------|---------|--------|---------|
| llms.txt | ✓ | ✗ | HTTP routing map (not needed offline) |
| llms-full.txt | ✓ | ✗ | Full context file (not needed for local npm access) |
| sitemap.xml | ✓ | ✗ | Web crawling |
| sitemap.md | ✓ | ✗ | Web navigation |
| robots.txt | ✓ | ✗ | Web bot rules |
| search-index.json | ✓ | ✗ | Static search index (not needed offline) |
| search-content.json | ✓ | ✗ | Search content data (not needed offline) |
| agent-readability.json | ✓ | ✗ | Agent readability metadata |
| AGENTS.md | ✗ | ✓ | Package entry point with relative links |
| docs/*.md | ✓ | ✓ | Generated markdown (both flows need these) |

## Design Philosophy

The two flows complement each other:

- **Hosted flow** optimizes for HTTP-based discovery and routing via llms.txt, enabling browser-like navigation for LLM agents
- **Bundle flow** optimizes for offline access inside node_modules, using relative links that don't require network I/O

Both flows respect the same **group configuration** for organization and routing:
- Groups drive sidebar position, llms.txt sections, search metadata, and AGENTS.md grouping
- Multiple groups can be assigned to a single page with `group: [a, b]`
- The root `/llms-full.txt` (website only) contains all pages as a fallback when group splitting is not applicable

This dual-artifact strategy allows a single documentation source to serve both URL-based HTTP agents and inline npm package consumers simultaneously.
