# Cross-group agent flows: hosted vs npm bundle

Leadtype supports two complementary agent documentation flows:

## Hosted website flow

- **Agent entrypoint:** `/llms.txt` at the site root.
- **How agents proceed:** HTTP/URL-based agents fetch `/llms.txt`, then follow its markdown links into the generated docs pages, such as `/docs/*.md`, or the full-context fallback `/llms-full.txt` when broad context is needed.
- **Generated website artifacts:** Website mode emits root and docs-scoped LLM maps plus web artifacts, including:
  - `/llms.txt`
  - `/docs/llms.txt`
  - `/llms-full.txt`
  - markdown mirrors under `/docs/*.md`
  - sitemap files, such as `/docs/sitemap.xml` and `/docs/sitemap.md`
  - `robots.txt`
  - `agent-readability.json`
  - `search-index.json`
  - `search-content.json`

## npm package bundle flow

- **Agent entrypoint:** `AGENTS.md` at the package root.
- **How agents proceed:** Coding agents working inside an installed npm package, such as under `node_modules`, read `AGENTS.md` and follow relative links like `./docs/reference/cli.md` to bundled markdown files.
- **Generated bundle artifacts:** Bundle mode, run with `leadtype generate --bundle`, writes:
  - `AGENTS.md`
  - `docs/*.md` files with relative links that work offline inside the package

## What bundle mode skips

Bundle mode skips website-only artifacts because package-installed coding agents do not need HTTP discovery, search metadata, or website routing files. Specifically, bundle mode skips:

- `llms.txt`
- `llms-full.txt`
- search JSON, including `search-index.json` and `search-content.json`
- sitemap files
- `robots.txt`
- `agent-readability.json`

In short: hosted agents start from `/llms.txt` and use website URLs, while npm-bundled coding agents start from `AGENTS.md` and use relative local `docs/*.md` links.