# Cross-group agent flows: hosted website vs npm package bundle

Leadtype emits two complementary sets of artifacts from the same MDX source. Each is designed for a different kind of agent, and each has its own entry point.

## The two flows at a glance

| Aspect | Hosted website flow | npm package bundle flow |
| --- | --- | --- |
| Intended consumer | HTTP-based agents fetching docs over the network | Coding agents reading files inside `node_modules` |
| Build command | `leadtype generate` (default, website mode) | `leadtype generate --bundle` |
| Entry file | `/llms.txt` | `AGENTS.md` at the package root |
| Link style | Absolute URLs and `/docs/*.md` paths discoverable over HTTP | Relative links such as `./docs/reference/cli.md` |
| Network required? | Yes (URL routing) | No (works offline inside `node_modules`) |

Per `docs/how-it-works.md`: *"HTTP agents start at `/llms.txt` and follow markdown links. Coding agents working inside installed npm packages start at `AGENTS.md` and follow relative `docs/*.md` links."*

## Starting files for each flow

### Hosted website flow — starts at `/llms.txt`
An HTTP agent first fetches `/llms.txt`, which lists product-level routing hints and points to:

- `/llms-full.txt` — every generated markdown docs page flattened into a single file (the "all-docs full context").
- `/docs/llms.txt` — the docs-scoped routing map produced alongside the root `llms.txt` by `generateLlmsTxt`.
- `/docs/*.md` — the markdown mirrors of each MDX page, served when `Accept: text/markdown` is requested or when a known AI user agent asks for a docs page.

From there the agent can follow links to specific pages such as `/docs/reference/cli.md`, `/docs/reference/llm.md`, etc.

### npm bundle flow — starts at `AGENTS.md`
When a package is installed, a coding agent opens `AGENTS.md` at the package root. `generateAgentsMd` writes this file with relative links into `./docs/*.md` so everything resolves on the local filesystem inside `node_modules`, with no HTTP request. Notably, `generateAgentsMd` "intentionally ignores `product.agentGuidance` because that text is written for website URL routing" (`docs/reference/llm.md`).

## Full website-mode artifact set

Per `docs/quickstart.md` and `docs/reference/cli.md` (`--json` output keys), default website mode produces:

- `/llms.txt` (`llmsTxt`)
- `/docs/llms.txt` (`docsLlmsTxt`)
- `/llms-full.txt` (`llmsFullTxt`)
- Markdown mirrors under `/docs/*.md`
- `docs/sitemap.xml` (`sitemapXml`)
- `docs/sitemap.md` (`sitemapMd`)
- `docs/robots.txt` (`robotsTxt`)
- `docs/agent-readability.json` (`agentReadabilityJson`)
- `docs/search-index.json` (`searchIndex`)
- `docs/search-content.json` (`searchContent`)

## Full bundle-mode artifact set

Per `docs/package-docs/bundle.md`, `--bundle` writes only:

- `AGENTS.md` at the package root
- `docs/*.md` beneath it (with relative links)

## Website artifacts that bundle mode skips

Bundle mode explicitly omits every URL-routing or web-serving artifact. From `docs/package-docs/bundle.md`:

> "Bundle mode skips website-only artifacts: `llms.txt`, `llms-full.txt`, search JSON, sitemap files, `robots.txt`, and `agent-readability.json`."

Concretely, the following hosted-site artifacts are **not** generated in bundle mode:

1. `/llms.txt` (root product-level routing file)
2. `/docs/llms.txt` (docs-scoped routing map)
3. `/llms-full.txt` (flattened all-docs full context)
4. `docs/sitemap.xml` and `docs/sitemap.md`
5. `docs/robots.txt`
6. `docs/search-index.json` and `docs/search-content.json`
7. `docs/agent-readability.json`

These all correspond to the paths that `isAgentReadabilityArtifactPath` identifies as agent-readability artifacts (`docs/reference/llm.md`) — exactly the set of files that only make sense when docs are served over HTTP. The bundle flow drops them because relative filesystem links from `AGENTS.md` make URL routing, sitemaps, robots rules, and a static search index unnecessary inside `node_modules`.

## Why the two flows coexist

`docs/how-it-works.md` notes that "a package can publish bundled offline docs for `node_modules` and a hosted docs website with `llms.txt` for URL-based agents." The same MDX source feeds both: groups still organize `llms.txt` sections, navigation, search metadata, and `AGENTS.md` grouping (`docs/reference/llm.md`), so authors maintain one set of pages and Leadtype emits the right entry point — `/llms.txt` for the web, `AGENTS.md` for the bundle — for whichever agent shows up.
