# Cross-group agent flows: hosted vs npm bundle

Leadtype supports two complementary agent flows from the same MDX source.

## Hosted website flow

For HTTP/URL-based agents, the flow starts at the site root:

- Start file: `/llms.txt`
- From there, agents follow markdown links to the generated docs mirrors, such as `/docs/*.md`.
- When broader context is needed, `/llms.txt` points to `/llms-full.txt`, which contains every generated markdown docs page flattened into one file.
- Hosted website mode also produces a docs-scoped map at `/docs/llms.txt`.

In this flow, groups organize the routing sections in `llms.txt`, sidebar/search metadata, and other navigation hints. They are routing aids, not separate per-group full-context shards; the root `/llms-full.txt` is the all-docs fallback.

Website mode writes hosted artifacts such as:

- `/llms.txt`
- `/docs/llms.txt`
- `/llms-full.txt`
- markdown mirrors under `/docs/*.md`
- sitemap files, such as `docs/sitemap.xml` and `docs/sitemap.md`
- `robots.txt`
- `agent-readability.json`
- `search-index.json`
- `search-content.json`

## npm package bundle flow

For coding agents working inside an installed npm package, the flow starts from the package root instead of a hosted URL:

- Start file: `AGENTS.md`
- From there, agents follow relative links such as `./docs/reference/cli.md`.
- The docs live inside the package, usually under `docs/*.md`, so agents can read them from `node_modules` without making a network request.

Bundle mode is produced with:

```bash
leadtype generate --bundle
```

It writes:

- `AGENTS.md`
- bundled markdown docs under `docs/*.md`

## Website artifacts skipped by bundle mode

Bundle mode intentionally skips website-only artifacts. It does not emit the hosted discovery/search/sitemap files used by the website flow, including:

- `llms.txt` / hosted LLM maps, including the product-level `/llms.txt` and docs-scoped `/docs/llms.txt`
- `llms-full.txt`
- search JSON, including `search-index.json` and `search-content.json`
- sitemap files, including `sitemap.xml` and `sitemap.md`
- `robots.txt`
- `agent-readability.json`

In short: hosted agents start from `/llms.txt` and use URL-discoverable website artifacts; npm-bundled coding agents start from `AGENTS.md` and use relative local markdown links inside the package.