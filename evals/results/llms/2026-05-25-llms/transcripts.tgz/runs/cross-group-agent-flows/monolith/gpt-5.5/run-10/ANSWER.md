# Cross-group agent flows: hosted vs npm bundle

Leadtype supports two complementary agent flows:

## Hosted website flow

- **Starts from:** `/llms.txt` at the hosted site root.
- **Used by:** HTTP/URL-based agents.
- **How agents navigate:** Agents fetch `/llms.txt` and follow its markdown links into the generated docs mirrors, such as `/docs/*.md`. When task-specific full context is needed, the site can also expose `/llms-full.txt`, which contains every generated markdown docs page in one file.
- **Group behavior:** Groups organize sections in `llms.txt`, sidebar/navigation, search metadata, and routing hints. The `/llms-full.txt` fallback is not split into per-group files by default.
- **Website-mode artifacts:** Website mode writes `/llms.txt`, `/docs/llms.txt`, `/llms-full.txt`, markdown mirrors under `/docs/*.md`, `docs/sitemap.xml`, `docs/sitemap.md`, `docs/robots.txt`, `docs/agent-readability.json`, `docs/search-index.json`, and `docs/search-content.json`.

## npm package bundle flow

- **Starts from:** `AGENTS.md` at the npm package root.
- **Used by:** Coding agents working inside installed packages, for example inside `node_modules`.
- **How agents navigate:** Agents read `AGENTS.md` and follow relative links such as `./docs/reference/cli.md` to bundled `docs/*.md` files. This works offline and does not require a network request.
- **Group behavior:** Groups still organize the generated `AGENTS.md` grouping, but the links are package-relative rather than website URLs.

## Website artifacts skipped by bundle mode

When running `leadtype generate --bundle`, Leadtype writes only `AGENTS.md` and bundled `docs/*.md` files. It skips the website-only artifacts:

- `llms.txt`
- `llms-full.txt`
- search JSON files
- sitemap files
- `robots.txt`
- `agent-readability.json`
