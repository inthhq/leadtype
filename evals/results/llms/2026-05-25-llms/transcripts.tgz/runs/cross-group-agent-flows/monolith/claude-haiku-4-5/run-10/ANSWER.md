# Cross-group agent flows: Hosted vs npm bundle

## Overview

Leadtype supports two distinct agent flow patterns that serve different use cases: **hosted website mode** for HTTP-discoverable agents and **bundle mode** for coding agents working inside installed npm packages.

## Hosted Website Flow

### Starting Point
HTTP agents start at **/llms.txt** (the product-level root file)

### Key Files Generated
The website mode flow generates the following artifact files:
- `/llms.txt` - Product-level routing map for HTTP agents
- `/docs/llms.txt` - Docs-scoped routing map  
- `/llms-full.txt` - Full context file containing every generated markdown docs page flattened into one file
- `/docs/*.md` - Markdown mirrors of all generated docs pages
- `/docs/sitemap.xml` - XML sitemap for crawler discovery
- `/docs/sitemap.md` - Markdown sitemap 
- `/docs/robots.txt` - Robots exclusion directives
- `/docs/agent-readability.json` - Agent readability metadata
- `/docs/search-index.json` - Static search index
- `/docs/search-content.json` - Search content

### Navigation Pattern
HTTP agents fetch `/llms.txt`, read its routing hints (descriptions from frontmatter), and follow markdown links between pages.

---

## npm Bundle Flow

### Starting Point
Coding agents start at **AGENTS.md** (at the package root)

### Key Files Generated
Bundle mode writes:
- **AGENTS.md** - Package-scoped agent entry point at the package root
- **docs/*.md** - Markdown mirrors of all generated docs pages beneath the docs directory

### Navigation Pattern
Agents follow relative links (e.g., `./docs/reference/cli.md`) that work inside `node_modules` without requiring network requests.

### Key Difference in Link Style
Bundle mode uses relative links instead of absolute URLs, enabling offline docs discovery within installed packages.

---

## Website Artifacts Skipped in Bundle Mode

Bundle mode **intentionally skips** these website-only artifacts:

1. **llms.txt** - The product-level routing map (not needed for relative navigation)
2. **llms-full.txt** - The complete flattened docs context (bundles use docs/*.md directly)
3. **Search JSON files** (`search-index.json`, `search-content.json`) - Static search index (bundles assume local or integrated search)
4. **Sitemap files** (`sitemap.xml`, `sitemap.md`) - Crawler discovery metadata
5. **robots.txt** - SEO directives for crawler behavior
6. **agent-readability.json** - Agent readability metadata (not needed for package context)

---

## Complementary Approach

The two flows are **complementary**. A single package can publish:
- **Bundled offline docs** in `node_modules` (via bundle mode) for coding agents that install the package
- **Hosted docs website** with `/llms.txt` (via website mode) for URL-based HTTP agents accessing the documentation site

This dual approach enables flexible agent interaction patterns while serving both online and offline use cases from the same MDX source.

---

## Key Distinction: Product.agentGuidance

An important detail: **generateAgentsMd intentionally ignores `product.agentGuidance`** because that text is written specifically for website URL routing in the hosted flow. Bundle mode focuses on relative package navigation instead.
