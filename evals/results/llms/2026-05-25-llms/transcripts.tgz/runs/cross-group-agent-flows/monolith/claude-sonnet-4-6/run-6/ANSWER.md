# Cross-group agent flows: hosted website vs npm bundle

## Overview

Leadtype produces two distinct agent-readable output modes from the same MDX source:
**website mode** (hosted docs site) and **bundle mode** (`--bundle` flag for npm packages).
The two flows differ in their entry-point files, their linking strategies, and the set of
artifacts each one emits.

---

## 1. Hosted Website Flow

### Entry point
HTTP-based agents start at **`/llms.txt`** at the site root. From there they follow markdown
links to individual docs pages served under `/docs/*.md`.

### How it works
- `generateLlmsTxt` writes both a product-level `/llms.txt` and a docs-scoped `/docs/llms.txt`
  map for hosted websites.
- `generateLLMFullContextFiles` writes `/llms-full.txt`, a single file that flattens every
  generated markdown docs page into one document for full-context consumption.
- The docs pages themselves are markdown mirrors of the MDX source, living under `/docs/*.md`.
- Links inside these files are absolute URL paths (e.g. `/docs/reference/cli.md`), suitable
  for HTTP retrieval.

### Artifacts produced (website mode)
| Artifact | Path |
|---|---|
| Product-level agent map | `/llms.txt` |
| Docs-scoped agent map | `/docs/llms.txt` |
| Full-context flat file | `/llms-full.txt` |
| Markdown page mirrors | `/docs/*.md` |
| XML sitemap | `/docs/sitemap.xml` |
| Markdown sitemap | `/docs/sitemap.md` |
| Robots file | `/docs/robots.txt` |
| Agent-readability metadata | `/docs/agent-readability.json` |
| Search index | `/docs/search-index.json` |
| Search content | `/docs/search-content.json` |

The `--json` CLI flag reports all of these paths via the fields: `llmsTxt`, `docsLlmsTxt`,
`llmsFullTxt`, `agentReadabilityJson`, `sitemapXml`, `sitemapMd`, `robotsTxt`,
`searchIndex`, and `searchContent`.

---

## 2. npm Bundle Flow

### Entry point
Coding agents working inside an installed npm package start at **`AGENTS.md`** at the
**package root** (i.e. inside `node_modules/<package>/AGENTS.md`). From there they follow
**relative** links such as `./docs/reference/cli.md` to reach individual docs pages — no
network request is needed.

### How it works
- `leadtype generate --bundle` writes `AGENTS.md` at the package root and `docs/*.md`
  beneath it.
- `generateAgentsMd` intentionally ignores `product.agentGuidance` because that text is
  written for website URL-routing scenarios, which do not apply inside `node_modules`.
- All links are relative so they resolve correctly regardless of where the package is
  installed on disk.

### Artifacts produced (bundle mode)
| Artifact | Path (relative to package root) |
|---|---|
| Agent entry point | `AGENTS.md` |
| Markdown doc pages | `docs/*.md` |

---

## 3. What Bundle Mode Skips

Bundle mode explicitly omits every artifact that only makes sense for a hosted website.
According to `/docs/package-docs/bundle.md` and confirmed by `isAgentReadabilityArtifactPath`
in `/docs/reference/llm.md`, the skipped artifacts are:

| Skipped artifact | Why it is website-only |
|---|---|
| `llms.txt` | HTTP discovery entry point; meaningless without a public URL |
| `llms-full.txt` | Full-context flat file for URL-based agents |
| `search-index.json` | Static search index served over HTTP |
| `search-content.json` | Search content payload for the hosted search runtime |
| `sitemap.xml` | XML sitemap for crawlers and HTTP agents |
| `sitemap.md` | Markdown sitemap variant for agent navigation over HTTP |
| `robots.txt` | Crawler permissions file; only relevant for HTTP servers |
| `agent-readability.json` | Metadata that identifies artifact paths for hosted agents |

---

## 4. Side-by-side Comparison

| Dimension | Hosted website flow | npm bundle flow |
|---|---|---|
| **Entry-point file** | `/llms.txt` | `AGENTS.md` (package root) |
| **Link style** | Absolute URL paths | Relative file paths (`./docs/…`) |
| **Network required?** | Yes (HTTP) | No (local filesystem) |
| **Full-context file** | `/llms-full.txt` | ✗ (not generated) |
| **Search artifacts** | `search-index.json`, `search-content.json` | ✗ skipped |
| **Sitemap artifacts** | `sitemap.xml`, `sitemap.md` | ✗ skipped |
| **robots.txt** | Generated | ✗ skipped |
| **agent-readability.json** | Generated | ✗ skipped |
| **CLI flag** | `leadtype generate` (default) | `leadtype generate --bundle` |
| **Typical consumer** | HTTP/URL-based AI agent | Coding agent inside node_modules |

---

## 5. How the Two Flows Complement Each Other

The flows are designed to coexist. A package publisher can run:
- `leadtype generate` → produces the hosted docs website with `/llms.txt` for URL-based
  agents visiting the public docs site.
- `leadtype generate --bundle` → produces `AGENTS.md` + `docs/*.md` to ship inside the npm
  package for coding agents that read docs offline from `node_modules`.

Both flows read the same MDX source and frontmatter; Leadtype simply routes the output to
the appropriate artifact set based on the `--bundle` flag.
