# Cross-group Agent Flows: Hosted vs NPM Bundle

## Overview
Leadtype supports two distinct agent flows for accessing documentation:

1. **Hosted Website Flow** - For HTTP-based agents accessing documentation via URLs
2. **NPM Bundle Flow** - For coding agents working inside installed npm packages

These flows complement each other and start from different entry points with different artifact outputs.

## Hosted Website Flow

### Starting Point
**File**: `/llms.txt`

HTTP agents start at the root-level `/llms.txt` file and follow markdown links to discover and navigate documentation.

### Key Artifacts Generated
Website mode writes the following artifacts:
- `/llms.txt` - Product-level entry point for agents
- `/docs/llms.txt` - Docs-scoped map for hosted websites
- `/llms-full.txt` - One comprehensive file containing every generated markdown docs page
- `/docs/*.md` - Markdown mirrors of all documentation pages
- `docs/sitemap.xml` - XML sitemap for discovery
- `docs/sitemap.md` - Markdown sitemap
- `docs/robots.txt` - Robots exclusion file
- `docs/agent-readability.json` - Agent readability metadata
- `docs/search-index.json` - Search index
- `docs/search-content.json` - Search content

### Command
```bash
leadtype generate
```

## NPM Bundle Flow

### Starting Point
**File**: `AGENTS.md`

Coding agents working inside installed npm packages start at `AGENTS.md` located at the package root and follow relative documentation links (e.g., `./docs/reference/cli.md`).

### Key Artifacts Generated
Bundle mode writes only:
- `AGENTS.md` - Package root entry point with relative links for offline access
- `docs/*.md` - Markdown documentation pages with relative links

### Command
```bash
leadtype generate --bundle
```

## Artifacts Skipped in Bundle Mode

Bundle mode intentionally skips all website-only artifacts:
- `llms.txt` - Not needed for relative offline access
- `llms-full.txt` - Not needed for npm package distribution
- `search-index.json` - Not applicable without HTTP serving
- `search-content.json` - Not applicable without HTTP serving
- `sitemap.xml` - Not applicable for local packages
- `sitemap.md` - Not applicable for local packages
- `robots.txt` - Not applicable for npm packages
- `agent-readability.json` - Metadata for website hosting only

## Key Differences Summary

| Aspect | Hosted Website Flow | NPM Bundle Flow |
|--------|-------------------|-----------------|
| **Starting Point** | `/llms.txt` | `AGENTS.md` |
| **Link Type** | Absolute URLs | Relative file paths |
| **Access Method** | HTTP requests (URL-based) | Local file system (node_modules) |
| **Search Support** | Yes (JSON indexes) | No |
| **Navigation Artifacts** | Sitemaps, robots.txt | None |
| **Full Context File** | `/llms-full.txt` | None |
| **Entry Point Count** | Two (`/llms.txt` and `/docs/llms.txt`) | One (`AGENTS.md`) |
| **Package Type** | Hosted website | npm package |

## Design Philosophy

The two flows are complementary and intentionally separate:

1. **Website mode** groups descriptions use `product.agentGuidance` text written for website URL routing
2. **Bundle mode** intentionally ignores `product.agentGuidance` since it's specific to website routing and not relevant for package-local agents
3. Groups are used for routing in both flows, not for sharding artifacts
4. Relative links in `AGENTS.md` enable agents to work inside `node_modules` without network requests
