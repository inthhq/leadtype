# Cross-group agent flows: hosted vs npm bundle

## Overview

Leadtype supports two distinct agent flows depending on how docs are consumed: the **hosted website flow** (for HTTP/URL-based agents) and the **npm package bundle flow** (for coding agents working inside `node_modules`). The two flows are complementary — a package can publish both.

---

## 1. Hosted Website Flow

**Trigger / command:** `leadtype generate` (default, no `--bundle` flag)

### Entry point file

HTTP agents **start at `/llms.txt`** — the product-level file generated at the site root by `generateLlmsTxt`. From there they follow markdown links.

### Full set of website artifacts generated

| Artifact | Path |
|---|---|
| Product-level agent map | `/llms.txt` |
| Docs-scoped agent map | `/docs/llms.txt` |
| Full-context flat file | `/llms-full.txt` |
| Markdown mirrors | `/docs/*.md` |
| Sitemap (XML) | `/docs/sitemap.xml` |
| Sitemap (Markdown) | `/docs/sitemap.md` |
| Robots file | `/docs/robots.txt` |
| Agent readability metadata | `/docs/agent-readability.json` |
| Search index | `/docs/search-index.json` |
| Search content | `/docs/search-content.json` |

### How agents navigate it

- An HTTP agent fetches `/llms.txt` to discover all docs sections and their URLs.
- For any individual page, agents (or browsers) can request it with `Accept: text/markdown` and receive the markdown mirror under `/docs/*.md`.
- `/llms-full.txt` provides every generated markdown page flattened into one file for agents that need full context in a single request.
- `isAgentReadabilityArtifactPath` ensures these artifact paths are never rewritten as missing markdown pages.

---

## 2. npm Package Bundle Flow

**Trigger / command:** `leadtype generate --bundle`

### Entry point file

Coding agents working inside an installed npm package **start at `AGENTS.md`** — written at the **package root** by `generateAgentsMd`. From there they follow **relative links** like `./docs/reference/cli.md`.

### Artifacts generated in bundle mode

| Artifact | Path |
|---|---|
| Agent index | `AGENTS.md` (package root) |
| Markdown docs | `docs/*.md` (relative) |

Relative links mean agents can read docs **inside `node_modules` without any network request**.

> **Note:** `generateAgentsMd` intentionally ignores `product.agentGuidance` because that text is written for website URL routing, which is irrelevant in an offline package context.

---

## Website Artifacts That Bundle Mode Skips

Bundle mode explicitly **does not** generate the following website-only artifacts:

| Skipped artifact | Why it's website-only |
|---|---|
| `llms.txt` | HTTP discovery file; meaningless without a hosted URL |
| `llms-full.txt` | Full-context flat file for URL-based agents |
| Search JSON (`search-index.json`, `search-content.json`) | Runtime search requires a served environment |
| Sitemap files (`sitemap.xml`, `sitemap.md`) | Only relevant for web crawlers / hosted sites |
| `robots.txt` | Only relevant for HTTP crawlers |
| `agent-readability.json` | Hosted metadata; not needed inside `node_modules` |

---

## Summary Comparison

| Dimension | Hosted website flow | npm bundle flow |
|---|---|---|
| **Command** | `leadtype generate` | `leadtype generate --bundle` |
| **Agent entry point** | `/llms.txt` (absolute URL) | `AGENTS.md` (package root, relative) |
| **Link style** | Absolute HTTP URLs | Relative file paths (`./docs/…`) |
| **Network required?** | Yes | No — works offline in `node_modules` |
| **Full-context file** | `/llms-full.txt` | *(skipped)* |
| **Search index** | ✅ generated | ❌ skipped |
| **Sitemap / robots** | ✅ generated | ❌ skipped |
| **agent-readability.json** | ✅ generated | ❌ skipped |

**Sources:** `/docs/how-it-works.md`, `/docs/build/connect-docs-site.md`, `/docs/package-docs/bundle.md`, `/docs/reference/llm.md`, `/docs/quickstart.md`
