# Hosted vs npm-bundled agent flows

## Hosted website flow

- **Starting file:** `/llms.txt` at the site root.
- **How agents navigate:** HTTP/URL-based agents start at `/llms.txt`, use its group/routing hints and markdown links, then follow links to generated markdown mirrors such as `/docs/quickstart.md` or other `/docs/*.md` pages.
- **Full-context option:** When task-specific context needs the whole documentation set, agents can follow `/llms-full.txt`, which contains every generated markdown docs page flattened into one file. Groups organize routing in `llms.txt`, search metadata, navigation, and `AGENTS.md`, but the full-context file is not split per group by default.
- **Website artifacts:** Website mode emits hosted/discoverable files such as `/llms.txt`, `/docs/llms.txt`, `/llms-full.txt`, markdown mirrors under `/docs/*.md`, sitemap files, robots.txt, search JSON, and `agent-readability.json`.

## npm package bundle flow

- **Starting file:** `AGENTS.md` at the npm package root.
- **How agents navigate:** Coding agents working inside an installed package, for example under `node_modules`, start at `AGENTS.md` and follow relative links like `./docs/reference/cli.md` to bundled `docs/*.md` files. This avoids requiring a network request to the hosted docs site.
- **Bundle output:** `leadtype generate --bundle` writes `AGENTS.md` plus `docs/*.md` beneath the package root, using relative links that work inside the package.

## Website artifacts skipped by bundle mode

Bundle mode is intentionally not a hosted-site build. It skips the website-only artifacts, including:

- `/llms.txt`
- `/docs/llms.txt`
- `/llms-full.txt`
- search JSON, such as `search-index.json` and `search-content.json`
- sitemap files, such as `sitemap.xml` and `sitemap.md`
- `robots.txt`
- `agent-readability.json`

In short: hosted agents begin with `/llms.txt` and use URL-addressable website artifacts; npm-bundled coding agents begin with `AGENTS.md` and use local relative `docs/*.md` files only.