# Cross-group agent flows: hosted website vs npm bundle

Leadtype's docs pipeline emits two complementary sets of artifacts from the same MDX sources. Each set serves a different kind of agent, and each has its own entry point.

## Hosted website flow (HTTP agents)

**Starting file:** `/llms.txt` at the site root.

From there, HTTP agents follow markdown links to per-page mirrors. The website build (`leadtype generate`) emits:

- `/llms.txt` — product-level routing map (written by `generateLlmsTxt`)
- `/docs/llms.txt` — docs-scoped map (also from `generateLlmsTxt`)
- `/llms-full.txt` — every generated markdown page flattened into one file (from `generateLLMFullContextFiles`)
- `/docs/*.md` — markdown mirrors of each MDX page
- `docs/sitemap.xml` and `docs/sitemap.md`
- `docs/robots.txt`
- `docs/agent-readability.json`
- `docs/search-index.json` and `docs/search-content.json`

When `--json` is passed, the website-mode result object exposes paths for: `llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, `agentReadabilityJson`, `sitemapXml`, `sitemapMd`, `robotsTxt`, `searchIndex`, and `searchContent`.

This flow assumes URL-based discovery: a docs site serves markdown when `Accept: text/markdown` is requested or when a known AI user agent fetches a docs page, and it serves the agent-readability artifacts as static files.

## npm bundle flow (coding agents inside `node_modules`)

**Starting file:** `AGENTS.md` at the package root.

Bundle mode is activated with `leadtype generate --bundle`. It writes:

- `AGENTS.md` at the package root (from `generateAgentsMd`)
- `docs/*.md` beneath the package root

`AGENTS.md` uses **relative** links like `./docs/reference/cli.md` so coding agents can read docs directly inside `node_modules` without any network request. `generateAgentsMd` intentionally ignores `product.agentGuidance` because that text is written for website URL routing, not local filesystem reads.

## Which website artifacts bundle mode skips

Per `docs/package-docs/bundle.md`, bundle mode **skips all website-only artifacts**:

- `llms.txt`
- `llms-full.txt`
- search JSON (`search-index.json`, `search-content.json`)
- sitemap files (`sitemap.xml`, `sitemap.md`)
- `robots.txt`
- `agent-readability.json`

These match the paths recognized by `isAgentReadabilityArtifactPath` — i.e., the routing/index/discovery surface that only makes sense over HTTP. Bundle mode keeps only what is useful on a local filesystem: the `AGENTS.md` entry point and the `docs/*.md` pages it links to.

## Summary table

| Aspect | Hosted website flow | npm bundle flow |
|---|---|---|
| Command | `leadtype generate` | `leadtype generate --bundle` |
| Agent entry point | `/llms.txt` | `AGENTS.md` |
| Consumer | HTTP/URL-based AI agents | Coding agents reading `node_modules` |
| Link style | Absolute site paths | Relative paths (`./docs/...`) |
| Per-page markdown | `/docs/*.md` | `docs/*.md` (relative to package root) |
| Flattened full context | `/llms-full.txt` | — (skipped) |
| Routing maps | `/llms.txt`, `/docs/llms.txt` | — (skipped) |
| Sitemaps | `sitemap.xml`, `sitemap.md` | — (skipped) |
| `robots.txt` | yes | — (skipped) |
| Search JSON | `search-index.json`, `search-content.json` | — (skipped) |
| `agent-readability.json` | yes | — (skipped) |
| Uses `product.agentGuidance` | yes | no (ignored by `generateAgentsMd`) |

The two flows are designed to complement each other: a package can publish offline bundled docs for `node_modules` consumers while a hosted site exposes `llms.txt` and friends for URL-based agents.
