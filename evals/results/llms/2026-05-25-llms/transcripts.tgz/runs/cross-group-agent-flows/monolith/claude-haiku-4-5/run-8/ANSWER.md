# Cross-Group Agent Flows: Hosted vs NPM Bundle

## Overview

Leadtype supports two distinct agent flows for accessing documentation: a hosted website flow and an npm package bundle flow. Each flow serves different use cases and generates different artifacts.

## Hosted Website Flow

### Starting Point
**HTTP agents start at `/llms.txt`** and follow markdown links to discover and read documentation pages.

### Key Files Generated
The hosted website flow generates the following agent-readable artifacts:
- `/llms.txt` - Product-level index file (starting point for agents)
- `/docs/llms.txt` - Docs-scoped index map
- `/llms-full.txt` - Root full-context file containing every generated markdown page
- `/docs/*.md` - Markdown mirrors of all documentation pages
- `/docs/sitemap.xml` - XML sitemap
- `/docs/sitemap.md` - Markdown sitemap
- `/docs/robots.txt` - Robots configuration
- `/docs/agent-readability.json` - Agent readability metadata
- `/docs/search-index.json` - Search index
- `/docs/search-content.json` - Search content

### Flow Characteristics
- Network-based discovery via HTTP requests
- Uses absolute URLs and markdown links
- Agent discovers available docs through `/llms.txt` routing hints
- Includes rich metadata (sitemaps, search indexes, readability hints)
- Serves documentation from a hosted website

## NPM Bundle Flow

### Starting Point
**Coding agents working inside installed npm packages start at `AGENTS.md`** (located at the package root) and follow relative markdown links to access documentation.

### Key Files Generated
The bundle mode generates a minimal set of artifacts optimized for local, offline access:
- `AGENTS.md` - Package root index file (starting point for bundled agents)
- `docs/*.md` - Relative markdown documentation files

### Link Strategy
- Uses relative links like `./docs/reference/cli.md`
- Works inside `node_modules` without network requests
- Self-contained and offline

## Artifacts Skipped in Bundle Mode

Bundle mode **skips all website-only artifacts**:
- `llms.txt` - Not needed without HTTP routing
- `llms-full.txt` - Not needed without centralized full-context serving
- `search-index.json` - Not included in bundle
- `search-content.json` - Not included in bundle
- `sitemap.xml` - Not needed for offline package
- `sitemap.md` - Not needed for offline package
- `robots.txt` - Not applicable to packages
- `agent-readability.json` - Not needed for bundle delivery

## Key Differences

| Aspect | Hosted Website | NPM Bundle |
|--------|---|---|
| **Agent Type** | HTTP agents | Coding agents in node_modules |
| **Starting Point** | `/llms.txt` | `AGENTS.md` |
| **Link Style** | Absolute URLs | Relative paths (e.g., `./docs/reference/cli.md`) |
| **Discovery** | Via routing hints and link following | Direct relative path access |
| **Network Required** | Yes | No (offline) |
| **Metadata** | Full (sitemaps, search, readability) | Minimal |
| **Use Case** | URL-based agents accessing hosted docs | Code-based agents reading bundled docs in packages |

## Complementary Approach

The two flows are designed to complement each other. A single package can:
1. **Publish bundled offline docs** (`AGENTS.md` + `docs/*.md`) for direct access from `node_modules`
2. **Host docs website** (`/llms.txt` + full artifacts) for URL-based agent discovery

This dual approach maximizes accessibility for different agent architectures and use cases.
