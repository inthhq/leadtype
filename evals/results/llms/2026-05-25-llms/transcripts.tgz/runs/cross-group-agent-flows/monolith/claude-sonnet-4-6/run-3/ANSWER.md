# Cross-group Agent Flows: Hosted Website vs npm Bundle

## Overview

Leadtype supports two distinct agent-readable output modes from the same MDX source:
**website (hosted) mode** and **bundle (npm package) mode**. They are designed to complement
each other — a package can publish bundled offline docs for `node_modules` *and* maintain a
hosted docs site with `llms.txt` for URL-based agents.

---

## 1. Hosted Website Flow

### Entry point
HTTP agents start at **`/llms.txt`** (at the site root).

From there they follow markdown links to:
- `/docs/llms.txt` — a docs-scoped map
- `/llms-full.txt` — every generated markdown page flattened into one file
- Individual markdown mirrors under **`/docs/*.md`**

### How it is triggered
Running `leadtype generate` (without `--bundle`) writes all website artifacts.

### Artifacts produced

| Artifact | Path |
|---|---|
| Product-level agent map | `/llms.txt` |
| Docs-scoped agent map | `/docs/llms.txt` |
| Full-context flat file | `/llms-full.txt` |
| Markdown mirrors | `/docs/*.md` |
| Sitemap (XML) | `/docs/sitemap.xml` |
| Sitemap (Markdown) | `/docs/sitemap.md` |
| Robots file | `/docs/robots.txt` |
| Agent readability metadata | `/docs/agent-readability.json` |
| Search index | `/docs/search-index.json` |
| Search content | `/docs/search-content.json` |

### Serving behaviour
For agent requests the server should return markdown when the `Accept` header contains
`text/markdown` or when a known AI user-agent requests a docs page. All the artifacts
above are kept as static files.

---

## 2. npm Bundle Flow

### Entry point
Coding agents working inside an installed npm package start at **`AGENTS.md`** (at the
package root, i.e. inside `node_modules/<package>/`).

From there they follow **relative links** such as `./docs/reference/cli.md` to reach
individual pages under **`docs/*.md`** — no network request is required.

### How it is triggered
Running `leadtype generate --bundle` switches to bundle mode.

### Artifacts produced

| Artifact | Path (relative to package root) |
|---|---|
| Agent entry point | `AGENTS.md` |
| Individual doc pages | `docs/*.md` |

`AGENTS.md` uses relative links (e.g. `./docs/reference/cli.md`) so that docs are fully
readable offline inside `node_modules`.

> **Note:** `generateAgentsMd` intentionally ignores `product.agentGuidance` because that
> text is written for website URL routing, which is irrelevant in an offline bundle context.

---

## 3. What Bundle Mode Skips

Bundle mode **omits all website-only artifacts**. These files are written by website mode
but are not present in an npm bundle:

| Skipped artifact | Why it is website-only |
|---|---|
| `llms.txt` | URL-discovery entry point for HTTP agents; meaningless without a hosted URL |
| `llms-full.txt` | Full-context file for URL-based agents |
| `docs/sitemap.xml` | HTTP sitemap for crawlers |
| `docs/sitemap.md` | Markdown sitemap for agents |
| `docs/robots.txt` | Crawler policy file; only relevant for hosted sites |
| `docs/agent-readability.json` | Metadata for hosted agent-readability checks |
| `docs/search-index.json` | Static search index; no runtime query engine in a package |
| `docs/search-content.json` | Search content backing the index |

`isAgentReadabilityArtifactPath` identifies exactly these paths so the build does not
accidentally rewrite them as missing markdown pages.

---

## 4. Side-by-side Summary

| Dimension | Hosted Website Flow | npm Bundle Flow |
|---|---|---|
| **CLI command** | `leadtype generate` | `leadtype generate --bundle` |
| **Agent entry file** | `/llms.txt` (absolute URL) | `AGENTS.md` (relative path) |
| **Link style** | Absolute URLs | Relative paths (`./docs/*.md`) |
| **Network required?** | Yes (HTTP) | No (offline inside `node_modules`) |
| **Full-context file** | `/llms-full.txt` | ✗ skipped |
| **Sitemap / robots** | ✓ generated | ✗ skipped |
| **Search JSON** | ✓ generated | ✗ skipped |
| **Agent readability JSON** | ✓ generated | ✗ skipped |
| **Markdown doc pages** | `/docs/*.md` | `docs/*.md` |
