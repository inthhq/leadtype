# Cross-group agent flows: hosted vs npm bundle

Leadtype supports two complementary agent flows:

## Hosted website flow

- **Starting file:** `/llms.txt` at the hosted site root.
- **Agent type:** HTTP/URL-based agents.
- **How it works:** An agent fetches `/llms.txt`, then follows the markdown links it contains, such as links to generated docs markdown pages or the full-context file.
- **Generated website artifacts include:**
  - `/llms.txt`
  - `/docs/llms.txt`
  - `/llms-full.txt`
  - Markdown mirrors under `/docs/*.md`
  - `docs/sitemap.xml`
  - `docs/sitemap.md`
  - `docs/robots.txt`
  - `docs/agent-readability.json`
  - `docs/search-index.json`
  - `docs/search-content.json`

## npm package bundle flow

- **Starting file:** `AGENTS.md` at the package root.
- **Agent type:** Coding agents working inside an installed npm package, such as under `node_modules`.
- **How it works:** The agent reads `AGENTS.md`, then follows relative links like `./docs/reference/cli.md` to bundled markdown docs. This works offline and does not require a network request.
- **Generated bundle artifacts include:**
  - `AGENTS.md`
  - `docs/*.md`

## What bundle mode skips

When using `leadtype generate --bundle`, Leadtype skips website-only artifacts:

- `llms.txt`
- `llms-full.txt`
- Search JSON files
- Sitemap files
- `robots.txt`
- `agent-readability.json`

In short: the hosted flow starts from `/llms.txt` and is designed for URL-discoverable docs websites, while the npm bundle flow starts from `AGENTS.md` and is designed for local package docs with relative links inside `node_modules`.