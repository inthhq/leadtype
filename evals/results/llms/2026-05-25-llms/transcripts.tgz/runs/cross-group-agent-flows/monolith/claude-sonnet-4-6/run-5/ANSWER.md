# Cross-group Agent Flows: Hosted vs npm Bundle

## Overview

Leadtype supports two distinct agent-readable documentation flows. Both start from the same MDX source files, but they produce different output artifacts and are navigated differently depending on whether an agent is making HTTP requests to a hosted website or reading files inside an installed npm package.

---

## 1. Hosted Website Flow

**Entry point:** `/llms.txt` (at the site root)

HTTP-based agents (e.g., LLM agents accessing docs via URL) begin at `/llms.txt`. From there they follow markdown links to explore the documentation.

### Artifacts produced by website mode (`leadtype generate`)

| Artifact | Path |
|---|---|
| Product-level agent index | `/llms.txt` |
| Docs-scoped agent map | `/docs/llms.txt` |
| Full-context flattened file | `/llms-full.txt` |
| Markdown mirrors of each page | `/docs/*.md` |
| XML sitemap | `/docs/sitemap.xml` |
| Markdown sitemap | `/docs/sitemap.md` |
| Robots file | `/docs/robots.txt` |
| Agent-readability metadata | `/docs/agent-readability.json` |
| Search index | `/docs/search-index.json` |
| Search content | `/docs/search-content.json` |

### Navigation pattern
1. Agent fetches `/llms.txt` — the top-level routing index, organized by group.
2. Agent follows markdown links into `/docs/*.md` pages.
3. `/llms-full.txt` is available as a fallback containing every generated markdown page flattened into one file.
4. Agents can also request docs pages directly using `Accept: text/markdown`.

---

## 2. npm Bundle Flow

**Entry point:** `AGENTS.md` (at the package root, inside `node_modules/<package>/`)

Coding agents working inside an installed npm package start at `AGENTS.md` and follow **relative** links to docs pages — no network request required.

### Artifacts produced by bundle mode (`leadtype generate --bundle`)

| Artifact | Path |
|---|---|
| Agent entry point | `AGENTS.md` (package root) |
| Markdown docs pages | `docs/*.md` |

Links inside `AGENTS.md` are relative (e.g., `./docs/reference/cli.md`) so they resolve correctly inside `node_modules` without a base URL.

### Navigation pattern
1. Coding agent reads `AGENTS.md` at the package root.
2. Agent follows relative links like `./docs/reference/cli.md` to read individual docs pages.
3. Everything is offline — no HTTP requests needed.

> **Note:** `generateAgentsMd` intentionally ignores `product.agentGuidance` because that text is written for website URL routing, which does not apply in bundle mode.

---

## 3. Website Artifacts That Bundle Mode Skips

Bundle mode omits all website-only artifacts. These are the files that `leadtype generate --bundle` does **not** produce:

| Skipped Artifact | Reason |
|---|---|
| `llms.txt` | HTTP routing index — not needed without a hosted URL |
| `llms-full.txt` | Full-context file for URL-based agents only |
| `search-index.json` | Static search index — not meaningful inside node_modules |
| `search-content.json` | Search content — same reason |
| `sitemap.xml` | Web crawler / sitemap standard — irrelevant offline |
| `sitemap.md` | Markdown sitemap — same reason |
| `robots.txt` | Web crawler directives — not applicable offline |
| `agent-readability.json` | Website metadata artifact — not needed in packages |

These paths are identified internally by `isAgentReadabilityArtifactPath`, which ensures they are never mistakenly rewritten as missing markdown pages.

---

## 4. Side-by-side Comparison

| Dimension | Hosted Website Flow | npm Bundle Flow |
|---|---|---|
| **Command** | `leadtype generate` | `leadtype generate --bundle` |
| **Agent entry point** | `/llms.txt` | `AGENTS.md` |
| **Link style** | Absolute URLs | Relative paths (e.g., `./docs/…`) |
| **Network required** | Yes (HTTP) | No (local filesystem) |
| **Markdown pages** | `/docs/*.md` | `docs/*.md` |
| **Full-context file** | `/llms-full.txt` ✅ | ❌ skipped |
| **Search JSON** | ✅ produced | ❌ skipped |
| **Sitemap files** | ✅ produced | ❌ skipped |
| **robots.txt** | ✅ produced | ❌ skipped |
| **agent-readability.json** | ✅ produced | ❌ skipped |

---

## Sources

- `/docs/how-it-works.md` — describes both flows and how they complement each other
- `/docs/build/connect-docs-site.md` — details website mode artifacts and agent serving
- `/docs/package-docs/bundle.md` — details bundle mode, entry point, and skipped artifacts
- `/docs/reference/llm.md` — covers `generateLlmsTxt`, `generateLLMFullContextFiles`, `generateAgentsMd`, and `isAgentReadabilityArtifactPath`
- `/docs/quickstart.md` — lists all website-mode output files
