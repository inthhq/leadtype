# Cross-group Agent Flows: Hosted vs NPM Bundle

## Overview

Leadtype supports two complementary agent flows for accessing documentation. The two flows serve different use cases: HTTP-based agents accessing a hosted website vs. coding agents working inside installed npm packages.

## Hosted Website Flow

**Starting Point:** `/llms.txt`

HTTP agents start at the product-level `/llms.txt` file and follow markdown links to navigate the documentation. Groups organize sections within llms.txt and provide routing structure for the website.

**Key Artifacts Generated:**
- `/llms.txt` (product-level entry point)
- `/docs/llms.txt` (docs-scoped map for hosted websites)
- `/llms-full.txt` (one root file containing every generated markdown docs page)
- `/docs/*.md` (markdown mirrors of all documentation)
- `docs/sitemap.xml` (XML sitemap for crawlers)
- `docs/sitemap.md` (Markdown sitemap)
- `docs/robots.txt` (robots directives)
- `docs/agent-readability.json` (metadata for agent readability)
- `docs/search-index.json` and `docs/search-content.json` (search data)

**Generation Command:** `leadtype generate` (without `--bundle` flag)

## NPM Bundle Flow

**Starting Point:** `AGENTS.md` (at package root)

Coding agents working inside installed npm packages start at `AGENTS.md` at the package root and follow relative links like `./docs/reference/cli.md` to navigate documentation. This approach requires no network requests.

**Key Artifacts Generated:**
- `AGENTS.md` (at package root)
- `docs/*.md` (markdown files with relative links compatible with node_modules structure)

**Generation Command:** `leadtype generate --bundle`

## Website Artifacts Skipped in Bundle Mode

Bundle mode intentionally skips all website-only artifacts:
- `llms.txt` (product-level entry point)
- `llms-full.txt` (full context file)
- `docs/llms.txt` (docs-scoped map)
- Search JSON files (`search-index.json`, `search-content.json`)
- Sitemap files (`docs/sitemap.xml`, `docs/sitemap.md`)
- `docs/robots.txt`
- `docs/agent-readability.json`

## Key Differences

| Aspect | Hosted Website | NPM Bundle |
|--------|---|---|
| **Entry Point** | `/llms.txt` | `AGENTS.md` |
| **Agent Type** | HTTP-based agents | Coding agents (node_modules) |
| **Link Style** | Absolute/URL-based | Relative paths |
| **Search Support** | Yes (JSON indices) | No search artifacts |
| **SEO/Crawling** | Yes (sitemap, robots.txt) | No SEO artifacts |
| **Agent Metadata** | Yes (agent-readability.json) | No metadata file |
| **Full Context** | Yes (llms-full.txt) | No full context file |

## Complementary Strategy

A single package can publish both artifacts simultaneously:
- Bundled offline docs for consumers installing the npm package
- Hosted docs website with llms.txt for URL-based agents to access the same documentation

This dual approach maximizes accessibility for different agent types and use cases.
