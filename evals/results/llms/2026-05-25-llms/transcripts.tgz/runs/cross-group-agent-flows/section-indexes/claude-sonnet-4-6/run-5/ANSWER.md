# Cross-group agent flows: hosted vs npm bundle

## Overview

Leadtype generates two distinct agent-readable flows from the same MDX source:
the **hosted website flow** (default `leadtype generate`) and the
**npm package bundle flow** (`leadtype generate --bundle`).

---

## 1. Hosted Website Flow

### Entry-point file

Agents begin at **`/llms.txt`** — the product-level index at the site root.
A docs-scoped companion, **`/docs/llms.txt`**, provides a section-level map.
From those files, agents follow markdown links (`/docs/*.md`) to individual pages.

> *"HTTP agents start at /llms.txt and follow markdown links."*
> — [How it works](/docs/how-it-works.md)

### What `leadtype generate` writes (website mode)

| Artifact | Path |
|---|---|
| Product-level agent index | `/llms.txt` |
| Docs-scoped agent index | `/docs/llms.txt` |
| Full-context bundle | `/llms-full.txt` |
| Markdown mirrors | `/docs/*.md` |
| XML sitemap | `/docs/sitemap.xml` |
| Markdown sitemap | `/docs/sitemap.md` |
| Robots file | `/docs/robots.txt` |
| Agent-readability metadata | `/docs/agent-readability.json` |
| Search index | `/docs/search-index.json` |
| Search content | `/docs/search-content.json` |

All of these are static, HTTP-discoverable artifacts served on the public
website. The CLI's `--json` output names them:
`llmsTxt`, `docsLlmsTxt`, `llmsFullTxt`, `agentReadabilityJson`,
`sitemapXml`, `sitemapMd`, `robotsTxt`, `searchIndex`, and `searchContent`.

---

## 2. npm Package Bundle Flow

### Entry-point file

Agents begin at **`AGENTS.md`** — written at the **package root** (i.e. inside
`node_modules/<package>/AGENTS.md`). From there, agents follow **relative**
links such as `./docs/reference/cli.md` to reach individual docs pages, with
no network request required.

> *"Coding agents working inside installed npm packages start at AGENTS.md
> and follow relative docs/\*.md links."*
> — [How it works](/docs/how-it-works.md)

### What `leadtype generate --bundle` writes

| Artifact | Path |
|---|---|
| Agent entry point | `AGENTS.md` |
| Markdown docs | `docs/*.md` |

`generateAgentsMd` intentionally ignores `product.agentGuidance` because that
text is written for website URL routing, not offline package navigation.

---

## 3. Website Artifacts That Bundle Mode Skips

Bundle mode **omits all website-only artifacts**. The following files are
written in website mode but are **not produced** by `--bundle`:

| Skipped artifact | Reason |
|---|---|
| `llms.txt` | HTTP-discovery index; not meaningful inside `node_modules` |
| `llms-full.txt` | Full-context web bundle; agents use `AGENTS.md` instead |
| `search-index.json` | Static search index; not available offline |
| `search-content.json` | Search content feed; not available offline |
| `sitemap.xml` | Web crawler / XML sitemap |
| `sitemap.md` | Markdown sitemap |
| `robots.txt` | Crawler policy; irrelevant in a package |
| `agent-readability.json` | Website readability metadata |

These are collectively identified by `isAgentReadabilityArtifactPath`, which
marks them so they are never accidentally rewritten as missing markdown pages.

---

## 4. Side-by-side Comparison

| Dimension | Hosted website flow | npm bundle flow |
|---|---|---|
| **Command** | `leadtype generate` | `leadtype generate --bundle` |
| **Agent entry file** | `/llms.txt` (+ `/docs/llms.txt`) | `AGENTS.md` |
| **Link style** | Absolute HTTP URLs | Relative paths (`./docs/…`) |
| **Network required?** | Yes — HTTP fetch | No — works offline in `node_modules` |
| **Full-context file** | `/llms-full.txt` | ✗ not generated |
| **Search artifacts** | `search-index.json`, `search-content.json` | ✗ skipped |
| **Sitemap / robots** | `sitemap.xml`, `sitemap.md`, `robots.txt` | ✗ skipped |
| **Readability metadata** | `agent-readability.json` | ✗ skipped |
| **Markdown docs** | `/docs/*.md` (HTTP-served) | `docs/*.md` (file-system) |

---

## 5. How the Two Flows Complement Each Other

A package can simultaneously:
- publish **bundled offline docs** (`AGENTS.md` + `docs/*.md`) inside the npm
  tarball for coding agents working in `node_modules`, and
- deploy a **hosted docs website** with `/llms.txt` for URL-based agents.

Both flows are generated from the same MDX source. Groups organise sections,
navigation, search metadata, and `AGENTS.md` structure in both cases, but the
per-group full-context files are not published by default — only the single
root `/llms-full.txt` is emitted for website mode.

### Sources
- [How it works](/docs/how-it-works.md)
- [Quickstart](/docs/quickstart.md)
- [Connect a docs site](/docs/build/connect-docs-site.md)
- [Bundle docs into a package](/docs/package-docs/bundle.md)
- [CLI reference](/docs/reference/cli.md)
- [LLM files reference](/docs/reference/llm.md)
