# Cross-group agent flows: hosted website vs npm bundle

Leadtype emits two complementary sets of agent-readable artifacts from a single MDX source. The hosted-website flow is described in the **Build** section (`/docs/build/connect-docs-site.md`), and the npm-bundle flow is described in the **Ship Package Docs** section (`/docs/package-docs/bundle.md`). The **Get Started → How it works** page (`/docs/how-it-works.md`) summarizes how the two flows complement each other.

## Where each flow starts

| Flow | Agent entry point | How the agent navigates |
|---|---|---|
| Hosted website (website mode) | `/llms.txt` at the site root | Follows links into per-section `llms.txt` indexes and then into `/docs/*.md` markdown mirrors over HTTP |
| npm package (bundle mode, `leadtype generate --bundle`) | `AGENTS.md` at the package root | Follows **relative** links like `./docs/reference/cli.md` to read markdown directly inside `node_modules`, with no network request |

From `how-it-works.md`: "HTTP agents start at `/llms.txt` and follow markdown links. Coding agents working inside installed npm packages start at `AGENTS.md` and follow relative `docs/*.md` links."

## Hosted website artifacts (website mode)

According to `docs/build/connect-docs-site.md`, the hosted docs build is responsible for exposing HTTP-discoverable agent files. It generates and serves the following as static artifacts:

- `/llms.txt` (root index for agents)
- `/llms-full.txt` (full-context bundle)
- `/docs/*.md` markdown mirrors (also served when `Accept: text/markdown` is sent, or when a known AI user agent requests a docs page)
- Sitemap files (e.g. `/docs/sitemap.xml`)
- `/robots.txt` (which must allow `/llms.txt`)
- Search JSON
- `agent-readability.json`

Verification checks for this flow include fetching `/llms.txt`, fetching a docs page with `Accept: text/markdown`, checking `/docs/sitemap.xml`, and confirming `/robots.txt` allows `/llms.txt`.

## npm bundle artifacts (bundle mode)

According to `docs/package-docs/bundle.md`, running `leadtype generate --bundle` writes only what an offline coding agent needs inside the published tarball:

- `AGENTS.md` at the package root
- `docs/*.md` beneath it, linked with relative paths like `./docs/reference/cli.md`

## Website artifacts that bundle mode skips

`docs/package-docs/bundle.md` is explicit that bundle mode **skips website-only artifacts**:

- `llms.txt`
- `llms-full.txt`
- Search JSON
- Sitemap files
- `robots.txt`
- `agent-readability.json`

These artifacts only make sense when docs are reachable over HTTP, so they are omitted from the npm tarball. The bundled package keeps only `AGENTS.md` plus the `docs/*.md` markdown that an agent can open directly from `node_modules`.

## Summary

- Hosted flow: starts at `/llms.txt`; ships the full HTTP discovery surface (`llms.txt`, `llms-full.txt`, markdown mirrors, sitemaps, `robots.txt`, search JSON, `agent-readability.json`).
- Bundle flow: starts at `AGENTS.md`; ships only `AGENTS.md` plus relative `docs/*.md`, and intentionally omits every website-only discovery artifact listed above.
