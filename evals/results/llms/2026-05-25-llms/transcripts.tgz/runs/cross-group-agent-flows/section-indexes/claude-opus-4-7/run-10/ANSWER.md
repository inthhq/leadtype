# Cross-group agent flows: hosted website vs npm bundle

Leadtype emits two complementary agent flows from one MDX source. The hosted
website flow targets HTTP-discoverable agents, while the npm bundle flow ships
offline-readable docs inside a package tarball under `node_modules`.

Sources used:
- `/llms.txt` (root index)
- `/docs/get-started/llms.txt` → `/docs/how-it-works.md`
- `/docs/build/llms.txt` → `/docs/build/connect-docs-site.md`
- `/docs/package-docs/llms.txt` → `/docs/package-docs/bundle.md`

## Entry points: where each flow starts

| Flow | Starting file | How agents follow links |
| --- | --- | --- |
| Hosted website | `/llms.txt` at the site root | Follow HTTP links to markdown mirrors under `/docs/*.md`; servers return markdown when `Accept: text/markdown` or a known AI user agent requests a docs page. |
| npm bundle (`leadtype generate --bundle`) | `AGENTS.md` at the package root | Follow **relative** links like `./docs/reference/cli.md`, so a coding agent can read docs inside `node_modules` with no network request. |

From `docs/how-it-works.md`: "HTTP agents start at `/llms.txt` and follow
markdown links. Coding agents working inside installed npm packages start at
`AGENTS.md` and follow relative `docs/*.md` links."

## Website-only artifacts (skipped by bundle mode)

Per `docs/build/connect-docs-site.md`, a hosted site keeps these as static
artifacts:

- `/llms.txt`
- `/llms-full.txt`
- sitemap files (e.g. `/docs/sitemap.xml`)
- `/robots.txt` (must allow `/llms.txt`)
- search JSON
- `agent-readability.json`

Per `docs/package-docs/bundle.md`, **bundle mode skips all of the above**.
Bundle output is intentionally minimal:

- `AGENTS.md` at the package root
- `docs/*.md` mirrors beneath it

The skipped items only make sense over HTTP: `llms.txt` / `llms-full.txt` are
URL-discoverable indexes, sitemaps and `robots.txt` are crawler protocols,
search JSON powers a hosted search UI, and `agent-readability.json` advertises
agent-mode capabilities of the site. Inside `node_modules` an agent already
has direct filesystem access starting from `AGENTS.md`, so those artifacts are
unnecessary.

## How the two flows complement each other

A single package can do both at once (`docs/how-it-works.md`): publish the
bundled offline docs alongside the package for `node_modules` consumers, and
host the website build with `/llms.txt` for URL-based agents. The MDX source
is shared; only the emitted artifacts differ.

### Quick verification

- Hosted site (from `connect-docs-site.md`): fetch `/llms.txt`, fetch a docs
  page with `Accept: text/markdown`, check `/docs/sitemap.xml`, and confirm
  `/robots.txt` allows `/llms.txt`.
- Bundle: confirm `AGENTS.md` and `docs/*.md` exist at the package root with
  relative links, and that none of the website-only artifacts were written.
