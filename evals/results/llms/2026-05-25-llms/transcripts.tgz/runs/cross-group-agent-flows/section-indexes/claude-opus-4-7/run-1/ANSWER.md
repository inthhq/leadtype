# Cross-group agent flows: hosted website vs npm bundle

Leadtype emits two complementary agent-reachable artifact sets from the same MDX source. The hosted website flow is documented in the **Build** group (`/docs/build/connect-docs-site.md`) and the npm bundle flow is documented in the **Ship Package Docs** group (`/docs/package-docs/bundle.md`). `/docs/how-it-works.md` summarizes how the two flows fit together.

## Where each flow starts

### Hosted website flow (HTTP agents)
- **Entry file:** `/llms.txt` at the site root.
- From `llms.txt`, agents follow section indexes (e.g. `/docs/build/llms.txt`) and then page-level markdown mirrors served under `/docs/*.md`.
- The site is expected to negotiate content: serve markdown when `Accept: text/markdown` is requested or when a known AI user agent fetches a docs page.
- Verification checks listed in `connect-docs-site.md`:
  - fetch `/llms.txt`
  - fetch a docs page with `Accept: text/markdown`
  - check `/docs/sitemap.xml`
  - confirm `/robots.txt` allows `/llms.txt`

### npm package bundle flow (coding agents inside `node_modules`)
- **Entry file:** `AGENTS.md` at the package root, produced by `leadtype generate --bundle`.
- `AGENTS.md` uses **relative** links like `./docs/reference/cli.md`, so an agent reads everything from disk inside `node_modules` without any network request.
- Markdown pages live under `docs/*.md` beneath the package root, version-matched to the published tarball.

## Website artifacts that bundle mode skips

Per `/docs/package-docs/bundle.md`, bundle mode intentionally omits the website-only artifacts (they make no sense offline inside an installed package):

| Artifact | Hosted website | npm bundle |
|---|---|---|
| `llms.txt` (root index) | ✅ emitted | ❌ skipped |
| `llms-full.txt` (full-site context bundle) | ✅ emitted | ❌ skipped |
| Search JSON index | ✅ emitted | ❌ skipped |
| Sitemap files (e.g. `/docs/sitemap.xml`) | ✅ emitted | ❌ skipped |
| `robots.txt` | ✅ emitted | ❌ skipped |
| `agent-readability.json` | ✅ emitted | ❌ skipped |
| `AGENTS.md` at package root | ❌ not produced | ✅ produced |
| `docs/*.md` page mirrors | ✅ served via HTTP | ✅ shipped on disk |

## Why two flows

`/docs/how-it-works.md` notes the flows are complementary: a single package can both publish bundled offline docs for `node_modules` consumers and host a docs website with `/llms.txt` for URL-based agents. The split exists because HTTP discovery artifacts (`llms.txt`, sitemap, robots, search index, agent-readability manifest) only have meaning when there is a server to serve them; inside an installed npm tarball the agent already has the filesystem, so it starts from `AGENTS.md` and walks relative links instead.
