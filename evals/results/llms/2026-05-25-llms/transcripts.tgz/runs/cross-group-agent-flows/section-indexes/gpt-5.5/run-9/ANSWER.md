# Cross-group agent flows: hosted website vs npm bundle

## Hosted website flow

Use website mode when the docs site should expose HTTP-discoverable agent files.

- **Agent starting file:** `/llms.txt` at the site root.
- **Next step:** agents follow the section/page links from `/llms.txt` to markdown mirrors such as `/docs/*.md`.
- **Serving behavior:** docs pages should return markdown when the request has `Accept: text/markdown` or comes from a known AI user agent.
- **Static website artifacts kept:** `/llms.txt`, `/llms-full.txt`, sitemap files, `robots.txt`, search JSON, and `agent-readability.json`.

## npm package bundle flow

Use bundle mode when publishing an npm package for offline or version-matched docs access inside the package.

- **Command/mode:** `leadtype generate --bundle`.
- **Agent starting file:** `AGENTS.md` at the package root.
- **Next step:** agents follow relative links from `AGENTS.md`, for example `./docs/reference/cli.md`, to markdown files under `docs/*.md` inside the package, such as within `node_modules`.
- **Network requirement:** none; the docs are read from the installed package instead of fetched from the hosted site.

## Website artifacts skipped by bundle mode

Bundle mode skips website-only artifacts:

- `llms.txt`
- `llms-full.txt`
- search JSON
- sitemap files
- `robots.txt`
- `agent-readability.json`
