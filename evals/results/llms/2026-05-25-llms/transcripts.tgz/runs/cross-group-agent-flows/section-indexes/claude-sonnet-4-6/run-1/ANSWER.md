# Cross-group Agent Flows: Hosted Website vs npm Bundle

## Overview

Leadtype generates two distinct agent-readable flows from the same MDX source. The two flows are designed to complement each other: a hosted docs site serves URL-based (HTTP) agents, while an npm bundle serves coding agents working offline inside `node_modules`.

---

## 1. Hosted Website Flow

### Entry Point / Starting File

HTTP agents start at **`/llms.txt`** — the product-level index at the site root. From there they follow links to section-level indexes (e.g. `/docs/build/llms.txt`, `/docs/reference/llms.txt`) and then to individual markdown page mirrors (e.g. `/docs/reference/cli.md`).

**Flow summary:**
```
/llms.txt  →  /docs/<section>/llms.txt  →  /docs/<page>.md
```

### How it works

- `generateLlmsTxt` writes the product-level `/llms.txt` **and** the docs-scoped `/docs/llms.txt` map.
- `generateLLMFullContextFiles` writes a single root `/llms-full.txt` containing every generated markdown docs page (a fallback for agents that need full section context).
- The build also exposes markdown mirrors of every docs page under `/docs/*.md`.
- For agent requests, the server serves markdown when the `Accept` header asks for `text/markdown` or when a known AI user agent requests a docs page.

### All Website Artifacts Generated

According to `leadtype generate` (website mode), the following artifacts are written:

| Artifact | Path |
|---|---|
| Root agent index | `/llms.txt` |
| Docs-scoped agent index | `/docs/llms.txt` |
| Full-context fallback | `/llms-full.txt` |
| Markdown page mirrors | `/docs/*.md` |
| XML sitemap | `/docs/sitemap.xml` |
| Markdown sitemap | `/docs/sitemap.md` |
| Robots file | `/robots.txt` |
| Agent-readability manifest | `/docs/agent-readability.json` |
| Search index | `/docs/search-index.json` |
| Search content | `/docs/search-content.json` |

Verification checks include: fetching `/llms.txt`, fetching a docs page with `Accept: text/markdown`, checking `/docs/sitemap.xml`, and confirming `/robots.txt` allows `/llms.txt`.

---

## 2. npm Bundle (Package) Flow

### Entry Point / Starting File

Coding agents working inside an installed npm package start at **`AGENTS.md`** — written at the **package root** — and follow **relative links** like `./docs/reference/cli.md` to reach individual docs pages, all without any network request.

**Flow summary:**
```
AGENTS.md  →  ./docs/<page>.md  (relative, inside node_modules)
```

### How it works

- Triggered by running `leadtype generate --bundle`.
- `generateAgentsMd` writes `AGENTS.md` at the package root.
  - It intentionally **ignores** `product.agentGuidance` because that text is written for website URL routing, which does not apply to offline bundle use.
- All docs pages are written as `docs/*.md` beneath the package root, using relative links so they resolve correctly inside `node_modules`.

### Artifacts Generated in Bundle Mode

| Artifact | Path |
|---|---|
| Agent entry point | `AGENTS.md` (package root) |
| Markdown docs pages | `docs/*.md` |

---

## Website Artifacts Skipped by Bundle Mode

Bundle mode deliberately skips every website-only artifact that requires a live server or HTTP resolution:

| Skipped Artifact | Reason |
|---|---|
| `llms.txt` | HTTP discovery index — not needed offline |
| `llms-full.txt` | Full-context web fallback — not needed offline |
| `sitemap.xml` | Web crawler/sitemap — not applicable |
| `sitemap.md` | Markdown sitemap — not applicable |
| `robots.txt` | HTTP crawler directives — not applicable |
| `agent-readability.json` | Website agent-readability manifest — not applicable |
| `search-index.json` | Static search index — not applicable |
| `search-content.json` | Search content store — not applicable |

The `isAgentReadabilityArtifactPath` API identifies these artifact paths so they are not mistakenly rewritten as missing markdown pages.

---

## Side-by-Side Summary

| Aspect | Hosted Website Flow | npm Bundle Flow |
|---|---|---|
| **Entry file** | `/llms.txt` (site root) | `AGENTS.md` (package root) |
| **Link style** | Absolute URLs | Relative paths (`./docs/...`) |
| **Network required** | Yes (HTTP) | No (local filesystem) |
| **Command** | `leadtype generate` | `leadtype generate --bundle` |
| **Docs pages** | `/docs/*.md` (HTTP-served) | `docs/*.md` (in tarball) |
| **Website artifacts** | All of the above | **None** — all skipped |
| **Use case** | URL-based / HTTP agents | Coding agents inside `node_modules` |

The two flows are designed to complement each other: a single package can publish bundled offline docs for node_modules use **and** maintain a hosted docs website with `llms.txt` for URL-based agents.
