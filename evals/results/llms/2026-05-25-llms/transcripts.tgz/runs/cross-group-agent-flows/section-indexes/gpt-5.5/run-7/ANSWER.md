# Cross-group agent flows: hosted vs npm bundle

## Hosted website flow

For a hosted Leadtype docs site, agents start at the site-root `llms.txt` file, for example:

- `/llms.txt`

That root index points agents to section indexes such as `/docs/build/llms.txt` or `/docs/package-docs/llms.txt`, which then link to page-level markdown files like `/docs/build/connect-docs-site.md`.

In website mode, the docs build should expose HTTP-discoverable agent files:

- `/llms.txt` at the site root
- markdown mirrors under `/docs/*.md`
- static website artifacts such as `/llms-full.txt`, sitemap files, `robots.txt`, search JSON, and `agent-readability.json`

Agents can fetch markdown directly, either by requesting markdown with `Accept: text/markdown` or by being recognized as an AI user agent requesting a docs page.

## npm package bundle flow

For an npm package, Leadtype uses bundle mode:

```sh
leadtype generate --bundle
```

In this flow, agents start from the package-root file:

- `AGENTS.md`

`AGENTS.md` uses relative links, such as:

- `./docs/reference/cli.md`

Those links point to bundled markdown files under the package's local `docs/*.md` directory, so coding agents can read version-matched docs from `node_modules` without making a network request.

## Website artifacts skipped by bundle mode

Bundle mode does not emit website-only artifacts. It skips:

- `llms.txt`
- `llms-full.txt`
- search JSON
- sitemap files
- `robots.txt`
- `agent-readability.json`

In short: hosted website mode starts agents at `/llms.txt` and serves HTTP-discoverable markdown plus website metadata; npm bundle mode starts agents at `AGENTS.md` and includes only local, relative-link markdown docs needed inside the package.