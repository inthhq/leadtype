# Cross-group Agent Flows: Hosted vs NPM Bundle

## Hosted Website Flow

**Starting Files:**
- `/llms.txt` - The root section index that agents fetch first
- Markdown mirrors at `/docs/*.md` - Generated as agent-readable files with Accept: text/markdown support

**Process:**
- Agents discover the docs site by fetching `/llms.txt` at the site root
- The site exposes HTTP-discoverable agent files, making all documentation accessible via network requests
- Static artifacts like `/llms-full.txt`, sitemap files, robots.txt, search JSON, and agent-readability.json are served alongside the markdown

## NPM Bundle Flow

**Starting File:**
- `AGENTS.md` - Located at the package root instead of llms.txt
- Docs at `docs/*.md` - Relative paths beneath the bundle root

**Process:**
- Uses `leadtype generate --bundle` command to create the bundle
- AGENTS.md uses relative links (e.g., `./docs/reference/cli.md`) so agents can read docs inside node_modules without network requests
- Designed for offline agent access within installed packages

## Key Differences

| Aspect | Hosted Website | NPM Bundle |
|--------|---|---|
| **Root Index File** | `/llms.txt` | `AGENTS.md` |
| **Link Style** | Absolute URLs | Relative paths |
| **Access Pattern** | HTTP/Network-based | Local filesystem/offline |
| **Deployment** | Hosted web server | npm tarball inside node_modules |

## Artifacts Skipped in Bundle Mode

Bundle mode skips the following website-only artifacts:
- `llms.txt`
- `llms-full.txt`
- Search JSON
- Sitemap files
- `robots.txt`
- `agent-readability.json`

These artifacts are unnecessary in the bundle mode because agents access docs locally via relative paths rather than discovering them through HTTP endpoints.
