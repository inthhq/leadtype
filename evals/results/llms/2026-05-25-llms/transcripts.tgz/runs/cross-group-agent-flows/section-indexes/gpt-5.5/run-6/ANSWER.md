# Cross-group agent flows: hosted website vs npm bundle

## Hosted website flow

For a hosted docs site, agents start at the HTTP-discoverable root file:

- `/llms.txt` — the product-level routing/index file for the website.

From there, the site points agents at generated markdown docs pages such as `/docs/*.md`. Leadtype also generates a docs-scoped map at `/docs/llms.txt` and may expose `/llms-full.txt` as a root full-context fallback containing every generated markdown docs page.

Website mode is meant for network access: the site should serve markdown when the request asks for `Accept: text/markdown` or when a known AI user agent requests a docs page. It also keeps website artifacts available as static files, including sitemaps, robots.txt, search data, and agent-readability metadata.

## npm package bundle flow

For an npm package, agents start inside the installed package at:

- `AGENTS.md` — written at the package root.

`AGENTS.md` uses relative links, for example `./docs/reference/cli.md`, so coding agents can read version-matched docs directly from `node_modules` without making a network request. Bundle mode writes markdown docs under `docs/*.md` beneath the package root.

## Website artifacts skipped by bundle mode

Bundle mode intentionally skips website-only artifacts:

- `llms.txt`
- `llms-full.txt`
- search JSON
- sitemap files
- `robots.txt`
- `agent-readability.json`

In short: hosted website mode starts from `/llms.txt` and publishes HTTP/static website discovery artifacts; npm bundle mode starts from `AGENTS.md` and keeps only package-local markdown docs needed for offline, version-matched agent use.
