# Hosted vs npm bundle agent flows

Leadtype supports two complementary agent-reading flows from the same MDX source.

## Hosted website flow

Use this when agents can fetch docs over HTTP.

- The agent starts at the site-root `/llms.txt`.
- `/llms.txt` points agents to section indexes such as `/docs/get-started/llms.txt`, `/docs/build/llms.txt`, `/docs/package-docs/llms.txt`, and `/docs/reference/llms.txt`.
- From those indexes, agents follow absolute website markdown links such as `/docs/build/connect-docs-site.md`.
- Website mode also emits markdown mirrors under `/docs/*.md` and can keep static agent/readability artifacts such as `/llms-full.txt`, sitemap files, `robots.txt`, search JSON, and `agent-readability.json`.
- For docs-page requests, the hosted site should serve markdown when the request asks for `text/markdown` or comes from a known AI user agent.

## npm package bundle flow

Use this when docs are shipped inside an npm package for coding agents working in `node_modules` without a network request.

- The agent starts at `AGENTS.md` in the package root.
- `AGENTS.md` links to bundled markdown with relative paths such as `./docs/reference/cli.md`.
- Bundle mode is produced with `leadtype generate --bundle` and writes `AGENTS.md` plus `docs/*.md` beneath the package root.

## Website artifacts skipped by bundle mode

Bundle mode skips website-only artifacts:

- `llms.txt`
- `llms-full.txt`
- search JSON, including search index/content files
- sitemap files
- `robots.txt`
- `agent-readability.json`

In short: hosted URL-based agents begin at `/llms.txt`; offline package-based coding agents begin at `AGENTS.md`. Groups help organize routing, sections, search metadata, and `AGENTS.md`, but the npm bundle does not include the hosted website discovery and indexing artifacts.