# Cross-group agent flows: hosted website vs npm bundle

Leadtype emits two complementary agent-facing flows from a single MDX source. The hosted website flow targets HTTP agents; the npm bundle flow targets coding agents reading files inside `node_modules`. The two are described across the **Get Started**, **Build**, and **Ship Package Docs** sections of the docs site.

## Where each flow starts

| Flow | Entry file | Link style agents follow |
|---|---|---|
| Hosted website | `/llms.txt` at the site root | URL links to `/docs/*.md` mirrors (served as markdown via `Accept: text/markdown` or a known AI user agent) |
| npm package bundle | `AGENTS.md` at the package root | Relative links like `./docs/reference/cli.md` resolved inside `node_modules`, with no network request |

Source: `docs/how-it-works.md` ("HTTP agents start at /llms.txt and follow markdown links. Coding agents working inside installed npm packages start at AGENTS.md and follow relative docs/*.md links.").

## Hosted website flow (Build section)

From `docs/build/connect-docs-site.md`, website mode is used when a docs site should expose HTTP-discoverable agent files. The build is expected to produce and serve the following static website artifacts:

- `/llms.txt` (root entry point for agents)
- `/llms-full.txt` (full-context bundle)
- `/docs/*.md` markdown mirrors of every page
- `/docs/sitemap.xml` and other sitemap files
- `/robots.txt` (must allow `/llms.txt`)
- search JSON
- `agent-readability.json`

Recommended verification: fetch `/llms.txt`, fetch a docs page with `Accept: text/markdown`, check `/docs/sitemap.xml`, and confirm `/robots.txt` allows `/llms.txt`.

## npm bundle flow (Ship Package Docs section)

From `docs/package-docs/bundle.md`, running `leadtype generate --bundle` writes the bundle for publishing inside an npm tarball:

- `AGENTS.md` at the package root (entry point)
- `docs/*.md` beneath it, linked from `AGENTS.md` with relative `./docs/...` paths

Because the bundle is consumed offline from `node_modules`, the links are intentionally relative and need no HTTP server.

## Website artifacts the bundle flow skips

Bundle mode deliberately omits the website-only artifacts. Per `docs/package-docs/bundle.md`, these are skipped:

- `llms.txt`
- `llms-full.txt`
- search JSON
- sitemap files
- `robots.txt`
- `agent-readability.json`

In other words, every discovery/indexing/HTTP-policy artifact from the hosted flow is dropped; only `AGENTS.md` plus the `docs/*.md` markdown pages travel inside the tarball.

## Why both exist

`docs/how-it-works.md` notes that the two flows complement each other: a single package can publish bundled offline docs for `node_modules` consumers and also host a docs website with `llms.txt` for URL-based agents — both emitted from the same MDX pipeline.
