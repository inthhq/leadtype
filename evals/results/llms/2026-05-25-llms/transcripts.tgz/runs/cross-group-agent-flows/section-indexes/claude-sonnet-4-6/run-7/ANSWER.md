# Cross-group Agent Flows: Hosted vs npm Bundle

## Overview

Leadtype produces two distinct agent-readable flows from the same MDX source. The choice of flow depends on how the docs are delivered: a **hosted website** (served over HTTP) or an **npm package bundle** (installed into `node_modules`). The two flows are designed to complement each other — a package can ship both.

---

## 1. Hosted Website Flow

### Entry Point / Starting File
HTTP-based agents (e.g., URL-following LLM crawlers) **start at `/llms.txt`** at the site root. From there, they follow links to section-level index files (e.g., `/docs/build/llms.txt`, `/docs/reference/llms.txt`) and then to individual markdown page mirrors (e.g., `/docs/reference/cli.md`).

### How it Works
1. `leadtype generate` (no `--bundle` flag) runs in **website mode**.
2. MDX pages are converted; frontmatter is read, MDX components are flattened to markdown, and the group tree is resolved.
3. Artifacts are emitted at the site root and under `/docs/`.

### Artifacts Generated (Website Mode)
| Artifact | Purpose |
|---|---|
| `/llms.txt` | Product-level section index; the agent entry point |
| `/docs/llms.txt` | Docs-scoped section map |
| `/llms-full.txt` | Single root file containing every generated markdown page (full-context fallback) |
| `/docs/*.md` | Markdown mirrors of every docs page |
| `/docs/sitemap.xml` | XML sitemap |
| `/docs/sitemap.md` | Markdown sitemap |
| `/docs/robots.txt` | Robots exclusion file (explicitly allows `/llms.txt`) |
| `/docs/agent-readability.json` | Agent readability metadata |
| `/docs/search-index.json` | Static search index |
| `/docs/search-content.json` | Search content payload |

> The `--json` CLI flag causes `leadtype generate` to print a JSON object whose keys name every one of these paths: `llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, `agentReadabilityJson`, `sitemapXml`, `sitemapMd`, `robotsTxt`, `searchIndex`, and `searchContent`.

---

## 2. npm Package Bundle Flow

### Entry Point / Starting File
Coding agents working inside an **installed npm package** (i.e., inside `node_modules`) **start at `AGENTS.md`** at the package root. From there, they follow **relative links** such as `./docs/reference/cli.md` — no network request is needed.

### How it Works
1. `leadtype generate --bundle` runs in **bundle mode**.
2. The same MDX source is processed, but the output targets offline use inside a tarball.
3. `generateAgentsMd` writes `AGENTS.md` — it intentionally ignores `product.agentGuidance` because that text is written for website URL routing (not relevant in `node_modules`).
4. Only the files an offline coding agent needs are emitted.

### Artifacts Generated (Bundle Mode)
| Artifact | Purpose |
|---|---|
| `AGENTS.md` | Package-root entry point; uses relative links for offline access |
| `docs/*.md` | Markdown page files, linked relatively from `AGENTS.md` |

---

## Website Artifacts That Bundle Mode Skips

Bundle mode deliberately omits all website-only artifacts because they depend on HTTP routing, absolute URLs, or server infrastructure that does not exist inside `node_modules`:

| Skipped Artifact | Reason |
|---|---|
| `llms.txt` | HTTP entry point; meaningless without a hosted URL |
| `llms-full.txt` | Full-context HTTP fallback; not needed offline |
| `search-index.json` | Static search index; requires a web server / search endpoint |
| `search-content.json` | Search content payload; same as above |
| `sitemap.xml` | XML sitemap for web crawlers; irrelevant in a package |
| `sitemap.md` | Markdown sitemap; same reason |
| `robots.txt` | HTTP crawler directive; no web server in `node_modules` |
| `agent-readability.json` | HTTP agent metadata; not applicable offline |

The utility function `isAgentReadabilityArtifactPath` identifies exactly these paths so the build system knows not to rewrite any of them as missing markdown pages.

---

## Summary Comparison

| Dimension | Hosted Website Flow | npm Bundle Flow |
|---|---|---|
| **Trigger** | `leadtype generate` | `leadtype generate --bundle` |
| **Agent entry point** | `/llms.txt` (absolute URL) | `AGENTS.md` (package root, relative) |
| **Link style** | Absolute HTTP URLs | Relative paths (`./docs/…`) |
| **Network required?** | Yes | No |
| **Markdown pages** | `/docs/*.md` (HTTP-served) | `docs/*.md` (inside tarball) |
| **Website-only artifacts** | All generated | All **skipped** |
| **Intended agent type** | HTTP/URL-following LLM agents | Coding agents in `node_modules` |
