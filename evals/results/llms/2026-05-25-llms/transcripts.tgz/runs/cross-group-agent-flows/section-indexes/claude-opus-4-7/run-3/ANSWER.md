# Cross-group agent flows: hosted website vs npm package bundle

Leadtype's docs pipeline emits two complementary agent-readable outputs from a single MDX source. Agents enter each flow at a different starting file, and the bundle flow deliberately skips a set of website-only artifacts.

## Hosted website flow (website mode)

HTTP-based agents start at **`/llms.txt`** at the site root (per `docs/how-it-works.md` and `docs/build/connect-docs-site.md`). From there they:

1. Read the top-level section index (`llms.txt`).
2. Follow links into per-section indexes (e.g. `/docs/get-started/llms.txt`, `/docs/build/llms.txt`).
3. Fetch individual page markdown mirrors under `/docs/*.md` (the build serves markdown when `Accept: text/markdown` is set or a known AI user agent requests a docs page).
4. Optionally pull a section's full-context bundle from `/docs/llms-full/<section>.txt` when page-level links are not enough.

Website mode generates and keeps the following static artifacts at known URLs:

- `/llms.txt` (root index)
- `/llms-full.txt` (whole-site full-context bundle)
- Per-section `llms.txt` indexes and `/docs/llms-full/*.txt` section bundles
- Markdown mirrors at `/docs/**/*.md`
- `sitemap` files (e.g. `/docs/sitemap.xml`)
- `robots.txt` (which must allow `/llms.txt`)
- Search JSON
- `agent-readability.json`

Verification of this flow involves fetching `/llms.txt`, fetching a docs page with `Accept: text/markdown`, checking `/docs/sitemap.xml`, and confirming `/robots.txt` allows `/llms.txt`.

## npm package bundle flow (bundle mode)

Coding agents working inside an installed npm package have no network, so they start at **`AGENTS.md`** at the package root (per `docs/how-it-works.md` and `docs/package-docs/bundle.md`). Bundle mode is produced with `leadtype generate --bundle` and writes:

- `AGENTS.md` at the package root — the entry point.
- `docs/*.md` beneath the package root — version-matched markdown pages.

`AGENTS.md` uses **relative** links like `./docs/reference/cli.md` so an agent can resolve docs purely by reading files inside `node_modules`, with no HTTP requests.

## Website artifacts bundle mode skips

Because bundle mode is offline and file-based, it intentionally omits every artifact whose purpose is HTTP discovery or site-wide indexing. Per `docs/package-docs/bundle.md`, bundle mode skips:

- `llms.txt`
- `llms-full.txt`
- Search JSON
- Sitemap files
- `robots.txt`
- `agent-readability.json`

In other words, the per-page markdown (`docs/*.md`) is shared by both flows, while the discovery layer (`llms.txt`, full-context `.txt` bundles, sitemaps, `robots.txt`, search index, and `agent-readability.json`) exists only in the hosted website flow. The bundle replaces that discovery layer with a single `AGENTS.md` entry point using relative links.

## Side-by-side summary

| Aspect | Hosted website flow | npm bundle flow |
|---|---|---|
| Entry file | `/llms.txt` | `AGENTS.md` (package root) |
| Page docs location | `/docs/**/*.md` (served over HTTP) | `docs/*.md` inside the npm tarball |
| Link style | Absolute URL paths | Relative paths like `./docs/reference/cli.md` |
| Transport | HTTP (with `Accept: text/markdown` content negotiation) | Filesystem reads in `node_modules` |
| Discovery indexes | `llms.txt` + per-section `llms.txt` + `llms-full.txt` bundles | None — `AGENTS.md` links directly |
| Also includes | sitemap, `robots.txt`, search JSON, `agent-readability.json` | — (skipped) |

The two flows are designed to complement each other: a package can publish offline bundled docs for `node_modules` agents while a hosted site with `llms.txt` serves URL-based agents from the same MDX source.
