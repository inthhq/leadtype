# Cross-group Agent Flows: Hosted vs NPM Bundle

## Hosted Website Flow

**Starting File:** `/llms.txt`

The hosted website flow is designed for HTTP-discoverable agent files. When using website mode:

1. The build generates `/llms.txt` at the site root as the entry point for agents
2. Markdown mirrors are created under `/docs/*.md`
3. The server serves markdown when the Accept header requests `text/markdown` or when a known AI user agent requests a docs page
4. Full context bundles are provided at `/llms-full.txt` and other section bundles

**Website Artifacts Generated:**
- `/llms.txt` - Main index for agents
- `/llms-full.txt` - Full-context bundles
- `/docs/*.md` - Markdown mirrors of all documentation
- `/docs/sitemap.xml` - XML sitemap
- `/robots.txt` - Robot rules (allows `/llms.txt`)
- `/search` - Search JSON files
- `/agent-readability.json` - Agent readability metadata

## NPM Bundle Flow

**Starting File:** `AGENTS.md` (at package root)

The npm bundle flow is designed for offline agents within npm packages. When using bundle mode (`leadtype generate --bundle`):

1. The build generates `AGENTS.md` at the package root as the entry point
2. Markdown files are written to `docs/*.md` beneath the package root
3. Links in `AGENTS.md` use relative paths (e.g., `./docs/reference/cli.md`) so agents can read docs from `node_modules` without network requests

**Artifacts Skipped in Bundle Mode:**
- `llms.txt` - Not generated
- `llms-full.txt` - Not generated
- `/search` JSON files - Not generated
- Sitemap files - Not generated
- `robots.txt` - Not generated
- `agent-readability.json` - Not generated

## Key Difference Summary

| Aspect | Hosted (Website) | Bundle (NPM) |
|--------|------------------|--------------|
| Entry Point | `/llms.txt` | `AGENTS.md` |
| Link Style | Absolute HTTP paths | Relative file paths |
| Use Case | HTTP-discoverable agents | Offline agents in node_modules |
| Full Context Bundles | `/llms-full.txt` + sections | Not included |
| Discovery Artifacts | sitemap, robots.txt, search | Skipped |
| Deployment | Hosted web server | npm tarball |

The fundamental difference is that **hosted mode relies on HTTP and structured discovery artifacts**, while **bundle mode uses relative file paths for self-contained offline access**.
