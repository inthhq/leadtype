# Cross-group agent flows: hosted website vs npm package bundle

Leadtype's pipeline emits two distinct sets of artifacts from the same MDX
sources. Each flow has a different entry point and a different surface area
that agents are expected to traverse.

## Entry points

| Flow | Agent type | Starts from | Link style |
|------|-----------|-------------|------------|
| Hosted website | HTTP / URL-based agents | `/llms.txt` at the site root | Absolute URL paths to `/docs/*.md` mirrors |
| npm package bundle | Coding agents reading files inside `node_modules` | `AGENTS.md` at the package root | Relative paths like `./docs/reference/cli.md` |

Sources:

- `docs/how-it-works.md`: "HTTP agents start at `/llms.txt` and follow markdown
  links. Coding agents working inside installed npm packages start at
  `AGENTS.md` and follow relative `docs/*.md` links."
- `docs/build/connect-docs-site.md`: website mode generates `/llms.txt` and
  markdown mirrors under `/docs/*.md`.
- `docs/package-docs/bundle.md`: bundle mode writes `AGENTS.md` at the package
  root with `docs/*.md` beneath it, so agents can read docs inside
  `node_modules` without a network request.

## Hosted website flow

Trigger: a normal docs build (no `--bundle`).

The hosted site exposes HTTP-discoverable agent files. According to
`docs/build/connect-docs-site.md`, the build emits and serves:

- `/llms.txt` (root index that agents start from)
- `/llms-full.txt` (full-context bundle)
- `/docs/*.md` markdown mirrors of every page
- `/docs/sitemap.xml` and other sitemap files
- `/robots.txt` (must allow `/llms.txt`)
- Search JSON
- `agent-readability.json`

Content negotiation: when a request's `Accept` header asks for
`text/markdown`, or when a known AI user agent fetches a docs page, the server
returns markdown instead of HTML.

Verification checks suggested by the page:

1. Fetch `/llms.txt`.
2. Fetch a docs page with `Accept: text/markdown`.
3. Fetch `/docs/sitemap.xml`.
4. Confirm `/robots.txt` allows `/llms.txt`.

## npm package bundle flow

Trigger: `leadtype generate --bundle` when publishing an npm package.

According to `docs/package-docs/bundle.md`, bundle mode writes:

- `AGENTS.md` at the package root (the entry point coding agents read)
- `docs/*.md` beneath the package root, linked relatively from `AGENTS.md`

This lets a tool running locally read version-matched docs straight from
`node_modules` without making an HTTP request.

## Website artifacts that bundle mode skips

`docs/package-docs/bundle.md` is explicit: bundle mode skips website-only
artifacts. These exist only in the hosted flow:

- `llms.txt`
- `llms-full.txt`
- Search JSON
- Sitemap files
- `robots.txt`
- `agent-readability.json`

The bundle keeps only the two things an offline coding agent actually needs:
`AGENTS.md` plus the `docs/*.md` files it links to.

## How the flows complement each other

`docs/how-it-works.md` notes the two flows are not alternatives but
complements: a single package can ship bundled offline docs for
`node_modules` consumers *and* publish a hosted docs site with `llms.txt`
for URL-based agents. Both flows are generated from the same MDX sources by
the same pipeline; only the emitted artifact set differs.
