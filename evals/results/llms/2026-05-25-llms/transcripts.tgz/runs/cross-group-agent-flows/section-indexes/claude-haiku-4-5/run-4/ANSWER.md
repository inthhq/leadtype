# Cross-Group Agent Flows: Hosted vs NPM Bundle

## Overview

Leadtype supports two distinct flows for enabling agent access to documentation:

1. **Hosted Website Flow**: For docs sites that expose HTTP-discoverable agent files
2. **NPM Bundle Flow**: For bundling docs inside npm packages for offline agent access

---

## Hosted Website Flow

### Starting Point
- Invoked with: `leadtype generate` (default website mode)
- Generates artifacts at the site root and under `/docs/*` paths

### Key Files Generated
- **Entry point**: `/llms.txt` at the site root
- **Metadata**: `/llms-full.txt` (full-context bundle)
- **Discovery**: `/docs/sitemap.xml` (sitemap files for crawling)
- **Configuration**: `/robots.txt` (allows agent access to /llms.txt)
- **Search**: Search JSON artifacts
- **Metadata**: `/agent-readability.json`
- **Content**: Markdown mirrors under `/docs/*.md` with HTTP serving via text/markdown Accept header

### Operational Details
- Agents fetch `/llms.txt` to discover documentation structure
- Agents request docs pages with `Accept: text/markdown` header
- Site serves markdown when known AI user agents request docs pages
- All artifacts remain static and HTTP-discoverable
- Supports network-dependent agent access

---

## NPM Bundle Flow

### Starting Point
- Invoked with: `leadtype generate --bundle`
- Writes AGENTS.md at the package root and docs under `docs/*.md`

### Key Files Generated
- **Entry point**: `AGENTS.md` (replaces /llms.txt)
- **Content**: Markdown docs beneath `docs/*.md` directory
- **Links**: Relative links like `./docs/reference/cli.md` for offline access

### Artifacts Skipped
Bundle mode explicitly **skips website-only artifacts**:
- `llms.txt` files
- `llms-full.txt` files
- Search JSON
- Sitemap files (robots.txt, sitemap.xml, etc.)
- `agent-readability.json`

### Operational Details
- No HTTP requests required; agents read from `node_modules` locally
- Relative link structure enables offline operation
- Optimized for use in npm packages where network access is not guaranteed
- Lighter footprint with only essential files

---

## Key Differences

| Aspect | Hosted Website | NPM Bundle |
|--------|---|---|
| **Entry Point** | `/llms.txt` (HTTP) | `AGENTS.md` (file system) |
| **Access Method** | HTTP requests with Accept headers | Direct file system reading |
| **Network Required** | Yes | No |
| **Extra Metadata** | Sitemaps, search index, agent-readability.json | None |
| **Link Style** | Absolute/relative to site root | Relative within package |
| **Use Case** | Public docs websites | Offline agent bundles in npm |

Both flows start from the same MDX source but diverge in their artifact generation and deployment strategy to support their respective use cases.
