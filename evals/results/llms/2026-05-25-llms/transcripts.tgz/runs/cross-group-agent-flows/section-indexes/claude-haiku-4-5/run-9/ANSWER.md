# Cross-group Agent Flows: Hosted vs NPM Bundle

## Overview

Leadtype supports two parallel agent flows that start from the same MDX source but diverge at the artifact generation stage. Each flow targets a different type of AI agent with distinct access patterns and deployment contexts.

## Hosted Website Flow

**Starting File:** `/llms.txt` (at site root)

The hosted website flow uses HTTP-based discovery for agents accessing the docs site via network requests:

1. **Entry Point:** Agents start at `/llms.txt` at the site root
2. **Navigation:** Agents follow markdown links from /llms.txt to discover related pages
3. **Markdown Mirrors:** All docs are available as HTTP-discoverable markdown at `/docs/*.md`
4. **Full Context:** Optional `/llms-full.txt` fallback containing all flattened docs pages
5. **Supplementary Artifacts:** Multiple supporting files served alongside markdown:
   - `/llms.txt` - Root index map
   - `/llms-full.txt` - Full context bundle
   - `/docs/sitemap.xml` - XML sitemap for agents
   - `/robots.txt` - Crawler instructions
   - `/docs/search.json` - Search index (optional)
   - `/agent-readability.json` - Agent readability metadata
   - HTTP headers with `Accept: text/markdown` support for known AI user agents

**Key Characteristic:** Network-based discovery using HTTP requests; agents follow links across the web.

## NPM Bundle Flow

**Starting File:** `AGENTS.md` (at package root)

The bundle flow packages offline-accessible docs for coding agents working inside installed npm packages:

1. **Entry Point:** Agents start at `AGENTS.md` at the package root in `node_modules`
2. **Navigation:** Agents follow relative links like `./docs/reference/cli.md` (no network required)
3. **Docs Directory:** All markdown pages available locally under `docs/*.md` relative to AGENTS.md
4. **No Full Context:** Per-group full-context files are not generated
5. **Minimal Footprint:** Only essential artifacts needed for offline access

**Key Characteristic:** Relative-path-based discovery using local file system; no network requests needed.

## Skipped Website-Only Artifacts in Bundle Mode

When using `leadtype generate --bundle`, the following website-specific artifacts are **intentionally skipped**:

1. **llms.txt** - Root HTTP index (replaced by AGENTS.md)
2. **llms-full.txt** - Full context fallback bundle
3. **search.json** - Search index and metadata
4. **sitemap.xml** - XML sitemap for crawlers
5. **robots.txt** - Crawler instructions
6. **agent-readability.json** - Agent readability metadata

Bundle mode also intentionally ignores `product.agentGuidance` text, which is written for website URL routing and doesn't apply to relative paths in installed packages.

## Shared Source, Divergent Outputs

Both flows start from the same MDX source files and use:
- The same frontmatter metadata
- The same group hierarchy for routing and organization
- The same flattened markdown conversion pipeline

However, they diverge in:
- **Access Pattern:** HTTP discovery (hosted) vs relative file paths (bundle)
- **Artifacts Generated:** Full set of website files vs minimal package files
- **Link Format:** Absolute URLs vs relative paths
- **Deployment Context:** Web server vs npm node_modules

## Complementary Deployment

A single documentation source can publish both simultaneously:
- **Hosted:** Website with llms.txt for HTTP-based agents
- **Bundled:** NPM tarball with AGENTS.md for offline/coding agents

This dual-channel approach allows agent access in both internet-connected and offline scenarios without maintaining separate documentation sources.
