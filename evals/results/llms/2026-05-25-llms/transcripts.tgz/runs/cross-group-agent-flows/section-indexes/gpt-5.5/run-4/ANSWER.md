# Hosted vs npm-bundled agent flows

Leadtype supports two complementary agent-reading flows from the same MDX source.

## Hosted website flow

- **Starts from:** `/llms.txt` at the site root.
- Agents use it as the product-level routing map, then follow linked markdown pages or section indexes such as `/docs/<group>/llms.txt`.
- Website mode also emits markdown mirrors under `/docs/*.md` so HTTP agents can fetch markdown directly. The site should serve markdown when `Accept: text/markdown` is requested or when a known AI user agent requests a docs page.
- Website mode keeps static agent/discovery artifacts such as `/llms-full.txt`, sitemap files, `robots.txt`, search JSON, and `agent-readability.json`.
- Groups are routing and organization metadata: they drive `llms.txt` sections, navigation, search metadata, and `AGENTS.md` grouping. They are **not** separate full-context shards by default; the fallback full-context file is the root `/llms-full.txt` containing all generated markdown docs pages.

## npm package bundle flow

- **Starts from:** `AGENTS.md` at the package root inside the npm tarball / `node_modules` install.
- `leadtype generate --bundle` writes `AGENTS.md` plus `docs/*.md` beneath the package root.
- `AGENTS.md` uses relative links, for example `./docs/reference/cli.md`, so coding agents can read version-matched docs offline without making a network request.
- Bundle mode still uses groups for organization in `AGENTS.md`, but the package flow is file-relative rather than URL-based.

## Website artifacts skipped by bundle mode

Bundle mode is intentionally smaller than website mode. It skips website-only artifacts:

- `llms.txt`
- `llms-full.txt`
- search JSON, such as `docs/search-index.json` and `docs/search-content.json`
- sitemap files, such as `docs/sitemap.xml` and `docs/sitemap.md`
- `robots.txt`
- `agent-readability.json`

In short: hosted agents start at `/llms.txt` and follow URL markdown; npm-installed coding agents start at `AGENTS.md` and follow relative `docs/*.md` links. Bundle mode omits the hosted-site discovery, search, sitemap, robots, full-context, and readability artifacts.