# Cross-group Agent Flows: Hosted Website vs npm Bundle

## Overview

Leadtype produces two distinct agent-readable flows from the same MDX source. The flow an agent uses depends on whether it is accessing a **hosted docs website** over HTTP or working inside an **installed npm package** (e.g. inside `node_modules`). These two flows are intentionally complementary: a project can publish both.

---

## 1. Hosted Website Flow

### Entry point
Agents start at **`/llms.txt`** — the product-level index at the site root.

From there they follow links to:
- **`/docs/llms.txt`** — the docs-scoped section map (written by `generateLlmsTxt`)
- Individual **`/docs/*.md`** markdown mirrors of each page
- **`/llms-full.txt`** — a single root file containing every generated markdown docs page flattened together (written by `generateLLMFullContextFiles`), used as a broad fallback

### How it works
- HTTP agents discover `/llms.txt`, read section indexes, and follow markdown links.
- The server serves markdown when the `Accept: text/markdown` header is present or when a known AI user agent requests a docs page.
- Groups organize `llms.txt` sections, navigation, search metadata, and routing hints.

### Static artifacts produced (website mode)
| Artifact | Path |
|---|---|
| Product-level agent index | `/llms.txt` |
| Docs-scoped agent index | `/docs/llms.txt` |
| Full-context bundle | `/llms-full.txt` |
| Markdown page mirrors | `/docs/*.md` |
| XML sitemap | `/docs/sitemap.xml` |
| Markdown sitemap | `/docs/sitemap.md` |
| Robots file | `/docs/robots.txt` |
| Agent readability manifest | `/docs/agent-readability.json` |
| Search index | `/docs/search-index.json` |
| Search content | `/docs/search-content.json` |

The CLI's `--json` output for website mode reports all of these paths: `llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, `agentReadabilityJson`, `sitemapXml`, `sitemapMd`, `robotsTxt`, `searchIndex`, and `searchContent`.

---

## 2. npm Bundle Flow

### Entry point
Agents start at **`AGENTS.md`** — written at the package root by `generateAgentsMd` when `leadtype generate --bundle` is run.

From there they follow:
- **`./docs/*.md`** relative links to individual markdown docs pages beneath the package root

### How it works
- Coding agents working inside an installed npm package (`node_modules/`) read `AGENTS.md` and follow its **relative** links (e.g. `./docs/reference/cli.md`) without any network request.
- `generateAgentsMd` intentionally ignores `product.agentGuidance` because that text is written for website URL routing, which has no meaning inside a local package.
- Groups still organize the structure of `AGENTS.md`, but are not published as per-group full-context files.

### Artifacts produced (bundle mode)
| Artifact | Path |
|---|---|
| Agent entry file | `AGENTS.md` (package root) |
| Markdown docs | `docs/*.md` (relative paths) |

---

## Website Artifacts That Bundle Mode Skips

Bundle mode explicitly skips every artifact that only makes sense in a hosted/HTTP context:

| Skipped Artifact | Reason skipped |
|---|---|
| `llms.txt` | HTTP discovery index — meaningless without a URL |
| `llms-full.txt` | Full-context HTTP bundle — not needed offline |
| `sitemap.xml` / `sitemap.md` | Website crawling — irrelevant in `node_modules` |
| `robots.txt` | Web crawler instructions — irrelevant in `node_modules` |
| `agent-readability.json` | Hosted agent-readability manifest — HTTP-specific |
| `search-index.json` / `search-content.json` | Static search — HTTP-specific feature |

---

## Summary Table

| Dimension | Hosted Website Flow | npm Bundle Flow |
|---|---|---|
| **Entry file** | `/llms.txt` (site root) | `AGENTS.md` (package root) |
| **Secondary entry** | `/docs/llms.txt` | _(none)_ |
| **Page links** | Absolute URL paths (`/docs/*.md`) | Relative paths (`./docs/*.md`) |
| **Full-context file** | `/llms-full.txt` | _(skipped)_ |
| **Network required** | Yes (HTTP) | No (local filesystem) |
| **Sitemap / robots** | Included | Skipped |
| **Search JSON** | Included | Skipped |
| **Agent readability manifest** | Included | Skipped |
| **CLI flag** | _(default)_ | `--bundle` |

Both flows read from the same MDX source; the pipeline selects which output artifacts to emit based on whether `--bundle` is passed to `leadtype generate`.
