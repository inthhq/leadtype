# Cross-group agent flows: hosted website vs npm bundle

Leadtype emits docs for two distinct agent audiences from the same MDX source. The hosted-website flow targets HTTP-based agents, while the bundle flow targets coding agents that read docs from `node_modules` without a network. The two flows are designed to complement each other — a single package can publish both.

## Sources used

- `/llms.txt` (root section index)
- `/docs/get-started/llms.txt` → `/docs/how-it-works.md`
- `/docs/build/llms.txt` → `/docs/build/connect-docs-site.md`
- `/docs/package-docs/llms.txt` → `/docs/package-docs/bundle.md`
- `/docs/reference/llms.txt` → `/docs/reference/llm.md`

## Entry files: where each flow starts

| Flow | Agent type | Entry file | Follow-on links |
|---|---|---|---|
| Hosted website | HTTP / URL-based agents | `/llms.txt` at the site root | Markdown mirrors under `/docs/*.md` (served when `Accept: text/markdown` or a known AI user agent requests a docs page) |
| npm bundle | Coding agents reading inside `node_modules` | `AGENTS.md` at the package root | Relative links like `./docs/reference/cli.md` — no network request needed |

From `docs/how-it-works.md`: "HTTP agents start at /llms.txt and follow markdown links. Coding agents working inside installed npm packages start at AGENTS.md and follow relative docs/*.md links."

## How each flow is produced

- **Website mode** (`docs/build/connect-docs-site.md`): The build generates `/llms.txt` at the site root and markdown mirrors under `/docs/*.md`. `generateLlmsTxt` also writes the docs-scoped `/docs/llms.txt` map. `generateLLMFullContextFiles` writes the root `/llms-full.txt` containing every generated docs page.
- **Bundle mode** (`docs/package-docs/bundle.md`): `leadtype generate --bundle` writes `AGENTS.md` at the package root and `docs/*.md` beneath it. `generateAgentsMd` intentionally ignores `product.agentGuidance` because that text is written for website URL routing, not relative-path lookups.

## Website artifacts that bundle mode skips

According to `docs/package-docs/bundle.md`, bundle mode skips these website-only artifacts:

1. `llms.txt`
2. `llms-full.txt`
3. Search JSON
4. Sitemap files
5. `robots.txt`
6. `agent-readability.json`

This list matches `isAgentReadabilityArtifactPath` in `docs/reference/llm.md`, which identifies the same set of paths as agent-readability artifacts that the website serves as static files.

## Why the split matters

The two flows have different discovery models:

- A hosted site needs HTTP-discoverable entry points (`/llms.txt`), crawl hints (`sitemap.xml`, `robots.txt`), routing-aware guidance (`product.agentGuidance`), and runtime artifacts like search JSON and `agent-readability.json`. Verification means fetching `/llms.txt`, requesting a docs page with `Accept: text/markdown`, checking `/docs/sitemap.xml`, and confirming `/robots.txt` allows `/llms.txt`.
- A tarball inside `node_modules` has no HTTP origin and no crawler. A single `AGENTS.md` plus version-matched relative markdown is enough; URL-shaped artifacts would be dead weight, so they are omitted by design.

## Summary

- Hosted flow: **starts at `/llms.txt`**, fans out to `/docs/*.md`, and is accompanied by `/llms-full.txt`, `/docs/llms.txt`, sitemap files, `robots.txt`, search JSON, and `agent-readability.json`.
- Bundle flow: **starts at `AGENTS.md`**, fans out to relative `./docs/*.md` paths, and **skips** `llms.txt`, `llms-full.txt`, search JSON, sitemap files, `robots.txt`, and `agent-readability.json`.
