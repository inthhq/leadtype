# Cross-group agent flows: hosted website vs npm bundle

Leadtype emits artifacts for two complementary agent flows from the same MDX source. The hosted website flow serves HTTP-discoverable files; the npm bundle flow ships offline docs inside a package tarball so coding agents can read them from `node_modules` without a network request.

Sources used:
- `/llms.txt` (root index)
- `/docs/get-started/llms.txt` → `/docs/how-it-works.md`
- `/docs/build/llms.txt` → `/docs/build/connect-docs-site.md`
- `/docs/package-docs/llms.txt` → `/docs/package-docs/bundle.md`

## Entry points: where each flow starts

| Flow | Agent type | Starting file | Link style followed |
|---|---|---|---|
| Hosted website | HTTP agents (and AI user-agents hitting docs pages) | `/llms.txt` at the site root | Absolute URL paths to markdown mirrors under `/docs/*.md` |
| npm bundle | Coding agents working inside an installed package | `AGENTS.md` at the package root | Relative links like `./docs/reference/cli.md` into bundled `docs/*.md` |

Per `docs/how-it-works.md`: "HTTP agents start at /llms.txt and follow markdown links. Coding agents working inside installed npm packages start at AGENTS.md and follow relative docs/*.md links."

## Website flow (build / "Connect a docs site")

Triggered by wiring Leadtype into a hosted docs build. The site exposes:

- `/llms.txt` (root index for agents)
- `/llms-full.txt` (full-context bundle)
- Markdown mirrors under `/docs/*.md`, served when `Accept: text/markdown` or when a known AI user agent requests a docs page
- `/docs/sitemap.xml` and other sitemap files
- `/robots.txt` (should allow `/llms.txt`)
- Search JSON
- `agent-readability.json`

These are kept as static artifacts. Verification checks include fetching `/llms.txt`, fetching a docs page with `Accept: text/markdown`, checking `/docs/sitemap.xml`, and confirming `/robots.txt` allows `/llms.txt`.

## npm bundle flow ("Ship Package Docs")

Triggered by `leadtype generate --bundle` when publishing an npm package. Bundle mode writes:

- `AGENTS.md` at the package root
- `docs/*.md` beneath it

`AGENTS.md` uses relative links (e.g. `./docs/reference/cli.md`) so agents can read everything directly from `node_modules` with no HTTP fetch.

## Website artifacts that bundle mode skips

Per `docs/package-docs/bundle.md`, bundle mode deliberately omits website-only artifacts:

- `llms.txt`
- `llms-full.txt`
- Search JSON
- Sitemap files
- `robots.txt`
- `agent-readability.json`

These exist only to support URL-based discovery, crawling, and indexing on a hosted site — none of which apply when an agent reads docs from a local `node_modules` install. The two flows are complementary: a package can ship the bundle for offline use *and* publish a hosted docs site with `llms.txt` for URL-based agents.
