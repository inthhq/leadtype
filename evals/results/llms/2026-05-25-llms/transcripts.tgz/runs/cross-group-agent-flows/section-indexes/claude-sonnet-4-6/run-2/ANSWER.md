# Cross-group Agent Flows: Hosted Website vs npm Bundle

## Overview

Leadtype produces two complementary agent-readable flows from the same MDX source: a **hosted website flow** for HTTP-based agents and an **npm bundle flow** for coding agents working inside installed packages. The two flows share the same underlying markdown pages but differ in their entry-point files, link styles, and the set of artifacts they generate.

---

## 1. Hosted Website Flow

### Entry-point file

The hosted flow starts at **`/llms.txt`** (the product-level root), which is placed at the site root and is HTTP-discoverable. A docs-scoped companion, **`/docs/llms.txt`**, is also generated and maps each section to its markdown pages. HTTP agents follow markdown links from those two index files.

> *"HTTP agents start at /llms.txt and follow markdown links."*  
> — [How it works](/docs/how-it-works.md)

### How it is triggered

Running **`leadtype generate`** (without `--bundle`) activates website mode.

### Full set of artifacts generated

| Artifact | Path |
|---|---|
| Root LLM index | `/llms.txt` |
| Docs-scoped LLM index | `/docs/llms.txt` |
| Full-context bundle | `/llms-full.txt` |
| Markdown page mirrors | `/docs/*.md` |
| XML sitemap | `/docs/sitemap.xml` |
| Markdown sitemap | `/docs/sitemap.md` |
| Robots file | `/docs/robots.txt` |
| Agent readability manifest | `/docs/agent-readability.json` |
| Search index | `/docs/search-index.json` |
| Search content | `/docs/search-content.json` |

The `--json` flag makes the CLI print a JSON object with keys `llmsTxt`, `docsLlmsTxt`, `llmsFullTxt`, `agentReadabilityJson`, `sitemapXml`, `sitemapMd`, `robotsTxt`, `searchIndex`, and `searchContent`.

### Link style

All links in `llms.txt` are **absolute URL paths** (e.g., `/docs/reference/cli.md`) because agents fetch them over HTTP.

### Key API functions

- `generateLlmsTxt` — writes `/llms.txt` and `/docs/llms.txt`
- `generateLLMFullContextFiles` — writes `/llms-full.txt`

---

## 2. npm Bundle Flow

### Entry-point file

The bundle flow starts at **`AGENTS.md`**, written at the **package root** inside the npm tarball. Coding agents working inside `node_modules` open `AGENTS.md` first and follow the relative links from there — no network request is needed.

> *"Coding agents working inside installed npm packages start at AGENTS.md and follow relative docs/*.md links."*  
> — [How it works](/docs/how-it-works.md)

### How it is triggered

Running **`leadtype generate --bundle`** activates bundle mode.

### Artifacts generated

| Artifact | Path |
|---|---|
| Agent entry point | `AGENTS.md` (package root) |
| Markdown docs pages | `docs/*.md` |

### Link style

All links in `AGENTS.md` use **relative paths** (e.g., `./docs/reference/cli.md`) so they resolve correctly inside `node_modules` without a base URL.

> Note: `generateAgentsMd` intentionally ignores `product.agentGuidance` because that text is written for website URL routing and is not meaningful in an offline bundle context.

---

## 3. What Bundle Mode Skips (Website-only Artifacts)

Bundle mode deliberately omits every artifact that only makes sense for a hosted website:

| Skipped Artifact | Why it is website-only |
|---|---|
| `llms.txt` | HTTP discovery index; useless without a URL |
| `llms-full.txt` | Full-context HTTP fallback; needs a URL to be fetched |
| `search-index.json` / `search-content.json` | Powers website search; irrelevant offline |
| `sitemap.xml` / `sitemap.md` | SEO/crawler artefacts; no crawler inside `node_modules` |
| `robots.txt` | Crawler instruction file; meaningless in a tarball |
| `agent-readability.json` | Website-level agent readability manifest |

> *"Bundle mode skips website-only artifacts: llms.txt, llms-full.txt, search JSON, sitemap files, robots.txt, and agent-readability.json."*  
> — [Bundle docs into a package](/docs/package-docs/bundle.md)

The helper `isAgentReadabilityArtifactPath` (in the LLM files API) identifies exactly these paths so the build pipeline knows not to rewrite them as missing markdown pages.

---

## 4. Side-by-side Summary

| Dimension | Hosted Website Flow | npm Bundle Flow |
|---|---|---|
| **Entry-point file** | `/llms.txt` (HTTP, site root) | `AGENTS.md` (relative, package root) |
| **Triggered by** | `leadtype generate` | `leadtype generate --bundle` |
| **Link style** | Absolute URL paths | Relative file paths |
| **Requires network** | Yes (HTTP fetch) | No (reads from `node_modules`) |
| **Markdown pages** | `/docs/*.md` (served over HTTP) | `docs/*.md` (inside tarball) |
| **Full-context bundle** | `/llms-full.txt` ✅ | ❌ skipped |
| **Search index** | ✅ | ❌ skipped |
| **Sitemap** | ✅ | ❌ skipped |
| **robots.txt** | ✅ | ❌ skipped |
| **agent-readability.json** | ✅ | ❌ skipped |

The two flows **complement each other**: a package can publish bundled offline docs for `node_modules`-based coding agents *and* maintain a hosted docs website with `llms.txt` for URL-based agents — all from the same MDX source.
