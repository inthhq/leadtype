# Cross-group agent flows: hosted website vs npm bundle

Leadtype supports two complementary agent flows built from the same MDX docs source.

## Hosted website flow

Use website mode when agents can fetch docs over HTTP.

- **Agent entrypoint:** `/llms.txt` at the site root.
- **How agents navigate:** agents read `/llms.txt`, choose a section index such as `/docs/build/llms.txt` or `/docs/reference/llms.txt`, then follow links to markdown mirrors like `/docs/reference/cli.md`.
- **Generated website artifacts:** website mode writes `/llms.txt`, `/docs/llms.txt`, `/llms-full.txt`, markdown mirrors under `/docs/*.md`, sitemap files, robots.txt, agent-readability metadata, and search JSON.
- **Serving behavior:** docs pages should serve markdown when `Accept: text/markdown` is requested or when a known AI user agent requests a docs page. Static artifacts such as `/llms.txt`, `/llms-full.txt`, sitemap files, `robots.txt`, search JSON, and `agent-readability.json` should remain directly fetchable.

## npm package bundle flow

Use bundle mode when docs need to work inside an installed npm package, without a network request.

- **Command:** `leadtype generate --bundle`.
- **Agent entrypoint:** `AGENTS.md` at the package root.
- **How agents navigate:** coding agents working in `node_modules` start at `AGENTS.md` and follow relative links such as `./docs/reference/cli.md` into bundled markdown files under `docs/*.md`.
- **Generated bundle artifacts:** bundle mode writes `AGENTS.md` plus `docs/*.md` inside the package.

## Website artifacts skipped by bundle mode

Bundle mode intentionally skips website-only artifacts:

- `llms.txt`
- `llms-full.txt`
- search JSON
- sitemap files
- `robots.txt`
- `agent-readability.json`

In short: hosted agents start from `/llms.txt` and follow URL-based markdown links, while npm-package agents start from `AGENTS.md` and follow relative local `docs/*.md` links.