# Cross-group Agent Flows: Hosted vs NPM Bundle

## Overview

Leadtype supports two distinct flows for agents to access documentation: a **hosted website flow** and an **npm package bundle flow**. Each flow optimizes for different deployment scenarios and generates different artifacts.

## Hosted Website Flow

**Starting Files:**
- `/llms.txt` (section index at site root)
- `/llms-full.txt` (optional full-context bundles)
- `/docs/*.md` (individual markdown pages)

**How it works:**
The hosted flow is designed for docs sites that should expose HTTP-discoverable agent files. The build generates a navigation structure where agents start at `/llms.txt` to discover available sections, then follow links to individual markdown pages. The site uses content negotiation to serve markdown when Accept headers request `text/markdown` or when known AI user agents request docs pages.

**Supporting Artifacts:**
- `/llms.txt` - Root section index
- `/llms-full.txt` - Pre-flattened section bundles for broader context
- `/docs/sitemap.xml` - XML sitemap for agent discovery
- `/robots.txt` - Crawl instructions
- `/search` (search JSON) - Search index
- `agent-readability.json` - Agent capability metadata

## NPM Bundle Flow

**Starting Files:**
- `AGENTS.md` (at package root)
- `docs/*.md` (beneath package root)

**How it works:**
The bundle flow is designed for npm packages and uses `leadtype generate --bundle`. This mode generates an `AGENTS.md` file at the package root with relative links like `./docs/reference/cli.md`, enabling coding agents to read documentation directly from `node_modules` without requiring network requests.

**Key Characteristic:**
Bundle mode prioritizes offline access for agents consuming the package as a dependency.

## Artifacts Skipped in Bundle Mode

The following website-only artifacts are **not generated** in bundle mode:

1. `llms.txt` - Section index (agents use AGENTS.md instead)
2. `llms-full.txt` - Full-context bundles (not needed for offline access)
3. Search JSON - Search infrastructure (offline doesn't need search)
4. Sitemap files - Sitemap XML (crawl discovery not applicable)
5. `robots.txt` - Crawl instructions (no web crawling in offline mode)
6. `agent-readability.json` - Agent capability metadata (offline context)

## Summary

| Aspect | Hosted Flow | Bundle Flow |
|--------|-------------|-------------|
| **Entry Point** | `/llms.txt` | `AGENTS.md` |
| **Link Style** | HTTP absolute or relative to domain | Relative file paths (`./docs/...`) |
| **Use Case** | HTTP-accessible docs sites | Offline npm packages |
| **Discovery Method** | HTTP requests with content negotiation | Direct file system access |
| **Discovery Artifacts** | Section indexes, sitemaps, robots.txt | Just AGENTS.md |
| **Website Artifacts** | Kept for agent navigation | Skipped |
| **Search Support** | Yes (search JSON) | No |

The critical distinction is that hosted flow optimizes for **discovery and navigation over HTTP**, while bundle flow optimizes for **offline access within node_modules**.
