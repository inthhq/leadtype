# Cross-group Agent Flows: Hosted Website vs npm Bundle

## Overview

Leadtype's pipeline produces two distinct agent-readable flows from the same MDX source. Each flow targets a different kind of agent and starts from a different entry-point file. The key documentation sources for this comparison are spread across multiple sections: **Get Started** (`/docs/how-it-works.md`, `/docs/quickstart.md`), **Build** (`/docs/build/connect-docs-site.md`), **Ship Package Docs** (`/docs/package-docs/bundle.md`), and **Reference** (`/docs/reference/llm.md`, `docs/reference/cli.md`).

---

## 1. Hosted Website Flow

### Entry point
Agents start at **`/llms.txt`** (the product-level index at the site root). A docs-scoped **`/docs/llms.txt`** also exists as a section-level map. From these files, agents follow markdown links to individual page files under `/docs/*.md`.

### How it works
- `leadtype generate` (without `--bundle`) runs in **website mode**.
- The build exposes all files over HTTP. Agents can discover and fetch files by URL.
- When an HTTP agent (or AI user agent) requests a docs page, the server returns the markdown mirror. Requests with `Accept: text/markdown` also receive markdown.
- Groups in `llms.txt` act as routing hints, organizing sections and navigation.
- `generateLlmsTxt` writes both `/llms.txt` and `/docs/llms.txt`.
- `generateLLMFullContextFiles` writes a single `/llms-full.txt` containing every generated markdown page as a flat fallback bundle.

### Website artifacts produced
| Artifact | Purpose |
|---|---|
| `/llms.txt` | Product-level agent entry point |
| `/docs/llms.txt` | Docs-scoped section index |
| `/llms-full.txt` | Root full-context fallback (all pages flattened) |
| `/docs/*.md` | Markdown mirrors of each docs page |
| `/docs/sitemap.xml` | XML sitemap |
| `/docs/sitemap.md` | Markdown sitemap |
| `/docs/robots.txt` | Robots crawl rules (allows `/llms.txt`) |
| `/docs/agent-readability.json` | Agent-readability metadata |
| `/docs/search-index.json` | Static search index |
| `/docs/search-content.json` | Search content source |

When `--json` is passed, `leadtype generate` prints a JSON object referencing all of the above paths (`llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, `agentReadabilityJson`, `sitemapXml`, `sitemapMd`, `robotsTxt`, `searchIndex`, `searchContent`).

---

## 2. npm Bundle Flow

### Entry point
Agents start at **`AGENTS.md`** at the package root (inside `node_modules/<package>/`). From there, agents follow **relative links** like `./docs/reference/cli.md` to reach individual page files under `docs/*.md`.

### How it works
- `leadtype generate --bundle` runs in **bundle mode**.
- The output is written into the npm tarball, not a hosted web server.
- Coding agents (e.g., IDE agents, CI agents) read docs directly from the file system inside `node_modules` — **no network request is needed**.
- `generateAgentsMd` writes `AGENTS.md`. It intentionally ignores `product.agentGuidance` because that text is written for website URL routing, which is irrelevant in a local file context.
- All links in `AGENTS.md` are relative (`./docs/...`) so they resolve correctly wherever the package is installed.

### Bundle artifacts produced
| Artifact | Purpose |
|---|---|
| `AGENTS.md` | Package-root agent entry point |
| `docs/*.md` | Markdown docs pages with relative links |

---

## 3. What Bundle Mode Skips

Bundle mode explicitly **skips all website-only artifacts** because they are meaningless without an HTTP server or URL-based discovery. According to `docs/package-docs/bundle.md` and `docs/reference/llm.md` (`isAgentReadabilityArtifactPath`), the skipped artifacts are:

| Skipped Artifact | Why it's skipped |
|---|---|
| `llms.txt` | URL-based discovery file; no URLs exist in a local package |
| `llms-full.txt` | Full-context HTTP fallback; not needed offline |
| `search-index.json` | Static search index; requires a hosted search endpoint |
| `search-content.json` | Search content source; same reason |
| `sitemap.xml` | XML sitemap for web crawlers |
| `sitemap.md` | Markdown sitemap for web agents |
| `robots.txt` | Crawl rules for HTTP bots |
| `agent-readability.json` | Website agent-readability metadata |

---

## 4. Side-by-Side Comparison

| Dimension | Hosted Website Flow | npm Bundle Flow |
|---|---|---|
| **Trigger** | `leadtype generate` | `leadtype generate --bundle` |
| **Agent entry file** | `/llms.txt` (HTTP URL) | `AGENTS.md` (relative file path) |
| **Secondary entry** | `/docs/llms.txt` | _(none)_ |
| **Link style** | Absolute URLs (`/docs/reference/cli.md`) | Relative paths (`./docs/reference/cli.md`) |
| **Transport** | HTTP (server-hosted) | File system (inside `node_modules`) |
| **Full-context fallback** | `/llms-full.txt` | _(not generated)_ |
| **Search artifacts** | `search-index.json`, `search-content.json` | _(skipped)_ |
| **Sitemap/robots** | `sitemap.xml`, `sitemap.md`, `robots.txt` | _(skipped)_ |
| **Agent-readability** | `agent-readability.json` | _(skipped)_ |
| **Target agent type** | HTTP/URL-based agents | Coding agents (IDE, CI, offline) |
| **`agentGuidance` used?** | Yes (URL routing hints) | No (intentionally ignored) |

---

## 5. How the Two Flows Complement Each Other

As described in `docs/how-it-works.md`, the flows are designed to coexist: a package can publish **bundled offline docs** for agents working inside `node_modules`, while the same project's **hosted docs website** serves `llms.txt` for URL-based agents. Both flows are generated from the same MDX source and group tree — only the output artifacts and entry-point files differ.
