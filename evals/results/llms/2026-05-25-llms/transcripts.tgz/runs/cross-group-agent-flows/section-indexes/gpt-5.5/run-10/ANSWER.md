# Hosted vs npm bundle agent flows

Leadtype supports two complementary agent flows from the same MDX source.

## Hosted website flow

- **Start file:** `/llms.txt` at the website root.
- **How agents navigate:** HTTP/URL-based agents read `/llms.txt`, choose a relevant section such as `/docs/build/llms.txt` or `/docs/package-docs/llms.txt`, then follow links to markdown page mirrors under `/docs/*.md`.
- **Generated website artifacts:** Website mode emits `/llms.txt`, `/docs/llms.txt`, `/llms-full.txt`, markdown mirrors under `/docs/*.md`, sitemap files, `robots.txt`, `agent-readability.json`, and search JSON.
- **Cross-group behavior:** Groups organize `llms.txt` sections, navigation, search metadata, and routing hints. A page can belong to multiple groups, but the root `/llms-full.txt` contains all generated markdown pages and is not split into per-group full-context files by default.

## npm package bundle flow

- **Start file:** `AGENTS.md` at the package root inside the npm package.
- **How agents navigate:** Coding agents working in `node_modules` read `AGENTS.md` and follow relative links such as `./docs/reference/cli.md` to bundled markdown files. This works offline and does not require a network request.
- **Generated bundle artifacts:** `leadtype generate --bundle` writes `AGENTS.md` and `docs/*.md` beneath the package root.
- **Cross-group behavior:** The same group metadata is still used for `AGENTS.md` grouping, so bundled docs can preserve routing/group organization without relying on website URLs.

## Website artifacts skipped by bundle mode

Bundle mode intentionally skips website-only artifacts:

- `llms.txt`
- `llms-full.txt`
- search JSON, including `search-index.json` and `search-content.json`
- sitemap files, such as `sitemap.xml` and `sitemap.md`
- `robots.txt`
- `agent-readability.json`

In short: hosted agents start from `/llms.txt` and traverse HTTP markdown links, while npm-package agents start from `AGENTS.md` and traverse relative `docs/*.md` files bundled inside the package.