# Cross-Group Agent Flows: Hosted vs NPM Bundle

## Overview

Leadtype supports two different agent-readable flows depending on deployment: a **hosted website flow** and an **npm package bundle flow**. Both flows serve agent-readable markdown, but they differ in starting points and artifacts generated.

## Hosted Website Flow

### Starting File
The hosted website flow starts from **/llms.txt** at the site root, which serves as the entry point for agent discovery.

### Generated Artifacts
In hosted website mode, the build generates:
- **/llms.txt** (root entry point with section indexes)
- **/llms-full.txt** (full-context bundle for broader section context)
- **/docs/*.md** (markdown mirrors of all documentation pages)
- **Sitemap files** (/docs/sitemap.xml, etc.)
- **robots.txt** (with allowance for /llms.txt)
- **search JSON** (search index)
- **agent-readability.json** (agent capability metadata)

### Key Characteristics
- HTTP-discoverable agent files
- Agents fetch markdown over the network using Accept: text/markdown headers
- Static artifacts served alongside dynamic content
- Full discovery system using llms.txt as navigation hub

## NPM Package Bundle Flow

### Starting File
The npm package bundle flow starts from **AGENTS.md** at the package root (not HTTP-accessible).

### Generated Artifacts
Bundle mode generates:
- **AGENTS.md** (package root entry point)
- **docs/*.md** (relative documentation mirrors beneath AGENTS.md)

### Key Characteristics
- Self-contained offline distribution inside node_modules
- Uses relative links like `./docs/reference/cli.md`
- Coding agents read docs without network requests
- Optimized for embedded distribution in npm tarballs

## Skipped Website Artifacts

When using bundle mode (`leadtype generate --bundle`), the following website-only artifacts are **skipped**:
- llms.txt
- llms-full.txt
- search JSON
- sitemap files
- robots.txt
- agent-readability.json

These artifacts are unnecessary for offline, self-contained npm package distribution.

## Summary Table

| Aspect | Hosted Website | NPM Bundle |
|--------|---|---|
| **Starting File** | /llms.txt | AGENTS.md |
| **Discovery Mode** | HTTP-discoverable | Offline, relative links |
| **File References** | Absolute URLs | Relative paths (./docs/*) |
| **Network Required** | Yes | No |
| **Index/Sitemap** | llms.txt, llms-full.txt | Not generated |
| **Search Support** | search JSON included | Not generated |
| **Use Case** | Hosted documentation sites | npm package distribution |
| **Entry Point** | Section index system | Package root entry point |

## Verification

For hosted sites, recommended verification includes:
- Fetching /llms.txt
- Fetching a docs page with Accept: text/markdown
- Checking /docs/sitemap.xml
- Confirming /robots.txt allows /llms.txt

For npm bundles, agents simply import or read from the installed node_modules directory using relative path resolution.
