# Cross-Group Agent Flows: Hosted vs npm Bundle

## Overview

Leadtype supports two distinct deployment flows for making documentation accessible to agents:

1. **Hosted Website Flow** - HTTP-discoverable agent files on a docs website
2. **npm Bundle Flow** - Offline-accessible docs bundled inside an npm package tarball

## Hosted Website Flow

**Starting File:** `/llms.txt` at the site root

**Process:**
- Uses website mode (default Leadtype behavior)
- Generates `/llms.txt` at the site root as the entry point for agents
- Creates markdown mirrors under `/docs/*.md` directories
- Builds HTTP-discoverable agent files that agents can fetch via network requests

**Key Artifacts Generated:**
- `/llms.txt` - Root index for agent discovery
- `/llms-full.txt` - Full context bundles for sections
- `/docs/*.md` - Markdown versions of all documentation
- `/docs/sitemap.xml` - XML sitemap for agents
- `/robots.txt` - Robot directives allowing access to agent files
- `/search/...` - Search JSON indexes
- `/agent-readability.json` - Agent readability metadata

**Agent Interaction:** Agents fetch documents via HTTP requests, using Accept headers (Accept: text/markdown) to request markdown content from docs pages.

## npm Bundle Flow

**Starting File:** `AGENTS.md` at the package root

**Process:**
- Uses `leadtype generate --bundle` command
- Generates `AGENTS.md` at the npm package root
- Creates `docs/*.md` files beneath the package root
- Uses relative links (e.g., `./docs/reference/cli.md`) for offline access
- Agents read docs from `node_modules` without requiring network requests

**Key Artifacts Generated:**
- `AGENTS.md` - Root index with relative links for offline agent access
- `docs/*.md` - Markdown versions of all documentation

**Website Artifacts Skipped:**
- `llms.txt` - Section indexes (replaced by AGENTS.md)
- `llms-full.txt` - Full context bundles
- `search/...` - Search JSON indexes
- `/sitemap.xml` - XML sitemaps
- `robots.txt` - Robot directives
- `agent-readability.json` - Agent readability metadata

## Key Differences

| Aspect | Hosted Flow | npm Bundle Flow |
|--------|------------|-----------------|
| **Entry Point** | `/llms.txt` | `AGENTS.md` |
| **Link Style** | Absolute HTTP URLs | Relative file paths |
| **Access Pattern** | Network requests to docs site | Local file system access in node_modules |
| **Discovery** | HTTP-discoverable via robots.txt & sitemap | Programmatic access via package files |
| **Website Artifacts** | All generated and served | Intentionally skipped |

The npm bundle flow is optimized for offline agent access within a development environment, eliminating web infrastructure artifacts that are unnecessary when docs are co-located with source code.
