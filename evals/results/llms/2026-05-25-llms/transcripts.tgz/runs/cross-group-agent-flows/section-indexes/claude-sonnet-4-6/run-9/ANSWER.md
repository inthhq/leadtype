# Cross-group Agent Flows: Hosted Website vs npm Bundle

## Overview

Leadtype supports two distinct agent flows from the same MDX source. Both flows share the same pipeline (MDX → frontmatter → group tree → markdown), but they target different consumers and emit different artifacts.

---

## 1. Hosted Website Flow

### Entry Point / Starting File

HTTP-based agents (URL-addressable LLMs) start at **`/llms.txt`** — the product-level index at the site root. From there, agents follow links to section-level indexes (e.g. `/docs/build/llms.txt`) and then to individual page markdown files (e.g. `/docs/build/connect-docs-site.md`).

### How It Works

- `generateLlmsTxt` writes the product-level `/llms.txt` **and** a docs-scoped `/docs/llms.txt` map.
- `generateLLMFullContextFiles` writes a single `/llms-full.txt` that flattens every generated markdown page into one file (a fallback for agents that want full context without following links).
- The server serves markdown when `Accept: text/markdown` is present or when a known AI user agent requests a docs page.

### Generated Artifacts (website mode)

| Artifact | Purpose |
|---|---|
| `/llms.txt` | Product-level agent entry point |
| `/docs/llms.txt` | Docs-scoped section map |
| `/llms-full.txt` | Root full-context fallback (all pages flattened) |
| `/docs/*.md` | Markdown mirrors of each page |
| `/docs/sitemap.xml` | XML sitemap |
| `/docs/sitemap.md` | Markdown sitemap |
| `/docs/robots.txt` | Crawler permissions (allows `/llms.txt`) |
| `/docs/agent-readability.json` | Agent-readability metadata |
| `/docs/search-index.json` | Static search index |
| `/docs/search-content.json` | Search content source |

The CLI's `--json` output for website mode includes: `llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, `agentReadabilityJson`, `sitemapXml`, `sitemapMd`, `robotsTxt`, `searchIndex`, and `searchContent`.

---

## 2. npm Package Bundle Flow

### Entry Point / Starting File

Coding agents working inside installed npm packages start at **`AGENTS.md`** — a file written at the package root. From there, agents follow **relative links** (e.g. `./docs/reference/cli.md`) to individual page docs. No network request is needed; everything is resolved inside `node_modules`.

### How It Works

- Triggered via `leadtype generate --bundle`.
- `generateAgentsMd` writes `AGENTS.md` at the package root. It intentionally **ignores** `product.agentGuidance` because that text is written for website URL routing (not applicable offline).
- All doc pages are written as `docs/*.md` relative to the package root, with relative links that resolve inside `node_modules`.

### Generated Artifacts (bundle mode)

| Artifact | Purpose |
|---|---|
| `AGENTS.md` | Package-root agent entry point (relative links) |
| `docs/*.md` | Markdown pages for each doc |

---

## 3. Artifacts That Bundle Mode Skips

Bundle mode explicitly **skips all website-only artifacts**. According to the docs, these are:

| Skipped Artifact | Why Skipped |
|---|---|
| `llms.txt` | HTTP-discovery entry point; not needed offline |
| `llms-full.txt` | Full-context HTTP fallback; not needed offline |
| `search-index.json` / `search-content.json` | Static search; not applicable in node_modules |
| `sitemap.xml` / `sitemap.md` | Web crawler artifacts; not applicable in node_modules |
| `robots.txt` | Crawler permissions; not applicable in node_modules |
| `agent-readability.json` | Website agent-readability metadata; not applicable in node_modules |

`isAgentReadabilityArtifactPath` (in the LLM files API) identifies exactly these paths so they are never rewritten as missing markdown pages.

---

## 4. Summary Comparison

| Aspect | Hosted Website Flow | npm Bundle Flow |
|---|---|---|
| **Agent entry file** | `/llms.txt` (HTTP URL) | `AGENTS.md` (package root) |
| **Link style** | Absolute HTTP URLs | Relative file paths (`./docs/…`) |
| **Triggered by** | `leadtype generate` (default) | `leadtype generate --bundle` |
| **Network required?** | Yes | No (works inside `node_modules`) |
| **Full-context fallback** | `/llms-full.txt` | Not included |
| **Search artifacts** | Yes | Skipped |
| **Sitemap / robots** | Yes | Skipped |
| **agent-readability.json** | Yes | Skipped |

The two flows are designed to complement each other: a package can publish bundled offline docs for `node_modules` **and** maintain a hosted docs website with `/llms.txt` for URL-based agents — both derived from the same MDX source.
