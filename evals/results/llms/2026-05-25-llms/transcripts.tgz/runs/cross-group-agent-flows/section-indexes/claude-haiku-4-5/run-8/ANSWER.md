# Cross-group Agent Flows: Hosted vs NPM Bundle

## Overview

Leadtype supports two distinct agent discovery flows for accessing documentation: a **hosted website flow** and an **npm package bundle flow**. These represent different deployment strategies for making docs available to agents.

## Hosted Website Flow

**Starting Point:** `/llms.txt`

In hosted mode (default website deployment), the flow begins at the root-level `/llms.txt` file, which serves as the entry point for agent discovery. This file contains:
- Section indexes linking to subsection llms.txt files
- Navigation structure for agents to discover available documentation

The hosted flow generates HTTP-discoverable agent files with the following artifacts:
- `/llms.txt` - Root entry point
- `/llms-full.txt` - Full-context bundles for sections
- `/docs/*.md` - Markdown mirrors of documentation pages
- `/docs/sitemap.xml` - XML sitemap
- `robots.txt` - Crawl directives
- `search.json` - Search index
- `agent-readability.json` - Agent readability metadata

Agents fetch documentation via HTTP requests with Content-Type negotiation (Accept: text/markdown or known AI user agents).

## NPM Package Bundle Flow

**Starting Point:** `AGENTS.md` (package root)

In bundle mode (npm package deployment), agents discover documentation starting from `AGENTS.md` located at the package root. This file serves as the entry point for agents reading docs offline from node_modules.

Bundle mode uses **relative links** like `./docs/reference/cli.md` to enable offline access without network requests.

## Files Skipped in Bundle Mode

The following website-only artifacts are **not generated** in bundle mode:
- `llms.txt` - Root index (unnecessary for offline packages)
- `llms-full.txt` - Full-context bundles (unnecessary for offline packages)
- `search.json` - Search index (offline agents don't need dynamic search)
- `sitemap.xml` - XML sitemap (navigation handled by AGENTS.md)
- `robots.txt` - Crawl directives (not applicable to node_modules)
- `agent-readability.json` - Agent readability metadata (not needed offline)

## Key Differences Summary

| Aspect | Hosted Website | NPM Bundle |
|--------|---|---|
| **Starting File** | `/llms.txt` | `AGENTS.md` |
| **Link Type** | HTTP absolute paths | Relative file paths |
| **Discovery** | HTTP requests with Content-Type negotiation | Local filesystem access |
| **Indexing** | Multiple llms.txt files in hierarchy | Single AGENTS.md with relative links |
| **Website Artifacts** | All website files generated | Website-only files skipped |
| **Use Case** | Hosted documentation sites | Offline npm package bundles |

## Command

The bundle mode is activated using:
```bash
leadtype generate --bundle
```
