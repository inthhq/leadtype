# Cross-group agent flows: hosted vs npm bundle

## Overview

Leadtype supports two different agent flow patterns for accessing documentation: a **hosted website flow** and an **npm package bundle flow**. Each flow optimizes for a different deployment scenario.

## Hosted Website Flow

**Starting Files:**
- `/llms.txt` - Root-level section index that agents fetch first
- `/llms-full.txt` - Full-context bundles for each section

**Generated Artifacts:**
- Markdown mirrors under `/docs/*.md` (HTTP-discoverable)
- `/llms.txt` at site root
- `/llms-full.txt` and additional `/llms-full/*.txt` bundles
- Sitemap files (`/docs/sitemap.xml`)
- `robots.txt` (allows agent crawling of `/llms.txt`)
- `search JSON` (search index)
- `agent-readability.json` (agent configuration)

**Use Case:** When a docs site should expose HTTP-discoverable agent files, agents fetch `/llms.txt` to discover documentation structure and fetch individual pages via HTTP requests with `Accept: text/markdown` headers.

## NPM Package Bundle Flow

**Starting Files:**
- `AGENTS.md` - Package root agent entry point
- `docs/*.md` - Documentation files beneath the package root

**Link Format:**
- Uses relative links like `./docs/reference/cli.md` so coding agents can read docs inside `node_modules` without network requests

**Use Case:** When publishing an npm package that should work offline, bundling docs alongside source code allows agents to access documentation through the filesystem.

## Key Differences: Website Artifacts Skipped in Bundle Mode

Bundle mode **explicitly skips** these website-only artifacts:

1. **llms.txt** - Section index (replaced by AGENTS.md in bundle)
2. **llms-full.txt** - Full-context section bundles
3. **Search JSON** - Search index (no search needed for offline access)
4. **Sitemap files** - XML sitemaps (not needed in npm context)
5. **robots.txt** - Crawler directives (not applicable to node_modules)
6. **agent-readability.json** - Agent configuration metadata

## Summary

| Aspect | Hosted Website | NPM Package Bundle |
|--------|----------------|-------------------|
| **Starting Point** | `/llms.txt` (HTTP fetch) | `AGENTS.md` (filesystem) |
| **Access Method** | HTTP requests | Direct filesystem access |
| **Link Format** | Absolute/HTTP paths | Relative paths (`./docs/`) |
| **Network Required** | Yes | No |
| **Artifacts Generated** | Section indexes, sitemaps, search JSON, agent metadata | Only markdown files |
| **Artifacts Skipped** | None | llms.txt, llms-full.txt, search JSON, sitemaps, robots.txt, agent-readability.json |
