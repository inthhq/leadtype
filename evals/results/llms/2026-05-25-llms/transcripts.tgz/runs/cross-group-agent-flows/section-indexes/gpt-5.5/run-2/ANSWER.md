# Cross-group agent flows: hosted website vs npm bundle

Leadtype supports two complementary agent flows from the same MDX source: a hosted website flow for URL-based agents and a package bundle flow for coding agents working offline inside `node_modules`.

## Hosted website flow

Hosted website mode is for docs exposed over HTTP. Agents start at the site-root file:

- `/llms.txt`

From there, they follow the section indexes and page markdown links, such as:

- `/docs/llms.txt` or section indexes like `/docs/build/llms.txt`
- markdown mirrors under `/docs/*.md`
- optional `/llms-full.txt` as a root full-context fallback

In website mode, Leadtype also emits website/static artifacts for discovery, routing, search, and readability checks. The documented website-mode outputs include:

- `/llms.txt`
- `/docs/llms.txt`
- `/llms-full.txt`
- markdown mirrors under `/docs/*.md`
- sitemap files, such as `docs/sitemap.xml` and `docs/sitemap.md`
- `robots.txt`
- `agent-readability.json`
- search JSON, such as `search-index.json` and `search-content.json`

For HTTP requests, the hosted site should serve markdown when `Accept` asks for `text/markdown` or when a known AI user agent requests a docs page.

## npm package bundle flow

Bundle mode is for publishing docs inside an npm package. It is produced with:

```sh
leadtype generate --bundle
```

Coding agents working inside an installed package start at:

- `AGENTS.md`

`AGENTS.md` then links relatively into bundled docs, for example:

- `./docs/reference/cli.md`
- other `docs/*.md` files shipped in the package

This lets agents read version-matched package docs from `node_modules` without making a network request.

## Website artifacts skipped by bundle mode

Bundle mode does **not** emit the website-only discovery/search artifacts. It skips:

- `llms.txt`
- `llms-full.txt`
- search JSON
- sitemap files
- `robots.txt`
- `agent-readability.json`

## Summary

| Flow | Agent starting file | Main links/artifacts followed | Purpose |
|---|---|---|---|
| Hosted website | `/llms.txt` | hosted section indexes, `/docs/*.md`, optional `/llms-full.txt` | HTTP-discoverable docs for URL-based agents |
| npm bundle | `AGENTS.md` | relative `./docs/*.md` links | offline, version-matched docs inside an npm package |
