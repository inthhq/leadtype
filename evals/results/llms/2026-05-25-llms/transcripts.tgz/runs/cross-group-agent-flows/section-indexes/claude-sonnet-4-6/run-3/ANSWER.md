# Cross-group Agent Flows: Hosted Website vs npm Bundle

## Overview

Leadtype's pipeline emits two distinct agent-facing flows from the same MDX source. The **hosted website flow** is designed for HTTP-based agents that discover docs over a network; the **npm bundle flow** is designed for coding agents (e.g. Copilot, Cursor) that read docs directly from inside `node_modules` without any network request. The two flows are complementary: a single package can publish both.

---

## 1. Hosted Website Flow

### Entry-point file
Agents start at **`/llms.txt`** (the product-level root index, written by `generateLlmsTxt`).  
A second, docs-scoped index is written at **`/docs/llms.txt`**.

### How the flow works
1. An HTTP agent fetches `/llms.txt` and reads the section indexes (e.g. `/docs/get-started/llms.txt`, `/docs/build/llms.txt`, etc.).
2. Each section index lists per-page markdown links (e.g. `/docs/how-it-works.md`).
3. The agent follows those links, requesting pages with `Accept: text/markdown` or being detected as a known AI user-agent, receiving the markdown mirror of the page.
4. If broader context is needed, a root full-context fallback is available at **`/llms-full.txt`** (written by `generateLLMFullContextFiles`), which flattens every generated markdown page into a single file. Per-group full-context files are **not** published by default.

### Static artifacts produced (website mode)
| Artifact | Path |
|---|---|
| Product-level agent index | `/llms.txt` |
| Docs-scoped agent index | `/docs/llms.txt` |
| Full-context bundle | `/llms-full.txt` |
| Markdown page mirrors | `/docs/*.md` |
| XML sitemap | `/docs/sitemap.xml` |
| Markdown sitemap | `/docs/sitemap.md` |
| robots.txt | `/docs/robots.txt` |
| Agent-readability manifest | `/docs/agent-readability.json` |
| Search index | `/docs/search-index.json` |
| Search content | `/docs/search-content.json` |

The CLI's `--json` flag reports all of these as: `llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, `agentReadabilityJson`, `sitemapXml`, `sitemapMd`, `robotsTxt`, `searchIndex`, and `searchContent`.

---

## 2. npm Bundle Flow

### Entry-point file
Agents start at **`AGENTS.md`** at the **package root** (written by `generateAgentsMd`).

### How the flow works
1. A coding agent working inside an installed package opens `AGENTS.md` from the package root (e.g. `node_modules/my-package/AGENTS.md`).
2. `AGENTS.md` uses **relative links** (e.g. `./docs/reference/cli.md`) so the agent can follow them without any network request.
3. The agent reads the linked `docs/*.md` files directly from the filesystem.

> **Note:** `generateAgentsMd` intentionally ignores `product.agentGuidance` because that text is written for website URL routing, which is irrelevant inside `node_modules`.

### Triggered by
```
leadtype generate --bundle
```

---

## 3. What Bundle Mode Skips

Bundle mode writes only `AGENTS.md` and `docs/*.md`. It explicitly **skips all website-only artifacts**:

| Skipped Artifact | Why it's skipped |
|---|---|
| `llms.txt` | HTTP discovery index — irrelevant offline |
| `llms-full.txt` | HTTP full-context fallback — irrelevant offline |
| `sitemap.xml` / `sitemap.md` | Web crawler/sitemap artifacts |
| `robots.txt` | Web crawler directive |
| `search-index.json` / `search-content.json` | Hosted search — not needed in node_modules |
| `agent-readability.json` | Hosted agent-readability manifest |

The helper `isAgentReadabilityArtifactPath` identifies these paths so the build does not mistakenly rewrite them as missing markdown pages.

---

## Summary Comparison

| Dimension | Hosted Website Flow | npm Bundle Flow |
|---|---|---|
| **Agent entry-point** | `/llms.txt` | `AGENTS.md` (package root) |
| **Link style** | Absolute URLs (`/docs/…`) | Relative paths (`./docs/…`) |
| **Network required?** | Yes (HTTP) | No (filesystem only) |
| **Triggered by** | `leadtype generate` (default) | `leadtype generate --bundle` |
| **Full-context file** | `/llms-full.txt` | _(none)_ |
| **Search artifacts** | ✅ Included | ❌ Skipped |
| **Sitemap / robots.txt** | ✅ Included | ❌ Skipped |
| **Agent-readability.json** | ✅ Included | ❌ Skipped |
| **Markdown page mirrors** | `/docs/*.md` (served over HTTP) | `docs/*.md` (inside tarball) |
