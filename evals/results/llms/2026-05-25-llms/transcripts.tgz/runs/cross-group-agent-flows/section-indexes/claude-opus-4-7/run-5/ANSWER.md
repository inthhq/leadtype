# Cross-group agent flows: hosted website vs npm package bundle

Leadtype emits two complementary agent-readable surfaces from one MDX source. The hosted website flow lives under the **Build** group (`/docs/build/llms.txt` → `connect-docs-site.md`) and the npm package flow lives under the **Ship Package Docs** group (`/docs/package-docs/llms.txt` → `bundle.md`). The `How it works` page (`/docs/how-it-works.md`) frames them as parallel flows that can coexist for the same package.

## Hosted website flow

**Entry file for agents:** `/llms.txt` at the site root.

From there, HTTP agents follow markdown links to per-page mirrors under `/docs/*.md`. To make this work, a connected docs site must serve markdown when `Accept: text/markdown` is requested or when a known AI user agent fetches a docs page (per `docs/build/connect-docs-site.md`).

**Static website artifacts the build keeps in place:**

- `/llms.txt` (root entry index)
- `/llms-full.txt` (full-context bundle)
- `/docs/*.md` (markdown mirrors of every page)
- Section indexes like `/docs/<group>/llms.txt` and per-group full-context bundles under `/docs/llms-full/*.txt`
- `sitemap` files (e.g. `/docs/sitemap.xml`)
- `/robots.txt` (must allow `/llms.txt`)
- search JSON
- `agent-readability.json`

Verification, per the Build page, includes fetching `/llms.txt`, fetching a docs page with `Accept: text/markdown`, checking `/docs/sitemap.xml`, and confirming `/robots.txt` allows `/llms.txt`.

## npm package bundle flow

**Entry file for agents:** `AGENTS.md` at the package root, produced by `leadtype generate --bundle`.

Coding agents working inside an installed dependency read `AGENTS.md` from `node_modules/<pkg>/` and follow **relative** links like `./docs/reference/cli.md` to markdown files bundled in the tarball. No network request is required — docs travel with the package and stay version-matched to the installed code.

**What bundle mode writes:**

- `AGENTS.md` at the package root
- `docs/*.md` beneath it, linked via relative paths

## Website artifacts that bundle mode skips

Per `docs/package-docs/bundle.md`, bundle mode deliberately omits the website-only artifacts because they assume an HTTP origin:

- `llms.txt`
- `llms-full.txt`
- search JSON
- sitemap files
- `robots.txt`
- `agent-readability.json`

Only `AGENTS.md` plus the `docs/*.md` tree are shipped in the npm tarball. The section-index `llms.txt` files, full-context `.txt` bundles, sitemap, robots, search index, and readability manifest are exclusive to the hosted-website flow.

## Side-by-side summary

| Aspect | Hosted website flow | npm bundle flow |
| --- | --- | --- |
| Group / source page | Build → `docs/build/connect-docs-site.md` | Ship Package Docs → `docs/package-docs/bundle.md` |
| Producer | Docs-site build | `leadtype generate --bundle` |
| Agent entry point | `/llms.txt` | `AGENTS.md` at package root |
| Link style | Absolute site paths to `/docs/*.md` | Relative `./docs/*.md` paths |
| Transport | HTTP (content-negotiated markdown) | Filesystem inside `node_modules` |
| Includes `llms.txt` / `llms-full.txt` | Yes | **No** |
| Includes sitemap, `robots.txt` | Yes | **No** |
| Includes search JSON | Yes | **No** |
| Includes `agent-readability.json` | Yes | **No** |
| Includes `docs/*.md` | Yes | Yes |

The two flows are designed to complement each other: the same package can publish offline bundled docs for coding agents browsing `node_modules` **and** host a docs website with `llms.txt` for URL-based agents.
