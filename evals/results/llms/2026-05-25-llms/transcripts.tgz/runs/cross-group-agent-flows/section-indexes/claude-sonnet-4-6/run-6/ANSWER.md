# Cross-group Agent Flows: Hosted Website vs npm Bundle

## Overview

Leadtype's pipeline produces **two distinct agent-readable flows** from the same MDX source. Each flow targets a different type of coding/AI agent and starts from a different entry-point file.

---

## 1. Hosted Website Flow

### Entry-point file
**`/llms.txt`** (at the site root)

HTTP-based agents (e.g. URL-fetching LLMs) begin here. The root `/llms.txt` is a map file that lists section indexes; agents follow those links to scoped section indexes such as `/docs/build/llms.txt`, which in turn link to individual page-level markdown files like `/docs/build/connect-docs-site.md`.

### How the flow works
1. Agent fetches **`/llms.txt`** — discovers all section indexes.
2. Agent fetches a **section index** (e.g. `/docs/get-started/llms.txt`) — discovers individual page links.
3. Agent fetches a **page-level `.md` file** (e.g. `/docs/quickstart.md`) — reads content.
4. If broader context is needed, an optional **full-context bundle** is available (e.g. `/docs/llms-full/build.txt` or `/llms-full.txt`), which flattens all pages in a section into one file.

Agents can also request markdown directly from any docs page by sending `Accept: text/markdown`, or are served markdown automatically when a known AI user-agent requests a docs page.

### Artifacts generated (website mode)
`leadtype generate` (no `--bundle` flag) writes all of the following:

| Artifact | Purpose |
|---|---|
| `/llms.txt` | Root agent entry-point / section map |
| `/docs/llms.txt` | Docs-scoped section map |
| `/llms-full.txt` | Root full-context fallback (all pages in one file) |
| `/docs/*.md` | Markdown mirrors of every docs page |
| `/docs/sitemap.xml` | XML sitemap |
| `/docs/sitemap.md` | Markdown sitemap |
| `/docs/robots.txt` | Robots file (explicitly allows `/llms.txt`) |
| `/docs/agent-readability.json` | Agent-readability metadata |
| `/docs/search-index.json` | Static search index |
| `/docs/search-content.json` | Search content |

The `generateLlmsTxt` API writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt`; `generateLLMFullContextFiles` writes `/llms-full.txt`. The `isAgentReadabilityArtifactPath` helper ensures none of these special artifacts are accidentally rewritten as missing markdown pages.

---

## 2. npm Package Bundle Flow

### Entry-point file
**`AGENTS.md`** (at the package root, inside `node_modules/<package>/`)

Coding agents (e.g. IDE-embedded LLMs, agentic coding tools) operating inside an installed npm package start here — **no network request required**. `AGENTS.md` uses *relative links* like `./docs/reference/cli.md` so the agent can navigate the docs tree entirely within the local filesystem.

### How the flow works
1. Agent reads **`AGENTS.md`** at the package root — discovers relative links to docs pages.
2. Agent follows **relative `./docs/*.md` links** — reads content offline inside `node_modules`.

Note: `generateAgentsMd` intentionally ignores `product.agentGuidance` (which is written for website URL routing) when generating `AGENTS.md`, since that guidance is not applicable in an offline bundle context.

### Artifacts generated (bundle mode)
`leadtype generate --bundle` writes **only**:

| Artifact | Purpose |
|---|---|
| `AGENTS.md` | Package-root agent entry-point with relative links |
| `docs/*.md` | Markdown docs pages |

---

## Website Artifacts That Bundle Mode Skips

Bundle mode explicitly omits all website-only artifacts. According to the docs:

| Skipped Artifact | Why skipped in bundle mode |
|---|---|
| `llms.txt` | HTTP discovery file; not meaningful inside `node_modules` |
| `llms-full.txt` | HTTP full-context fallback; not needed offline |
| `search-index.json` | Static search index; only useful on a hosted site |
| `search-content.json` | Search content; only useful on a hosted site |
| `sitemap.xml` | XML sitemap; only relevant for web crawlers |
| `sitemap.md` | Markdown sitemap; website navigation aid |
| `robots.txt` | Web crawler control file; irrelevant in a package |
| `agent-readability.json` | Hosted-site agent-readability metadata |

These are the same paths identified by `isAgentReadabilityArtifactPath` in the hosted flow — and they are all omitted in bundle mode because they serve HTTP/URL-based discovery rather than local filesystem navigation.

---

## Summary Comparison

| Aspect | Hosted Website Flow | npm Bundle Flow |
|---|---|---|
| **Entry-point file** | `/llms.txt` (site root) | `AGENTS.md` (package root) |
| **Agent type** | HTTP/URL-fetching agents | Coding agents in `node_modules` |
| **Link style** | Absolute URLs | Relative paths (`./docs/*.md`) |
| **Network required** | Yes | No (offline) |
| **CLI command** | `leadtype generate` | `leadtype generate --bundle` |
| **Artifacts** | All 10 listed above | Only `AGENTS.md` + `docs/*.md` |
| **Skips** | — | `llms.txt`, `llms-full.txt`, search JSON, sitemaps, `robots.txt`, `agent-readability.json` |

The two flows are **complementary**: a package can publish bundled offline docs for node_modules agents *and* maintain a hosted docs website with `llms.txt` for URL-based agents, both generated from the same MDX source.
