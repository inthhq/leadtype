# Cross-group Agent Flows: Hosted vs NPM Bundle

## Overview

Leadtype supports two complementary agent flows for accessing documentation:

1. **Hosted Website Flow**: For HTTP agents accessing a docs site via the web
2. **NPM Bundle Flow**: For coding agents working inside installed npm packages (offline)

## Hosted Website Flow

**Starting Point**: `/llms.txt` at the site root

### Flow Process
- HTTP agents start by fetching `/llms.txt`
- Agents follow markdown links to discover documentation
- The site root contains agent-readable markdown files at `/docs/*.md`

### Generated Artifacts
The hosted website mode generates:
- `/llms.txt` - Entry point for agent discovery
- `/llms-full.txt` - Full-context section bundles
- `/docs/*.md` - Markdown mirrors of documentation
- `/docs/sitemap.xml` - Sitemap for agent navigation
- `/robots.txt` - Robots exclusion file with agent directives
- `agent-readability.json` - Agent readability metadata
- Search JSON files - Searchable index for agents
- Static website artifacts (HTML, CSS, JS, etc.)

### Request Handling
- Serve markdown when `Accept: text/markdown` header is present
- Serve markdown when known AI user agents request docs pages
- Keep agent-specific artifacts available as static files

## NPM Bundle Flow

**Starting Point**: `AGENTS.md` at the package root

### Flow Process
- Coding agents read `AGENTS.md` from the installed package root
- Follow relative links like `./docs/reference/cli.md`
- All docs access is offline (no network requests needed)

### Generated Artifacts
The bundle mode generates:
- `AGENTS.md` - Entry point at package root
- `docs/*.md` - Markdown documentation beneath the package root

### Skipped Artifacts
Bundle mode **intentionally skips** these website-only artifacts:
- `llms.txt` - Not needed for offline package access
- `llms-full.txt` - Full-context bundles not needed in npm packages
- Search JSON - Search indexing not applicable to offline packages
- Sitemap files (`sitemap.xml`, etc.) - No web navigation needed
- `robots.txt` - No crawling directives needed
- `agent-readability.json` - Agent readability metadata not needed for packages

## Key Differences

| Aspect | Hosted Website | NPM Bundle |
|--------|---|---|
| **Entry Point** | `/llms.txt` | `AGENTS.md` |
| **Link Style** | Absolute URLs (e.g., `/docs/reference/cli.md`) | Relative paths (e.g., `./docs/reference/cli.md`) |
| **Access Pattern** | HTTP-based, network requests | Offline, file system access |
| **Target Audience** | HTTP agents | Coding agents in node_modules |
| **Web Artifacts** | Full set | None |
| **Network Dependent** | Yes | No |

## Complementary Deployment

A package can publish both flows simultaneously:
- Host a docs website with `/llms.txt` for URL-based HTTP agents
- Bundle `AGENTS.md` and `docs/*.md` inside the npm tarball for offline agents

This allows maximum flexibility: agents can either fetch docs from a hosted site or work offline with bundled documentation inside installed packages.
