# Hosted website flow vs npm package bundle flow for agents

Leadtype supports two complementary agent flows from the same MDX source.

## Hosted website flow

- **Agent entry point:** HTTP agents start at the site-root **`/llms.txt`**.
- **Routing:** `/llms.txt` points agents to markdown docs links, including docs-scoped maps such as **`/docs/llms.txt`** and markdown mirrors under **`/docs/*.md`**.
- **Fallback/context:** Website mode can also publish a root **`/llms-full.txt`** containing all generated markdown docs pages.
- **Serving behavior:** A hosted docs site should serve markdown when `Accept` asks for `text/markdown` or when a known AI user agent requests a docs page.
- **Website artifacts kept static:** `/llms.txt`, `/llms-full.txt`, sitemap files, `robots.txt`, search JSON, and `agent-readability.json` should be deployed as static artifacts.

## npm package bundle flow

- **Agent entry point:** Coding agents inside an installed npm package start at package-root **`AGENTS.md`**.
- **Routing:** `AGENTS.md` uses relative links such as **`./docs/reference/cli.md`**, so agents can follow **`docs/*.md`** files inside `node_modules` without making network requests.
- **Generation mode:** This is produced with **`leadtype generate --bundle`**.
- **Grouping:** Groups still organize the generated `AGENTS.md` and docs, but bundle mode is for offline, package-local navigation rather than URL routing.

## Website artifacts skipped by bundle mode

Bundle mode writes only **`AGENTS.md`** plus bundled markdown docs under **`docs/*.md`**. It skips website-only artifacts:

- **`llms.txt`**
- **`llms-full.txt`**
- **Search JSON**, including files such as `docs/search-index.json` and `docs/search-content.json`
- **Sitemap files**, such as `docs/sitemap.xml` and `docs/sitemap.md`
- **`robots.txt`**
- **`agent-readability.json`**

In short: hosted agents begin at **`/llms.txt`** and follow HTTP-accessible markdown links; npm-bundled coding agents begin at **`AGENTS.md`** and follow relative package-local `docs/*.md` links.