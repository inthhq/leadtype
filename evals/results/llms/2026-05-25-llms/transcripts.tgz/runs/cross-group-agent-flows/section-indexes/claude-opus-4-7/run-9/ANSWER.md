# Cross-group agent flows: hosted website vs npm package bundle

Leadtype emits two complementary agent-facing flows from one MDX source. The hosted website flow targets HTTP-based agents; the npm bundle flow targets coding agents working offline inside `node_modules`.

Sources consulted (via `/llms.txt` and section indexes):
- `/docs/how-it-works.md` — pipeline overview of the two flows
- `/docs/build/connect-docs-site.md` — Build section, website mode
- `/docs/package-docs/bundle.md` — Ship Package Docs section, bundle mode

## Hosted website flow

- **Entry point for agents:** `/llms.txt` at the site root. HTTP agents start here and follow markdown links to pages under `/docs/*.md`.
- **Where the docs live:** markdown mirrors under `/docs/*.md`, served as `text/markdown` either when `Accept: text/markdown` is set or when a known AI user agent requests the page.
- **Static website artifacts kept alongside the pages:**
  - `/llms.txt` (root index)
  - `/llms-full.txt` (full-context bundle)
  - sitemap files (e.g. `/docs/sitemap.xml`)
  - `/robots.txt` (must allow `/llms.txt`)
  - search JSON
  - `agent-readability.json`
- **Verification:** fetch `/llms.txt`, fetch a `/docs/*.md` page with `Accept: text/markdown`, check `/docs/sitemap.xml`, and confirm `/robots.txt` allows `/llms.txt`.

## npm package bundle flow

- **Entry point for agents:** `AGENTS.md` at the package root, written by `leadtype generate --bundle`. Coding agents inside `node_modules` start here and follow relative links like `./docs/reference/cli.md` — no network request required.
- **Where the docs live:** `docs/*.md` beneath the package root, shipped inside the npm tarball.
- **Goal:** version-matched, offline-readable docs that travel with the installed package.

## Which website artifacts bundle mode skips

Per `/docs/package-docs/bundle.md`, bundle mode deliberately omits website-only artifacts because they assume an HTTP origin:

- `llms.txt`
- `llms-full.txt`
- search JSON
- sitemap files
- `robots.txt`
- `agent-readability.json`

In bundle mode these are replaced by a single root entry point (`AGENTS.md`) plus the relative `docs/*.md` tree.

## Side-by-side summary

| Aspect | Hosted website flow | npm bundle flow |
|---|---|---|
| Entry file | `/llms.txt` | `AGENTS.md` (package root) |
| Doc pages | `/docs/*.md` served over HTTP | `docs/*.md` inside the tarball |
| Link style | Site-absolute URLs | Relative paths (`./docs/...`) |
| Transport | HTTP, content-negotiated markdown | Filesystem read inside `node_modules` |
| Indexes/discovery | `llms.txt`, `llms-full.txt`, sitemap, `robots.txt` | `AGENTS.md` only |
| Extras | search JSON, `agent-readability.json` | (skipped) |
| Generator cue | website build wiring | `leadtype generate --bundle` |

The two flows are complementary: a project can publish bundled offline docs for `node_modules` *and* host a docs website with `llms.txt` for URL-based agents from the same MDX source.
