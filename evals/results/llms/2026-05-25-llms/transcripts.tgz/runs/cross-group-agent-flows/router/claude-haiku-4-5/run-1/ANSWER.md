# Cross-Group Agent Flows: Hosted vs npm Bundle

## Overview

Leadtype supports two distinct agent flows for accessing documentation: a hosted website flow and an npm package bundle flow. Both start from MDX source files but diverge in their starting artifacts and generated outputs.

## Hosted Website Flow

**Starting Point:** `/llms.txt`

HTTP agents discover and access agent-readable documentation through the hosted website flow. Agents start by fetching `/llms.txt` at the site root, which serves as the entry point for discovering available documentation.

**Generated Artifacts:**
- `/llms.txt` - Root entry point with routing hints
- `/llms-full.txt` - Full-context router with complete documentation structure
- `/docs/*.md` - Markdown mirrors of all MDX source pages
- `/docs/llms.txt` - Docs-specific routing
- `/docs/sitemap.xml` and `/docs/sitemap.md` - Sitemap files
- `/docs/robots.txt` - Robot rules
- `/docs/agent-readability.json` - Agent readability metadata
- `/docs/search-index.json` and `/docs/search-content.json` - Search indexes

The hosted flow is HTTP-based, meaning agents discover documentation by following links and making network requests to the website.

## npm Bundle Flow

**Starting Point:** `AGENTS.md` (at package root)

Coding agents working inside installed npm packages start at `AGENTS.md`, which is bundled at the package root. This enables offline documentation access without network requests.

**Generated Artifacts:**
- `AGENTS.md` - Root entry point at package root (uses relative links)
- `docs/*.md` - Markdown docs beneath the package root (with relative links like `./docs/reference/cli.md`)

Bundle mode uses relative links instead of HTTP URLs, allowing agents to read docs directly from `node_modules` without requiring network access.

## Website Artifacts Skipped in Bundle Mode

The npm bundle flow explicitly **skips all website-only artifacts**:
- `llms.txt` - Not included
- `llms-full.txt` - Not included
- Search JSON files (`search-index.json`, `search-content.json`) - Not included
- Sitemap files (`sitemap.xml`, `sitemap.md`) - Not included
- `robots.txt` - Not included
- `agent-readability.json` - Not included

These artifacts are designed for HTTP-discoverable website access and are unnecessary for offline, node_modules-based package documentation.

## Key Differences

| Aspect | Hosted Website Flow | npm Bundle Flow |
|--------|-------------------|-----------------|
| **Entry Point** | `/llms.txt` | `AGENTS.md` |
| **Link Style** | HTTP URLs | Relative file paths |
| **Network Requirement** | Required (HTTP-based) | Not required (offline) |
| **Primary Audience** | HTTP agents | Coding agents in node_modules |
| **Full Router** | `/llms-full.txt` | Not included |
| **Search Support** | Yes (search JSON) | No |
| **Discoverability** | Via robots.txt and sitemaps | Direct file access |

## Complementary Deployment

Both flows can operate simultaneously. A package can publish:
1. **Bundled docs** (via `leadtype generate --bundle`) for offline node_modules access
2. **Hosted docs** (default website mode) with `/llms.txt` for URL-based agents

This allows teams to serve both HTTP-based and offline-based agent workflows from the same MDX source.
