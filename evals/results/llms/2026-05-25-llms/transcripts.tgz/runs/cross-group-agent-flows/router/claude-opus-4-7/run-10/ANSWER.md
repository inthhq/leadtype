# Cross-group agent flows: hosted website vs npm package bundle

Leadtype emits docs for two distinct agent audiences from a single MDX source. The hosted-website flow targets agents that fetch over HTTP, and the npm-bundle flow targets coding agents that read files inside `node_modules` with no network. The docs describe these as complementary flows that a single package can publish side by side (`docs/how-it-works.md`).

## Where each flow starts

### Hosted website flow (agents over HTTP)
- **Entry file:** `/llms.txt` at the site root. Per `docs/how-it-works.md`: *"HTTP agents start at /llms.txt and follow markdown links."*
- `/llms.txt` is a short router that points at `/llms-full.txt` (the "Full Context Router"), which in turn routes to topic-specific deep-context files such as `/docs/llms-full/build.txt`, `/docs/llms-full/package-docs.txt`, etc.
- Individual pages are served as markdown mirrors under `/docs/*.md` when the request sends `Accept: text/markdown` or comes from a known AI user agent (`docs/build/connect-docs-site.md`).

### npm package bundle flow (coding agents in `node_modules`)
- **Entry file:** `AGENTS.md` at the package root. Per `docs/how-it-works.md`: *"Coding agents working inside installed npm packages start at AGENTS.md and follow relative docs/*.md links."*
- `AGENTS.md` uses relative links like `./docs/reference/cli.md` so the agent can read everything off disk without a network request (`docs/package-docs/bundle.md`).
- Produced by running `leadtype generate --bundle` (`docs/package-docs/bundle.md`, `docs/quickstart.md`).

## What each flow writes

### Website mode writes (from `docs/quickstart.md` and `docs/reference/cli.md`)
- `/llms.txt`
- `/docs/llms.txt`
- `/llms-full.txt`
- Markdown mirrors under `/docs/*.md`
- `docs/sitemap.xml`
- `docs/sitemap.md`
- `docs/robots.txt`
- `docs/agent-readability.json`
- `docs/search-index.json`
- `docs/search-content.json`

The CLI's `--json` output exposes these as `llmsTxt`, `docsLlmsTxt`, `llmsFullTxt`, `sitemapXml`, `sitemapMd`, `robotsTxt`, `agentReadabilityJson`, `searchIndex`, and `searchContent` (`docs/reference/cli.md`).

### Bundle mode writes (from `docs/package-docs/bundle.md` and `docs/quickstart.md`)
- `AGENTS.md` at the package root
- `docs/*.md` beneath it, with relative links

That's it — bundle mode is intentionally minimal so it fits inside an npm tarball.

## Website artifacts that bundle mode skips

`docs/package-docs/bundle.md` is explicit: *"Bundle mode skips website-only artifacts: llms.txt, llms-full.txt, search JSON, sitemap files, robots.txt, and agent-readability.json."*

Concretely, bundle mode omits:

| Skipped artifact | Why it's website-only |
|---|---|
| `llms.txt` | HTTP router; offline agents start at `AGENTS.md` instead. |
| `llms-full.txt` | The root full-context fallback for URL-based agents (`docs/reference/llm.md`). |
| `docs/llms.txt` | Docs-scoped llms map for hosted sites (`docs/reference/llm.md`). |
| `docs/search-index.json` and `docs/search-content.json` | Static search index for the hosted site's runtime search (`docs/reference/search.md`). |
| `docs/sitemap.xml` and `docs/sitemap.md` | Sitemap files for crawlers/agents discovering URLs. |
| `docs/robots.txt` | Crawl policy that, among other things, allows `/llms.txt`. |
| `docs/agent-readability.json` | Manifest of agent-readable artifact paths on the site. |

Additionally, `generateAgentsMd` *"intentionally ignores `product.agentGuidance` because that text is written for website URL routing"* (`docs/reference/llm.md`) — relative `./docs/*.md` links replace URL routing inside a bundle.

## Summary

- Hosted flow: entry is `/llms.txt` → `/llms-full.txt` → topic `*.txt` and `/docs/*.md`. Ships the full set of website artifacts (llms files, sitemaps, robots.txt, search JSON, agent-readability.json).
- Bundle flow: entry is `AGENTS.md` → relative `./docs/*.md`. Skips every website-only artifact above, keeping only `AGENTS.md` plus the markdown docs tree so agents can read it directly from `node_modules`.
