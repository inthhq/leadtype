# Cross-group agent flows: hosted website vs npm bundle

## Hosted website flow

- Agents start at the site root file: `/llms.txt`.
- `/llms.txt` points agents to `/llms-full.txt`, the full-context router.
- `/llms-full.txt` routes the agent to the smallest relevant topic file, such as `/docs/llms-full/get-started.txt`, `/docs/llms-full/build.txt`, or `/docs/llms-full/package-docs.txt`.
- In website mode, the docs build exposes HTTP-discoverable agent files:
  - `/llms.txt`
  - `/llms-full.txt`
  - markdown mirrors under `/docs/*.md`
  - sitemap files
  - `robots.txt`
  - search JSON
  - `agent-readability.json`
- Docs pages should serve markdown when `Accept` asks for `text/markdown` or when a known AI user agent requests a docs page.

## npm package bundle flow

- Agents start inside the installed package at `AGENTS.md` in the package root.
- `AGENTS.md` links to bundled markdown with relative paths such as `./docs/reference/cli.md`.
- The markdown docs are included under `docs/*.md` inside the npm tarball, so agents can read version-matched docs from `node_modules` without making a network request.
- This flow is produced with `leadtype generate --bundle`.

## Website artifacts skipped by bundle mode

Bundle mode does **not** include website-only artifacts. It skips:

- `llms.txt`
- `llms-full.txt`
- search JSON
- sitemap files
- `robots.txt`
- `agent-readability.json`
