# Cross-group agent flows: hosted vs npm bundle

## Hosted website flow

- **Agent entry point:** an HTTP/URL-based agent starts at the site-root file **`/llms.txt`**.
- **Routing path:** `/llms.txt` points to **`/llms-full.txt`**, which routes the agent to the smallest relevant topic file, such as `/docs/llms-full/build.txt` or `/docs/llms-full/package-docs.txt`.
- **Docs pages:** the hosted build exposes markdown mirrors under **`/docs/*.md`** so agents can fetch page content as markdown. For docs-page requests, the site should serve markdown when the request asks for `Accept: text/markdown` or comes from a known AI user agent.
- **Website artifacts kept as static files:** hosted website mode keeps files such as `llms.txt`, `llms-full.txt`, sitemap files, `robots.txt`, search JSON, and `agent-readability.json` available on the site.

## npm package bundle flow

- **Agent entry point:** a coding agent working inside an installed npm package starts at **`AGENTS.md`** at the package root.
- **Routing path:** `AGENTS.md` uses relative links, for example **`./docs/reference/cli.md`**, so the agent can follow links to bundled **`docs/*.md`** files inside `node_modules` without making a network request.
- **Generation command:** this flow is produced with **`leadtype generate --bundle`**.

## What bundle mode skips

Bundle mode is intentionally not a hosted website build. It writes **`AGENTS.md`** plus bundled **`docs/*.md`** files, and skips website-only artifacts:

- `llms.txt`
- `llms-full.txt`
- search JSON, such as `search-index.json` and `search-content.json`
- sitemap files
- `robots.txt`
- `agent-readability.json`

In short: hosted docs are for URL-based agents that begin at `/llms.txt`; npm bundled docs are for coding agents inside `node_modules` that begin at `AGENTS.md` and use relative local markdown links.