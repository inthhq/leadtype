# Cross-group agent flows: hosted website vs npm bundle

Leadtype turns one MDX source into multiple delivery modes. Two of those modes—the **hosted website flow** (Build group) and the **npm package bundle flow** (Ship Package Docs group)—both target coding agents, but they start from different entry files and produce different artifacts.

## Hosted website flow (Build)

Source: [`/docs/build/connect-docs-site.md`](/docs/build/connect-docs-site.md) (via the Build router at `/docs/llms-full/build.txt`).

- **Entry file for agents:** `/llms.txt` at the site root.
- **How agents discover content:** they fetch `/llms.txt`, follow it to topic-specific deep-context files (e.g., `/llms-full.txt` and the topic routers), and then fetch individual markdown mirrors under `/docs/*.md`.
- **Content negotiation:** the site serves markdown when the request's `Accept` header asks for `text/markdown`, or when a known AI user agent requests a docs page.
- **Static website artifacts kept:**
  - `/llms.txt`
  - `/llms-full.txt`
  - sitemap files (e.g., `/docs/sitemap.xml`)
  - `/robots.txt` (which must allow `/llms.txt`)
  - search JSON
  - `agent-readability.json`
- **Verification:** fetch `/llms.txt`, fetch a docs page with `Accept: text/markdown`, check `/docs/sitemap.xml`, and confirm `/robots.txt` allows `/llms.txt`.

## npm package bundle flow (Ship Package Docs)

Source: [`/docs/package-docs/bundle.md`](/docs/package-docs/bundle.md) (via the Ship Package Docs router at `/docs/llms-full/package-docs.txt`).

- **Trigger:** run `leadtype generate --bundle` when publishing an npm package.
- **Entry file for agents:** `AGENTS.md` at the package root (inside the published tarball, so it lands at `node_modules/<pkg>/AGENTS.md` after install).
- **How agents discover content:** `AGENTS.md` uses **relative links** like `./docs/reference/cli.md`, so a coding agent can read the docs straight off the filesystem inside `node_modules` with **no network request**.
- **Layout written:** `AGENTS.md` at the package root and `docs/*.md` beneath it.

## Website artifacts that bundle mode skips

Bundle mode is explicitly offline-only, so it omits every website-only artifact:

| Artifact | Hosted website | npm bundle |
|---|---|---|
| `llms.txt` | ✅ served | ❌ skipped |
| `llms-full.txt` | ✅ served | ❌ skipped |
| Sitemap files (e.g., `sitemap.xml`) | ✅ served | ❌ skipped |
| `robots.txt` | ✅ served | ❌ skipped |
| Search JSON | ✅ served | ❌ skipped |
| `agent-readability.json` | ✅ served | ❌ skipped |
| `AGENTS.md` at root | — | ✅ written |
| `docs/*.md` mirrors | ✅ served via content negotiation | ✅ written to tarball |

## Summary

- The **hosted flow starts at `/llms.txt`**, which routes agents through `/llms-full.txt` to topic files, with HTTP content negotiation serving the `/docs/*.md` mirrors. It keeps a full set of discovery artifacts (`llms.txt`, `llms-full.txt`, sitemaps, `robots.txt`, search JSON, `agent-readability.json`).
- The **bundle flow starts at `AGENTS.md`** at the package root, with relative links into `./docs/*.md`. Because the agent reads files directly from `node_modules`, bundle mode skips every HTTP-discovery artifact: `llms.txt`, `llms-full.txt`, search JSON, sitemap files, `robots.txt`, and `agent-readability.json`.
