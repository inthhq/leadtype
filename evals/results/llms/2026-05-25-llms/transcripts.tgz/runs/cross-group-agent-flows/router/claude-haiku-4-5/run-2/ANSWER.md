# Cross-Group Agent Flows: Hosted vs NPM Bundle

## Overview
Leadtype supports two distinct agent flows for accessing documentation: a hosted website flow and an NPM bundle flow. Each serves different deployment scenarios and generates different starting points and artifacts.

## Hosted Website Flow

### Starting Point
The hosted website flow begins with `/llms.txt` as the entry point for agents.

### File Structure & Flow
1. Agents fetch `/llms.txt` from the site root
2. `/llms.txt` routes to topic-specific resources (referenced as `/llms-full.txt`)
3. Agents access markdown mirrors under `/docs/*.md` via HTTP
4. Website serves markdown when the request includes `Accept: text/markdown` or when a known AI user agent requests a docs page

### Key Configuration
Website mode exposes HTTP-discoverable agent files and requires:
- `/llms.txt` at the site root
- Markdown mirrors under `/docs/*.md`
- Static artifacts: `/llms-full.txt`, sitemap files, robots.txt, search JSON, and agent-readability.json

### Deployment Context
Used when a docs site should expose documentation to agents via HTTP requests over the network.

---

## NPM Bundle Flow

### Starting Point
The bundle flow begins with `AGENTS.md` at the package root.

### File Structure & Flow
1. Agents read `AGENTS.md` from the npm package root
2. `AGENTS.md` uses relative links (e.g., `./docs/reference/cli.md`)
3. Agents access docs from `docs/*.md` relative to the package root
4. All documentation is available offline without network requests

### Key Configuration
Generated with `leadtype generate --bundle` command.

---

## Skipped Artifacts in Bundle Mode

Bundle mode **skips these website-only artifacts**:
- `llms.txt` - The website entry point
- `llms-full.txt` - The full context router for websites
- Search JSON - Search index for website search functionality
- Sitemap files - XML sitemaps for web crawlers
- `robots.txt` - Web crawler directives
- `agent-readability.json` - Website-specific agent readability metadata

These artifacts are unnecessary in a bundle because agents access docs offline and directly via relative file paths without HTTP discovery or search facilities.

---

## Key Differences Summary

| Aspect | Hosted Website | NPM Bundle |
|--------|---|---|
| **Entry Point** | `/llms.txt` | `AGENTS.md` |
| **Link Style** | HTTP/absolute paths | Relative paths (e.g., `./docs/reference/cli.md`) |
| **Access Method** | HTTP requests (network-dependent) | File system (offline) |
| **Router Files** | `/llms.txt`, `/llms-full.txt` | None needed |
| **Discovery Artifacts** | Sitemaps, robots.txt, search JSON | Skipped |
| **Deployment Use Case** | Hosted docs sites with HTTP access | NPM packages bundled into node_modules |

The two flows allow Leadtype to serve the same MDX source documentation in different contexts: as a discoverable, searchable hosted website for web agents and as a compact, offline-accessible bundle for agents working within npm packages.
