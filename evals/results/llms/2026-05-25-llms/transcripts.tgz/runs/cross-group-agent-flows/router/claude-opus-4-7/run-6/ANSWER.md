# Cross-group agent flows: hosted website vs npm bundle

Leadtype produces two distinct agent-readable flows from the same MDX source. The hosted website flow is described in the **Build** group, and the npm bundle flow is described in the **Ship Package Docs** group. The comparison below is drawn entirely from the docs files reachable via `/llms.txt` → `/llms-full.txt`.

## Entry points each flow starts from

| Flow | Starting / root file an agent reads | Where it lives | Source doc |
|---|---|---|---|
| Hosted website | `/llms.txt` at the site root (which links to `/llms-full.txt`, then to per-topic deep-context files and `/docs/*.md` mirrors) | Served over HTTP from the docs site | `docs/build/connect-docs-site.md` |
| npm package bundle | `AGENTS.md` at the package root (which uses relative links such as `./docs/reference/cli.md`) | Inside the npm tarball, readable from `node_modules` with no network request | `docs/package-docs/bundle.md` |

So agents discovering a Leadtype-powered project online start at `/llms.txt`, while agents working against an installed npm dependency start at the package's `AGENTS.md`.

## How each flow is produced

- **Hosted website mode** (`docs/build/connect-docs-site.md`): the build generates `/llms.txt` at the site root and markdown mirrors under `/docs/*.md`. The server is expected to return markdown when the request uses `Accept: text/markdown` or when a known AI user agent asks for a docs page. Verification: fetch `/llms.txt`, fetch a docs page with `Accept: text/markdown`, check `/docs/sitemap.xml`, and confirm `/robots.txt` allows `/llms.txt`.
- **Bundle mode** (`docs/package-docs/bundle.md`): invoked with `leadtype generate --bundle` when publishing an npm package. It writes `AGENTS.md` at the package root and `docs/*.md` beneath it. Links inside `AGENTS.md` are relative so agents can read the docs straight out of `node_modules`.

## Website artifacts that bundle mode skips

According to `docs/package-docs/bundle.md`, bundle mode deliberately omits the website-only artifacts that the hosted build keeps as static files (per `docs/build/connect-docs-site.md`). The skipped artifacts are:

1. `llms.txt`
2. `llms-full.txt`
3. Search JSON
4. Sitemap files (e.g. `/docs/sitemap.xml`)
5. `robots.txt`
6. `agent-readability.json`

These all exist to support HTTP discovery, crawling, search, and agent-readability signaling — none of which apply when the docs travel inside a tarball. The bundle therefore keeps only what an offline agent actually needs to navigate: a top-level `AGENTS.md` and the `docs/*.md` files it links to.

## Summary

- Hosted flow → entry file `/llms.txt`; serves `/docs/*.md` mirrors plus the discovery/indexing artifacts (`llms-full.txt`, sitemap, `robots.txt`, search JSON, `agent-readability.json`).
- Bundle flow → entry file `AGENTS.md` next to `docs/*.md` inside the npm package; drops every artifact whose purpose is HTTP discovery (`llms.txt`, `llms-full.txt`, search JSON, sitemap files, `robots.txt`, `agent-readability.json`).
