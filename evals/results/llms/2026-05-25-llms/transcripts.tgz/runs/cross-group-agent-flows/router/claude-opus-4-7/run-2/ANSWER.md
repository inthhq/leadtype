# Cross-group agent flows: hosted website vs. npm bundle

Leadtype publishes documentation through two distinct delivery modes for AI/coding
agents. Both pipelines are derived from the same MDX source, but each exposes a
different set of entry files and artifacts. The relevant docs are grouped under
two different `llms-full` topics: **Build** (hosted website) and **Ship Package
Docs** (npm bundle).

## Starting files for an agent

| Flow | Topic router page | Starting agent-readable file(s) |
| --- | --- | --- |
| Hosted website | `/docs/llms-full/build.txt` → `/docs/build/connect-docs-site.md` | `/llms.txt` at the site root, with markdown mirrors served under `/docs/*.md` |
| npm package bundle | `/docs/llms-full/package-docs.txt` → `/docs/package-docs/bundle.md` | `AGENTS.md` at the package root, with `docs/*.md` beneath it inside the tarball |

Both flows are reached from the top-level router `/llms.txt` → `/llms-full.txt`,
which lists Build and Ship Package Docs as separate topics.

## Hosted website flow (`leadtype generate`, website mode)

Source: `/docs/build/connect-docs-site.md`.

- Used when a docs site should expose **HTTP-discoverable** agent files.
- The build generates `/llms.txt` at the site root plus markdown mirrors under
  `/docs/*.md`.
- The server returns markdown when `Accept: text/markdown` is set or when a
  known AI user agent requests a docs page.
- Static website artifacts kept on disk for agents and crawlers:
  - `/llms.txt`
  - `/llms-full.txt`
  - sitemap files (e.g. `/docs/sitemap.xml`)
  - `/robots.txt`
  - search JSON
  - `agent-readability.json`
- Recommended verification: fetch `/llms.txt`, fetch a docs page with
  `Accept: text/markdown`, check `/docs/sitemap.xml`, and confirm `/robots.txt`
  allows `/llms.txt`.

## npm package bundle flow (`leadtype generate --bundle`)

Source: `/docs/package-docs/bundle.md`.

- Used when publishing an npm package so agents can read docs **offline** from
  `node_modules` without a network request.
- Bundle mode writes `AGENTS.md` at the package root and `docs/*.md` beneath it.
- `AGENTS.md` uses relative links like `./docs/reference/cli.md` so the docs
  resolve inside the installed package directory.

### Website artifacts that bundle mode skips

Bundle mode deliberately omits website-only artifacts (since there is no HTTP
host inside an npm tarball):

- `llms.txt`
- `llms-full.txt`
- search JSON
- sitemap files
- `robots.txt`
- `agent-readability.json`

## Summary of the contrast

- The hosted website flow centers on `/llms.txt` as the agent entry point and
  relies on HTTP conventions (Accept negotiation, robots, sitemaps, search JSON,
  `agent-readability.json`) to make markdown discoverable.
- The npm bundle flow centers on `AGENTS.md` as the entry point and ships only
  the markdown corpus (`docs/*.md`) with relative links, dropping every
  discovery/indexing artifact that only makes sense on a live website.
