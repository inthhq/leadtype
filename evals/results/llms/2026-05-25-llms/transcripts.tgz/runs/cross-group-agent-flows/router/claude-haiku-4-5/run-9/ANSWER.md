# Cross-Group Agent Flows: Hosted vs npm Bundle

## Overview

Leadtype supports two different agent flows for accessing documentation: a **hosted website flow** and an **npm package bundle flow**. Both expose the same markdown content to agents but through different distribution mechanisms and with different artifacts.

## Hosted Website Flow

### Starting Point
The hosted website flow starts from `/llms.txt` at the site root.

### How It Works
1. **Initial discovery**: Agents fetch `/llms.txt` from the hosted docs site
2. **Full context routing**: Agents can read `/llms-full.txt` for deeper context
3. **HTTP-discoverable**: All agent files are accessible via HTTP requests
4. **Markdown fetching**: When agents need documentation, they request markdown from `/docs/*.md` paths
5. **Special handling**: The server responds with markdown content when:
   - The request has `Accept: text/markdown` header
   - A known AI user agent requests a docs page

### Artifacts Generated
- `/llms.txt` - Quick reference router
- `/llms-full.txt` - Full context router with topic routing
- `/docs/*.md` - Markdown mirrors of all documentation
- `/docs/sitemap.xml` - Sitemap for docs discovery
- `/robots.txt` - Includes `/llms.txt` for agent crawlers
- `/agent-readability.json` - Agent readability metadata
- Search JSON - For integrated search functionality

## npm Package Bundle Flow

### Starting Point
The npm package bundle flow starts from `AGENTS.md` at the package root (in `node_modules/package-name/`).

### How It Works
1. **Direct packaging**: Run `leadtype generate --bundle` during npm package publishing
2. **Offline access**: All docs are bundled inside the npm tarball for offline agent access
3. **Relative links**: `AGENTS.md` uses relative links like `./docs/reference/cli.md`
4. **No network required**: Coding agents can read docs directly from `node_modules` without HTTP requests

### Artifacts Generated
- `AGENTS.md` - Main agent entry point at package root
- `docs/*.md` - Version-matched markdown files beneath the package root

### Artifacts Skipped (Website-Only)
Bundle mode explicitly skips these website-only artifacts:
- `llms.txt`
- `llms-full.txt`
- Search JSON
- Sitemap files (`/docs/sitemap.xml`, etc.)
- `robots.txt`
- `agent-readability.json`

## Key Differences

| Aspect | Hosted Website | npm Bundle |
|--------|---|---|
| **Entry Point** | `/llms.txt` | `AGENTS.md` |
| **Access Method** | HTTP requests | File system (node_modules) |
| **Network Required** | Yes | No |
| **Link Style** | Absolute/HTTP | Relative paths |
| **Discovery Artifacts** | llms.txt, llms-full.txt, sitemap, robots.txt | None |
| **Search Support** | Included | Skipped |
| **Use Case** | Public hosted documentation | Package-bundled offline docs |

## Summary

**Hosted website flow** begins at `/llms.txt` and leverages HTTP discovery with full routing infrastructure, search capabilities, and crawler-friendly artifacts.

**npm bundle flow** begins at `AGENTS.md` and uses relative links for offline access within node_modules, eliminating the need for discovery and routing artifacts while maintaining the same markdown content.
