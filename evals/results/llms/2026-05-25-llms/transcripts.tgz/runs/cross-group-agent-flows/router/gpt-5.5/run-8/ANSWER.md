# Cross-group agent flows: hosted website vs npm bundle

Leadtype supports two complementary agent flows:

## Hosted website flow

- **Starting file:** `/llms.txt` at the hosted site root.
- **How agents navigate:** HTTP agents fetch `/llms.txt`, follow its links to `/llms-full.txt` or topic-specific markdown, and can request docs pages as markdown.
- **Generated website artifacts:** website mode writes `/llms.txt`, `/llms-full.txt`, markdown mirrors under `/docs/*.md`, sitemap files, robots.txt, search JSON, and `agent-readability.json`.
- **Typical use:** URL-based agents reading a public docs site over HTTP.

## npm package bundle flow

- **Starting file:** `AGENTS.md` at the npm package root.
- **How agents navigate:** coding agents working inside `node_modules` read `AGENTS.md` and follow relative links such as `./docs/reference/cli.md` to bundled `docs/*.md` files, without a network request.
- **Generated package artifacts:** `leadtype generate --bundle` writes `AGENTS.md` plus `docs/*.md` into the package tarball.
- **Typical use:** offline, version-matched docs shipped with an installed npm package.

## Website artifacts skipped by bundle mode

Bundle mode skips website-only artifacts:

- `llms.txt`
- `llms-full.txt`
- search JSON
- sitemap files
- `robots.txt`
- `agent-readability.json`
