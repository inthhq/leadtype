# Cross-group Agent Flows: Hosted vs npm Bundle

## Overview

Leadtype supports two complementary agent flows from the same MDX source: a **hosted website flow** for HTTP-based agents and an **npm bundle flow** for coding agents working inside installed packages. The two flows emit different sets of artifacts and have different entry points.

---

## 1. Hosted Website Flow

### Entry Point
HTTP agents start at **`/llms.txt`** (the product-level root file, at the site root). From there they can follow links to **`/llms-full.txt`** (the full-context router) and to the individual topic deep-context files it lists, then on to the markdown mirrors at **`/docs/*.md`**.

### How it works
- `leadtype generate` (without `--bundle`) runs in website mode.
- The build generates `/llms.txt` at the site root and markdown mirrors under `/docs/*.md`.
- Agents can also discover docs via `Accept: text/markdown` on any docs page, or through known AI user-agent routing.

### Artifacts produced (website mode)
| Artifact | Purpose |
|---|---|
| `/llms.txt` | Product-level entry point for HTTP agents |
| `/docs/llms.txt` | Docs-scoped map |
| `/llms-full.txt` | Root full-context router listing all topic files |
| `/docs/*.md` | Markdown mirrors of every docs page |
| `docs/sitemap.xml` | XML sitemap |
| `docs/sitemap.md` | Markdown sitemap |
| `docs/robots.txt` | Robots file (allows `/llms.txt`) |
| `docs/agent-readability.json` | Agent readability metadata |
| `docs/search-index.json` | Static search index |
| `docs/search-content.json` | Search content payload |

The `--json` flag causes `leadtype generate` to print a JSON object with paths for all of these artifacts (keys: `llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, `agentReadabilityJson`, `sitemapXml`, `sitemapMd`, `robotsTxt`, `searchIndex`, `searchContent`).

---

## 2. npm Bundle Flow

### Entry Point
Coding agents working inside an installed npm package start at **`AGENTS.md`** (written at the package root). From there they follow **relative links** like `./docs/reference/cli.md` to reach the bundled markdown docs — no network request required.

### How it works
- `leadtype generate --bundle` runs in bundle mode.
- The command writes `AGENTS.md` at the package root and `docs/*.md` beneath it.
- Relative links in `AGENTS.md` are designed to resolve correctly from inside `node_modules/`.
- `generateAgentsMd` intentionally ignores `product.agentGuidance` because that text is written for website URL routing, not offline package use.

### Artifacts produced (bundle mode)
| Artifact | Purpose |
|---|---|
| `AGENTS.md` | Entry point for coding agents in `node_modules` |
| `docs/*.md` | Markdown docs pages with relative links |

---

## 3. Website Artifacts That Bundle Mode Skips

Bundle mode deliberately **omits** every website-only artifact because they are either URL-dependent or not meaningful inside a local `node_modules` tree:

| Skipped Artifact | Why it is website-only |
|---|---|
| `llms.txt` | HTTP discovery entry point; requires a hosted URL |
| `llms-full.txt` | Full-context HTTP router; requires a hosted URL |
| Search JSON (`search-index.json`, `search-content.json`) | Runtime search index for the hosted site |
| Sitemap files (`sitemap.xml`, `sitemap.md`) | URL-based crawling/discovery |
| `robots.txt` | HTTP crawler instructions |
| `agent-readability.json` | Hosted-site agent metadata |

These paths are internally identified by `isAgentReadabilityArtifactPath` so they are never accidentally rewritten as missing markdown pages.

---

## Summary

| Dimension | Hosted Website Flow | npm Bundle Flow |
|---|---|---|
| **Agent entry point** | `/llms.txt` (HTTP, site root) | `AGENTS.md` (relative, package root) |
| **Link style** | Absolute URLs | Relative paths (`./docs/…`) |
| **CLI command** | `leadtype generate` | `leadtype generate --bundle` |
| **Network required** | Yes | No (works offline in `node_modules`) |
| **Website artifacts** | All (llms.txt, llms-full.txt, sitemaps, robots.txt, search JSON, agent-readability.json) | **Skipped** |
| **Doc page artifacts** | `/docs/*.md` (URL-addressable) | `docs/*.md` (relative) |

The two flows are designed to complement each other: a package can publish bundled offline docs for `node_modules`-based agents **and** host a website with `llms.txt` for URL-based agents, both generated from the same MDX source.
