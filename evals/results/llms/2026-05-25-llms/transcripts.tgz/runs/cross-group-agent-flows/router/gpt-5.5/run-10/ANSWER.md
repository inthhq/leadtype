# Cross-group agent flows: hosted vs npm bundle

## Hosted website flow

For a hosted Leadtype docs site, agents start at the site-root `llms.txt` file, i.e. `/llms.txt`. That file points them to the full-context router at `/llms-full.txt`, which then routes them to the smallest relevant topic file or markdown docs page.

The hosted build is designed for HTTP discovery:

- Root entry point: `/llms.txt`
- Full-context / routing file: `/llms-full.txt`
- Markdown mirrors: `/docs/*.md`
- Optional docs-scoped map: `/docs/llms.txt`
- Static website artifacts: sitemap files, `robots.txt`, search JSON, and `agent-readability.json`

For docs pages, the site should serve markdown when the request asks for `Accept: text/markdown` or when a known AI user agent requests a docs page.

## npm package bundle flow

For an npm package bundle, agents do not start from `/llms.txt`. They start from `AGENTS.md` at the package root inside the installed package, such as under `node_modules`.

Bundle mode is designed for offline, version-matched package docs:

- Root entry point: `AGENTS.md`
- Bundled markdown docs: `docs/*.md`
- Links are relative, for example `./docs/reference/cli.md`
- Agents can read the package docs locally without making a network request

This flow is produced with `leadtype generate --bundle`.

## Website artifacts skipped by bundle mode

Bundle mode skips website-only artifacts because they are only useful for hosted HTTP discovery and site indexing. Specifically, it does not write:

- `llms.txt`
- `llms-full.txt`
- search JSON
- sitemap files
- `robots.txt`
- `agent-readability.json`

In short: the hosted flow starts from `/llms.txt` and exposes web-discoverable routing, markdown, search, and crawler artifacts; the npm bundle flow starts from package-root `AGENTS.md` and includes only the relative-linked markdown docs needed by coding agents inside the installed package.
