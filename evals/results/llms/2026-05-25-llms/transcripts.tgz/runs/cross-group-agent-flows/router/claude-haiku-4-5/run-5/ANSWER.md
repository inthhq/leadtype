# Cross-group agent flows: hosted vs npm bundle

## Overview

Leadtype supports two complementary agent flows for different deployment scenarios:
- **Hosted website flow**: For HTTP-based agents accessing docs via URLs
- **NPM bundle flow**: For coding agents working inside installed npm packages

## Starting Files

### Hosted Website Flow
- **Starts from**: `/llms.txt` (product-level entry point at site root)
- HTTP agents fetch `/llms.txt` and follow markdown links to discover documentation

### NPM Bundle Flow
- **Starts from**: `AGENTS.md` (package-root entry point)
- Coding agents read `AGENTS.md` and follow relative links like `./docs/reference/cli.md` to access docs inside `node_modules`

## Website Artifacts Skipped by Bundle Mode

Bundle mode (`leadtype generate --bundle`) intentionally excludes the following website-specific artifacts:

1. **llms.txt** - Product-level discovery file
2. **llms-full.txt** - Full context router for hosted docs
3. **Search JSON** - Search index artifacts
4. **Sitemap files** - XML/HTML sitemaps for web crawlers
5. **robots.txt** - Web crawler directives
6. **agent-readability.json** - Agent readability metadata

## Key Differences

| Aspect | Hosted Flow | Bundle Flow |
|--------|------------|------------|
| Entry Point | `/llms.txt` | `AGENTS.md` |
| Link Style | HTTP URLs (e.g., `/docs/reference/cli.md`) | Relative paths (e.g., `./docs/reference/cli.md`) |
| Access Model | Network-based, requires HTTP | Offline, local file access |
| Generated Artifacts | Full website artifacts including discovery files and metadata | Only `AGENTS.md` and `docs/*.md` |
| Use Case | URL-based agents accessing hosted website | Coding agents in installed npm packages |

## Complementary Design

These flows are intentionally complementary: a single package can publish both bundled offline docs for npm `node_modules` installations and a hosted docs website with `llms.txt` for URL-based agents. This allows maximum flexibility for different agent deployment scenarios.
