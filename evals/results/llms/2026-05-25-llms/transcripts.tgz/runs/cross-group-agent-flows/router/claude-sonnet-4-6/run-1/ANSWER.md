# Cross-group Agent Flows: Hosted Website vs npm Bundle

## Overview

Leadtype generates two distinct agent-readable flows from the same MDX source tree:
one for **hosted websites** (HTTP-discoverable) and one for **npm package bundles**
(offline, file-system accessible). The two flows complement each other and can be
used simultaneously.

---

## 1. Hosted Website Flow

### Entry point
HTTP agents start at **`/llms.txt`** (the product-level file at the site root).

### How the flow works
1. An agent fetches `/llms.txt`, which acts as a router.
2. `/llms.txt` links to **`/llms-full.txt`** (the full-context router), which in
   turn links to per-topic deep-context files such as
   `/docs/llms-full/build.txt`, `/docs/llms-full/get-started.txt`, etc.
3. Agents can also fetch any individual docs page by requesting it with
   `Accept: text/markdown`, receiving the markdown mirror for that page.

### Files generated (website mode)
`leadtype generate` (without `--bundle`) writes:

| Artifact | Path |
|---|---|
| Product-level agent index | `/llms.txt` |
| Docs-scoped agent index | `/docs/llms.txt` |
| Full-context router | `/llms-full.txt` |
| Markdown mirrors of docs | `/docs/*.md` |
| Docs sitemap (XML) | `/docs/sitemap.xml` |
| Docs sitemap (Markdown) | `/docs/sitemap.md` |
| Robots rules | `/docs/robots.txt` |
| Agent-readability manifest | `/docs/agent-readability.json` |
| Search index | `/docs/search-index.json` |
| Search content | `/docs/search-content.json` |

The `--json` flag makes `leadtype generate` print a JSON object whose keys include
`llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, `agentReadabilityJson`, `sitemapXml`,
`sitemapMd`, `robotsTxt`, `searchIndex`, and `searchContent`.

### Guidance note
`generateLlmsTxt` writes the product-level and docs-scoped `.txt` maps.
`generateLLMFullContextFiles` assembles one root `/llms-full.txt` containing every
generated markdown page (groups organise its sections but are not published as
separate per-group full-context files by default).

---

## 2. npm Bundle Flow

### Entry point
Coding agents working inside an installed npm package start at **`AGENTS.md`** at
the package root (i.e. `node_modules/<package>/AGENTS.md`).

### How the flow works
1. `leadtype generate --bundle` writes `AGENTS.md` at the package root.
2. `AGENTS.md` uses **relative links** (e.g. `./docs/reference/cli.md`) so agents
   can navigate to topic files without any network request.
3. Agents follow those relative links to `docs/*.md` files bundled inside the
   tarball.

### Files generated (bundle mode)
`leadtype generate --bundle` writes only:

| Artifact | Path |
|---|---|
| Agent entry point | `AGENTS.md` (package root) |
| Markdown docs | `docs/*.md` |

`generateAgentsMd` intentionally ignores `product.agentGuidance` because that text
is written for website URL routing, which does not apply in an offline package
context.

---

## 3. What Bundle Mode Skips

Bundle mode omits all **website-only artifacts**. These files are irrelevant without
an HTTP server and are explicitly excluded:

| Skipped Artifact | Reason |
|---|---|
| `llms.txt` | HTTP-discovery index; no server in node_modules |
| `llms-full.txt` | Full-context router for URL-based agents |
| Search JSON (`search-index.json`, `search-content.json`) | Static search index built for hosted runtime |
| Sitemap files (`sitemap.xml`, `sitemap.md`) | URL-based crawling only |
| `robots.txt` | HTTP crawler rules; meaningless offline |
| `agent-readability.json` | Hosted agent-readability manifest |

The helper `isAgentReadabilityArtifactPath` identifies all of these paths so they
are never accidentally rewritten as missing markdown pages.

---

## 4. Side-by-side Summary

| Dimension | Hosted Website Flow | npm Bundle Flow |
|---|---|---|
| **Start file** | `/llms.txt` | `AGENTS.md` |
| **Navigation style** | Absolute URLs, HTTP links | Relative file paths (`./docs/…`) |
| **Network required** | Yes | No (works inside `node_modules`) |
| **CLI command** | `leadtype generate` | `leadtype generate --bundle` |
| **Skips** | — | `llms.txt`, `llms-full.txt`, search JSON, sitemaps, `robots.txt`, `agent-readability.json` |
| **Key generator function** | `generateLlmsTxt` + `generateLLMFullContextFiles` | `generateAgentsMd` |

---

## Sources

- `/docs/how-it-works.md` — pipeline model and flow descriptions  
- `/docs/quickstart.md` — artifact lists for both modes  
- `/docs/build/connect-docs-site.md` — hosted website mode details  
- `/docs/package-docs/bundle.md` — bundle mode details and skipped artifacts  
- `/docs/reference/cli.md` — CLI flags and JSON output keys  
- `/docs/reference/llm.md` — generator function responsibilities  
