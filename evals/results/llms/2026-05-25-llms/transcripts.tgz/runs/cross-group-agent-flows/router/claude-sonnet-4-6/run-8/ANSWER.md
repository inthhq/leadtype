# Cross-group Agent Flows: Hosted vs npm Bundle

## Overview

Leadtype runs the same MDX source through two distinct agent-readable output modes: **hosted website mode** and **npm bundle mode**. Each mode targets a different kind of agent and produces a different set of artifacts. The two flows complement each other — a project can publish both simultaneously.

---

## 1. Hosted Website Flow

### Entry Point for Agents

HTTP/URL-based agents start at **`/llms.txt`** at the site root.

- `/llms.txt` is the product-level entry point.
- `/docs/llms.txt` is a docs-scoped map.
- `/llms-full.txt` is a root full-context fallback containing every generated markdown page.

Agents follow markdown links from `llms.txt` into the individual pages (e.g. `/docs/reference/cli.md`).

### How the Flow Works

1. Leadtype reads MDX source files under `docs/`, processes frontmatter and group metadata, and flattens MDX components into portable markdown.
2. Running **`leadtype generate`** (without `--bundle`) writes the full set of website artifacts.
3. For agent requests, the server serves markdown when `Accept: text/markdown` is sent, or when a known AI user-agent requests a docs page.

### Artifacts Generated (Website Mode)

| Artifact | Purpose |
|---|---|
| `/llms.txt` | Product-level agent entry point |
| `/docs/llms.txt` | Docs-scoped agent map |
| `/llms-full.txt` | Root full-context file with all pages |
| `/docs/*.md` | Markdown mirrors of every MDX page |
| `docs/sitemap.xml` | XML sitemap for crawlers |
| `docs/sitemap.md` | Markdown sitemap |
| `docs/robots.txt` | Crawler permissions (allows `/llms.txt`) |
| `docs/agent-readability.json` | Agent-readability metadata |
| `docs/search-index.json` | Static search index |
| `docs/search-content.json` | Search content source |

When `--json` is enabled, `leadtype generate` prints a JSON object with keys: `llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, `agentReadabilityJson`, `sitemapXml`, `sitemapMd`, `robotsTxt`, `searchIndex`, and `searchContent`.

---

## 2. npm Bundle Flow

### Entry Point for Agents

Coding agents working inside installed npm packages start at **`AGENTS.md`** at the package root.

- `AGENTS.md` uses **relative links** (e.g. `./docs/reference/cli.md`) so agents can read docs inside `node_modules` **without a network request**.

### How the Flow Works

1. Same MDX source is used as input.
2. Running **`leadtype generate --bundle`** activates bundle mode.
3. `AGENTS.md` is written at the package root; `docs/*.md` files are written beneath it.
4. The `--bundle` flag causes `generateAgentsMd` to intentionally ignore `product.agentGuidance` (that text is written for website URL routing, not offline use).

### Artifacts Generated (Bundle Mode)

| Artifact | Purpose |
|---|---|
| `AGENTS.md` | Package-root agent entry point with relative links |
| `docs/*.md` | Markdown docs browsable offline inside `node_modules` |

---

## 3. What Bundle Mode Skips

Bundle mode deliberately **omits all website-only artifacts**:

| Skipped Artifact | Why It's Skipped |
|---|---|
| `llms.txt` | HTTP discovery artifact; not meaningful offline |
| `llms-full.txt` | URL-based full-context fallback; not needed in node_modules |
| `search-index.json` / `search-content.json` | Static search is a hosted-site concern |
| `sitemap.xml` / `sitemap.md` | Crawler sitemaps have no role inside a tarball |
| `robots.txt` | Crawler permissions file; irrelevant in npm bundle |
| `agent-readability.json` | Website-level metadata artifact |

The function `isAgentReadabilityArtifactPath` in the API identifies these paths so they are never rewritten as missing markdown pages.

---

## 4. Side-by-Side Summary

| Dimension | Hosted Website Flow | npm Bundle Flow |
|---|---|---|
| **Command** | `leadtype generate` | `leadtype generate --bundle` |
| **Agent entry file** | `/llms.txt` (HTTP URL) | `AGENTS.md` (relative path) |
| **Link style** | Absolute URLs | Relative file paths (`./docs/…`) |
| **Network required?** | Yes (HTTP requests) | No (reads from `node_modules`) |
| **Full-context fallback** | `/llms-full.txt` | None (AGENTS.md covers it) |
| **Search artifacts** | ✅ Included | ❌ Skipped |
| **Sitemap / robots** | ✅ Included | ❌ Skipped |
| **agent-readability.json** | ✅ Included | ❌ Skipped |
| **Target agent type** | HTTP/URL-based agents | Coding agents (e.g. in IDEs) |

---

## Sources

- `/docs/how-it-works.md` — pipeline model and the two complementary flows
- `/docs/quickstart.md` — artifact lists for both modes
- `/docs/build/connect-docs-site.md` — hosted website mode detail
- `/docs/package-docs/bundle.md` — bundle mode detail and skipped artifacts
- `/docs/reference/cli.md` — CLI flags and JSON output keys
- `/docs/reference/llm.md` — `generateLlmsTxt`, `generateAgentsMd`, `isAgentReadabilityArtifactPath`
