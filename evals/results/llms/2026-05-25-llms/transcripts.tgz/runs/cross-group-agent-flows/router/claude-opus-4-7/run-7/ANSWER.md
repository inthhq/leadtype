# Cross-group agent flows: hosted website vs. npm bundle

Leadtype emits two complementary flavors of agent-readable docs from the same MDX source. The hosted site flow targets agents that fetch over HTTP, and the npm bundle flow targets coding agents reading files inside `node_modules`. The docs describe them in two different groups: **Build** (hosted) and **Ship Package Docs** (bundle).

## Where each flow starts

### Hosted website flow (website mode)

- **Entry file for agents:** `/llms.txt` at the site root.
- **Router behind it:** `/llms-full.txt`, which routes to per-topic `docs/llms-full/*.txt` deep-context files; from there agents follow links to markdown mirrors under `/docs/*.md`.
- **How requests are served:** the site serves markdown when the request's `Accept` header asks for `text/markdown`, or when a known AI user agent requests a docs page (per `docs/build/connect-docs-site.md`).
- **Verification touchpoints:** fetching `/llms.txt`, fetching a docs page with `Accept: text/markdown`, checking `/docs/sitemap.xml`, and confirming `/robots.txt` allows `/llms.txt`.

### npm package bundle flow (bundle mode)

- **Entry file for agents:** `AGENTS.md` at the package root, written by `leadtype generate --bundle`.
- **Router behind it:** `AGENTS.md` uses **relative** links such as `./docs/reference/cli.md`, so coding agents inside `node_modules` can read everything without a network request.
- **How requests are served:** there is no server — files are read directly off disk inside the installed package.

The two flows are designed to coexist: a package can publish a bundled offline copy for `node_modules` *and* a hosted docs site with `/llms.txt` for URL-based agents (see `docs/how-it-works.md`).

## What each flow emits

From `docs/quickstart.md` and the Build / Package Docs topic files:

### Website mode writes
- `/llms.txt` and `/docs/llms.txt`
- `/llms-full.txt`
- Markdown mirrors under `/docs/*.md`
- `docs/sitemap.xml`, `docs/sitemap.md`
- `docs/robots.txt`
- `docs/agent-readability.json`
- `docs/search-index.json`, `docs/search-content.json`

### Bundle mode writes
- `AGENTS.md` at the package root
- `docs/*.md` beneath it (with relative links)

## Website artifacts that bundle mode skips

Per `docs/package-docs/bundle.md`, bundle mode deliberately omits the website-only artifacts:

| Skipped artifact | Why it belongs only to the hosted site |
|---|---|
| `llms.txt` | HTTP entry point; bundle uses `AGENTS.md` instead. |
| `llms-full.txt` | HTTP router; bundle relies on relative `./docs/...` links from `AGENTS.md`. |
| `search-index.json` (search JSON) | Powers site search; no server in `node_modules`. |
| `search-content.json` (search JSON) | Same — site-only search payload. |
| `sitemap.xml` / `sitemap.md` (sitemap files) | URL discovery for crawlers; meaningless on disk. |
| `robots.txt` | Crawl policy for HTTP clients. |
| `agent-readability.json` | Static site metadata endpoint for agents. |

In short: hosted mode publishes a discoverable HTTP surface starting at `/llms.txt` plus a sitemap/robots/search/agent-readability metadata layer; bundle mode strips all of that and ships a single self-contained `AGENTS.md` + `docs/*.md` tree that works offline inside an npm tarball.
