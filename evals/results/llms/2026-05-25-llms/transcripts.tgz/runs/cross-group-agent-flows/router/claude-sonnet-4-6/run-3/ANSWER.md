# Cross-group Agent Flows: Hosted Website vs npm Bundle

## Overview

Leadtype supports two distinct agent flows from the same MDX source: one for **HTTP/URL-based agents** that discover docs through a hosted website, and one for **coding agents** that read docs offline from an installed npm package. The two flows are complementary—a project can publish both simultaneously.

---

## 1. Hosted Website Flow

### Entry Point
HTTP agents start at **`/llms.txt`** at the site root.

From there, agents follow links to:
- **`/llms-full.txt`** — the root full-context router, which aggregates every generated markdown docs page and routes agents to topic-specific files.
- **`/docs/*.md`** — per-page markdown mirrors of the MDX source content.

### How It Works
- The build runs `leadtype generate` (without `--bundle`).
- The server serves markdown when a request includes `Accept: text/markdown` or comes from a known AI user agent.
- Agents navigate via URL-based links found in `llms.txt` and `llms-full.txt`.

### Artifacts Generated (Website Mode)
| Artifact | Purpose |
|---|---|
| `/llms.txt` | Product-level agent entry point |
| `/docs/llms.txt` | Docs-scoped map |
| `/llms-full.txt` | Root full-context router (all docs pages aggregated) |
| `/docs/*.md` | Markdown mirrors of MDX pages |
| `docs/sitemap.xml` | XML sitemap |
| `docs/sitemap.md` | Markdown sitemap |
| `docs/robots.txt` | Crawler/agent permissions |
| `docs/agent-readability.json` | Agent-readability metadata |
| `docs/search-index.json` | Static search index |
| `docs/search-content.json` | Search content payload |

---

## 2. npm Bundle Flow

### Entry Point
Coding agents working inside an installed npm package start at **`AGENTS.md`** at the package root.

From there, agents follow **relative links** like `./docs/reference/cli.md` to reach:
- **`docs/*.md`** — markdown docs bundled beneath the package root, navigable without any network request.

### How It Works
- The build runs `leadtype generate --bundle`.
- `generateAgentsMd` writes `AGENTS.md`. Notably, it **intentionally ignores** `product.agentGuidance` because that text is written for website URL routing, not for offline package navigation.
- All links in `AGENTS.md` are **relative** so they resolve correctly inside `node_modules/`.

### Artifacts Generated (Bundle Mode)
| Artifact | Purpose |
|---|---|
| `AGENTS.md` | Coding-agent entry point at package root |
| `docs/*.md` | Markdown docs, linked relatively from AGENTS.md |

---

## 3. Website Artifacts That Bundle Mode Skips

Bundle mode deliberately omits every artifact that only makes sense for a live hosted website. According to the docs, bundle mode skips:

| Skipped Artifact | Why It Is Website-Only |
|---|---|
| `llms.txt` | URL-discovery entry point; meaningless without an HTTP server |
| `llms-full.txt` | Full-context router based on absolute URLs |
| `search-index.json` | Static search index served at runtime from a host |
| `search-content.json` | Search content payload for the hosted search runtime |
| `sitemap.xml` (and `sitemap.md`) | Web crawler / sitemap protocol artifacts |
| `robots.txt` | HTTP crawler permissions file |
| `agent-readability.json` | Hosted agent-readability metadata |

The CLI's `--json` output for website mode lists all of these paths (`llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, `agentReadabilityJson`, `sitemapXml`, `sitemapMd`, `robotsTxt`, `searchIndex`, `searchContent`), none of which appear in a bundle build. Internally, `isAgentReadabilityArtifactPath` identifies these paths so they are never rewritten as missing markdown pages on the website.

---

## Summary

| Dimension | Hosted Website Flow | npm Bundle Flow |
|---|---|---|
| **Entry file** | `/llms.txt` | `AGENTS.md` |
| **Navigation** | Absolute URLs via `llms-full.txt` | Relative paths (`./docs/*.md`) |
| **Network required** | Yes (HTTP) | No (reads from `node_modules`) |
| **CLI command** | `leadtype generate` | `leadtype generate --bundle` |
| **Skips** | — | `llms.txt`, `llms-full.txt`, `search-index.json`, `search-content.json`, `sitemap.xml`, `sitemap.md`, `robots.txt`, `agent-readability.json` |
| **Includes** | All artifacts above + markdown mirrors | `AGENTS.md` + `docs/*.md` only |

The two flows are designed to complement each other: the hosted flow serves URL-based agents discovering docs from the web, while the bundle flow serves coding agents (e.g., in an IDE or CI environment) that read docs directly from the installed package—no network request needed.
