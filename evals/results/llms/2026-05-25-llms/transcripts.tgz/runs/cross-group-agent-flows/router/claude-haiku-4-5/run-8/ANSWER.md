# Cross-group Agent Flows: Hosted vs NPM Bundle

## Overview

Leadtype supports two complementary agent flows for accessing documentation: a hosted website flow and an npm package bundle flow. Both flows are driven by the same MDX source but produce different entry points and artifacts.

## Hosted Website Flow

### Starting Point
- **Entry file**: `/llms.txt` (at the website root)
- **Access pattern**: HTTP agents discover the docs site and fetch `/llms.txt` to bootstrap their documentation reading
- **Navigation**: Agents follow markdown links from `/llms.txt` to additional pages

### Generated Artifacts
The hosted website flow generates multiple artifacts:
- `/llms.txt` - Main entry point at site root
- `/llms-full.txt` - Fallback containing all generated markdown pages (not split by group)
- `/docs/llms.txt` - Group-aware routing hint file
- `/docs/*.md` - Markdown mirrors of all MDX pages
- `/docs/sitemap.xml` - XML sitemap for discoverability
- `/docs/sitemap.md` - Markdown sitemap
- `/docs/robots.txt` - Robots exclusion file
- `/docs/agent-readability.json` - Agent readability metadata
- `/docs/search-index.json` and `/docs/search-content.json` - Search indexes

### Group Handling
- The `group` frontmatter field drives the structure of `/llms.txt` and determines which section agents discover
- `/llms-full.txt` contains all pages as a fallback, not split by group
- Groups are used to organize routing hints and sidebar positioning

## NPM Bundle Flow

### Starting Point
- **Entry file**: `AGENTS.md` (at the package root)
- **Access pattern**: Coding agents working inside installed npm packages find `AGENTS.md` directly
- **Navigation**: Agents follow relative links like `./docs/reference/cli.md` from `AGENTS.md`

### Generated Artifacts
The bundle flow generates fewer artifacts optimized for offline use:
- `AGENTS.md` - Main entry point at package root
- `docs/*.md` - Markdown docs using relative links for offline access within node_modules

### Group Handling
- Similar group semantics apply, with `AGENTS.md` being group-aware
- Uses relative links instead of HTTP URLs to work offline inside node_modules
- No need for absolute paths or HTTP routing

## Artifacts Skipped in Bundle Mode

Bundle mode intentionally skips website-only artifacts that are not useful for offline consumption in npm packages:

1. **llms.txt** - HTTP router for website discovery
2. **llms-full.txt** - Full context file for web-based agents
3. **search-index.json** - Search index (search runs on the hosted site, not in packages)
4. **search-content.json** - Search content data
5. **sitemap.xml** - XML sitemap for search engines
6. **sitemap.md** - Markdown sitemap for website navigation
7. **robots.txt** - Robot exclusion rules
8. **agent-readability.json** - Agent readability metadata

## Summary

| Aspect | Hosted Website | NPM Bundle |
|--------|---|---|
| **Starting File** | `/llms.txt` | `AGENTS.md` |
| **Discovery Method** | HTTP, user agents | Local filesystem in node_modules |
| **Link Style** | Absolute URLs | Relative paths (e.g., `./docs/reference/cli.md`) |
| **Primary Use Case** | URL-based AI agents fetching over HTTP | Offline coding agents in node_modules |
| **Website Artifacts** | ✓ Full suite (llms.txt, search, sitemaps, robots.txt) | ✗ Skipped |
| **Core Docs** | ✓ `/docs/*.md` markdown mirrors | ✓ `docs/*.md` markdown files |
| **Complementary** | Work together—same package can publish both | Yes, both flows can coexist |

The two flows complement each other: a package can publish bundled offline docs for node_modules and a hosted docs website with llms.txt for URL-based agents, all generated from the same MDX source.
