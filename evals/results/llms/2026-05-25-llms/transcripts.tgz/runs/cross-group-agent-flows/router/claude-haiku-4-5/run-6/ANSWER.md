# Cross-Group Agent Flows: Hosted vs NPM Bundle

## Overview

Leadtype produces two distinct agent-facing flows that serve different deployment contexts:

1. **Hosted Website Flow**: For agents discovering and fetching docs via HTTP
2. **NPM Bundle Flow**: For agents reading docs from installed packages offline

Both flows start from the same MDX source but produce different artifacts and entry points for agents.

## Hosted Website Flow

**Starting Point**: `/llms.txt` (at the site root)

When running `leadtype generate` in website mode, agents discover documentation through:

1. **HTTP Discovery**: Agents start at `/llms.txt` and follow markdown links
2. **Full Context Router**: Agents can follow links to `/llms-full.txt` for deeper context routing

**Generated Artifacts**:
- `/llms.txt` - Entry point for HTTP agents
- `/llms-full.txt` - Full context router with topic routing
- `/docs/llms.txt` - Mirror of root llms.txt
- Markdown mirrors under `/docs/*.md` for each documentation page
- `/docs/sitemap.xml` - XML sitemap for crawlability
- `/docs/sitemap.md` - Markdown sitemap
- `/docs/robots.txt` - Robot directives
- `/docs/agent-readability.json` - Machine-readable agent guidance
- `/docs/search-index.json` - Search index for queries
- `/docs/search-content.json` - Search content data

## NPM Bundle Flow

**Starting Point**: `AGENTS.md` (at the package root in node_modules)

When running `leadtype generate --bundle`, agents access documentation offline through:

1. **Bundle Discovery**: Agents start at `AGENTS.md` in the installed package
2. **Relative Links**: AGENTS.md uses relative links like `./docs/reference/cli.md` so agents can read docs without network requests
3. **Local File Access**: Agents follow relative markdown links within `docs/*.md`

**Generated Artifacts**:
- `AGENTS.md` - Entry point for coding agents in node_modules
- `docs/*.md` - Documentation files with relative links

## Website Artifacts Skipped in Bundle Mode

Bundle mode explicitly skips all website-only infrastructure artifacts:

- `llms.txt` - HTTP discovery entry point (not needed for offline access)
- `llms-full.txt` - Full context router (not needed for bundled packages)
- Search JSON files (`search-index.json`, `search-content.json`)
- Sitemap files (`sitemap.xml`, `sitemap.md`)
- `robots.txt` - Robot directives (not applicable to local files)
- `agent-readability.json` - Machine-readable agent guidance

## Key Differences

| Aspect | Hosted Flow | Bundle Flow |
|--------|-------------|-------------|
| **Entry Point** | `/llms.txt` | `AGENTS.md` |
| **Network Access** | HTTP-based discovery | Offline/local file system |
| **Link Style** | Absolute/relative to site root | Relative to package root |
| **Discovery** | Router files guide navigation | Direct relative links in markdown |
| **Search** | JSON search indexes | Not applicable |
| **Sitemaps** | XML and markdown sitemaps | Not generated |
| **Use Case** | Web-accessible agents | Installed package agents (node_modules) |

## Complementary Deployment

A single package can publish both:
- **Bundled offline docs** for agents reading from installed `node_modules` (via AGENTS.md)
- **Hosted docs website** with `/llms.txt` for URL-based HTTP agents

This dual approach allows organizations to serve both coding agents (accessing offline package docs) and HTTP-based agents (discovering and fetching docs from a hosted site).
