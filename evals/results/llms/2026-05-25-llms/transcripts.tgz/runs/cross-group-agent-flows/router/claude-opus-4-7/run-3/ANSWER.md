# Cross-group agent flows: hosted website vs npm bundle

Leadtype emits two complementary sets of artifacts from one MDX source. Agents enter each flow through a different starter file, and bundle mode deliberately skips the HTTP-only artifacts the website flow depends on.

Sources consulted:
- `/llms.txt`
- `/llms-full.txt`
- `/docs/llms-full/get-started.txt` (`/docs/quickstart.md`, `/docs/how-it-works.md`)
- `/docs/llms-full/build.txt` (`/docs/build/connect-docs-site.md`)
- `/docs/llms-full/package-docs.txt` (`/docs/package-docs/bundle.md`)

## Where each flow starts

| Flow | Generator command | Agent entry file | Link style |
|------|-------------------|------------------|------------|
| Hosted website | `leadtype generate` (website mode) | `/llms.txt` at the site root | Absolute URLs to markdown mirrors under `/docs/*.md` |
| npm package bundle | `leadtype generate --bundle` | `AGENTS.md` at the package root | Relative links like `./docs/reference/cli.md` |

Per `/docs/how-it-works.md`: "HTTP agents start at `/llms.txt` and follow markdown links. Coding agents working inside installed npm packages start at `AGENTS.md` and follow relative `docs/*.md` links." The relative links matter because bundle consumers read docs straight from `node_modules` with no network request.

## What the hosted website flow produces

From `/docs/quickstart.md` and `/docs/build/connect-docs-site.md`, website mode writes:

- `/llms.txt` (root router)
- `/docs/llms.txt`
- `/llms-full.txt` (full-context router)
- Markdown mirrors under `/docs/*.md`
- `docs/sitemap.xml` and `docs/sitemap.md`
- `docs/robots.txt`
- `docs/agent-readability.json`
- `docs/search-index.json` and `docs/search-content.json`

The hosted site is also expected to content-negotiate: serve markdown when `Accept: text/markdown` is requested or when a known AI user agent fetches a docs page. The `llms.txt`, `llms-full.txt`, sitemap files, `robots.txt`, search JSON, and `agent-readability.json` are kept as static artifacts so agents can discover them by URL.

## What the npm bundle flow produces

From `/docs/package-docs/bundle.md`, `--bundle` writes only:

- `AGENTS.md` at the package root
- `docs/*.md` beneath it (with relative links)

That is the entire surface a coding agent inside `node_modules` needs.

## Website artifacts that bundle mode skips

`/docs/package-docs/bundle.md` is explicit: "Bundle mode skips website-only artifacts." Those are:

- `llms.txt`
- `llms-full.txt`
- Search JSON (`search-index.json`, `search-content.json`)
- Sitemap files (`sitemap.xml`, `sitemap.md`)
- `robots.txt`
- `agent-readability.json`

These are skipped because they only make sense for HTTP discovery (routing, crawler hints, sitemaps, search indexes, readability advertisement). An agent reading a tarball on disk reaches every doc via `AGENTS.md`'s relative links, so none of those discovery artifacts are needed.

## How the two flows fit together

Per `/docs/how-it-works.md`, a single package can do both: publish a bundled, offline-friendly doc set into its npm tarball for `node_modules` agents, while a hosted docs site exposes `/llms.txt` and the full website artifact set for URL-based agents. The MDX sources, frontmatter, and group tree are shared; only the emitted artifacts differ.
