# Cross-Group Agent Flows: Hosted vs NPM Bundle

## Overview

Leadtype supports two distinct agent flows that work with the same MDX source but emit different artifacts depending on the deployment mode.

## Hosted Website Flow

**Starting Point:** `/llms.txt`

The hosted website flow serves HTTP-discoverable agent files that enable remote agents to fetch documentation via network requests.

**Agent Flow:**
- HTTP agents start by fetching `/llms.txt` at the site root
- Agents follow markdown links to discover additional documentation
- All content is served over HTTP with proper content negotiation

**Website Artifacts Generated:**
- `/llms.txt` - Entry point for agents
- `/llms-full.txt` - Full context router
- `/docs/*.md` - Markdown mirrors of documentation
- `/docs/sitemap.xml` and `/docs/sitemap.md` - Site maps
- `/docs/robots.txt` - Robot instructions
- `/docs/agent-readability.json` - Agent readability metadata
- `/docs/search-index.json` and `/docs/search-content.json` - Search indices

## NPM Bundle Flow

**Starting Point:** `AGENTS.md`

The bundle flow packages documentation inside an npm tarball for offline consumption by coding agents working within installed node_modules.

**Agent Flow:**
- Coding agents start at `AGENTS.md` at the package root
- Agents follow relative links like `./docs/reference/cli.md`
- No network requests are needed—all docs are available locally in node_modules

**Package Artifacts Generated:**
- `AGENTS.md` - Entry point for coding agents
- `docs/*.md` - Documentation files with relative links

**Website Artifacts Skipped (Not Generated in Bundle Mode):**
- `llms.txt`
- `llms-full.txt`
- `search-index.json` and `search-content.json`
- `sitemap.xml` and `sitemap.md`
- `robots.txt`
- `agent-readability.json`

## Key Differences

| Aspect | Hosted Flow | Bundle Flow |
|--------|-------------|------------|
| **Entry Point** | `/llms.txt` | `AGENTS.md` |
| **Link Type** | Absolute URLs | Relative paths |
| **Deployment** | Website hosting | npm package |
| **Agent Type** | HTTP agents (remote) | Coding agents (local) |
| **Network Access** | Required | Not needed |
| **Website Artifacts** | Full set (llms.txt, search, sitemaps, etc.) | None (skipped) |

## Complementary Deployment

A single package can leverage both flows simultaneously:
1. Publish bundled offline docs via `npm package` with `AGENTS.md` for developers working locally
2. Host a website with `/llms.txt` for URL-based agents fetching documentation remotely

This dual approach enables maximum flexibility for different agent consumption patterns.
