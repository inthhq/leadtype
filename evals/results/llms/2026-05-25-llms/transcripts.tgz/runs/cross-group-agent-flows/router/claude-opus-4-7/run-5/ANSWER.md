# Cross-group agent flows: hosted website vs npm bundle

Leadtype's pipeline emits artifacts for two distinct agent audiences from one MDX source. The hosted website flow (documented in the **Build** group) targets HTTP-based agents, while the npm bundle flow (documented in the **Ship Package Docs** group) targets coding agents reading files directly from `node_modules`. The **Get Started** group's "How it works" page frames them as complementary: a single package can publish both.

## Sources consulted

- `/llms.txt` and `/llms-full.txt` — top-level routers.
- `/docs/llms-full/get-started.txt` — includes `/docs/quickstart.md` and `/docs/how-it-works.md`.
- `/docs/llms-full/build.txt` — includes `/docs/build/connect-docs-site.md` (website mode).
- `/docs/llms-full/package-docs.txt` — includes `/docs/package-docs/bundle.md` (bundle mode).

## Hosted website flow (website mode)

**Entry point for agents:** `/llms.txt` at the site root.

Per `docs/how-it-works.md`: "HTTP agents start at /llms.txt and follow markdown links." From `/llms.txt` they reach `/llms-full.txt` (the full-context router), which routes to topic files under `/docs/llms-full/*.txt`, which in turn link to the underlying `/docs/**/*.md` mirrors.

**Artifacts the website build emits** (from `docs/quickstart.md` and `docs/build/connect-docs-site.md`):

- `/llms.txt` and `/docs/llms.txt`
- `/llms-full.txt`
- Markdown mirrors under `/docs/*.md`
- `docs/sitemap.xml` and `docs/sitemap.md`
- `docs/robots.txt`
- `docs/agent-readability.json`
- `docs/search-index.json` and `docs/search-content.json`

**Serving rules** (from `docs/build/connect-docs-site.md`): serve markdown when `Accept: text/markdown` is requested, or when a known AI user agent fetches a docs page. The router/sitemap/robots/search/readability files are kept as static artifacts. Verification: fetch `/llms.txt`, fetch a docs page with `Accept: text/markdown`, check `/docs/sitemap.xml`, confirm `/robots.txt` allows `/llms.txt`.

## npm package bundle flow (bundle mode)

**Entry point for agents:** `AGENTS.md` at the package root inside `node_modules`.

Per `docs/how-it-works.md`: "Coding agents working inside installed npm packages start at AGENTS.md and follow relative docs/*.md links." `docs/package-docs/bundle.md` confirms `AGENTS.md` uses relative links like `./docs/reference/cli.md` so agents can read docs from disk without a network request.

**Trigger:** `leadtype generate --bundle` (from `docs/quickstart.md` and `docs/package-docs/bundle.md`).

**Artifacts the bundle emits:**

- `AGENTS.md` at the package root
- `docs/*.md` beneath it (version-matched to the package), with relative cross-links

## Website artifacts that bundle mode skips

From `docs/package-docs/bundle.md`, bundle mode explicitly **skips these website-only artifacts**:

| Skipped artifact | Why it is website-only |
|---|---|
| `llms.txt` | HTTP discovery root; useless without a URL |
| `llms-full.txt` | Companion router file; same reason |
| `search-index.json` (search JSON) | Powers the hosted search UI |
| `search-content.json` (search JSON) | Powers the hosted search UI |
| `sitemap.xml` / `sitemap.md` | SEO/crawler artifacts for a live site |
| `robots.txt` | Crawler policy for a live site |
| `agent-readability.json` | Static metadata served alongside the site |

In short: bundle mode keeps only the two things an offline coding agent needs — an `AGENTS.md` entry point and the `docs/*.md` corpus with relative links — and drops every artifact whose purpose is HTTP discovery, crawling, or search on the hosted site.

## Side-by-side summary

| Aspect | Hosted website flow | npm bundle flow |
|---|---|---|
| Group | Build | Ship Package Docs |
| Command | `leadtype generate` (website mode) | `leadtype generate --bundle` |
| Agent entry file | `/llms.txt` | `AGENTS.md` (package root) |
| Link style | Site-absolute URLs (e.g. `/docs/...md`) | Relative paths (e.g. `./docs/reference/cli.md`) |
| Audience | HTTP/URL-based agents | Coding agents inside `node_modules` |
| Markdown corpus | `/docs/*.md` mirrors served via content negotiation | `docs/*.md` shipped in the tarball |
| Routers | `llms.txt`, `llms-full.txt` | none (AGENTS.md only) |
| Discovery/SEO | `sitemap.xml`, `sitemap.md`, `robots.txt` | skipped |
| Search | `search-index.json`, `search-content.json` | skipped |
| Readability metadata | `agent-readability.json` | skipped |
