# Cross-group Agent Flows: Hosted Website vs npm Bundle

## Overview

Leadtype supports two complementary agent-readable flows from the same MDX source:
the **hosted website flow** (for HTTP/URL-based agents) and the **npm bundle flow**
(for coding agents working inside installed packages). Each flow has a distinct
entry-point file and produces a different set of output artifacts.

---

## 1. Hosted Website Flow

### Entry Point
Agents start at **`/llms.txt`** at the site root. From there they can follow links
to `/llms-full.txt` (the full-context router), then to topic-specific deep-context
files, and finally to individual markdown page mirrors under `/docs/*.md`.

> *"HTTP agents start at /llms.txt and follow markdown links."*
> — [How it works](/docs/how-it-works.md)

### Files Generated (`leadtype generate`, website mode)
| Artifact | Purpose |
|---|---|
| `/llms.txt` | Product-level agent entry point |
| `/docs/llms.txt` | Docs-scoped map |
| `/llms-full.txt` | Root full-context router / fallback |
| `/docs/*.md` | Markdown mirrors of every docs page |
| `docs/sitemap.xml` | XML sitemap |
| `docs/sitemap.md` | Markdown sitemap |
| `docs/robots.txt` | Crawler/agent permissions |
| `docs/agent-readability.json` | Agent-readability metadata |
| `docs/search-index.json` | Static search index |
| `docs/search-content.json` | Search content payload |

### How Agents Navigate It
1. Fetch **`/llms.txt`** (the product-level entry point).
2. Follow the link to **`/llms-full.txt`** (the full-context router).
3. Choose the smallest matching topic file (e.g., `/docs/llms-full/build.txt`).
4. Follow in-topic links to individual **`/docs/*.md`** pages.
5. Pages are also served with `Content-Type: text/markdown` when the request
   carries `Accept: text/markdown` or comes from a known AI user agent.

---

## 2. npm Bundle Flow

### Entry Point
Coding agents working inside installed npm packages start at **`AGENTS.md`** at the
**package root** (i.e., inside `node_modules/<package>/`). `AGENTS.md` uses
*relative* links (e.g., `./docs/reference/cli.md`) so agents can read all docs
without a network request.

> *"Coding agents working inside installed npm packages start at AGENTS.md and
> follow relative docs/*.md links."*
> — [How it works](/docs/how-it-works.md)

### Files Generated (`leadtype generate --bundle`, bundle mode)
| Artifact | Purpose |
|---|---|
| `AGENTS.md` | Offline agent entry point (package root) |
| `docs/*.md` | Markdown docs pages (relative links) |

### Key Difference in `AGENTS.md`
`generateAgentsMd` intentionally **ignores** `product.agentGuidance` because that
text is written for website URL routing — it has no meaning in an offline
node_modules context.

---

## 3. Website Artifacts That Bundle Mode Skips

Because bundle mode is designed for **offline, filesystem-based** access inside
`node_modules`, it omits every artifact that only makes sense for a live HTTP site:

| Skipped Artifact | Reason Skipped |
|---|---|
| `llms.txt` | HTTP discovery entry point — not needed offline |
| `llms-full.txt` | Full-context router for URL-based agents |
| `search-index.json` | Runtime search index requires a server/edge |
| `search-content.json` | Runtime search content, same reason |
| `sitemap.xml` | HTTP crawler artifact |
| `sitemap.md` | HTTP crawler artifact (markdown form) |
| `robots.txt` | Crawler permissions — meaningless in a tarball |
| `agent-readability.json` | Website agent-readability metadata |

> *"Bundle mode skips website-only artifacts: llms.txt, llms-full.txt, search JSON,
> sitemap files, robots.txt, and agent-readability.json."*
> — [Bundle docs into a package](/docs/package-docs/bundle.md)

The `isAgentReadabilityArtifactPath` utility in the reference API codifies exactly
this list — it identifies those paths so they are never mistakenly rewritten as
missing markdown pages.

---

## 4. Side-by-Side Summary

| Dimension | Hosted Website Flow | npm Bundle Flow |
|---|---|---|
| **Command** | `leadtype generate` | `leadtype generate --bundle` |
| **Agent entry point** | `/llms.txt` (URL) | `AGENTS.md` (relative file path) |
| **Navigation** | HTTP links → `/llms-full.txt` → `/docs/*.md` | Relative links → `./docs/*.md` |
| **Network required?** | Yes (HTTP) | No (filesystem only) |
| **llms.txt / llms-full.txt** | ✅ Generated | ❌ Skipped |
| **AGENTS.md** | ❌ Not generated | ✅ Generated |
| **docs/*.md mirrors** | ✅ Generated | ✅ Generated |
| **Search JSON** | ✅ Generated | ❌ Skipped |
| **Sitemap files** | ✅ Generated | ❌ Skipped |
| **robots.txt** | ✅ Generated | ❌ Skipped |
| **agent-readability.json** | ✅ Generated | ❌ Skipped |

The two flows are designed to **complement each other**: a package can ship bundled
offline docs for `node_modules` *and* maintain a hosted docs website with `llms.txt`
for URL-based agents — both generated from the same MDX source.
