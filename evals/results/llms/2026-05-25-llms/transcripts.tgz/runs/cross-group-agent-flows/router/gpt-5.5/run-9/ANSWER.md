# Cross-group agent flows: hosted website vs npm package bundle

Leadtype supports two complementary agent flows from the same MDX docs source.

## Hosted website flow

Hosted website mode is for HTTP-discoverable docs. Agents start at the site root:

- Start file: `/llms.txt`
- Typical next step: follow its link to `/llms-full.txt`, then choose the smallest topic/deep-context file for the task.
- Docs pages are available as markdown mirrors under `/docs/*.md`.

Website mode publishes agent and site artifacts such as:

- `/llms.txt`
- `/docs/llms.txt`
- `/llms-full.txt`
- markdown mirrors under `/docs/*.md`
- sitemap artifacts such as `docs/sitemap.xml` and `docs/sitemap.md`
- robots metadata such as `docs/robots.txt`
- readability metadata such as `docs/agent-readability.json`
- search artifacts such as `docs/search-index.json` and `docs/search-content.json`

This flow is intended for agents fetching docs over HTTP. The docs also describe serving markdown when `Accept: text/markdown` is requested or when a known AI user agent requests a docs page.

## npm package bundle flow

Bundle mode is for coding agents working inside an installed npm package, without needing network access.

- Command: `leadtype generate --bundle`
- Start file: `AGENTS.md` at the package root
- Docs location: `docs/*.md` inside the package tarball
- Link style: relative links, for example `./docs/reference/cli.md`, so the docs work from inside `node_modules`.

In this flow, the package carries version-matched markdown docs alongside the code. Agents start from `AGENTS.md` rather than a hosted `/llms.txt` URL.

## Website artifacts skipped by bundle mode

Bundle mode writes only `AGENTS.md` and bundled `docs/*.md`. It skips the website-only artifacts:

- `llms.txt`
- `llms-full.txt`
- search JSON files
- sitemap files
- `robots.txt`
- `agent-readability.json`

In short: hosted agents start from `/llms.txt` on the website; npm-package agents start from `AGENTS.md` in the package. Bundle mode replaces URL routing with relative package-local links and omits the hosted-site discovery, search, sitemap, robots, and readability artifacts.