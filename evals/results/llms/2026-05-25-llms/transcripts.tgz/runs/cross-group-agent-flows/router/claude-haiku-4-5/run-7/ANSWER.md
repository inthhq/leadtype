# Cross-group agent flows: hosted vs npm bundle

## Overview

Leadtype supports two different agent discovery flows for serving documentation to AI agents: a **hosted website flow** and an **npm package bundle flow**. Each has different starting points and artifacts.

## Hosted Website Flow

**Starting Point:** `/llms.txt` at the site root

**Process:**
- Agents fetch `/llms.txt` as the entry point
- `/llms.txt` routes to `/llms-full.txt` for full-context navigation
- `/llms-full.txt` routes to topic-specific deep-context files in `/docs/llms-full/`
- Agents fetch markdown mirrors served at `/docs/*.md`
- The site is configured to serve markdown when Accept headers request `text/markdown` or when known AI user agents request docs pages

**Key Artifacts Generated:**
- `/llms.txt` - entry point router
- `/llms-full.txt` - full-context router
- `/docs/*.md` - markdown mirrors of documentation
- `/docs/sitemap.xml` - sitemap for discoverability
- `/robots.txt` - crawling rules that allow `/llms.txt`
- `search.json` - search index
- `agent-readability.json` - agent configuration metadata

## NPM Package Bundle Flow

**Starting Point:** `AGENTS.md` at the package root

**Process:**
- Agents access `AGENTS.md` directly from `node_modules`
- `AGENTS.md` uses relative links like `./docs/reference/cli.md` for offline access
- All referenced markdown is included beneath `docs/` within the tarball
- No network requests are needed - everything is available locally in `node_modules`

**Key Artifacts Generated:**
- `AGENTS.md` - agent discovery entry point (relative link format)
- `docs/*.md` - markdown documentation files

## Artifacts Bundle Mode Skips

The npm bundle flow explicitly **skips website-only artifacts**:

- `llms.txt` - not needed for offline bundle discovery
- `llms-full.txt` - not needed for offline bundle discovery
- `search.json` - search functionality not applicable in bundle
- Sitemap files - HTTP discoverability not needed
- `robots.txt` - crawling rules not applicable to local files
- `agent-readability.json` - agent configuration metadata not needed for bundle

## Summary

| Aspect | Hosted Website | NPM Bundle |
|--------|---|---|
| **Entry Point** | `/llms.txt` | `AGENTS.md` |
| **Discovery Method** | HTTP requests to hosted URLs | Direct file access in `node_modules` |
| **Link Format** | Absolute URLs (`/docs/...`) | Relative links (`./docs/...`) |
| **Website-only Artifacts** | Included | Skipped |
| **Use Case** | Real-time hosted documentation access | Offline package documentation for dev tools |
