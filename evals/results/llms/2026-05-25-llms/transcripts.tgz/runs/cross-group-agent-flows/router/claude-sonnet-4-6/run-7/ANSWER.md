# Cross-group Agent Flows: Hosted Website vs npm Bundle

## Overview

Leadtype compiles one MDX source into two complementary agent flows: a **hosted website flow** for HTTP-based agents and an **npm bundle flow** for coding agents working offline inside `node_modules`. Both flows share the same underlying MDX pages and group tree, but they emit different artifacts and have different starting files.

---

## 1. Hosted Website Flow

### How it is triggered
Run `leadtype generate` (without `--bundle`).

### Entry-point files for agents
HTTP agents start at **`/llms.txt`** (the product-level site root file). From there they can follow links to:

- **`/llms-full.txt`** — a root full-context fallback that contains every generated markdown docs page in one file, organised by group. The `llms.txt` router points agents here first.
- **`/docs/llms.txt`** — a docs-scoped map (equivalent to the product-level file but rooted under `/docs/`).

### Artifacts written to the web root
| Artifact | Purpose |
|---|---|
| `/llms.txt` | Product-level agent entry point; routes to topic files |
| `/docs/llms.txt` | Docs-scoped agent map |
| `/llms-full.txt` | Full-context fallback; every markdown page in one file |
| `/docs/*.md` | Markdown mirrors of every MDX page |
| `docs/sitemap.xml` | XML sitemap for crawlers |
| `docs/sitemap.md` | Markdown sitemap |
| `docs/robots.txt` | Crawler permissions (must allow `/llms.txt`) |
| `docs/agent-readability.json` | Agent-readability metadata |
| `docs/search-index.json` | Static BM25-style search index |
| `docs/search-content.json` | Search content for answer generation |

When `--json` is used, `generate` also prints a JSON manifest whose keys are `llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, `agentReadabilityJson`, `sitemapXml`, `sitemapMd`, `robotsTxt`, `searchIndex`, and `searchContent`.

### Verification checks
- Fetch `/llms.txt` — must return the router file.
- Fetch a docs page with `Accept: text/markdown` — must return markdown.
- Check `/docs/sitemap.xml` exists.
- Confirm `/robots.txt` allows `/llms.txt`.

---

## 2. npm Bundle Flow

### How it is triggered
Run `leadtype generate --bundle`.

### Entry-point files for agents
Coding agents working inside an installed npm package start at **`AGENTS.md`** (written at the package root). From `AGENTS.md` they follow **relative links** such as `./docs/reference/cli.md` to read individual topic files — no network request or URL resolution is needed.

### Artifacts written into the tarball
| Artifact | Purpose |
|---|---|
| `AGENTS.md` | Package-root entry point; links to topic files with relative paths |
| `docs/*.md` | Markdown mirrors of every MDX page; relative links work inside `node_modules` |

> **Note:** `generateAgentsMd` intentionally ignores `product.agentGuidance` because that text is written for website URL routing, which is irrelevant in an offline bundle.

---

## 3. What Bundle Mode Skips (Website-Only Artifacts)

Bundle mode deliberately omits every artifact that only makes sense over HTTP:

| Skipped Artifact | Why it is website-only |
|---|---|
| `llms.txt` | HTTP discovery entry point; meaningless without a base URL |
| `llms-full.txt` | Full-context URL-based fallback; not needed offline |
| `search-index.json` / `search-content.json` | Runtime search over HTTP endpoints |
| `sitemap.xml` / `sitemap.md` | Crawler/indexer artifacts for hosted sites |
| `robots.txt` | HTTP crawler permissions |
| `agent-readability.json` | HTTP-level agent metadata |

The helper `isAgentReadabilityArtifactPath` in the API identifies these same six artifact categories so they are never mistakenly rewritten as missing markdown pages.

---

## 4. Side-by-side Summary

| Dimension | Hosted Website Flow | npm Bundle Flow |
|---|---|---|
| **Trigger** | `leadtype generate` | `leadtype generate --bundle` |
| **Agent entry file** | `/llms.txt` (absolute URL) | `AGENTS.md` (package root, relative) |
| **Secondary routing file** | `/llms-full.txt`, `/docs/llms.txt` | `docs/*.md` (relative links only) |
| **Link style** | Absolute URLs | Relative paths (`./docs/…`) |
| **Network required** | Yes (HTTP) | No (reads from `node_modules`) |
| **Skipped artifacts** | _(none; all artifacts produced)_ | `llms.txt`, `llms-full.txt`, search JSON, sitemaps, `robots.txt`, `agent-readability.json` |
| **Complementary use** | URL-based agents fetching live docs | Coding agents reading offline bundled docs |

The two flows complement each other: a package can ship bundled offline docs inside the npm tarball **and** maintain a hosted docs website with `llms.txt` for URL-based agents, using the same MDX source for both.

---

### Sources
- `/llms.txt` — site entry point and router
- `/llms-full.txt` — full context router listing all topic files
- `/docs/llms-full/build.txt` → `/docs/build/connect-docs-site.md`
- `/docs/llms-full/package-docs.txt` → `/docs/package-docs/bundle.md`
- `/docs/llms-full/get-started.txt` → `/docs/quickstart.md`, `/docs/how-it-works.md`
- `/docs/llms-full/reference.txt` → `/docs/reference/cli.md`, `/docs/reference/llm.md`
