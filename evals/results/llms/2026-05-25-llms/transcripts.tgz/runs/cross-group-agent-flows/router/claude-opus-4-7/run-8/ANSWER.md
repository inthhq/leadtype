# Cross-group agent flows: hosted website vs. npm package bundle

Leadtype emits docs from a single MDX source into two distinct delivery modes for agents. The hosted website flow exposes HTTP-discoverable artifacts; the npm bundle flow ships offline, relatively-linked markdown inside a published package. The docs explicitly describe both flows as complementary — a project can do both at once.

Sources consulted (from `/llms.txt` → `/llms-full.txt`):

- `/docs/llms-full/get-started.txt` (quickstart + how-it-works)
- `/docs/llms-full/build.txt` (connect-docs-site)
- `/docs/llms-full/package-docs.txt` (bundle)

## 1. Hosted website flow (website mode)

**Entry point for agents:** `/llms.txt` at the site root.

From `docs/how-it-works.md`: *"HTTP agents start at /llms.txt and follow markdown links."*

From `docs/build/connect-docs-site.md`: *"Use website mode when a docs site should expose HTTP-discoverable agent files. The build should generate /llms.txt at the site root and markdown mirrors under /docs/*.md."*

**Artifacts emitted in website mode** (per `docs/quickstart.md` and `docs/build/connect-docs-site.md`):

- `/llms.txt` (root router)
- `/docs/llms.txt`
- `/llms-full.txt` (full-context router)
- Markdown mirrors at `/docs/*.md`
- `docs/sitemap.xml` and `docs/sitemap.md`
- `docs/robots.txt`
- `docs/agent-readability.json`
- `docs/search-index.json`
- `docs/search-content.json`

**Serving behavior:** The site should return markdown when `Accept: text/markdown` is requested, or when a known AI user agent fetches a docs page. Verification suggestions in the docs include fetching `/llms.txt`, fetching a docs page with `Accept: text/markdown`, checking `/docs/sitemap.xml`, and confirming `/robots.txt` allows `/llms.txt`.

## 2. npm package bundle flow (bundle mode)

**Entry point for agents:** `AGENTS.md` at the package root inside `node_modules/<pkg>/`.

From `docs/how-it-works.md`: *"Coding agents working inside installed npm packages start at AGENTS.md and follow relative docs/*.md links."*

From `docs/package-docs/bundle.md`: *"Use `leadtype generate --bundle` when publishing an npm package. Bundle mode writes AGENTS.md at the package root and docs/*.md beneath it."*

**Artifacts emitted in bundle mode:**

- `AGENTS.md` at the package root
- `docs/*.md` beneath it

Links inside `AGENTS.md` are relative (e.g. `./docs/reference/cli.md`) so a coding agent can read them from `node_modules` without any network request.

## 3. Website artifacts that bundle mode skips

`docs/package-docs/bundle.md` lists the website-only artifacts that are intentionally omitted when `--bundle` is used:

- `llms.txt`
- `llms-full.txt`
- search JSON (i.e. `search-index.json` and `search-content.json`)
- sitemap files (`sitemap.xml`, `sitemap.md`)
- `robots.txt`
- `agent-readability.json`

These are all HTTP-discovery / crawler-oriented artifacts. They have no use inside `node_modules`, where the agent already has a filesystem and starts from `AGENTS.md` rather than a URL router.

## Side-by-side summary

| Aspect | Hosted website flow | npm bundle flow |
|---|---|---|
| CLI invocation | `leadtype generate` (website mode) | `leadtype generate --bundle` |
| Agent entry point | `/llms.txt` (HTTP) | `AGENTS.md` (filesystem, in `node_modules`) |
| Link style | Absolute site paths (e.g. `/docs/...md`) | Relative (e.g. `./docs/reference/cli.md`) |
| Markdown mirrors | `/docs/*.md` served over HTTP | `docs/*.md` inside the tarball |
| Routers | `llms.txt`, `llms-full.txt` | none (replaced by `AGENTS.md`) |
| Sitemaps | `docs/sitemap.xml`, `docs/sitemap.md` | skipped |
| Crawler hints | `docs/robots.txt`, `docs/agent-readability.json` | skipped |
| Search | `docs/search-index.json`, `docs/search-content.json` | skipped |
| Network required at read time | Yes (agent fetches URLs) | No (offline read from `node_modules`) |

## Why the two flows coexist

Per `docs/how-it-works.md`, the flows are complementary: *"A package can publish bundled offline docs for node_modules and a hosted docs website with llms.txt for URL-based agents."* The same MDX source feeds both — the website flow optimizes for URL-based discovery and search, while the bundle flow optimizes for version-matched, offline reading by coding agents that already have the package installed.
