# Cross-group Agent Flows: Hosted Website vs npm Bundle

## Overview

Leadtype supports two complementary agent flows from the same MDX source. Each flow targets a different kind of agent and produces a different set of artifacts.

---

## 1. Hosted Website Flow

### Entry Point
HTTP agents start at **`/llms.txt`** at the site root. From there they follow the link to **`/llms-full.txt`**, which routes to topic-specific deep-context files. Agents then follow markdown links through the docs pages.

### How It Works
- The build generates `/llms.txt` and `/llms-full.txt` at the site root.
- Markdown mirrors of every docs page are published under `/docs/*.md`.
- When an agent (or browser client) requests a docs page with `Accept: text/markdown` or a known AI user-agent header, the server returns the markdown version.

### Artifacts Produced
| Artifact | Path |
|---|---|
| Top-level router | `/llms.txt` |
| Full context router | `/llms-full.txt` |
| Per-docs router | `/docs/llms.txt` |
| Markdown page mirrors | `/docs/*.md` |
| Sitemap (XML) | `/docs/sitemap.xml` |
| Sitemap (Markdown) | `/docs/sitemap.md` |
| Robots file | `/docs/robots.txt` |
| Agent readability manifest | `/docs/agent-readability.json` |
| Search index | `/docs/search-index.json` |
| Search content | `/docs/search-content.json` |

### Verification Checks
- Fetch `/llms.txt` and confirm it is reachable.
- Fetch a docs page with `Accept: text/markdown` and confirm markdown is returned.
- Check `/docs/sitemap.xml` exists.
- Confirm `/robots.txt` allows `/llms.txt`.

---

## 2. npm Bundle (Package) Flow

### Entry Point
Coding agents working inside an installed npm package start at **`AGENTS.md`** at the **package root** (i.e., inside `node_modules/<package>/AGENTS.md`). They then follow **relative links** like `./docs/reference/cli.md` to reach individual docs pages — no network request is needed.

### How It Works
- Triggered by running `leadtype generate --bundle` at publish time.
- Writes `AGENTS.md` at the package root and `docs/*.md` beneath it.
- All links in `AGENTS.md` are relative so they resolve correctly inside `node_modules` without HTTP.

### Artifacts Produced
| Artifact | Path (relative to package root) |
|---|---|
| Agent entry point | `AGENTS.md` |
| Docs pages | `docs/*.md` |

---

## What Bundle Mode Skips

Bundle mode deliberately omits all website-only artifacts because they are meaningless for an offline, filesystem-based agent:

| Skipped Artifact | Reason |
|---|---|
| `llms.txt` | HTTP discovery file; not needed in node_modules |
| `llms-full.txt` | HTTP router; not needed in node_modules |
| Search JSON (`search-index.json`, `search-content.json`) | Website search infrastructure |
| Sitemap files (`sitemap.xml`, `sitemap.md`) | Website crawling; irrelevant offline |
| `robots.txt` | HTTP crawler directive; irrelevant offline |
| `agent-readability.json` | Website agent-readability manifest |

---

## Summary Comparison

| Dimension | Hosted Website Flow | npm Bundle Flow |
|---|---|---|
| **Agent type** | HTTP / URL-based agents | Coding agents (e.g., in an IDE or CI) |
| **Entry file** | `/llms.txt` (site root) | `AGENTS.md` (package root) |
| **Link style** | Absolute URLs | Relative paths (`./docs/…`) |
| **Network required** | Yes | No (works offline inside node_modules) |
| **Trigger** | Normal `leadtype generate` | `leadtype generate --bundle` |
| **Extra artifacts** | llms.txt, llms-full.txt, sitemaps, robots.txt, search JSON, agent-readability.json | None — only AGENTS.md + docs/*.md |

The two flows are designed to complement each other: a package can ship bundled offline docs for node_modules agents **and** maintain a hosted docs site with `llms.txt` for URL-based agents, both generated from the same MDX source.
