# Cross-group Agent Flows: Hosted Website vs npm Bundle

## Overview

Leadtype produces two distinct agent flows from the same MDX source. Both flows use the same underlying pages and group structure, but they differ in their entry-point files, link style, and which artifacts are emitted.

---

## 1. Hosted Website Flow

### How it starts
HTTP agents (URL-based agents) begin at **`/llms.txt`** at the site root. From there they can follow markdown links to:
- **`/llms-full.txt`** — the root full-context fallback containing every generated markdown docs page.
- **`/docs/llms.txt`** — the docs-scoped map.
- Individual **`/docs/*.md`** markdown mirrors of each page.

### Entry-point file
`/llms.txt` (at the web root)

### All generated artifacts (website mode)
| Artifact | Path |
|---|---|
| Product-level agent entry | `/llms.txt` |
| Docs-scoped map | `/docs/llms.txt` |
| Full context fallback | `/llms-full.txt` |
| Markdown mirrors | `/docs/*.md` |
| Sitemap (XML) | `/docs/sitemap.xml` |
| Sitemap (Markdown) | `/docs/sitemap.md` |
| Robots | `/docs/robots.txt` |
| Agent readability | `/docs/agent-readability.json` |
| Search index | `/docs/search-index.json` |
| Search content | `/docs/search-content.json` |

### Key characteristics
- The build generates `/llms.txt` at the site root so agents can discover it via HTTP.
- Pages with `Accept: text/markdown` headers (or known AI user agents) are served markdown directly.
- Groups organize the `llms.txt` sections, navigation, and search metadata.
- `generateLlmsTxt` and `generateLLMFullContextFiles` drive the website artifacts.

---

## 2. npm Bundle Flow

### How it starts
Coding agents working **inside an installed npm package** (i.e. inside `node_modules`) begin at **`AGENTS.md`** at the package root. From there they follow relative links to:
- **`./docs/*.md`** — markdown docs bundled alongside the package.

### Entry-point file
`AGENTS.md` (at the package root, relative to the installed package)

### Generated artifacts (bundle mode — `leadtype generate --bundle`)
| Artifact | Path |
|---|---|
| Agent entry | `AGENTS.md` |
| Markdown docs | `docs/*.md` |

All links in `AGENTS.md` use **relative paths** (e.g. `./docs/reference/cli.md`) so they resolve correctly inside `node_modules` without any network request.

### Key characteristics
- Triggered with the `--bundle` flag: `leadtype generate --bundle`.
- `generateAgentsMd` writes `AGENTS.md`. It intentionally ignores `product.agentGuidance` because that text is written for website URL routing, not relative-path navigation.
- Groups still organize the `AGENTS.md` groupings, but are not published as per-group full-context files.

---

## What Bundle Mode Skips

Bundle mode deliberately omits all **website-only artifacts** because they are HTTP-specific and meaningless inside a file-system-local `node_modules` path:

| Skipped Artifact | Why it's skipped |
|---|---|
| `llms.txt` | HTTP discovery entry point — not useful offline |
| `llms-full.txt` | URL-based full-context fallback — not useful offline |
| `search-index.json` | Runtime search index — no server to query |
| `search-content.json` | Search content source — no server to query |
| `sitemap.xml` | Site crawl map — HTTP/web-crawler artifact |
| `sitemap.md` | Markdown sitemap — website navigation artifact |
| `robots.txt` | Crawler directives — HTTP server artifact |
| `agent-readability.json` | Website agent-readability signal — HTTP artifact |

These are all the paths identified by `isAgentReadabilityArtifactPath` as artifacts that should not be rewritten as missing markdown pages in the website flow, and are all absent in bundle mode.

---

## Side-by-side Comparison

| Dimension | Hosted Website | npm Bundle |
|---|---|---|
| **Agent entry file** | `/llms.txt` (web root) | `AGENTS.md` (package root) |
| **Link style** | Absolute URLs | Relative paths (`./docs/…`) |
| **Network required?** | Yes (HTTP) | No (filesystem only) |
| **CLI invocation** | `leadtype generate` | `leadtype generate --bundle` |
| **Full-context file** | `/llms-full.txt` (all pages) | — (not generated) |
| **Search artifacts** | ✅ generated | ❌ skipped |
| **Sitemap / robots** | ✅ generated | ❌ skipped |
| **agent-readability.json** | ✅ generated | ❌ skipped |
| **Markdown docs** | `/docs/*.md` (served via HTTP) | `docs/*.md` (inside tarball) |

---

## How They Complement Each Other

The two flows are not mutually exclusive. A package can publish **both**:
1. A hosted docs website with `/llms.txt` for URL-based (HTTP) agents.
2. A bundled `AGENTS.md` + `docs/*.md` inside the npm tarball for coding agents working offline inside `node_modules`.

The single MDX source is the shared input; Leadtype determines which artifacts to emit based on whether `--bundle` is passed.
