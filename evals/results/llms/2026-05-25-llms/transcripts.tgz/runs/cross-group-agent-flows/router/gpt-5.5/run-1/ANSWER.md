# Hosted vs npm bundle agent flows

Leadtype supports two complementary agent documentation flows from the same MDX source.

## Hosted website flow

Use website mode for URL-based/HTTP agents.

- Agents start at the site-root file: `/llms.txt`.
- From there, they follow markdown links such as `/llms-full.txt` and topic/page markdown mirrors under `/docs/*.md`.
- For docs page requests, the hosted site should serve markdown when the request `Accept` header asks for `text/markdown` or when a known AI user agent requests a docs page.
- Website mode emits static website artifacts including:
  - `/llms.txt`
  - `/llms-full.txt`
  - `/docs/*.md` markdown mirrors
  - sitemap files, such as `/docs/sitemap.xml` and `/docs/sitemap.md`
  - `robots.txt`
  - `agent-readability.json`
  - search JSON, such as `search-index.json` and `search-content.json`

## npm package bundle flow

Use bundle mode when publishing docs inside an npm package, especially for coding agents reading installed packages from `node_modules` without network access.

- Run `leadtype generate --bundle`.
- Agents start at `AGENTS.md` at the package root.
- `AGENTS.md` links to bundled markdown using relative paths, for example `./docs/reference/cli.md`.
- Bundle mode writes `AGENTS.md` and `docs/*.md` beneath the package root.

## Cross-group behavior

Groups are preserved for agent navigation in both flows: the frontmatter `group` value drives the `llms.txt` section on the hosted site and `AGENTS.md` grouping in package bundles. Pages may also belong to multiple groups with `group: [a, b]`.

## Website artifacts skipped by bundle mode

Bundle mode intentionally skips website-only artifacts:

- `llms.txt`
- `llms-full.txt`
- search JSON
- sitemap files
- `robots.txt`
- `agent-readability.json`
