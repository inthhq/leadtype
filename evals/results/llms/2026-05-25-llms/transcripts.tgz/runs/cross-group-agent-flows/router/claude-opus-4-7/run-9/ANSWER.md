# Cross-group agent flows: hosted vs npm bundle

Leadtype emits two complementary agent flows from a single MDX source. The hosted website flow targets HTTP agents that can fetch URLs, while the npm bundle flow targets coding agents that read files from inside an installed `node_modules` package without network access.

Sources used: `llms.txt`, `llms-full.txt`, `docs/llms-full/get-started.txt`, `docs/llms-full/build.txt`, and `docs/llms-full/package-docs.txt`.

## Entry files for each flow

### Hosted website flow
- **Starts from:** `/llms.txt` at the site root.
- HTTP agents read `/llms.txt`, follow the link to `/llms-full.txt` (the full-context router), and from there drill into topic deep-context files such as `/docs/llms-full/build.txt`.
- Individual pages are served as markdown mirrors under `/docs/*.md`. The site should return markdown when the request `Accept`s `text/markdown` or when a known AI user agent asks for a docs page.

### npm package bundle flow
- **Starts from:** `AGENTS.md` at the package root (produced by `leadtype generate --bundle`).
- `AGENTS.md` uses **relative** links such as `./docs/reference/cli.md`, so a coding agent can open docs straight out of `node_modules` with no HTTP request.
- All bundled pages live under `docs/*.md` next to `AGENTS.md`.

## Artifacts each flow produces

### Website mode (`leadtype generate`) writes:
- `/llms.txt` and `/docs/llms.txt`
- `/llms-full.txt`
- Markdown mirrors under `/docs/*.md`
- `docs/sitemap.xml` and `docs/sitemap.md`
- `docs/robots.txt`
- `docs/agent-readability.json`
- `docs/search-index.json` and `docs/search-content.json`

### Bundle mode (`leadtype generate --bundle`) writes:
- `AGENTS.md` at the package root
- `docs/*.md` beneath it, with relative links

## Website artifacts that bundle mode skips

Per `docs/package-docs/bundle.md`, bundle mode deliberately omits every website-only artifact, because they only make sense over HTTP:

- `llms.txt`
- `llms-full.txt`
- Search JSON (`search-index.json`, `search-content.json`)
- Sitemap files (`sitemap.xml`, `sitemap.md`)
- `robots.txt`
- `agent-readability.json`

## Why the split exists

The two flows are designed to coexist: a project can ship a hosted docs site whose `/llms.txt` guides URL-based agents, **and** publish an npm package whose `AGENTS.md` plus bundled `docs/*.md` serves offline coding agents working inside `node_modules`. The website routers (`llms.txt`, `llms-full.txt`), discoverability metadata (`sitemap.*`, `robots.txt`, `agent-readability.json`), and search indexes (`search-*.json`) are exactly the pieces that have no purpose in a local tarball, so bundle mode drops them and replaces the entry point with `AGENTS.md` using relative links.
