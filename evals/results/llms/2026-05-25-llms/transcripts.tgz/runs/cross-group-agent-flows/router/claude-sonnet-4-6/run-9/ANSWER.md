# Cross-group Agent Flows: Hosted Website vs npm Bundle

Leadtype serves agents through two complementary flows. Both start from the same MDX source files, but they diverge completely in what they emit and where agents begin reading.

---

## 1. Hosted Website Flow

### Entry point for agents
HTTP agents start at **`/llms.txt`** (at the site root). From there they follow links to topic-specific deep-context files (e.g. `/llms-full.txt`, per-group `.txt` files) and then on to individual markdown mirrors at `/docs/*.md`.

### How it is triggered
Running `leadtype generate` **without** `--bundle` activates website mode.

### Artifacts generated
| Artifact | Path |
|---|---|
| Top-level router | `/llms.txt` |
| Per-docs router | `/docs/llms.txt` |
| Full-context router | `/llms-full.txt` |
| Markdown mirrors | `/docs/*.md` |
| XML sitemap | `docs/sitemap.xml` |
| Markdown sitemap | `docs/sitemap.md` |
| Robots file | `docs/robots.txt` |
| Agent-readability metadata | `docs/agent-readability.json` |
| Search index | `docs/search-index.json` |
| Search content | `docs/search-content.json` |

### Verification checks
- Fetch `/llms.txt` — must be present and valid.
- Fetch a docs page with `Accept: text/markdown` — must return markdown.
- Check `/docs/sitemap.xml` is accessible.
- Confirm `/robots.txt` allows `/llms.txt`.

---

## 2. npm Bundle (Package) Flow

### Entry point for agents
Coding agents working inside an installed npm package start at **`AGENTS.md`** at the package root. From there they follow **relative** links such as `./docs/reference/cli.md` that resolve inside `node_modules` — no network request required.

### How it is triggered
Running `leadtype generate --bundle` activates bundle mode.

### Artifacts generated
| Artifact | Path |
|---|---|
| Agent entry file | `AGENTS.md` (package root) |
| Markdown docs | `docs/*.md` (relative, beneath the package root) |

All links inside `AGENTS.md` are relative so they work regardless of where the package is installed inside `node_modules`.

---

## 3. What Bundle Mode Skips

Bundle mode omits every artifact that is only meaningful in the context of a hosted, HTTP-accessible website:

| Skipped artifact | Why it is website-only |
|---|---|
| `llms.txt` | HTTP discovery entry point; meaningless on disk inside `node_modules` |
| `llms-full.txt` | Full-context router for URL-based agents |
| Search JSON (`search-index.json`, `search-content.json`) | Powers the website search UI and remote search APIs |
| Sitemap files (`sitemap.xml`, `sitemap.md`) | Used by crawlers and HTTP-based agents |
| `robots.txt` | HTTP crawler directive; irrelevant for offline use |
| `agent-readability.json` | Metadata consumed by hosted agent-readability checks |

---

## 4. Side-by-Side Summary

| Dimension | Hosted Website Flow | npm Bundle Flow |
|---|---|---|
| **Agent entry file** | `/llms.txt` (absolute URL) | `AGENTS.md` (relative, package root) |
| **Link style** | Absolute HTTP URLs | Relative filesystem paths |
| **Network required?** | Yes | No — works fully offline inside `node_modules` |
| **CLI flag** | `leadtype generate` | `leadtype generate --bundle` |
| **Skips** | — | `llms.txt`, `llms-full.txt`, search JSON, sitemaps, `robots.txt`, `agent-readability.json` |

The two flows are designed to complement each other: a package can publish bundled offline docs for agents inside `node_modules` **and** maintain a hosted docs website with `llms.txt` for URL-based agents — both generated from the same MDX source.
