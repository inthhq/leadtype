# Cross-group agent flows: hosted website vs npm bundle

## Hosted website flow

Use website mode when the docs are meant to be discovered over HTTP.

An agent starts at the site-root file:

1. `/llms.txt` — the product-level entry point. In this site it points the agent to `/llms-full.txt`.
2. `/llms-full.txt` — the full-context router, which routes the agent to the smallest relevant topic file, such as `/docs/llms-full/build.txt` or `/docs/llms-full/package-docs.txt`.
3. Markdown docs pages under `/docs/*.md` — the website build exposes markdown mirrors of docs pages. For docs-page requests, the site should serve markdown when `Accept: text/markdown` is sent or when a known AI user agent requests a docs page.

Website mode also keeps static agent and site artifacts available at the hosted root/site paths, including `/llms.txt`, `/llms-full.txt`, sitemap files, `robots.txt`, search JSON, and `agent-readability.json`.

## npm package bundle flow

Use bundle mode when publishing docs inside an npm package for coding agents working offline or inside `node_modules`.

An agent starts at the package-root file:

1. `AGENTS.md` — written at the npm package root by `leadtype generate --bundle`.
2. `docs/*.md` — version-matched markdown docs shipped beneath the package root.

`AGENTS.md` uses relative links such as `./docs/reference/cli.md`, so agents can navigate the bundled documentation from inside `node_modules` without making network requests.

## What bundle mode skips

Bundle mode intentionally skips website-only artifacts:

- `llms.txt`
- `llms-full.txt`
- search JSON
- sitemap files
- `robots.txt`
- `agent-readability.json`

In short: the hosted flow begins with URL-discoverable `/llms.txt` and routes through hosted markdown and web artifacts; the npm bundle flow begins with package-local `AGENTS.md` and follows relative links to bundled `docs/*.md`, omitting the hosted-site artifacts that only make sense on a website.