# Cross-group agent flows: hosted website vs npm bundle

Leadtype supports two complementary agent flows from the same MDX source.

## Hosted website flow

- **Starts from:** `/llms.txt` at the hosted site root.
- Agents then follow markdown links from that entry point. In the docs site represented here, `/llms.txt` points to `/llms-full.txt`, which acts as the full-context router and links to topic-specific files such as `/docs/llms-full/build.txt` and `/docs/llms-full/package-docs.txt`.
- Website mode also exposes markdown mirrors under `/docs/*.md`. For docs pages, the site should serve markdown when `Accept: text/markdown` is sent or when a known AI user agent requests the page.
- Group metadata is used for routing and organization: it affects `llms.txt` sections, navigation, search metadata, and AGENTS.md grouping. Groups are not separate full-context shards by default; the root `/llms-full.txt` fallback contains all generated markdown pages.

Website mode writes artifacts such as:

- `/llms.txt`
- `/docs/llms.txt`
- `/llms-full.txt`
- markdown mirrors under `/docs/*.md`
- sitemap files, for example `/docs/sitemap.xml` and `/docs/sitemap.md`
- `robots.txt`
- `agent-readability.json`
- search JSON, including `search-index.json` and `search-content.json`

## npm package bundle flow

- **Starts from:** `AGENTS.md` at the package root inside the npm tarball / installed package.
- Coding agents working in `node_modules` follow **relative links** from `AGENTS.md`, for example `./docs/reference/cli.md`.
- Bundle mode is produced with `leadtype generate --bundle` and writes `AGENTS.md` plus `docs/*.md` into the package so agents can read version-matched docs without a network request.

## Website artifacts skipped by bundle mode

Bundle mode skips website-only artifacts. The docs explicitly list these skipped artifacts:

- `llms.txt`
- `llms-full.txt`
- search JSON
- sitemap files
- `robots.txt`
- `agent-readability.json`

In short: hosted URL-based agents begin at `/llms.txt`, while offline coding agents inside an npm package begin at `AGENTS.md`. The hosted flow publishes discovery, search, sitemap, robots, and readability files for a website; the bundle flow omits those and keeps only the package-root agent guide plus relative markdown docs.