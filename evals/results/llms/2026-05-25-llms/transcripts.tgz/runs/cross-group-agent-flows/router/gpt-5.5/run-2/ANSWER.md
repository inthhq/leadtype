# Hosted website flow vs npm bundle flow for agents

Leadtype supports two complementary agent flows from the same MDX source.

## Hosted website flow

Use **website mode** when agents will read docs over HTTP from a hosted site.

- Agents start at **`/llms.txt`**.
- `/llms.txt` links agents to the appropriate markdown docs and to the full-context fallback.
- Hosted output includes markdown mirrors such as **`/docs/*.md`**.
- Leadtype also writes hosted discovery and support artifacts, including:
  - **`/docs/llms.txt`**
  - **`/llms-full.txt`**
  - sitemap files such as **`docs/sitemap.xml`** and **`docs/sitemap.md`**
  - **`docs/robots.txt`**
  - **`docs/agent-readability.json`**
  - **`docs/search-index.json`**
  - **`docs/search-content.json`**

HTTP agents should fetch `/llms.txt`, then follow markdown links. For docs pages, the site should serve markdown when the request asks for `text/markdown` or comes from a known AI user agent.

## npm package bundle flow

Use **bundle mode** with **`leadtype generate --bundle`** when publishing docs inside an npm package tarball.

- Coding agents working inside an installed package start at **`AGENTS.md`** at the package root.
- `AGENTS.md` uses relative links such as **`./docs/reference/cli.md`**.
- The bundled docs live under **`docs/*.md`** inside the package.
- This lets agents read version-matched docs from `node_modules` without making network requests.

## What bundle mode skips

Bundle mode does **not** emit website-only artifacts. It skips:

- **`llms.txt`**
- **`llms-full.txt`**
- search JSON files
- sitemap files
- **`robots.txt`**
- **`agent-readability.json`**

In short: hosted agents start from `/llms.txt` and follow URL-based markdown links, while npm-package agents start from `AGENTS.md` and follow relative `docs/*.md` links inside the installed package.