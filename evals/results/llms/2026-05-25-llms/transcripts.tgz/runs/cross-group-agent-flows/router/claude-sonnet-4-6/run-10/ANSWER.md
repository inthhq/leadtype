# Cross-group Agent Flows: Hosted Website vs npm Bundle

## Overview

Leadtype's pipeline takes a single MDX source and emits two distinct agent-readable flows: one for HTTP-based agents browsing a **hosted docs website**, and one for coding agents working inside an **installed npm package**. The two flows are designed to complement each other — a project can publish both simultaneously.

---

## 1. Hosted Website Flow

### Entry Point

HTTP agents start at **`/llms.txt`** (at the site root).

- From `/llms.txt`, agents are directed to **`/llms-full.txt`**, a full-context router that lists topic-specific deep-context files.
- From `/llms-full.txt`, agents follow links to topic `.txt` files (e.g. `/docs/llms-full/build.txt`), which in turn link to individual markdown page mirrors under `/docs/*.md`.

### How it is triggered

Website mode is the default output of `leadtype generate` (without `--bundle`).

### Artifacts generated

| Artifact | Purpose |
|---|---|
| `/llms.txt` | Root entry point for HTTP agents |
| `/docs/llms.txt` | Docs-scoped map for hosted websites |
| `/llms-full.txt` | Root full-context fallback containing every generated markdown docs page |
| `/docs/*.md` | Markdown mirrors of every MDX page |
| `docs/sitemap.xml` | XML sitemap |
| `docs/sitemap.md` | Markdown sitemap |
| `docs/robots.txt` | Robots directives (must allow `/llms.txt`) |
| `docs/agent-readability.json` | Agent-readability metadata |
| `docs/search-index.json` | Static search index |
| `docs/search-content.json` | Search content source |

When `--json` is enabled, `leadtype generate` prints a JSON object with keys: `llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, `agentReadabilityJson`, `sitemapXml`, `sitemapMd`, `robotsTxt`, `searchIndex`, and `searchContent`.

### Agent navigation model

Agents fetch pages over HTTP. They can also be served markdown directly when sending `Accept: text/markdown` or when a known AI user-agent requests a docs page.

---

## 2. npm Bundle Flow

### Entry Point

Coding agents working inside installed npm packages start at **`AGENTS.md`** (at the package root, i.e. inside `node_modules/<package>/AGENTS.md`).

- `AGENTS.md` uses **relative links** (e.g. `./docs/reference/cli.md`) so agents can navigate the full docs tree without any network request.
- All linked content lives under `docs/*.md` alongside `AGENTS.md` in the tarball.

### How it is triggered

Bundle mode is activated with **`leadtype generate --bundle`** when publishing an npm package.

### Artifacts generated

| Artifact | Purpose |
|---|---|
| `AGENTS.md` | Root entry point for coding agents; uses relative links |
| `docs/*.md` | Markdown docs pages, navigable via relative links |

> **Note:** `generateAgentsMd` intentionally ignores `product.agentGuidance` because that text is written for website URL routing, which does not apply in the offline bundle context.

### Agent navigation model

Agents read files directly from the filesystem inside `node_modules` — no HTTP, no network request required.

---

## 3. What Bundle Mode Skips

Bundle mode deliberately omits all **website-only artifacts** that are meaningless or unreachable without a hosted HTTP server:

| Skipped Artifact | Reason skipped |
|---|---|
| `llms.txt` | HTTP entry-point file; irrelevant without a web server |
| `llms-full.txt` | Full-context router for URL-based agents |
| Search JSON (`search-index.json`, `search-content.json`) | Requires a runtime query path; not useful offline in node_modules |
| Sitemap files (`sitemap.xml`, `sitemap.md`) | Web-crawl artifacts; no URLs to index |
| `robots.txt` | HTTP crawler directive; not applicable offline |
| `agent-readability.json` | Website metadata artifact |

These paths are identified internally by `isAgentReadabilityArtifactPath`, which prevents them from being rewritten as missing markdown pages in website mode, and they are simply never written in bundle mode.

---

## 4. Side-by-side Summary

| Dimension | Hosted Website Flow | npm Bundle Flow |
|---|---|---|
| **Entry file** | `/llms.txt` (HTTP URL) | `AGENTS.md` (filesystem path) |
| **Navigation** | HTTP links through `/llms-full.txt` → `/docs/*.md` | Relative links `./docs/*.md` inside `node_modules` |
| **Triggered by** | `leadtype generate` (default) | `leadtype generate --bundle` |
| **Network required** | Yes — agents fetch over HTTP | No — fully offline |
| **Search index** | ✅ Included | ❌ Skipped |
| **Sitemaps** | ✅ Included | ❌ Skipped |
| **robots.txt** | ✅ Included | ❌ Skipped |
| **agent-readability.json** | ✅ Included | ❌ Skipped |
| **llms.txt / llms-full.txt** | ✅ Included | ❌ Skipped |
| **docs/\*.md mirrors** | ✅ Included | ✅ Included |

---

## Sources

- `/docs/how-it-works.md`
- `/docs/build/connect-docs-site.md`
- `/docs/package-docs/bundle.md`
- `/docs/quickstart.md`
- `/docs/reference/llm.md`
- `/docs/reference/cli.md`
