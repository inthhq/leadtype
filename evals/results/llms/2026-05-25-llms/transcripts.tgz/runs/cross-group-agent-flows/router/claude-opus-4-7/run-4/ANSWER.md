# Cross-group agent flows: hosted website vs npm bundle

Leadtype's docs pipeline turns one MDX source into two distinct agent-facing flows. The hosted **website flow** (Build group) exposes docs over HTTP so remote agents can discover and fetch them; the **npm bundle flow** (Ship Package Docs group) ships the same docs inside a tarball so coding agents can read them locally from `node_modules` with no network access.

## Where each flow starts

### Hosted website flow
- **Entry file:** `/llms.txt` at the site root. This is the discovery file an agent loads first.
- **Router:** `/llms.txt` links to `/llms-full.txt` (the full-context router), which routes to topic-specific deep-context files such as `/docs/llms-full/build.txt`.
- **Per-topic map:** `/docs/llms.txt` provides a docs-scoped map for website agents (written by `generateLlmsTxt`).
- **Page bodies:** Individual pages like `/docs/build/connect-docs-site.md` are served as markdown when the request's `Accept` header asks for `text/markdown` or when a known AI user agent fetches a docs page.
- Authoritative source: `docs/build/connect-docs-site.md` (linked from `docs/llms-full/build.txt`).

### npm bundle flow
- **Entry file:** `AGENTS.md` at the package root, written by `generateAgentsMd` when the build runs `leadtype generate --bundle`.
- **Page bodies:** Markdown files under `./docs/*.md` inside the published tarball. `AGENTS.md` uses relative links like `./docs/reference/cli.md` so an agent can resolve them inside `node_modules` without any HTTP request.
- Authoritative source: `docs/package-docs/bundle.md` (linked from `docs/llms-full/package-docs.txt`).

So the website flow boots agents from `/llms.txt`, while the bundle flow boots them from `AGENTS.md`. Notably, `generateAgentsMd` intentionally ignores `product.agentGuidance` because that text is written for website URL routing and would be wrong inside an offline package.

## Website artifacts that bundle mode skips

Per `docs/package-docs/bundle.md`, bundle mode is deliberately narrow: it writes only `AGENTS.md` and `docs/*.md`. It skips every website-only artifact:

| Artifact | Purpose in website mode | Why bundle mode omits it |
| --- | --- | --- |
| `llms.txt` | Root discovery file for HTTP agents | Bundle uses `AGENTS.md` as the entry point instead |
| `llms-full.txt` | Root full-context router across topics | No HTTP routing needed inside a tarball |
| Search JSON (`searchIndex`, `searchContent`) | Powers the static BM25 search index | No edge runtime / search UI in a package |
| Sitemap files (`sitemap.xml`, `sitemap.md`) | Crawler and agent discovery on the web | No crawling against a local `node_modules` tree |
| `robots.txt` | Tells crawlers `/llms.txt` is allowed | Irrelevant offline |
| `agent-readability.json` | Declares which paths are agent-readable artifacts | Irrelevant offline |

These are the same paths that `isAgentReadabilityArtifactPath` recognizes (llms.txt, llms-full.txt, sitemap files, robots.txt, search JSON, and agent-readability.json), and the same set the CLI's website-mode `--json` output enumerates (`llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, `agentReadabilityJson`, `sitemapXml`, `sitemapMd`, `robotsTxt`, `searchIndex`, `searchContent`).

## Summary

- **Hosted flow:** starts at `/llms.txt` → `/llms-full.txt` → topic context files → `/docs/**/*.md`, backed by sitemaps, robots, search JSON, and `agent-readability.json`.
- **Bundle flow:** starts at `AGENTS.md` → `./docs/**/*.md` via relative links, with every website-only artifact (llms.txt, llms-full.txt, search JSON, sitemap files, robots.txt, agent-readability.json) deliberately skipped.

Same MDX source, two delivery shapes: HTTP-discoverable for web agents, file-relative for agents reading inside an installed npm package.
