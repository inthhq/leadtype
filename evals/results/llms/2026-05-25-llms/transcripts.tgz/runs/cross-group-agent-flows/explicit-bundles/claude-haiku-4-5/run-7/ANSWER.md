# Cross-group Agent Flows: Hosted vs npm Bundle

## Hosted Website Flow

**Starting Point:** `/llms.txt`

The hosted website flow exposes agent-readable files through HTTP discovery. The build generates a set of static artifacts at the site root and under the docs directory:

- **Primary entry point:** `/llms.txt` (site root)
- **Secondary entry point:** `/llms-full.txt` 
- **Content mirrors:** Markdown files under `/docs/*.md`
- **Supporting artifacts:**
  - Sitemap files (for discoverability)
  - `robots.txt` (configured to allow `/llms.txt`)
  - Search JSON (for agent search capabilities)
  - `agent-readability.json` (metadata about agent readability)

**Agent Access Pattern:** Agents make HTTP requests with appropriate Accept headers (`text/markdown` or known AI user agent headers) to fetch markdown content from the hosted site.

**Verification:** Agents can verify the setup by:
1. Fetching `/llms.txt`
2. Fetching a docs page with `Accept: text/markdown`
3. Checking `/docs/sitemap.xml`
4. Confirming `/robots.txt` allows `/llms.txt`

## npm Bundle Flow

**Starting Point:** `AGENTS.md` (at package root)

The npm bundle flow packages documentation for offline consumption inside npm tarballs. It uses the `leadtype generate --bundle` command.

- **Primary entry point:** `AGENTS.md` (at package root)
- **Content mirrors:** `docs/*.md` beneath the package root
- **Link pattern:** Relative links like `./docs/reference/cli.md` for offline access within `node_modules`

**Agent Access Pattern:** Agents read `AGENTS.md` first, then follow relative links to access markdown files without requiring network requests.

## Skipped Artifacts in Bundle Mode

Bundle mode **intentionally excludes** the following website-only artifacts:

- `llms.txt`
- `llms-full.txt`
- Search JSON
- Sitemap files
- `robots.txt`
- `agent-readability.json`

## Key Differences Summary

| Aspect | Hosted Website | npm Bundle |
|--------|---|---|
| **Entry point** | `/llms.txt` (HTTP discoverable) | `AGENTS.md` (file system based) |
| **Access method** | HTTP requests with Accept headers | Direct file system reads |
| **Network requirement** | Required | Not required |
| **Link style** | Absolute URLs or site-relative paths | Relative paths (e.g., `./docs/...`) |
| **Artifact density** | Includes SEO and discovery artifacts | Minimal, code-focused artifacts only |
| **Use case** | Production hosted docs sites | npm package docs distribution |

