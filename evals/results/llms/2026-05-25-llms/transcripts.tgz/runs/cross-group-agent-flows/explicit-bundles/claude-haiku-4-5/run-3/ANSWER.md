# Cross-Group Agent Flows: Hosted vs npm Bundle

## Hosted Website Flow

**Starting Point:** `/llms.txt` at the site root

**Key Files Generated:**
- `/llms.txt` - Product-level discovery entry point for agents
- `/docs/llms.txt` - Docs-scoped map for hosted websites
- `/llms-full.txt` - Root full-context file containing every generated markdown docs page
- `/docs/*.md` - Markdown mirrors of documentation
- Website artifacts (served as static files):
  - `/docs/sitemap.xml` and sitemap files
  - `/robots.txt`
  - Search JSON indices
  - `/agent-readability.json`

**Agent Discovery Path:**
1. Agent fetches `/llms.txt` at the site root
2. Uses `Accept: text/markdown` header or known AI user agent detection to request docs
3. Fetches documentation from `/docs/*.md` via HTTP
4. May fetch `/llms-full.txt` as a root full-context fallback
5. Can discover content via sitemap files for comprehensive indexing

## npm Bundle Flow

**Starting Point:** `AGENTS.md` at the package root

**Key Files Generated:**
- `AGENTS.md` - Entry point at package root for npm-bundled docs
- `docs/*.md` - Markdown documentation beneath the package root
- Uses relative links like `./docs/reference/cli.md` for offline navigation

**Agent Discovery Path:**
1. Agent reads `AGENTS.md` from package root in `node_modules`
2. Follows relative links to access docs without network requests
3. Operates entirely offline from the installed package

## Artifacts Skipped in Bundle Mode

Bundle mode intentionally skips website-only artifacts:
- `llms.txt` (product-level discovery, HTTP-only)
- `llms-full.txt` (website root full-context)
- `search JSON` indices
- `sitemap.xml` and sitemap files (HTTP navigation)
- `robots.txt` (HTTP crawler metadata)
- `agent-readability.json` (HTTP artifact routing)

## Key Differences

| Aspect | Hosted Website | npm Bundle |
|--------|---|---|
| **Starting File** | `/llms.txt` | `AGENTS.md` |
| **Link Style** | Absolute HTTP paths | Relative filesystem paths |
| **Network Required** | Yes (HTTP fetches) | No (offline in node_modules) |
| **Discovery Method** | HTTP headers, user agents, sitemaps | Direct filesystem navigation |
| **Full Context** | `/llms-full.txt` included | Not generated separately |
| **Search Index** | Static JSON indices included | Skipped |
| **Product Guidance** | Included in website artifacts | Ignored (not applicable to offline usage) |
| **Use Case** | Agents discovering and navigating docs via web | Coding agents reading docs from installed packages |

The hosted flow leverages HTTP discovery with rich metadata (sitemaps, search indices, readability hints), while the bundle flow prioritizes offline accessibility with relative links for local filesystem access from within `node_modules`.
