# Cross-group agent flows: hosted website vs npm package bundle

Leadtype produces two distinct agent-facing flows from the same MDX source. The hosted website flow exposes agent files over HTTP, while the npm bundle flow ships docs inside a package tarball so agents can read them locally from `node_modules` without a network request.

Sources used:

- `/llms.txt` (site entry point)
- `/docs/llms-full/build.txt` and `/docs/build/connect-docs-site.md` (website / hosted flow)
- `/docs/llms-full/package-docs.txt` and `/docs/package-docs/bundle.md` (npm bundle flow)

## Hosted website flow

**Starting file for agents:** `/llms.txt` at the site root.

From there, agents follow links to full-context bundles under `/docs/llms-full/*.txt` and to per-page markdown mirrors under `/docs/*.md`. The site is built in "website mode," which means it must:

- Generate `/llms.txt` at the site root.
- Generate markdown mirrors under `/docs/*.md`.
- Serve markdown when the request has `Accept: text/markdown`, or when a known AI user agent requests a docs page.
- Keep the following as static artifacts: `/llms.txt`, `/llms-full.txt`, sitemap files (e.g. `/docs/sitemap.xml`), `/robots.txt`, search JSON, and `agent-readability.json`.

Verification for this flow involves fetching `/llms.txt`, fetching a docs page with `Accept: text/markdown`, checking `/docs/sitemap.xml`, and confirming `/robots.txt` allows `/llms.txt`.

## npm package bundle flow

**Starting file for agents:** `AGENTS.md` at the package root (inside `node_modules/<package>/AGENTS.md`).

This flow is produced by running `leadtype generate --bundle` when publishing an npm package. Bundle mode:

- Writes `AGENTS.md` at the package root.
- Writes per-page markdown under `docs/*.md` beneath the package root.
- Uses relative links from `AGENTS.md` such as `./docs/reference/cli.md` so coding agents can read the docs straight from `node_modules` with no network call.

Because the docs are bundled and version-matched with the package, agents always see the docs that correspond to the installed version.

## Which website artifacts bundle mode skips

Bundle mode deliberately omits website-only, HTTP-discoverable artifacts. According to `/docs/package-docs/bundle.md`, the skipped artifacts are:

- `llms.txt`
- `llms-full.txt`
- search JSON
- sitemap files
- `robots.txt`
- `agent-readability.json`

## Side-by-side comparison

| Aspect | Hosted website flow | npm bundle flow |
| --- | --- | --- |
| Trigger | Website build (website mode) | `leadtype generate --bundle` |
| Agent entry point | `/llms.txt` | `AGENTS.md` at the package root |
| Page format | Markdown mirrors at `/docs/*.md` (served via `Accept: text/markdown` or AI UA) | `docs/*.md` beneath the package root |
| Link style | Absolute site paths (e.g. `/docs/reference/cli.md`) | Relative paths (e.g. `./docs/reference/cli.md`) |
| Transport | HTTP fetch | Local filesystem read from `node_modules` |
| Includes `llms.txt` / `llms-full.txt` | Yes | No |
| Includes sitemap, `robots.txt` | Yes | No |
| Includes search JSON, `agent-readability.json` | Yes | No |

In short: the hosted flow starts at `/llms.txt` and relies on a constellation of static discovery artifacts served over HTTP; the bundle flow starts at `AGENTS.md` shipped inside the tarball and skips every website-only discovery artifact (`llms.txt`, `llms-full.txt`, sitemap files, `robots.txt`, search JSON, and `agent-readability.json`) because the docs are read directly from disk.
