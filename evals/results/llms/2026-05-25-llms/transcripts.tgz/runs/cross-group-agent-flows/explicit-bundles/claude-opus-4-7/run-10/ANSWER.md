# Cross-group agent flows: hosted website vs npm bundle

Leadtype emits docs through two complementary flows from the same MDX source. They differ in their entry point, their link style, and which artifacts they produce.

## Hosted website flow

**Entry point:** `/llms.txt` at the site root.

HTTP-based agents start at `/llms.txt` and follow markdown links to reach individual pages. Markdown is served either as static `/docs/*.md` mirrors, or by content-negotiating on the `Accept: text/markdown` header (or a known AI user agent) for docs URLs.

Website mode (`leadtype generate`) produces the full set of HTTP-discoverable artifacts:

- `/llms.txt` (root entry point)
- `/docs/llms.txt`
- `/llms-full.txt` (plus the per-group `/docs/llms-full/*.txt` bundles linked from `llms.txt`)
- Markdown mirrors under `/docs/*.md`
- `docs/sitemap.xml` and `docs/sitemap.md`
- `docs/robots.txt` (which must allow `/llms.txt`)
- `docs/agent-readability.json`
- `docs/search-index.json` and `docs/search-content.json`

Typical verification: fetch `/llms.txt`, fetch a docs page with `Accept: text/markdown`, check `/docs/sitemap.xml`, and confirm `/robots.txt` allows `/llms.txt`.

## npm package bundle flow

**Entry point:** `AGENTS.md` at the package root (inside `node_modules/<pkg>/`).

Coding agents working inside an installed npm package start at `AGENTS.md` and follow relative links like `./docs/reference/cli.md`. Because the links are relative and the docs live on disk inside `node_modules`, no network request is required, and the docs are version-matched to the installed package.

Bundle mode (`leadtype generate --bundle`) writes only:

- `AGENTS.md` at the package root
- `docs/*.md` beneath it

## Website artifacts that bundle mode skips

Bundle mode intentionally omits the website-only, HTTP-discoverable artifacts because they assume a server and an absolute URL space:

- `llms.txt`
- `llms-full.txt`
- Search JSON (`search-index.json`, `search-content.json`)
- Sitemap files (`sitemap.xml`, `sitemap.md`)
- `robots.txt`
- `agent-readability.json`

In short: the hosted flow starts at `/llms.txt` and ships the full HTTP discovery surface (llms files, sitemaps, robots, search index, agent-readability JSON); the bundle flow starts at `AGENTS.md` with relative `./docs/*.md` links and ships only those two pieces, dropping every artifact that exists to support URL-based discovery. The two flows are complementary — one package can publish bundled offline docs for `node_modules` *and* a hosted website with `llms.txt` for URL-based agents.
