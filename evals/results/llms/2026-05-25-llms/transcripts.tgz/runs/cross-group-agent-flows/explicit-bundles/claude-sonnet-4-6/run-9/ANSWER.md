# Cross-group Agent Flows: Hosted Website vs npm Bundle

## Overview

Leadtype supports two distinct agent flows that complement each other. A package can publish bundled offline docs for `node_modules` **and** a hosted docs website with `llms.txt` for URL-based agents — the two are not mutually exclusive.

---

## 1. Hosted Website Flow

### Entry Point
HTTP agents start at **`/llms.txt`** (at the site root) and follow markdown links from there.

### How It Works
1. `leadtype generate` (without `--bundle`) runs in **website mode**.
2. The generator reads MDX source pages, processes frontmatter and groups, flattens MDX components into markdown, and emits a full set of website artifacts.
3. Agents discover content by fetching `/llms.txt`, which provides a structured map of all docs sections and their full-context bundle files.
4. Agents can also request individual docs pages via `Accept: text/markdown` or as known AI user agents.

### Files/Artifacts Produced (website mode)
| Artifact | Purpose |
|---|---|
| `/llms.txt` | Root product-level index for HTTP agents |
| `/docs/llms.txt` | Docs-scoped map for hosted websites |
| `/llms-full.txt` | Root fallback containing every generated markdown page |
| `/docs/*.md` | Markdown mirrors of all MDX source pages |
| `/docs/sitemap.xml` | XML sitemap |
| `/docs/sitemap.md` | Markdown sitemap |
| `/docs/robots.txt` | Robots directives (allows `/llms.txt`) |
| `/docs/agent-readability.json` | Agent-readability metadata |
| `/docs/search-index.json` | Static search index |
| `/docs/search-content.json` | Search content data |

The `--json` flag causes `generate` to print a JSON object with paths for all of these artifacts (`llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, `agentReadabilityJson`, `sitemapXml`, `sitemapMd`, `robotsTxt`, `searchIndex`, `searchContent`).

---

## 2. npm Package Bundle Flow

### Entry Point
Coding agents working inside an installed npm package start at **`AGENTS.md`** (at the package root) and follow **relative** `./docs/*.md` links — no network request is needed.

### How It Works
1. `leadtype generate --bundle` runs in **bundle mode**.
2. The generator writes `AGENTS.md` at the package root and `docs/*.md` beneath it.
3. `AGENTS.md` uses relative links (e.g., `./docs/reference/cli.md`) so that coding agents can read docs directly inside `node_modules` without any HTTP access.
4. `generateAgentsMd` intentionally ignores `product.agentGuidance` text, because that text is written for website URL routing and is not appropriate for the offline bundle context.

### Files/Artifacts Produced (bundle mode)
| Artifact | Purpose |
|---|---|
| `AGENTS.md` | Root entry point for coding agents inside `node_modules` |
| `docs/*.md` | Markdown docs pages with relative links |

---

## 3. What Bundle Mode Skips

Bundle mode **skips all website-only artifacts** because they are meaningless without an HTTP server and a public URL:

| Skipped Artifact | Why It Is Website-Only |
|---|---|
| `llms.txt` | HTTP discovery index; requires a hosted URL |
| `llms-full.txt` | Root full-context fallback; served over HTTP |
| `search-index.json` | Static search index for the hosted site's query path |
| `search-content.json` | Search content data for the hosted site |
| `sitemap.xml` | XML sitemap for crawlers; requires a public URL |
| `sitemap.md` | Markdown sitemap; website navigation artifact |
| `robots.txt` | HTTP crawler directives; irrelevant in `node_modules` |
| `agent-readability.json` | Agent-readability metadata for the hosted docs site |

These paths are also identified internally by `isAgentReadabilityArtifactPath` so that the build does not mistakenly rewrite them as missing markdown pages.

---

## Summary Comparison

| Aspect | Hosted Website Flow | npm Bundle Flow |
|---|---|---|
| **Command** | `leadtype generate` | `leadtype generate --bundle` |
| **Agent entry point** | `/llms.txt` (HTTP URL) | `AGENTS.md` (relative file path) |
| **Link style** | Absolute URLs | Relative paths (`./docs/…`) |
| **Network required?** | Yes | No (works offline inside `node_modules`) |
| **Skipped artifacts** | None | `llms.txt`, `llms-full.txt`, search JSON, sitemap files, `robots.txt`, `agent-readability.json` |
| **Target agent type** | HTTP / URL-based agents | Coding agents (e.g., inside an IDE or CI environment) |
