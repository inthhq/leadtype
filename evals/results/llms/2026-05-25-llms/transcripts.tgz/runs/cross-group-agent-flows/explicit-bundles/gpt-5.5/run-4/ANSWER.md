# Cross-group agent flows: hosted website vs npm package bundle

Leadtype supports two complementary agent flows:

## Hosted website flow

Use website mode when agents will discover docs over HTTP from a hosted docs site.

- **Agent starting file:** `/llms.txt` at the website root.
- **How agents continue:** agents follow markdown links from `/llms.txt` into markdown mirrors such as `/docs/*.md` and full-context bundles such as `/docs/llms-full/*.txt`.
- **Generated website artifacts:** website mode writes `/llms.txt`, `/docs/llms.txt`, `/llms-full.txt`, markdown mirrors under `/docs/*.md`, sitemap files, robots rules, agent-readability metadata, and search JSON.
- **Serving behavior:** docs pages should serve markdown when `Accept` asks for `text/markdown` or when a known AI user agent requests a docs page.

## npm package bundle flow

Use bundle mode when publishing docs inside an npm tarball for coding agents working offline in `node_modules`.

- **Command:** `leadtype generate --bundle`.
- **Agent starting file:** `AGENTS.md` at the package root.
- **How agents continue:** `AGENTS.md` uses relative links such as `./docs/reference/cli.md`, so agents can read version-matched docs from the installed package without making network requests.
- **Generated package artifacts:** bundle mode writes `AGENTS.md` and `docs/*.md` beneath the package root.

## Website artifacts skipped by bundle mode

Bundle mode intentionally skips website-only artifacts:

- `llms.txt`
- `llms-full.txt`
- search JSON
- sitemap files
- `robots.txt`
- `agent-readability.json`

In short: URL-based agents start from hosted `/llms.txt`, while coding agents inside installed npm packages start from package-local `AGENTS.md`. The hosted flow includes web discovery, search, sitemap, robots, and readability artifacts; the bundle flow keeps only the offline package entry point and markdown docs needed inside `node_modules`.