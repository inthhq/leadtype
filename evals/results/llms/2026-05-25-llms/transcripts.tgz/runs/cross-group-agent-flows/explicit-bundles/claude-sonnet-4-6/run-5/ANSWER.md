# Cross-group Agent Flows: Hosted Website vs npm Bundle

## Overview

Leadtype supports two distinct agent flows from the same MDX source: a **hosted website flow** for HTTP-based agents and an **npm bundle flow** for coding agents working inside installed packages. Both flows complement each other — a package can publish bundled offline docs for `node_modules` *and* a hosted docs website with `llms.txt` for URL-based agents.

---

## 1. Hosted Website Flow

### Entry Point / Starting File
- **`/llms.txt`** (at the site root)

HTTP agents start at `/llms.txt` and follow the markdown links it exposes. There is also a docs-scoped `/docs/llms.txt` map generated alongside it.

### How It Works
1. An agent fetches `/llms.txt`, which lists available full-context bundles and individual docs pages with routing hints.
2. The agent follows links to markdown mirrors under `/docs/*.md` (served as `text/markdown` when the `Accept` header or user-agent indicates an AI client).
3. A root `/llms-full.txt` is also available as a single-file fallback containing every generated markdown docs page.

### Artifacts Generated (Website Mode)
Running `leadtype generate` (without `--bundle`) produces all of the following:

| Artifact | Purpose |
|---|---|
| `/llms.txt` | Product-level agent entry point |
| `/docs/llms.txt` | Docs-scoped agent map |
| `/llms-full.txt` | Root full-context fallback (all pages) |
| `/docs/*.md` | Markdown mirrors of each MDX page |
| `docs/sitemap.xml` | XML sitemap |
| `docs/sitemap.md` | Markdown sitemap |
| `docs/robots.txt` | Crawler directives |
| `docs/agent-readability.json` | Agent readability metadata |
| `docs/search-index.json` | Static search index |
| `docs/search-content.json` | Search content payload |

The `--json` flag makes `leadtype generate` print a JSON object with paths for all of the above (`llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, `agentReadabilityJson`, `sitemapXml`, `sitemapMd`, `robotsTxt`, `searchIndex`, `searchContent`).

---

## 2. npm Bundle Flow

### Entry Point / Starting File
- **`AGENTS.md`** (at the package root, inside `node_modules/<package>/`)

Coding agents working inside installed npm packages start at `AGENTS.md` and follow **relative** links like `./docs/reference/cli.md` — no network request is required.

### How It Works
1. Running `leadtype generate --bundle` writes `AGENTS.md` at the package root.
2. `AGENTS.md` links to docs pages under `docs/*.md` using relative paths so everything resolves correctly inside `node_modules`.
3. The agent reads docs entirely offline, without any HTTP discovery.

> **Note:** `generateAgentsMd` intentionally ignores `product.agentGuidance` because that text is written for website URL routing, which is irrelevant in the bundle context.

### Artifacts Generated (Bundle Mode)
Running `leadtype generate --bundle` produces only:

| Artifact | Purpose |
|---|---|
| `AGENTS.md` | Package-root agent entry point with relative links |
| `docs/*.md` | Markdown docs pages (relative links, works in `node_modules`) |

---

## 3. What Bundle Mode Skips

Bundle mode **skips all website-only artifacts** — those that only make sense for a hosted, HTTP-accessible site:

| Skipped Artifact | Why It's Website-Only |
|---|---|
| `llms.txt` | URL-based agent discovery; meaningless without a host |
| `llms-full.txt` | Root full-context file tied to URL routing |
| `docs/search-index.json` | Static search index for the hosted site |
| `docs/search-content.json` | Search content for the hosted site |
| `docs/sitemap.xml` | XML sitemap for crawlers |
| `docs/sitemap.md` | Markdown sitemap |
| `docs/robots.txt` | Crawler directives for the hosted domain |
| `docs/agent-readability.json` | Agent readability metadata for the hosted site |

These paths are collectively identified by `isAgentReadabilityArtifactPath` in the Leadtype API, which ensures they are never mistakenly rewritten as missing markdown pages.

---

## Summary Comparison

| Aspect | Hosted Website Flow | npm Bundle Flow |
|---|---|---|
| **Command** | `leadtype generate` | `leadtype generate --bundle` |
| **Agent entry point** | `/llms.txt` (HTTP URL) | `AGENTS.md` (relative file path) |
| **Link style** | Absolute URLs | Relative paths (`./docs/...`) |
| **Network required?** | Yes (HTTP) | No (offline, inside `node_modules`) |
| **Full-context fallback** | `/llms-full.txt` | Not generated |
| **Search index** | Generated | Skipped |
| **Sitemap / robots** | Generated | Skipped |
| **Agent-readability metadata** | Generated | Skipped |
| **Target agent type** | HTTP / URL-based agents | Coding agents in local environments |
