# Cross-group Agent Flows: Hosted Website vs npm Bundle

## Overview

Leadtype's pipeline produces two distinct agent-readable output modes from the same MDX source: **website mode** (the hosted docs site) and **bundle mode** (the npm package tarball). Each mode targets a different kind of agent and starts from a different entry-point file.

---

## 1. Hosted Website Flow

### Entry point
**`/llms.txt`** (at the site root)

HTTP agents discover the docs site by fetching `/llms.txt`. From there they follow markdown links to individual pages.

### How the flow works
1. An HTTP-based or URL-routing agent fetches `/llms.txt`, which lists all docs groups and their page links.
2. The agent can also fetch `/docs/llms.txt` (the docs-scoped map) or `/llms-full.txt` (a single file containing every generated markdown page, for full-context tasks).
3. Individual docs pages are served as markdown mirrors under `/docs/*.md` (via `Accept: text/markdown` or AI user-agent detection).

### Artifacts generated (website mode)
| Artifact | Purpose |
|---|---|
| `/llms.txt` | Product-level agent entry point |
| `/docs/llms.txt` | Docs-scoped agent map |
| `/llms-full.txt` | Root full-context fallback (all pages concatenated) |
| `/docs/*.md` | Markdown mirrors of each MDX page |
| `/docs/sitemap.xml` | XML sitemap |
| `/docs/sitemap.md` | Markdown sitemap |
| `/docs/robots.txt` | Crawler/agent permissions |
| `/docs/agent-readability.json` | Agent-readability metadata |
| `/docs/search-index.json` | Static search index |
| `/docs/search-content.json` | Search content payload |

The `--json` flag makes `leadtype generate` print a JSON object with paths to all of the above (`llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, `agentReadabilityJson`, `sitemapXml`, `sitemapMd`, `robotsTxt`, `searchIndex`, `searchContent`).

---

## 2. npm Bundle Flow

### Entry point
**`AGENTS.md`** (at the package root, inside `node_modules/<package>/`)

Coding agents working inside an installed npm package start at `AGENTS.md` and follow **relative** links (`./docs/reference/cli.md`, etc.) — no network request required.

### How the flow works
1. Run `leadtype generate --bundle` before publishing the npm package.
2. `AGENTS.md` is written at the package root with relative links into `docs/*.md`.
3. A coding agent (e.g. one reading source code in `node_modules`) opens `AGENTS.md` and navigates entirely through the local file system.

### Artifacts generated (bundle mode)
| Artifact | Purpose |
|---|---|
| `AGENTS.md` | Package-level agent entry point (relative links) |
| `docs/*.md` | Markdown docs pages, path-stable for `node_modules` |

> **Note:** `generateAgentsMd` intentionally ignores `product.agentGuidance` because that text is written for website URL routing, which is irrelevant inside a local package.

---

## 3. Website Artifacts That Bundle Mode Skips

Bundle mode produces **only** `AGENTS.md` and `docs/*.md`. It explicitly omits every website-only artifact:

| Skipped artifact | Why it's omitted |
|---|---|
| `llms.txt` | URL-discovery file; meaningless without an HTTP server |
| `llms-full.txt` | Root full-context file for HTTP agents |
| `sitemap.xml` | Requires a hosted base URL |
| `sitemap.md` | Markdown sitemap for hosted navigation |
| `robots.txt` | Crawler policy; only relevant on a web host |
| `search-index.json` | Runtime search index for the hosted website |
| `search-content.json` | Search content for the hosted website |
| `agent-readability.json` | Hosted agent-readability metadata |

The helper `isAgentReadabilityArtifactPath` identifies all of these paths so they are never rewritten as missing markdown pages.

---

## 4. Side-by-side Comparison

| Dimension | Hosted Website Flow | npm Bundle Flow |
|---|---|---|
| **Trigger** | `leadtype generate` (default) | `leadtype generate --bundle` |
| **Entry-point file** | `/llms.txt` | `AGENTS.md` |
| **Agent type** | HTTP / URL-routing agents | Coding agents in `node_modules` |
| **Link style** | Absolute URLs | Relative paths (`./docs/…`) |
| **Requires network?** | Yes | No |
| **Full-context fallback** | `/llms-full.txt` | All content in `docs/*.md` |
| **Skipped artifacts** | _(none — all are produced)_ | `llms.txt`, `llms-full.txt`, sitemaps, `robots.txt`, search JSON, `agent-readability.json` |

---

## Key Takeaway

The two flows are **complementary, not mutually exclusive**. A package can publish bundled offline docs for agents working inside `node_modules` *and* maintain a hosted docs website with `llms.txt` for URL-based agents. The same MDX source feeds both pipelines; only the output artifacts — and the entry-point file an agent starts from — differ.
