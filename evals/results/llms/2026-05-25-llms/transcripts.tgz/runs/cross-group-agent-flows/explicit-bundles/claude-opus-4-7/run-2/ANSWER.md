# Cross-group agent flows: hosted website vs npm bundle

Leadtype exposes two distinct flows for getting docs into the hands of coding agents. They are described in two separate full-context bundles on the docs site:

- `/docs/llms-full/build.txt` → Build group (hosted website flow)
- `/docs/llms-full/package-docs.txt` → Ship Package Docs group (npm bundle flow)

## Hosted website flow

**Source page:** [`/docs/build/connect-docs-site.md`](/docs/build/connect-docs-site.md)

Use this "website mode" when a docs site needs to expose HTTP-discoverable agent files. The flow starts from a well-known entry point and fans out:

1. **Entry point:** `/llms.txt` at the site root — the agent's first fetch.
2. **Markdown mirrors:** `/docs/*.md` served alongside the rendered HTML. The server is expected to return markdown when the request's `Accept` header asks for `text/markdown`, or when a known AI user agent requests a docs page.
3. **Static agent artifacts** kept on disk:
   - `/llms.txt`
   - `/llms-full.txt`
   - sitemap files (e.g. `/docs/sitemap.xml`)
   - `/robots.txt` (must allow `/llms.txt`)
   - search JSON
   - `agent-readability.json`

Recommended verification: fetch `/llms.txt`, fetch a docs page with `Accept: text/markdown`, check `/docs/sitemap.xml`, and confirm `/robots.txt` allows `/llms.txt`.

## npm bundle flow

**Source page:** [`/docs/package-docs/bundle.md`](/docs/package-docs/bundle.md)

Use this "bundle mode" when publishing an npm package. The flow is invoked with `leadtype generate --bundle` and produces a self-contained tree inside the tarball:

1. **Entry point:** `AGENTS.md` at the package root — what an agent reads after `npm install`.
2. **Co-located docs:** `docs/*.md` beneath the package root.
3. **Linking:** `AGENTS.md` uses relative links such as `./docs/reference/cli.md` so a coding agent can read docs straight out of `node_modules` with no network request.

## Which website artifacts the bundle skips

Bundle mode is deliberately offline-first, so it **skips every website-only artifact**:

| Artifact | Website flow | Bundle flow |
|---|---|---|
| `llms.txt` | ✅ served at site root | ❌ skipped |
| `llms-full.txt` | ✅ static file | ❌ skipped |
| Search JSON | ✅ static file | ❌ skipped |
| Sitemap files | ✅ static file | ❌ skipped |
| `robots.txt` | ✅ static file | ❌ skipped |
| `agent-readability.json` | ✅ static file | ❌ skipped |
| `AGENTS.md` | — | ✅ package root |
| `docs/*.md` | ✅ HTTP-served mirrors | ✅ relative files in tarball |

## Summary

- **Hosted flow** starts at `/llms.txt` and depends on HTTP conventions (content negotiation, sitemap, robots, search index, readability manifest).
- **Bundle flow** starts at `AGENTS.md` inside the installed package and uses relative file paths instead, dropping all six website-only artifacts (`llms.txt`, `llms-full.txt`, search JSON, sitemap files, `robots.txt`, and `agent-readability.json`) because no HTTP server is involved.
