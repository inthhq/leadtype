# Cross-group Agent Flows: Hosted vs npm Bundle

## Overview

Leadtype supports two parallel but complementary agent flows. Both start from the same MDX source and produce markdown, but they differ in their entry-point files, link strategies, and which artifacts are generated.

---

## 1. Hosted Website Flow

### Entry Point
HTTP agents start at **`/llms.txt`** (at the site root). From there they follow markdown links into the docs pages.

### How It Works
- The build generates `/llms.txt` at the site root and markdown mirrors under `/docs/*.md`.
- Agents can also reach docs pages by sending an `Accept: text/markdown` header, or by being a recognized AI user agent requesting a docs page.
- The docs-scoped **`/docs/llms.txt`** provides a narrower map of just the docs section.
- A root fallback **`/llms-full.txt`** bundles every generated markdown docs page into one file.

### Artifacts Generated (Website Mode)
| Artifact | Purpose |
|---|---|
| `/llms.txt` | Product-level agent entry point |
| `/docs/llms.txt` | Docs-scoped agent map |
| `/llms-full.txt` | Full-context fallback (all pages concatenated) |
| `/docs/*.md` | Markdown mirrors of each docs page |
| `docs/sitemap.xml` | XML sitemap |
| `docs/sitemap.md` | Markdown sitemap |
| `docs/robots.txt` | Crawler permissions (must allow `/llms.txt`) |
| `docs/agent-readability.json` | Agent-readability metadata |
| `docs/search-index.json` | Static search index |
| `docs/search-content.json` | Search content source |

### CLI JSON Output Keys (website mode)
`llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, `agentReadabilityJson`, `sitemapXml`, `sitemapMd`, `robotsTxt`, `searchIndex`, `searchContent`.

---

## 2. npm Bundle Flow

### Entry Point
Coding agents working inside installed npm packages start at **`AGENTS.md`** (written at the package root). From there they follow **relative links** like `./docs/reference/cli.md`.

### How It Works
- Run `leadtype generate --bundle` when publishing an npm package.
- Bundle mode writes `AGENTS.md` at the package root and `docs/*.md` beneath it.
- Links are relative so agents can read docs inside `node_modules` **without any network request** — fully offline.
- `generateAgentsMd` intentionally ignores `product.agentGuidance` because that text is written for website URL routing, which is irrelevant in a local `node_modules` context.

### Artifacts Generated (Bundle Mode)
| Artifact | Purpose |
|---|---|
| `AGENTS.md` | Coding-agent entry point (relative links) |
| `docs/*.md` | Markdown docs pages |

---

## Website Artifacts That Bundle Mode Skips

Bundle mode explicitly **omits** all website-only artifacts. These are the files skipped:

| Skipped Artifact | Why It's Skipped |
|---|---|
| `llms.txt` | HTTP discovery file; meaningless without a hosted URL |
| `llms-full.txt` | Root full-context fallback; HTTP-only concept |
| Search JSON (`search-index.json`, `search-content.json`) | Runtime search requires a web server |
| Sitemap files (`sitemap.xml`, `sitemap.md`) | URL-based crawling artifact |
| `robots.txt` | Crawler/HTTP agent permissions; not relevant in `node_modules` |
| `agent-readability.json` | Website agent-readability metadata |

These paths are identified programmatically by `isAgentReadabilityArtifactPath`, which prevents them from being mistakenly rewritten as missing markdown pages.

---

## Summary Comparison

| Dimension | Hosted Website Flow | npm Bundle Flow |
|---|---|---|
| **Agent entry point** | `/llms.txt` (HTTP, site root) | `AGENTS.md` (filesystem, package root) |
| **Link style** | Absolute URLs | Relative paths (`./docs/…`) |
| **Network required?** | Yes | No (works offline in `node_modules`) |
| **Full-context file** | `/llms-full.txt` | — (skipped) |
| **Search index** | ✅ Generated | ❌ Skipped |
| **Sitemap / robots.txt** | ✅ Generated | ❌ Skipped |
| **agent-readability.json** | ✅ Generated | ❌ Skipped |
| **CLI flag** | `leadtype generate` (default) | `leadtype generate --bundle` |

The two flows are designed to complement each other: a package can publish bundled offline docs for `node_modules`-based agents **and** maintain a hosted docs website with `llms.txt` for URL-based agents simultaneously.
