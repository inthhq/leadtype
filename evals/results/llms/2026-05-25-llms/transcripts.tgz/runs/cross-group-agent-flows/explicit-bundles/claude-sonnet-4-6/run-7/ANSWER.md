# Cross-group agent flows: hosted vs npm bundle

## Overview

Leadtype supports two distinct agent flows from the same MDX source: a **hosted website flow** for HTTP-based agents and an **npm bundle flow** for coding agents working inside installed packages. The two flows are complementary — a project can publish both simultaneously.

---

## 1. Hosted Website Flow

### Entry point / starting file
HTTP agents start at **`/llms.txt`** (the product-level index at the site root).  
A second, docs-scoped index is also generated at **`/docs/llms.txt`**.

Agents follow markdown links from those index files to the individual content pages exposed as HTTP-discoverable markdown mirrors under `/docs/*.md`.

### How it works
- The build runs `leadtype generate` (no `--bundle` flag).
- MDX pages are converted and their markdown mirrors are written under `/docs/*.md`.
- When a request arrives with `Accept: text/markdown` or from a known AI user agent, the server serves the markdown version of a docs page.

### Artifacts generated (website mode)
| Artifact | Purpose |
|---|---|
| `/llms.txt` | Product-level agent index (entry point) |
| `/docs/llms.txt` | Docs-scoped agent index |
| `/llms-full.txt` | Root full-context fallback (all pages in one file) |
| `/docs/*.md` | Markdown mirrors of every docs page |
| `docs/sitemap.xml` | XML sitemap |
| `docs/sitemap.md` | Markdown sitemap |
| `docs/robots.txt` | Crawler permissions (allows `/llms.txt`) |
| `docs/agent-readability.json` | Agent-readability metadata |
| `docs/search-index.json` | Static search index |
| `docs/search-content.json` | Search content payload |

Verification checks: fetch `/llms.txt`, fetch a docs page with `Accept: text/markdown`, check `/docs/sitemap.xml`, and confirm `/robots.txt` allows `/llms.txt`.

---

## 2. npm Bundle Flow

### Entry point / starting file
Coding agents working inside installed npm packages start at **`AGENTS.md`** (written at the **package root**).

`AGENTS.md` uses **relative links** (e.g. `./docs/reference/cli.md`) so agents can navigate the docs entirely inside `node_modules` without any network request.

### How it works
- The build runs `leadtype generate --bundle`.
- `AGENTS.md` is written at the package root.
- Docs content is written as `docs/*.md` beneath it, using relative links throughout.
- The `generateAgentsMd` function intentionally ignores `product.agentGuidance` because that text is written for website URL routing, which is irrelevant in the offline bundle context.

### Artifacts generated (bundle mode)
| Artifact | Purpose |
|---|---|
| `AGENTS.md` | Package-root agent index (entry point) |
| `docs/*.md` | Markdown content pages with relative links |

---

## 3. What Bundle Mode Skips

Bundle mode deliberately omits all **website-only artifacts** because they are HTTP/URL-oriented and have no meaning inside a local `node_modules` directory:

| Skipped Artifact | Why it's skipped |
|---|---|
| `llms.txt` | HTTP discovery index — no URL routing in node_modules |
| `llms-full.txt` | Root full-context file for hosted URL access |
| Search JSON (`search-index.json`, `search-content.json`) | Static search infrastructure is for the hosted site |
| Sitemap files (`sitemap.xml`, `sitemap.md`) | Web crawler / sitemap — irrelevant offline |
| `robots.txt` | Crawler directives — not applicable in a package |
| `agent-readability.json` | Hosted-site agent-readability metadata |

The `isAgentReadabilityArtifactPath` API in the reference layer covers exactly these paths, identifying them as artifacts that must not be rewritten as missing markdown pages.

---

## Summary Comparison

| Aspect | Hosted Website Flow | npm Bundle Flow |
|---|---|---|
| **Agent entry point** | `/llms.txt` (HTTP URL) | `AGENTS.md` (package root file) |
| **Content links** | Absolute HTTP URLs | Relative file paths (`./docs/…`) |
| **Network required?** | Yes | No (works fully offline in node_modules) |
| **CLI command** | `leadtype generate` | `leadtype generate --bundle` |
| **Website artifacts** | All generated | **Skipped** (llms.txt, llms-full.txt, search JSON, sitemaps, robots.txt, agent-readability.json) |
| **Use case** | HTTP/URL-based agents | Coding agents in installed packages |
