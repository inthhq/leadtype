# Cross-group agent flows: hosted website vs npm bundle

## Hosted website flow

- **Entry point:** HTTP/URL-based agents start at the site-root file **`/llms.txt`**.
- **How agents continue:** They follow the markdown links from `/llms.txt` into the hosted docs, including markdown mirrors under **`/docs/*.md`** and full-context bundles such as **`/llms-full.txt`** or grouped full-context files.
- **Serving behavior:** The hosted site should serve markdown for docs pages when `Accept` asks for `text/markdown` or when a known AI user agent requests a docs page.
- **Website artifacts:** Website mode generates or keeps static artifacts such as:
  - `llms.txt`
  - `/docs/llms.txt`
  - `llms-full.txt`
  - markdown mirrors under `/docs/*.md`
  - sitemap files, including `docs/sitemap.xml` and `docs/sitemap.md`
  - `robots.txt`
  - `agent-readability.json`
  - `search-index.json`
  - `search-content.json`

## npm package bundle flow

- **Entry point:** Coding agents working inside an installed npm package start at **`AGENTS.md`** in the package root.
- **How agents continue:** `AGENTS.md` uses relative links, for example `./docs/reference/cli.md`, so agents can follow links to bundled **`docs/*.md`** files inside `node_modules`.
- **Network requirement:** This flow is offline and version-matched to the installed package; agents do not need to fetch hosted docs.
- **How it is generated:** Use **`leadtype generate --bundle`** when publishing an npm package. Bundle mode writes:
  - `AGENTS.md`
  - `docs/*.md`

## Website artifacts skipped by bundle mode

Bundle mode intentionally skips website-only artifacts:

- `llms.txt`
- `llms-full.txt`
- search JSON, including `search-index.json` and `search-content.json`
- sitemap files
- `robots.txt`
- `agent-readability.json`

In short: hosted docs are for HTTP agents and begin at `/llms.txt`; npm-bundled docs are for coding agents inside `node_modules` and begin at `AGENTS.md`. Both expose markdown docs, but bundle mode omits the discovery, search, sitemap, robots, and readability artifacts that only matter for a hosted website.