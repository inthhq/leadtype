# Cross-group agent flows: hosted website vs npm package bundle

Leadtype emits two distinct sets of agent-readable artifacts from a single MDX source. Each targets a different kind of agent and starts from a different entry file.

## Starting files for each flow

| Flow | Entry file | Discovery model | Followed links |
|------|------------|-----------------|----------------|
| Hosted website | `/llms.txt` at the site root | HTTP fetch (with `Accept: text/markdown` or a known AI user agent) | Absolute URLs to `/docs/*.md` markdown mirrors |
| npm package bundle | `AGENTS.md` at the package root | Local filesystem reads inside `node_modules` (no network) | Relative links like `./docs/reference/cli.md` |

Quoting `docs/how-it-works.md`:

> HTTP agents start at `/llms.txt` and follow markdown links. Coding agents working inside installed npm packages start at `AGENTS.md` and follow relative `docs/*.md` links.

## Website (hosted) flow

Triggered by `leadtype generate` in website mode. According to `docs/quickstart.md` and `docs/build/connect-docs-site.md`, the build writes:

- `/llms.txt` (root entry point for agents)
- `/docs/llms.txt`
- `/llms-full.txt`
- Markdown mirrors under `/docs/*.md`
- `docs/sitemap.xml` and `docs/sitemap.md`
- `docs/robots.txt`
- `docs/agent-readability.json`
- `docs/search-index.json` and `docs/search-content.json`

The site should serve markdown when the client asks for `text/markdown` or when a recognized AI user agent requests a docs page. Verification includes fetching `/llms.txt`, fetching a docs page with `Accept: text/markdown`, checking `/docs/sitemap.xml`, and confirming `/robots.txt` allows `/llms.txt`.

## npm package bundle flow

Triggered by `leadtype generate --bundle`. According to `docs/package-docs/bundle.md`, bundle mode writes only:

- `AGENTS.md` at the package root
- `docs/*.md` beneath it

`AGENTS.md` uses relative links (e.g. `./docs/reference/cli.md`) so a coding agent can read docs directly out of `node_modules` without any HTTP request.

## Website artifacts bundle mode skips

Per `docs/package-docs/bundle.md`, bundle mode deliberately omits every website-only artifact:

- `llms.txt`
- `llms-full.txt`
- Search JSON (`search-index.json`, `search-content.json`)
- Sitemap files (`sitemap.xml`, `sitemap.md`)
- `robots.txt`
- `agent-readability.json`

These are skipped because they exist to support HTTP-based discovery and indexing, which is irrelevant for an agent reading files locally inside an installed package.

## How the two flows complement each other

From `docs/how-it-works.md`: a single package can publish both — bundled offline docs inside the npm tarball for `node_modules` consumers, and a hosted docs website with `llms.txt` for URL-based agents — from the same MDX source.
