# Cross-group agent flows: hosted vs npm bundle

## Hosted Website Flow

**Starting Point:** `/llms.txt`

The hosted website flow exposes HTTP-discoverable agent files. Agents discover and navigate the documentation starting from `/llms.txt` at the site root. The flow generates:

- `/llms.txt` - Main entry point
- `/llms-full.txt` - Full context bundles
- `/docs/*.md` - Markdown mirrors of all docs pages
- `/docs/sitemap.xml` - Sitemap files
- `/robots.txt` - SEO/discovery directives
- `/search.json` - Search index
- `agent-readability.json` - Agent readability metadata

Agents fetch markdown by making requests with `Accept: text/markdown` header or when recognized as known AI user agents. All website artifacts remain static and discoverable via HTTP.

## npm Package Bundle Flow

**Starting Point:** `AGENTS.md` (at package root)

The npm package bundle flow ships documentation inside the npm tarball for offline access. When bundled, the flow:

- Generates `AGENTS.md` at the package root
- Bundles markdown docs under `./docs/*.md` 
- Uses relative links (e.g., `./docs/reference/cli.md`) so agents can read docs from `node_modules` without network requests

## Artifacts Skipped in Bundle Mode

Bundle mode **skips all website-only artifacts**:

- `llms.txt`
- `llms-full.txt`
- Search JSON
- Sitemap files
- `robots.txt`
- `agent-readability.json`

## Key Differences

| Aspect | Hosted Website | npm Bundle |
|--------|---|---|
| **Entry Point** | `/llms.txt` (HTTP discovery) | `AGENTS.md` (direct file access) |
| **Link Style** | Absolute HTTP URLs | Relative file paths |
| **Network Required** | Yes | No |
| **Discovery Artifacts** | `llms.txt`, `llms-full.txt`, sitemaps, robots.txt, search.json, agent-readability.json | None |
| **Documentation Files** | `/docs/*.md` at HTTP paths | `docs/*.md` as relative paths |

The hosted flow optimizes for HTTP-based agent discovery with rich metadata, while the bundle flow optimizes for offline package consumption with minimal overhead.
