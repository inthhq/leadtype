# Cross-group agent flows: hosted website vs npm bundle

## Hosted website flow

- **Entry point for agents:** `/llms.txt` at the site root.
- **How agents continue:** HTTP agents follow the markdown links from `/llms.txt` into generated markdown mirrors such as `/docs/*.md`.
- **Related hosted artifacts:** website mode also generates a docs-scoped map at `/docs/llms.txt`, a root `/llms-full.txt` fallback, markdown mirrors under `/docs/*.md`, sitemap files, robots rules, search JSON, and `agent-readability.json`.
- **Use case:** URL-based agents can discover and fetch docs over HTTP. Docs pages should serve markdown when requested with `Accept: text/markdown` or by known AI user agents.

## npm package bundle flow

- **Entry point for agents:** `AGENTS.md` at the npm package root.
- **How agents continue:** coding agents inside `node_modules` follow relative links from `AGENTS.md`, for example `./docs/reference/cli.md`, into bundled `docs/*.md` files.
- **Use case:** offline, version-matched package docs that work without a network request.

## Website artifacts skipped by bundle mode

When using `leadtype generate --bundle`, Leadtype writes only the package-oriented `AGENTS.md` plus `docs/*.md`. It skips the website-only artifacts:

- `llms.txt`
- `llms-full.txt`
- search JSON
- sitemap files
- `robots.txt`
- `agent-readability.json`
