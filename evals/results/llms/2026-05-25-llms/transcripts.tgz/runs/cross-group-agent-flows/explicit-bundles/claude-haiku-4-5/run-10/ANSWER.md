# Cross-Group Agent Flows: Hosted vs NPM Bundle

## Overview

Leadtype supports two distinct cross-group agent flows for deploying documentation: a **hosted website mode** and an **npm bundle mode**. Each flow is optimized for different delivery contexts and generates different sets of artifacts.

## Hosted Website Flow (Website Mode)

### Starting Point
The hosted flow **starts from `/llms.txt`** at the site root, which serves as the agent's entry point for HTTP-discoverable documentation.

### Key Artifacts Generated
- **`/llms.txt`** - Root-level manifest file that agents discover to begin navigation
- **`/llms-full.txt`** - Fallback file containing all generated markdown pages (not split by group)
- **`/docs/*.md`** - Markdown mirrors organized under the docs directory
- **`/docs/sitemap.xml`** - Sitemap file for agent discoverability
- **`/robots.txt`** - Standard robots file (explicitly configured to allow `/llms.txt`)
- **`/search.json`** - Search index for agent queries
- **`agent-readability.json`** - Metadata about agent-readable content

### Flow Characteristics
- Agents fetch content via **HTTP requests** with content negotiation
- Markdown is served when Accept header requests `text/markdown` or when known AI user agents request docs pages
- Content is **network-dependent** - agents must fetch files from the hosted server
- Each group declaration in page frontmatter affects sidebar position, `/llms.txt` section organization, search metadata, and `AGENTS.md` grouping

## NPM Bundle Flow (Bundle Mode)

### Starting Point
The npm bundle flow **starts from `AGENTS.md`** at the package root, which serves as the agent's entry point for offline access inside `node_modules`.

### Key Artifacts Generated
- **`AGENTS.md`** - Root-level manifest file at package root
- **`docs/*.md`** - Version-matched markdown docs beneath the package root

### Flow Characteristics
- Agents use **relative links** like `./docs/reference/cli.md` to navigate documentation
- Agents can read docs **offline** without network requests
- All references are **relative paths**, enabling agents to work inside `node_modules` directories
- Uses `leadtype generate --bundle` command during npm package publishing

### Skipped Artifacts
Bundle mode explicitly skips all **website-only artifacts**:
- `llms.txt` - Not needed without HTTP discovery
- `llms-full.txt` - Not needed for bundled agents
- `search.json` - Search not applicable offline
- Sitemap files - Not needed without a website
- `robots.txt` - Not applicable for offline bundle
- `agent-readability.json` - Not needed for package distribution

## Key Differences Summary

| Aspect | Hosted (Website) | NPM Bundle |
|--------|-----------------|-----------|
| **Entry Point** | `/llms.txt` (HTTP-discoverable) | `AGENTS.md` (package root) |
| **Link Style** | Absolute/HTTP URLs | Relative paths (e.g., `./docs/reference/cli.md`) |
| **Network Dependency** | Network-required | Offline (node_modules) |
| **Discovery Method** | HTTP with content negotiation | Direct file system access |
| **Sitemap/Robots** | Generated | Skipped |
| **Search Index** | Generated | Skipped |
| **Agent Readability Metadata** | Generated | Skipped |

## Common Element

Both flows respect the **group** field from page frontmatter, which:
- Drives sidebar positioning
- Organizes `llms.txt` sections and `AGENTS.md` grouping
- Provides search metadata
- Allows pages to belong to multiple groups via `group: [a, b]`

The root `/llms-full.txt` in hosted mode serves as the fallback containing all pages and is not split by group, providing a comprehensive option when group-specific navigation isn't available.
