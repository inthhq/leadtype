# Cross-group agent flows: hosted vs npm bundle

Leadtype has two complementary agent flows that start from different entry files:

| Flow | Agent context | Entry file | How agents continue |
| --- | --- | --- | --- |
| Hosted website flow | URL/HTTP agents reading the docs site | `/llms.txt` at the site root | Follow markdown links to hosted markdown mirrors such as `/docs/*.md`; docs pages can also be served as markdown when `Accept: text/markdown` or a known AI user agent requests them. |
| npm package bundle flow | Coding agents working inside an installed package, for example under `node_modules` | `AGENTS.md` at the package root | Follow relative links such as `./docs/reference/cli.md` to bundled `docs/*.md` files without making a network request. |

In website mode, `leadtype generate` emits HTTP-discoverable site artifacts such as `/llms.txt`, `/docs/llms.txt`, `/llms-full.txt`, markdown mirrors under `/docs/*.md`, sitemap files, robots metadata, search JSON, and `agent-readability.json`.

In package bundle mode, `leadtype generate --bundle` writes only the package-oriented agent docs: `AGENTS.md` plus `docs/*.md` beneath the package root. Bundle mode intentionally skips website-only artifacts: `llms.txt`, `llms-full.txt`, search JSON, sitemap files, `robots.txt`, and `agent-readability.json`.