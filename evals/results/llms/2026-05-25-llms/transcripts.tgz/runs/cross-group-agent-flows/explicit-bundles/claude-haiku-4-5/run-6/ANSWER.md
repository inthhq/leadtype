# Cross-Group Agent Flows: Hosted vs NPM Bundle

## Overview
Leadtype supports two distinct agent flows that complement each other, serving different deployment contexts and access patterns.

## Hosted Website Flow (HTTP Agents)

**Starting File:** `/llms.txt`

HTTP-based agents access the hosted documentation website by starting at the root `llms.txt` file. They then follow markdown links to discover and read documentation pages.

### Generated Artifacts for Hosted Mode:
- `/llms.txt` (root entry point)
- `/docs/llms.txt`
- `/llms-full.txt` (full context bundle)
- Markdown mirrors at `/docs/*.md`
- `docs/sitemap.xml`
- `docs/sitemap.md`
- `docs/robots.txt`
- `docs/agent-readability.json`
- `docs/search-index.json`
- `docs/search-content.json`

## NPM Bundle Flow (Offline Agents)

**Starting File:** `AGENTS.md`

Coding agents working inside installed npm packages start at the `AGENTS.md` file located at the package root. The documentation uses relative links (e.g., `./docs/reference/cli.md`) so agents can discover and read docs without requiring network requests.

### Generated Artifacts for Bundle Mode:
- `AGENTS.md` (root entry point)
- `docs/*.md` (relative markdown links)

## Artifacts Skipped in Bundle Mode

The bundle mode skips all website-only artifacts that are not needed for offline access within `node_modules`:

- `llms.txt`
- `llms-full.txt`
- Search JSON files (`search-index.json`, `search-content.json`)
- Sitemap files (`sitemap.xml`, `sitemap.md`)
- `robots.txt`
- `agent-readability.json`

## Key Differences

| Aspect | Hosted Flow | Bundle Flow |
|--------|-------------|-------------|
| **Starting Point** | `/llms.txt` | `AGENTS.md` |
| **Access Model** | HTTP/URL-based | File system/node_modules |
| **Link Format** | Absolute URLs | Relative paths |
| **Network Required** | Yes | No |
| **Website Artifacts** | All included | Skipped |
| **Use Case** | Public documentation websites | Private package documentation |

## Complementary Strategy

Both flows can be used by a single project: a package can publish bundled offline docs for use by agents working inside installed npm packages, while simultaneously hosting a website with `llms.txt` for URL-based agents accessing documentation over HTTP.
