# Cross-Group Agent Flows: Hosted vs NPM Bundle

## Overview

Leadtype supports two distinct agent flows for serving documentation: a **hosted website mode** and an **npm bundle mode**. Each flow optimizes for different agent access patterns.

---

## Hosted Website Flow (Website Mode)

### Starting Point
The hosted website flow is initiated using **website mode** (the default Leadtype build mode).

### Generated Files
The build generates:
- `/llms.txt` at the site root (entry point for agent discovery)
- `/llms-full.txt` (full context bundles)
- Markdown mirrors under `/docs/*.md`
- Static artifacts: sitemap files, robots.txt, search JSON, and agent-readability.json

### Agent Interaction Pattern
1. Agents discover the docs site via `/llms.txt`
2. Agents make HTTP requests to fetch markdown files
3. Requests use `Accept: text/markdown` headers or are identified as known AI user agents
4. The server responds with markdown versions of documentation

### Key Characteristic
This flow is **HTTP-discoverable** and designed for agents that can make network requests to a hosted website.

---

## NPM Bundle Mode Flow

### Starting Point
The npm bundle flow is initiated using `leadtype generate --bundle` when publishing an npm package.

### Generated Files
The build generates:
- `AGENTS.md` at the package root (entry point for agents)
- `docs/*.md` beneath the package root

### Agent Interaction Pattern
1. Agents locate `AGENTS.md` within `node_modules`
2. `AGENTS.md` contains relative links like `./docs/reference/cli.md`
3. Agents read documentation files **offline** directly from the filesystem
4. No network requests are required

### Key Characteristic
This flow is **offline-first** and designed for agents that access docs inside `node_modules` without making HTTP requests.

---

## Website Artifacts Skipped in Bundle Mode

Bundle mode skips the following website-only artifacts that are generated in hosted mode:

1. **llms.txt** - HTTP discovery entry point (not needed for package mode)
2. **llms-full.txt** - Full context bundles (not needed for package mode)
3. **Search JSON** - Search index files (not applicable for offline mode)
4. **Sitemap files** - XML/HTML sitemaps for HTTP crawlers (not needed for packages)
5. **robots.txt** - HTTP crawler directives (not applicable for packages)
6. **agent-readability.json** - Agent metadata for HTTP discovery (not needed for packages)

---

## Summary Table

| Aspect | Hosted Website Mode | NPM Bundle Mode |
|--------|-------------------|-----------------|
| **Initiation** | Default Leadtype build | `leadtype generate --bundle` |
| **Root Entry Point** | `/llms.txt` | `AGENTS.md` |
| **Doc Location** | `/docs/*.md` (HTTP-served) | `docs/*.md` (filesystem) |
| **Access Model** | HTTP requests | Offline filesystem reads |
| **Link Type** | HTTP URLs | Relative paths (./docs/...) |
| **Target Agents** | Network-capable agents | Node.js agents in package consumers |
| **Artifacts Generated** | llms.txt, llms-full.txt, sitemaps, robots.txt, search JSON, agent-readability.json | AGENTS.md, docs/*.md |
| **Artifacts Skipped** | None | All website-only artifacts |

---

## Verification Approach

**Hosted mode** should be verified by:
- Fetching `/llms.txt`
- Fetching a docs page with `Accept: text/markdown` header
- Checking `/docs/sitemap.xml`
- Confirming `/robots.txt` allows `/llms.txt`

**Bundle mode** requires only:
- Locating `AGENTS.md` in the package root
- Reading linked `docs/*.md` files via relative paths
