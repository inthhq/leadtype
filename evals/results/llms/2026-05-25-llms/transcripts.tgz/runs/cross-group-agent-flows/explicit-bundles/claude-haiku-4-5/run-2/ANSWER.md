# Cross-group Agent Flows: Hosted vs NPM Bundle

## Overview

Leadtype supports two complementary agent flows for discovering and accessing documentation. These flows diverge at the starting point and differ in which artifacts are generated.

## Hosted Website Flow

**Starting Point:** `/llms.txt`

The hosted website flow is designed for HTTP-discoverable agent files. When agents access a hosted docs site:

1. Agents start by fetching `/llms.txt` at the site root
2. Agents follow markdown links from there
3. The website contains markdown mirrors under `/docs/*.md`

**Generated Artifacts Include:**
- `/llms.txt` (entry point at site root)
- `/docs/llms.txt` (alternative access point)
- `/llms-full.txt` (full context bundle)
- `/docs/*.md` (markdown mirrors of all documentation)
- `docs/sitemap.xml` and `docs/sitemap.md` (discovery aids)
- `docs/robots.txt` (SEO guidance)
- `docs/agent-readability.json` (agent capability declaration)
- `docs/search-index.json` and `docs/search-content.json` (search functionality)

## NPM Bundle Flow

**Starting Point:** `AGENTS.md` (at package root)

The npm bundle flow is designed for offline, coding agents working inside installed npm packages. When agents access bundled docs:

1. Agents start at `AGENTS.md` located at the package root
2. Agents follow relative links like `./docs/reference/cli.md`
3. All links are relative, enabling offline discovery inside `node_modules` without network requests

**Generated Artifacts Include:**
- `AGENTS.md` (entry point at package root)
- `docs/*.md` (relative-linked markdown documentation)

## Artifacts Skipped in Bundle Mode

Bundle mode **skips all website-only artifacts** since they are unnecessary for offline, package-based access:

- `llms.txt` (no HTTP discovery needed)
- `llms-full.txt` (no full context bundle needed)
- `search-index.json` and `search-content.json` (no search functionality needed)
- `sitemap.xml` and `sitemap.md` (no discovery aids needed)
- `robots.txt` (no SEO guidance needed)
- `agent-readability.json` (no capability declaration needed)

## Complementary Flows

These two flows are complementary and can coexist:

- A package can simultaneously publish **bundled offline docs** (via `--bundle` flag) for agents accessing `node_modules`
- The same package can provide a **hosted docs website with `/llms.txt`** for agents accessing the documentation URL

**Usage:**
- Website mode: `leadtype generate` (default)
- Bundle mode: `leadtype generate --bundle`

Both flows stem from the same MDX source, enabling a single source of truth to serve humans, HTTP agents, and offline coding agents.
