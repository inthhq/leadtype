# Cross-group Agent Flows: Hosted Website vs npm Bundle

## Overview

Leadtype supports two distinct agent flows from a single MDX source: a **hosted website flow** for HTTP-based agents and an **npm bundle flow** for coding agents working inside installed packages. The two flows complement each other — a package can publish bundled offline docs for `node_modules` *and* a hosted docs website with `llms.txt` for URL-based agents.

---

## 1. Hosted Website Flow

### Entry Point
HTTP agents start at **`/llms.txt`** — a product-level index file written at the site root. A docs-scoped companion, **`/docs/llms.txt`**, is also generated as a map for hosted websites.

### How It Works
`leadtype generate` (without `--bundle`) runs in **website mode**. It:
1. Reads MDX source pages and frontmatter.
2. Flattens MDX components into markdown.
3. Resolves the group tree.
4. Emits a full set of website and agent-readable artifacts.

Agents follow markdown links from `/llms.txt` into the markdown mirrors at `/docs/*.md`. When an agent (or browser) requests a docs page with `Accept: text/markdown` or uses a known AI user-agent header, the server serves the markdown version directly.

### Files Generated (Website Mode)
| Artifact | Purpose |
|---|---|
| `/llms.txt` | Product-level agent entry point |
| `/docs/llms.txt` | Docs-scoped agent map |
| `/llms-full.txt` | Root full-context fallback (all pages concatenated) |
| `/docs/*.md` | Markdown mirrors of every MDX page |
| `/docs/sitemap.xml` | XML sitemap |
| `/docs/sitemap.md` | Markdown sitemap |
| `/docs/robots.txt` | Robots/crawl instructions (allows `/llms.txt`) |
| `/docs/agent-readability.json` | Agent-readability metadata |
| `/docs/search-index.json` | Static BM25-style search index |
| `/docs/search-content.json` | Raw search content |

The `--json` CLI flag causes `leadtype generate` to print a JSON object listing all of these artifact paths (`llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, `agentReadabilityJson`, `sitemapXml`, `sitemapMd`, `robotsTxt`, `searchIndex`, `searchContent`).

---

## 2. npm Bundle Flow

### Entry Point
Coding agents working inside installed npm packages start at **`AGENTS.md`** — written at the **package root** — and follow **relative links** into `./docs/*.md`.

### How It Works
`leadtype generate --bundle` runs in **bundle mode**. It:
1. Reads the same MDX source.
2. Writes `AGENTS.md` at the package root.
3. Writes `docs/*.md` beneath it.
4. Uses **relative links** (e.g., `./docs/reference/cli.md`) so agents can read docs inside `node_modules` **without any network request**.

`AGENTS.md` intentionally ignores `product.agentGuidance` text, because that text is written for website URL routing — it is not meaningful in an offline, filesystem-based context.

### Files Generated (Bundle Mode)
| Artifact | Purpose |
|---|---|
| `AGENTS.md` | Package-root agent entry point with relative links |
| `docs/*.md` | Markdown docs pages with relative cross-links |

---

## 3. What Bundle Mode Skips

Bundle mode deliberately **omits all website-only artifacts** because they are meaningless without a live HTTP server:

| Skipped Artifact | Why It Is Skipped |
|---|---|
| `llms.txt` | URL-based discovery file; no URLs inside `node_modules` |
| `llms-full.txt` | Root full-context file; only useful for HTTP agents |
| `search-index.json` | Static search index; not needed for offline file reads |
| `search-content.json` | Raw search content backing the search index |
| `sitemap.xml` | XML sitemap; requires a hosted domain |
| `sitemap.md` | Markdown sitemap; same reason |
| `robots.txt` | Crawler/bot instructions; requires HTTP context |
| `agent-readability.json` | Agent-readability metadata for hosted pages |

These paths are also recognized by the `isAgentReadabilityArtifactPath` API, which ensures they are never mistakenly rewritten as missing markdown pages during site builds.

---

## Summary

| Dimension | Hosted Website Flow | npm Bundle Flow |
|---|---|---|
| **Command** | `leadtype generate` | `leadtype generate --bundle` |
| **Agent entry file** | `/llms.txt` (HTTP URL) | `AGENTS.md` (filesystem path) |
| **Link style** | Absolute URLs (`/docs/…`) | Relative paths (`./docs/…`) |
| **Network required?** | Yes | No — works inside `node_modules` |
| **Website artifacts?** | ✅ All generated | ❌ All skipped |
| **Markdown docs?** | ✅ `/docs/*.md` | ✅ `docs/*.md` |
