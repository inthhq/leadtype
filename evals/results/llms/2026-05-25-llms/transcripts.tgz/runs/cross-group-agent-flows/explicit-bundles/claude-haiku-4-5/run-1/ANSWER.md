# Cross-Group Agent Flows: Hosted vs NPM Bundle

## Overview

Leadtype supports two complementary cross-group agent flows:
1. **Hosted Website Flow** - For HTTP agents accessing docs via a website
2. **NPM Bundle Flow** - For coding agents accessing docs inside node_modules

Both flows start with the same MDX source but diverge at the artifact generation phase.

## Hosted Website Flow

### Starting Point
**File:** `/llms.txt` (at site root)

HTTP agents begin by fetching `/llms.txt`, which serves as the entry point to discover and navigate the documentation hierarchy.

### Generated Artifacts
The hosted website flow generates the following artifacts:
- `/llms.txt` - Entry point for agents
- `/llms-full.txt` - Full context bundles
- `/docs/*.md` - Markdown mirrors of the source docs
- `/docs/llms.txt` - Docs group entry point
- `docs/sitemap.xml` - XML sitemap for agent discovery
- `docs/sitemap.md` - Markdown sitemap
- `docs/robots.txt` - Robots exclusion rules for agents
- `docs/agent-readability.json` - Agent metadata
- `docs/search-index.json` - Search index data
- `docs/search-content.json` - Search content data

### Process
Agents follow HTTP-discoverable links through markdown content, making network requests to navigate the documentation structure.

---

## NPM Bundle Flow

### Starting Point
**File:** `AGENTS.md` (at package root)

Coding agents begin by reading `AGENTS.md` at the package root (inside `node_modules`), using relative links to navigate offline.

### Generated Artifacts
The bundle flow generates:
- `AGENTS.md` - Entry point for agents inside node_modules
- `docs/*.md` - Markdown documentation files

### Key Characteristics
- Uses **relative links** (e.g., `./docs/reference/cli.md`) so agents can navigate without network access
- Designed for offline operation inside installed npm packages
- No external dependencies on hosted infrastructure

---

## Skipped Artifacts in Bundle Mode

The bundle mode **skips all website-only artifacts**:
- `llms.txt` - Not needed (bundled mode doesn't use HTTP discovery)
- `llms-full.txt` - Not needed (full context bundles are for hosted discovery)
- `docs/search-index.json` - Search index not included
- `docs/search-content.json` - Search content not included
- `docs/sitemap.xml` - Sitemap not needed without HTTP
- `docs/sitemap.md` - Markdown sitemap not needed
- `docs/robots.txt` - Robot directives not needed offline
- `docs/agent-readability.json` - Agent metadata not included

---

## Complementary Design

These two flows are designed to complement each other:

- **Packages can publish both**: A package can ship bundled offline docs (`AGENTS.md` + relative links) inside the npm tarball AND expose a hosted website with `/llms.txt` for URL-based agent access
- **Same source, different outputs**: Both flows start from the same MDX source, read frontmatter, flatten MDX components, and resolve the group tree
- **Different agent types**: HTTP agents (external, API-based) use the hosted flow; coding agents (working inside your codebase) use the bundle flow

---

## Summary

| Aspect | Hosted Website | NPM Bundle |
|--------|---|---|
| **Starting File** | `/llms.txt` | `AGENTS.md` |
| **Access Method** | HTTP requests | Relative filesystem links |
| **Agent Type** | HTTP agents (external APIs) | Coding agents (inside node_modules) |
| **Network Required** | Yes | No |
| **Artifacts Included** | llms.txt, full context, search index, sitemaps, robots.txt, etc. | AGENTS.md, markdown docs only |
| **Artifacts Skipped** | None (all website artifacts included) | All website-only artifacts |
