# Cross-group agent flows: hosted website vs npm package bundle

Leadtype emits two different sets of artifacts from one MDX source, and each is meant for a different kind of agent. The hosted website flow targets HTTP agents that discover docs over the network, while the npm bundle flow targets coding agents that read docs from inside an installed `node_modules` package.

## Starting files

| Flow | Entry file | How the agent navigates |
| --- | --- | --- |
| Hosted website | `/llms.txt` at the site root | Follows absolute markdown links to `/docs/*.md` pages, with the server returning markdown when `Accept: text/markdown` or a known AI user agent is detected. |
| npm package bundle | `AGENTS.md` at the package root | Follows **relative** links like `./docs/reference/cli.md` so docs can be read directly inside `node_modules` with no network request. |

This split is described in `docs/how-it-works.md`:

> HTTP agents start at `/llms.txt` and follow markdown links. Coding agents working inside installed npm packages start at `AGENTS.md` and follow relative `docs/*.md` links.

## What the website flow generates

Per `docs/quickstart.md` and `docs/build/connect-docs-site.md`, `leadtype generate` in website mode writes:

- `/llms.txt` and `/docs/llms.txt` (entry index for agents)
- `/llms-full.txt` (and the per-group `docs/llms-full/*.txt` bundles)
- Markdown mirrors under `/docs/*.md`
- `docs/sitemap.xml` and `docs/sitemap.md`
- `docs/robots.txt` (which should allow `/llms.txt`)
- `docs/agent-readability.json`
- `docs/search-index.json` and `docs/search-content.json`

These are served as static artifacts alongside content negotiation that returns markdown for AI agents.

## What the bundle flow generates

Per `docs/package-docs/bundle.md`, `leadtype generate --bundle` writes only:

- `AGENTS.md` at the package root
- `docs/*.md` beneath the package root

Links inside `AGENTS.md` are relative (`./docs/reference/cli.md`) so agents can resolve them from `node_modules/<pkg>/` without any HTTP.

## Website artifacts the bundle flow skips

Bundle mode deliberately omits everything that only makes sense for a hosted site. From `docs/package-docs/bundle.md`:

> Bundle mode skips website-only artifacts: `llms.txt`, `llms-full.txt`, search JSON, sitemap files, `robots.txt`, and `agent-readability.json`.

Concretely, the bundle does **not** include:

- `llms.txt` / `docs/llms.txt`
- `llms-full.txt` (and the `docs/llms-full/*.txt` per-group bundles)
- `docs/sitemap.xml` and `docs/sitemap.md`
- `docs/robots.txt`
- `docs/agent-readability.json`
- `docs/search-index.json` and `docs/search-content.json`

It keeps only the offline-readable pair: a root `AGENTS.md` index and the `docs/*.md` content it links to.

## How they complement each other

The two flows are not exclusive. As `docs/how-it-works.md` notes, a single package can ship bundled offline docs for `node_modules` consumers **and** publish a hosted docs website with `/llms.txt` for URL-based agents — same MDX source, two delivery channels tuned to how each agent discovers content.
