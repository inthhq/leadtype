# Cross-group agent flows: hosted website vs npm bundle

Leadtype supports two complementary agent flows from the same MDX source:

| Flow | Who uses it | Starting file | Link style / access | Generated docs payload |
|---|---|---|---|---|
| Hosted website mode | HTTP/URL-based agents | `/llms.txt` at the site root | Agents fetch over HTTP, then follow markdown links. Docs pages can be served as markdown when `Accept: text/markdown` is sent or when a known AI user agent requests a docs page. | Markdown mirrors under `/docs/*.md`, plus website discovery and search artifacts. |
| npm package bundle mode | Coding agents inside an installed package | `AGENTS.md` at the package root | Agents read files locally inside `node_modules`. `AGENTS.md` uses relative links such as `./docs/reference/cli.md`, so no network request is needed. | `AGENTS.md` and `docs/*.md` bundled into the npm tarball. |

## Hosted website flow

Website mode is for a docs site that exposes HTTP-discoverable agent files. The key entrypoint is:

- `/llms.txt`

From there, agents follow links to markdown mirrors such as:

- `/docs/*.md`

The hosted build also keeps website-oriented artifacts available as static files, including the root full-context file, sitemap files, robots file, search JSON, and agent-readability metadata.

## npm package bundle flow

Bundle mode is enabled with:

```sh
leadtype generate --bundle
```

It is intended for publishing version-matched docs inside an npm package. The key entrypoint is:

- `AGENTS.md`

From there, coding agents follow relative local links into:

- `docs/*.md`

This lets an agent inspect the docs that shipped with the installed package version, even offline and without hitting the hosted docs site.

## Website artifacts skipped by bundle mode

Bundle mode does **not** emit the website-only artifacts. It skips:

- `llms.txt` files, including the hosted `/llms.txt` discovery map
- `llms-full.txt`
- search JSON files, such as `search-index.json` and `search-content.json`
- sitemap files, such as `sitemap.xml` and `sitemap.md`
- `robots.txt`
- `agent-readability.json`

So, in short: hosted agents start at `/llms.txt` and use HTTP-discoverable markdown plus website metadata; npm-bundled coding agents start at `AGENTS.md` and use only local relative markdown docs inside the package.