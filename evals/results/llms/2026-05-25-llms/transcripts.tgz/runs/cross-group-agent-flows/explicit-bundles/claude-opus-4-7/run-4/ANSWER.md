# Cross-group agent flows: hosted vs npm bundle

Leadtype's docs pipeline emits two distinct agent-facing flows from one MDX source. The hosted website flow targets HTTP-based agents, while the npm bundle flow targets coding agents reading files inside `node_modules`. The two flows complement each other — a single package can ship both.

## Where each flow starts

### Hosted website flow

- **Entry point:** `/llms.txt` at the site root (HTTP-discoverable).
- **How agents traverse it:** HTTP agents fetch `/llms.txt` and follow markdown links to `/docs/*.md` mirrors. Content negotiation also kicks in — the site serves markdown when `Accept: text/markdown` is requested or when a known AI user agent hits a docs page.
- **Source docs describing it:**
  - `docs/build/connect-docs-site.md` (Connect a docs site)
  - `docs/quickstart.md` and `docs/how-it-works.md`

### npm bundle flow

- **Entry point:** `AGENTS.md` at the **package root** inside the published npm tarball.
- **How agents traverse it:** `AGENTS.md` uses **relative links** like `./docs/reference/cli.md`, so a coding agent reads docs directly from `node_modules/<package>/...` with **no network request**.
- **Source docs describing it:**
  - `docs/package-docs/bundle.md` (Bundle docs into a package)
  - `docs/quickstart.md` and `docs/how-it-works.md`

## Build command difference

| Flow | Command | Root entry file |
| --- | --- | --- |
| Hosted website | `leadtype generate` (default / website mode) | `/llms.txt` |
| npm bundle | `leadtype generate --bundle` | `AGENTS.md` |

## Artifacts produced by website mode

According to `docs/quickstart.md`, website mode writes the full set of HTTP-discoverable agent artifacts:

- `/llms.txt`
- `/docs/llms.txt`
- `/llms-full.txt`
- Markdown mirrors under `/docs/*.md`
- `docs/sitemap.xml`
- `docs/sitemap.md`
- `docs/robots.txt`
- `docs/agent-readability.json`
- `docs/search-index.json`
- `docs/search-content.json`

## Artifacts produced by bundle mode

Bundle mode (`leadtype generate --bundle`) writes only the offline-friendly subset:

- `AGENTS.md` at the package root
- `docs/*.md` beneath it (version-matched to the package)

## Website artifacts skipped by bundle mode

Per `docs/package-docs/bundle.md`, bundle mode **explicitly skips these website-only artifacts**:

- `llms.txt`
- `llms-full.txt`
- Search JSON (`search-index.json`, `search-content.json`)
- Sitemap files (`sitemap.xml`, `sitemap.md`)
- `robots.txt`
- `agent-readability.json`

These are skipped because they only make sense for HTTP discovery — an agent reading a tarball from `node_modules` does not need a sitemap, a robots policy, a search index, or a top-level `llms.txt` table of contents. The relative-link `AGENTS.md` replaces `llms.txt` as the entry-point index for the offline case.

## Why both flows coexist

From `docs/how-it-works.md`: HTTP agents start at `/llms.txt`; coding agents in installed npm packages start at `AGENTS.md`. The same MDX source feeds both, so a package can publish bundled offline docs for `node_modules` **and** a hosted docs website with `llms.txt` for URL-based agents — without authoring docs twice.
