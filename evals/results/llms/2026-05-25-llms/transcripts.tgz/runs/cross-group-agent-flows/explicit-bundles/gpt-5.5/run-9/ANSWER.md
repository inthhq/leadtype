# Hosted vs npm bundle agent flows

Leadtype supports two complementary agent flows from the same MDX source.

## Hosted website flow

- **Agent entry point:** `/llms.txt` at the site root.
- **How agents continue:** HTTP agents follow the markdown links from `/llms.txt` into generated markdown mirrors under `/docs/*.md`. A hosted build also provides a docs-scoped `/docs/llms.txt` map and a root `/llms-full.txt` full-context fallback containing all generated markdown docs pages.
- **Cross-group behavior:** Groups organize sections in `llms.txt`, navigation, search metadata, and routing hints. They are not separate per-group full-context bundles by default; `/llms-full.txt` contains all generated markdown pages, so agents can move across groups through the published maps and links.

Typical hosted artifacts include:

- `/llms.txt`
- `/docs/llms.txt`
- `/llms-full.txt`
- markdown mirrors under `/docs/*.md`
- sitemap files such as `docs/sitemap.xml` and `docs/sitemap.md`
- `robots.txt`
- `agent-readability.json`
- search JSON such as `docs/search-index.json` and `docs/search-content.json`

## npm package bundle flow

- **Agent entry point:** `AGENTS.md` at the package root.
- **How agents continue:** Coding agents working inside `node_modules` follow relative links from `AGENTS.md`, such as `./docs/reference/cli.md`, into bundled `docs/*.md` files. This avoids requiring a network request and keeps docs version-matched with the installed package.
- **Cross-group behavior:** The same group metadata is still used for `AGENTS.md` grouping, but the package flow is rooted in local relative files rather than hosted URLs.

## Website artifacts skipped by bundle mode

When using `leadtype generate --bundle`, Leadtype writes only the package-oriented docs entry point and markdown docs: `AGENTS.md` plus `docs/*.md`. Bundle mode skips hosted website artifacts, including:

- `llms.txt` / hosted llms maps such as `/docs/llms.txt`
- `llms-full.txt`
- search JSON
- sitemap files
- `robots.txt`
- `agent-readability.json`
