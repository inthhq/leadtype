# Cross-group agent flows: hosted website vs npm bundle

Leadtype's docs pipeline emits two complementary sets of agent-readable artifacts from the same MDX source: a hosted **website** flow (for HTTP/URL-based agents) and an **npm bundle** flow (for coding agents working inside `node_modules`). These flows are described across the Get Started, Build, and Ship Package Docs groups on the docs site.

## Where each flow starts

### Hosted website flow
- **Entry point:** `/llms.txt` at the site root.
- HTTP agents fetch `/llms.txt`, then follow markdown links it advertises (e.g. the full-context bundles under `/docs/llms-full/*.txt`, and per-page mirrors under `/docs/*.md`).
- Per Build docs, sites should also serve markdown when the `Accept: text/markdown` header is set or when a known AI user agent requests a docs page.
- Source: `docs/how-it-works.md` ("HTTP agents start at /llms.txt and follow markdown links") and `docs/build/connect-docs-site.md`.

### npm package bundle flow
- **Entry point:** `AGENTS.md` at the package root (inside the published tarball).
- Produced by running `leadtype generate --bundle`.
- `AGENTS.md` uses **relative links** like `./docs/reference/cli.md`, so an agent reading files directly from `node_modules/<pkg>/` can follow them without any network request.
- Source: `docs/how-it-works.md` ("Coding agents working inside installed npm packages start at AGENTS.md and follow relative docs/*.md links") and `docs/package-docs/bundle.md`.

## What each flow generates

### Website mode (`leadtype generate`)
From `docs/quickstart.md`, website mode writes:
- `/llms.txt`
- `/docs/llms.txt`
- `/llms-full.txt`
- Markdown mirrors under `/docs/*.md`
- `docs/sitemap.xml`
- `docs/sitemap.md`
- `docs/robots.txt`
- `docs/agent-readability.json`
- `docs/search-index.json`
- `docs/search-content.json`

The Build group adds that `/llms.txt`, `/llms-full.txt`, sitemap files, `robots.txt`, search JSON, and `agent-readability.json` should be kept as static artifacts.

### Bundle mode (`leadtype generate --bundle`)
From `docs/package-docs/bundle.md`, bundle mode writes only:
- `AGENTS.md` at the package root
- `docs/*.md` beneath it (with relative links)

## Website artifacts that bundle mode skips

`docs/package-docs/bundle.md` lists the website-only artifacts that bundle mode **does not** emit:

| Artifact | Purpose (website mode) | In bundle? |
|---|---|---|
| `llms.txt` | HTTP entry point for agents | ❌ skipped |
| `llms-full.txt` | Aggregated full-context bundle | ❌ skipped |
| `search-index.json` (search JSON) | Site search index | ❌ skipped |
| `sitemap.xml` / `sitemap.md` | Sitemap files | ❌ skipped |
| `robots.txt` | Crawler rules, allows `/llms.txt` | ❌ skipped |
| `agent-readability.json` | Agent-readability metadata | ❌ skipped |

Bundle mode keeps just `AGENTS.md` + `docs/*.md` because none of the skipped artifacts make sense inside `node_modules` — there is no host serving HTTP, no crawler to obey `robots.txt`, no search runtime, and `AGENTS.md` itself replaces `/llms.txt` as the entry point.

## Why both exist

Per `docs/how-it-works.md`, the two flows are **complementary**: a single package can simultaneously publish bundled offline docs (for agents reading `node_modules`) and a hosted docs website (with `/llms.txt` and markdown mirrors for URL-based agents). Both are generated from the same MDX source by the Leadtype pipeline.
