# Cross-group agent flows: hosted website vs npm bundle

Leadtype produces two distinct agent-facing deliverables from the same MDX source. The hosted **website flow** is documented in `docs/build/connect-docs-site.md` (summarized in `docs/llms-full/build.txt`); the **npm bundle flow** is documented in `docs/package-docs/bundle.md` (summarized in `docs/llms-full/package-docs.txt`).

## Where each flow starts

### Hosted website flow
Agents discover the docs over HTTP. The flow is rooted at:

- **`/llms.txt`** — the site-root entry file that lists the available full-context bundles. This is the discovery starting point for an agent visiting the hosted site.
- Linked from `/llms.txt`, the per-group full-context bundles live under **`/docs/llms-full/*.txt`** (e.g. `get-started.txt`, `authoring.txt`, `build.txt`, `package-docs.txt`, `reference.txt`).
- Individual pages are served as markdown mirrors under **`/docs/*.md`**, returned when a client sends `Accept: text/markdown` or a recognized AI user agent.

### npm package bundle flow
Agents read docs locally from `node_modules` without making a network request. The flow is rooted at:

- **`AGENTS.md`** at the package root, written by `leadtype generate --bundle`. This is the entry file an agent opens after installing the package.
- `AGENTS.md` uses **relative links** like `./docs/reference/cli.md` that point at the version-matched markdown shipped inside the tarball under **`docs/*.md`**.

## Website artifacts that bundle mode skips

Bundle mode is intentionally narrower than the hosted site. According to `docs/package-docs/bundle.md`, bundle mode **skips these website-only artifacts**:

- `llms.txt`
- `llms-full.txt` (and the per-group `docs/llms-full/*.txt` bundles it represents)
- search JSON
- sitemap files (e.g. `/docs/sitemap.xml`)
- `robots.txt`
- `agent-readability.json`

Those files only make sense for a hosted site because they exist to be fetched over HTTP, crawled, or indexed. Inside an npm tarball there is no crawler, no `Accept` header negotiation, and no search index to serve — the agent already has the filesystem — so the bundle keeps only `AGENTS.md` plus the `docs/*.md` it links to.

## Summary table

| Aspect | Hosted website flow | npm bundle flow |
|---|---|---|
| Entry file | `/llms.txt` | `AGENTS.md` at package root |
| Per-group context | `/docs/llms-full/*.txt` | (none — agent reads markdown directly) |
| Page format | `/docs/*.md` served via content negotiation | `./docs/*.md` via relative links |
| Transport | HTTP (with `Accept: text/markdown` or AI UA detection) | Local filesystem inside `node_modules` |
| Discovery extras | `llms.txt`, `llms-full.txt`, sitemap, `robots.txt`, search JSON, `agent-readability.json` | **Skipped** |
| Verification | Fetch `/llms.txt`, fetch a `.md` page with `Accept: text/markdown`, check `/docs/sitemap.xml`, confirm `/robots.txt` allows `/llms.txt` | Open `AGENTS.md` and follow relative links |

In short: the website flow optimizes for **HTTP discovery** and starts at `/llms.txt`, while the bundle flow optimizes for **offline, version-matched reads** and starts at `AGENTS.md` — dropping every artifact whose only purpose is being fetched, crawled, or indexed over the network.
