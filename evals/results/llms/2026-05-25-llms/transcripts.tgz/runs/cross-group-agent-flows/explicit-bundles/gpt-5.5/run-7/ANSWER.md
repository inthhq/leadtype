# Cross-group agent flows: hosted website vs npm bundle

Leadtype supports two complementary agent-doc flows from the same MDX source.

## Hosted website flow

- **Mode:** normal website generation (`leadtype generate`).
- **Agent starting file:** `/llms.txt` at the hosted site root.
- **How agents continue:** HTTP agents follow the markdown links from `/llms.txt`. Docs pages should serve markdown when the request has `Accept: text/markdown` or comes from a known AI user agent.
- **Website artifacts produced:** the hosted site can expose `/llms.txt`, `/docs/llms.txt`, `/llms-full.txt`, markdown mirrors under `/docs/*.md`, sitemap files, `robots.txt`, `agent-readability.json`, and search JSON.

## npm package bundle flow

- **Mode:** package bundle generation (`leadtype generate --bundle`).
- **Agent starting file:** `AGENTS.md` at the npm package root, inside the published tarball / installed `node_modules` package.
- **How agents continue:** coding agents follow relative links from `AGENTS.md`, such as `./docs/reference/cli.md`, to markdown files bundled under `docs/*.md`. This works offline and does not require a network request.

## What bundle mode skips

Bundle mode writes only the package-oriented entrypoint and markdown docs: `AGENTS.md` plus `docs/*.md`. It skips the website-only artifacts used by hosted URL-based docs, including:

- `llms.txt` / hosted llms entry files
- `llms-full.txt`
- search JSON, such as `search-index.json` and `search-content.json`
- sitemap files, such as `sitemap.xml` and `sitemap.md`
- `robots.txt`
- `agent-readability.json`

In short: hosted agents start from `/llms.txt` on the web; npm-installed coding agents start from package-root `AGENTS.md` and stay within relative, version-matched markdown files bundled in the package.
