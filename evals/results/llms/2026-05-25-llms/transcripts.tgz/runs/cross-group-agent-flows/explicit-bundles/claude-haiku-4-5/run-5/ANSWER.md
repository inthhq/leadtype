# Cross-group Agent Flows: Hosted vs NPM Bundle

## Overview
Leadtype supports two distinct agent flows for accessing documentation: one for hosted websites and one for npm package bundles. Each flow generates different starting files and artifacts optimized for their respective distribution method.

## Hosted Website Flow

### Starting File
- **`/llms.txt`** at the site root

### Flow
1. Agents fetch `/llms.txt` from the website root
2. `/llms.txt` provides index and entry points to documentation
3. Agents can fetch markdown mirrors via HTTP at `/docs/*.md`
4. Agents can access full-context bundles like `/docs/llms-full/*.txt`

### Generated Artifacts Included
- `/llms.txt` - Main entry point index
- `/llms-full.txt` - Full context bundles
- `/docs/*.md` - Markdown versions of documentation
- `/docs/sitemap.xml` - XML sitemap for discovery
- `/robots.txt` - Search engine and agent access rules
- Search JSON - Search index for queries
- `/agent-readability.json` - Agent discoverability metadata

## NPM Bundle Flow

### Starting File
- **`AGENTS.md`** at the package root (inside node_modules)

### Flow
1. Agents read `AGENTS.md` from the npm package root
2. `AGENTS.md` contains relative links like `./docs/reference/cli.md`
3. Agents access documentation offline from the package without network requests
4. All references use relative paths compatible with node_modules structure

### Generated Artifacts Included
- `AGENTS.md` - Package-root entry point
- `docs/*.md` - Markdown documentation files

## Artifacts Skipped in Bundle Mode

The npm bundle flow **deliberately skips** the following website-only artifacts:

1. **`llms.txt`** - Not needed for offline package access
2. **`llms-full.txt`** - Full-context bundles irrelevant for bundled code
3. **Search JSON** - Search functionality requires web infrastructure
4. **Sitemap files** - Used for web crawling/discovery only
5. **`robots.txt`** - Web server directive irrelevant to packages
6. **`agent-readability.json`** - HTTP-based agent discoverability metadata

## Key Differences

| Aspect | Hosted Website | NPM Bundle |
|--------|---|---|
| **Starting File** | `/llms.txt` | `AGENTS.md` |
| **Access Method** | HTTP requests | File system (node_modules) |
| **Link Style** | Absolute URLs | Relative paths |
| **Network Dependency** | Yes (HTTP requests) | No (offline) |
| **Use Case** | Web-hosted docs | Distributed npm packages |
| **Sitemap/Search** | Included | Excluded |

## Implementation Command

- **Website mode**: `leadtype generate` (default)
- **Bundle mode**: `leadtype generate --bundle`

The bundle mode creates a self-contained, network-independent documentation artifact optimized for distribution inside npm packages, while the hosted mode creates web-accessible discovery and access mechanisms.
