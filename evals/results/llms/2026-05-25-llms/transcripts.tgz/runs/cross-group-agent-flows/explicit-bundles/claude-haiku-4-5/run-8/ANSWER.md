# Cross-Group Agent Flows: Hosted vs NPM Bundle

## Overview

Leadtype processes a single MDX source to generate artifacts for two distinct agent flows: one for hosted websites and one for npm packages. These flows diverge at the entry point and artifact generation stage.

## Hosted Website Flow

### Starting File
- **Entry point**: `/llms.txt` at the site root

### Flow Description
HTTP agents start at `/llms.txt` and follow markdown links to discover and read documentation pages. The hosted website serves markdown mirrors under `/docs/*.md` that agents can fetch via HTTP requests.

### Generated Artifacts
- `/llms.txt` - Main entry point with grouped sections
- `/llms-full.txt` - Root full-context fallback containing all generated markdown pages
- `/docs/*.md` - Markdown mirrors of all documentation pages
- `/docs/sitemap.xml` - XML sitemap for agent discovery
- `/robots.txt` - Robots file (allows `/llms.txt` access)
- `search.json` - Search index for agent queries
- `agent-readability.json` - Agent readability metadata

## NPM Bundle Flow

### Starting File
- **Entry point**: `AGENTS.md` at the package root

### Flow Description
Coding agents working inside installed npm packages start at `AGENTS.md` and follow relative links (e.g., `./docs/reference/cli.md`) to read docs. This allows agents to access documentation offline directly from `node_modules` without requiring network requests.

### Generated Artifacts
- `AGENTS.md` - Package root entry point with grouped sections and relative links
- `docs/*.md` - Markdown documentation files with relative path links

## Key Differences

### Website-Only Artifacts (Skipped in Bundle Mode)
The npm bundle flow intentionally skips the following website-only artifacts:
- `llms.txt` - Not needed as AGENTS.md serves as the entry point
- `llms-full.txt` - Not needed for offline, relative-link usage
- `search.json` - Search functionality handled by the website, not npm packages
- `sitemap.xml` - Not applicable to npm package structure
- `robots.txt` - Not applicable to npm package structure
- `agent-readability.json` - Not needed for offline agents

### Link Strategy
- **Hosted**: Absolute URLs (e.g., `/docs/reference/cli.md`)
- **Bundle**: Relative links (e.g., `./docs/reference/cli.md`)

## Complementary Flows

The two flows complement each other, enabling a single documentation source to serve dual purposes:
1. **Hosted docs site** - For HTTP agents accessing documentation via URLs
2. **Offline npm package** - For coding agents reading docs inside `node_modules`

A package can publish both:
- Bundled offline docs (via `leadtype generate --bundle`) for npm usage
- A hosted docs website with `llms.txt` for URL-based agents
