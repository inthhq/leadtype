# Cross-group agent flows: hosted website vs npm bundle

The Leadtype docs pipeline produces two different agent-facing flows from the same MDX source. The "Build" group documents the hosted website flow, while the "Ship Package Docs" group documents the npm bundle flow.

## Hosted website flow (Build group)

**Starting file for agents:** `/llms.txt` at the site root.

This flow is described in `docs/build/connect-docs-site.md` (surfaced via `docs/llms-full/build.txt`). It is used when a docs site needs to expose HTTP-discoverable agent files. The build generates:

- `/llms.txt` — the entry point an agent fetches first.
- `/docs/*.md` — markdown mirrors of every docs page.
- `/llms-full.txt` — full-context aggregate bundle.
- `/docs/sitemap.xml` and other sitemap files.
- `/robots.txt` — must allow `/llms.txt`.
- Search JSON.
- `agent-readability.json`.

The server is expected to negotiate content: when `Accept: text/markdown` is sent (or a known AI user agent requests a docs page), the markdown mirror is returned instead of HTML. Verification involves fetching `/llms.txt`, fetching a docs page with `Accept: text/markdown`, checking `/docs/sitemap.xml`, and confirming `/robots.txt` allows `/llms.txt`.

## npm package bundle flow (Ship Package Docs group)

**Starting file for agents:** `AGENTS.md` at the package root (inside `node_modules/<pkg>/`).

This flow is described in `docs/package-docs/bundle.md` (surfaced via `docs/llms-full/package-docs.txt`). It is triggered by running `leadtype generate --bundle` when publishing an npm package. Bundle mode writes:

- `AGENTS.md` at the package root — the entry point.
- `docs/*.md` beneath the package root — version-matched markdown.

`AGENTS.md` uses relative links such as `./docs/reference/cli.md` so a coding agent can read the docs straight from `node_modules` without making a network request.

## Website artifacts that bundle mode skips

Per `docs/package-docs/bundle.md`, bundle mode intentionally omits the website-only artifacts. These are produced by the hosted flow but **skipped** by `--bundle`:

- `llms.txt`
- `llms-full.txt`
- Search JSON
- Sitemap files
- `robots.txt`
- `agent-readability.json`

## Side-by-side summary

| Aspect | Hosted website flow | npm bundle flow |
| --- | --- | --- |
| Source doc | `docs/build/connect-docs-site.md` | `docs/package-docs/bundle.md` |
| Trigger | Docs-site build (website mode) | `leadtype generate --bundle` |
| Agent entry point | `/llms.txt` | `AGENTS.md` at package root |
| Markdown location | `/docs/*.md` served over HTTP (content negotiation) | `./docs/*.md` inside the tarball, relative links |
| Discovery extras | `llms-full.txt`, sitemap, `robots.txt`, search JSON, `agent-readability.json` | None — these are skipped |
| Network required? | Yes — agents fetch over HTTP | No — agents read from `node_modules` |
