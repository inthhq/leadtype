# Cross-group agent flows: hosted website vs npm bundle

Leadtype supports two complementary agent flows from the same MDX docs source:

## Hosted website flow

- **Agent entry point:** `/llms.txt` at the site root.
- **How agents navigate:** HTTP agents read `/llms.txt` and follow its markdown links to generated markdown mirrors under `/docs/*.md`.
- **Hosted outputs:** website mode generates the product-level `/llms.txt`, a docs-scoped `/docs/llms.txt`, `/llms-full.txt`, markdown mirrors under `/docs/*.md`, sitemap files, robots files, search JSON, and agent-readability metadata.
- **Serving behavior:** for agent requests, the site should serve markdown when `Accept` asks for `text/markdown` or when a known AI user agent requests a docs page. Static agent artifacts such as `/llms.txt`, `/llms-full.txt`, sitemap files, `robots.txt`, search JSON, and `agent-readability.json` remain directly fetchable.

## npm package bundle flow

- **Agent entry point:** `AGENTS.md` at the package root, typically inside `node_modules` after install.
- **How agents navigate:** coding agents read `AGENTS.md` and follow relative links such as `./docs/reference/cli.md` to bundled `docs/*.md` files.
- **Bundle command/output:** `leadtype generate --bundle` writes `AGENTS.md` plus `docs/*.md` into the npm package tarball so agents can use version-matched docs without a network request.

## What bundle mode skips

Bundle mode intentionally omits website-only artifacts:

- `llms.txt`
- `llms-full.txt`
- search JSON, including files like `docs/search-index.json` and `docs/search-content.json`
- sitemap files, such as `docs/sitemap.xml` and `docs/sitemap.md`
- `robots.txt`
- `agent-readability.json`

In short: hosted agents start from `/llms.txt` over HTTP, while package-local coding agents start from `AGENTS.md` and stay within relative `docs/*.md` files bundled in the npm package.