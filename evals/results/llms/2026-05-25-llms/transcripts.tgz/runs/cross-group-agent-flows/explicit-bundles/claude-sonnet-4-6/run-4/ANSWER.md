# Cross-group Agent Flows: Hosted Website vs npm Bundle

## Overview

Leadtype supports two distinct agent flows from a single MDX source: one for **hosted websites** (HTTP-based agents) and one for **npm package bundles** (offline/coding agents). The two flows complement each other — a package can publish bundled offline docs for `node_modules` *and* maintain a hosted docs website with `llms.txt` for URL-based agents.

---

## 1. Hosted Website Flow

### Entry Point (Starting File)
HTTP agents start at **`/llms.txt`** — the product-level file generated at the site root. A docs-scoped **`/docs/llms.txt`** map is also generated for finer-grained navigation. From there, agents follow markdown links to individual docs pages (e.g., `/docs/*.md`).

### How It Works
- `leadtype generate` (without `--bundle`) writes all website artifacts.
- The pipeline reads MDX pages, resolves frontmatter and groups, flattens MDX components into markdown, and emits a full set of HTTP-discoverable files.
- For agent requests, Leadtype serves markdown when the `Accept` header asks for `text/markdown` or a known AI user agent requests a docs page.

### Artifacts Generated
| Artifact | Purpose |
|---|---|
| `/llms.txt` | Product-level agent entry point |
| `/docs/llms.txt` | Docs-scoped agent map |
| `/llms-full.txt` | Root full-context fallback (every markdown page concatenated) |
| `/docs/*.md` | Markdown mirrors of all MDX pages |
| `/docs/sitemap.xml` | XML sitemap |
| `/docs/sitemap.md` | Markdown sitemap |
| `/docs/robots.txt` | Robots file (allows `/llms.txt`) |
| `/docs/agent-readability.json` | Agent-readability metadata |
| `/docs/search-index.json` | Static search index |
| `/docs/search-content.json` | Search content payload |

### Verification
Good checks include fetching `/llms.txt`, fetching a docs page with `Accept: text/markdown`, checking `/docs/sitemap.xml`, and confirming `/robots.txt` allows `/llms.txt`.

---

## 2. npm Bundle (Package) Flow

### Entry Point (Starting File)
Coding agents working inside installed npm packages start at **`AGENTS.md`** — written at the **package root** — and follow **relative `./docs/*.md` links** from there. No network request is required; everything is resolved inside `node_modules`.

### How It Works
- `leadtype generate --bundle` writes only the offline-safe artifacts.
- `generateAgentsMd` writes `AGENTS.md` and intentionally ignores `product.agentGuidance` because that text is written for website URL routing.
- Links in `AGENTS.md` are relative (e.g., `./docs/reference/cli.md`) so they resolve correctly inside `node_modules` without a base URL.

### Artifacts Generated
| Artifact | Purpose |
|---|---|
| `AGENTS.md` | Package-root agent entry point (relative links) |
| `docs/*.md` | Markdown docs bundled beneath the package root |

---

## 3. What Bundle Mode Skips

Bundle mode explicitly **skips all website-only artifacts**. The following files are generated in hosted mode but are **absent from the npm bundle**:

| Skipped Artifact | Reason |
|---|---|
| `llms.txt` | HTTP-discovery entry point; meaningless without a base URL |
| `llms-full.txt` | Full-context HTTP fallback; not needed offline |
| `search-index.json` | Static search index; website-only feature |
| `search-content.json` | Search content payload; website-only feature |
| `sitemap.xml` | XML sitemap; HTTP crawlers only |
| `sitemap.md` | Markdown sitemap; website navigation only |
| `robots.txt` | HTTP crawler instructions; irrelevant in `node_modules` |
| `agent-readability.json` | Agent-readability metadata; website-only |

These paths are identified internally by `isAgentReadabilityArtifactPath`, which flags them so they are never rewritten as missing markdown pages.

---

## Summary

| Aspect | Hosted Website Flow | npm Bundle Flow |
|---|---|---|
| **Agent entry file** | `/llms.txt` (HTTP URL) | `AGENTS.md` (package root, relative) |
| **Link style** | Absolute URLs | Relative paths (`./docs/*.md`) |
| **Network required** | Yes | No (works inside `node_modules`) |
| **Full-context file** | `/llms-full.txt` | — (skipped) |
| **Search artifacts** | `search-index.json`, `search-content.json` | — (skipped) |
| **Sitemap/robots** | `sitemap.xml`, `sitemap.md`, `robots.txt` | — (skipped) |
| **Agent-readability** | `agent-readability.json` | — (skipped) |
| **CLI command** | `leadtype generate` | `leadtype generate --bundle` |
