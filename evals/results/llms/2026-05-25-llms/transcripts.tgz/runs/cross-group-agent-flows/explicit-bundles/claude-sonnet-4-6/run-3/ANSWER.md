# Cross-group Agent Flows: Hosted Website vs npm Bundle

## Overview

Leadtype's pipeline produces two distinct agent flows from the same MDX source:
the **hosted website flow** (default `leadtype generate`) and the
**npm package bundle flow** (`leadtype generate --bundle`).
The two flows are designed to complement each other: a package can publish
bundled offline docs for `node_modules`-based agents _and_ a hosted docs
website with `llms.txt` for URL-based agents.

---

## 1. Hosted Website Flow

### Entry-point file

HTTP agents start at **`/llms.txt`** — the product-level index at the site
root. From there they follow markdown links into the docs.
A docs-scoped companion index lives at **`/docs/llms.txt`**.

### What the flow produces

Running `leadtype generate` (website mode) writes the following artifacts:

| Artifact | Path |
|---|---|
| Product-level agent index | `/llms.txt` |
| Docs-scoped agent index | `/docs/llms.txt` |
| Root full-context fallback | `/llms-full.txt` |
| Markdown mirrors of MDX pages | `/docs/*.md` |
| XML sitemap | `/docs/sitemap.xml` |
| Markdown sitemap | `/docs/sitemap.md` |
| Robots file | `/docs/robots.txt` |
| Agent-readability metadata | `/docs/agent-readability.json` |
| Search index | `/docs/search-index.json` |
| Search content | `/docs/search-content.json` |

When `--json` is enabled, the CLI prints a JSON object whose keys are
`llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, `agentReadabilityJson`,
`sitemapXml`, `sitemapMd`, `robotsTxt`, `searchIndex`, and `searchContent`.

### How serving works

For agent requests the site serves markdown when the `Accept` header asks for
`text/markdown` or when a known AI user-agent requests a docs page.
All the artifacts listed above are kept as static files.

---

## 2. npm Package Bundle Flow

### Entry-point file

Coding agents working inside an installed npm package start at **`AGENTS.md`**
at the package root and follow **relative** links such as
`./docs/reference/cli.md` into `docs/*.md` beneath it.
All links are relative so they work inside `node_modules` without any network
request.

### What the flow produces

Running `leadtype generate --bundle` writes:

| Artifact | Path |
|---|---|
| Agent entry-point | `AGENTS.md` (package root) |
| Markdown docs pages | `docs/*.md` (relative to package root) |

`generateAgentsMd` intentionally ignores `product.agentGuidance` because that
text is written for website URL routing, which is irrelevant inside a package.

---

## 3. Website Artifacts That Bundle Mode Skips

Bundle mode deliberately omits every file that only makes sense for a hosted,
URL-addressable site:

| Skipped artifact | Reason it is website-only |
|---|---|
| `llms.txt` | HTTP discovery index; meaningless without a URL |
| `llms-full.txt` | Root full-context fallback for URL-based agents |
| `search-index.json` | Static lexical search index for the hosted site |
| `search-content.json` | Companion search content file |
| `sitemap.xml` | XML sitemap for crawlers |
| `sitemap.md` | Markdown sitemap for agents browsing the hosted site |
| `robots.txt` | Crawler-permission file; requires a hostname |
| `agent-readability.json` | Metadata about which hosted paths expose markdown |

`isAgentReadabilityArtifactPath` (in the Leadtype API) identifies exactly these
paths so the build does not mistakenly rewrite them as missing markdown pages.

---

## Summary Table

| Dimension | Hosted website flow | npm bundle flow |
|---|---|---|
| **Agent entry-point** | `/llms.txt` (absolute URL) | `AGENTS.md` (relative, in package root) |
| **Docs pages** | `/docs/*.md` (served over HTTP) | `docs/*.md` (relative links inside tarball) |
| **Full-context fallback** | `/llms-full.txt` | ✗ skipped |
| **Search JSON** | `search-index.json`, `search-content.json` | ✗ skipped |
| **Sitemap** | `sitemap.xml`, `sitemap.md` | ✗ skipped |
| **Robots.txt** | `robots.txt` | ✗ skipped |
| **Agent-readability metadata** | `agent-readability.json` | ✗ skipped |
| **Network required?** | Yes (HTTP) | No (local `node_modules`) |
| **CLI flag** | `leadtype generate` (default) | `leadtype generate --bundle` |
