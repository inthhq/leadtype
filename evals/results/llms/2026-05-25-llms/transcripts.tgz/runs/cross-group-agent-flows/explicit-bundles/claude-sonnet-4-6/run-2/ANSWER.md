# Cross-group Agent Flows: Hosted Website vs npm Bundle

## Overview

Leadtype produces two distinct agent-readable flows from the same MDX source:
1. **Hosted website flow** — for HTTP-based agents navigating a live docs site.
2. **npm bundle flow** — for coding agents working offline inside `node_modules`.

---

## 1. Hosted Website Flow

### Entry Point

HTTP agents start at **`/llms.txt`** — a product-level index file written to the site root. A docs-scoped companion, **`/docs/llms.txt`**, is also generated.

### How the Flow Works

- `leadtype generate` (no `--bundle` flag) runs in **website mode**.
- Agents fetch `/llms.txt`, discover group sections and routing hints (drawn from each page's `description` frontmatter), then follow links to **markdown mirrors** published under `/docs/*.md`.
- Servers should serve markdown when an `Accept: text/markdown` header or a known AI user-agent is present.

### Files Generated (Website Mode)

| Artifact | Path |
|---|---|
| Product-level agent index | `/llms.txt` |
| Docs-scoped agent index | `/docs/llms.txt` |
| Root full-context fallback | `/llms-full.txt` |
| Markdown mirrors | `/docs/*.md` |
| Sitemap (XML) | `/docs/sitemap.xml` |
| Sitemap (Markdown) | `/docs/sitemap.md` |
| Robots exclusion file | `/docs/robots.txt` |
| Agent readability metadata | `/docs/agent-readability.json` |
| Search index | `/docs/search-index.json` |
| Search content | `/docs/search-content.json` |

The `--json` output object includes: `llmsFullTxt`, `docsLlmsTxt`, `llmsTxt`, `agentReadabilityJson`, `sitemapXml`, `sitemapMd`, `robotsTxt`, `searchIndex`, and `searchContent`.

---

## 2. npm Bundle Flow

### Entry Point

Coding agents working inside an installed npm package start at **`AGENTS.md`** — written to the **package root** — and follow **relative links** like `./docs/reference/cli.md`.

### How the Flow Works

- `leadtype generate --bundle` runs in **bundle mode**.
- AGENTS.md uses relative paths so agents can read docs entirely **offline, inside `node_modules`**, with no network request.
- The `generateAgentsMd` function intentionally ignores `product.agentGuidance` because that text is written for website URL routing, which does not apply in a local package context.
- Markdown docs are written under **`docs/*.md`** relative to the package root.

### Files Generated (Bundle Mode)

| Artifact | Path |
|---|---|
| Coding-agent index | `AGENTS.md` (package root) |
| Markdown docs | `docs/*.md` |

---

## 3. Website Artifacts That Bundle Mode Skips

Bundle mode deliberately **omits** all website-only artifacts because they are meaningless without a hosted HTTP server:

| Skipped Artifact | Reason |
|---|---|
| `llms.txt` | URL-based agent discovery; irrelevant inside `node_modules` |
| `llms-full.txt` | Root full-context fallback for HTTP agents |
| `search-index.json` | Static search index; no runtime query path in a package |
| `search-content.json` | Search content feed; same reason |
| `sitemap.xml` | HTTP sitemap for crawlers |
| `sitemap.md` | Markdown sitemap variant |
| `robots.txt` | Crawler instructions for web servers |
| `agent-readability.json` | HTTP agent-readability metadata |

The function `isAgentReadabilityArtifactPath` identifies exactly these paths so the build system knows not to rewrite them as missing markdown pages.

---

## Summary Comparison

| Aspect | Hosted Website Flow | npm Bundle Flow |
|---|---|---|
| **Command** | `leadtype generate` | `leadtype generate --bundle` |
| **Agent entry file** | `/llms.txt` (site root) | `AGENTS.md` (package root) |
| **Link style** | Absolute URLs (`/docs/*.md`) | Relative paths (`./docs/*.md`) |
| **Network required?** | Yes (HTTP) | No (offline, inside `node_modules`) |
| **Full-context fallback** | `/llms-full.txt` | Not generated |
| **Search artifacts** | `search-index.json`, `search-content.json` | Skipped |
| **Sitemap/robots** | `sitemap.xml`, `sitemap.md`, `robots.txt` | Skipped |
| **Agent metadata** | `agent-readability.json` | Skipped |
| **Markdown docs** | `/docs/*.md` | `docs/*.md` (relative) |

The two flows are designed to **complement each other**: a package can publish bundled offline docs for node_modules consumers *and* a hosted docs website with `llms.txt` for URL-based agents, both sourced from the same MDX files.
