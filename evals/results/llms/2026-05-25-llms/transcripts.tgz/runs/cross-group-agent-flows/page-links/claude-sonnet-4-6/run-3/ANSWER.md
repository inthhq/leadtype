# Cross-group Agent Flows: Hosted Website vs npm Bundle

## Overview

Leadtype's pipeline processes the same MDX source and emits **two distinct agent-readable
flows** depending on the deployment target: a hosted website and an npm package bundle.
The two flows are designed to complement each other — a package can carry offline docs
inside `node_modules` while a hosted site exposes the same content via URL-addressable
HTTP artifacts.

---

## 1. Hosted Website Flow

### Entry point
HTTP-based agents start at **`/llms.txt`** (the site root). From there they follow
markdown links to individual docs pages.

### How the flow works
1. The build generates **`/llms.txt`** at the site root, organised into sections that
   mirror the group tree.
2. A docs-scoped **`/docs/llms.txt`** map is also generated for finer-grained navigation.
3. Every MDX source page is mirrored as a `.md` file under **`/docs/*.md`**.
4. For agent requests, the server serves markdown when the `Accept: text/markdown` header
   is present, or when a known AI user-agent requests a docs page.
5. A root **`/llms-full.txt`** is generated containing every markdown page as a single
   full-context fallback file.

### Static artifacts kept on the website
| Artifact | Purpose |
|---|---|
| `/llms.txt` | Top-level agent index / entry point |
| `/docs/llms.txt` | Docs-scoped agent map |
| `/llms-full.txt` | Single-file full-context fallback |
| `/docs/sitemap.xml` (+ other sitemap files) | Crawler/agent discoverability |
| `/robots.txt` | Crawl policy (must allow `/llms.txt`) |
| Search JSON | Static search index |
| `agent-readability.json` | Agent-readability metadata |

### Verification checklist (per docs)
- Fetch `/llms.txt` ✓  
- Fetch a docs page with `Accept: text/markdown` ✓  
- Check `/docs/sitemap.xml` ✓  
- Confirm `/robots.txt` allows `/llms.txt` ✓

---

## 2. npm Bundle Flow

### Entry point
Coding agents working inside an installed npm package start at **`AGENTS.md`** at the
**package root** (e.g. `node_modules/<pkg>/AGENTS.md`). From there they follow
**relative links** such as `./docs/reference/cli.md`.

### How the flow works
1. Run `leadtype generate --bundle` when publishing a package.
2. The generator writes **`AGENTS.md`** at the package root.
3. Individual markdown docs are written under **`docs/*.md`** inside the tarball.
4. All links in `AGENTS.md` are relative (e.g. `./docs/reference/cli.md`) so agents can
   resolve them directly from the filesystem — **no network request required**.
5. `generateAgentsMd` intentionally **ignores** `product.agentGuidance` because that
   text is authored for website URL routing and is not meaningful offline.

---

## 3. What Bundle Mode Skips (Website-Only Artifacts)

Bundle mode deliberately omits every artifact that only makes sense on a hosted website:

| Skipped Artifact | Why it's website-only |
|---|---|
| `llms.txt` | HTTP entry point; not meaningful in a local filesystem |
| `llms-full.txt` | Full-context HTTP fallback; not needed offline |
| Search JSON | Powers the hosted static search index |
| Sitemap files | For web crawlers / URL-based discoverability |
| `robots.txt` | Crawl policy for HTTP bots |
| `agent-readability.json` | Website agent-readability metadata |

The function `isAgentReadabilityArtifactPath` (in the LLM reference) identifies exactly
these paths so the build never rewrites them as missing markdown pages in either mode.

---

## 4. Side-by-Side Comparison

| Dimension | Hosted Website Flow | npm Bundle Flow |
|---|---|---|
| **Agent entry file** | `/llms.txt` (site root) | `AGENTS.md` (package root) |
| **Docs files location** | `/docs/*.md` (HTTP URLs) | `docs/*.md` (relative paths in tarball) |
| **Link style** | Absolute URL paths | Relative filesystem paths (`./docs/…`) |
| **Network required?** | Yes (HTTP) | No (local `node_modules`) |
| **Full-context fallback** | `/llms-full.txt` | Not generated |
| **Search / sitemap / robots** | Included | **Skipped** |
| **`product.agentGuidance`** | Used | Ignored |
| **Triggered by** | Normal docs build | `leadtype generate --bundle` |

---

## Sources

- `/docs/how-it-works.md`
- `/docs/build/connect-docs-site.md`
- `/docs/package-docs/bundle.md`
- `/docs/reference/llm.md`
