# Cross-group Agent Flows: Hosted Website vs npm Bundle

## Overview

Leadtype's pipeline takes one MDX source and produces two distinct agent-readable output modes: **website mode** (for hosted docs sites) and **bundle mode** (for npm packages). The two flows are complementary — a package can publish both, serving offline agents through `node_modules` and URL-based agents through the hosted site.

---

## 1. Hosted Website Flow

### Entry point for agents
HTTP agents start at **`/llms.txt`** (the site root). From there they follow markdown links to individual pages.

### How it works
- The build generates `/llms.txt` and `/docs/llms.txt` (the docs-scoped map) at the site root.
- Full context is available at `/llms-full.txt`, which contains every generated markdown docs page in one file.
- Markdown mirrors of every docs page are served under `/docs/*.md`.
- Agents are served markdown when they send `Accept: text/markdown` or when a known AI user-agent requests a docs page.

### Artifacts produced (website mode)
| Artifact | Purpose |
|---|---|
| `/llms.txt` | Product-level agent entry point; TOC with links |
| `/docs/llms.txt` | Docs-scoped map |
| `/llms-full.txt` | Root full-context fallback (all pages concatenated) |
| `/docs/*.md` | Per-page markdown mirrors |
| `docs/sitemap.xml` | Sitemap for crawlers |
| `docs/sitemap.md` | Markdown sitemap |
| `docs/robots.txt` | Allows `/llms.txt` |
| `docs/agent-readability.json` | Agent-readability metadata |
| `docs/search-index.json` | Static search index |
| `docs/search-content.json` | Search content for grounded answers |

### Key detail
`generateLlmsTxt` writes `/llms.txt` and the docs-scoped map. `generateLLMFullContextFiles` writes `/llms-full.txt`. Groups organize `llms.txt` sections, navigation, and search metadata, but are **not** published as per-group full-context files by default.

---

## 2. npm Package Bundle Flow

### Entry point for agents
Coding agents working inside installed npm packages start at **`AGENTS.md`** (written at the package root). They then follow **relative links** like `./docs/reference/cli.md` to reach individual pages — no network request needed.

### How it works
- Invoked with `leadtype generate --bundle`.
- Writes `AGENTS.md` at the package root, which uses relative links so agents can read docs inside `node_modules` entirely offline.
- Writes `docs/*.md` beneath the package root (mirroring the per-page markdown content).
- `generateAgentsMd` intentionally **ignores** `product.agentGuidance` because that text is written for website URL routing, which is irrelevant in `node_modules`.

### Artifacts produced (bundle mode)
| Artifact | Purpose |
|---|---|
| `AGENTS.md` | Package-root entry point with relative links |
| `docs/*.md` | Per-page markdown docs, accessible offline |

---

## 3. What Bundle Mode Skips

Bundle mode deliberately omits all **website-only** artifacts. These are the files identified by `isAgentReadabilityArtifactPath` as artifacts that should not be rewritten as missing markdown pages:

| Skipped Artifact | Reason skipped in bundle mode |
|---|---|
| `llms.txt` / `docs/llms.txt` | Requires a live URL to be useful; meaningless inside `node_modules` |
| `llms-full.txt` | Full-context file for HTTP agents; not needed offline |
| `docs/search-index.json` | Static search index — only relevant on a hosted site |
| `docs/search-content.json` | Search content — only relevant on a hosted site |
| `docs/sitemap.xml` | Crawler artifact — no crawlers inside `node_modules` |
| `docs/sitemap.md` | Markdown sitemap — same reason |
| `docs/robots.txt` | HTTP-level crawler policy — not applicable in a package |
| `docs/agent-readability.json` | Website agent-readability metadata — not needed offline |

---

## 4. Side-by-side Summary

| Dimension | Hosted Website Flow | npm Bundle Flow |
|---|---|---|
| **Entry file** | `/llms.txt` (site root) | `AGENTS.md` (package root) |
| **Link style** | Absolute URLs (`/docs/…`) | Relative paths (`./docs/…`) |
| **Network required?** | Yes — HTTP fetch | No — reads from `node_modules` |
| **Command** | `leadtype generate` (default) | `leadtype generate --bundle` |
| **Full-context file** | `/llms-full.txt` | ✗ skipped |
| **Search index** | ✓ included | ✗ skipped |
| **Sitemap / robots** | ✓ included | ✗ skipped |
| **agent-readability.json** | ✓ included | ✗ skipped |
| **Per-page markdown** | `/docs/*.md` | `docs/*.md` (relative) |
| **`product.agentGuidance`** | Used in `llms.txt` | Ignored (URL-routing text, irrelevant offline) |

The two flows are designed to be complementary: a project can run both so that URL-based HTTP agents use the hosted `/llms.txt` entry point while coding agents working offline in `node_modules` use the bundled `AGENTS.md` entry point.
