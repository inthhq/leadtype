# Cross-group agent flows: hosted vs npm bundle

## Overview

Leadtype's pipeline takes one MDX source and emits two distinct agent-readable flows: a **hosted website flow** (HTTP-discoverable) and an **npm bundle flow** (offline, inside `node_modules`). The two flows are designed to complement each other — a package can ship both.

---

## 1. Hosted Website Flow

### Entry point / starting file
HTTP agents start at **`/llms.txt`** (at the site root).

- `generateLlmsTxt` writes both a product-level `/llms.txt` and a docs-scoped `/docs/llms.txt` map.
- From `/llms.txt`, agents follow **markdown links** to individual pages served under `/docs/*.md`.
- Agents may also request docs pages directly using the `Accept: text/markdown` header (or via a known AI user-agent), and the server returns the markdown mirror of that page.

### Artifacts produced (static files kept at the web root)
| Artifact | Purpose |
|---|---|
| `/llms.txt` | Top-level agent entry point; groups organize navigation sections |
| `/docs/llms.txt` | Docs-scoped map |
| `/llms-full.txt` | Root full-context fallback — every generated markdown page in one file |
| `/docs/*.md` | Markdown mirrors of each docs page |
| `/docs/sitemap.xml` (and other sitemap files) | Crawlability |
| `/robots.txt` | Signals that `/llms.txt` is allowed |
| Search JSON | Static search index |
| `agent-readability.json` | Agent-readability metadata |

### How the build works
The hosted build runs `leadtype generate` (website mode). It starts from MDX source pages, reads frontmatter, flattens MDX components into markdown, resolves the group tree, and emits all of the artifacts above. `isAgentReadabilityArtifactPath` protects these static artifacts from being rewritten as missing markdown pages.

---

## 2. npm Bundle Flow

### Entry point / starting file
Coding agents working inside an installed npm package start at **`AGENTS.md`** (written at the **package root**).

- `generateAgentsMd` writes `AGENTS.md` with **relative links** (e.g., `./docs/reference/cli.md`) so agents can read docs inside `node_modules` **without any network request**.
- From `AGENTS.md`, agents follow those relative links to `docs/*.md` files that are included in the tarball.

### How the build works
The npm bundle flow is triggered with **`leadtype generate --bundle`**. It writes:
- `AGENTS.md` at the package root
- `docs/*.md` beneath it

> Note: `generateAgentsMd` intentionally **ignores** `product.agentGuidance` because that field is written for website URL routing — it is not meaningful in an offline, relative-path context.

---

## 3. What Bundle Mode Skips

Bundle mode deliberately **omits all website-only artifacts** because they are HTTP/URL-centric and have no meaning inside a local `node_modules` tree:

| Skipped Artifact | Why it's website-only |
|---|---|
| `llms.txt` | HTTP entry point for URL-based agents |
| `llms-full.txt` | Full-context HTTP fallback file |
| Search JSON | Powers hosted static search |
| Sitemap files | For web crawlers |
| `robots.txt` | Web-crawl permissions |
| `agent-readability.json` | Hosted agent-readability metadata |

---

## 4. Side-by-side Comparison

| Dimension | Hosted Website Flow | npm Bundle Flow |
|---|---|---|
| **Trigger** | `leadtype generate` (website mode) | `leadtype generate --bundle` |
| **Agent entry file** | `/llms.txt` (site root) | `AGENTS.md` (package root) |
| **Link style** | Absolute URLs (`/docs/reference/cli.md`) | Relative paths (`./docs/reference/cli.md`) |
| **Network required?** | Yes — HTTP fetches | No — reads from `node_modules` |
| **Full-context fallback** | `/llms-full.txt` | Not generated |
| **Search index** | Yes (search JSON) | Skipped |
| **Sitemap / robots** | Yes | Skipped |
| **agent-readability.json** | Yes | Skipped |
| **`product.agentGuidance`** | Used (URL routing hints) | Ignored |
| **Groups** | Organize `llms.txt` sections, navigation, search metadata, and `AGENTS.md` | Still organize `AGENTS.md`; not published as per-group full-context files |

---

## Sources
- [`/docs/how-it-works.md`](/docs/how-it-works.md)
- [`/docs/build/connect-docs-site.md`](/docs/build/connect-docs-site.md)
- [`/docs/package-docs/bundle.md`](/docs/package-docs/bundle.md)
- [`/docs/reference/llm.md`](/docs/reference/llm.md)
