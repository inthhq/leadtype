# Cross-group agent flows: hosted website vs npm bundle

Leadtype supports two complementary agent flows:

## Hosted website flow

- **Starting file:** `/llms.txt` at the website root.
- **How agents navigate:** HTTP/URL-based agents read `/llms.txt`, then follow its markdown links to generated page-level markdown mirrors such as `/docs/*.md`.
- **Website artifacts:** Website mode is meant for a hosted docs site and can emit `/llms.txt`, `/docs/llms.txt`, `/llms-full.txt`, markdown mirrors under `/docs/*.md`, sitemap files, robots.txt, search JSON, and `agent-readability.json`.
- **Serving behavior:** The site should serve markdown when `Accept` asks for `text/markdown` or when a known AI user agent requests a docs page.

## npm package bundle flow

- **Starting file:** `AGENTS.md` at the npm package root.
- **How agents navigate:** Coding agents working inside an installed package, such as under `node_modules`, read `AGENTS.md` and follow relative links like `./docs/reference/cli.md` to bundled markdown docs.
- **Generated files:** `leadtype generate --bundle` writes `AGENTS.md` plus `docs/*.md` inside the package, so agents can use version-matched docs without a network request.

## Website artifacts skipped by bundle mode

Bundle mode skips website-only artifacts, specifically:

- `llms.txt`
- `llms-full.txt`
- search JSON
- sitemap files
- `robots.txt`
- `agent-readability.json`

So the key difference is discovery context: hosted docs are discovered from the site-root `/llms.txt`, while npm-bundled docs are discovered from package-root `AGENTS.md` with relative links for offline use.