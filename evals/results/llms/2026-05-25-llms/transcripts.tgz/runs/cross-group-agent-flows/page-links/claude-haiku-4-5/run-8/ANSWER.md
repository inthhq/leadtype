# Cross-group agent flows: hosted vs npm bundle

## Overview

The Leadtype docs pipeline supports two complementary agent flows:

1. **Hosted Website Flow** - HTTP agents accessing a live website
2. **NPM Bundle Flow** - Coding agents accessing offline docs inside node_modules

## Hosted Website Flow (HTTP Agents)

**Starting Point:** `/llms.txt`

HTTP agents (web-based LLMs) start at the site root `/llms.txt` and follow markdown links to navigate the documentation. This flow generates website-specific artifacts designed for URL-based discovery.

**Key Files Generated:**
- `/llms.txt` - Product-level entry point for HTTP agents
- `/docs/llms.txt` - Docs-scoped map for hosted websites
- `/llms-full.txt` - Root file containing every generated markdown docs page
- `/docs/*.md` - Markdown mirrors of all documentation pages
- `sitemap.xml` - XML sitemaps for search discovery
- `robots.txt` - Robot directives for the domain
- `search.json` - Static search index
- `agent-readability.json` - Agent readability metadata

## NPM Bundle Flow (Coding Agents)

**Starting Point:** `AGENTS.md`

Coding agents working inside installed npm packages start at `AGENTS.md` in the package root and follow relative links like `./docs/reference/cli.md` to navigate the bundled documentation without requiring network requests.

**Key Files Generated:**
- `AGENTS.md` - Package-root entry point with relative links
- `docs/*.md` - Markdown docs organized with relative path references

## Website Artifacts Skipped in Bundle Mode

When using `leadtype generate --bundle`, the following website-only artifacts are **not generated**:

1. **llms.txt** - Product-level HTTP entry point
2. **llms-full.txt** - Full-context root file for web access
3. **search.json** - Static search index for websites
4. **Sitemap files** - XML sitemaps (sitemap.xml, etc.)
5. **robots.txt** - Robot directives for web crawlers
6. **agent-readability.json** - Agent readability metadata

## Key Differences

| Aspect | Hosted Flow | Bundle Flow |
|--------|-------------|------------|
| **Starting File** | `/llms.txt` | `AGENTS.md` |
| **Link Style** | Absolute URLs (e.g., `/docs/reference/cli.md`) | Relative paths (e.g., `./docs/reference/cli.md`) |
| **Network Requirements** | Requires HTTP requests | Fully offline (node_modules) |
| **Use Case** | HTTP agents, web-based LLMs | Installed npm packages |
| **Entry Point Logic** | Ignores `product.agentGuidance` | Intentionally ignores `product.agentGuidance` (written for website routing) |
| **Search Artifacts** | Included | Not generated |
| **Web Discovery** | Full sitemap/robots support | Not applicable |

## Complementary Nature

Both flows serve the same MDX source and generate group-organized markdown. The two flows complement each other—a package can simultaneously publish bundled offline docs for node_modules and a hosted docs website with llms.txt for URL-based agents.
