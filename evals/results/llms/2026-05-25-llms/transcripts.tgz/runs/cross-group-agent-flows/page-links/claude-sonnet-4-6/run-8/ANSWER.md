# Cross-group Agent Flows: Hosted Website vs npm Bundle

## Overview

Leadtype produces artifacts for two distinct agent flows from the same MDX source. The two flows complement each other: a hosted docs site serves URL-based (HTTP) agents, while an npm package serves coding agents working offline inside `node_modules`.

---

## 1. Hosted Website Flow

### Entry Point
HTTP agents start at **`/llms.txt`** at the site root.

### How it works
- `generateLlmsTxt` writes both the product-level `/llms.txt` and a docs-scoped `/docs/llms.txt` map.
- From `/llms.txt`, agents follow **markdown links** to pages served under `/docs/*.md`.
- When an AI user agent (or a request with `Accept: text/markdown`) hits a docs page, the server returns markdown.
- A root full-context fallback file **`/llms-full.txt`** (written by `generateLLMFullContextFiles`) contains every generated markdown docs page in one file, so agents can load the entire corpus in a single request.

### Static Artifacts Generated (website mode)
The `--json` output from `leadtype generate` in website mode includes:

| Artifact | Path |
|---|---|
| Top-level agent index | `/llms.txt` |
| Docs-scoped agent index | `/docs/llms.txt` |
| Full-context bundle | `/llms-full.txt` |
| Agent-readability config | `/agent-readability.json` |
| XML sitemap | `/docs/sitemap.xml` (or similar) |
| Markdown sitemap | `/docs/sitemap.md` (or similar) |
| Robots rules | `/robots.txt` |
| Search index | search JSON files |

Verification checks include fetching `/llms.txt`, fetching a docs page with `Accept: text/markdown`, checking `/docs/sitemap.xml`, and confirming `/robots.txt` allows `/llms.txt`.

---

## 2. npm Package Bundle Flow

### Entry Point
Coding agents working inside an installed npm package start at **`AGENTS.md`** at the **package root**.

### How it works
- Triggered via `leadtype generate --bundle`.
- `generateAgentsMd` writes **`AGENTS.md`** at the package root.
- `AGENTS.md` uses **relative links** (e.g. `./docs/reference/cli.md`) so agents can navigate docs entirely within `node_modules` — **no network request required**.
- Agents follow those relative links to `docs/*.md` files bundled alongside the package.

> **Note:** `generateAgentsMd` intentionally ignores `product.agentGuidance` because that text is written for website URL routing, which is irrelevant in an offline bundle context.

---

## 3. What Bundle Mode Skips

Bundle mode omits all **website-only artifacts** — the files that only make sense in an HTTP/hosted context:

| Skipped Artifact | Why it's skipped |
|---|---|
| `llms.txt` | URL-discovery index; meaningless without a web server |
| `llms-full.txt` | Full HTTP-served context fallback; not needed offline |
| Search JSON | Static search index; no search server in `node_modules` |
| Sitemap files (`sitemap.xml`, `sitemap.md`) | Web crawler / agent URL maps; irrelevant offline |
| `robots.txt` | HTTP crawl directives; irrelevant offline |
| `agent-readability.json` | Website agent-routing config; irrelevant offline |

This set of paths is identified internally by `isAgentReadabilityArtifactPath`, which prevents them from being rewritten as missing markdown pages and marks them as website-only outputs that bundle mode does not produce.

---

## Summary Table

| Aspect | Hosted Website Flow | npm Bundle Flow |
|---|---|---|
| **Agent entry point** | `/llms.txt` (site root) | `AGENTS.md` (package root) |
| **Navigation style** | Absolute URL links in `/llms.txt` → `/docs/*.md` | Relative links in `AGENTS.md` → `./docs/*.md` |
| **Network required?** | Yes — HTTP requests | No — all files are local in `node_modules` |
| **Full-context file** | `/llms-full.txt` (entire corpus in one HTTP fetch) | Not generated |
| **CLI flag** | `leadtype generate` (default / website mode) | `leadtype generate --bundle` |
| **Skipped artifacts** | *(none — all artifacts generated)* | `llms.txt`, `llms-full.txt`, search JSON, sitemaps, `robots.txt`, `agent-readability.json` |
