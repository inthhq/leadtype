# Cross-Group Agent Flows: Hosted vs NPM Bundle

## Overview

Leadtype supports two complementary agent workflows for accessing documentation: a hosted website flow and an npm package bundle flow. Each serves different use cases and agent types.

## Hosted Website Flow

**Starting Point:** `/llms.txt`

The hosted website flow is designed for HTTP agents that discover documentation through network requests.

### Artifacts Generated:
- `/llms.txt` - The root entry point for agents
- `/llms-full.txt` - Full-context fallback document
- `/docs/*.md` - Markdown mirrors of all documentation pages
- `/docs/sitemap.xml` - Sitemap for agent discovery
- `robots.txt` - Robot permissions (allows /llms.txt)
- `search.json` - Static search index
- `agent-readability.json` - Agent readability metadata
- `AGENTS.md` - Agent discovery file

**Agent Pattern:** HTTP agents start at `/llms.txt` and follow markdown links to discover additional pages.

## NPM Bundle Flow

**Starting Point:** `AGENTS.md` (at package root)

The bundle flow is designed for coding agents working inside installed npm packages in `node_modules`.

### Artifacts Generated:
- `AGENTS.md` - Entry point at package root using relative links
- `docs/*.md` - Markdown documentation files beneath the package root

**Agent Pattern:** Coding agents start at `AGENTS.md` and follow relative links like `./docs/reference/cli.md` to read docs without network requests.

## Key Differences

| Aspect | Hosted (Website Mode) | Bundle (npm Mode) |
|--------|----------------------|-------------------|
| **Entry Point** | `/llms.txt` (absolute URL) | `AGENTS.md` (relative path) |
| **Agent Type** | HTTP-based agents | Offline/local agents in node_modules |
| **Link Style** | Absolute URLs | Relative file paths |
| **Network Required** | Yes | No |

## Artifacts Skipped in Bundle Mode

Bundle mode specifically skips all website-only artifacts:

1. **llms.txt** - HTTP entry point not needed offline
2. **llms-full.txt** - Full-context fallback for HTTP
3. **search.json** - Search index for websites
4. **sitemap files** (e.g., `/docs/sitemap.xml`) - For web discovery
5. **robots.txt** - Web crawler permissions
6. **agent-readability.json** - Website agent metadata

These artifacts are exclusively relevant to hosted websites and are unnecessary when docs are bundled inside npm packages.

## Complementary Approach

A single MDX source can serve both flows:
- **Hosted docs site:** Uses website mode to generate `/llms.txt` and HTTP-discoverable artifacts
- **npm package:** Uses bundle mode to generate `AGENTS.md` and offline docs with relative links

This allows the same source documentation to work for URL-based HTTP agents accessing a website and for coding agents working offline inside installed packages.
