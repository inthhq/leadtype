# Cross-group agent flows: hosted website vs npm bundle

Leadtype's docs pipeline turns one MDX source into two distinct agent-facing deliveries. The "Build" group covers the hosted website flow; the "Ship Package Docs" group covers the npm bundle flow. They start from different entry files and produce different artifact sets.

## Hosted website flow

**Source docs:** `docs/build/connect-docs-site.md` (group: Build) and `docs/reference/llm.md` (group: Reference).

**Entry file agents start from:** `/llms.txt` at the site root. From there, agents follow page-level markdown links such as `/docs/reference/cli.md`, optionally falling back to the root full-context file `/llms-full.txt`. The docs-scoped map `/docs/llms.txt` provides a docs-only index.

**How the build is wired:**
- The site generates `/llms.txt` at the root and markdown mirrors under `/docs/*.md`.
- Servers return markdown when `Accept: text/markdown` is requested, or when a known AI user agent requests a docs page.
- Per `docs/reference/llm.md`, `generateLlmsTxt` writes both the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` map. `generateLLMFullContextFiles` writes the single root `/llms-full.txt` containing every generated markdown page.

**Static artifacts kept at the web root (website-only):**
- `/llms.txt`
- `/llms-full.txt`
- sitemap files (e.g. `/docs/sitemap.xml`)
- `/robots.txt` (which must allow `/llms.txt`)
- search JSON
- `agent-readability.json`

`isAgentReadabilityArtifactPath` recognizes exactly this set so the website does not rewrite them as missing markdown pages.

**Verification checks (from `connect-docs-site.md`):** fetch `/llms.txt`, fetch a docs page with `Accept: text/markdown`, check `/docs/sitemap.xml`, and confirm `/robots.txt` allows `/llms.txt`.

## npm package bundle flow

**Source doc:** `docs/package-docs/bundle.md` (group: Ship Package Docs), with the API described in `docs/reference/llm.md`.

**Entry file agents start from:** `AGENTS.md` at the package root, shipped inside the npm tarball. Agents then follow relative links like `./docs/reference/cli.md` to read markdown directly from `node_modules` — no network request required.

**How the build is wired:**
- Invoked via `leadtype generate --bundle`.
- Writes `AGENTS.md` at the package root and `docs/*.md` beneath it.
- `generateAgentsMd` produces `AGENTS.md` and intentionally ignores `product.agentGuidance`, because that text is written for website URL routing and would be wrong inside an offline tarball.

## What bundle mode skips

Bundle mode is offline-first, so it omits the website-only artifacts that only make sense behind an HTTP origin. Per `docs/package-docs/bundle.md`, bundle mode skips:

- `llms.txt`
- `llms-full.txt`
- search JSON
- sitemap files
- `robots.txt`
- `agent-readability.json`

This list lines up exactly with the website-only artifact set called out in `connect-docs-site.md` and recognized by `isAgentReadabilityArtifactPath` in `docs/reference/llm.md`.

## Side-by-side summary

| Aspect | Hosted website flow | npm bundle flow |
| --- | --- | --- |
| Source group | Build (+ Reference) | Ship Package Docs (+ Reference) |
| Driving doc | `docs/build/connect-docs-site.md` | `docs/package-docs/bundle.md` |
| Command/API | `generateLlmsTxt`, `generateLLMFullContextFiles` | `leadtype generate --bundle`, `generateAgentsMd` |
| Agent entry file | `/llms.txt` (root) | `AGENTS.md` (package root) |
| Link style | Absolute URLs like `/docs/reference/cli.md` | Relative paths like `./docs/reference/cli.md` |
| Transport | HTTP with markdown content negotiation | Filesystem read inside `node_modules` |
| `product.agentGuidance` | Used (website URL routing) | Ignored by `generateAgentsMd` |
| Produces | `/llms.txt`, `/docs/llms.txt`, `/llms-full.txt`, `/docs/*.md`, sitemap, `robots.txt`, search JSON, `agent-readability.json` | `AGENTS.md`, `docs/*.md` |
| Skips | — | `llms.txt`, `llms-full.txt`, search JSON, sitemap files, `robots.txt`, `agent-readability.json` |
