# Cross-group agent flows: hosted website vs. npm bundle

Leadtype produces two distinct agent-readable flows from the same MDX source. The flows differ in their entry point, link style, and which website artifacts they emit.

## Hosted website flow

**Entry file:** `/llms.txt` at the site root (with a docs-scoped companion at `/docs/llms.txt`).

The hosted docs site exposes HTTP-discoverable agent files. The build generates `/llms.txt` at the site root and markdown mirrors under `/docs/*.md`. For agent requests, the server returns markdown when `Accept: text/markdown` is set or when a known AI user agent fetches a docs page.

Website mode keeps the following as static artifacts:

- `/llms.txt` (product-level, written by `generateLlmsTxt`)
- `/docs/llms.txt` (docs-scoped map, also from `generateLlmsTxt`)
- `/llms-full.txt` (root full-context fallback, written by `generateLLMFullContextFiles`)
- Sitemap files (e.g. `/docs/sitemap.xml`)
- `/robots.txt` (configured to allow `/llms.txt`)
- Search JSON (static search index)
- `agent-readability.json`

Verification for this flow involves fetching `/llms.txt`, fetching a docs page with `Accept: text/markdown`, checking `/docs/sitemap.xml`, and confirming `/robots.txt` allows `/llms.txt`.

## npm package bundle flow

**Entry file:** `AGENTS.md` at the package root, written by `generateAgentsMd` when running `leadtype generate --bundle`.

Bundle mode writes `AGENTS.md` at the package root and `docs/*.md` beneath it. `AGENTS.md` uses relative links like `./docs/reference/cli.md` so coding agents can read docs inside `node_modules` without any network request. Because of that offline target, `generateAgentsMd` intentionally ignores `product.agentGuidance` — that field is text written for website URL routing.

## Which website artifacts bundle mode skips

Bundle mode skips every website-only artifact (the same set that `isAgentReadabilityArtifactPath` identifies for the website):

- `llms.txt`
- `llms-full.txt`
- Search JSON
- Sitemap files
- `robots.txt`
- `agent-readability.json`

## Summary table

| Aspect | Hosted website | npm bundle |
| --- | --- | --- |
| Agent entry point | `/llms.txt` (+ `/docs/llms.txt`) | `AGENTS.md` at package root |
| Generator | `generateLlmsTxt`, `generateLLMFullContextFiles` | `generateAgentsMd` (via `leadtype generate --bundle`) |
| Link style | Absolute site paths (`/docs/reference/cli.md`) | Relative paths (`./docs/reference/cli.md`) |
| Transport | HTTP with `Accept: text/markdown` or AI UA sniffing | Local filesystem read inside `node_modules` |
| `product.agentGuidance` | Used (URL routing hints) | Ignored |
| `llms.txt` / `llms-full.txt` | Emitted | Skipped |
| Search JSON | Emitted | Skipped |
| Sitemap files | Emitted | Skipped |
| `robots.txt` | Emitted | Skipped |
| `agent-readability.json` | Emitted | Skipped |

## Sources

- `/llms.txt`
- `/docs/build/connect-docs-site.md`
- `/docs/package-docs/bundle.md`
- `/docs/reference/llm.md`
