# Cross-group agent flows: hosted website vs npm bundle

## Overview

Leadtype produces the same MDX source into two distinct agent flows. The two flows are complementary and can coexist: a package can ship bundled offline docs inside `node_modules` *and* a hosted docs website with `llms.txt` for URL-based agents.

---

## 1. Hosted Website Flow

### Entry point / starting file

HTTP agents start at **`/llms.txt`** (at the site root). From there they follow the markdown links it lists (e.g. `/docs/quickstart.md`, `/docs/reference/cli.md`, etc.).

### How it works

1. `leadtype generate` (no `--bundle` flag) runs in **website mode**.
2. The generator writes the following artifacts to the web root:

| Artifact | Purpose |
|---|---|
| `/llms.txt` | Product-level map; the agent entry point |
| `/docs/llms.txt` | Docs-scoped map |
| `/llms-full.txt` | Root full-context fallback — every generated markdown page in one file |
| `/docs/*.md` | Markdown mirrors of every MDX page |
| `docs/sitemap.xml` | Machine-readable sitemap |
| `docs/sitemap.md` | Markdown sitemap |
| `docs/robots.txt` | Crawl policy |
| `docs/agent-readability.json` | Agent-readability descriptor |
| `docs/search-index.json` | Static search index |
| `docs/search-content.json` | Search content payload |

3. The server serves markdown when a request carries `Accept: text/markdown` or comes from a known AI user agent.
4. `generateLlmsTxt` writes both the product-level and docs-scoped `llms.txt` maps.  
5. `generateLLMFullContextFiles` writes `/llms-full.txt` containing every generated markdown page. Groups organize the `llms.txt` sections and navigation but are **not** published as per-group full-context files by default.
6. `isAgentReadabilityArtifactPath` ensures that the artifact paths above are never rewritten as missing markdown pages.

---

## 2. npm Bundle (Package) Flow

### Entry point / starting file

Coding agents working inside an installed npm package start at **`AGENTS.md`** (at the package root) and follow **relative** links like `./docs/reference/cli.md`.

### How it works

1. `leadtype generate --bundle` runs in **bundle mode**.
2. The generator writes only two kinds of files into the tarball:

| Artifact | Purpose |
|---|---|
| `AGENTS.md` | Agent entry point; uses relative `./docs/*.md` links |
| `docs/*.md` | Markdown docs pages, readable without a network request |

3. `generateAgentsMd` writes `AGENTS.md`. It intentionally **ignores** `product.agentGuidance` because that text is written for website URL routing — not for `node_modules` path resolution.
4. All links are relative so agents can traverse docs entirely inside `node_modules` with no HTTP requests.

---

## 3. What bundle mode skips

Bundle mode explicitly omits every website-only artifact. The following files are written in hosted mode but **not** in `--bundle` mode:

| Skipped artifact | Why it is website-only |
|---|---|
| `llms.txt` / `docs/llms.txt` | Designed for HTTP discovery at a root URL |
| `llms-full.txt` | Full-context file served over HTTP |
| `docs/search-index.json` | Powers hosted static search |
| `docs/search-content.json` | Powers hosted static search |
| `docs/sitemap.xml` | For web crawlers and sitemaps |
| `docs/sitemap.md` | Markdown sitemap for hosted navigation |
| `docs/robots.txt` | HTTP crawl policy |
| `docs/agent-readability.json` | HTTP agent-readability descriptor |

These are exactly the paths identified by `isAgentReadabilityArtifactPath` as artifacts that should not be rewritten as missing markdown pages in a hosted context — and they are entirely absent from the npm tarball.

---

## Summary table

| Dimension | Hosted website flow | npm bundle flow |
|---|---|---|
| **Agent entry point** | `/llms.txt` (HTTP URL) | `AGENTS.md` (filesystem path) |
| **Link style** | Absolute URLs (`/docs/reference/cli.md`) | Relative paths (`./docs/reference/cli.md`) |
| **Network required?** | Yes — HTTP requests to the docs site | No — all files live in `node_modules` |
| **Full-context file** | `/llms-full.txt` (all pages in one file) | Not present |
| **Search index** | `search-index.json`, `search-content.json` | Not present |
| **Sitemap / robots** | `sitemap.xml`, `sitemap.md`, `robots.txt` | Not present |
| **Agent-readability descriptor** | `agent-readability.json` | Not present |
| **`product.agentGuidance`** | Used (URL-routing guidance) | Ignored by `generateAgentsMd` |
| **CLI flag** | `leadtype generate` (default) | `leadtype generate --bundle` |
