# Cross-group Agent Flows: Hosted vs NPM Bundle

## Overview

Leadtype supports two distinct flows for agent access to documentation, optimized for different deployment scenarios. Both flows originate from the same MDX source but produce different artifacts and entry points.

## Hosted Website Flow

**Entry Point:** `/llms.txt`

The hosted website flow serves HTTP-discoverable agent files from a live docs site.

### Starting File
- `/llms.txt` - The root entry point that agents discover and follow

### Website-Mode Artifacts Generated
The full set of website-mode artifacts includes:
1. `/llms.txt` - Product-level navigation and routing hints
2. `/docs/llms.txt` - Docs-scoped map for the hosted website
3. `/llms-full.txt` - Complete root full-context file containing every generated markdown docs page
4. `/docs/*.md` - Markdown mirrors of documentation pages
5. `/docs/sitemap.xml` - XML sitemap for agent discovery
6. `/docs/sitemap.md` - Markdown sitemap 
7. `/robots.txt` - Robots rules allowing agent access to `/llms.txt`
8. `/search.json` - Search index
9. `/search-content.json` - Search content data
10. `agent-readability.json` - Agent readability metadata

### Process
Agents fetch `/llms.txt`, which uses group organization to route them to relevant sections. Groups organize navigation and routing hints within llms.txt. Agents then follow markdown links through the documentation structure, making network requests for each page they need.

## NPM Bundle Flow

**Entry Point:** `AGENTS.md`

The bundle flow packages documentation for offline access inside npm tarballs.

### Starting File
- `AGENTS.md` - Located at the package root, serves as the entry point for coding agents in node_modules

### Bundle-Mode Artifacts Generated
1. `AGENTS.md` - Package-root entry point with relative links
2. `docs/*.md` - Markdown documentation files with relative references

### Process
Agents working inside installed npm packages start at `AGENTS.md` and follow relative links like `./docs/reference/cli.md`. This enables agents to read documentation inside node_modules without any network requests.

## Key Differences

### Starting Points
| Flow | Entry Point | Location |
|------|-------------|----------|
| **Hosted** | `/llms.txt` | Website root |
| **Bundle** | `AGENTS.md` | Package root |

### Skipped Artifacts in Bundle Mode

Bundle mode **intentionally skips all website-only artifacts**:
- `llms.txt` - Product-level navigation
- `llms-full.txt` - Full-context fallback
- `/docs/llms.txt` - Docs-scoped map
- `/docs/sitemap.xml` - XML sitemap
- `/docs/sitemap.md` - Markdown sitemap
- `/robots.txt` - Robot rules
- `search.json` - Search index
- `search-content.json` - Search content
- `agent-readability.json` - Agent readability metadata

### Design Decisions

**AGENTS.md Generation:** The `generateAgentsMd` function intentionally ignores `product.agentGuidance` because that text is written for website URL routing, which is irrelevant in the offline npm context.

**Group Organization:** Groups remain important in both flows for routing and navigation organization, but they serve different purposes:
- **Hosted flow:** Groups organize routing in llms.txt and navigation metadata
- **Bundle flow:** Groups organize the documentation structure into docs/*.md files

## Complementary Deployment

These two flows are designed to complement each other. A single documentation source can simultaneously:
1. Publish bundled offline docs for node_modules (via `--bundle` flag)
2. Maintain a hosted docs website with llms.txt for URL-based agents

This allows the same MDX source to serve both HTTP agents discovering docs at a URL and offline agents reading from installed packages.
