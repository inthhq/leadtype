# Cross-group Agent Flows: Hosted Website vs npm Bundle

## Overview

Leadtype's pipeline converts a single MDX source into artifacts that serve two distinct agent audiences: **HTTP agents** that access a hosted docs website, and **coding agents** that work inside installed npm packages. The two flows are intentionally complementary — a project can publish both.

---

## 1. Hosted Website Flow

### Entry Point

HTTP agents start at **`/llms.txt`** (served at the site root). From there they follow the markdown links listed inside that file (e.g. `/docs/quickstart.md`, `/docs/how-it-works.md`, etc.) to reach individual pages.

### How It Works

- `leadtype generate` (without `--bundle`) runs in **website mode**.
- The generator writes `llms.txt` and `docs/llms.txt` (via `generateLlmsTxt`), a root `/llms-full.txt` containing every generated page concatenated together (via `generateLLMFullContextFiles`), and individual markdown mirrors under `/docs/*.md`.
- When an agent or AI user-agent requests a docs page, the server serves **markdown** (via `Accept: text/markdown` or known-agent user-agent detection).
- Groups organize the `llms.txt` sections and navigation so agents can follow routing hints to the right sub-section.

### Full Set of Website Artifacts

| Artifact | Purpose |
|---|---|
| `/llms.txt` | Root agent entry point and table of contents |
| `/docs/llms.txt` | Docs-scoped map |
| `/llms-full.txt` | Full-context fallback (every page concatenated) |
| `/docs/*.md` | Per-page markdown mirrors |
| `docs/sitemap.xml` | XML sitemap |
| `docs/sitemap.md` | Markdown sitemap |
| `docs/robots.txt` | Crawler permission rules |
| `docs/agent-readability.json` | Agent-readability metadata |
| `docs/search-index.json` | Static search index |
| `docs/search-content.json` | Search content payload |

---

## 2. npm Bundle Mode Flow

### Entry Point

Coding agents working inside an installed npm package start at **`AGENTS.md`** (written to the package root). From there they follow **relative links** such as `./docs/reference/cli.md` to reach individual docs pages — no network request needed.

### How It Works

- `leadtype generate --bundle` runs in **bundle mode**.
- The generator writes `AGENTS.md` at the package root (via `generateAgentsMd`) and `docs/*.md` beneath it.
- All links inside `AGENTS.md` are relative so they resolve correctly inside `node_modules/` without any URL routing.
- `generateAgentsMd` intentionally **ignores** `product.agentGuidance` because that text is written for website URL routing and is not meaningful in an offline package context.

### Artifacts Written in Bundle Mode

| Artifact | Purpose |
|---|---|
| `AGENTS.md` | Offline agent entry point (relative links) |
| `docs/*.md` | Per-page markdown docs |

---

## 3. What Bundle Mode Skips

Bundle mode omits every **website-only artifact** — those that only make sense when the docs are served over HTTP:

| Skipped Artifact | Why it is skipped |
|---|---|
| `llms.txt` / `docs/llms.txt` | URL-based discovery file; irrelevant inside node_modules |
| `llms-full.txt` | Full-context HTTP fallback; not needed offline |
| `docs/search-index.json` / `docs/search-content.json` | Static search is a hosted-site concern |
| `docs/sitemap.xml` / `docs/sitemap.md` | Crawler sitemaps are only relevant on a live website |
| `docs/robots.txt` | Crawler directives only apply on a hosted server |
| `docs/agent-readability.json` | HTTP-level agent-readability metadata |

These paths are also recognized by `isAgentReadabilityArtifactPath` so the framework knows not to treat them as missing markdown pages when they are absent in bundle mode.

---

## 4. Side-by-Side Comparison

| Dimension | Hosted Website Flow | npm Bundle Flow |
|---|---|---|
| **Triggered by** | `leadtype generate` | `leadtype generate --bundle` |
| **Agent entry file** | `/llms.txt` (site root, HTTP) | `AGENTS.md` (package root, filesystem) |
| **Navigation links** | Absolute URLs (e.g. `/docs/cli.md`) | Relative paths (e.g. `./docs/cli.md`) |
| **Full-context fallback** | `/llms-full.txt` | ✗ Not generated |
| **Search index** | ✓ Generated | ✗ Skipped |
| **Sitemap / robots.txt** | ✓ Generated | ✗ Skipped |
| **agent-readability.json** | ✓ Generated | ✗ Skipped |
| **Works offline** | No (requires HTTP server) | Yes (inside node_modules) |
| **`product.agentGuidance`** | Used | Ignored (URL-routing text) |

---

## Sources

- `/llms.txt`
- `/docs/how-it-works.md`
- `/docs/quickstart.md`
- `/docs/build/connect-docs-site.md`
- `/docs/package-docs/bundle.md`
- `/docs/reference/llm.md`
