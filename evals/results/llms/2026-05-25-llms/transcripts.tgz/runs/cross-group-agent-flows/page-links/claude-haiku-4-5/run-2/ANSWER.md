# Cross-group Agent Flows: Hosted vs NPM Bundle

## Overview

Leadtype supports two complementary agent discovery flows that start from different entry points:

1. **Hosted Website Flow**: HTTP agents navigating a live docs site
2. **NPM Bundle Flow**: Coding agents working inside installed npm packages

## Hosted Website Flow

**Starting File**: `/llms.txt` (at the site root)

The hosted website flow is designed for HTTP-based agents that fetch docs over the network:

- Agents start by fetching `/llms.txt` at the domain root
- They follow markdown links to discover related documentation pages
- The generated artifacts include full website infrastructure
- Agents may request markdown with `Accept: text/markdown` headers or via known AI user agents

**Generated Website Artifacts**:
- `/llms.txt` - Root navigation map for agent discovery
- `/llms-full.txt` - Complete concatenated markdown of all docs pages
- `/docs/*.md` - Mirror markdown files under the docs path
- `/docs/llms.txt` - Docs-scoped navigation map
- `/docs/sitemap.xml` - XML sitemap for site structure
- `/robots.txt` - Robots directives (should allow `/llms.txt`)
- `search JSON` - Static search index
- `agent-readability.json` - Agent readability metadata
- `sitemap files` - Additional sitemaps as needed

## NPM Bundle Flow

**Starting File**: `AGENTS.md` (at the package root)

The npm bundle flow is designed for coding agents working with installed packages:

- Agents start by reading `AGENTS.md` at the package root
- They follow relative links like `./docs/reference/cli.md` to access documentation
- All docs are local within `node_modules`, no network requests needed
- AGENTS.md specifically uses relative paths for offline discovery

**Generated Bundle Artifacts**:
- `AGENTS.md` - Root navigation map at package root (relative links only)
- `docs/*.md` - Markdown files beneath the package root docs directory

## Website Artifacts Skipped in Bundle Mode

When using `--bundle` mode, Leadtype intentionally skips these website-specific artifacts:

- `llms.txt` - Not needed for relative link discovery
- `llms-full.txt` - Not needed in bundle mode
- `search JSON` - Search index unnecessary for offline package docs
- `sitemap files` - XML/HTML sitemaps not applicable to packages
- `robots.txt` - Robots directives not relevant in node_modules
- `agent-readability.json` - Readability metadata for web agents only

## Key Differences

| Aspect | Hosted Website | NPM Bundle |
|--------|---|---|
| **Starting File** | `/llms.txt` | `AGENTS.md` |
| **Link Style** | Absolute URLs (`/docs/...`) | Relative paths (`./docs/...`) |
| **Transport** | HTTP requests | Filesystem (node_modules) |
| **Target Audience** | HTTP agents (LLMs via URL) | Coding agents (installed packages) |
| **Navigation Scope** | Site-wide routing | Local package-relative routing |
| **Additional Artifacts** | Website infrastructure (sitemaps, search, robots.txt) | None (minimal) |

## The Complementary Model

A single MDX documentation source can serve both flows simultaneously:
- The same docs are generated for both website and package consumption
- Groups organize routing for both modes
- Website-specific text (like `product.agentGuidance`) is only used for website mode
- Bundle mode skips all HTTP-oriented artifacts, creating a minimal offline package bundle

This design allows teams to publish docs that work for both hosted web agents and offline npm package agents without maintaining separate documentation sources.
