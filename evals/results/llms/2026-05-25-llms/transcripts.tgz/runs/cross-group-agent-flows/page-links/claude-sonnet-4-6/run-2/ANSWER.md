# Cross-group agent flows: hosted vs npm bundle

## Overview

Leadtype supports two complementary agent flows from the same MDX source: a **hosted website flow** for HTTP-based agents and an **npm bundle flow** for coding agents working offline inside installed packages. The two flows share the same group structure and markdown content but differ in their entry points, link styles, and the set of artifacts they emit.

---

## 1. Hosted Website Flow

**Source:** [How it works](/docs/how-it-works.md), [Connect a docs site](/docs/build/connect-docs-site.md), [LLM files](/docs/reference/llm.md)

### Entry point
HTTP agents start at **`/llms.txt`** at the site root. From there they follow absolute markdown links (e.g. `/docs/reference/cli.md`) to individual docs pages.

### How it works
- The build generates `/llms.txt` (the product-level map) and `/docs/llms.txt` (the docs-scoped map) via `generateLlmsTxt`.
- A root `/llms-full.txt` is written by `generateLLMFullContextFiles`; it bundles every generated markdown page into a single full-context file for agents that prefer one large document.
- Markdown mirrors are placed under `/docs/*.md`. When an AI user-agent or a request with `Accept: text/markdown` arrives, the server serves the markdown version of a docs page.
- `product.agentGuidance` text is used here because it is written for website URL routing.

### Static artifacts produced
| Artifact | Purpose |
|---|---|
| `/llms.txt` | Product-level agent entry point / map |
| `/docs/llms.txt` | Docs-scoped agent map |
| `/llms-full.txt` | Single-file full-context fallback |
| `/docs/*.md` | Per-page markdown mirrors |
| `/docs/sitemap.xml` | Sitemap for crawlers |
| `/robots.txt` | Crawler policy (must allow `/llms.txt`) |
| `search JSON` | Static search index |
| `agent-readability.json` | Agent-readability signal |

### Verification
Good checks include fetching `/llms.txt`, fetching a docs page with `Accept: text/markdown`, checking `/docs/sitemap.xml`, and confirming `/robots.txt` allows `/llms.txt`.

---

## 2. npm Bundle Flow

**Source:** [How it works](/docs/how-it-works.md), [Bundle docs into a package](/docs/package-docs/bundle.md), [LLM files](/docs/reference/llm.md)

### Entry point
Coding agents working inside installed npm packages start at **`AGENTS.md`** at the package root. From there they follow **relative** links (e.g. `./docs/reference/cli.md`) to individual docs pages — no network request is required.

### How it works
- Triggered by `leadtype generate --bundle`.
- `generateAgentsMd` writes `AGENTS.md` with relative links so agents can read docs directly inside `node_modules` while offline.
- `generateAgentsMd` intentionally **ignores** `product.agentGuidance` because that text is written for website URL routing, which is irrelevant in a local file context.
- Docs pages are written to `docs/*.md` beneath the package root, mirroring the same group-organized content as the hosted site.

### Static artifacts produced
| Artifact | Purpose |
|---|---|
| `AGENTS.md` | Package-root agent entry point |
| `docs/*.md` | Per-page markdown docs (relative links) |

---

## 3. What Bundle Mode Skips

Bundle mode explicitly skips all **website-only artifacts** because they are meaningless (or unreachable) inside a local `node_modules` directory:

| Skipped Artifact | Why skipped |
|---|---|
| `llms.txt` | HTTP discovery entry point — no web server in a package |
| `llms-full.txt` | Full-context HTTP fallback — not needed offline |
| Search JSON | Static search index — requires a web host |
| Sitemap files | Crawler/SEO artifact — irrelevant in a tarball |
| `robots.txt` | Crawler policy — irrelevant in a tarball |
| `agent-readability.json` | HTTP agent-readability signal — irrelevant offline |

These paths are identified internally by `isAgentReadabilityArtifactPath`, which ensures they are never mistakenly rewritten as missing markdown pages in either flow.

---

## 4. Side-by-side Summary

| Dimension | Hosted website flow | npm bundle flow |
|---|---|---|
| **Agent entry file** | `/llms.txt` (site root) | `AGENTS.md` (package root) |
| **Link style** | Absolute URLs (`/docs/…`) | Relative paths (`./docs/…`) |
| **Network required** | Yes (HTTP) | No (local `node_modules`) |
| **Full-context file** | `/llms-full.txt` | — (skipped) |
| **Search index** | Yes | — (skipped) |
| **Sitemap / robots** | Yes | — (skipped) |
| **agent-readability.json** | Yes | — (skipped) |
| **CLI trigger** | `leadtype generate` (default) | `leadtype generate --bundle` |
| **`agentGuidance` used** | Yes (URL routing text) | No (intentionally ignored) |

The two flows are complementary: a package can ship bundled offline docs for `node_modules`-based agents **and** maintain a hosted docs website with `llms.txt` for URL-based agents, both generated from the same MDX source with the same group structure.
