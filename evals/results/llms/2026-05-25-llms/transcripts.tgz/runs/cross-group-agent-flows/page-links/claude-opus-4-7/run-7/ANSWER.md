# Cross-group agent flows: hosted website vs npm package bundle

Leadtype turns one MDX source into two distinct agent-facing distributions. The Build group documents the hosted website flow, while the Ship Package Docs group documents the npm bundle flow. The Reference group's LLM files page explains the underlying generator functions for both.

## Hosted website flow

**Starting file for agents:** `/llms.txt` at the site root.

**What the build produces (per `docs/build/connect-docs-site.md` and `docs/reference/llm.md`):**

- `/llms.txt` — product-level entry point, written by `generateLlmsTxt`.
- `/docs/llms.txt` — docs-scoped map, also written by `generateLlmsTxt`.
- `/llms-full.txt` — single root full-context fallback, written by `generateLLMFullContextFiles` (one file containing every generated markdown docs page; groups are not published as per-group full-context files by default).
- Markdown mirrors under `/docs/*.md`.
- Sitemap files, `robots.txt`, search JSON, and `agent-readability.json` as static artifacts.

**Serving rules:** Serve markdown when `Accept: text/markdown` is requested or when a known AI user agent fetches a docs page. Verification checks include fetching `/llms.txt`, fetching a docs page with `Accept: text/markdown`, checking `/docs/sitemap.xml`, and confirming `/robots.txt` allows `/llms.txt`.

## npm package bundle flow

**Command:** `leadtype generate --bundle`.

**Starting file for agents:** `AGENTS.md` at the package root (inside `node_modules/<pkg>/`).

**What the bundle contains (per `docs/package-docs/bundle.md` and `docs/reference/llm.md`):**

- `AGENTS.md` at the package root, written by `generateAgentsMd`. It uses relative links like `./docs/reference/cli.md` so coding agents can read docs inside `node_modules` with no network request.
- `docs/*.md` beneath the package root.

`generateAgentsMd` intentionally ignores `product.agentGuidance` because that text is written for website URL routing, not local relative-link reads.

## Website artifacts the bundle flow skips

Bundle mode is offline-first and explicitly omits website-only artifacts. Per `docs/package-docs/bundle.md` (and corroborated by `isAgentReadabilityArtifactPath` in `docs/reference/llm.md`), the bundle skips:

- `llms.txt`
- `llms-full.txt`
- search JSON
- sitemap files
- `robots.txt`
- `agent-readability.json`

## Side-by-side summary

| Aspect | Hosted website | npm bundle |
| --- | --- | --- |
| Entry file for agents | `/llms.txt` | `AGENTS.md` (package root) |
| Transport | HTTP, content negotiation on `Accept: text/markdown` | Local filesystem reads inside `node_modules` |
| Generator function for entry | `generateLlmsTxt` | `generateAgentsMd` |
| Full-context fallback | `/llms-full.txt` via `generateLLMFullContextFiles` | none |
| Sitemaps / `robots.txt` | included | skipped |
| Search JSON | included | skipped |
| `agent-readability.json` | included | skipped |
| Uses `product.agentGuidance` | yes (URL routing) | no (ignored by `generateAgentsMd`) |
| Link style in entry file | site URLs | relative paths like `./docs/reference/cli.md` |

In short: the hosted flow starts at `/llms.txt` and publishes the full set of HTTP-discoverable artifacts; the bundle flow starts at `AGENTS.md` and ships only `AGENTS.md` plus `docs/*.md`, skipping `llms.txt`, `llms-full.txt`, search JSON, sitemap files, `robots.txt`, and `agent-readability.json`.
