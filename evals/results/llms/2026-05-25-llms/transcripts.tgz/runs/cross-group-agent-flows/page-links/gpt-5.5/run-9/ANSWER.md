# Hosted website flow vs npm package bundle flow for agents

## Hosted website flow

- **Entry point:** an HTTP/URL-based agent starts at the site-root **`/llms.txt`**.
- **How it proceeds:** the agent follows the markdown links advertised from `llms.txt`, including hosted markdown mirrors such as **`/docs/*.md`**. Hosted sites can also expose the docs-scoped **`/docs/llms.txt`** map.
- **Generated website artifacts:** website mode writes agent-readable and discovery artifacts such as:
  - `/llms.txt`
  - `/docs/llms.txt`
  - `/llms-full.txt`
  - markdown mirrors under `/docs/*.md`
  - sitemap files, for example `/docs/sitemap.xml` and `/docs/sitemap.md`
  - `robots.txt`
  - `agent-readability.json`
  - search JSON, such as `search-index.json` and `search-content.json`
- **Serving behavior:** for agent requests, the hosted site should serve markdown when the request asks for `text/markdown` or comes from a known AI user agent.

## npm package bundle flow

- **Entry point:** a coding agent working inside an installed npm package starts at package-root **`AGENTS.md`**.
- **How it proceeds:** `AGENTS.md` uses relative links, for example `./docs/reference/cli.md`, so the agent can read bundled documentation from `node_modules` without making network requests.
- **Generated package artifacts:** `leadtype generate --bundle` writes:
  - `AGENTS.md`
  - bundled markdown docs under `docs/*.md`

## Website artifacts skipped by bundle mode

Bundle mode intentionally does **not** emit the hosted-website-only artifacts. It skips:

- `llms.txt` artifacts, including the hosted root `/llms.txt` and docs map `/docs/llms.txt`
- `/llms-full.txt`
- search JSON files
- sitemap files
- `robots.txt`
- `agent-readability.json`

In short: hosted agents discover docs through URL routing from `/llms.txt`; npm-bundled agents discover offline docs through `AGENTS.md` and relative `docs/*.md` links.