# Cross-group agent flows: hosted website vs npm bundle

Leadtype emits two distinct agent-facing flows from the same MDX source. The
hosted website flow is documented under the **Build** group, while the npm
package bundle flow is documented under **Ship Package Docs**. The Reference
group's LLM files page clarifies which generator writes which artifact.

## Hosted website flow

Documented in [`/docs/build/connect-docs-site.md`](docs/build/connect-docs-site.md).

- **Starting file for agents:** `/llms.txt` at the site root. Agents discover
  docs pages from the page-level markdown links it contains, then fetch
  individual `/docs/*.md` mirrors over HTTP.
- **Content negotiation:** the site serves markdown when `Accept: text/markdown`
  is sent or when a known AI user agent requests a docs page.
- **Static website artifacts kept alongside `llms.txt`:**
  - `/llms.txt` (product-level map; written by `generateLlmsTxt`)
  - `/docs/llms.txt` (docs-scoped map; also from `generateLlmsTxt`)
  - `/llms-full.txt` (single root full-context file; written by
    `generateLLMFullContextFiles`)
  - `/docs/sitemap.xml` and other sitemap files
  - `/robots.txt` (must allow `/llms.txt`)
  - search JSON
  - `agent-readability.json`
- **Verification:** fetch `/llms.txt`, fetch a docs page with
  `Accept: text/markdown`, check `/docs/sitemap.xml`, and confirm `/robots.txt`
  allows `/llms.txt`.

## npm package bundle flow

Documented in [`/docs/package-docs/bundle.md`](docs/package-docs/bundle.md).

- **Command:** `leadtype generate --bundle`, used when publishing an npm package.
- **Starting file for agents:** `AGENTS.md` at the package root (written by
  `generateAgentsMd`), with `docs/*.md` beneath it.
- **Linking style:** `AGENTS.md` uses relative links like
  `./docs/reference/cli.md` so coding agents can read the docs directly from
  `node_modules` without any network request.
- **Intentional omission:** `generateAgentsMd` ignores `product.agentGuidance`
  because that text is written for website URL routing, not on-disk reads.

## Website artifacts the bundle flow skips

Bundle mode is offline-first, so it omits everything that only makes sense when
served over HTTP. Per `/docs/package-docs/bundle.md` (and corroborated by
`isAgentReadabilityArtifactPath` in `/docs/reference/llm.md`), bundle mode
skips:

- `llms.txt`
- `llms-full.txt`
- search JSON
- sitemap files
- `robots.txt`
- `agent-readability.json`

## Side-by-side summary

| Aspect | Hosted website flow | npm bundle flow |
| --- | --- | --- |
| Docs group | Build | Ship Package Docs |
| Source page | `/docs/build/connect-docs-site.md` | `/docs/package-docs/bundle.md` |
| Entry file for agents | `/llms.txt` | `AGENTS.md` |
| Docs location | `/docs/*.md` served over HTTP | `docs/*.md` inside the tarball |
| Link style | Absolute site URLs | Relative paths (`./docs/...`) |
| Transport | HTTP with content negotiation | Local filesystem (`node_modules`) |
| Generators used | `generateLlmsTxt`, `generateLLMFullContextFiles` | `generateAgentsMd` |
| Includes `llms.txt` / `llms-full.txt` | Yes | No |
| Includes sitemap / `robots.txt` | Yes | No |
| Includes search JSON | Yes | No |
| Includes `agent-readability.json` | Yes | No |
| Uses `product.agentGuidance` | Yes (URL routing) | No (ignored by `generateAgentsMd`) |
