# Cross-Group Agent Flows: Hosted vs npm Bundle

## Overview

Leadtype supports two complementary flows for serving agent-readable documentation:

1. **Hosted Website Flow**: For HTTP-based agents accessing docs over the network
2. **npm Bundle Flow**: For coding agents working inside installed npm packages

## Hosted Website Flow

**Starting Point**: `/llms.txt` at the site root

### Process
- HTTP agents start at `/llms.txt` and follow markdown links to discover documentation
- The build generates `/llms.txt` at the site root and markdown mirrors under `/docs/*.md`
- Groups organize content sections, navigation, search metadata, and provide routing hints
- Includes `product.agentGuidance` text written for website URL routing

### Artifacts Generated
- `/llms.txt` (product-level index)
- `/docs/llms.txt` (docs-scoped map)
- `/docs/*.md` (markdown mirrors of all pages)
- `/llms-full.txt` (root file containing every generated markdown docs page)
- Sitemap files
- `/robots.txt`
- Search JSON
- `agent-readability.json`

### Verification
- Fetch `/llms.txt`
- Fetch a docs page with `Accept: text/markdown`
- Check `/docs/sitemap.xml`
- Confirm `/robots.txt` allows `/llms.txt`

## npm Bundle Flow

**Starting Point**: `AGENTS.md` at the package root

### Process
- Coding agents start at `AGENTS.md` and follow relative docs/*.md links
- Uses relative links like `./docs/reference/cli.md` so agents can read docs inside node_modules without network requests
- Intentionally ignores `product.agentGuidance` (not applicable for offline package context)
- Activated with: `leadtype generate --bundle`

### Artifacts Generated
- `AGENTS.md` (at package root)
- `docs/*.md` (relative documentation files)

## Artifacts Skipped in Bundle Mode

Bundle mode **does not generate** the following website-only artifacts:

- `llms.txt` (product and docs-scoped variants)
- `llms-full.txt`
- Search JSON
- Sitemap files
- `robots.txt`
- `agent-readability.json`

## Key Differences

| Aspect | Hosted | Bundle |
|--------|--------|--------|
| **Starting File** | `/llms.txt` | `AGENTS.md` |
| **Agent Type** | HTTP-based | Coding (offline) |
| **Link Style** | Absolute URLs | Relative paths |
| **Network Required** | Yes | No |
| **product.agentGuidance** | Included | Ignored |
| **Web Artifacts** | Full set | None |
| **Use Case** | Network-accessible docs | npm package distribution |

## Complementary Deployment

A single package can publish both:
- **Bundled offline docs** for node_modules access (via `--bundle` mode)
- **Hosted docs website** with llms.txt for URL-based agents (standard mode)

This allows maximum flexibility for different agent deployment contexts.
