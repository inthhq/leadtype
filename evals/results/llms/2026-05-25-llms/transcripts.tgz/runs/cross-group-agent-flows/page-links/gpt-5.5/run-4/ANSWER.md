# Cross-group agent flows: hosted vs npm bundle

Leadtype supports two complementary agent flows from the same MDX source and group metadata.

## Hosted website flow

- **Starts from:** `/llms.txt` for HTTP/URL-based agents.
- **Then follows:** page-level markdown links, usually to markdown mirrors under `/docs/*.md`.
- **Related hosted artifacts:** website mode also emits `/docs/llms.txt`, `/llms-full.txt`, sitemap files, robots.txt, search JSON, and `agent-readability.json`.
- **Group behavior:** groups organize `llms.txt` sections, navigation, search metadata, and routing hints. A page can appear in multiple groups, but `/llms-full.txt` is a single full-context fallback containing all generated markdown pages, not per-group shards.

## npm package bundle flow

- **Starts from:** `AGENTS.md` at the npm package root.
- **Then follows:** relative links such as `./docs/reference/cli.md` to bundled `docs/*.md` files inside the package, so coding agents can work from `node_modules` without a network request.
- **Group behavior:** the same group metadata is used for `AGENTS.md` grouping, so cross-group organization is preserved for package-local agent routing.

## Website artifacts skipped by bundle mode

`leadtype generate --bundle` writes only `AGENTS.md` and bundled `docs/*.md` markdown. It skips website-only artifacts, including:

- `llms.txt` files, including the hosted `/llms.txt` flow entry point
- `llms-full.txt`
- search JSON, such as `search-index.json` and `search-content.json`
- sitemap files, such as `sitemap.xml` and `sitemap.md`
- `robots.txt`
- `agent-readability.json`

In short: hosted agents start at `/llms.txt` and use website-discoverable markdown and static web artifacts; npm-bundled coding agents start at `AGENTS.md` and use relative package-local markdown, skipping the hosted website discovery, search, sitemap, robots, and readability artifacts.
