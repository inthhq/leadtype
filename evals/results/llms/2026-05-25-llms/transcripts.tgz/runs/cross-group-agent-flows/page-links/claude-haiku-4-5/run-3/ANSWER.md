# Cross-group Agent Flows: Hosted vs NPM Bundle

## Overview

Leadtype supports two distinct flows for making documentation accessible to agents, each optimized for different deployment scenarios. Both flows start from a single MDX source, but diverge in their generated artifacts and starting points.

## Hosted Website Flow

**Starting Point:** `/llms.txt`

The hosted website flow is designed for HTTP agents accessing a live docs website.

### Process:
1. Leadtype generates `/llms.txt` at the site root
2. Agents (like Claude, GPT-4, etc.) start by fetching `/llms.txt`
3. `/llms.txt` contains markdown links to docs pages
4. Agents follow those links to fetch `/docs/*.md` pages
5. The site serves markdown when agents request with `Accept: text/markdown` or when recognized as an AI user agent

### Artifacts Generated:
- `/llms.txt` - Root file that agents start from
- `/llms-full.txt` - Full-context fallback
- `/docs/*.md` - Individual markdown pages
- `/docs/sitemap.xml` - Sitemap for agent discovery
- `/robots.txt` - Crawler directives
- `/agent-readability.json` - Agent metadata
- Search JSON indices

## NPM Bundle (Package) Flow

**Starting Point:** `AGENTS.md` (at package root)

The bundle flow is designed for coding agents working within installed npm packages (accessing files in `node_modules`).

### Process:
1. Leadtype generates `AGENTS.md` at the package root
2. Coding agents start by reading `AGENTS.md` from the installed package
3. `AGENTS.md` uses **relative links** like `./docs/reference/cli.md`
4. Agents follow relative paths to access docs offline from `node_modules`
5. No network requests required

### Artifacts Generated:
- `AGENTS.md` - Root file that agents start from (at package root)
- `docs/*.md` - Individual markdown pages (relative to package root)

## Key Differences

| Aspect | Hosted Website | NPM Bundle |
|--------|----------------|-----------|
| **Starting File** | `/llms.txt` | `AGENTS.md` |
| **Link Type** | Absolute HTTP paths | Relative file paths |
| **Network Requirement** | Yes (HTTP requests) | No (offline access) |
| **Entry Point Location** | Site root | Package root |

## Website Artifacts Skipped by Bundle Mode

When using `leadtype generate --bundle`, the following website-only artifacts are **not generated**:

- `llms.txt` - Root discovery file (replaced by AGENTS.md)
- `llms-full.txt` - Full-context fallback
- Search JSON indices
- `sitemap.xml` and related sitemap files
- `robots.txt` - Crawler directives
- `agent-readability.json` - Agent metadata

These artifacts are specific to HTTP-served websites and unnecessary for offline npm package distributions.

## Complementary Deployment

A single documentation source can support both flows simultaneously:
- **Website deployment:** Uses hosted mode, generating `/llms.txt` and HTTP-accessible docs
- **NPM package:** Uses bundle mode, generating `AGENTS.md` and relative-linked docs in the tarball

This allows the same MDX source to serve both URL-based agents (via hosted website) and code-based agents (via installed npm packages).
