# Cross-group Agent Flows: Hosted vs npm Bundle

## Hosted Website Flow

**Starting point:** `/llms.txt`

Agents accessing a hosted docs website start by fetching the `/llms.txt` file at the site root. This file provides a map of the documentation with links to markdown pages. Agents then follow markdown links to discover and read additional pages from the `/docs/*.md` paths.

**Key artifacts generated:**
- `/llms.txt` (product-level navigation file)
- `/docs/llms.txt` (docs-scoped map)
- `/docs/*.md` (markdown mirrors of pages)
- `/llms-full.txt` (optional full-context file with all docs)
- Website support files: sitemap files, robots.txt, search JSON, agent-readability.json

## npm Bundle Flow

**Starting point:** `AGENTS.md`

Coding agents working inside installed npm packages start from `AGENTS.md` at the package root. This file uses relative links (e.g., `./docs/reference/cli.md`) so agents can read docs inside `node_modules` without making network requests.

**Key artifacts generated:**
- `AGENTS.md` (package root navigation file with relative links)
- `docs/*.md` (markdown documentation)

## Artifacts Skipped in Bundle Mode

Bundle mode **does not generate** the following website-only artifacts:

- `llms.txt` (product-level navigation)
- `llms-full.txt` (full-context file)
- Search JSON (search index)
- Sitemap files
- `robots.txt`
- `agent-readability.json`

Additionally, `AGENTS.md` intentionally ignores `product.agentGuidance` text, which is written for website URL routing and not applicable to offline bundle scenarios.

## Summary

| Aspect | Hosted Website | npm Bundle |
|--------|---|---|
| **Entry file** | `/llms.txt` | `AGENTS.md` |
| **Link type** | Absolute URLs | Relative paths |
| **Access method** | HTTP requests | Local filesystem |
| **Support files** | llms.txt, llms-full.txt, search, sitemaps, robots.txt, agent-readability.json | None |
| **Use case** | HTTP agents discovering docs via URL routing | Coding agents reading bundled offline docs |

Both flows start from a root navigation file that agents can bootstrap from, but they serve different deployment models: hosted websites for URL-based discovery and npm packages for offline, node_modules-embedded documentation.
