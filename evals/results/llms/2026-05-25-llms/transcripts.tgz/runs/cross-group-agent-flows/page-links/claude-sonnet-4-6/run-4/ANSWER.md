# Cross-group Agent Flows: Hosted Website vs npm Bundle

## Overview

Leadtype's pipeline takes the same MDX source and produces two distinct agent-readable output modes:
**website mode** (for HTTP-discoverable, hosted docs sites) and **bundle mode** (for offline, npm-packaged docs).
Both flows complement each other — a package can publish bundled offline docs for `node_modules` *and*
maintain a hosted docs website with `llms.txt` for URL-based agents.

---

## 1. Hosted Website Flow

### Entry point / starting file
HTTP agents start at **`/llms.txt`** at the site root. This file is the top-level map that lists all
groups and links to individual markdown pages. A second, docs-scoped map is also written at
**`/docs/llms.txt`**. Agents follow the markdown links found in those files.

### How it works
1. Leadtype reads MDX sources, resolves frontmatter and the group tree, and flattens supported MDX
   components into plain markdown.
2. `generateLlmsTxt` writes `/llms.txt` (product-level) and `/docs/llms.txt` (docs-scoped).
3. `generateLLMFullContextFiles` writes **`/llms-full.txt`** — a single file containing every generated
   markdown docs page — as a root full-context fallback.
4. Markdown mirrors of every docs page are placed under `/docs/*.md`.
5. The build also emits all supporting static artifacts (see below).
6. For agent requests the server serves markdown when the `Accept` header asks for `text/markdown`
   or when a known AI user agent requests a docs page.

### Website-only static artifacts generated
| Artifact | Purpose |
|---|---|
| `/llms.txt` | Top-level agent map (product level) |
| `/docs/llms.txt` | Docs-scoped agent map |
| `/llms-full.txt` | Full-context single-file fallback |
| `docs/sitemap.xml` | XML sitemap |
| `docs/sitemap.md` | Markdown sitemap |
| `docs/robots.txt` | Crawler/agent permissions |
| `docs/agent-readability.json` | Agent-readability metadata |
| `docs/search-index.json` | Static search index |
| `docs/search-content.json` | Search content payload |

> `isAgentReadabilityArtifactPath` identifies all these paths so they are never rewritten as
> missing markdown pages.

---

## 2. npm Bundle Flow

### Entry point / starting file
Coding agents working inside an installed npm package start at **`AGENTS.md`** at the package root.
`AGENTS.md` uses **relative links** (e.g. `./docs/reference/cli.md`) so agents can traverse docs
entirely inside `node_modules` without any network request.

### How it works
1. Run `leadtype generate --bundle` during the npm package's publish step.
2. `generateAgentsMd` writes **`AGENTS.md`** at the package root.
   - It intentionally ignores `product.agentGuidance` because that text is written for website
     URL routing and is not meaningful in an offline `node_modules` context.
3. Markdown docs pages are written under **`docs/*.md`** relative to the package root, reachable
   via the relative links in `AGENTS.md`.

---

## 3. What Bundle Mode Skips

Bundle mode **does not generate** the following website-only artifacts:

| Skipped Artifact | Why it's skipped |
|---|---|
| `llms.txt` | HTTP discovery artifact; not useful inside `node_modules` |
| `llms-full.txt` | Full-context HTTP fallback; not needed offline |
| Search JSON (`search-index.json`, `search-content.json`) | Server-side / hosted search; irrelevant offline |
| Sitemap files (`sitemap.xml`, `sitemap.md`) | URL-based navigation; meaningless inside a tarball |
| `robots.txt` | Crawler rules; no web server in `node_modules` |
| `agent-readability.json` | Hosted-site metadata; not applicable to a package |

All of these artifacts require an HTTP server or web-browser-style URL routing to be useful.
Bundle mode produces only the two things an offline coding agent needs: **`AGENTS.md`** and the
**`docs/*.md`** markdown files it links to.

---

## 4. Side-by-side Summary

| Dimension | Hosted Website Flow | npm Bundle Flow |
|---|---|---|
| **Trigger** | `leadtype generate` (no flag) | `leadtype generate --bundle` |
| **Agent entry point** | `/llms.txt` (HTTP URL) | `AGENTS.md` (relative file path) |
| **Secondary entry** | `/docs/llms.txt`, `/llms-full.txt` | — |
| **Docs pages** | `/docs/*.md` (HTTP-served) | `docs/*.md` (relative, inside tarball) |
| **Link style** | Absolute URLs | Relative paths (`./docs/…`) |
| **Network required** | Yes (HTTP) | No (offline inside `node_modules`) |
| **Website artifacts** | All of the above | **None** (all skipped) |
| **`product.agentGuidance`** | Used (URL routing hints) | Ignored (not meaningful offline) |
