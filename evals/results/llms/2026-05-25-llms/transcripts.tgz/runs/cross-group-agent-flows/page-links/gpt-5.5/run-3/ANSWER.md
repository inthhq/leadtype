# Cross-group agent flows: hosted website vs npm bundle

Leadtype supports two complementary agent documentation flows built from the same MDX source pages.

## Hosted website flow

Use the hosted website flow when agents will read docs over HTTP.

- **Starting file:** `/llms.txt` at the website root.
- **How agents proceed:** agents fetch `/llms.txt`, use its group-organized routing links, and follow links to markdown mirrors such as `/docs/quickstart.md` or `/docs/reference/cli.md`.
- **Expected website artifacts:** the hosted site should keep static agent and discovery artifacts including:
  - `/llms.txt`
  - `/llms-full.txt`
  - `/docs/llms.txt`
  - sitemap files such as `/docs/sitemap.xml`
  - `/robots.txt`
  - search JSON
  - `agent-readability.json`
- **Serving behavior:** docs pages should serve markdown when `Accept` requests `text/markdown` or when a known AI user agent requests a docs page.

## npm package bundle flow

Use bundle mode when publishing docs inside an npm package for offline coding agents working in `node_modules`.

- **Starting file:** `AGENTS.md` at the package root.
- **How agents proceed:** agents read `AGENTS.md` and follow relative links such as `./docs/reference/cli.md` to markdown files bundled inside the package.
- **Generated package docs:** bundle mode writes:
  - `AGENTS.md`
  - `docs/*.md` markdown files beneath the package root

## What bundle mode skips

Bundle mode skips website-only artifacts because package consumers do not need HTTP discovery, routing, or site search files. It does **not** emit:

- `llms.txt`
- `llms-full.txt`
- search JSON
- sitemap files
- `robots.txt`
- `agent-readability.json`

## Summary

Hosted website agents start at `/llms.txt` and navigate URL-based markdown docs plus website discovery artifacts. npm-bundled coding agents start at `AGENTS.md` and navigate relative `docs/*.md` files inside the installed package. The same MDX source can support both flows, but bundle mode intentionally omits the hosted-site artifacts.