# Cross-group agent flows: hosted website vs npm bundle

Leadtype emits agent-readable docs through two complementary flows from a single MDX source. They differ in the entry point an agent uses and in which generated artifacts ship alongside that entry point.

## Sources consulted

- `/llms.txt` — site map of docs pages.
- `/docs/how-it-works.md` — describes the two agent flows.
- `/docs/build/connect-docs-site.md` — hosted website wiring.
- `/docs/package-docs/bundle.md` — npm bundle wiring.
- `/docs/reference/llm.md` — which generator writes which file.

## Hosted website flow (website mode)

Used when a docs site exposes HTTP-discoverable agent files.

- **Entry point an agent starts from:** `/llms.txt` at the site root. HTTP agents start there and follow markdown links (per `how-it-works.md`).
- **Fallback / full-context entry:** `/llms-full.txt` at the site root, written by `generateLLMFullContextFiles`, which inlines every generated markdown docs page.
- **Group-scoped map:** `/docs/llms.txt`, also written by `generateLlmsTxt`.
- **Per-page markdown:** mirrors under `/docs/*.md`, served when `Accept: text/markdown` or a known AI user agent requests a docs page.
- **Static support artifacts kept at the site root:**
  - `llms.txt`
  - `llms-full.txt`
  - sitemap files (e.g. `/docs/sitemap.xml`)
  - `robots.txt` (must allow `/llms.txt`)
  - search JSON
  - `agent-readability.json`
- **Verification cues:** fetch `/llms.txt`, fetch a `/docs/*.md` page with `Accept: text/markdown`, check `/docs/sitemap.xml`, and confirm `/robots.txt` allows `/llms.txt`.

## npm package bundle flow (bundle mode)

Used when publishing docs inside an npm tarball so coding agents can read them from `node_modules` without a network request. Triggered by `leadtype generate --bundle`.

- **Entry point an agent starts from:** `AGENTS.md` at the package root, written by `generateAgentsMd`. Coding agents working inside installed npm packages start there.
- **Per-page markdown:** `docs/*.md` beneath the package root.
- **Link style:** `AGENTS.md` uses relative links like `./docs/reference/cli.md` so resolution works on disk inside `node_modules`.
- **Intentional omission inside AGENTS.md:** `generateAgentsMd` ignores `product.agentGuidance` because that text is written for website URL routing, not on-disk reads.

## Artifacts that bundle mode skips

Bundle mode deliberately omits the website-only artifacts listed in `docs/package-docs/bundle.md` (and recognized by `isAgentReadabilityArtifactPath` in `docs/reference/llm.md`):

- `llms.txt`
- `llms-full.txt`
- search JSON
- sitemap files
- `robots.txt`
- `agent-readability.json`

These are URL-routing and discovery artifacts that only make sense for an HTTP-served docs site; an agent reading files from `node_modules` does not need them and instead walks `AGENTS.md` → relative `./docs/*.md` links.

## Side-by-side summary

| Concern | Hosted website flow | npm bundle flow |
| --- | --- | --- |
| Trigger | Normal `leadtype generate` wired into a docs site | `leadtype generate --bundle` |
| Agent entry file | `/llms.txt` (site root) | `AGENTS.md` (package root) |
| Full-context fallback | `/llms-full.txt` | — (not emitted) |
| Group-scoped map | `/docs/llms.txt` | — |
| Per-page markdown | `/docs/*.md`, content-negotiated by `Accept: text/markdown` | `docs/*.md` read directly from disk |
| Link style in entry file | URL paths | Relative `./docs/...` paths |
| Sitemap / robots.txt | Yes | Skipped |
| Search JSON | Yes | Skipped |
| `agent-readability.json` | Yes | Skipped |
| `product.agentGuidance` text | Used (URL routing) | Ignored by `generateAgentsMd` |

## Why both can coexist

Per `docs/how-it-works.md`, the two flows complement each other: a package can publish bundled offline docs for `node_modules` *and* a hosted docs website with `llms.txt` for URL-based agents, both generated from the same MDX source.
