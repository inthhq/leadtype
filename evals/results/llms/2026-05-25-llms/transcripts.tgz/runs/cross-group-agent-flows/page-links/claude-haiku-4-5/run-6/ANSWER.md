# Cross-group Agent Flows: Hosted vs NPM Bundle

## Overview

Leadtype supports two complementary agent flows that serve different deployment scenarios. Both start from the same MDX source and frontmatter, but diverge in their output artifacts and entry points.

## The Two Flows

### Hosted Website Flow

**Starting Point:** `/llms.txt`

The hosted website flow is designed for HTTP-based agents that discover documentation through URL-based requests. 

**Key Characteristics:**
- Agents begin by fetching `/llms.txt` at the site root
- They follow markdown links (in the form of URLs like `/docs/reference/cli.md`)
- The generated artifacts are accessible via HTTP
- Designed for agents that need network access to fetch docs on-demand

**Generated Website Artifacts:**
- `/llms.txt` - Root agent entry point with full-context fallback
- `/docs/llms.txt` - Docs-scoped map for hosted websites
- `/llms-full.txt` - Complete full-context file containing every generated markdown docs page
- `/docs/*.md` - Markdown mirrors of all docs pages
- `/docs/sitemap.xml` - XML sitemap for navigation
- `/docs/sitemap.md` - Markdown sitemap
- `robots.txt` - Robot configuration file
- `search JSON` - Static search index
- `agent-readability.json` - Agent readability metadata

### NPM Bundle Flow

**Starting Point:** `AGENTS.md` (in package root)

The npm bundle flow is designed for coding agents working inside installed npm packages that prefer offline access to documentation.

**Key Characteristics:**
- Agents begin by reading `AGENTS.md` at the package root
- They follow relative links like `./docs/reference/cli.md`
- No network requests are required; docs are bundled in node_modules
- Uses the `--bundle` flag with `leadtype generate`

**Generated Bundle Artifacts:**
- `AGENTS.md` - Root entry point for offline agents with relative links
- `docs/*.md` - All markdown docs pages, referenced by relative paths

## Key Differences

### Starting Files
| Flow | Entry Point | Type |
|------|-------------|------|
| Hosted Website | `/llms.txt` | HTTP URL |
| NPM Bundle | `AGENTS.md` | Relative file path |

### Skipped Artifacts in Bundle Mode

Bundle mode intentionally **skips all website-only artifacts**:

1. **llms.txt** - Not needed for offline access; replaced by AGENTS.md
2. **llms-full.txt** - Full-context document for hosted sites
3. **search JSON** - Static search index (not useful offline)
4. **sitemap files** - robots.txt, sitemap.xml, sitemap.md (HTTP discovery tools)
5. **agent-readability.json** - Metadata for HTTP agent readability checks
6. **docs/llms.txt** - Docs-scoped map specific to website routing

### Link Style

- **Hosted:** Absolute URLs (e.g., `/docs/reference/cli.md`)
- **Bundle:** Relative paths (e.g., `./docs/reference/cli.md`)

This allows AGENTS.md to work without requiring knowledge of the eventual host URL.

## Complementary Nature

The two flows complement each other perfectly:
- A **package** can publish bundled offline docs for `node_modules` (bundle mode)
- The **same package's website** can expose llms.txt for URL-based agents (hosted mode)
- Both flows read the same MDX source and frontmatter
- Groups organize navigation, search metadata, and routing in both flows

This design allows library maintainers to serve agents efficiently whether they're accessed via HTTP requests to a website or via file system access to installed npm packages.

## Configuration

- **Website mode:** Default behavior of `leadtype generate`
  - Generates all artifacts for HTTP discovery and serving
  
- **Bundle mode:** `leadtype generate --bundle`
  - Strips HTTP-specific artifacts
  - Uses relative links in AGENTS.md
  - Optimizes for node_modules deployment
