# Cross-group Agent Flows: Hosted vs npm Bundle

## Overview

Leadtype supports two complementary agent flows that serve different deployment contexts:

1. **Hosted Website Flow** - for HTTP agents accessing docs at a URL
2. **npm Bundle Flow** - for coding agents accessing docs inside node_modules

Both flows start from the same MDX source but generate different artifacts tailored to their runtime environment.

---

## Hosted Website Flow

### Starting Point
- **Root file**: `/llms.txt` (the product-level LLM index)
- **Alternative root**: `/docs/llms.txt` (docs-scoped map)

### Flow Behavior
HTTP agents start at `/llms.txt` and follow markdown links to discover documentation pages. The hosted flow generates complete website artifacts including:

- `/llms.txt` - product-level agent discovery index
- `/docs/llms.txt` - docs-scoped navigation map
- `/docs/*.md` - markdown mirrors of all documentation pages (following the group structure)
- `/llms-full.txt` - optional root full-context file containing every generated markdown page
- Sitemap files (`/docs/sitemap.xml`)
- `robots.txt` - configured to allow agent access to `/llms.txt`
- `search.json` - static search index
- `agent-readability.json` - agent-specific metadata

### Architecture
Groups organize llms.txt sections, navigation, search metadata, and routing. The hosted flow is designed for URL-based discovery and routing.

---

## npm Bundle Flow

### Starting Point
- **Root file**: `AGENTS.md` (at the package root)

### Flow Behavior
Coding agents working inside installed npm packages start at `AGENTS.md` and follow relative docs/*.md links without making network requests. The bundle flow generates only offline artifacts:

- `AGENTS.md` - at package root with relative links like `./docs/reference/cli.md`
- `docs/*.md` - markdown documentation files beneath the package root

### Intentional Differences
Bundle mode **intentionally ignores** `product.agentGuidance` because that text is written for website URL routing, which is irrelevant for offline npm consumption.

---

## Website Artifacts Skipped in Bundle Mode

Bundle mode **skips all website-only artifacts**:

1. `/llms.txt` - product-level agent index (no URL routing)
2. `/docs/llms.txt` - docs-scoped map (no URL routing)
3. `/llms-full.txt` - full-context root file (not needed offline)
4. Sitemap files (e.g., `/docs/sitemap.xml`)
5. `robots.txt` - not relevant for local file access
6. `search.json` - static search index
7. `agent-readability.json` - agent-specific metadata

---

## Summary Comparison

| Aspect | Hosted Website | npm Bundle |
|--------|---|---|
| **Starting File** | `/llms.txt` | `AGENTS.md` |
| **Link Type** | HTTP URLs | Relative paths |
| **Access Pattern** | HTTP agent discovery | Local node_modules access |
| **Markdown Pages** | `/docs/*.md` | `docs/*.md` |
| **Product Guidance** | Included in llms.txt | Skipped (uses AGENTS.md instead) |
| **Search Index** | ✓ search.json | ✗ (skipped) |
| **Sitemaps** | ✓ sitemap files | ✗ (skipped) |
| **robots.txt** | ✓ generated | ✗ (skipped) |

Both flows complement each other, allowing a package to publish bundled offline docs for node_modules and a hosted docs website with llms.txt for URL-based agents.
