# Cross-group agent flows: hosted website vs npm bundle

Leadtype generates docs from one MDX source but emits two different agent-facing flows. The differences are documented across the **Build** group ([connect-docs-site.md](/docs/build/connect-docs-site.md)), the **Ship Package Docs** group ([bundle.md](/docs/package-docs/bundle.md)), and the **Reference** group ([llm.md](/docs/reference/llm.md)).

## Hosted website flow

**Starting file for agents:** `/llms.txt` at the site root.

Per `docs/build/connect-docs-site.md`, website mode is used when a docs site needs to expose HTTP-discoverable agent files. The build:

- Generates `/llms.txt` at the site root and markdown mirrors under `/docs/*.md`.
- Serves markdown when `Accept: text/markdown` is requested, or when a known AI user agent fetches a docs page.
- Keeps these as static artifacts: `/llms.txt`, `/llms-full.txt`, sitemap files, `robots.txt`, search JSON, and `agent-readability.json`.

The reference page (`docs/reference/llm.md`) confirms the underlying generators:

- `generateLlmsTxt` writes the product-level `/llms.txt` and the docs-scoped `/docs/llms.txt` map.
- `generateLLMFullContextFiles` writes the root `/llms-full.txt` containing every generated markdown docs page.

Verification of this flow uses HTTP probes: fetching `/llms.txt`, fetching a docs page with `Accept: text/markdown`, checking `/docs/sitemap.xml`, and confirming `/robots.txt` allows `/llms.txt`.

## npm package bundle flow

**Starting file for agents:** `AGENTS.md` at the package root.

Per `docs/package-docs/bundle.md`, bundle mode is invoked with `leadtype generate --bundle` when publishing an npm package. It:

- Writes `AGENTS.md` at the package root and `docs/*.md` beneath it.
- Uses relative links like `./docs/reference/cli.md` so coding agents can read docs inside `node_modules` without any network request.

The reference page (`docs/reference/llm.md`) notes that `generateAgentsMd` writes `AGENTS.md` for npm-bundled docs and intentionally ignores `product.agentGuidance`, because that guidance text is written for website URL routing — not for filesystem-relative reads inside a package.

## Website artifacts that bundle mode skips

Bundle mode is explicitly scoped to offline, filesystem-based reads, so it omits everything that only makes sense over HTTP. Per `docs/package-docs/bundle.md`, bundle mode skips these website-only artifacts:

- `llms.txt`
- `llms-full.txt`
- search JSON
- sitemap files
- `robots.txt`
- `agent-readability.json`

This matches the set that `isAgentReadabilityArtifactPath` recognizes in `docs/reference/llm.md` (llms.txt, llms-full.txt, sitemap files, robots.txt, search JSON, and agent-readability.json) — the same artifacts that the website serves statically are the ones bundle mode leaves out.

## Summary table

| Aspect | Hosted website flow | npm bundle flow |
|---|---|---|
| Entry file for agents | `/llms.txt` | `AGENTS.md` (package root) |
| Generator | `generateLlmsTxt`, `generateLLMFullContextFiles` | `generateAgentsMd` |
| Command | default `leadtype generate` site build | `leadtype generate --bundle` |
| Link style | absolute URLs, content negotiation on `/docs/*.md` | relative paths like `./docs/reference/cli.md` |
| Access mode | HTTP fetch with `Accept: text/markdown` | filesystem reads inside `node_modules` |
| `product.agentGuidance` | used (website URL routing) | ignored by `generateAgentsMd` |
| Artifacts produced | `/llms.txt`, `/docs/llms.txt`, `/llms-full.txt`, `/docs/*.md`, sitemap files, `robots.txt`, search JSON, `agent-readability.json` | `AGENTS.md`, `docs/*.md` |
| Artifacts skipped | — | `llms.txt`, `llms-full.txt`, search JSON, sitemap files, `robots.txt`, `agent-readability.json` |
