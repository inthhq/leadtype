# Cross-group agent flows: hosted website vs npm bundle

Leadtype generates docs artifacts for two distinct agent-consumption flows from one MDX source. The starting files and the artifacts each flow produces (or skips) differ in important ways.

## Hosted website flow

**Starting files for agents:**
- `/llms.txt` — the product-level entry point, written by `generateLlmsTxt`. This is the discovery file an agent fetches first.
- `/docs/llms.txt` — the docs-scoped map, also written by `generateLlmsTxt`.
- `/llms-full.txt` — a single root file containing every generated markdown docs page, written by `generateLLMFullContextFiles`. Acts as a full-context fallback.

**Supporting website artifacts (kept as static files):**
- `/llms.txt` and `/llms-full.txt`
- `sitemap` files (e.g. `/docs/sitemap.xml`)
- `/robots.txt` (must allow `/llms.txt`)
- search JSON (static search index)
- `agent-readability.json`
- markdown mirrors under `/docs/*.md`

**Serving behavior:** the site serves markdown when `Accept: text/markdown` is requested or when a known AI user agent requests a docs page. `isAgentReadabilityArtifactPath` marks the artifact paths above so they aren't rewritten as missing markdown pages.

Source: [Connect a docs site](/docs/build/connect-docs-site.md), [LLM files](/docs/reference/llm.md).

## npm package bundle flow

**Starting file for agents:**
- `AGENTS.md` at the package root, written by `generateAgentsMd` when running `leadtype generate --bundle`. Coding agents read it directly out of `node_modules` — no network request required.

**Supporting bundle artifacts:**
- `docs/*.md` beneath the package root.
- `AGENTS.md` uses **relative links** like `./docs/reference/cli.md` so traversal works offline inside `node_modules`.

**Important detail:** `generateAgentsMd` intentionally ignores `product.agentGuidance`, because that guidance text is written for website URL routing and doesn't apply to a local-filesystem bundle.

Source: [Bundle docs into a package](/docs/package-docs/bundle.md), [LLM files](/docs/reference/llm.md).

## Website artifacts that bundle mode skips

Bundle mode is explicitly narrower than the hosted flow. It does **not** emit:

| Skipped artifact         | Why it's website-only                                |
|--------------------------|------------------------------------------------------|
| `llms.txt`               | HTTP discovery file; agents read `AGENTS.md` instead |
| `llms-full.txt`          | Root full-context fallback for hosted fetches        |
| search JSON              | Powers the static search index on the website        |
| sitemap files            | For crawlers of the hosted site                      |
| `robots.txt`             | Controls hosted crawler access                       |
| `agent-readability.json` | Declares hosted agent-readable artifact paths        |

These are exactly the paths recognized by `isAgentReadabilityArtifactPath` — i.e., the set of "agent-readability" artifacts only makes sense when there is a web origin to serve them from.

## Summary

- **Hosted flow** starts at `/llms.txt`, branches to `/docs/llms.txt` and `/llms-full.txt`, and relies on a constellation of static website-only artifacts (sitemaps, `robots.txt`, search JSON, `agent-readability.json`).
- **Bundle flow** starts at `AGENTS.md` shipped inside the npm tarball, uses relative links to `docs/*.md`, and skips every website-only artifact above because there is no HTTP origin and no crawler to satisfy.
