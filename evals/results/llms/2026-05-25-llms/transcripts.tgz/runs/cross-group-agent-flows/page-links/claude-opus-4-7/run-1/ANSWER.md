# Cross-group agent flows: hosted website vs npm package bundle

Leadtype generates docs from a single MDX source but ships them through two distinct agent-facing flows. The flows live in different doc groups in `/llms.txt` — "Build" for the hosted website and "Ship Package Docs" for the npm bundle — and the Reference group's `llm.md` page describes the generator APIs that back each one.

## Hosted website flow

**Entry doc:** [`/docs/build/connect-docs-site.md`](/docs/build/connect-docs-site.md)
**Backing reference:** [`/docs/reference/llm.md`](/docs/reference/llm.md)

The hosted flow starts from the site root. An agent first fetches `/llms.txt` (the product-level map written by `generateLlmsTxt`) and follows links into markdown mirrors served under `/docs/*.md`. Content negotiation matters here: the docs site serves markdown when `Accept: text/markdown` is requested or when a known AI user agent asks for a docs page.

Website mode emits a full set of HTTP-discoverable artifacts that the build keeps as static files:

- `/llms.txt` (product-level map) and `/docs/llms.txt` (docs-scoped map) — from `generateLlmsTxt`
- `/llms-full.txt` — the single root full-context fallback from `generateLLMFullContextFiles`
- Sitemap files (e.g. `/docs/sitemap.xml`)
- `/robots.txt` (which must allow `/llms.txt`)
- Search JSON (the static search index)
- `agent-readability.json`

The `isAgentReadabilityArtifactPath` helper in `llm.md` enumerates exactly this set so the site doesn't mistake them for missing markdown pages.

## npm package bundle flow

**Entry doc:** [`/docs/package-docs/bundle.md`](/docs/package-docs/bundle.md)
**Backing reference:** [`/docs/reference/llm.md`](/docs/reference/llm.md) (`generateAgentsMd`)

The bundle flow is invoked with `leadtype generate --bundle` and is designed for coding agents reading docs out of `node_modules` with no network access. It starts from a different file: `AGENTS.md` at the package root, with markdown under `./docs/*.md` beside it. `AGENTS.md` uses relative links like `./docs/reference/cli.md` so the agent can walk the tree on disk.

`generateAgentsMd` intentionally ignores `product.agentGuidance` because that field is written for website URL routing and isn't meaningful inside a tarball.

## Which website artifacts bundle mode skips

Per `bundle.md` (and confirmed by the `isAgentReadabilityArtifactPath` list in `llm.md`), bundle mode skips every website-only artifact:

| Artifact | Hosted site | npm bundle |
| --- | --- | --- |
| `llms.txt` (entry point) | ✅ | ❌ skipped |
| `llms-full.txt` (root full-context) | ✅ | ❌ skipped |
| Sitemap files | ✅ | ❌ skipped |
| `robots.txt` | ✅ | ❌ skipped |
| Search JSON | ✅ | ❌ skipped |
| `agent-readability.json` | ✅ | ❌ skipped |
| `AGENTS.md` (package-root entry) | ❌ (not the entry point) | ✅ |
| `docs/*.md` mirrors | ✅ (HTTP-served) | ✅ (filesystem) |

## Summary

- The **hosted flow** starts at `/llms.txt` and depends on HTTP-discoverable artifacts (`llms.txt`, `llms-full.txt`, sitemaps, `robots.txt`, search JSON, `agent-readability.json`) plus content-negotiated `/docs/*.md` mirrors.
- The **bundle flow** starts at `AGENTS.md` at the package root and ships only `AGENTS.md` plus `docs/*.md` with relative links — skipping all six website-only artifacts above because there is no HTTP server inside an npm tarball.
