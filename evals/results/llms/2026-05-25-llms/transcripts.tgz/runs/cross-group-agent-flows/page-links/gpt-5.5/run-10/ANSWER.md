# Cross-group agent flows: hosted vs npm bundle

## Hosted website flow

- Use **website mode** when docs should be discoverable over HTTP.
- HTTP agents start at the site-root **`/llms.txt`** and follow its markdown links to generated page mirrors such as **`/docs/*.md`**.
- Leadtype also generates a docs-scoped **`/docs/llms.txt`** map for hosted websites.
- A docs site should serve markdown for agent requests, either when `Accept` asks for `text/markdown` or when a known AI user agent requests a docs page.
- Hosted static artifacts include **`/llms.txt`**, **`/llms-full.txt`**, sitemap files, **`robots.txt`**, search JSON, and **`agent-readability.json`**.

## npm package bundle flow

- Use **`leadtype generate --bundle`** when publishing docs inside an npm package.
- Coding agents working inside an installed package start at package-root **`AGENTS.md`**.
- `AGENTS.md` uses relative links such as **`./docs/reference/cli.md`**, so agents can read version-matched docs inside `node_modules` without a network request.
- Bundle mode writes **`AGENTS.md`** and **`docs/*.md`** beneath the package root.

## What bundle mode skips

Bundle mode skips website-only artifacts:

- **`llms.txt`**
- **`llms-full.txt`**
- search JSON
- sitemap files
- **`robots.txt`**
- **`agent-readability.json`**

## Cross-group behavior

Groups are used for routing and organization, not for sharding agent context. They organize `llms.txt` sections, navigation, search metadata, and `AGENTS.md`, but Leadtype does not publish per-group full-context files by default. The hosted and bundle flows therefore complement each other: URL-based agents use `/llms.txt` on the website, while offline coding agents use `AGENTS.md` inside the npm package.