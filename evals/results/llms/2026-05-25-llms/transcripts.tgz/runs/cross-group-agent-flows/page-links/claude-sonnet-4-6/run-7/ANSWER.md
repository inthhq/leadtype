# Cross-group Agent Flows: Hosted Website vs npm Bundle

## Overview

Leadtype's pipeline produces the same MDX source into two distinct delivery
modes — a **hosted website** and an **npm package bundle** — each designed for
a different kind of agent (HTTP URL-based agents vs. coding agents inside
`node_modules`). The two flows complement each other, and a project can publish
both simultaneously.

---

## 1. Hosted Website Flow

### Entry point
Agents start at **`/llms.txt`** at the site root.

### How it works
- `/llms.txt` (and a docs-scoped `/docs/llms.txt`) act as the discovery map.
  Agents read this file and follow the markdown links listed there.
- Individual docs pages are served under **`/docs/*.md`**.  When an agent
  (or a browser with `Accept: text/markdown`) requests a docs page, the server
  returns the markdown mirror of that page.
- A root **`/llms-full.txt`** is also generated as a single-file full-context
  fallback containing every generated markdown docs page.

### Static website artifacts produced
| Artifact | Path |
|---|---|
| Site-level agent map | `/llms.txt` |
| Docs-scoped agent map | `/docs/llms.txt` |
| Full-context fallback | `/llms-full.txt` |
| Agent readability metadata | `/agent-readability.json` |
| XML sitemap | `/docs/sitemap.xml` |
| Markdown sitemap | `/docs/sitemap.md` |
| Robots rules | `/robots.txt` |
| Search index | search JSON |
| Search content | search content JSON |

These are all exposed over HTTP and identified internally by
`isAgentReadabilityArtifactPath` so they are never rewritten as missing
markdown pages.

---

## 2. npm Bundle Flow

### Entry point
Agents start at **`AGENTS.md`** at the **package root** (i.e., inside
`node_modules/<package>/AGENTS.md`).

### How it works
- Triggered by running `leadtype generate --bundle`.
- `AGENTS.md` is written at the package root with **relative links** such as
  `./docs/reference/cli.md`, so coding agents can navigate all docs entirely
  offline, without any network request.
- Supporting markdown pages are written under **`docs/*.md`** inside the
  package tarball.
- `generateAgentsMd` intentionally ignores `product.agentGuidance` because
  that text is written for website URL routing, which is irrelevant inside
  `node_modules`.

### Artifacts produced
| Artifact | Location |
|---|---|
| Agent entry point | `AGENTS.md` (package root) |
| Reference docs | `docs/*.md` (relative) |

---

## 3. What Bundle Mode Skips

Bundle mode **skips all website-only artifacts** because they have no meaning
without an HTTP server:

| Skipped artifact | Why it is website-only |
|---|---|
| `llms.txt` / `docs/llms.txt` | HTTP discovery map; requires a URL-addressable host |
| `llms-full.txt` | HTTP full-context fallback file |
| Search JSON | Requires a hosted search endpoint |
| `sitemap.xml` / `sitemap.md` | Crawl/indexing hints for web agents |
| `robots.txt` | HTTP crawler directives |
| `agent-readability.json` | Website-level agent metadata |

---

## 4. Side-by-side Summary

| Dimension | Hosted Website | npm Bundle |
|---|---|---|
| **CLI trigger** | `leadtype generate` (default) | `leadtype generate --bundle` |
| **Agent entry file** | `/llms.txt` (HTTP URL) | `AGENTS.md` (relative path) |
| **Docs pages** | `/docs/*.md` served over HTTP | `docs/*.md` inside tarball |
| **Full-context file** | `/llms-full.txt` | ✗ skipped |
| **Search index** | ✓ generated | ✗ skipped |
| **Sitemap / robots** | ✓ generated | ✗ skipped |
| **agent-readability.json** | ✓ generated | ✗ skipped |
| **Requires network?** | Yes | No — fully offline |

### Sources
- [`/docs/how-it-works.md`](/docs/how-it-works.md)
- [`/docs/build/connect-docs-site.md`](/docs/build/connect-docs-site.md)
- [`/docs/package-docs/bundle.md`](/docs/package-docs/bundle.md)
- [`/docs/reference/llm.md`](/docs/reference/llm.md)
- [`/docs/reference/cli.md`](/docs/reference/cli.md)
