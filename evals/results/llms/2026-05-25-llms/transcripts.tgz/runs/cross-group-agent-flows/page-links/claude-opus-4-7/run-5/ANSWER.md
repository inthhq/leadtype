# Cross-group agent flows: hosted website vs npm bundle

Leadtype generates docs from a single MDX source but ships them through two distinct agent-facing flows. The flows live in different doc groups (`Build` vs `Ship Package Docs`) and are backed by different generator functions in the `Reference` group.

## Hosted website flow

**Doc group:** Build → [`/docs/build/connect-docs-site.md`](/docs/build/connect-docs-site.md)
**Reference:** [`/docs/reference/llm.md`](/docs/reference/llm.md)

Website mode exposes agent files over HTTP so AI clients can fetch them on demand.

- **Entry file for agents:** `/llms.txt` at the site root (product-level map), with a docs-scoped `/docs/llms.txt` also produced by `generateLlmsTxt`.
- **Full-context fallback:** `/llms-full.txt` at the root, written by `generateLLMFullContextFiles` — a single file containing every generated markdown page.
- **Per-page mirrors:** markdown mirrors under `/docs/*.md`, served when the request `Accept` header asks for `text/markdown` or when a known AI user agent requests a docs page.
- **Static support artifacts (kept as static files):**
  - `/llms.txt`
  - `/llms-full.txt`
  - sitemap files (e.g. `/docs/sitemap.xml`)
  - `/robots.txt` (must allow `/llms.txt`)
  - search JSON
  - `agent-readability.json`
- **Verification:** fetch `/llms.txt`, fetch a docs page with `Accept: text/markdown`, check `/docs/sitemap.xml`, and confirm `/robots.txt` allows `/llms.txt`.

In this flow, `product.agentGuidance` is meaningful because it is written for website URL routing.

## npm package bundle flow

**Doc group:** Ship Package Docs → [`/docs/package-docs/bundle.md`](/docs/package-docs/bundle.md)
**Reference:** [`/docs/reference/llm.md`](/docs/reference/llm.md) (`generateAgentsMd`)

Bundle mode is triggered by `leadtype generate --bundle` and is intended for npm tarballs that coding agents read offline from `node_modules`, without a network request.

- **Entry file for agents:** `AGENTS.md` at the package root, written by `generateAgentsMd`.
- **Per-page docs:** `docs/*.md` beneath the package root.
- **Linking style:** `AGENTS.md` uses **relative** links like `./docs/reference/cli.md` so agents can resolve them on the local filesystem.
- **Intentional omission:** `generateAgentsMd` ignores `product.agentGuidance`, because that guidance text targets website URL routing rather than local filesystem layout.

## Website artifacts that bundle mode skips

Per `bundle.md` (and consistent with `isAgentReadabilityArtifactPath` in `llm.md`), bundle mode does **not** produce any of the website-only artifacts:

| Artifact | Website flow | Bundle flow |
| --- | --- | --- |
| `llms.txt` | ✅ written | ❌ skipped |
| `llms-full.txt` | ✅ written | ❌ skipped |
| Search JSON | ✅ written | ❌ skipped |
| Sitemap files | ✅ written | ❌ skipped |
| `robots.txt` | ✅ written | ❌ skipped |
| `agent-readability.json` | ✅ written | ❌ skipped |
| `AGENTS.md` | — (not the entry point) | ✅ written (entry point) |
| `docs/*.md` | ✅ served as mirrors | ✅ written under package root |

## Summary

- **Hosted flow starts from `/llms.txt`** (with `/llms-full.txt` as a root full-context fallback) and relies on a suite of HTTP-discoverable artifacts: `llms.txt`, `llms-full.txt`, sitemaps, `robots.txt`, search JSON, and `agent-readability.json`.
- **Bundle flow starts from `AGENTS.md`** at the package root and ships only `AGENTS.md` plus `docs/*.md` with relative links. It deliberately skips every website-only artifact (`llms.txt`, `llms-full.txt`, search JSON, sitemap files, `robots.txt`, `agent-readability.json`) and ignores `product.agentGuidance`, because those exist to serve HTTP URL routing rather than offline filesystem reads.
