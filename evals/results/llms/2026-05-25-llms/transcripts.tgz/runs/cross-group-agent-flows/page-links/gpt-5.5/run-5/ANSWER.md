# Cross-group agent flows: hosted vs npm bundle

Leadtype supports two complementary agent flows:

## Hosted website flow

- **Agent entry point:** `/llms.txt` at the hosted site root.
- **How agents continue:** Agents follow the markdown links listed in `/llms.txt`, such as `/docs/*.md` pages.
- **Generated/served artifacts:** Website mode exposes HTTP-discoverable agent files, including:
  - `/llms.txt`
  - `/docs/llms.txt`
  - `/llms-full.txt`
  - markdown mirrors under `/docs/*.md`
  - sitemap files
  - `robots.txt`
  - search JSON
  - `agent-readability.json`
- **Request behavior:** Docs pages should serve markdown when `Accept` asks for `text/markdown` or when a known AI user agent requests a docs page.

## npm package bundle flow

- **Agent entry point:** `AGENTS.md` at the npm package root.
- **How agents continue:** Coding agents follow relative links from `AGENTS.md`, such as `./docs/reference/cli.md`, to read bundled docs inside `node_modules` without a network request.
- **Generated/served artifacts:** Bundle mode writes:
  - `AGENTS.md`
  - `docs/*.md` beneath the package root

## What bundle mode skips

When using `leadtype generate --bundle`, Leadtype skips website-only artifacts:

- `llms.txt`
- `llms-full.txt`
- search JSON
- sitemap files
- `robots.txt`
- `agent-readability.json`

In short: URL-based agents start from hosted `/llms.txt`; offline coding agents inside an installed npm package start from `AGENTS.md`. Both can use the same generated markdown docs, but bundle mode omits the website discovery, search, sitemap, robots, and readability artifacts.