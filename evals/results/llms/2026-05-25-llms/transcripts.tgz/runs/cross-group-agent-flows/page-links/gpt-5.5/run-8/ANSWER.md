# Cross-group agent flows: hosted vs npm bundle

Leadtype supports two complementary agent flows:

## Hosted website flow

- **Use case:** Agents access the docs over HTTP on a hosted docs site.
- **Starting file:** `/llms.txt` at the site root.
- **How agents navigate:** HTTP agents start at `/llms.txt` and follow its markdown links to page-level markdown mirrors such as `/docs/*.md`.
- **Generated/served website artifacts:** Website mode should keep static artifacts including:
  - `/llms.txt`
  - `/llms-full.txt`
  - sitemap files, such as `/docs/sitemap.xml`
  - `/robots.txt`
  - search JSON
  - `agent-readability.json`
- **Serving behavior:** Docs pages should return markdown when the request asks for `text/markdown` or when a known AI user agent requests a docs page.

## npm package bundle flow

- **Use case:** Coding agents read docs from an installed npm package, such as inside `node_modules`, without making network requests.
- **Starting file:** `AGENTS.md` at the package root.
- **How agents navigate:** Coding agents start at `AGENTS.md` and follow relative links like `./docs/reference/cli.md` to bundled `docs/*.md` files.
- **Command:** Bundle mode is used with `leadtype generate --bundle` when publishing an npm package.

## What bundle mode skips

Bundle mode writes `AGENTS.md` and bundled `docs/*.md` files, but it skips website-only artifacts:

- `llms.txt`
- `llms-full.txt`
- search JSON
- sitemap files
- `robots.txt`
- `agent-readability.json`

In short: hosted website agents start from `/llms.txt` and use URL-addressable markdown plus website discovery artifacts, while npm-bundled coding agents start from `AGENTS.md` and use relative package-local markdown files. The two flows can be published together: one for URL-based agents and one for offline package-aware agents.