# Hosted vs npm bundle agent flows

Leadtype supports two complementary agent flows from the same MDX source.

## Hosted website flow

For a hosted docs site, agents start at the site-root file:

- `/llms.txt`

From there, HTTP agents follow the markdown links to generated page-level markdown files, such as `/docs/*.md`. Website mode should expose `/llms.txt` at the root and markdown mirrors under `/docs/*.md`. It can also serve markdown for docs pages when the request asks for `text/markdown` or comes from a known AI user agent.

Hosted website mode also keeps website discovery and readability artifacts as static files, including `/llms-full.txt`, sitemap files, `robots.txt`, search JSON, and `agent-readability.json`.

## npm package bundle flow

For an npm package, agents start inside the installed package at:

- `AGENTS.md`

Bundle mode is produced with `leadtype generate --bundle`. It writes `AGENTS.md` at the package root and markdown docs beneath it, such as:

- `docs/*.md`

`AGENTS.md` uses relative links like `./docs/reference/cli.md`, so coding agents can read version-matched docs from `node_modules` without making network requests.

## Website artifacts skipped by bundle mode

Bundle mode skips website-only artifacts:

- `llms.txt`
- `llms-full.txt`
- search JSON
- sitemap files
- `robots.txt`
- `agent-readability.json`

In short: hosted website agents begin at `/llms.txt` and traverse URL-based markdown docs, while npm-package coding agents begin at `AGENTS.md` and traverse relative `docs/*.md` files bundled in the package.