# Cross-group Agent Flows: Hosted Website vs npm Bundle

## Overview

Leadtype generates the same MDX source into two distinct delivery targets — a **hosted docs website** and an **npm package bundle** — each designed for a different kind of agent consumer. The two flows complement each other: a project can publish both simultaneously.

---

## 1. Hosted Website Flow

### Entry point
Agents using the hosted website flow start at **`/llms.txt`** (at the site root). From there they follow markdown links into the docs pages (e.g. `/docs/*.md`).

### How the flow works
1. `leadtype generate` (website mode, no `--bundle` flag) reads MDX source files, resolves frontmatter and the group tree, and emits artifacts to the web root.
2. The build generates:
   - `/llms.txt` — the product-level agent map (primary entry point).
   - `/docs/llms.txt` — a docs-scoped map.
   - `/llms-full.txt` — a single root file containing every generated markdown docs page (full-context fallback).
   - `/docs/*.md` — markdown mirrors of every docs page, served with `text/markdown` for agent or AI user-agent requests.
   - `/agent-readability.json` — agent-readability metadata.
   - `/sitemap.xml`, `/sitemap.md` — sitemap files.
   - `/robots.txt` — crawl permissions (must allow `/llms.txt`).
   - Search JSON (`searchIndex`, `searchContent`) — static search index.
3. HTTP/URL-based agents discover everything through the root `/llms.txt` and then fetch individual markdown pages over the network.

### Key functions (reference)
- `generateLlmsTxt` — writes `/llms.txt` and `/docs/llms.txt`.
- `generateLLMFullContextFiles` — writes `/llms-full.txt`.
- Groups organise `llms.txt` sections, navigation, search metadata, and `AGENTS.md`.

---

## 2. npm Package Bundle Flow

### Entry point
Agents working inside installed npm packages start at **`AGENTS.md`** (at the package root, i.e. inside `node_modules/<package>/`). From there they follow **relative links** such as `./docs/reference/cli.md` — no network request is needed.

### How the flow works
1. `leadtype generate --bundle` reads the same MDX source but emits only the offline-friendly subset of artifacts:
   - `AGENTS.md` — root entry point with relative links to all docs.
   - `docs/*.md` — the same markdown docs pages, co-located in the tarball.
2. Coding agents (e.g. those running inside a repo that has the package installed) can read documentation entirely from the filesystem.
3. `AGENTS.md` intentionally ignores `product.agentGuidance` because that text is written for website URL routing, which is irrelevant in an offline bundle context.

---

## 3. Website Artifacts That Bundle Mode Skips

When running in `--bundle` mode, Leadtype explicitly **omits** all website-only artifacts. These are identified internally by `isAgentReadabilityArtifactPath`:

| Skipped Artifact | Reason skipped in bundle mode |
|---|---|
| `llms.txt` | HTTP discovery file; meaningless without a hosted URL |
| `llms-full.txt` | Full-context HTTP fallback; not needed offline |
| Search JSON (`searchIndex`, `searchContent`) | Static search index is a website concern |
| `sitemap.xml` / `sitemap.md` | Sitemap files are for web crawlers |
| `robots.txt` | Crawl permissions file; not applicable to npm packages |
| `agent-readability.json` | Website agent-readability metadata |

---

## Summary Comparison

| Aspect | Hosted Website Flow | npm Bundle Flow |
|---|---|---|
| **Agent entry point** | `/llms.txt` (HTTP, site root) | `AGENTS.md` (filesystem, package root) |
| **Link style** | Absolute URLs (`/docs/*.md`) | Relative paths (`./docs/*.md`) |
| **Network required?** | Yes | No |
| **CLI invocation** | `leadtype generate` (no `--bundle`) | `leadtype generate --bundle` |
| **Full-context file** | `/llms-full.txt` generated | Not generated |
| **Search index** | Generated | Skipped |
| **Sitemap / robots.txt** | Generated | Skipped |
| **agent-readability.json** | Generated | Skipped |
| **Markdown docs pages** | `/docs/*.md` served over HTTP | `docs/*.md` inside tarball |
| **Use case** | URL-based / HTTP agents | Coding agents inside `node_modules` |

Both flows share the same MDX source and group tree, ensuring docs are consistent whether an agent reaches them through a URL or through the local filesystem.
