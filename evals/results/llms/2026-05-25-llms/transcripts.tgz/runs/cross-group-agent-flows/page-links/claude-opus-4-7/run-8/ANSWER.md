# Cross-group agent flows: hosted website vs npm bundle

Leadtype turns a single MDX source into two distinct delivery modes for coding
agents. They are documented in different groups of `/llms.txt` (the **Build**
group for the hosted site, the **Ship Package Docs** group for the bundle), and
they produce different starting files and different sets of website artifacts.

## Hosted website flow

Documented in [`/docs/build/connect-docs-site.md`](docs/build/connect-docs-site.md)
with reference detail in [`/docs/reference/llm.md`](docs/reference/llm.md).

- **Entry file for agents:** `/llms.txt` at the site root, served over HTTP.
- **Discoverable docs:** markdown mirrors under `/docs/*.md`. The site serves
  markdown when the request `Accept`s `text/markdown` or comes from a known AI
  user agent.
- **Generation API:** `generateLlmsTxt` writes the product-level `/llms.txt`
  and the docs-scoped `/docs/llms.txt` map. `generateLLMFullContextFiles`
  writes the root `/llms-full.txt` fallback containing every generated
  markdown docs page.
- **Static website artifacts kept as-is:**
  - `/llms.txt`
  - `/llms-full.txt`
  - sitemap files (e.g. `/docs/sitemap.xml`)
  - `/robots.txt` (must allow `/llms.txt`)
  - search JSON
  - `agent-readability.json`
- **Verification:** fetch `/llms.txt`, fetch a docs page with
  `Accept: text/markdown`, check `/docs/sitemap.xml`, confirm `/robots.txt`
  allows `/llms.txt`.

`isAgentReadabilityArtifactPath` exists to recognize this exact set of
artifacts so the site does not rewrite them as missing markdown pages.

## npm package bundle flow

Documented in [`/docs/package-docs/bundle.md`](docs/package-docs/bundle.md)
with reference detail in [`/docs/reference/llm.md`](docs/reference/llm.md).

- **Trigger:** `leadtype generate --bundle` when publishing an npm package.
- **Entry file for agents:** `AGENTS.md` at the package root (inside
  `node_modules/<pkg>/`). Coding agents read it from disk — no network
  request is required.
- **Docs layout:** `docs/*.md` beneath the package root.
- **Links:** `AGENTS.md` uses relative links like `./docs/reference/cli.md`
  so they resolve against the on-disk package, not a URL.
- **Generation API:** `generateAgentsMd` writes `AGENTS.md`. It intentionally
  ignores `product.agentGuidance` because that text is written for website
  URL routing, not for offline file paths.

## What bundle mode skips

Per `/docs/package-docs/bundle.md`, bundle mode deliberately omits the
website-only artifacts — the same set that `isAgentReadabilityArtifactPath`
enumerates on the hosted side:

| Artifact | Hosted site | npm bundle |
|---|---|---|
| `llms.txt` | ✅ generated at site root | ❌ skipped |
| `llms-full.txt` | ✅ root full-context fallback | ❌ skipped |
| search JSON | ✅ static search index | ❌ skipped |
| sitemap files | ✅ e.g. `/docs/sitemap.xml` | ❌ skipped |
| `robots.txt` | ✅ must allow `/llms.txt` | ❌ skipped |
| `agent-readability.json` | ✅ static artifact | ❌ skipped |
| `AGENTS.md` | — (uses `llms.txt` instead) | ✅ entry point |
| `docs/*.md` | ✅ HTTP-served mirrors | ✅ bundled on disk |

## Why the split exists

The two flows answer different questions for an agent:

- **Hosted:** "What URL do I fetch?" → start at `/llms.txt`, follow links,
  optionally fall back to `/llms-full.txt`. Sitemaps, `robots.txt`, search
  JSON, and `agent-readability.json` exist only because there is a web server
  and crawlers in the loop.
- **Bundle:** "What file do I open in `node_modules`?" → start at
  `AGENTS.md`, follow relative paths into `./docs/*.md`. There is no server,
  so every web-oriented artifact (`llms.txt`, `llms-full.txt`, search JSON,
  sitemaps, `robots.txt`, `agent-readability.json`) is intentionally
  dropped, and even `product.agentGuidance` is ignored because it targets
  URL routing.
