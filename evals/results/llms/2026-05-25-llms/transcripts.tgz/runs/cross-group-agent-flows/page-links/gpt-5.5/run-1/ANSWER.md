# Cross-group agent flows: hosted vs npm bundle

Leadtype supports two complementary agent flows.

## Hosted website flow

For HTTP or URL-based agents, the flow starts at the site root file:

- `/llms.txt`

From there, agents follow page-level markdown links to generated markdown mirrors such as:

- `/docs/*.md`
- optionally the docs-scoped map `/docs/llms.txt`

Website mode also emits hosted/static artifacts for discovery, routing, search, and verification, including:

- `/llms.txt`
- `/llms-full.txt`
- `/docs/llms.txt`
- markdown mirrors under `/docs/*.md`
- sitemap files such as `/docs/sitemap.xml` and `/docs/sitemap.md`
- `robots.txt`
- `agent-readability.json`
- search JSON such as `search-index.json` and `search-content.json`

Docs pages can also be served as markdown when the request asks for `Accept: text/markdown` or when a known AI user agent requests a docs page.

## npm package bundle flow

For coding agents working inside an installed npm package, the flow starts from the package root file:

- `AGENTS.md`

`AGENTS.md` uses relative links, for example:

- `./docs/reference/cli.md`

Agents can therefore read version-matched docs directly from `node_modules` without making a network request. Bundle mode writes:

- `AGENTS.md`
- `docs/*.md`

## Website artifacts skipped by bundle mode

`leadtype generate --bundle` skips website-only artifacts. In bundle mode, Leadtype does **not** write:

- `llms.txt`
- `llms-full.txt`
- search JSON, including `search-index.json` and `search-content.json`
- sitemap files, such as `sitemap.xml` and `sitemap.md`
- `robots.txt`
- `agent-readability.json`

In short: hosted agents start at `/llms.txt` and navigate URL-based markdown, while npm-package agents start at `AGENTS.md` and navigate relative `docs/*.md` files inside the package.