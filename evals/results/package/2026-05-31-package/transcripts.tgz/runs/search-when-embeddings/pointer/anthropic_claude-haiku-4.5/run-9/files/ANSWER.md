# What leadtype gives you for docs search by default

## 1. Default docs search: Static, edge-safe BM25 index

By default, `leadtype` uses **static, local search at build time** with **no database required**:

- **Indexing method**: BM25 (probabilistic relevance ranking)
- **Index format**: Two static JSON files generated at build time:
  - `search-index.json` — compact tuple format with term postings, document references, and chunk references (small, loads on every search)
  - `search-content.json` — actual chunk text, separate from index (cheap, loaded lazily for excerpts and answers)
- **Chunking**: Heading-aware document slicing — each heading becomes a separate searchable chunk, so results jump to the exact section, not just the page
- **Ranking weights**: Titles 4×, headings 2×, body text 1×, code 0.35×. These are tunable.
- **Query processing**: 
  - Lightweight stemming
  - Prefix matching
  - Typo-tolerant fallbacks
  - Small built-in synonym map
  - Exact matches weighted highest (preserves API names and config keys)
- **Runtime**: Edge-safe, no Node APIs — works on Vercel, Cloudflare, and any edge runtime. No dependencies, stateless.
- **Optional AI layer**: Source-grounded answer streaming can wrap the retrieved chunks, but retrieval is still lexical (BM25).

**Why this is enough**: The default search handles exact API names, config keys, error messages, section paths, and guide phrases without any extra infrastructure. The lexical approach catches what users explicitly search for, and the stemming/prefix/synonym features handle vocabulary variation.

---

## 2. Specific conditions to add embeddings (and what to keep)

**Add embeddings only when:**

1. **Users search with vocabulary that doesn't appear in your docs** — e.g., someone types "make it faster" when your docs use "performance optimization." Lexical search will miss this mismatch; embeddings catch semantic intent.

2. **Your docs scale past tens of thousands of chunks** — the cold-start memory footprint of loading and decompressing the BM25 index becomes a noticeable performance hit.

**What to keep even with embeddings:**

- **Keep the BM25 lexical index.** It is complementary, not a replacement. Embeddings and lexical search excel at different things:
  - Lexical is precise for exact terminology, code snippets, and product-specific keywords
  - Embeddings are good for semantic similarity across different phrasings
- **Merge results from both approaches.** Many production RAG systems use hybrid retrieval: run both searches and blend the results (e.g., reciprocal rank fusion, weighted score combination).
- **Keep the static build process** if possible. Embeddings require either:
  - Precomputing them at build time (static, like BM25), or
  - A hosted embedding service/database at runtime (adds infrastructure)
  
  If you stay static + build-time, you avoid the database entirely. If you move to a hosted index, you lose the build-time isolation.

**Bottom line**: Embeddings are the answer when your docs use different vocabulary than users do, and your scale justifies the infrastructure. But BM25 is still doing most of the work — especially for navigation and exact-match queries. Don't replace it; layer on top of it.
