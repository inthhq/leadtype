# Leadtype Docs Search: What You Get By Default

## 1. What leadtype's docs search uses by default

Leadtype builds a **static, edge-safe BM25 lexical search index** at build time.

**Build-time process:**
- Generates two JSON files during `leadtype generate`:
  - `search-index.json` — compact ranking data with term postings and document references
  - `search-content.json` — the actual chunk text for excerpts and answer context (separated for lazy loading)

**Runtime behavior:**
- **No database, no embeddings, no API calls needed.** The index is imported or fetched and queried entirely client-side or at the edge.
- **BM25 ranking function** with tunable weights:
  - Titles: 4×
  - Headings: 2×
  - Body text: 1×
  - Code: 0.35×
- **Smart query expansion:**
  - Lightweight stemming
  - Prefix matching
  - Typo-tolerant fallbacks
  - Small built-in synonym map
  - Product-specific synonyms are optional and configurable
- **Chunk-aware indexing:** Each heading-aware slice of a page is a separate document, so search results jump to the right section, not just the right page.

**What you get:**
- Instant search with zero network calls
- Works on any edge runtime (Vercel, Cloudflare, etc.)
- Exact matches on API names and config keys stay precise and highest-ranked
- Optional source-grounded AI answers can layer on top (still pulling from the static index)

---

## 2. When adding embeddings is actually warranted—and what to keep

Add embeddings **only when both conditions are true:**

1. **Users search with vocabulary that doesn't match the docs** — e.g., searching "make it faster" when your docs say "performance optimization," and basic stemming + synonyms don't close the gap.
2. **Your docs scale past tens of thousands of chunks** — enough that the cold-start memory hit of loading the lexical index becomes noticeable.

**Keep the lexical index even then.** Embeddings are complementary, not replacements:

- Keep the BM25 index for **exact matches** on API names, config keys, error messages, and paths — these must stay precise and rank highest.
- Layer embeddings on top for **semantic fuzzy matching** on conceptual queries.
- The two approaches handle different query patterns: lexical for "findAll" (precise), embeddings for "how do I speed this up?" (conceptual).

**Bottom line:** A static, lexical search index handles the vast majority of real-world docs queries. Reach for a database-backed vector index only after proving that semantic search adds value worth its operational cost.
