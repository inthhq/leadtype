# Leadtype Docs Search: Default and When Embeddings Matter

## 1. What Leadtype Uses by Default

Leadtype generates a **static, edge-safe, BM25-based search index** with no database dependency.

### The Implementation

- **Build-time indexing**: At doc generation, the pipeline reads your markdown and builds two JSON files:
  - `search-index.json` — compact ranking data (term postings, document refs, chunk refs)
  - `search-content.json` — the actual chunk text, separated for lazy loading

- **Runtime search**: A dependency-free JavaScript function queries these static files:
  ```ts
  import { searchDocs } from "leadtype/search";
  const results = searchDocs(index, "query here", { content });
  ```

- **Ranking algorithm**: BM25 with tunable weights:
  - Titles: 4× weight
  - Headings: 2× weight  
  - Body text: 1× weight
  - Code: 0.35× weight

- **Query capabilities**: Beyond exact matching, search includes:
  - Lightweight stemming
  - Prefix matching
  - Typo-tolerant fallbacks
  - Small built-in synonym map (customizable with your own)

### Why This Works Out of the Box

- **Fast**: No network roundtrip, no database latency
- **Cost-free**: No hosted index to pay for
- **Cacheable**: Static files served from CDN
- **Edge-compatible**: Runs on Vercel, Cloudflare, browsers — anywhere
- **Chunk-aware**: Results point to specific headings, not just pages

## 2. When Embeddings Are Actually Warranted (and What to Keep)

Add embeddings **only after** meeting both conditions:

### Condition 1: Semantic Mismatch
Users search with vocabulary that doesn't match your docs. Example: "make it faster" should find a "performance optimization" page, but the BM25 index won't connect those concepts because the words don't overlap.

### Condition 2: Scale Penalty
Your docs grow past **tens of thousands of chunks** and the memory cold-start hit becomes noticeable when loading the static index.

### What to Keep Even With Embeddings

**Do not replace the BM25 index.** Layer embeddings on top instead:

1. **Keep the static lexical index for exact matches** — it's still the fastest path for API names, config keys, error messages, and paths. Users typing "useState" or "400 error" get instant precise results.

2. **Use embeddings as a complementary fallback** — when lexical search doesn't find good results, fetch embeddings to catch semantic intent.

3. **Maintain the static generation pipeline** — keep building `search-index.json` and `search-content.json` at build time. Do not shift to database-backed indexing. The static files remain your source of truth and are always deployable.

### Why This Hybrid Approach

Lexical and semantic search are **complementary, not replacements**. The index handles the 80% case (exact terminology) cheaply; embeddings cover the 20% case (conceptual synonyms) with embedded models or API calls. Removing BM25 loses precision, speed, and the ability to serve search without external dependencies.

---

**Bottom line**: Before building hosted infrastructure, ship the default static search. Try it with actual users. Only add embeddings if you hit the specific conditions above — and keep the BM25 index as your primary search mechanism.
