# What Leadtype Gives You for Docs Search

## 1. Leadtype's Default Docs Search

By default, **leadtype generates a static, edge-safe search index** that works entirely at the client/edge level — no database required.

### How it works:
- **Build-time indexing**: `leadtype generate` reads your markdown and produces two JSON files:
  - `search-index.json` — a compact ranking index with term postings and document refs
  - `search-content.json` — the actual chunk text, separated for lazy loading

- **Runtime search algorithm**: BM25 ranking with:
  - **Lexical matching** as the foundation (exact tokens and stems)
  - **Prefix matching** for partial terms
  - **Typo-tolerant fallbacks** for misspellings
  - **Built-in synonym map** for common variations
  - **Weighted fields**: Titles 4×, headings 2×, body text 1×, code 0.35×
  - Results jump to the exact heading (chunks are heading-aware), not just the page

- **Optional lightweight enhancements**:
  - Add product-specific **vocabulary aliases** (synonyms) when users search with words your docs don't use
  - Layer on **source-grounded answers** that retrieve chunks, build a constrained prompt, and stream responses via any LLM provider

### Why this works well:
- ✅ Static — generated at build time, no infrastructure needed
- ✅ Edge-safe — runs on Vercel, Cloudflare, or anywhere; no Node APIs
- ✅ Fast — loads two small JSON files, queries locally
- ✅ Cost-effective — zero database costs, minimal bandwidth
- ✅ Exact matches stay precise — API names and config keys don't get fuzzy
- ✅ Answers cite sources — built from retrieved docs chunks, not model hallucination

---

## 2. When Embeddings Are Actually Warranted

**Do not add embeddings (or a hosted vector index) unless you meet specific conditions:**

### Only add embeddings when:

1. **Users search with vocabulary that doesn't match your docs**
   - Example: "make it faster" should match a "performance optimization" page, but lexical search fails
   - You've tried product-specific synonyms and they're insufficient
   
2. **Your docs grow past tens of thousands of chunks**
   - The cold-start memory hit of loading the index becomes noticeable
   - Semantic search adds negligible overhead at that scale

### What to keep even if you add embeddings:

- ✅ **Keep the lexical BM25 index** — don't replace it
- ✅ **Layer embeddings on top** — they're complementary, not replacements
  - Lexical search handles exact matches (API names, config keys, error messages)
  - Embeddings handle semantic queries where vocabulary doesn't align
- ✅ **Keep the static generation pipeline** — embeddings can be generated at build time too; you don't need a hosted vector database
- ✅ **Keep the source-grounded answer flow** — retrieve from both indices, let the model see all candidates

### The default recommendation:
Start with the static lexical index. Test it with real users. Add embeddings only if you have measurable evidence that search quality requires semantic understanding rather than better vocabulary coverage.
