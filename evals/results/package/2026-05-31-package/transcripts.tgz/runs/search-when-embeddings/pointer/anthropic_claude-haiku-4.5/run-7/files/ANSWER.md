# Leadtype's Default Docs Search

## 1. What Leadtype's Docs Search Uses by Default

Leadtype uses a **static, edge-safe, BM25-based lexical search index** — no database required.

### How it works:

- **Build time:** `leadtype generate` creates two JSON files:
  - `search-index.json` — compact ranking data with term postings and document references
  - `search-content.json` — the actual chunk text (separate from the index)

- **Runtime:** Import or fetch those JSON files. The runtime queries them **locally without touching a database** (works on Vercel, Cloudflare, anywhere edge-safe code runs).

- **Ranking function:** BM25 with tunable weights:
  - Titles: 4× weight
  - Headings: 2× weight
  - Body text: 1× weight
  - Code: 0.35× weight

- **Query expansion:** Beyond exact matching, the search handles:
  - Lightweight stemming (e.g., "run" matches "running")
  - Prefix matches
  - Typo-tolerant fallbacks
  - A small built-in synonym map
  - Optional product-specific vocabulary aliases (e.g., "starter" → "quickstart")

- **Chunk-aware:** Results jump to the right section (heading), not just the right page. Each heading-aware slice is a separate document in the index.

### Why this is sufficient for most use cases:

✅ **Fast** — no network round-trips for searching; results are instant  
✅ **Cheap** — no hosting or infrastructure; static files on any CDN  
✅ **Edge-safe** — no Node.js APIs; runs everywhere  
✅ **Good for API names, config keys, error messages, and common terminology** — exact matches are weighted highest  

---

## 2. When to Add Embeddings (and What to Keep)

### Only add embeddings when:

1. **Users search with vocabulary that doesn't match your docs**  
   Example: Users search "make it faster" but your docs only say "performance optimization"

2. **Your docs grow past tens of thousands of chunks**  
   The cold-start memory hit of loading the lexical index becomes noticeable

### Critical: Keep the lexical index even after adding embeddings

The two approaches are **complementary, not replacements**. The guidance is explicit:

> "Even then, keep the lexical index for exact matches and layer embeddings on top — they're complementary, not replacements."

### What to keep:
- The static BM25 index (`search-index.json`) for exact API names, config keys, and known terminology
- Layer embeddings **on top** to catch semantic variations your vocabulary doesn't explicitly document
- Use both in search results — combine their rankings for the best coverage

### Why this hybrid approach:

- Lexical search excels at **precision** (exact matches get highest weight)
- Embedding search excels at **semantic recall** (related but differently-worded content)
- Together, they handle both the users who know what to search for and those exploring with loose terminology

---

## Conclusion

**Before building a hosted vector index:** Use leadtype's static, edge-safe BM25 search. It's production-ready, requires zero infrastructure, and solves 90% of use cases. Only layer in embeddings if you've actually observed users struggling to find docs because your vocabulary differs from theirs — and keep the lexical index as your foundation.
