# Docs search with `leadtype` — what you already have, and when embeddings are warranted

> TL;DR: `leadtype` ships a **static, edge-safe BM25 (lexical) search index** out of the
> box — no database, no server, no embeddings, no vector store. Before standing up a
> hosted vector index "because RAG," check whether your retrieval problem actually needs
> dense embeddings. Most docs sets do not. When it does, **add embeddings as a second
> retrieval signal on top of BM25 — don't replace it.**

---

## 1. What leadtype's docs search uses by default

leadtype generates a **static search index from your MDX/markdown at build time** and
queries it client-/edge-side. There is no database and no running search service.

**Retrieval model: BM25 (classic lexical / keyword ranking).**

Confirmed in the package source (`leadtype@0.1.2`, `dist/_shared/search-*.js`):

- **BM25 scoring** with the standard parameters `k1 = 1.2`, `b = 0.75`, plus
  inverse-document-frequency weighting over an inverted index (`index.terms`).
- **Field weighting** so structure matters: title ×4, headings ×2, body ×1, code ×0.35.
- **Build-time index creation** (`createDocsSearchIndex` / `generateDocsSearchFiles`)
  that chunks docs (~1200 chars with ~160-char overlap), tokenizes, and emits a JSON
  index — e.g. `public/docs/search-index.json`. The README calls this a
  "static, edge-safe search index (BM25)."
- **Lexical query expansion instead of semantic similarity** — it bridges the
  vocabulary gap without any embeddings:
  - light **stemming** (`installing` → `install`),
  - a built-in **synonym** map (e.g. `ai`→`agent`/`llm`, `config`→`configure`/`settings`,
    `ts`→`typescript`),
  - **prefix / autocomplete** expansion,
  - **typo tolerance** via bounded edit distance,
  - **phrase and proximity boosts** for multi-word queries.
- **No vectors anywhere.** A full-source search for `embedding | vector | cosine | dense |
  hybrid | semantic similarity` across `dist/` turns up nothing. The only "semantic"
  hits are semver strings and comments.

**"Source-grounded answers" (the optional RAG-style answer feature) are also BM25-based.**
`createAnswerContext` runs the *same BM25 `searchDocs`*, takes the top N chunks
(default 6, capped at ~12k chars), and assembles them into a grounded prompt + system
message for an LLM (via the `leadtype/search/vercel`, `/tanstack`, or `/cloudflare`
adapters). The retrieval step is lexical; the LLM only summarizes and **cites** the
retrieved doc chunks. So leadtype already gives you a retrieval-augmented answer flow
**with zero embeddings and zero vector database.**

### What this means for the proposal

The hosted, database-backed vector index is **not the baseline you have to build to get
docs search or even RAG answers** — leadtype already covers both with a static artifact.
A vector DB is a heavier, additional piece of infrastructure (hosting, indexing jobs,
embedding API costs/latency, sync with content), and for typical product docs BM25 with
the expansions above is strong: docs are keyword-rich, users search for exact API names,
flags, and error strings, and a static index is cheap, offline-capable, and edge-safe.

---

## 2. When adding embeddings is actually warranted — and what to keep

Add embeddings only when you have **evidence** that lexical retrieval is the bottleneck,
not by default. Concretely, embeddings are warranted when **all** of these hold:

1. **You have measured a real recall gap that expansion can't close.** You can point to
   queries that fail because they're conceptual/paraphrased ("how do I make my docs
   readable by AI agents?" vs. the page titled "llms.txt"), where the synonym map,
   stemming, prefix, and typo expansion still miss. If a few synonym-map entries or
   better headings fix it, do that first — it's free and stays static.
2. **The vocabulary mismatch is intrinsic**, e.g. large multilingual or natural-language
   "ask a question" traffic, or end-user support content where users and docs use very
   different words. (Pure API/CLI reference lookups rarely qualify.)
3. **Your corpus is large/diverse enough** that the ranking quality gain justifies the
   added embedding pipeline, storage, and per-query latency/cost.
4. **You can keep the index reliably in sync** with content changes (re-embedding on
   every docs build) without that becoming an operational burden.

If you don't have a measured failure mode, you don't yet have a reason to build the
vector index.

### What to keep even then

- **Keep BM25 — go hybrid, not vector-only.** Embeddings are weak at exact-match terms
  that dominate docs: API names, flags (`--base-url`), error codes, version strings,
  symbol names. Use embeddings as an **additional retrieval signal fused with BM25**
  (e.g. rank fusion / reranking), so lexical precision is preserved. Replacing BM25 with
  pure vector search typically *regresses* these high-value queries.
- **Keep leadtype's build-time index as the lexical half** of that hybrid and as a
  zero-dependency fallback (offline, edge, agent/bundle consumers via `AGENTS.md`).
- **Keep the existing source-grounded answer flow and its guardrails.** leadtype's
  `createAnswerContext` already enforces good RAG hygiene — answer only from provided
  context, treat doc excerpts as untrusted (prompt-injection guard), require bracket
  citations, and refuse to invent APIs/paths. Whatever retrieves the chunks (BM25,
  hybrid, or vectors), feed them through this same grounding + citation + guardrail
  layer rather than rebuilding it.
- **Keep query validation and rate limiting** (`validateDocsQuery`, request-body size
  limits, `createMemoryRateLimiter`, client-identifier helpers) that ship with the
  search runtime for any hosted endpoint.

### Recommendation

Ship leadtype's default BM25 static index now. Instrument search to capture
zero/low-result and "ask" queries. Only if those logs show a persistent semantic-recall
gap that synonyms/headings can't fix, add an embedding signal **in hybrid with BM25**,
reusing leadtype's grounding/guardrail layer — rather than starting from a hosted vector
database.
