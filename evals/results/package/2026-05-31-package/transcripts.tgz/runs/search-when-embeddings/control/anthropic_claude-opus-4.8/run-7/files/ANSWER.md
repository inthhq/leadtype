# Does `leadtype` already give us docs search? (Before building a hosted vector index)

**Short answer:** Yes. `leadtype` ships a complete, working docs-search system out of the box. It is **keyword/lexical search (BM25), not embeddings**, and it is deliberately designed to run without a database or hosted vector service. Stand up the hosted vector index only if you hit one of the specific limitations below — and even then, keep what leadtype already gives you.

---

## 1. What leadtype's docs search uses by default

leadtype generates a **static, edge-safe search index** at build time and queries it with a **BM25 ranking function**. There is no server, no database, and no embedding model in the default path.

Concretely, from the installed package (`leadtype/search` and `leadtype/search/node`):

### Index generation (build time)
- `generateDocsSearchFiles` / `createDocsSearchIndex` flatten your docs into markdown, split them into **chunks** (default ~1200 chars with ~160-char overlap), and build an **inverted index** (`terms → postings`).
- Output is a plain JSON file (e.g. `public/docs/search-index.json`) — a static artifact you ship with your site. Content can be embedded in the index or split into a separate content file (`embedContent` option).
- Index format is versioned (`SEARCH_INDEX_VERSION`), so it's a stable, portable artifact.

### Query (runtime, edge-safe)
- `searchDocs` scores chunks with **Okapi BM25** (`k1 = 1.2`, `b = 0.75`) over the inverted index.
- It is **field-weighted**: title (×4), headings (×2), body (×1), code (×0.35), so matches in titles/headings rank higher than incidental body matches.
- The tokenizer does real lexical work, which is why keyword search is good enough for most docs:
  - Unicode-aware tokenization, lowercasing, and **diacritic stripping** (NFKD normalization).
  - **Stopword** removal.
  - Lightweight **stemming** (plurals / `-ing` / `-ed` / `-es` / `-ies`).
  - **Synonym expansion** (built-in map, e.g. `ai → agent/llm`, `config → configure/settings`; extendable via `options.synonyms`).
  - **Prefix matching** (autocomplete-style), and **typo tolerance** via bounded edit distance.
  - **Phrase and ordered-proximity boosts** for multi-word queries.
- It runs entirely client-side or at the edge — the React/Next/TanStack/etc. adapters (`leadtype/search/*`) are thin state/routing primitives over this same static index. No backend round-trip is required for plain search.

### Optional "ask"/answer mode (still no embeddings)
- `createAnswerContext` provides **source-grounded answers**: it runs the same BM25 search, selects the top sources (default 6, capped by `maxContextChars ≈ 12k`), and assembles a citation-ready prompt + system message for an LLM.
- The system prompt enforces grounding: *use only provided context, cite sources `[1]`/`[2]`, don't invent APIs/paths, treat docs as untrusted reference text.*
- The actual answer text is produced by whatever model you wire up (Vercel AI SDK, TanStack, Cloudflare adapters). **Retrieval is still lexical BM25** — the index itself contains no vectors.

### What is explicitly NOT in the package
A content search of the installed package confirms there is **no embedding model, no vector store, no semantic/ANN search, and no database** anywhere in leadtype. "RAG-style" answering is supported, but its retrieval layer is the static BM25 index.

**Bottom line for #1:** Default docs search = a versioned static JSON index built at compile time, queried with field-weighted BM25 plus stemming, synonyms, prefix/typo tolerance, and phrase/proximity boosts, runnable at the edge with zero infrastructure. Optional source-grounded LLM answers reuse that same lexical retrieval.

---

## 2. When adding embeddings is actually warranted (and what to keep)

Embeddings + a hosted vector index are a real cost (a service to run, a DB to back it, an embedding model to call and pay for, re-embedding on every docs change, and an extra network hop per query). For a docs corpus, BM25 is usually competitive or better, because docs queries are heavy on exact terms — API names, flags, error strings, file paths — which lexical search nails and embeddings often blur.

Add embeddings **only if you have evidence of a gap that lexical search structurally cannot close**, specifically:

1. **Vocabulary-mismatch / conceptual queries dominate.** Users routinely search by intent/paraphrase using words that don't appear in the docs (e.g. "make my site show up in ChatGPT" → the `llms.txt` page), and you've confirmed leadtype's **synonym map and stemming don't recover these** even after you extend `options.synonyms`. Semantic similarity helps here; keyword matching can't.
2. **Cross-lingual or multilingual retrieval** where the query language differs from the doc language and you can't maintain synonym/translation mappings.
3. **Large, sprawling corpus** where you have measured (not assumed) poor recall — relevant pages exist but don't surface in the top results despite tuned field weights and synonyms.
4. **You've already exhausted the cheap tuning levers** leadtype exposes — synonyms, field weights, chunk size/overlap, query expansion — and measured a recall/relevance deficit on real query logs. "That's how RAG is done" is not a condition; a measured retrieval gap is.

If none of these hold, the hosted vector index is added cost and operational surface for no measurable gain. Default BM25 is the recommended baseline.

### What to keep even if you add embeddings

Do **not** rip out the existing system. Treat embeddings as an *augmentation*, not a replacement:

- **Keep the BM25 static index and run hybrid retrieval.** Combine lexical + vector results (e.g. score fusion / reciprocal-rank fusion). BM25 remains the strong signal for exact terms — API names, flags, error codes, paths — which is exactly where pure vector search regresses. Hybrid beats either alone for docs.
- **Keep the static index as the zero-dependency / fallback path.** It works at the edge with no service to fail; if the vector service is down or you're in an offline/bundled context, lexical search still answers.
- **Keep leadtype's build pipeline as the source of truth:** the same chunking (`createDocsSearchIndex`), heading/anchor metadata, field structure, and content store. Embed *those* chunks so retrieval, citations, and anchors stay consistent across both paths.
- **Keep `createAnswerContext`'s grounding contract:** source citations, the "use only provided context / don't invent APIs" system prompt, and `maxSources`/`maxContextChars` limits. Embeddings change *how* sources are retrieved, not the grounded-answer discipline that prevents hallucination.
- **Keep the request guards** (`validateDocsQuery`, `readJsonWithLimit`, the memory rate limiter, client identification) on whatever endpoint now fronts the vector service.

**Bottom line for #2:** Warranted only when measured semantic/multilingual recall gaps remain after tuning leadtype's lexical knobs — and even then, add it as a *hybrid* layer on top of the existing BM25 index, the leadtype chunking/build pipeline, the grounded-answer contract, and the static fallback path. Don't replace; augment.
