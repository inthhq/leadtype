# What Leadtype already gives us for docs search

## Default search model

Leadtype does **not** default to a hosted database or a vector index. Its default docs search is a generated, static, edge-safe lexical index:

- `leadtype generate` emits `docs/search-index.json` for a hosted docs site.
- The runtime loads generated JSON artifacts and searches them in-process, so it can run in the browser, at the edge, or in a simple server route without a search service.
- The index is built from flattened Markdown docs, split into overlapping chunks.
- Ranking is BM25-based, with separate weights for title, heading, body, and code.
- It also includes practical lexical improvements: normalization, stopword removal, simple stemming, built-in and custom synonyms, prefix expansion, typo tolerance, phrase/proximity boosts, excerpts, and result limits.
- For “ask the docs”/RAG-style answers, Leadtype can build a source-grounded answer context from the top search results and stream an LLM answer through its AI adapters. That answer context is still grounded in the static BM25 search results by default, not embeddings.

In other words: Leadtype already gives us a versionable, deployable docs search index and source-grounded answer plumbing without standing up a vector database.

## When embeddings are actually warranted

Adding embeddings is warranted only if we can show a retrieval problem that lexical search cannot solve well enough. Good triggers would be:

1. **Measured semantic misses:** query logs, support tickets, or a golden test set show users asking with different vocabulary than the docs use, and relevant pages do not share enough terms for BM25/synonyms to find them.
2. **Paraphrase-heavy or conceptual queries:** users commonly ask broad intent questions where the right answer is semantically related but not lexically similar.
3. **Cross-language or vocabulary-bridging needs:** users query in one language/domain vocabulary while docs are written in another, and synonym tuning is not enough.
4. **Scale or product constraints that exceed static artifacts:** the corpus becomes too large, too dynamic, too personalized, or too access-controlled for a single static JSON index to remain practical.
5. **Evaluation proves a hybrid index wins:** an embedding prototype improves recall/answer quality on real queries without unacceptable latency, cost, freshness, or operational complexity.

Even then, we should **keep Leadtype’s generated docs artifacts and BM25 search**. Use embeddings as an additional retrieval signal, not a replacement. BM25 remains better for exact API names, code symbols, option names, error strings, URLs, headings, and version-specific identifiers. A hybrid approach should keep Leadtype as the source-of-truth docs pipeline, preserve its chunking/Markdown outputs, keep source-grounded citations and answer-context construction, and combine vector recall with BM25 precision/reranking.