# Do we need a hosted vector index for docs search?

**Short answer: almost certainly not — at least not to start.** `leadtype` (v0.1.2,
the version installed in `node_modules/leadtype`) already ships a complete docs
search system that runs without a database, a server, or an embeddings provider.
Build on what it gives you first; only reach for embeddings under the narrow
conditions below, and even then keep the existing pieces.

## 1. What leadtype's docs search uses by default

leadtype builds a **static, edge-safe lexical (keyword) search index** at build
time and queries it with **BM25 ranking**. There is no vector database and no
embedding model in the default path.

Concretely, `leadtype generate` (or `generateDocsSearchFiles` /
`createDocsSearchIndex`) produces JSON artifacts — `search-index.json` and
`search-content.json` — that are served as plain static files from your existing
host/CDN. The runtime query (`searchDocs`, used by `createSearchClient`,
`useLeadtypeSearch`, etc.) is pure JavaScript that runs in the browser, an edge
worker, or Node. No infrastructure to stand up, no per-query API cost.

What's inside that lexical index, from `dist/_shared/search-TL9muun_.js`:

- **BM25 scoring** with the standard saturation/length-normalization params
  (`k1 = 1.2`, `b = 0.75`), and an inverse-document-frequency term.
- **Field weighting** so matches in titles/headings rank above body and code:
  title ×4, heading ×2, body ×1, code ×0.35.
- **Content-aware chunking** — documents are split by heading sections into
  overlapping chunks (~1200 chars, 160-char overlap), each carrying its heading
  path and anchor, so results deep-link to the right section.
- **Query expansion that recovers a lot of what people assume only embeddings
  give you**, all without a model:
  - light **stemming** (e.g. `installing`/`installed` → `install`),
  - a built-in **synonym map** (`ai`→`agent`/`llm`, `config`→`configure`/
    `settings`, `auth`→`authentication`/`login`, `install`→`setup`/`add`, …)
    plus your own custom synonyms,
  - **prefix / partial-word** matching,
  - **typo tolerance** via bounded edit distance,
  - **phrase and proximity boosts** for multi-word queries,
  - **stopword removal** and Unicode/diacritic normalization.
- **Source-grounded answers (optional)** via `createAnswerContext`, which runs
  the same BM25 search to retrieve the top sources, then builds a cited prompt
  + system message for an LLM (with adapters for Vercel AI SDK, TanStack AI, and
  Cloudflare). This is retrieval-augmented answering — **the "RAG" your team is
  describing — already wired up on top of lexical retrieval, no vector store
  required.** There are also read-only "bash" adapters for agent tools.

So the default stack is: **build-time static index → BM25 + query expansion →
static-file/edge query → optional cited LLM answers.** Keyword search, served
from files you already host.

## 2. When adding embeddings is actually warranted — and what to keep

Embeddings/semantic search solve one specific problem: matching queries to
content that shares **meaning but not vocabulary** (synonyms/paraphrases the
built-in synonym map and stemming don't cover). They are *not* a prerequisite
for RAG, deep-linking, or good results on a typical docs corpus.

Add embeddings only when **all** of these hold:

1. **You have measured a real recall gap.** Real user/agent queries are failing
   in a way that is specifically *semantic* — users phrase things in words that
   never appear in the docs — and the failures persist after you've used the
   cheap levers first: adding **custom synonyms**, improving titles/headings
   (which are weighted heavily), and tuning chunking. If you haven't tried those,
   you're not ready for embeddings.
2. **The corpus is large and/or naturally-language-heavy enough** that keyword
   overlap genuinely breaks down (broad knowledge bases, support content), not a
   focused product-docs set where users already use product vocabulary.
3. **You can justify the new operational cost and complexity** — an embedding
   model/provider, an index to build and re-embed on every docs change, and (if
   hosted) a service to run — against the gain you measured in (1). The default
   path has none of these; a hosted DB-backed index reintroduces all of them.

**Even then, keep the lexical layer — don't replace it.** Specifically:

- **Keep BM25 lexical search and run it alongside embeddings (hybrid).** Keyword
  search beats vectors on exact terms, identifiers, API/option names, code,
  flags, and error strings — exactly the high-value queries in developer docs.
  Best practice is to combine lexical + semantic scores, not swap one for the
  other.
- **Keep leadtype's chunking, heading paths, anchors, and citation/answer
  context.** These are independent of how you retrieve. Embeddings change only
  the *retrieval/ranking* step; you'd feed your hybrid results into the same
  `createAnswerContext` grounding + citation machinery and the same UI
  client/hooks. Reusing this is what keeps deep-linking and source-grounded
  answers working.
- **Prefer static/edge-friendly delivery.** If you do add embeddings, weigh
  edge-friendly approaches before committing to a hosted, database-backed
  service — that hosted index is the single biggest cost/complexity jump and is
  rarely needed for docs-sized corpora.

### Bottom line
leadtype already gives you static, BM25-based keyword search with stemming,
synonyms, typo tolerance, phrase/proximity ranking, section deep-links, and
optional cited LLM answers — served from static files with zero backend. Ship
that, instrument it, and tune synonyms/headings first. Treat a hosted vector
index as a later, measured optimization for a proven semantic-recall gap on a
large corpus — added *as a hybrid layer that preserves* leadtype's lexical
search, chunking, and answer-grounding, not as a replacement for them.
