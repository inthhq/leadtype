# Leadtype docs search vs. a hosted vector index

## 1. What Leadtype uses by default

Leadtype’s built-in docs search is **not** a hosted database-backed vector index. By default it generates a **static, edge-safe lexical search index** from the flattened Markdown docs.

In site generation mode, `leadtype generate` writes docs artifacts under the output directory, including the docs Markdown plus search artifacts such as `docs/search-index.json` and `docs/search-content.json`. Those JSON files can be served as static assets and queried from the browser, an edge function, or server code using `leadtype/search` / `leadtype/search/client`.

The runtime search is BM25-style lexical retrieval over chunks of the docs:

- docs are split into section-aware chunks;
- default chunk sizing is about `1200` characters with `160` characters of overlap;
- title, heading, body, and code matches are weighted differently;
- query handling includes tokenization, stopword removal, light stemming, built-in/custom synonyms, prefix expansion, typo tolerance, and phrase/proximity boosts;
- results include excerpts, URLs, anchors, headings, and scores.

Leadtype also includes source-grounded answer helpers (`createAnswerContext` and framework/AI adapters) that retrieve matching chunks from the same generated artifacts and build a prompt with citations. That is RAG-style retrieval over local/static docs artifacts, but it does **not** require embeddings, a vector database, or a hosted search service.

## 2. When embeddings are actually warranted — and what to keep

Add embeddings only if we can show that the default Leadtype search is not enough for our docs search workload. Good reasons are specific and measurable:

- real query logs or an evaluation set show poor recall for natural-language questions where the relevant page uses different vocabulary than the query;
- users ask conceptual/semantic questions that cannot be fixed well with better headings, page titles, content, redirects, or Leadtype synonym tuning;
- the corpus is large or diverse enough that lexical BM25 misses important related material even after chunking/tuning;
- we need cross-language or paraphrase-heavy retrieval where exact terms are unreliable;
- we have measured that embeddings improve answer quality/recall enough to justify the added cost, latency, privacy review, indexing pipeline, re-embedding/staleness handling, and operational complexity.

Even then, do not replace Leadtype’s defaults outright. Keep:

- Leadtype’s flattened Markdown/docs pipeline as the canonical source of retrievable content;
- the generated static BM25 index as a fast keyword/exact-match path, fallback, and hybrid first-stage signal;
- Leadtype’s chunk metadata, URLs, anchors, headings, excerpts, and source citations;
- the source-grounded answer pattern: answers should cite retrieved documentation chunks and say when context is insufficient;
- request/query limits and other guardrails around any answer endpoint.

If embeddings are added, the safer shape is **hybrid search**: use Leadtype’s BM25/static artifacts for precision, exact API names, code terms, and fallback behavior, add vector retrieval only for semantic recall gaps, then rank/merge results and continue answering strictly from cited docs sources.