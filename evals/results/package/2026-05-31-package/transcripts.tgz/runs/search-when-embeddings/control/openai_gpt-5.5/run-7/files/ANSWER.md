# Leadtype docs search and embeddings

## 1. What Leadtype uses by default

Leadtype already ships a docs-search system. By default it is **not** a hosted database-backed vector index.

It generates **static JSON search artifacts** from the flattened markdown docs during `leadtype generate` / `generateDocsSearchFiles`:

- `docs/search-index.json`
- `docs/search-content.json` unless content is explicitly embedded in the index

The runtime search is an **edge-safe, local BM25 lexical index**. It:

- chunks markdown by headings/sections, with overlapping chunks;
- indexes title, heading, body, and code text with different weights;
- uses BM25 scoring;
- expands matches with built-in/custom synonyms, light stemming, prefix matching, typo tolerance, phrase boosts, and proximity boosts;
- returns source metadata, URLs/anchors, excerpts, and scores;
- can build a source-grounded answer context via `createAnswerContext` / answer streaming adapters.

So the default path is: **build-time static index + client/edge search over JSON**, with no search server, no database, and no embeddings required.

## 2. When embeddings are warranted, and what to keep

Add embeddings only if we have evidence from real docs-search traffic or evaluation queries that Leadtype's lexical/BM25 search is not enough. Specific cases that can justify it:

- Users ask mostly **semantic or conceptual questions** where the correct page does not share the same words, stems, synonyms, product terms, API names, or code identifiers as the query.
- There is persistent **vocabulary mismatch** that cannot reasonably be fixed with better titles/headings/descriptions, docs wording, or Leadtype's synonym support.
- We need **cross-language or paraphrase-heavy retrieval** where lexical matching is expected to miss relevant chunks.
- A measured search-quality test set shows low recall for important queries after tuning docs structure, metadata, synonyms, and chunking.
- The corpus is large enough or heterogeneous enough that a hybrid semantic layer materially improves recall despite added cost, latency, operational complexity, and freshness concerns.

Even then, we should keep Leadtype's default search artifacts and BM25 path. Use embeddings as an additional or second-stage/hybrid retriever, not as a replacement, because BM25 is still better for:

- exact API names, option names, CLI flags, package names, error messages, code identifiers, and paths;
- deterministic fast fallback when the embedding service or vector DB is unavailable;
- cheap client/edge search with no hosted dependency;
- source grounding: Leadtype already produces chunk text, URLs, headings, excerpts, and citation-ready answer context that an LLM answer layer should continue to use.

Recommended approach: start with Leadtype's static BM25 index, measure search misses, tune docs/synonyms first, and only add embeddings if the remaining misses are genuinely semantic. If embeddings are added, run a **hybrid BM25 + vector retrieval** pipeline and keep Leadtype's chunks/source metadata as the citation and grounding layer.
