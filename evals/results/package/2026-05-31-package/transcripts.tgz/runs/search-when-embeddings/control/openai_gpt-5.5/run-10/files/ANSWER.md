# Leadtype docs search vs. hosted vector search

## 1. What Leadtype uses by default

Leadtype already builds a **static, edge-safe lexical search index** for docs. Its default docs search is **not** a hosted database-backed vector index and does **not** require embeddings.

Concretely, Leadtype:

- converts docs to clean markdown;
- chunks the markdown into overlapping sections (defaults include 1,200-character chunks and 160-character overlap);
- writes generated JSON artifacts such as `docs/search-index.json` and, unless content is embedded, `docs/search-content.json`;
- ranks results with **BM25** over title, heading, body, and code fields, with extra handling for stemming, configured/default synonyms, prefix matches, typos, phrase matches, and proximity matches;
- can build source-grounded answer prompts from the top lexical search results, with citations back to the matching docs chunks.

So the default model is: **ship static search artifacts with the docs site, load them from the client/edge/server, and run BM25 locally/in memory.** There is no separate search service to operate by default.

## 2. When embeddings are actually warranted

Add embeddings only if we have evidence that Leadtype's built-in lexical search is not enough for our actual docs/search workload. Good triggers would be:

- users ask broad, conceptual, or heavily paraphrased questions where the right page shares few or no keywords with the query;
- the docs contain many semantically similar topics where keyword ranking consistently misses intent even after improving titles/headings/content and adding synonyms;
- we need cross-language or natural-language semantic matching beyond Leadtype's i18n docs selection and lexical term matching;
- the corpus becomes large enough that static artifacts are too big or too slow for the target runtime, after scoping/splitting the index has been tried;
- evaluation data shows unacceptable recall for real queries, and embeddings measurably improve recall/answer quality.

Even then, we should **keep Leadtype's generated docs artifacts and BM25 path**:

- keep the Leadtype markdown/chunk pipeline as the canonical source of searchable docs content;
- keep BM25 as the exact-match/keyword fallback and often as a first-stage or hybrid retriever;
- keep citations/source-grounding from Leadtype chunks so generated answers quote the docs rather than inventing behavior;
- keep the static index for local development, offline/package docs, edge-safe fallback, and debugging retrieval failures.

In short: start with Leadtype's default static BM25 search. Reach for embeddings only when measured semantic-recall problems justify the extra database, embedding generation, synchronization, cost, and operational complexity.