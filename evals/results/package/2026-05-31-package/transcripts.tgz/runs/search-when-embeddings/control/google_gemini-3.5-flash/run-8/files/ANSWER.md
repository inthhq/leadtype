# leadtype Docs Search Evaluation

## 1. What `leadtype` Docs Search Uses By Default

By default, `leadtype` provides a **static, edge-safe, keyword-based (lexical) search engine** built directly into the client or edge runtime. It completely avoids the overhead, complexity, and latency of a hosted database or server-side retrieval engine. 

### Core Retrieval Algorithm: Okapi BM25
The core search algorithm relies on the industry-standard **Okapi BM25** probabilistic relevance ranking algorithm. When building the search index, `leadtype` generates a compact, pre-computed `search-index.json` and a separate `search-content.json` which can be served statically. 

The BM25 algorithm uses standard hyperparameters:
* **$k_1 = 1.2$** (term frequency saturation control).
* **$b = 0.75$** (document length normalization scaling).

### Parsing and Chunking Pipeline
* **Flat MDX Parsing**: It strips frontmatter and flattens MDX components into clean markdown, identifying section blocks by headers.
* **Overlapping Chunking**: It segments the clean markdown and code text into overlapping semantic blocks (default chunk size `maxChunkChars = 1200` characters, overlap `overlapChars = 160` characters).
* **Field-Specific Weighting**: Terms are indexed with different weights based on where they appear to ensure section context takes precedence:
  * **Title**: `4.0`
  * **Heading**: `2.0`
  * **Body**: `1.0`
  * **Code block**: `0.35`

### Query Optimization and Heuristics
`leadtype` enhances standard lexical search with robust local processing features:
1. **Normalization & Stopwords**: Query terms and indexed content are normalized (lowercased, NFKD unicode normalization, diacritics stripped). Common stopwords (e.g., *a, an, and, are, with*) are filtered out to improve signal-to-noise ratio.
2. **Custom Stemming**: Employs a lightweight suffix stemmer for English pluralization and tense rules (e.g., `ies` -> `y`, `ing` -> ``, `ed` -> ``, `es` -> ``, `s` -> ``) on words with a length of 4 or more.
3. **Synonym Expansion**: Uses built-in common developer synonyms (e.g., `ai: ["agent", "llm"]`, `auth: ["authentication", "login", "signin"]`, `ts: ["typescript"]`, `install: ["setup", "add"]`) alongside user-defined custom synonyms.
4. **Prefix Matching**: Performs prefix-matching expansions on terms of length $\ge 4$ (up to 24 prefix expansions) to provide autocomplete-like behaviors.
5. **Typo Tolerance**: Uses Levenshtein edit distance (threshold of 1 for 4-6 letter words, 2 for $\ge 7$ letter words) up to 16 expansions to gracefully catch misspellings.
6. **Phrase and Proximity Boosts**: 
   * **Phrase Match Boost ($1.4\times$)**: Applied if the exact sequence of query tokens is found consecutively in a chunk.
   * **Proximity Match Boost ($0.8\times$)**: Applied for ordered, near-proximity occurrences of the query tokens within an 8-token window.

### Built-in RAG Support (`createAnswerContext`)
For RAG (Retrieval-Augmented Generation) pipelines, `leadtype` provides the server/edge helper `createAnswerContext` which:
1. Performs BM25 search on the index with the query.
2. Extracts and slices raw chunk contexts up to a character limit (default `maxContextChars = 12000` across up to `maxSources = 6` sources).
3. Auto-generates pre-baked, citation-aware **System Instructions** and a structured **User Prompt** containing cited blocks (e.g., `[1] API Reference`, `[2] ...`). This prompt is fully optimized for downstream streaming with the LLM.


---

## 2. When Are Embeddings (Vector Search) Actually Warranted?

Vector embeddings are excellent but add infrastructure complexity (vector databases, embedding models/APIs, ingestion pipelines, extra costs, and added latency). Adding vector embeddings is only warranted under specific conditions:

### When Embeddings are Warranted:
1. **Highly Conceptual or Abstract Queries**: When users ask high-level, semantic, or conceptual questions where the search vocabulary doesn't match literal keywords (e.g., querying *"how do I prevent unauthorized crawlers"* instead of searching for *"robots.txt user-agent blocking"*).
2. **Cross-Lingual Retrieval**: If documentation is written in English, but users query in Spanish, Japanese, or other languages. Multi-lingual embeddings resolve semantic meaning across language boundaries without requiring manual localization/translation of search index synonyms.
3. **Conversational QA (Chatbots)**: For open-ended chat assistants where users ask conversational questions (e.g., *"Why is my build failing with code 137?"*), which require a deeper understanding of relationship patterns rather than keyword frequency.
4. **Massive and Extremely Diverse Corpuses**: When your documentation spans millions of lines, making local JSON indexes too large to fetch in the client.

### What We Should Keep Even Then:
If we decide to adopt embeddings, we must **not** throw away the existing lexical architecture. We should implement a **Hybrid Search** pattern and preserve the following features from `leadtype`:

1. **Keyword/Lexical Search (BM25) fallback/fusion**:
   * Lexical search is significantly superior to vector embeddings for finding **exact matches** such as specific function signatures, API paths, shell commands, exact error codes, configuration parameters, and brand new version terms. 
   * A hybrid search (using Reciprocal Rank Fusion - RRF or score-weighting) ensures users get the best of both worlds.
2. **Build-time Extraction & MDX Structural Parsing**:
   * Keep `leadtype`'s build-time parser to strip MDX components, flatten AST structures, split content into smart overlapping blocks, and preserve the hierarchical heading path context (`headingPath: ['Getting Started', 'Installation']`).
3. **Source-grounded Answer Context Construction**:
   * Keep using the structured citation, length-bounding, and system-instruction prompt assembly pattern. This prevents LLM hallucination and ensures responses cite specific documentation segments cleanly.
