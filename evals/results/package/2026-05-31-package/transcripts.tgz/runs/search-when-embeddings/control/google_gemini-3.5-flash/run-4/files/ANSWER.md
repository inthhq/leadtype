# Leadtype Docs Search Architecture & RAG Analysis

Before spinning up a hosted, database-backed vector database for documentation search "because that's how RAG is done," we analyzed what `leadtype` already provides out-of-the-box. 

---

## 1. What `leadtype`'s Docs Search Uses by Default

By default, `leadtype` uses a **high-performance, fully static, edge-safe keyword search engine** based on the **Okapi BM25 algorithm**. It runs entirely in-memory—allowing it to execute on the client side or in serverless/edge runtimes (e.g., Next.js Edge, Cloudflare Workers) with zero external database dependencies or network latency.

Its default implementation (found in `leadtype/search`) includes the following sophisticated text-retrieval mechanisms:

### A. Okapi BM25 Scoring & Weighted Fields
It scores document chunks based on term frequency and inverse document frequency, adjusted for average chunk length. Crucially, it applies structured weights depending on where the term matches inside your MDX/Markdown:
* **`TITLE_WEIGHT` = 4.0** (Highest importance)
* **`HEADING_WEIGHT` = 2.0**
* **`BODY_WEIGHT` = 1.0**
* **`CODE_WEIGHT` = 0.35** (Ensures code snippets are indexed, but prevents noisy code tokens/comments from overwhelming actual prose matches)

### B. Natural Language Processing & Normalization
* **Unicode Normalization:** Downcases text and performs `NFKD` unicode normalization to strip diacritics, facilitating seamless accents/special character handling.
* **Stopwords Filtering:** Excludes 24 highly frequent English stop words (e.g., `the`, `and`, `is`, `for`, `with`) to keep the search index clean and focused.
* **Lightweight Rule-Based Stemming:** Reduces plurals and common suffixes (converting `-ies` to `-y`, stripping `-ing`, `-ed`, `-es`, and `-s`) for words of length $\ge 4$.

### C. Multi-tiered Query Expansion (Weighted Matches)
`leadtype` automatically expands user queries to find matching variations using different score multipliers:
* **Exact Matches (Weight: `1.0`):** Matches the exact token.
* **Stemmed Matches (Weight: `0.82`):** Matches other grammatical forms of the word.
* **Developer Synonyms (Weight: `0.72`):** Ships with a built-in static developer-focused dictionary mapping common industry terms (e.g., `ai` $\leftrightarrow$ `["agent", "llm"]`, `auth` $\leftrightarrow$ `["authentication", "login", "signin"]`, `ts` $\leftrightarrow$ `["typescript"]`, `config` $\leftrightarrow$ `["configure", "settings"]`).
* **Prefix Autocomplete Matching (Weight: `0.55`):** Matches the start of words (up to 24 prefix expansions) for typing-as-you-search/live autocomplete.
* **Typo Tolerance (Weight: `0.45`):** Uses a Damerau-Levenshtein / edit-distance check (allowing a distance of 1 or 2 depending on length) up to 16 typo expansions.

### D. Phrase & Proximity Matching Boosts
* **Phrase Boost (`1.4x`):** Boosts chunks where the query terms appear adjacent to each other in the exact order queried.
* **Proximity Boost (`0.8` adder):** Boosts chunks where the queried terms appear near each other within a sliding window of `8` tokens, even if they aren't adjacent.

### E. Built-In Context-As-A-Service (RAG)
`leadtype` provides a direct `createAnswerContext` utility. It searches the index, segments content into semantic sections based on headers, handles overlap (`maxChunkChars: 1200`, `overlapChars: 160`), and constructs a fully cited system/user prompt for LLM Q&A out-of-the-box **without needing a vector database**.

---

## 2. When Are Embeddings Actually Warranted, and What to Keep?

### When is Adding Vector/Embedding Search Warranted?
Adding semantic vector search is only warranted when your users encounter situations where keyword matching fails:
1. **High Conceptual Variance (Zero Keyword Overlap):** When users search for concepts using natural language but do not know the exact technical terms/jargon written in your documentation (e.g., searching for "how do I make sure only authorized users see this" when the docs use the term "role-based access control").
2. **Conversational / Long-Form Queries:** When users enter full questions, thoughts, or copy-paste long paragraphs instead of entering concise technical keywords.
3. **Multi-lingual Needs:** If you want users to be able to search in their native language (e.g., Japanese or Spanish) and retrieve documentation written in English without manually translating every keyword.
4. **Massive Content Scale:** When you have tens of thousands of pages of documentation, and BM25 returns too many high-scoring term matches, requiring high-dimensional semantic clustering to surface the correct search intent.

---

### What Should We Keep Even Then? (The Case for Hybrid Search)
If you decide to stand up a vector database, **you must retain `leadtype`'s static BM25 keyword search index** and combine them using a **Hybrid Search** approach (e.g., Reciprocal Rank Fusion / RRF or weighted sum scoring).

**Why we must keep keyword search (BM25):**
1. **The Technical Jargon & Code Problem:** Vector embedding models are notoriously bad at matching specific, exact technical terms, alphanumeric identifiers, and code snippets. For example, search queries containing:
   * Specific API methods or class names (e.g., `createMemoryRateLimiter`, `readDocsContentChunk`)
   * CLI flags and options (e.g., `--src`, `--bundle`)
   * Error messages, HTTP codes, or precise version numbers (e.g., `413`)
   * Rare library names or brand names
   
   Embedding models project these into generic vector coordinates, leading to "hallucinated" search matches that look conceptually similar but miss the exact class, function, or flag. BM25 is guaranteed to find exact keyword matches.
2. **Edge-Safe, Zero-Latency Autocomplete:** Keyword indexes like `leadtype`'s JSON are extremely lightweight, load instantly, and execute in microseconds directly on the client's device or at the edge. Initiating an embedding model and vector database query for every single keystroke during live-autocomplete is slow, expensive, and unnecessary.
3. **Determinism and Predictability:** BM25 provides simple, explainable, and fully deterministic search. If a page contains a specific term, it will rank. Vector searches are "black boxes" where small variations in a user query can unexpectedly shuffle the top results.
4. **Zero Infrastructure & Model Cost:** Retaining the static keyword search means a significant portion of searches can bypass expensive embedding API calls and vector database compute entirely.
