# What leadtype already gives us for docs search

## 1. What leadtype uses by default

Leadtype ships a **static, lexical search index** — not a vector database. By default it generates two JSON artifacts:

- `search-index.json` — BM25 term postings, document metadata, and chunk metadata
- `search-content.json` — the actual chunk text content

The search runtime (`searchDocs`) is entirely edge-safe: it runs in the browser, a Cloudflare Worker, or a Next.js edge function with **no database or hosted vector store** required.

### How the default retrieval works

- **Scoring:** BM25 with tuned field weights (`title=4`, `heading=2`, `body=1`, `code=0.35`).
- **Query expansion:** exact terms, stemming, built-in synonyms, prefix matches, and typo tolerance (edit distance 1–2).
- **Re-ranking boosts:** phrase matches and ordered-proximity matches get extra score.
- **Chunking:** documents are split into ~1,200-character chunks with 160-character overlap, aligned to section headings and sentence boundaries.
- **RAG / answers:** `createAnswerContext` retrieves top chunks with `searchDocs`, then formats them into a cited, source-grounded prompt for an LLM.

The AI answer adapters (`leadtype/search/vercel`, `leadtype/search/tanstack`, `leadtype/search/cloudflare`) all consume this same BM25 index. There is no embedding step in the default pipeline.

> Note: the `embedContent` build flag does **not** enable vector embeddings. It only controls whether chunk text is inlined into `search-index.json` or kept in a separate `search-content.json` file.

## 2. When embeddings are actually warranted — and what to keep

### Conditions that justify adding embeddings

1. **Conceptual mismatch between queries and docs.** BM25 depends on keyword overlap. If users regularly ask questions whose wording has little surface overlap with the docs (e.g., "how do I gate features by plan?" when the docs say "collection-level access control"), dense retrieval can bridge the gap.
2. **Very large doc sets where lexical coverage breaks down.** The default pipeline warns at >10,000 chunks and >10 MB total. If pruning or scoping isn’t enough, a hybrid lexical + dense approach can improve recall.
3. **You already run a hosted inference stack.** If you are paying for an embedding model and a vector DB *anyway* for other features, adding docs is incremental. Building a vector index *just* for docs when leadtype’s static index already exists is usually premature.

### What you should keep even if you add embeddings

| Leadtype primitive | Why keep it |
|---|---|
| **Chunking strategy** | Section-aware splits (~1,200 chars / 160 overlap, sentence-bounded) are already optimized for LLM context windows and citation accuracy. |
| **Field-weighted retrieval** | Even in a hybrid system, title/heading/body/code weights improve precision. You can feed the same chunk structure into a vector store. |
| **Source-grounded answer builder (`createAnswerContext`)** | It produces cited prompts, enforces "untrusted reference text" guardrails, and limits context to `maxContextChars` (default 12,000). Re-use this layer. |
| **Static lexical index** | Keep BM25 as the first retrieval stage (fast, offline, no latency). Use embeddings for re-ranking or as a secondary recall stage, not as a replacement. |
| **Edge-safe search client** | The default `searchDocs` works without a backend. Use it for autocomplete / quick lookup; reserve embedding-based retrieval for the deeper "Ask AI" path. |

### Bottom line

Leadtype’s default search is a **complete, production-ready RAG retrieval layer** for most docs sites. Before standing up a database-backed vector index, verify that BM25’s recall is actually the bottleneck. If you do add embeddings, treat them as a **supplement** to leadtype’s chunking, indexing, and answer-context primitives — not a replacement.
