# Leadtype docs search and embeddings

## 1. What Leadtype uses by default

Leadtype already ships a database-free docs search pipeline. In site-generation mode (`leadtype generate`), it converts MDX to flattened markdown and builds static JSON search artifacts under `public/docs/`.

The default search runtime is lexical, not vector-based:

- It builds an edge-safe static index from markdown docs with `createDocsSearchIndex` / `generateDocsSearchFiles`.
- It stores chunk text in the generated content store (`search-content.json` by default, or embedded in the index if configured).
- It chunks content by headings/sections, with defaults of about `1200` chars per chunk and `160` chars overlap.
- It indexes terms from titles, headings, body text, and code with different weights.
- It ranks results with BM25-style scoring (`k1 = 1.2`, `b = 0.75`) plus boosts for exact phrase/proximity matches.
- It expands queries with stemming, built-in synonyms, optional custom synonyms, prefix matching, and typo-tolerant matches.
- It can serve source-grounded AI answers without a vector database: `createAnswerContext` runs the same search, selects top sources, builds a context prompt, and instructs the model to use only that context and cite sources.

So, by default, Leadtype gives us a static BM25 search index plus optional source-grounded answer streaming. It does not require hosted storage, embeddings, or a vector database.

## 2. When embeddings are actually warranted

Add embeddings only if we can prove the default lexical system is missing relevant docs for real queries. Concretely, embeddings are warranted when all of these are true:

1. We have an evaluation set from actual user/search logs or support questions.
2. The correct doc/chunk is not appearing in the top results from Leadtype's default search.
3. The miss is caused by semantic mismatch rather than documentation quality; e.g. users ask conceptual or paraphrased questions that share little vocabulary with the docs, or we need cross-lingual / highly synonym-heavy retrieval.
4. The miss cannot be fixed more simply by improving titles/headings/descriptions, adding terminology users actually use, adding custom synonyms, or scoping/restructuring the docs.
5. A hybrid embedding prototype measurably improves recall/answer quality on that eval set enough to justify the operational cost of hosted storage, indexing jobs, embedding refreshes, privacy review, latency, and failure modes.

Even then, we should keep Leadtype's existing pieces:

- Keep the generated markdown mirrors and static search artifacts as the canonical, versioned source of docs content.
- Keep BM25/lexical search as part of hybrid retrieval, because it is excellent for exact API names, CLI flags, package names, error strings, code identifiers, headings, and recently changed docs.
- Keep Leadtype's source-grounded answer flow: retrieve sources first, pass only those excerpts to the model, require citations, and say when the context is insufficient.
- Keep query validation, rate limiting/request guards, and deterministic fallbacks so docs search still works if the embedding service or database is unavailable.

In short: start with Leadtype's static BM25 search. Add embeddings only as a measured hybrid-retrieval enhancement for demonstrated semantic-recall failures, not as the default architecture.
