# What leadtype already gives us for docs search

## 1. Default search behavior

leadtype does **not** default to a hosted database, a vector store, or embeddings.

By default, `leadtype generate` builds a **static, edge-safe JSON search index** from the flattened markdown docs. The installed package describes this as a “static search index” using **BM25**. The runtime APIs (`createDocsSearchIndex`, `searchDocs`, `createAnswerContext`) operate over that generated index and its content store.

Concretely, the default index/search path:

- chunks each markdown doc by section, with defaults of about **1200 chars per chunk** and **160 chars overlap**;
- indexes lexical terms from the page title, headings, body text, and code text;
- ranks results with **BM25**, with extra weighting for title and heading matches;
- supports pragmatic lexical recall improvements: normalization, stopword removal, light stemming, built-in/custom synonyms, prefix expansion, typo tolerance, phrase boosts, and proximity boosts;
- can create source-grounded answer context from the top search results, with citations and instructions to answer only from the provided docs context.

So leadtype already covers the normal docs-search/RAG retrieval layer without running infrastructure: generate markdown mirrors plus `search-index.json`, serve them statically, and query them at the edge or in the client/server runtime.

## 2. When embeddings are actually warranted

Adding embeddings is warranted only after we can show that leadtype’s lexical/BM25 search is failing for reasons embeddings specifically solve.

Good reasons to add embeddings:

- Query logs or an evaluation set show important failures where the user’s wording has **little or no token overlap** with the relevant docs, even after improving titles, headings, descriptions, synonyms, and aliases.
- Users ask broad conceptual or paraphrased questions where the right answer is present but not discoverable by API names, option names, headings, error text, or other exact terms.
- We need cross-lingual or strongly semantic matching that cannot be handled well with localized docs plus synonyms.
- The docs corpus or update pattern has grown beyond what is practical for a static JSON index, and we need server-side retrieval for operational reasons anyway.

Bad reasons to add embeddings:

- “That’s how RAG is done.”
- We have not measured BM25 misses.
- The target queries are mostly exact identifiers: API names, CLI flags, config keys, error messages, package names, paths, or versioned docs. Lexical search is usually better for these.

Even if we add embeddings, we should keep leadtype’s default search assets and behavior:

- Keep leadtype’s flattened markdown/docs outputs as the **canonical ingest source** for any embedding pipeline.
- Keep the BM25 index as a **hybrid first-stage retriever, reranker signal, or fallback**. Exact identifier matches should not be left solely to vector similarity.
- Keep leadtype’s source-grounded answer context pattern: cite sources, answer only from retrieved docs, and say when the context is insufficient.
- Keep the static search index for cheap, reliable docs search and as a no-database fallback.

Recommended path: ship leadtype’s built-in static BM25 search first, instrument queries and misses, then add embeddings only if the measured failures are semantic-recall failures rather than content, metadata, synonym, or ranking problems.
