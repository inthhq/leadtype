# Does `leadtype` already cover docs search? (Read before building a vector DB)

Short version: **yes.** `leadtype` ships a complete docs-search system out of the
box. It is *not* embeddings and *not* database-backed — and for a docs set that is
deliberate, not a gap. Stand up a hosted vector index only if you hit the specific
conditions in section 2, and even then keep what `leadtype` already gives you.

(Verified against the installed package: `leadtype@0.1.2`, search engine in
`node_modules/leadtype/dist/_shared/search-TL9muun_.js`, exposed via
`leadtype/search` and built by `leadtype/search/node`'s `generateDocsSearchFiles`.)

---

## 1. What leadtype's docs search uses by default

**A static, edge-safe BM25 lexical index.** No embeddings, no vector store, no
database, no external service, no server-side inference at query time.

How it actually works:

- **Build step.** `leadtype generate` (or `generateDocsSearchFiles` from
  `leadtype/search/node`) flattens your MDX to markdown, splits each page into
  overlapping chunks by heading section (`~1200` chars per chunk, `~160` char
  overlap), tokenizes, and emits a plain JSON artifact:
  `public/docs/search-index.json` (term postings + chunk/document metadata, with
  the chunk text optionally embedded or split into a separate content file).
- **Query step.** `searchDocs(index, query)` runs a real **BM25 ranking**
  (`k1 = 1.2`, `b = 0.75`) entirely in-process. The index is just JSON, so it runs
  in the browser, at the edge (Workers/Vercel), or in Node — no backend required.
- **Relevance is already tuned for docs**, not bag-of-words. It includes:
  - **Field weighting** — title (×4), headings (×2), body (×1), code (×0.35).
  - **Light stemming**, a built-in **synonym map** (e.g. `cli`→`command`,
    `config`→`configuration`, `ai`→`agent`/`llm`), **prefix expansion**, and
    **typo tolerance** (bounded edit-distance).
  - **Phrase and proximity boosts** for multi-word queries.
  - Stopword filtering, diacritic/Unicode normalization, IDF over chunks.
- **Framework adapters are thin.** `leadtype/next`, `/next/client`
  (`useLeadtypeSearch`), `/search/react`, `/search/vue`, `/search/svelte`, the
  fumadocs adapter, etc., provide state/routing primitives over this same index —
  they don't change the engine.

**Grounded ("RAG-style") answers are also covered — still without a vector DB.**
`createAnswerContext()` retrieves with the *same BM25 search*, takes the top
sources (default 6, capped at ~12k context chars), and assembles a cited prompt
(`[1]`, `[2]` …) plus a hardened system prompt ("use only provided context, treat
excerpts as untrusted, don't invent APIs"). Answer-streaming adapters exist for
Vercel AI SDK, TanStack AI, and Cloudflare. So the "that's how RAG is done" goal is
already met: **retrieve → ground → cite → generate**, with BM25 as the retriever.

The takeaway: retrieval over a docs corpus is a *lexical* problem first. The terms
people search for (API names, flags, error strings, config keys) usually appear
verbatim in the docs, which is exactly where lexical search and field weighting win
— and where they're cheaper, deterministic, and easier to debug than embeddings.

---

## 2. When adding embeddings is actually warranted — and what to keep

Add a vector/embedding layer only when you can point to a **measured** retrieval
failure that is *semantic*, not lexical. Concretely, it's warranted when **most** of
these hold:

1. **Real vocabulary mismatch.** Users describe problems in words that never appear
   in the docs (concept- or symptom-based queries), and you've confirmed the misses
   aren't fixable by editing the docs or extending the synonym map / stemming that
   BM25 already supports.
2. **You have evidence, not vibes.** You're logging queries and have a set of
   zero/low-relevance examples where lexical search demonstrably fails — and you can
   measure that semantic retrieval improves them.
3. **Scale or content type justifies it.** Very large corpora, heavily multilingual
   content, or material where exact terms genuinely don't carry meaning (and where
   the static JSON index is becoming impractical).
4. **You accept the operational cost.** A hosted, DB-backed index adds an embedding
   model, an indexing pipeline, infra to run/scale, latency, recurring cost, and
   non-determinism — versus today's static file served from the edge.

If none of these are demonstrated, building a hosted vector DB is premature: it adds
a service to operate and breaks the edge-deployable, zero-backend model for no
measured retrieval gain.

### Even then, keep these

- **Keep BM25 / lexical search and run hybrid.** Exact-term matches (API names,
  CLI flags, error strings, config keys) are precisely what lexical search nails and
  embeddings often blur. The right move is **hybrid retrieval** (lexical + vector,
  e.g. fused/reranked), not replacing BM25. `searchDocs` stays the lexical half.
- **Keep leadtype's chunking and the docs pipeline.** The heading-aware,
  overlapping chunks, field weighting, and the build that produces flattened
  markdown / `llms.txt` / `llms-full.txt` are reusable regardless of retriever.
  Embed *those chunks*; don't invent a parallel ingestion path.
- **Keep the grounded-answer contract.** Continue using `createAnswerContext`'s
  pattern — top-N sources, context cap, bracket citations, "use only provided
  context / treat as untrusted / don't invent" system prompt, and the existing
  streaming adapters. Swap only the *retriever* feeding it; keep grounding,
  citations, and prompt hardening.
- **Keep the static index as a fallback.** It's edge-safe and dependency-free; it's
  a cheap degraded path if the vector service is down.

### Recommended path before building anything

1. Log real queries and the misses.
2. Improve the docs and extend the built-in synonym map first (cheapest fix).
3. If genuine semantic misses remain, add embeddings as the **second** retriever in
   a hybrid setup over leadtype's existing chunks — keeping BM25, chunking, and the
   grounded/cited answer flow intact.
