# Leadtype Docs Search & Retrieval Strategy

This document details what the `leadtype` package already provides out-of-the-box for documentation search and outlines when a transition to a hosted, database-backed vector database (semantic search/embeddings) is actually justified—including what must be preserved even if such a transition is made.

---

## 1. What Leadtype's Docs Search Uses by Default

By default, `leadtype` builds and queries a **static, edge-safe search index** based on a highly customized **BM25 (Best Matching 25) scoring algorithm** coupled with **lexical expansion and multi-field weighting**. 

Rather than requiring a database, server, or hosted SaaS, search is fully self-contained. It works by generating static JSON files at build-time and querying them using a lightweight, edge-compatible JavaScript runtime.

### Key Components of Leadtype's Default Search

#### A. Build-Time Index Generation
During `leadtype generate`, the pipeline converts MDX files, strips frontmatter, and parses Markdown into distinct hierarchical blocks and chunks. It emits:
*   `search-index.json`: A compact index mapping normalized terms/tokens to chunk posting lists.
*   `search-content.json`: The chunked raw text content used to build search excerpts and ground AI answers (grounding contexts).
*   *Optimization*: If the `embedContent` option is enabled, the content is bundled directly into a single, unified `search-index.json`. Chunks default to a maximum size of `1,200` characters with a `160`-character overlap.

#### B. Multi-Field Weighting
Not all matches are equal. Leadtype applies specific relative weights depending on where a query term is found in the document structure:
*   **Title**: `4.0`
*   **Heading**: `2.0`
*   **Body Text**: `1.0`
*   **Code Fences/Blocks**: `0.35` (ensures exact API/syntax matches are indexed but don't overwhelm prose).

#### C. Edge-Safe Lexical Query Processing
When a search query is executed, Leadtype processes the query through several lexical expansion stages:
1.  **Normalization & Tokenization**: Normalizes text (via NFKD), strips diacritics, lowercase-converts, splits on word characters, and filters out common english stopwords (e.g., *the*, *and*, *with*, etc.).
2.  **Light Stemming**: Standardizes word suffixes (e.g., mapping plural or tense inflections: `-ies` -> `-y`, `-ing` -> ``, `-ed` -> ``, `-es` -> ``, `-s` -> ``).
3.  **Expansion & Match Weights**:
    *   **Exact Match** (Weight `1.0`): Perfect lexical alignment.
    *   **Stemmed Match** (Weight `0.82`): Matching word roots.
    *   **Synonym Expansion** (Weight `0.72`): Expands common technical terms via built-in mappings (e.g., `ai` $\leftrightarrow$ `agent` / `llm`, `auth` $\leftrightarrow$ `authentication` / `login`, `ts` $\leftrightarrow$ `typescript`) and custom synonyms.
    *   **Prefix Expansion** (Weight `0.55`): Matches partial query words to terms sharing prefixes (up to 24 expansions).
    *   **Typo Tolerance** (Weight `0.45`): Corrects minor typos (edit distance $\le 1$ or $\le 2$ depending on word length) assuming the first letter is correct (up to 16 expansions).

#### D. BM25 and Phrase/Proximity Scoring
*   **BM25 Math**: Scores each chunk using the standard BM25 formulation ($k_1 = 1.2$, $b = 0.75$) based on term frequency within the chunk (adjusted for average document length across the corpus) and inverse document frequency (IDF) in the index.
*   **Phrase Match Boost**: Adds a boost of `+1.4` if query tokens appear sequentially and consecutively in the chunk.
*   **Ordered Proximity Boost**: Adds a boost of `+0.8` if query tokens appear in order within an 8-word sliding window.

#### E. AI Answer Grounding (Local RAG)
Leadtype ships with a native grounding pipeline (`createAnswerContext` and edge-streaming adapters like `streamDocsAnswer` for Vercel AI SDK, Cloudflare, and TanStack Start):
*   Performs BM25 search to locate the most relevant document chunks.
*   Pulls raw text for up to `6` sources (maximum context length of `12,000` characters).
*   Formats a secure, instruction-hardened LLM prompt that instructs the model to act as an answer bot, cite sources using brackets (e.g., `[1]`, `[2]`), and treat excerpts as untrusted reference text rather than raw instructions.

---

## 2. When Are Embeddings Actually Warranted?

Transitioning from a static BM25 index to a hosted, database-backed vector database (such as Pinecone, Milvus, Qdrant, or pgvector) is a major architectural commitment involving hosted infrastructure, embedding generation pipelines, API latency, and extra costs. 

### Conditions Warranting Embeddings

Adding semantic embeddings is **only warranted** under the following specific conditions:

1.  **Dominance of Conceptual, Synonym-Independent Queries**:
    *   When your users routinely search using highly abstract concepts or colloquialisms that do not share any vocabulary with your technical docs.
    *   *Example*: A user searches *"How do I keep my routes private?"* but the documentation only uses terms like *"Middleware token-based authentication guard configuration"*. If the synonyms list cannot scale to cover this conceptual distance, a dense vector space is required to bridge the semantic gap.
2.  **Cross-Lingual or Multi-Lingual Querying**:
    *   When your documentation is authored in English, but users query in Spanish, Japanese, or French, and you require the system to retrieve English source documents directly without requiring manual translation of the index. Multilingual embeddings (e.g., Cohere, OpenAI text-embedding-3) resolve this seamlessly.
3.  **Conversational/Chat-First User Experiences**:
    *   When the primary search modality is a conversational chatbot where queries are long, conversational, full-sentence questions (*"Wait, I tried to deploy my app but I got a rate limit error, how do I increase my limit?"*). Natural language embeddings excel at extracting meaning from noisy, conversational questions where BM25 may match too many irrelevant terms (e.g., "tried", "deploy", "increase", "limit").
4.  **Extremely Large and Broad Document Corpora**:
    *   If your documentation spans tens of thousands of pages with diverse, overlapping vocabularies where keyword matching results in too much noise and low precision. Semantic search allows high-level vector clustering to narrow down context before precise retrieval.

---

### What We Should Keep Even Then (Hybrid Architecture)

If we do decide to implement vector embeddings, we should **not throw away BM25**. A pure vector-based RAG approach has significant blind spots. Instead, we should implement a **Hybrid Search** architecture and preserve Leadtype's core pipeline.

We must retain:

1.  **Lexical Search (BM25) for Technical Identifiers**:
    *   Vector embeddings are notoriously bad at matching precise technical jargon, exact API function names (`createDocsSearchIndex`), error codes, CLI flags (`--src`, `--out`), and specific configuration parameters. 
    *   A hybrid search system utilizing **Reciprocal Rank Fusion (RRF)** combines the precision of BM25 for technical identifiers with the semantic recall of embeddings.
2.  **Leadtype’s MDX-to-Markdown Pipeline**:
    *   The highest-quality embeddings and LLM answers depend entirely on **clean source data**.
    *   Leadtype's pipeline flattens complex MDX tags, resolves file imports, and strips frontmatter to generate clean, agent-readable, plain-markdown chunks. We should feed **Leadtype's flattened markdown** into our embedding model, not the raw, tag-heavy MDX source files.
3.  **The LLM-Friendly `llms.txt` and `llms-full.txt` Context Files**:
    *   For LLM agents and coding tools (like Cursor, Windsurf, or custom developer tools) reading our documentation directly, the static, unified context files generated by Leadtype are vastly superior to querying a vector API. Keeping these files allows agents to consume the entire codebase’s documentation context offline, instantly.
4.  **Leadtype’s Grounding Prompt Mechanics**:
    *   The prompt engineering structure defined in `createAnswerContext`—including source-citation injection, bracketed citations, and prompt-injection defense instructions—is highly optimized for preventing AI hallucinations.
