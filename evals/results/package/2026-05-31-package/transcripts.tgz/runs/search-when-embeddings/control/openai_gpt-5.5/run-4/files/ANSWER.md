# Leadtype docs search and when embeddings make sense

## What leadtype uses by default

Leadtype does **not** require a hosted vector database for docs search. In site mode, `leadtype generate` builds static search artifacts under the generated docs output: a BM25-style `search-index.json` plus a chunk content store (`search-content.json` by default in the current package code). These are plain JSON files that can be served from the docs site/CDN and queried in an edge-safe runtime or browser client.

The default runtime is lexical retrieval over generated markdown chunks:

- docs are split into heading-aware chunks, with default chunk sizing around `1200` chars and `160` chars overlap;
- terms are tokenized, normalized, stopwords are removed, and simple stemming is applied;
- scoring is BM25 with field weights: title matches count most, then headings, body text, and code;
- matching also includes built-in/user synonyms, prefix expansion, typo tolerance, phrase boosts, and proximity boosts;
- default search returns a small top-k set (`8` results by default).

Leadtype also has optional source-grounded answer helpers for Vercel/TanStack/Cloudflare AI integrations. Those helpers still start from the same docs search index: they retrieve BM25 results, build a bounded context from the matching chunks, and instruct the model to answer only from that context with citations.

## When embeddings are actually warranted

Add embeddings only if we can show that the default lexical/hybrid-ish BM25 search is failing for our real docs and real queries. Good reasons are specific and measurable, for example:

1. **Important query logs show semantic misses**: users ask natural-language or paraphrased questions where the right page exists, but there is little/no vocabulary overlap even after adding obvious synonyms.
2. **Synonym/stemming/prefix/typo tuning is not enough**: the misses are conceptual rather than wording/typo problems.
3. **The corpus is large or heterogeneous enough** that lexical ranking consistently buries relevant conceptual matches, and evaluation shows embeddings improve recall/answer success.
4. **We need cross-language or cross-domain semantic retrieval** beyond what Leadtype's localized/static per-locale search handles.
5. **We have an evaluation set and operating budget**: representative queries, expected sources/answers, latency/cost targets, freshness requirements, and a plan for re-indexing.

Even then, do not replace Leadtype's default search. Keep it as the backbone/fallback and run embeddings as an additional retrieval signal:

- keep the generated markdown mirrors and chunk/content artifacts as the source of truth;
- keep BM25 for exact API names, options, error messages, code symbols, paths, headings, and known-keyword queries;
- use a hybrid retriever that merges/reranks BM25 and vector candidates;
- keep source-grounded answer construction with citations and "answer only from context" constraints;
- keep static search available as a cheap, fast, private, CDN-friendly fallback when the vector service or model provider is slow, down, stale, or too expensive.

In short: Leadtype already gives us static, database-free BM25 docs search plus source-grounded answer plumbing. Embeddings are worth adding only after measured semantic-recall failures justify the extra infrastructure, and they should augment—not replace—the Leadtype index and citation-grounded context flow.
