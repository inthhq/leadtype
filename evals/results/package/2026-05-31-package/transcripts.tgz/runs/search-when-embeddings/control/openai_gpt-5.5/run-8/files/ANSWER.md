# Leadtype docs search and when embeddings make sense

## 1. What Leadtype uses by default

Leadtype already ships a docs-search pipeline that is **static, lexical, and edge-safe** by default — not a hosted database-backed vector index.

By default, `leadtype generate` emits generated website artifacts including:

- `docs/search-index.json`
- `docs/search-content.json` when content is not embedded in the index
- flattened markdown docs used as the source material

The runtime search is a **BM25-style inverted index** over generated markdown chunks. It:

- chunks flattened docs content, with default chunk sizing around `1200` chars and overlap around `160` chars;
- indexes title, heading, body, and code terms with different weights;
- ranks matches with BM25 scoring;
- expands lexical matching with stemming, built-in/custom synonyms, prefix matches, typo-tolerant matches, phrase boosts, and proximity boosts;
- runs from JSON artifacts via `leadtype/search` or framework clients such as `leadtype/search/client` and `leadtype/search/react`;
- can build **source-grounded answer context** from top search results for an LLM, but the retrieval step is still the generated Leadtype search index, not embeddings.

So the default architecture is: **build-time static search artifacts + client/edge BM25 retrieval + optional source-grounded LLM answering**. It does not require a vector database, an embedding provider, or a hosted search service.

## 2. When adding embeddings is warranted

Add embeddings only after the static Leadtype search has been tested against real docs-search traffic and is demonstrably insufficient. Embeddings are warranted when we have specific evidence of semantic-recall failures, for example:

1. Users ask natural-language questions whose correct pages use substantially different vocabulary, and BM25/synonyms cannot recover them reliably.
2. The docs corpus is large or conceptually broad enough that lexical overlap is consistently a poor proxy for intent.
3. We need cross-document conceptual matching, paraphrase matching, or ambiguous intent resolution that cannot be handled with better headings, redirects, glossary terms, or Leadtype synonym tuning.
4. Search-quality evaluation shows acceptable precision but unacceptable recall for important queries after improving the docs content and BM25 configuration.
5. The product requirement is specifically semantic retrieval across multiple sources beyond the generated Leadtype docs artifacts.

Even then, we should **keep Leadtype's generated docs artifacts and BM25 search**. Use embeddings as an additional retrieval layer, not as a replacement. In particular, keep:

- the flattened markdown outputs as the canonical, source-grounded text;
- `search-index.json` / `search-content.json` for fast exact lookup, fallback search, and debugging;
- BM25 results for high-precision keyword/API/error-code queries;
- Leadtype's chunking and citation/source-context behavior for answer generation;
- source-grounding rules: answers should cite retrieved docs and should not invent APIs or behavior.

A practical hybrid would be: run Leadtype BM25 first or alongside vector search, merge/rerank the candidates, then feed only the selected Leadtype doc chunks into the answer-generation context. That gives semantic recall where it is proven necessary while preserving the cheap, deterministic, debuggable search Leadtype already provides.
