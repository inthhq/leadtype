# Leadtype Docs Search & Vector Indexes Analysis

This document outlines how `leadtype` handles search by default and analyzes the specific scenarios where introducing a hosted, database-backed vector index is justified—and what to preserve from `leadtype` if you do.

---

## 1. What Leadtype's Docs Search Uses By Default

By default, `leadtype` provides a **static, edge-safe search engine** built entirely on a custom **BM25 (Best Matching 25) lexical ranking algorithm** combined with advanced query expansion and linguistic optimizations. It requires **no external database** or hosted microservice, running purely as a client-side or edge-friendly runtime that loads pre-compiled, lightweight JSON artifacts.

### A. Indexing & Representation
- **Build-Time Generation**: During the generation phase (`leadtype generate`), the pipeline flattens complex MDX files into clean markdown, extracts heading paths, and produces two static search artifacts:
  - `search-index.json`: A compact postings index mapping normalized search terms to their document occurrences, term frequencies, and structural weights.
  - `search-content.json`: The actual raw textual content of the parsed chunks (or optionally embedded directly within `search-index.json` when `embedContent: true` is configured).
- **Heading-Aware Overlap Chunking**: MDX/Markdown is organized into section blocks based on headings. Within each block, text and code elements are parsed separately and split into overlapping chunks:
  - Default maximum chunk size: `1,200` characters.
  - Default overlap: `160` characters.
  - Splitting logic: Intelligently prefers breaking on sentence boundaries (`. `) or space boundaries inside the overlap window to maintain natural context.

### B. BM25 Query & Weighting Engine
- **BM25 Formula Tuning**: The lexical scoring uses standard BM25 parameters:
  - $k_1 = 1.2$ (controls term frequency saturation).
  - $b = 0.75$ (controls document length normalization).
- **Structural Location Weighting**: Hits are weighted based on where they appear in the document structure:
  - Title: **4.0**
  - Headings: **2.0**
  - Body Text: **1.0**
  - Code Blocks: **0.35**
- **Query Term Weighting & Expansion**: Rather than doing simple exact-word matching, `leadtype` normalizes queries (lowercasing and diacritic removal) and applies weighted matching strategies:
  - **Exact Term Matches**: Weight of `1.0`.
  - **Linguistic Stemming**: Suffix-stripping rules for tokens $\ge 4$ characters (e.g., `ies` $\rightarrow$ `y`, `ing` $\rightarrow$ truncated, `ed`/`es`/`s` removal) with a weight of `0.82`.
  - **Synonym Expansion**: Mapping using built-in developer synonyms (e.g., `ai` $\leftrightarrow$ `agent`/`llm`, `ts` $\leftrightarrow$ `typescript`, `cli` $\leftrightarrow$ `command`/`terminal`, `auth` $\leftrightarrow$ `authentication`/`login`/`signin`) with a weight of `0.72`.
  - **Prefix Expansion**: Automatically matches partial prefix terms (up to 24 expansions) with a weight of `0.55`.
  - **Typo/Edit-Distance Tolerance**: Uses Levenshtein distance (1 edit for 4–6 chars, 2 edits for 7+ chars) on words sharing the same first letter (up to 16 expansions) with a weight of `0.45`.
- **Phrase and Proximity Matching Boosts**:
  - Exact phrase matches in the text are given a score boost of `+1.4`.
  - Ordered proximity matches (query terms appearing close to each other within an 8-word window) receive a boost of `+0.8`.
- **Stopwords Filtering**: Common English stopwords (e.g., *a, an, and, are, can, how, use, with*) are automatically stripped to reduce noise.

### C. Grounded Answer Streaming (RAG)
`leadtype` comes with a lightweight, edge-safe RAG integration (supporting adapters like Vercel AI SDK, Cloudflare Workers AI, and TanStack AI). Under the hood, `createAnswerContext`:
- Queries the static BM25 index for the top matching chunks (up to `6` sources / `12,000` characters by default).
- Constructs a secure **system prompt** telling the LLM to restrict answers to the provided context, treat documents as untrusted reference text, cite references strictly with bracket citations (e.g., `[1]`, `[2]`), and refrain from inventing APIs.
- Generates a fully formatted context prompt ready to be streamed to an LLM provider.

---

## 2. When to Add Embeddings (and What to Keep)

Introducing a hosted, database-backed vector database (such as Pinecone, Qdrant, PGVector, or Milvus) is a heavy infrastructure and operational cost. It should only be adopted under very specific conditions.

### A. Specific Conditions Where Vector Embeddings Are Warranted
1. **Massive Content Scale**: When your documentation set grows so large (tens of thousands of pages, hundreds of megabytes of raw text) that distributing a static `search-index.json` to the client's browser or keeping it in-memory on edge/serverless functions exceeds bandwidth budgets, memory limits, or cold-start thresholds.
2. **Extreme Vocabulary Mismatch (Concept-Only Search)**: When users ask highly conceptual, vague, or natural-language questions that do not share any words with your actual docs (e.g., a user searches *"how do I prevent my background tasks from being paused when the phone goes to sleep?"* but the documentation only uses technical terms like *"foreground services, wakelocks, and thread lifecycles"*). Dense embeddings capture these semantic relations where BM25 fails.
3. **Cross-Source Knowledge Integration**: When you must search across heterogeneous knowledge sources simultaneously (e.g., indexing documentation, Zendesk support tickets, Slack channels, and public GitHub issues) within a single unified retrieval interface.
4. **Dynamic Personalization and Access Control (ACLs)**: If your documentation contains strict enterprise access control lists where search results must be filtered dynamically based on user identity in real-time, or if documents are updated constantly with zero latency tolerated.

### B. What We Should Keep Even Then
Even if a vector index is introduced, you should **never discard `leadtype`'s architecture**. Instead, keep:

1. **Hybrid Search (BM25 + Vector Retrieval)**:
   - Vector-only search is notoriously bad at finding exact technical details, such as specific CLI commands, API endpoint names (e.g., `createDocsRouteHandler`), precise error codes, or version numbers.
   - Keep `leadtype`'s BM25 search index and perform **Hybrid Search** (combining dense vector similarity scores with BM25 lexical scores, typically merged using Reciprocal Rank Fusion / RRF). This is the gold standard for developer-facing documentation search.
2. **MDX Flattening and Heading-Based Chunking**:
   - High-quality chunking is the single most important factor in RAG performance. `leadtype`'s pipeline already handles MDX flattening, Frontmatter stripping, and heading-aware block segmentation.
   - Retain `leadtype`'s build-time parser to generate clean, semantic markdown inputs for your vector embedding generator, rather than using generic, naive paragraph- or character-splitters.
3. **Agent-Readable Static Entry Points (`llms.txt`, `llms-full.txt`, `AGENTS.md`)**:
   - External coding agents, IDE extensions (Cursor, Copilot), and LLM crawlers read flat, raw markdown content much better than calling a proprietary database API.
   - Keep these files exposed at the root of your domain so that LLM agents can discover and ingest your entire codebase offline or in a single request.
4. **Source-Grounded Prompt Engineering & Citation Rules**:
   - `leadtype`'s default system instructions, bracket citation templates (`[1]`, `[2]`), and request guards are highly optimized for documentation search and should continue to form the core of your LLM prompts.
