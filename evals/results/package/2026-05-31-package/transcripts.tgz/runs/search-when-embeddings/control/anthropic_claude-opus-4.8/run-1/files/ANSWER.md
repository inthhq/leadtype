# Does `leadtype` already give us docs search? Do we need a vector DB?

Short version: **leadtype already ships a complete docs search engine, and it is not embeddings-based.** A hosted, database-backed vector index is almost certainly unnecessary for docs search. Before building one, read what's below.

## 1. What leadtype's docs search uses by default

leadtype generates a **static, edge-safe lexical search index** at build time and runs queries with **BM25 keyword ranking** — no embeddings, no model inference, no database, and no server-side vector store.

Concretely, from the installed package (`leadtype/search` + `leadtype/search/node`):

- **Build step.** `generateDocsSearchFiles` / `createDocsSearchIndex` flatten your MDX/markdown into a single JSON artifact (`public/docs/search-index.json`). The README describes this as "a static, edge-safe search index (BM25, optional source-grounded answers)."
- **Index structure.** Docs are split into overlapping chunks (default `maxChunkChars: 1200`, `overlapChars: 160`) and reduced to an inverted index: `terms -> postings`. Each posting records per-field term counts so ranking can weight where a term appeared.
- **Ranking = Okapi BM25.** The runtime (`searchDocs`) scores chunks with classic BM25 (`k1 = 1.2`, `b = 0.75`) using inverse-document-frequency and length normalization. It is pure arithmetic over the prebuilt index — it runs in-process / at the edge, with no external service.
- **Field weighting.** Matches are boosted by where they occur: title ×4, heading ×2, body ×1, code ×0.35.
- **Lexical "smartness" without a model.** Despite being keyword-based, it already handles a lot of what people reach for embeddings to get:
  - tokenization with stopword removal and diacritic/case normalization,
  - light **stemming** (so "publishing" matches "publish"),
  - a built-in **synonym** map (e.g. `auth → authentication/login/signin`, `cli → command/terminal`) that you can extend via `synonyms`,
  - **prefix** expansion (type-ahead),
  - **typo tolerance** via bounded edit distance,
  - **phrase and proximity** boosts for multi-word queries,
  - query-aware **excerpts** for result snippets.
- **Optional source-grounded answers (RAG-style, still no vectors).** `createAnswerContext` runs the same BM25 search, takes the top sources (default `maxSources: 6`, `maxContextChars: 12000`), and assembles a cited `system` + `prompt` payload for an LLM. Retrieval is lexical; the LLM only summarizes/cites the retrieved chunks. Adapters exist for Vercel AI SDK, TanStack, and Cloudflare answer streaming.
- **Operational guards included.** `validateDocsQuery`, `readJsonWithLimit`, `createMemoryRateLimiter`, and `getClientIdentifier` give you query validation, body-size limits, and rate limiting for the ask/search endpoints.

> Note: the `embedContent` flag on `generateDocsSearchFiles` is **not** about vector embeddings — it controls whether chunk text is inlined into the index JSON vs. written to a separate content file. There are no embedding/vector primitives anywhere in the package.

### Why the default is a good fit for docs

- **Zero infrastructure:** one JSON file served from a CDN/edge. No database, no embedding pipeline, no vector index to host, secure, or pay for.
- **Deterministic and debuggable:** results are explainable (you can see which terms/fields matched). No drift from model/embedding version changes.
- **Cheap and fast:** no per-query embedding inference, no network round-trip to a vector store.
- **Docs are keyword-rich:** product names, API symbols, flags, and error strings are exact tokens — exactly what BM25 excels at, and often where semantic search *underperforms*.

## 2. When adding embeddings is actually warranted — and what to keep

Add embeddings only if you have **evidence** that BM25 is failing on real queries, typically one of:

1. **Persistent vocabulary mismatch / conceptual queries.** Users phrase questions in words that never appear in the docs (different domain vocabulary, natural-language "how do I…" intents) and the lexical aids (synonyms, stemming, prefix, typo tolerance) don't bridge the gap. Before reaching for vectors, first **extend the `synonyms` map** — that closes most of these gaps for free.
2. **Cross-lingual or paraphrase-heavy search** where query and content rarely share surface tokens.
3. **Large, heterogeneous corpora** (well beyond focused product docs) where conceptual recall measurably beats keyword recall in your own evaluation.

Validate with a labeled query set and an A/B before committing — "that's how RAG is done" is not a requirement.

Even then, **do not throw away the lexical layer. Keep:**

- **leadtype's BM25 index as the lexical half of a hybrid retriever.** The strongest practical setup is **hybrid search**: run BM25 *and* vector similarity, then fuse/rerank. BM25 anchors exact matches (API names, flags, error codes) that pure embeddings notoriously miss.
- **leadtype's chunking and grounding pipeline.** Reuse its chunk boundaries (`maxChunkChars` / `overlapChars`) and `createAnswerContext` for citation-grounded answers. Embeddings would replace/augment *retrieval ranking only* — the chunking, citation format, untrusted-context handling, and answer-streaming adapters stay.
- **The static-first, edge-safe posture.** Add a vector store as an *augmentation*, not a replacement. Keep the prebuilt index as a no-dependency fallback so search keeps working if the vector service is down or unconfigured.
- **The request guards** (`validateDocsQuery`, `readJsonWithLimit`, rate limiting) — those apply regardless of retrieval backend.

### Recommendation

Ship leadtype's built-in BM25 search first (it's already installed and generates the index from one command), extend the synonym map for your domain, and instrument query/click logs. Only stand up a hosted vector index if your own data shows lexical retrieval is the bottleneck — and even then, run it as a **hybrid** layered on top of leadtype's existing chunking and grounding, not as a replacement.
