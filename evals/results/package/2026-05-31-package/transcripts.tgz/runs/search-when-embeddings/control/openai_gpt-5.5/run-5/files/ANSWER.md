# Leadtype docs search: what we get before adding vectors

## 1. What leadtype uses by default

Leadtype’s docs search is **not a hosted vector database** by default. It is a **build-time, static, edge-safe lexical search index** generated from the same flattened markdown that leadtype emits for docs and agent-readable artifacts.

Concretely, the installed package shows that leadtype:

- Reads generated markdown docs and writes static JSON search artifacts, normally under `docs/search-index.json` plus a separate `docs/search-content.json` content store unless content is explicitly embedded.
- Chunks docs by section, with defaults of about **1,200 characters per chunk** and **160 characters overlap**.
- Builds an inverted index over tokens and scores results with **BM25**.
- Weights matches by field: title, heading, body, and code all contribute, with title and heading weighted higher than body and code.
- Adds practical lexical recall features: stopword removal, simple stemming, built-in and custom synonyms, prefix matching, typo tolerance, phrase-match boosts, and ordered-proximity boosts.
- Runs anywhere static JSON can be fetched; the client fetches the generated artifacts and calls `searchDocs` locally/at the edge. There is no database, embedding model, vector store, or indexing service required.
- For “ask the docs” style answers, leadtype can create a **source-grounded answer context** from the lexical search results. The prompt explicitly says to use only the provided docs context, cite sources, and say what is missing instead of inventing APIs.

So the default RAG-like path is: **flattened markdown → static BM25 index/content artifacts → retrieve matching chunks → optional source-grounded LLM answer**.

## 2. When embeddings are actually warranted

Embeddings are warranted only when we have evidence that lexical retrieval is the limiting factor. Good reasons include:

1. **Measured semantic-recall misses**: real queries or an evaluation set show that relevant docs are consistently missed because users ask with vocabulary that does not appear in the docs, and this cannot be fixed well with titles, headings, aliases, redirects, frontmatter descriptions, or leadtype synonyms.
2. **Large natural-language question surface**: users ask broad conceptual questions where the relevant page often shares little exact terminology with the query.
3. **Cross-language or heavy paraphrase needs**: we need semantic matching across locales or across very different wording styles, not just exact API names, error messages, commands, and options.
4. **Scale/operational constraints justify server-side retrieval**: the docs corpus or access-control model becomes too large or dynamic for public static JSON artifacts. Even then, that justifies hosted retrieval infrastructure; embeddings are justified only if semantic retrieval also improves quality.

What we should keep even if we add embeddings:

- Keep leadtype as the **source-of-truth docs pipeline**: MDX flattening, generated markdown, `llms.txt`/agent artifacts, and search chunk generation.
- Keep the **BM25/static lexical index** as a baseline, fallback, and often as part of a **hybrid retrieval** system.
- Keep lexical retrieval for exact-match-heavy docs queries: API names, config keys, CLI flags, error strings, code identifiers, package names, and versioned paths.
- Keep leadtype’s **source-grounded answer behavior**: answer only from retrieved docs context, cite sources, and report insufficient context rather than hallucinating.
- If vectors are added, use them to supplement or rerank leadtype chunks, not to replace the docs corpus or citations. The answer context should still point back to the original leadtype-generated chunks/pages.

In short: start with leadtype’s built-in static BM25 search and grounded answer context. Add embeddings only after query evidence shows semantic recall gaps that lexical search plus synonyms/content improvements cannot solve, and keep BM25 + leadtype chunks for exactness, fallback, and citations.
