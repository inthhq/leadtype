# Leadtype Docs Search & RAG Architecture

Before standing up a hosted, database-backed vector database for documentation search and RAG, it is highly recommended to understand what `leadtype` provides out of the box. 

`leadtype` ships with a zero-infrastructure, serverless, edge-safe docs search and RAG pipeline that achieves extremely high relevance with zero runtime cost, no cold starts, and no database synchronization overhead.

---

## 1. What Leadtype's Docs Search Uses by Default

By default, `leadtype` uses a **static, client-side, edge-compatible BM25 (Best Matching 25) search index**. It generates this index at build time as highly optimized JSON artifacts (`search-index.json` and optionally `search-content.json`).

At query time, the search runs locally (either in the user's browser, in a serverless function, or on an edge worker) using a lightweight runtime.

### Key Features of Leadtype's Default Search Runtime:

1. **Deterministic, Field-Weighted BM25 Scoring**:
   Relevance is calculated dynamically based on term frequency and document length, with built-in weights for different document sections:
   * **Title Weight**: `4.0`
   * **Heading Weight**: `2.0`
   * **Body Weight**: `1.0`
   * **Code Weight**: `0.35` (e.g., inside code fences)

2. **Advanced Term Expansion & Weighting**:
   To catch queries that don't match the written text exactly, the query engine expands and weights terms using a variety of fallbacks:
   * **Exact Matches** (Weight: `1.0`)
   * **Stemming / Stemmed Matches** (Weight: `0.82`): Custom suffix stemming matches pluralizations or conjugations (e.g., matching "setup/installing/installed" to "install").
   * **Synonym Mappings** (Weight: `0.72`): Includes a robust built-in synonym dictionary mapping common tech synonyms (e.g., `ai` &rarr; `llm`/`agent`, `config` &rarr; `settings`, `install` &rarr; `setup`/`add`, `typescript` &rarr; `ts`).
   * **Prefix Matches** (Weight: `0.55`): Matches partial query starts up to a configured threshold.
   * **Typo Tolerance** (Weight: `0.45`): Corrects typographical errors using Levenshtein distance calculations (supporting up to an edit distance of 1 or 2 depending on term length).

3. **Phrase & Proximity Boosting**:
   To ensure multi-word search queries (e.g., "install cli command") are ranked correctly:
   * **Phrase Matches** receive a **`1.4` boost** if the terms appear exactly sequentially in the content.
   * **Ordered Proximity Matches** receive a **`0.8` boost** if terms appear close to each other within an 8-word window (`PROXIMITY_WINDOW = 8`).

4. **Zero-Database Retrieval & Low Latency**:
   The entire search index is compressed into a static JSON artifact. There are no hosted servers, database connections, or API round-trips required to perform a search. It runs in sub-milliseconds on client browsers or edge platforms (Next.js, Astro, Cloudflare Workers, etc.).

5. **Native RAG and LLM Prompt Generation**:
   `leadtype` has first-class primitives for building AI answers. The `createAnswerContext` helper does the following:
   * Runs the local search over the index.
   * Extracts the top `maxSources` chunks.
   * Automatically formats a structured system prompt and context complete with bracket citations (e.g., `[1]`, `[2]`).
   * Prevents LLM hallucinations by structuring strict instructions (e.g., *"Do not invent APIs, options, behavior, paths, or package names."*).
   * Generates prompt payloads ready to stream responses through Vercel AI SDK, TanStack AI, or Cloudflare AI. **This enables highly effective RAG without ever needing a vector database!**

---

## 2. When Embeddings are Warranted (and What to Keep)

While `leadtype`'s default BM25 keyword approach is incredibly accurate and fast for developer documentation, there are specific situations where incorporating a dense vector (embedding) index makes sense.

### Specific Conditions Warranting Embeddings:

* **High Semantic/Conceptual Disconnect**: When users ask questions in abstract, conceptual terms rather than literal code terms. For example, a user searching for *"How do I undo a mistake"* won't match a BM25 keyword index if the documentation only uses the word *"Rollback"* or *"Revert"* (and those aren't mapped in synonyms).
* **Cross-Lingual or Multi-Lingual Search**: When documentation is written in English, but users query in Spanish, French, or Japanese. Vector spaces can map meanings across languages naturally, which BM25 keyword engines cannot do without full translations or massive dictionary mapping.
* **Extremely Large, Unstructured Corpora**: If the docset scales to hundreds of thousands of unstructured files where manually maintaining synonyms is unfeasible, semantic embeddings can automate topic mapping.

### What We Should Keep Even When Adding Embeddings (Hybrid Search)

If we do decide to integrate a hosted vector database or add embeddings, **we must not discard leadtype's built-in pipeline**. Instead, we should build a **Hybrid Search** architecture (using techniques like **Reciprocal Rank Fusion - RRF**) to combine them. 

Specifically, we should keep:

1. **The BM25 Keyword Index (Crucial for Docs)**:
   * **Vector search is notoriously bad at exact code syntax matching**. If a developer searches for a specific CLI flag (e.g., `--bundle`), an exact function name (e.g., `createAnswerContext`), or an error code, a vector embedding will often fetch conceptually similar but syntactically wrong pages.
   * BM25 is highly precise for exact string matches and code tokens. Combining BM25 and Vector scores provides the industry-standard gold standard for documentation RAG.

2. **Leadtype's MDX and Content Processing Pipeline**:
   * Even for a vector database, files must be parsed, cleaned, and split into chunks.
   * Keep `leadtype`'s build-time pipeline because it handles flattening MDX/React components into clean, plain markdown, stripping unneeded elements (frontmatter, control characters), segmenting text logically into chunks with heading hierarchy paths, and generating slug anchors.

3. **Leadtype's RAG Prompting & Citation Primitives**:
   * The RAG instruction structure provided by `createAnswerContext` is highly refined. It formats citations, handles strict instructions against hallucinating APIs, and controls chunk size limits (`maxContextChars`). This logic should be kept to feed the LLM, regardless of whether the retrieved sources come from BM25, vectors, or both.
