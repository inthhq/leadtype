# Leadtype docs search vs. a hosted vector index

## What Leadtype uses by default

Leadtype already ships docs search without a hosted database or vector store. By default it generates static JSON artifacts for the docs site and queries them with an edge-safe lexical search runtime:

- `leadtype generate` emits website search artifacts such as `docs/search-index.json` and `docs/search-content.json`.
- The index is a local/static BM25-style inverted index over documentation chunks.
- Chunks are built from flattened markdown sections, with title, description, heading path, body text, and code treated separately.
- Ranking includes field weights, BM25 normalization, phrase/proximity boosts, stemming, prefix matching, typo tolerance, and built-in/custom synonyms.
- The runtime can run in the browser, workers, or server routes by fetching those static artifacts; it does not require a database.
- If we want AI answers, Leadtype can build a source-grounded answer context from the same search results and content chunks, with citations and instructions to use only the provided docs context.

So the default is not “RAG = embeddings + hosted vector DB.” It is static, docs-specific BM25 retrieval plus optional source-grounded answer generation.

## When embeddings are warranted

Add embeddings only if we can show that the default lexical search is the bottleneck. Concretely, embeddings are warranted when all of these are true:

1. We have real query logs or evaluation queries where Leadtype’s default search misses relevant docs.
2. The misses are semantic/paraphrase misses, not fixable by better headings, terminology, frontmatter, synonyms, or search transformers.
3. Users commonly search with concepts that do not share words with the docs, or we need cross-lingual/conceptual retrieval where lexical matching is inherently weak.
4. The improved recall justifies the extra system: embedding generation, model/version management, re-indexing, hosted storage, latency, cost, auth, observability, and failure modes.

Even then, we should keep Leadtype’s pipeline as the source of truth and keep lexical search in the retrieval stack:

- Keep Leadtype’s markdown flattening, section chunking, canonical URLs, headings, and generated content store as the source material for any embeddings.
- Keep BM25 search as a hybrid retriever and/or fallback; it is better for exact API names, option flags, errors, code identifiers, and recent terminology.
- Keep Leadtype’s source-grounded answer context, citations, and “do not invent” constraints so any AI answer remains tied to docs chunks rather than free-form generation.
- Keep static artifacts for simple docs search and resilience, even if a vector service is added for semantic recall.
