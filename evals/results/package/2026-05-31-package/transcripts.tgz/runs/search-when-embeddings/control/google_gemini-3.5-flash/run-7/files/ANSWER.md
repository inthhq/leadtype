# Leadtype Documentation Search Analysis

Our team is considering building a hosted, database-backed vector search index for RAG (Retrieval-Augmented Generation). Before doing so, this document details what `leadtype` already provides out-of-the-box and the trade-offs involved in moving to a vector/embeddings model.

---

## 1. What Leadtype's Docs Search Uses by Default

By default, `leadtype` delivers a highly optimized, **zero-dependency, static, edge-safe, client-runnable lexical search index**. Rather than requiring an active server database, it packages docs into a structured index (`search-index.json`) that can be loaded instantly in browser environments or edge/serverless runtimes (such as Vercel, Cloudflare, Next.js, and TanStack Start).

Its technical implementation includes:

*   **BM25 (Best Matching 25) Algorithm:** It utilizes BM25, the industry-standard lexical retrieval scoring function that ranks documents based on term frequency and document length normalization.
*   **Field-Specific Weighting:** Content is segmented and scored according to where the search term appears:
    *   **Document Title:** Weight of `4.0`
    *   **Section Headings:** Weight of `2.0`
    *   **Body Text:** Weight of `1.0`
    *   **Code Snippets:** Weight of `0.35`
*   **Intelligent Text Processing & Tokenization:**
    *   **Normalization:** Strips diacritics and converts to lowercase.
    *   **Stopword Filtering:** Excludes common filler words (e.g., "the", "and", "how", "what") to focus on valuable keywords.
    *   **Stemming:** Simplifies plural and tense suffixes (e.g., `ies`, `ing`, `ed`, `es`, `s`) to match base root words.
*   **Five-Tier Query Expansion & Term Boosting:**
    1.   **Exact Matches:** Full relevance weight (`1.0`).
    2.   **Stemmed Matches:** High relevance weight (`0.82`) for word variations.
    3.   **Synonym Mapping:** Medium-high weight (`0.72`) mapped to custom and built-in synonym sets (e.g., `ai` matching `agent` and `llm`; `ts` matching `typescript`).
    4.   **Prefix-Matching:** Medium weight (`0.55`, up to 24 expansions) to instantly return results as users type.
    5.   **Typo Tolerance:** Low-medium weight (`0.45`, up to 16 expansions) computed using Levenshtein Edit Distance ($\le 1$ or $2$ depending on term length).
*   **Contextual Matching Boosts:**
    *   **Phrase Match Boost (`1.4`):** Boosts the document score if search query terms appear sequentially.
    *   **Ordered Proximity Match Boost (`0.8`):** Boosts the score if keywords appear close to each other within an 8-token sliding window.
*   **Boundary-Aware Chunking:** Chunks text segments dynamically up to `maxChunkChars = 1200` with an overlap of `overlapChars = 160`. It breaks on natural sentence/space boundaries to keep the extracted semantic context coherent.
*   **Source-Grounded Prompt Generation:**
    *   Via `createAnswerContext`, it matches the query, builds citations, and formats a secure, structured system instruction block. This tells LLMs to only answer questions based on the provided reference text, cite brackets, avoid inventing APIs, and handle lack of context gracefully.

---

## 2. When to Add Embeddings (and What to Keep)

Adding a hosted, database-backed vector search index introduces operational complexity, hosting costs, external API latencies, and maintenance overhead. 

### A. Specific Conditions Where Vector Embeddings are Warranted:
1.  **Massive Scale (Corpus Size):** When documentation spans thousands of pages, the compiled `search-index.json` becomes too large (e.g., several megabytes) to download to the client's browser or load inside memory-constrained edge workers.
2.  **Conceptual/Abstract Retrieval:** When users query with abstract conceptual questions or high-level architecture designs (e.g., "How do I make my server secure?") where exact terminology might not overlap with the written text, and simple synonyms or stemming can't capture the relationship.
3.  **Cross-Lingual/Multi-lingual Queries:** When users query in languages other than the main documentation language, and pre-translated static pages are not available. Dense vector spaces map meanings across languages natively.

### B. What We Should Keep Even When Adding Embeddings:
If we do decide to introduce a vector database, we should build a **hybrid search system** and retain key elements of the `leadtype` pipeline:

1.  **Lexical Retrieval (Hybrid Search):** Dense vector search is notoriously bad at locating exact API keywords, method signatures, error messages, code snippets, or configuration flags (e.g., searching for `TypeError: Cannot read properties of undefined` or `--force-all`). We must combine the BM25 lexical scores from `leadtype` with vector scores (e.g., via Reciprocal Rank Fusion / RRF) to prevent the search from failing on developer-centric keyword queries.
2.  **Content Chunking and Flattening Pipeline:** `leadtype`'s robust engine parses MDX files, flattens JSX components, resolves includes, validates frontmatter, and chunks text cleanly. Rather than feeding raw Markdown or HTML into an embedding generator, we should use `leadtype`'s clean chunk extractor as the ingestion source for the vector index.
3.  **Local/Offline Developer Experience (DX):** `leadtype` bundles version-matched `AGENTS.md` and offline markdown folders directly into our npm package dependencies. Local coding assistants (Cursor, Copilot, Cline, etc.) can read these docs offline from `node_modules` instantly, completely bypassing network API calls or vector database latency.
4.  **Strict Prompt Grounding:** Retain `leadtype`'s battle-tested system prompt formatting and rate-limiting wrapper logic from `createAnswerContext` to prevent LLM hallucination and ensure reliable, source-cited responses.
