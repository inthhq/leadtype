# Leadtype Docs Search & Retrieval Analysis

This document details what the `leadtype` package provides by default for documentation search and outlines the conditions under which migrating to or adding database-backed vector embeddings is actually warranted.

---

## 1. What Leadtype's Docs Search Uses by Default

By default, `leadtype` delivers a highly optimized, **infrastructure-free, static docs search** that runs entirely on the client-side or at the edge. It does not require a hosted database or server.

### Core Architecture
- **Static Artifacts**: At build time, `leadtype` converts your MDX files into clean markdown and exports two highly compressed search JSON artifacts:
  - `search-index.json`: A static inverted index containing term maps, titles, headings, and chunk lengths.
  - `search-content.json`: A static content store holding the segmented, clean-text chunks of your documents.
- **Client-Side / Edge Runtime**: A lightweight runtime (`leadtype/search/client` or serverless/edge adapters) fetches these static JSON files once and performs all search and ranking operations locally in milliseconds.

### Search Algorithm & Retrieval Logic
Instead of vector embeddings, `leadtype` implements a highly refined, deterministic **BM25 (Best Matching 25) search engine**:
- **BM25 Retrieval**: Uses standard BM25 scoring parameters ($k_1 = 1.2$ and $b = 0.75$) to evaluate the relevance of document chunks based on term frequency and document length.
- **Weighting by Document Part**: Scores are boosted according to where the term matches, ensuring structural search precision:
  - **Title Matches**: `TITLE_WEIGHT = 4`
  - **Heading Matches**: `HEADING_WEIGHT = 2`
  - **Body Matches**: `BODY_WEIGHT = 1`
  - **Code Block Matches**: `CODE_WEIGHT = 0.35`
- **Smart Chunking**: Splits documentation into overlapping chunks (by default, `maxChunkChars: 1200` with `overlapChars: 160`) bounded cleanly at sentence and space boundaries.
- **Synonym Expansion & Stemming**:
  - Implements a built-in English stemmer (handling verb conjugations, plurals, and suffixes like `-ies`, `-ing`, `-ed`, `-es`, `-s`).
  - Supports custom and default synonyms (e.g., mapping `auth` $\to$ `authentication`, `login`, `signin`; `cli` $\to$ `command`, `terminal`).
- **Typo Tolerance & Prefix Matching**:
  - Uses Levenshtein edit distance calculations (up to distance 2 for longer terms) to handle typos gracefully.
  - Expands query prefixes automatically to match partial user queries during typing.
- **Phrase and Proximity Boosting**:
  - **Phrase Match Boost**: Scores are boosted by `1.4` when multi-word search queries appear exactly in order inside the text chunk.
  - **Proximity Match Boost**: Scores are boosted by `0.8` if search query terms appear close to each other (within an 8-word window).

### Built-in Source-Grounded RAG (No Vector DB Required)
Through the `createAnswerContext` helper (and adapters for Next.js, TanStack Start, Cloudflare AI, and Vercel AI), `leadtype` implements a **full RAG context assembler out-of-the-box**:
1. It queries the local static BM25 index to find the most relevant context chunks.
2. It aggregates these chunks, automatically matching target context budgets (defaulting to 12,000 characters across up to 6 sources).
3. It constructs a system-prompt with citations, guiding an LLM to answer user queries using only the retrieved documentation context.
4. **Result**: Your team can implement source-grounded chatbot answers immediately without any hosted vector database.

---

## 2. When Adding Embeddings Is Warranted (and What to Keep)

A hosted, database-backed vector database (dense vector embeddings) is a powerful tool, but it is not a silver bullet. 

### Specific Conditions That Warrant Adding Embeddings
Deploying vector embeddings is justified **only** when your search requirements meet one or more of the following conditions:

1. **Highly Conceptual / Abstract Queries**: Users frequently search using ideas, descriptions, or synonyms that do not share exact words or stems with your documentation (e.g., a user searching for *"how to make sure no one else reads my data"* when the documentation strictly uses the technical term *"symmetric AES-256 payload encryption"*).
2. **Conversational, Subjective, or Fuzzy Q&A**: When users ask long, conversational questions where keyword matching fails because common conversational filler words dominate the BM25 query terms.
3. **Cross-Lingual Search**: When documentation is written in one language (e.g., English), but users need to query and receive relevant document chunks in other languages (e.g., Spanish, Japanese) via a multilingual embedding model (like `text-embedding-3-large` or Cohere Multilingual).
4. **Vast, Unstructured, or Ever-Expanding Datasets**: If your documentation spans millions of pages across many disjointed products where maintaining custom BM25 synonym maps and dictionaries is no longer scalable.

### What We Should Keep Even Then (Hybrid Search)
If you decide to deploy dense vector embeddings, you **must not discard BM25 keyword search**. Instead, you should implement **Hybrid Search** (combining both dense vector and keyword retrieval, typically ranked using Reciprocal Rank Fusion or a re-ranking cross-encoder).

You must keep BM25 and leadtype's static indexing logic because:
- **Exact Match Precision**: Embeddings are notoriously bad at finding exact matches. If a developer searches for a specific CLI flag (e.g., `--base-url`), a specific error code (e.g., `413`), a configuration option, or a precise API method (e.g., `createDocsSearchIndex`), a vector model will often retrieve unrelated chunks that look semantically similar, whereas BM25 will instantly pinpoint the exact API reference chunk.
- **Code & Syntax Term Match**: Documentation is uniquely dense with syntax, package names, import statements, and code blocks. BM25 treats these as exact symbols and weights them perfectly, whereas vector embeddings often wash out syntactic differences.
- **Latency, Fallbacks, and Client-Side Autocomplete**: `leadtype`'s static index can be loaded directly on the client with zero network-hop latency to power immediate, instantaneous as-you-type search autocompletion. Having this static index means your docs search is robust and continues to work offline or if your vector database suffers an outage.
