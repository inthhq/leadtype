# Leadtype Docs Search & RAG Architecture Analysis

Before building a hosted, database-backed vector search system for document RAG, here is an evaluation of what `leadtype` already provides and the trade-offs of adding vector embeddings.

---

## 1. What Leadtype's Docs Search Uses by Default

By default, `leadtype` implements a highly optimized, **static keyword-based search engine** that runs entirely at the edge or client-side. Here is how it is structured:

### A. Core Retrieval Algorithm: BM25
The search uses **BM25 (Best Matching 25)** under the hood. BM25 is a robust, classical ranking function that scores document relevance based on:
- **Term Frequency (TF):** How often the query terms appear in a chunk.
- **Inverse Document Frequency (IDF):** Scaling down the score of extremely common terms.
- **Document Length Normalization:** Penalizing extremely long chunks to prevent term-stuffing.
- **Field Weighting:** The index weights matches differently depending on where the query term is found (scoring hits in `title` and `heading` higher than in `body` and `code`).

### B. Generated Build-Time Artifacts
When running the `leadtype generate` pipeline, it analyzes MDX documents, partitions them into granular chunks (divided by sections/headings), and outputs two static JSON artifacts to the public/output folder:
1. **`search-index.json`**: A compressed BM25 search index. It contains term posting lists, document listings, chunk metadata, and term statistics.
2. **`search-content.json`**: The raw text content of the chunks (which can also be embedded directly in the index via the `embedContent` configuration).

### C. Client/Edge Runtime
To query the index, `leadtype/search/client` provides a vanilla `createSearchClient` (along with React/Vue/Svelte wrappers). 
- It fetches the static JSON files once (or preloads them).
- It executes search queries **entirely in-memory** within the browser, edge function (e.g., Cloudflare Workers), or serverless context.
- **No external hosted database or search server is required.**

### D. Out-of-the-Box RAG Support
Instead of requiring an embedding model and a vector store to retrieve context for an LLM, `leadtype`'s search utilities include:
- **`createAnswerContext`**: An API that performs a fast BM25 local search for a query, extracts the top-scoring content chunks, and builds a fully formatted `system` and `user` prompt structure including sources and citations.
- **Streaming Adapters**: Native integrations under `leadtype/search/vercel`, `leadtype/search/tanstack`, and `leadtype/search/cloudflare` that take this retrieved BM25 context and stream answers using the Vercel AI SDK or TanStack AI, enabling fully functional RAG with zero database infra.

---

## 2. When Are Embeddings Actually Warranted, and What to Keep?

### When Are Vector Embeddings Warranted?
Adding semantic vector embeddings (dense retrieval) is only warranted under the following specific conditions:
1. **Conceptual, Non-Keyword Queries:** When users search using synonyms or describe what they want to achieve without using the exact terminology of your docs (e.g., searching for "package configuration" when the documentation refers only to "bundling options").
2. **Conversational, High-Level Questions:** When users ask complex, conversational questions ("How do I prevent my build from failing due to file system boundaries on Cloudflare?") where semantic matching of the user's intent is more reliable than looking up exact keywords.
3. **Cross-Lingual Retrieval:** When users query in different languages, and you want to retrieve the relevant English-language documentation utilizing cross-lingual or multilingual embedding models.

### What We Should Keep Even Then (Hybrid Search)
If you decide to stand up a vector database, **you should not discard leadtype's BM25 search**. Instead, you must implement **Hybrid Search** (combining BM25 and Vector Search using a strategy like Reciprocal Rank Fusion - RRF) and keep the static BM25 system as a baseline for the following reasons:

1. **Exact Matches for Technical Tokens (Syntax, Code, CLI Flags):**
   Developers frequently search for exact strings, such as CLI flags (e.g., `--bundle`), method names (e.g., `defineDocsConfig`), specific error codes, or package names. Vector embedding models are notoriously poor at locating exact technical identifiers because they map terms semantically (e.g., a model might think `defineDocsConfig` is semantically similar to `createSearchClient` because they are both configuration functions, leading to false positives). BM25 handles exact technical token and keyword matches perfectly.
2. **Instant, Zero-Cost Client-Side Baseline & Fallback:**
   The `leadtype` local BM25 search is instant, has zero runtime hosting cost, operates offline, and is edge-native. It serves as an excellent fallback system if the vector database API is slow, rate-limited, down, or incurs prohibitive token costs.
