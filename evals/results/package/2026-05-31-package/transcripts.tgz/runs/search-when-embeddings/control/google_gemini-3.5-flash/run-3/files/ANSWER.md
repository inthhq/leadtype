# Documentation Search with `leadtype`: Evaluation and RAG Strategy

Before standing up a hosted, database-backed vector database for documentation search, here is an evaluation of what `leadtype` already provides out-of-the-box, when adding embeddings (semantic search) is actually warranted, and what architectural pieces we must retain.

---

## 1. What `leadtype` Docs Search Uses By Default

By default, `leadtype` provides a **static, edge-safe keyword search index** that does not require a database, server, or cloud dependency. It compiles documentation during the build step into lightweight `search-index.json` and `search-content.json` static artifacts, which can be fetched and queried entirely client-side or within edge/serverless functions.

Under the hood, `leadtype`'s search engine is highly optimized and implements a sophisticated search pipeline:

### Key Core Features
*   **BM25 Scoring Algorithm:** It implements the industry-standard Best Matching 25 (BM25) ranking function (with default coefficients $k_1 = 1.2$ and $b = 0.75$) to evaluate relevance based on term frequency and document length normalization.
*   **Structured Document Weighting:** It assigns different weights depending on where a keyword match occurs in the document:
    *   **Title Weight:** `4.0`
    *   **Heading Weight:** `2.0`
    *   **Body Text Weight:** `1.0`
    *   **Code Block Weight:** `0.35` (optimizes code matching without letting code syntax overwhelm prose scores)
*   **Phrase & Proximity Boosting:** 
    *   **Phrase Match Boost (`1.4`):** If query terms appear consecutively as an exact phrase in the text, the score is boosted.
    *   **Proximity Match Boost (`0.8`):** If query terms appear near each other within an $8$-word sliding window in the correct order, it applies a proximity boost.
*   **Advanced Linguistic Enhancements:**
    *   **Stemming:** It strips common plural and verb inflections (e.g., `-ies` to `-y`, `-ing`, `-ed`, `-es`, `-s`) so searches for "queries" match "query" or "setup" matches "setting".
    *   **Synonym Expansion:** It maps common developer terminology interchangeably out of the box (e.g., `ai` $\leftrightarrow$ `agent` / `llm`, `auth` $\leftrightarrow$ `login` / `signin`, `cli` $\leftrightarrow$ `terminal`, `ts` $\leftrightarrow$ `typescript`) and supports custom synonym dictionaries.
    *   **Prefix Expansion:** Expands search tokens to match prefixed terms in the index (up to 24 expansions).
    *   **Typo Tolerance:** Computes Levenshtein/edit distance to match misspelled words (up to 16 expansions).
*   **RAG & LLM Integration (Context Compiler):** It contains a built-in `createAnswerContext` utility that constructs system prompts and context blocks with automatic citation mappings (e.g., `[1]`, `[2]`), making it 100% ready for streaming RAG responses using the Vercel AI SDK, Cloudflare AI Gateway, or TanStack AI out-of-the-box.

---

## 2. When to Add Embeddings (and What to Keep)

### Conditions Under Which Adding Embeddings Is Warranted
While "vector search" is popular, standing up a hosted vector database is only actually warranted under the following specific conditions:

1.  **Vocabulary / Conceptual Mismatch:** When users frequently search using highly abstract concepts, metaphors, or intent-based queries that have *zero keyword overlap* with the documentation (e.g., a user searching "how to secure my app" when the docs only use technical keywords like "JSON Web Tokens", "cors", and "auth middleware").
2.  **Cross-Lingual Queries:** When users write queries in their native languages (e.g., Spanish, Japanese) and expect them to match English documentation based on semantic intent rather than literal character mapping.
3.  **Massive Scale Document Corpuses:** When the documentation comprises tens of thousands of deeply heterogeneous pages where standard lexical search suffers from high collision, and vector search can help prune top-level semantic areas before scoring.

### What We Must Keep Even If We Use Embeddings
If we do decide to introduce embeddings, **we must not throw away `leadtype`'s architecture**. Instead, we should implement a **Hybrid Search** model and preserve these critical pieces:

*   **Keyword/BM25 Search Index:** Pure vector search is notoriously poor at finding **exact matches, API signatures, function/variable names** (e.g., searching for `createDocsSearchIndex`), **CLI flags**, and **error codes**. We must combine the BM25 lexical results with vector results (e.g., using Reciprocal Rank Fusion / RRF) so users can still search for exact code and API references.
*   **MDX Parsing, Cleaning, and Chunking:** To generate high-quality embeddings, you need clean text chunks. `leadtype`'s build-time parser is exceptional: it strips frontmatter, flattens MDX components, isolates code blocks, splits sections logically by headings with overlap controls (`maxChunkChars` & `overlapChars`), and generates structured metadata. We should reuse this exact chunking pipeline to feed our embedding models.
*   **Offline Agent Support (`AGENTS.md` and `llms.txt`):** Modern coding agents (such as Cursor, Copilot, or Claude Code) read documentation directly from the user's filesystem (`node_modules/` or the package root). They **do not** query hosted vector databases. `leadtype` bundles offline, agent-readable mirrors (`AGENTS.md` and `docs/*.md`) right inside the package so LLM tools have version-matched local access. We must keep these files intact.
*   **Context/Prompt Compiler and Streaming Adapters:** The `leadtype/search/vercel`, `leadtype/search/cloudflare`, and `leadtype/search/tanstack` adapters are framework-agnostic. The prompt compilation logic (`createAnswerContext`), citation mapping, and edge-safe streaming layers should be retained to handle the LLM interaction after results are retrieved.
