# leadtype docs search: default behavior and when embeddings make sense

## 1. What leadtype uses by default

leadtype ships a **static, edge-safe, lexical search index** that requires no database or vector store.

- **Build time**: `leadtype generate` (or `generateDocsSearchFiles`) writes two JSON files:
  - `search-index.json` — a compact BM25 index with term postings, document refs, and chunk refs.
  - `search-content.json` — the actual chunk text used for excerpts and answer context.
- **Runtime**: `searchDocs` queries those JSON files locally. It is dependency-free and works on Vercel Edge, Cloudflare Workers, and browsers.
- **Ranking**: BM25 with tuned field weights — titles 4×, headings 2×, body 1×, code 0.35×.
- **Query expansion**: Lightweight stemming, prefix matches, typo-tolerant fallbacks, and a small built-in synonym map. Exact matches retain the highest weight so API names, config keys, and error messages stay precise.

In short, the default is a static BM25 index over heading-aware chunks, fetched and queried without any hosted infrastructure.

## 2. When adding embeddings is warranted — and what to keep

Add embeddings **only** when:

1. **Vocabulary mismatch** — users search with words that do not appear in the docs (e.g., "make it faster" should surface a "performance optimization" page).
2. **Scale pressure** — the docs grow past tens of thousands of chunks and the cold-start memory cost of loading the static JSON index becomes noticeable.

**Even then, keep the lexical index.**

- The BM25 index should remain the primary path for exact matches (API names, config keys, paths, error strings).
- Layer embeddings on top as a complementary retrieval path, not a replacement.
- Hybrid retrieval (lexical + semantic) gives the precision of exact matching plus the recall of semantic similarity.
