# Answer

## 1. Single `leadtype generate` invocation

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://your-domain.com
```

- `--docs-dir docs` mounts the main docs folder at the generated docs root.
- `--docs-dir changelog=/changelog` mounts the sibling `changelog/` folder with its **own public URL prefix** (`/changelog`) instead of nesting it under `/docs/changelog`.
- `--base-url` is required so that canonical links (in `llms.txt`, sitemap, search metadata, and `agent-readability.json`) are absolute.

## 2. What it emits for `changelog/v1.mdx`

| Artifact | Path / URL |
|----------|------------|
| **Internal generated copy** (for search & runtime helpers) | `public/docs/changelog/v1.md` |
| **Public static mirror** (served directly) | `public/changelog/v1.md` |
| **Canonical URL agents see** | `https://your-domain.com/changelog/v1.md` |

Leadtype keeps the internal copy under `public/docs/changelog/v1.md` so the static search index and runtime helpers can still find and index the page. At the same time, it writes a public mirror at `public/changelog/v1.md` and points all canonical metadata—`llms.txt`, sitemap entries, `agent-readability.json`, and search-index references—to `/changelog/v1.md` (resolved absolutely via `--base-url`).
