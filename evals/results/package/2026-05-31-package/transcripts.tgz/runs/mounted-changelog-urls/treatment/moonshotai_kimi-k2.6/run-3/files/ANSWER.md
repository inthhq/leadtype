# Serving `changelog/` under `/changelog/...`

## 1. Single `leadtype generate` invocation

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

The `changelog=/changelog` mount syntax tells Leadtype to keep the changelog content searchable (it is still indexed from the internal docs tree) while giving it its own public URL prefix. The first folder (`docs`) remains mounted at the generated docs root as usual.

## 2. What is emitted for `changelog/v1.mdx`

| Artifact | Path / URL | Purpose |
|---|---|---|
| **Internal generated copy** | `public/docs/changelog/v1.md` | Used by the search indexer and runtime helpers (e.g. `readDocsContentFile`, answer streaming). This is what makes the page searchable even though it is not served under `/docs/...`. |
| **Public static mirror** | `public/changelog/v1.md` | The static markdown file served at `/changelog/v1.md` on the site. |
| **Canonical URL agents see** | `/changelog/v1.md` (resolved against `--base-url`) | Used in `llms.txt`, `llms-full.txt`, sitemap entries, search metadata, and `agent-readability.json`. Agents and crawlers are directed to the `/changelog/...` URL, not `/docs/changelog/...`. |
