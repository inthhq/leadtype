# Serving `changelog/` beside `docs/` under `/changelog/...`

## 1. Single `leadtype generate` invocation

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public
```

The `=<url-prefix>` syntax tells leadtype to mount the `changelog` folder at its own public route (`/changelog`) instead of nesting it under `/docs/changelog`.

## 2. What is emitted for `changelog/v1.mdx`

| Artifact | Path / URL | Purpose |
|---|---|---|
| **Internal generated copy** | `public/docs/changelog/v1.md` | Kept inside the docs tree so search indexes, runtime helpers, and the source primitive can still find it. |
| **Public mirror** | `public/changelog/v1.md` | A static markdown mirror written at the root-level `changelog/` output directory, served directly at `/changelog/v1.md`. |
| **Canonical URL (agents)** | `/changelog/v1.md` | Emitted as the canonical link in `llms.txt`, `llms-full.txt`, search metadata, sitemap entries, and `agent-readability.json`. If you also pass `--base-url`, that becomes the absolute canonical URL (e.g. `https://example.com/changelog/v1.md`). The human-readable page route is `/changelog/v1`. |
