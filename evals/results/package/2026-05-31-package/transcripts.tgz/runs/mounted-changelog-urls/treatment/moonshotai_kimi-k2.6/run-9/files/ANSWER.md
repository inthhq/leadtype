# Serving `changelog/` under `/changelog/...`

## 1. Single `leadtype generate` invocation

Use the `<dir>=<url-prefix>` syntax on `--docs-dir` to mount the sibling `changelog/` folder at its own public URL prefix while keeping the main docs tree intact.

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

- `--docs-dir docs` mounts the primary docs tree normally (pages appear under `/docs/...`).
- `--docs-dir changelog=/changelog` tells Leadtype that `changelog/` should **not** be nested under `/docs/changelog/...`; instead it gets its own root-level prefix `/changelog`.
- `--base-url` is required so canonical links, sitemap entries, and search metadata can be produced.

## 2. What it emits for `changelog/v1.mdx`

| Artifact | Path / Value | Purpose |
|----------|--------------|---------|
| **Internal generated copy** | `public/docs/changelog/v1.md` | Kept inside the generated docs tree for the **search index** and runtime helpers (e.g. `createDocsSource`, `agent-readability.json` lookups). |
| **Public mirror** | `public/changelog/v1.md` | A static markdown mirror written directly to the public path so HTTP agents requesting `Accept: text/markdown` (or direct `.md` URLs) get the flattened file. |
| **Canonical URL agents see** | `/changelog/v1.md` (root-relative) | Emitted in `llms.txt`, `llms-full.txt`, search metadata, sitemap data, and `agent-readability.json`. When fully resolved against `--base-url`, this becomes `https://example.com/changelog/v1.md` for absolute contexts like the XML sitemap. |

In short: Leadtype keeps an internal copy under `public/docs/` so search and navigation still work, but all **agent-facing canonical metadata** points to the public mirror at `/changelog/v1.md` rather than `/docs/changelog/v1.md`.
