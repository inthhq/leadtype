# Serving `changelog/` under `/changelog/...`

## 1. The command

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

The first `--docs-dir docs` mounts the main docs folder at the generated docs
root (`/docs`). The second flag uses the `<dir>=<url-prefix>` form
(`changelog=/changelog`), which gives the sibling `changelog/` folder its own
public URL prefix instead of nesting it under `/docs/changelog/...`.

(Swap `--base-url` for your real production origin; it feeds the canonical links
in `sitemap.xml`, `robots.txt`, search metadata, and the full-context fallbacks.)

## 2. What it emits for `changelog/v1.mdx`

With the `changelog=/changelog` mount, a file like `changelog/v1.mdx` produces:

- **Internal generated copy:** `public/docs/changelog/v1.md`
  This stays under `public/docs/*` so the search index, `search-content.json`,
  and runtime/agent helpers can still find and serve it — the page remains
  searchable.

- **Public mirror:** `public/changelog/v1.md`
  A static markdown mirror written at the root-level `/changelog` prefix, so the
  page is actually served at `/changelog/...` rather than `/docs/changelog/...`.

- **Canonical URL agents see:** `/changelog/v1.md` (i.e. `/changelog/v1`)
  This is the canonical link emitted in `llms.txt`, search metadata, sitemap
  entries, and `agent-readability.json`. Agents are pointed at the `/changelog`
  prefix, not the internal `/docs/changelog` location.

### Why this works (and the contrast)

Without the `=/changelog` suffix — i.e. a plain `--docs-dir changelog` — the
folder would simply nest under the docs root: `changelog/v1.mdx` would become
`public/docs/changelog/v1.md` served at `/docs/changelog/v1`, which is exactly
what we want to avoid. The `<dir>=<url-prefix>` form is what splits the internal
searchable copy (under `/docs`) from the canonical public URL (under
`/changelog`).
