# Mounted changelog URLs

## 1. Single `leadtype generate` invocation

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

(The `= /changelog` mount tells leadtype to give the `changelog/` folder its own public URL prefix instead of nesting it under `/docs`.)

## 2. What gets emitted for `changelog/v1.mdx`

| Artifact | Path / URL | Purpose |
|----------|------------|---------|
| **Internal generated copy** | `public/docs/changelog/v1.md` | Flattened markdown kept inside the docs tree so the static search index and runtime helpers can still read and index the content. |
| **Public mirror** | `public/changelog/v1.md` | A static markdown mirror served directly at `/changelog/v1.md`. |
| **Canonical URL agents see** | `https://example.com/changelog/v1.md` (root-relative `/changelog/v1.md`) | The URL used in `llms.txt`, search metadata, sitemap entries, and `agent-readability.json`. |

Because the internal copy stays at `public/docs/changelog/v1.md`, the page remains fully searchable: the search index reads from that internal path, but every result points to the canonical `/changelog/v1` URL.
