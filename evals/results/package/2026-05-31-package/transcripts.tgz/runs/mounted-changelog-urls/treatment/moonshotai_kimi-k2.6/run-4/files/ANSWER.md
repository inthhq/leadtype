# Serving `changelog/` under `/changelog/...`

## 1. Single `leadtype generate` invocation

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

The `--docs-dir docs` must be repeated explicitly so it remains the first source and stays at the generated docs root. The mount syntax `changelog=/changelog` tells leadtype to copy the sibling `changelog/` folder into its own public URL prefix instead of nesting it under `/docs/changelog/`.

## 2. What it emits for `changelog/v1.mdx`

| Artifact | Path / URL | Purpose |
|---|---|---|
| **Internal generated copy** | `public/docs/changelog/v1.md` | Kept for the search index and runtime helpers so the content is still searchable even though it is not served under `/docs`. |
| **Public mirror** | `public/changelog/v1.md` | The static markdown file actually served at the public route. |
| **Canonical URL agents see** | `https://example.com/changelog/v1` | The canonical page URL emitted in `llms.txt`, sitemap entries, search metadata, and `agent-readability.json`. The `.md` mirror (`https://example.com/changelog/v1.md`) is also listed in `llms.txt` so agents can fetch the raw markdown directly. |
