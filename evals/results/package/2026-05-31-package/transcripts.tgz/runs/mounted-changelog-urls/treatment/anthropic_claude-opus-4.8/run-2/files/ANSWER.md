# Serving `changelog/` under `/changelog/...`

## 1. The command

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public
```

The key is the second `--docs-dir` using the `<dir>=<url-prefix>` form
(`changelog=/changelog`). The first `--docs-dir docs` is mounted at the
generated docs root as usual; appending `=/changelog` to the sibling
`changelog` folder gives it its own public URL prefix instead of being nested
under `/docs/changelog/...`.

Because the changelog is still passed through `leadtype generate`, its pages are
processed by the same pipeline and stay fully searchable (they're indexed in
`public/docs/search-index.json` / `search-content.json` like any other page).

## 2. What gets emitted for `changelog/v1.mdx`

With the `changelog=/changelog` mount, a file like `changelog/v1.mdx` produces:

- **Internal generated copy:** `public/docs/changelog/v1.md`
  This is the canonical on-disk copy that the search index and runtime helpers
  read from — it keeps the changelog discoverable/searchable alongside the rest
  of the docs tree.

- **Public mirror:** `public/changelog/v1.md`
  A static markdown mirror written at the custom prefix so the page is served
  directly under `/changelog/...` rather than `/docs/changelog/...`.

- **Canonical URL agents see:** `/changelog/v1.md`
  This prefixed URL is what's emitted in `llms.txt`, the search metadata, the
  sitemap entries, and `agent-readability.json`.

### Contrast: without the `=/changelog` prefix

If you ran `--docs-dir changelog` (no prefix), the folder would simply be
mounted under its own name inside the docs tree: `changelog/v1.mdx` would become
`public/docs/changelog/v1.md` served at `/docs/changelog/v1.md` — i.e. exactly
the `/docs/changelog/...` URL you want to avoid. The `=/changelog` suffix is what
lifts it out to the site-root prefix while keeping the internal indexed copy.
