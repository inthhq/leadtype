# Answer

## 1. Single `leadtype generate` invocation

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://<your-domain>
```

* `--docs-dir changelog=/changelog` tells leadtype to mount the `changelog/` folder at its own URL prefix (`/changelog`) instead of nesting it under `/docs/changelog`.
* `--base-url` is required so that canonical URLs in `llms.txt`, sitemaps, search metadata, and `agent-readability.json` are absolute.

## 2. What gets emitted for `changelog/v1.mdx`

| Output | Location / URL | Purpose |
|--------|----------------|---------|
| **Internal generated copy** | `public/docs/changelog/v1.md` | Flattened markdown used by the search index and runtime helpers (e.g. `search-index.json`, `search-content.json`). |
| **Public static mirror** | `public/changelog/v1.md` | Served directly to humans and agents at `/changelog/v1.md`. |
| **Canonical URL agents see** | `https://<your-domain>/changelog/v1.md` | Emitted in `llms.txt`, search metadata, `sitemap.xml`, and `agent-readability.json` so agents and crawlers discover the page at its public `/changelog/...` route. |

In short: the pipeline keeps an internal copy under `public/docs/` for searchability, writes a publicly served mirror under `public/changelog/`, and points all canonical metadata at `/changelog/v1.md`.
