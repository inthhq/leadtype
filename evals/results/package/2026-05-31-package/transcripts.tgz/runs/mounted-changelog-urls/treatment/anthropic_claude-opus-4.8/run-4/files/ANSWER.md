# Serving `changelog/` under `/changelog/...`

## 1. The command

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public
```

The key is the `<dir>=<url-prefix>` form on the second `--docs-dir`. Without the
`=/changelog` suffix, the sibling `changelog/` folder would be mounted under the
docs root and served at `/docs/changelog/...`. The explicit `=/changelog` prefix
gives that source folder its own public URL namespace while it still flows
through the same conversion + search pipeline.

- `--docs-dir docs` — the primary source folder, mounted at the generated docs
  root (`/docs`).
- `--docs-dir changelog=/changelog` — the sibling changelog folder, mounted at
  its own public prefix `/changelog`.

## 2. What it emits for `changelog/v1.mdx`

For a source file `changelog/v1.mdx`, the run produces three things:

1. **Internal generated copy** — `public/docs/changelog/v1.md`.
   This stays under the docs tree so it's picked up by the search index and the
   runtime helpers (it's a regular generated page internally).

2. **Public mirror** — `public/changelog/v1.md`.
   A static markdown mirror written at the requested public prefix, so the page
   is actually served from `/changelog/...` rather than `/docs/changelog/...`.

3. **Canonical URL** — `/changelog/v1.md`.
   This is the URL agents see: it's the canonical link emitted into `llms.txt`,
   the search metadata, the sitemap entries, and `agent-readability.json`.

So the page is reachable and canonicalized at `/changelog/v1.md`, while the
internal `public/docs/changelog/v1.md` copy keeps it searchable through the
standard docs search index.
