1. **Invocation**

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

(Substitute your actual `--base-url`.)

2. **What it emits for `changelog/v1.mdx`**

| Artifact | Path / URL |
|---|---|
| **Internal generated copy** | `public/docs/changelog/v1.md` — kept for the search index, runtime helpers, and `agent-readability.json` lookups. |
| **Public mirror** | `public/changelog/v1.md` — served directly at `/changelog/v1.md`. |
| **Canonical URL agents see** | `/changelog/v1.md` (fully qualified as `https://example.com/changelog/v1.md` via `--base-url`) — this is the URL written into `llms.txt`, search metadata, sitemap entries, and `agent-readability.json`. |
