# Serving Changelog Pages Under `/changelog/` (Not `/docs/changelog/`)

## 1. The `leadtype generate` Invocation

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://your-site.com
```

**Key points:**
- `--docs-dir docs` mounts the `docs/` folder at the docs root (so `docs/foo.mdx` → `/docs/foo.md`).
- `--docs-dir changelog=/changelog` mounts the `changelog/` folder with a **custom URL prefix** of `/changelog` instead of the default `/docs/changelog`.
- The syntax is `<source-dir>=<url-prefix>`.

## 2. What It Emits for `changelog/v1.mdx`

### Internal generated copy (for search & runtime):
```
public/docs/changelog/v1.md
```
This always lives under `docs/` because the search index and runtime helpers need all pages in one tree.

### Public mirror (the actual served file):
```
public/changelog/v1.md
```
This is the canonical file served to browsers and agents at the custom URL prefix.

### Canonical URL in metadata:
Agents see `/changelog/v1.md` in:
- `llms.txt` and `llms-full.txt` (the include/link lists)
- `search-index.json` entries (the canonical URL field)
- `sitemap.xml` and `sitemap.md` entries
- `agent-readability.json` metadata

## Why This Works

The `<source>=<url-prefix>` syntax tells leadtype to:
1. **Mount** the source folder under the provided URL prefix (for agent-facing artifacts and links)
2. **Still write** an internal searchable copy under `docs/` (for unified full-text search)
3. **Also emit** a public mirror at the custom prefix (for direct serving)

This allows changelog pages to be:
- ✅ Searchable (indexed in the unified search-index.json alongside docs)
- ✅ Discoverable to agents via their canonical `/changelog/` URLs (not `/docs/changelog/`)
- ✅ Served from both paths (internal copy for search runtime, public copy for browsers)

---

**Alternative using `leadtype.config.ts` (collections mode):**

If you prefer a config file, create `leadtype.config.ts`:

```typescript
import { defineCollection, defineDocsConfig } from "leadtype";

export default defineDocsConfig({
  product: { name: "My Product", summary: "..." },
  collections: {
    docs: defineCollection({ dir: "./docs", prefix: "/docs" }),
    changelog: defineCollection({ dir: "./changelog", prefix: "/changelog" }),
  },
});
```

Then run:
```bash
leadtype generate --src . --out public --base-url https://your-site.com
```

This is cleaner for multi-collection projects; the CLI approach above works for simpler cases without a config file.
