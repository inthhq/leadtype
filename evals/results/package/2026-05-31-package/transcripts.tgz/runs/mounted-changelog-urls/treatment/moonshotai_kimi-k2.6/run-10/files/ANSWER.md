# Mounted Changelog URLs

## 1. `leadtype generate` invocation

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public
```

## 2. What it emits for `changelog/v1.mdx`

| Artifact | Path / URL | Purpose |
|---|---|---|
| **Internal generated copy** | `public/docs/changelog/v1.md` | Kept inside the docs tree so search indexes and runtime helpers can still discover the page. |
| **Public mirror** | `public/changelog/v1.md` | Served directly at `/changelog/v1.md` on the site. |
| **Canonical URL (agents see)** | `/changelog/v1` (and `/changelog/v1.md`) | Used in `llms.txt`, search metadata, sitemap entries, and `agent-readability.json`. |
