# Serving the changelog under `/changelog/...`

## 1. The command

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

The key is the `<dir>=<url-prefix>` form on the second `--docs-dir`:

- `--docs-dir docs` mounts the main docs folder at the generated docs root (served under `/docs`).
- `--docs-dir changelog=/changelog` merges the sibling `changelog/` folder into the generated docs tree (so it stays in the search index and agent helpers) **but** assigns it its own public URL prefix of `/changelog` instead of `/docs/changelog`.

Replace `--base-url` with your real site origin so the canonical links, sitemap entries, and agent metadata resolve to absolute URLs.

> If you'd rather express this in config than flags, the equivalent is a project-level `leadtype.config.ts` with two `defineCollection` entries — `docs` at `prefix: "/docs"` and `changelog` at `prefix: "/changelog"` — then run plain `leadtype generate --src . --out public --base-url ...`. The single-command flag form above is the lightest way to do it.

## 2. What it emits for `changelog/v1.mdx`

With the `changelog=/changelog` mount, leadtype produces three things for that one source file:

1. **Internal generated copy (for search + runtime helpers):**
   `public/docs/changelog/v1.md`
   This stays inside the generated docs tree so the page remains part of `search-index.json` / `search-content.json` and the runtime/source helpers can find it — i.e. it's still searchable.

2. **Public mirror (the static markdown served at the requested prefix):**
   `public/changelog/v1.md`
   A static markdown mirror written at the URL prefix you asked for, so the page is served from `/changelog/...` rather than `/docs/changelog/...`.

3. **Canonical URL agents see:**
   `/changelog/v1` (markdown mirror at `/changelog/v1.md`)
   This is the link emitted in `llms.txt`, the search metadata, `sitemap.xml`, and `agent-readability.json`. Agents discover and cite the page under `/changelog/...`, never under `/docs/changelog/...`.

### Summary

| Artifact | Path / URL |
|--|--|
| Internal generated copy (search) | `public/docs/changelog/v1.md` |
| Public static mirror | `public/changelog/v1.md` |
| Canonical URL (llms.txt, search, sitemap, agent-readability) | `/changelog/v1` (`/changelog/v1.md`) |
