**1. Single `leadtype generate` invocation**

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

* `--src .` – repo root where `docs/` and `changelog/` are siblings.
* `--docs-dir docs` – the primary docs tree.
* `--docs-dir changelog=/changelog` – merges the sibling `changelog/` folder and mounts it at the public URL prefix `/changelog` instead of the default `/docs/changelog`.
* `--out public` – output root (default, included for clarity).
* `--base-url https://example.com` – origin used for absolute canonical links in `llms.txt`, sitemaps, search metadata, and `agent-readability.json`.

**2. Emissions for a file like `changelog/v1.mdx`**

| Artifact | Path / URL | Role |
|---|---|---|
| **Internal generated copy** | `public/docs/changelog/v1.md` | Kept inside the unified docs tree so the page is indexed for search and available to runtime helpers. |
| **Public markdown mirror** | `public/changelog/v1.md` | Written to the public route and served directly at `/changelog/v1.md`. |
| **Canonical URL (agents)** | `/changelog/v1.md` | The URL emitted in `llms.txt`, `llms-full.txt`, search metadata, sitemap entries, and `agent-readability.json` as the canonical markdown link for agents. |

Because the internal copy remains at `public/docs/changelog/v1.md`, the changelog stays fully searchable; because of the `changelog=/changelog` mount, visitors and agents reach it under `/changelog/...` rather than `/docs/changelog/...`.
