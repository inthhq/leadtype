# Mounting `changelog/` at `/changelog/...`

Our repo layout:

```text
.
├── docs/
│   └── …
└── changelog/
    └── v1.mdx
```

We want changelog pages served under `/changelog/...` (not `/docs/changelog/...`)
while still being included in the same search index. leadtype's
`--docs-dir` flag supports a `<dir>=<url-prefix>` mount form that does exactly
this.

## 1. The command

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://docs.example.com
```

- `--docs-dir docs` mounts the primary docs folder at the generated docs root
  (URL prefix `/docs`).
- `--docs-dir changelog=/changelog` mounts the sibling `changelog/` folder with
  its **own** public URL prefix `/changelog` instead of the default
  `/docs/changelog`.
- The `=<url-prefix>` part is the key: without it (`--docs-dir changelog`),
  the folder is mounted under `/docs/changelog/...` instead.

(Adjust `--base-url` to your real host. `--src .` assumes the docs source and the
build run in the same repo; point `--src` at a checkout otherwise.)

## 2. What it emits for `changelog/v1.mdx`

For a source file `changelog/v1.mdx`, the mounted-with-prefix form produces
three things:

| Artifact | Path / value | Purpose |
| --- | --- | --- |
| **Internal generated copy** | `public/docs/changelog/v1.md` | Lives under the docs root so the search index and the runtime/source helpers can read it. This copy always exists regardless of the URL prefix. |
| **Public mirror** | `public/changelog/v1.md` | A static markdown mirror written at the custom prefix, so the file is actually reachable at `/changelog/...` on the served site. |
| **Canonical URL (what agents see)** | `/changelog/v1` (page) and `/changelog/v1.md` (markdown) | The canonical links emitted in `llms.txt`, search metadata, sitemap entries, and `agent-readability.json` all point at the `/changelog/...` prefix — not `/docs/changelog/...`. |

So the page is searchable (via the internal `public/docs/changelog/v1.md` copy
that feeds `search-index.json` / `search-content.json`), and every
agent-facing artifact advertises the clean `/changelog/v1` URL through the
public mirror at `public/changelog/v1.md`.
