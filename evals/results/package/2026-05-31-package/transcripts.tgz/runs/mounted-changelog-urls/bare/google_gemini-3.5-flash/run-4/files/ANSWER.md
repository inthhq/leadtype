# Serving Changelog under `/changelog/...`

To serve pages from a sibling `changelog/` folder under `/changelog/...` on your generated site (instead of `/docs/changelog/...`), while keeping them fully searchable, use the following configuration and command with `leadtype`.

---

### 1. The `leadtype generate` Invocation

You can use a multi-source mounting pattern by repeating the `--docs-dir` flag and specifying the path prefix to URL prefix mapping (`<dir>=<url-prefix>`).

Run the following command:

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://docs.example.com
```

- `--src .` specifies that the current repository directory is the source root.
- `--docs-dir docs` mounts the main `docs/` folder to the docs root (e.g. `/docs`).
- `--docs-dir changelog=/changelog` mounts the sibling `changelog/` folder to the `/changelog` public route prefix.
- `--out public` is the directory where the build artifacts are written.
- `--base-url https://docs.example.com` sets the base URL for canonical references.

---

### 2. Output and Canonical Details for `changelog/v1.mdx`

For a source file located at `changelog/v1.mdx`, the `leadtype generate` command will emit the following:

1. **Internal Generated Copy:**
   - **Path:** `public/docs/changelog/v1.md`
   - **Purpose:** This internal Markdown copy is preserved under the main generated docs directory `public/docs/` so that runtime search utilities, search indexes (such as `search-index.json` and `search-content.json`), and metadata helpers can process it.

2. **Public Mirror:**
   - **Path:** `public/changelog/v1.md`
   - **Purpose:** A static Markdown copy is generated and written directly to this directory so that it can be publicly served by your host application or CDN under `/changelog/v1.md`.

3. **Canonical URL:**
   - **URL/Paths:** `/changelog/v1.md` (or extensionless `/changelog/v1` depending on resolution configuration)
   - **Purpose:** This is the URL shown to AI agents and web crawlers. The canonical link maps to `/changelog/v1.md` within `llms.txt`, `llms-full.txt`, sitemap XML/Markdown, Agent Readability manifests (`agent-readability.json`), and search indexing metadata.
