# Answer

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://your-site.example
```

`--docs-dir changelog=/changelog` adds the sibling `changelog/` source, keeps it mounted internally under the generated docs tree for Leadtype's runtime/search artifacts, and gives it the public URL prefix `/changelog` instead of the default `/docs/changelog`.

For `changelog/v1.mdx`, site-mode generation emits:

- Internal generated markdown copy: `public/docs/changelog/v1.md`
  - This is the docs-root copy Leadtype uses for search/runtime helpers, so the page remains included in `public/docs/search-index.json` / `search-content.json`.
- Public markdown mirror: `public/changelog/v1.md`
  - This is the file to serve at `/changelog/v1.md`.
- Agent-facing URLs:
  - Markdown mirror links in agent-facing indexes point to `/changelog/v1.md`, not `/docs/changelog/v1.md`.
  - Canonical page URL metadata resolves to `/changelog/v1` (`https://your-site.example/changelog/v1` with the `--base-url` above).
