# Mounting `changelog/` at `/changelog/...`

## 1. Single `leadtype generate` invocation

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

The key piece is the `<dir>=<url-prefix>` syntax on the second `--docs-dir` flag. This tells leadtype to keep the changelog pages in the generated corpus (so they remain searchable) while giving them their own public URL prefix instead of nesting them under `/docs/...`.

## 2. What gets emitted for `changelog/v1.mdx`

| Artifact | Path / URL | Purpose |
|----------|------------|---------|
| **Internal generated copy** | `public/docs/changelog/v1.md` | Flattened markdown kept inside the docs tree for the search index and runtime helpers. |
| **Public mirror** | `public/changelog/v1.md` | Static file served directly at `/changelog/v1.md` on the site. |
| **Canonical URL agents see** | `/changelog/v1` (and `/changelog/v1.md`) | Emitted in `llms.txt`, search metadata, sitemap entries, and `agent-readability.json` so agents discover the page at its top-level route. |
