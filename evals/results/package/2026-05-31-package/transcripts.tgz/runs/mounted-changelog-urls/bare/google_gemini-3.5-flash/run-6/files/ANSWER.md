# Custom Changelog Mount Paths in Leadtype

To serve your `changelog/` pages under the custom `/changelog/...` path instead of `/docs/changelog/...` while keeping them fully searchable, you can use multi-source mounting with a custom URL prefix.

---

## 1. The `leadtype generate` Invocation

Specify multiple `--docs-dir` flags, pointing the second one to the custom prefix `changelog=/changelog`:

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

### Explanation of flags:
- `--src .`: Specifies the current directory as the source root.
- `--docs-dir docs`: Mounts the default `docs/` directory to the docs root (served at `/docs/...`).
- `--docs-dir changelog=/changelog`: Mounts the `changelog/` directory side-by-side with its own public route prefix (`/changelog`).
- `--out public`: Specifies the public directory where build artifacts and public mirrors are generated.
- `--base-url https://example.com` *(optional but recommended)*: Anchors canonical absolute URLs for search metadata, sitemaps, robots, and LLM text files.

---

## 2. Emitted Outputs for `changelog/v1.mdx`

Given a source file like `changelog/v1.mdx`, the invocation above will emit the following:

### Internal Generated Copy
* **File path:** `public/docs/changelog/v1.md`
* **Purpose:** This copy is kept in the main docs structure so that internal search index generation, search content helpers, and other runtime tools can discover and index it alongside the rest of the documentation.

### Public Mirror
* **File path:** `public/changelog/v1.md`
* **Purpose:** This is the static markdown mirror generated at the root-level path corresponding to the custom `/changelog` prefix, matching the public URL path structure.

### Canonical URL Agents See
* **URL paths:** `/changelog/v1` and `/changelog/v1.md` (or absolute URLs like `https://example.com/changelog/v1` / `https://example.com/changelog/v1.md` if `--base-url` is specified).
* **Where it is referenced:** These canonical routes are used in:
  1. `llms.txt` and `llms-full.txt`
  2. Search index/metadata files (`search-index.json`, `search-content.json`)
  3. Generated sitemaps (`sitemap.xml`, `sitemap.md`)
  4. Agent readability manifests (`agent-readability.json`)
