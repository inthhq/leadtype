# Serving `changelog/` under `/changelog/...`

## 1. The command

Mount the sibling `changelog/` folder at its own URL prefix with the
`--docs-dir <dir>=<url-prefix>` syntax:

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://docs.example.com
```

- The **first** `--docs-dir docs` is mounted at the generated docs root (`/docs`).
- The **second** `--docs-dir changelog=/changelog` merges the sibling `changelog/`
  folder into the same generated corpus (so it stays searchable) but gives it its
  own public URL prefix `/changelog` instead of the default `/docs/changelog`.

(If you omitted the `=/changelog` and wrote just `--docs-dir changelog`, the pages
would land under `/docs/changelog/...`, which is what we want to avoid.)

## 2. What it emits for `changelog/v1.mdx`

With the explicit `=/changelog` mount, leadtype produces three things:

| Artifact | Path / value | Purpose |
| --- | --- | --- |
| Internal generated copy | `public/docs/changelog/v1.md` | Lives under the docs root so the **search index** and runtime helpers (`createDocsSource`, search-content) still see it. This keeps the changelog searchable. |
| Public mirror | `public/changelog/v1.md` | A static markdown mirror written at the mounted prefix, so the page is actually served from `/changelog/...`, not `/docs/changelog/...`. |
| Canonical URL | `/changelog/v1` (page) and `/changelog/v1.md` (markdown) | The canonical links agents see. These mounted-prefix URLs are what get emitted in `llms.txt`, search metadata, sitemap entries, and `agent-readability.json`. |

So the page is **searchable** (because the internal copy stays under `public/docs/`)
while being **served and canonicalized under `/changelog/...`** (because of the public
mirror and the rewritten canonical links).
