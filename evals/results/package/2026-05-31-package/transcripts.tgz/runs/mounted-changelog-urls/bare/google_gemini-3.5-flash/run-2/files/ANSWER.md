# Leadtype Multi-Source Mount Configuration

To mount the sibling `changelog/` folder under a custom public route `/changelog/...` (outside of `/docs/...`) while preserving full searchability and agent discoverability, you can use the multi-source mounting feature of `leadtype`.

---

## 1. The Single `leadtype generate` Invocation

Run the following command from the root of your project:

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

### Explanation of flags:
* `--src .`: Specifies the repository/source root directory where both `docs/` and `changelog/` live as siblings.
* `--docs-dir docs`: Mounts your primary `docs/` folder at the default generated docs root.
* `--docs-dir changelog=/changelog`: Uses the `<dir>=<url-prefix>` syntax to mount the sibling `changelog/` folder under its own custom public URL prefix (`/changelog`).
* `--out public`: Instructs the pipeline to write the static build files to the `public/` directory.
* `--base-url https://example.com`: Configures the absolute base URL for canonical sitemaps, search metadata, and LLM-ready links.

---

## 2. Generated Outputs for `changelog/v1.mdx`

For a source file located at `changelog/v1.mdx`, the pipeline will emit the following artifacts:

### A. The Internal Generated Copy
* **File Path:** `public/docs/changelog/v1.md`
* **Purpose:** This file is preserved in the internal `public/docs/...` hierarchy so that internal search index builders and runtime helpers can find, parse, and include it in the global static search index (e.g., `search-index.json` and `search-content.json`).

### B. The Public Mirror
* **File Path:** `public/changelog/v1.md`
* **Purpose:** This is the static markdown mirror generated at the root level of your output folder according to the `/changelog` prefix mapping. It allows your hosting provider/CDN to serve the page directly at `/changelog/v1.md` rather than `/docs/changelog/v1.md`.

### C. The Canonical URL Agents See
* **URL:** `/changelog/v1` (or `/changelog/v1.md`, or the absolute `https://example.com/changelog/v1` when `--base-url` is supplied)
* **Purpose:** This is the URL emitted inside LLM/agent-facing metadata, such as:
  * `llms.txt` and `llms-full.txt`
  * Sitemap entries (`sitemap.xml` and `sitemap.md`)
  * `agent-readability.json` manifest
  * Search metadata fields
