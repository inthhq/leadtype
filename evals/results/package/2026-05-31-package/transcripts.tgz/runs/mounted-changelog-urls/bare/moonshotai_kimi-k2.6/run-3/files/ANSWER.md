# Mounted changelog URLs

## 1. Single `leadtype generate` invocation

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

The key is the `--docs-dir changelog=/changelog` mount syntax. It tells leadtype that the sibling `changelog/` folder should keep its own public URL prefix (`/changelog`) instead of being nested under `/docs/changelog`.

## 2. What gets emitted for `changelog/v1.mdx`

| Artifact | Path / URL | Purpose |
|---|---|---|
| **Internal generated copy** | `public/docs/changelog/v1.md` | The flattened markdown file that the **search index** and runtime helpers read. This is what keeps the page searchable. |
| **Public mirror** | `public/changelog/v1.md` | A static markdown mirror written directly to the mounted route, served at `/changelog/v1.md`. |
| **Canonical URL (agents)** | `/changelog/v1.md` | The root-relative URL emitted in `llms.txt`, search metadata, sitemap entries, and `agent-readability.json`. Search results point to `/changelog/*` rather than `/docs/changelog/*`. |

In other words: the pipeline still builds the corpus from `public/docs/changelog/v1.md` so search works, but agents and canonical metadata see the page as living at `/changelog/v1.md` (or fully qualified as `https://example.com/changelog/v1.md` when `--base-url` is provided).
