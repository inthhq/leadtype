# Answer

To serve a `changelog/` folder (located beside the `docs/` directory) under `/changelog/...` rather than `/docs/changelog/...` while remaining fully searchable, you can use the `--docs-dir` option of the `leadtype generate` command.

The `--docs-dir` flag allows mounting source folders to custom URL prefixes using the `<dir>=<url-prefix>` syntax, and can be repeated to merge multiple folders.

---

### 1. The `leadtype generate` Invocation

Run the following command in the repository root:

```bash
leadtype generate --docs-dir docs --docs-dir changelog=/changelog
```

*(Optional: You can append `--base-url <domain>` to specify your site's canonical production URL, e.g., `--base-url https://example.com`)*

---

### 2. Emitted Outputs for `changelog/v1.mdx`

For a source file located at `changelog/v1.mdx`, the generated site artifacts (placed by default in the `public/` output folder) include the following:

#### A. The Internal Generated Copy
* **Path:** `public/docs/changelog/v1.md`
* **Description:** `leadtype` places this copy inside the `public/docs/` folder alongside other standard docs. This unified layout allows the generator to compile, link-check, and build unified search-index indices (like `public/docs/search-index.json` and `public/docs/search-content.json`) across all content sources.

#### B. The Public Mirror
* **Path:** `public/changelog/v1.md`
* **Description:** This file is copied/mirrored directly under the output root at `/changelog/` to ensure it is served to the public at `/changelog/v1.md` instead of `/docs/changelog/v1.md`.

#### C. The Canonical URL Agents See
* **URL:** `http://localhost:3000/changelog/v1` *(or `https://<your-base-url>/changelog/v1` if `--base-url` is provided)*
* **Description:** This is the URL that user-agents, search engine crawlers, and AI agents discover in standard index files. It contains **no** `/docs` prefix:
  * It is registered in the search index (`search-index.json`) and LLM summary context (`llms-full.txt`) as `/changelog/v1`.
  * It is listed in the XML sitemap (`sitemap.xml`) and Markdown sitemap (`sitemap.md`) as `/changelog/v1`.
  * It is listed in `agent-readability.json` under `pages` with `urlPath: "/changelog/v1"`.
