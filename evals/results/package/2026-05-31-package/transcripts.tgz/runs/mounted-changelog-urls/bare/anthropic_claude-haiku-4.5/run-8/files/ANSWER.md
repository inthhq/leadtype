# Changelog URL Configuration for leadtype

## Single `leadtype generate` Invocation

```bash
leadtype generate --source docs --source changelog:/ --include-search
```

**Key flags:**
- `--source docs` — Read documentation from `docs/` folder
- `--source changelog:/` — Mount the `changelog/` folder at the root level (`/`) rather than nested under docs
- `--include-search` — Include search indexing for all mounted sources

Alternatively, if your leadtype version supports a configuration file:

```bash
leadtype generate --config leadtype.config.mjs
```

Where `leadtype.config.mjs` contains:

```javascript
export default {
  sources: [
    { root: 'docs' },
    { root: 'changelog', mount: '/' }
  ],
  search: { enabled: true }
};
```

## Output Structure for `changelog/v1.mdx`

Given the invocation above, here's what leadtype generates:

### 1. **Internal Generated Copy**
```
.leadtype/.gen/docs/changelog/v1.mdx
```
- This is the processed, normalized markdown/MDX file with resolved links and metadata
- Located in the internal build cache under the docs namespace (for processing consistency)

### 2. **Public Mirror (Served File)**
```
dist/changelog/v1.html
```
- The final HTML file served to users
- Accessible at URL: `https://yoursite.com/changelog/v1`
- **Not** at `/docs/changelog/v1`

### 3. **Canonical URL for Agents**
```
/changelog/v1
```
- This is the canonical URL that search indexing and agent navigation sees
- Used in search results, sitemaps, and agent instructions
- Agents and search tools receive this path as the source of truth

## How It Works

The `--source changelog:/` syntax tells leadtype to:
1. **Read from** the `changelog/` directory on disk
2. **Mount at** `/` in the URL hierarchy (not nested under docs)
3. **Index for search** like any other content source
4. Generate output at `dist/changelog/...` with corresponding `/changelog/...` URLs

This achieves the goal of serving changelog content outside the docs folder structure while maintaining full search functionality, since leadtype treats all mounted sources equally for indexing purposes.
