# Serving `changelog/` under `/changelog/...`

Our repo keeps `changelog/` beside `docs/`. By default, when you add a second
source folder with `--docs-dir changelog`, leadtype mounts it *under the docs
root* — at `/docs/changelog/...`. To get the changelog served at its own
top-level public route while keeping it in the same searchable corpus, use the
`<dir>=<url-prefix>` form of `--docs-dir`.

## 1. The single `leadtype generate` invocation

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://docs.example.com
```

Key parts:

- `--docs-dir docs` — the primary source folder, mounted at the generated docs
  root (`/docs`).
- `--docs-dir changelog=/changelog` — the sibling `changelog/` folder, mounted
  at its **own** public URL prefix `/changelog` instead of `/docs/changelog`.
- Both folders are merged into one generated corpus, so the changelog is still
  indexed by the same static search index.
- `--base-url` lets the canonical links in `llms.txt`, sitemap, search metadata,
  and `agent-readability.json` resolve to absolute URLs.

(Without the `=/changelog` suffix — i.e. just `--docs-dir changelog` — the page
would land at `public/docs/changelog/v1.md` and the URL `/docs/changelog/v1.md`,
which is exactly what we want to avoid.)

## 2. What it emits for `changelog/v1.mdx`

With `--docs-dir changelog=/changelog`, a source file `changelog/v1.mdx`
produces three distinct things:

| Role | Location / value |
| --- | --- |
| **Internal generated copy** (for search + runtime helpers) | `public/docs/changelog/v1.md` |
| **Public mirror** (statically served markdown) | `public/changelog/v1.md` |
| **Canonical URL** agents see (in `llms.txt`, search metadata, sitemap entries, `agent-readability.json`) | `/changelog/v1` (and `/changelog/v1.md` for the markdown form) |

In other words:

- The changelog page still lives **inside** the generated docs tree at
  `public/docs/changelog/v1.md`, so it remains part of the searchable index and
  is resolvable by the runtime helpers that read the generated docs corpus.
- A **static markdown mirror** is additionally written at
  `public/changelog/v1.md`, matching the public `/changelog` route.
- Every URL-anchored artifact advertises the **canonical** `/changelog/v1`
  (page) and `/changelog/v1.md` (markdown) links — never `/docs/changelog/...` —
  so humans, HTTP agents, and crawlers see the changelog under its own
  top-level path.
