# Answer

```bash
leadtype generate --src . --docs-dir docs --docs-dir changelog=/changelog --out public
```

This uses site mode, so search artifacts are still generated. The first `--docs-dir docs` is the normal docs root; the mounted `--docs-dir changelog=/changelog` merges the sibling `changelog/` folder into leadtype's internal docs tree while giving it its own public URL prefix.

For `changelog/v1.mdx`, leadtype emits:

- Internal generated copy: `public/docs/changelog/v1.md` — kept inside the generated docs tree so search and runtime helpers can index/read it.
- Public markdown mirror: `public/changelog/v1.md` — served from the site at `/changelog/v1.md`.
- Canonical URL agents see: `/changelog/v1.md` in agent-facing artifacts such as `llms.txt`, search metadata, sitemap entries, and `agent-readability.json`; not `/docs/changelog/v1.md`.

If you also pass `--base-url https://example.com`, absolute canonical contexts use `https://example.com/changelog/v1.md`.