# Mounted changelog URLs

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://docs.example.com
```

Replace `https://docs.example.com` with the site's real origin.

For `changelog/v1.mdx`, that mount means:

- Internal generated copy: `public/docs/changelog/v1.md`. Leadtype keeps this merged docs-tree copy so search and runtime helpers can read the generated markdown from the normal `<out>/docs` corpus.
- Public markdown mirror: `public/changelog/v1.md`. This is the static mirror that can be served at `/changelog/v1.md` instead of `/docs/changelog/v1.md`.
- Canonical URL agents see: `https://docs.example.com/changelog/v1` for the page, with the markdown URL advertised as `https://docs.example.com/changelog/v1.md`. Those mounted URLs are what appear in `llms.txt`, `llms-full.txt`, search metadata, sitemap entries, and `public/docs/agent-readability.json`, so search results also point at `/changelog/...`.
