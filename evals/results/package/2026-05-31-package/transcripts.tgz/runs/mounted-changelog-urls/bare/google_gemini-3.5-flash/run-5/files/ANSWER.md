# Answer

## 1. CLI Invocation

To mount the `changelog/` directory right beside `docs/` and serve it under `/changelog/...` rather than `/docs/changelog/...` while keeping it searchable and agent-accessible, use the following `leadtype generate` command:

```bash
leadtype generate --src . --docs-dir docs --docs-dir changelog=/changelog --out public
```

*(Note: You can optionally include `--base-url <url>` if you want to generate fully-qualified canonical absolute URLs for search metadata, sitemaps, robots.txt, and `llms.txt` entries.)*

---

## 2. Emitted Files and Canonical URL for `changelog/v1.mdx`

When the generator runs, a source file like `changelog/v1.mdx` will produce the following outputs:

### A. The Internal Generated Copy
* **File Path:** `public/docs/changelog/v1.md`
* **Purpose:** This file is used internally by the pipeline for search indexing and content resolution/runtime helpers.

### B. The Public Mirror
* **File Path:** `public/changelog/v1.md`
* **Purpose:** This is the static markdown mirror written under the `/changelog` route directory structure on disk.

### C. The Canonical URL Agents See
* **URL Paths:** `/changelog/v1` and `/changelog/v1.md` (or prepended with the configured `--base-url`, e.g., `https://<base-url>/changelog/v1`)
* **Purpose:** These URLs are emitted as canonical links in search metadata, `llms.txt`, sitemaps, and `agent-readability.json`.
