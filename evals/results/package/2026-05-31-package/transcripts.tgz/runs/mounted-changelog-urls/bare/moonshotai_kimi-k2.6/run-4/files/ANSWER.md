# Mounting `changelog/` beside `docs/` under `/changelog/...`

## 1. Single `leadtype generate` invocation

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public
```

The `=<url-prefix>` syntax on the second `--docs-dir` tells leadtype that the `changelog` source should keep its own public route instead of being nested under `/docs`.

## 2. What it emits for `changelog/v1.mdx`

| Artifact | Path / URL |
|---|---|
| **Internal generated copy** | `public/docs/changelog/v1.md` |
| **Public static mirror** | `public/changelog/v1.md` |
| **Canonical URL (agents)** | `/changelog/v1` (page URL) and `/changelog/v1.md` (markdown mirror link) |

- **Internal copy:** The converted markdown is still written to `public/docs/changelog/v1.md` so that search indexes, runtime helpers, and the source primitive can find it in the unified generated docs tree.
- **Public mirror:** A second copy is written to `public/changelog/v1.md` so it can be served directly at the root-level `/changelog/` route.
- **Canonical URLs:** Agents and crawlers see `/changelog/v1` as the canonical page URL in sitemaps and `agent-readability.json`, while `llms.txt`, search metadata, and markdown-response handlers reference the mirror at `/changelog/v1.md`.
