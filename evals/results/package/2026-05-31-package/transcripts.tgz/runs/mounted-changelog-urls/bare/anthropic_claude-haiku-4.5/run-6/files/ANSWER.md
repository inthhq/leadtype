# Changelog URL Mounting Configuration

## 1. The `leadtype generate` Command

```bash
leadtype generate --mount changelog:/changelog
```

This single invocation mounts the `changelog/` folder at the root-level `/changelog/` path instead of nesting it under `/docs/`.

The `--mount` flag accepts a `SOURCE:MOUNT_PATH` format:
- `SOURCE`: the directory containing your content (relative to project root)
- `MOUNT_PATH`: where it should be served on the generated site

## 2. Output Structure for `changelog/v1.mdx`

For a file at `changelog/v1.mdx`, leadtype generates:

### Internal Generated Copy
- **Location**: `.leadtype/content/changelog/v1.mdx`
- **Purpose**: The processed source file used by the build system
- **Searchable**: Yes—indexed by the build pipeline regardless of mount path

### Public Mirror
- **Location**: `dist/changelog/v1.html` (or `dist/changelog/v1/index.html` depending on config)
- **Purpose**: The static HTML output served to users
- **Route**: `/changelog/v1` (not `/docs/changelog/v1`)

### Canonical URL
- **URL agents see**: `https://your-site.com/changelog/v1`
- **Used by**: Search indexing, link resolution, sitemaps, and navigation
- **Metadata**: Included in document frontmatter and OpenGraph tags

---

## Summary

The `--mount changelog:/changelog` directive:
- Routes content from `changelog/` folder directly to `/changelog/` on the site
- Preserves searchability through the internal processing pipeline
- Generates static files in `dist/changelog/` matching the public URL structure
- Ensures agents, crawlers, and search engines see the correct canonical path
