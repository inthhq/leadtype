# Mounting Changelog at `/changelog/` with Leadtype

## 1. The Single `leadtype generate` Invocation

```bash
leadtype generate \
  --docs docs \
  --mount changelog:/changelog \
  --searchable
```

Or equivalently with combined flags:
```bash
leadtype generate --docs docs --mount changelog:/changelog --searchable
```

**Explanation:**
- `--docs docs`: Designates `docs/` as the primary documentation source (served at `/docs/...`)
- `--mount changelog:/changelog`: Mounts the `changelog/` folder at the `/changelog` URL path instead of nesting it under docs
- `--searchable`: Ensures all content (from both docs and changelog) is indexed for search

---

## 2. What Gets Emitted for `changelog/v1.mdx`

For a file `changelog/v1.mdx`, leadtype generates:

### Internal Generated Copy
```
.leadtype/cache/changelog/v1.html
```
This is the intermediate built artifact cached by leadtype.

### Public Mirror (Output)
```
dist/changelog/v1/index.html
```
The publicly served HTML file at the correct URL path.

### Canonical URL Agents See
```
/changelog/v1/
```
Search engines, link checkers, and agents discover and index the content at this canonical path, **not** at `/docs/changelog/v1/`. This ensures proper site structure and SEO while keeping source files organized separately on disk.

---

## Why This Works

The `--mount` flag tells leadtype to map a source directory to an arbitrary URL path during generation. This decouples the **filesystem layout** (where you keep files) from the **URL structure** (how users and agents access them):

- **Filesystem:** `changelog/` lives at the root, separate from `docs/`
- **URLs:** Pages are served at `/changelog/...` as a first-class section
- **Search:** The `--searchable` flag ensures the search index includes changelog content at its correct URL path, making it discoverable alongside main docs

