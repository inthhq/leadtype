# Mounted Changelog URLs

## 1. Single `leadtype generate` invocation

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

Repeat `--docs-dir` and use `<dir>=<url-prefix>` for the sibling folder. The first folder stays at the generated docs root; the second keeps its own public route (`/changelog/…`) while still being part of the same searchable corpus.

## 2. What it emits for `changelog/v1.mdx`

| Artifact | Path / URL |
|----------|------------|
| **Internal generated copy** | `public/docs/changelog/v1.md` — converted markdown kept inside the docs tree so the search index and runtime helpers can discover it. |
| **Public mirror** | `public/changelog/v1.md` — a static markdown mirror written at the custom URL prefix. |
| **Canonical URL agents see** | `/changelog/v1.md` (and the page route `/changelog/v1`) emitted in `llms.txt`, search metadata, sitemap entries, and `agent-readability.json`. |
