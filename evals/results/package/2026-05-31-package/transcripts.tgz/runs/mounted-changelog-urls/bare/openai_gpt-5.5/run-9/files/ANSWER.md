# Answer

Use site mode with the changelog source mounted to its own URL prefix:

```bash
leadtype generate --src . --docs-dir docs --docs-dir changelog=/changelog --out public
```

For a source file such as `changelog/v1.mdx`, this produces:

- **Internal generated copy:** `public/docs/changelog/v1.md` — the page remains in the generated docs tree, so the site-mode search artifacts under `public/docs/` can index it.
- **Public mirror:** `public/changelog/v1.md` — the static markdown path to serve outside `/docs`.
- **Canonical URL for agents:** `/changelog/v1.md` in artifacts such as `llms.txt`, search metadata, sitemap entries, and `agent-readability.json` (or the same path resolved against `--base-url` if you also pass one).
