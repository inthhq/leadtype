# Mounting `changelog/` at `/changelog/...`

## 1. Invocation

Run `leadtype generate` with the mount syntax `<dir>=<url-prefix>` for the changelog folder:

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

- `docs` is mounted normally at `/docs`.
- `changelog=/changelog` tells leadtype to keep the changelog content in the generated corpus **and** give it its own public URL prefix (`/changelog`).

## 2. What gets emitted for `changelog/v1.mdx`

| Artifact | Location / URL | Purpose |
|----------|----------------|---------|
| **Internal generated copy** | `public/docs/changelog/v1.md` | Kept inside the docs tree so search indexes and runtime helpers can still find and index the page. |
| **Public mirror** | `public/changelog/v1.md` | The static markdown file served at the public path. |
| **Canonical URL (agents see)** | `/changelog/v1.md` | Written into `llms.txt`, search metadata, `sitemap.xml`, and `agent-readability.json` as the canonical address for the page. |

Because the internal copy at `public/docs/changelog/v1.md` is still part of the generated corpus, the page is fully searchable.
