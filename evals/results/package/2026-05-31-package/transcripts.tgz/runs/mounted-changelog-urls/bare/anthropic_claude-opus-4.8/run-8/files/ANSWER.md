# Serving the `changelog/` folder under `/changelog/...`

## 1. The command

Mount the sibling `changelog/` folder with its own public URL prefix using the
`--docs-dir <dir>=<url-prefix>` form:

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://docs.example.com
```

- `--docs-dir docs` mounts the main docs folder at the generated docs root
  (URL prefix `/docs`).
- `--docs-dir changelog=/changelog` merges the sibling `changelog/` folder into
  the same generated corpus (so it stays searchable) **but** gives it its own
  public route prefix `/changelog` instead of the default `/docs/changelog`.

(Use the real production base URL in place of `https://docs.example.com`.)

## 2. What it emits for `changelog/v1.mdx`

Because `changelog` is mounted with the explicit `=/changelog` URL prefix, the
file is treated as a first-class `/changelog` route while still being indexed
alongside the rest of the docs corpus:

| Artifact | Path / value |
| --- | --- |
| **Internal generated copy** (for search index + runtime helpers) | `public/docs/changelog/v1.md` |
| **Public static markdown mirror** | `public/changelog/v1.md` |
| **Canonical page URL agents see** | `/changelog/v1` (with the markdown mirror at `/changelog/v1.md`) |

The internal copy stays under `public/docs/` so the generated search index
(`public/docs/search-index.json` / `search-content.json`) and the
`createDocsSource` runtime helpers can find it — that's what keeps the changelog
searchable. The public mirror at `public/changelog/v1.md` and the canonical
`/changelog/v1` (+ `/changelog/v1.md`) links are what get emitted into
`llms.txt`, search metadata, sitemap entries, and `agent-readability.json`, so
agents and crawlers see the page under `/changelog/...`, never
`/docs/changelog/...`.
