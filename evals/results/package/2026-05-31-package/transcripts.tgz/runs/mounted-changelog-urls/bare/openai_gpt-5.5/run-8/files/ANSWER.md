# Answer

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://docs.example.com
```

Use your real site origin for `--base-url`. This is site mode (no `--bundle`), so Leadtype also emits the search files.

For `changelog/v1.mdx`, that mount means:

- Internal generated copy for Leadtype/search/runtime helpers: `public/docs/changelog/v1.md`
- Public markdown mirror served at the changelog route: `public/changelog/v1.md`
- Canonical public page URL agents see: `https://docs.example.com/changelog/v1` (with the markdown mirror at `https://docs.example.com/changelog/v1.md`), not `/docs/changelog/v1`.

The changelog page is still included in the generated site artifacts such as `public/docs/search-index.json`, `public/docs/search-content.json`, `llms.txt`, sitemap entries, and `public/docs/agent-readability.json`, but all public/canonical links use `/changelog/...`.
