# Mounting Sibling Changelog Folders in Leadtype

To host a `changelog/` folder side-by-side with your `docs/` folder, and have the generated changelog pages served under `/changelog/...` rather than `/docs/changelog/...` while remaining searchable, you can use the multi-source mounting feature of `leadtype`.

---

## 1. The `leadtype generate` Command

Run the following invocation:

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

### Explanation of parameters:
* `--src .`: Directs `leadtype` to search the current root directory where `docs/` and `changelog/` folders reside.
* `--docs-dir docs`: Mounts the primary docs source folder at the default location.
* `--docs-dir changelog=/changelog`: Mounts the sibling source folder `changelog/` with the target public route prefix `/changelog`.
* `--out public`: Specifies the destination folder for static output artifacts.
* `--base-url https://example.com`: Sets the domain base for absolute URL sitemap, robots, and agent readability metadata generation.

---

## 2. Emitted Files and Agent Visibility

For a source file like `changelog/v1.mdx`, `leadtype generate` produces the following files and references:

### A. Internal Generated Copy
* **File path:** `public/docs/changelog/v1.md`
* **Purpose:** This file is used internally by search compilers, local indexing routines, and runtime helpers to build search indexes.

### B. Public Static Mirror
* **File path:** `public/changelog/v1.md`
* **Purpose:** This is the publicly-accessible markdown file served directly to static requests or search spiders looking for raw content at that route.

### C. Canonical URL Seen by Agents
* **The URL:** `/changelog/v1.md` (or `/changelog/v1` depending on resolution configuration)
* **Where it is referenced:** 
  * The site-wide `llms.txt` and `llms-full.txt` files.
  * The search index and search results metadata (`public/docs/search-index.json`).
  * Page sitemaps and search artifacts.
  * The Agent Readability structured manifest (`public/docs/agent-readability.json`).
