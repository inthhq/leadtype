# Answer

```bash
leadtype generate --src . --docs-dir docs --docs-dir changelog=/changelog --out public --base-url https://example.com
```

Replace `https://example.com` with the site's real origin.

For `changelog/v1.mdx`, the `changelog=/changelog` mount means:

- **Internal generated copy:** `public/docs/changelog/v1.md`
  - This stays in the merged generated docs tree, so the normal site-mode search artifacts under `public/docs/` can index it.
- **Public markdown mirror:** `public/changelog/v1.md`
  - This is the copy to serve from the changelog URL space instead of from `/docs/changelog/...`.
- **Agent-facing canonical markdown URL:** `/changelog/v1.md`
  - With the `--base-url` above, absolute agent/readability metadata can point at `https://example.com/changelog/v1.md`.
