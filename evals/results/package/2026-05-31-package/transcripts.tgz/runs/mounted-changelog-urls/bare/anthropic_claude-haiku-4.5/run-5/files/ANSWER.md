# Serving Changelog Under `/changelog/...` Instead of `/docs/changelog/...`

## 1. The `leadtype generate` Invocation

```bash
leadtype generate \
  --source docs \
  --source changelog \
  --public . \
  --searchable '*'
```

**Alternative with explicit path mappings (if your leadtype version supports it):**

```bash
leadtype generate \
  --source docs \
  --source changelog:changelog \
  --public . \
  --searchable '*'
```

The key insight is that when you specify `--source changelog` as a separate source directory alongside `--source docs`, leadtype mounts it at its own root level in the public output, rather than nesting it under `docs/`. The `--searchable '*'` flag ensures all content across all sources remains searchable.

## 2. Emission Details for `changelog/v1.mdx`

For a file `changelog/v1.mdx`, here's what `leadtype generate` produces:

### Internal Generated Copy
- **Location**: `.leadtype/internal/changelog/v1.html` (or similar build cache)
- **Purpose**: Processed intermediate representation used internally by leadtype for indexing and optimization

### Public Mirror  
- **Location**: `public/changelog/v1.html`
- **Access**: Served at `/changelog/v1.html` on the generated site
- **Browser behavior**: Users navigate directly to `https://yoursite.com/changelog/v1.html`

### Canonical URL (What Agents See)
- **URL**: `/changelog/v1.html` (or `/changelog/v1/` depending on permalink settings)
- **Search index entry**: The file is indexed under the canonical path `/changelog/v1` with full searchability
- **No `/docs/` prefix**: The path is NOT `/docs/changelog/v1`, it's mounted at the root level under `/changelog/`

This setup ensures:
1. ✓ Changelog files are served at `/changelog/...` URLs, not `/docs/changelog/...`
2. ✓ The internal processing preserves the source structure for proper linking
3. ✓ Search indexes the canonical `/changelog/...` paths
4. ✓ Both `docs/` and `changelog/` content is discoverable
