# Serving Changelog at Root URL with Searchability

## 1. The `leadtype generate` Invocation

To serve the `changelog/` folder at `/changelog/...` while keeping it searchable (and not nested under `/docs/changelog/...`), use:

```bash
leadtype generate --docs docs --mount changelog:/changelog
```

**Key aspects:**
- `--docs docs`: Main documentation source directory (served at `/docs/...`)
- `--mount changelog:/changelog`: Mounts the `changelog/` folder as a separate documentation tree at the `/changelog` URL path (root-level)

The `--mount` flag registers the changelog folder as a separate documentation source that gets included in search indexing while using a distinct URL mount point separate from the main docs hierarchy.

## 2. What Gets Emitted for `changelog/v1.mdx`

For a file like `changelog/v1.mdx` with the above invocation, the generation produces:

### Internal Generated Copy
- **Location:** `./.leadtype-cache/sources/changelog/v1.mdx` (or similar internal cache)
- **Purpose:** Processed markdown source with extracted metadata, frontmatter, and searchable content

### Public Mirror / Build Output
- **Location:** `dist/changelog/v1.html` (in the output build directory)
- **File structure:** Rendered as a standalone HTML page with proper styling and navigation

### Canonical URL Agents See
- **URL:** `/changelog/v1` (or fully: `https://yoursite.com/changelog/v1`)
- **Search Index Entry:** Indexed under canonical path `/changelog/v1` with full searchability alongside docs
- **Metadata visible to crawlers/agents:** Links, breadcrumbs, and sitemaps all reference `/changelog/v1` (never `/docs/changelog/v1`)

**Example search behavior:**
- User query "version 1 release" → search result shows: "Version 1.0 — `/changelog/v1`"
- The changelog is treated as a first-class content source with its own URL namespace
- Navigation and breadcrumbs recognize it as a separate documentation tree from `/docs/*`
- Search algorithms weight results consistently with the main docs tree

## Why This Works

The `--mount` flag achieves the requirements by:
1. **Separating URL hierarchy**: Content is served at `/changelog/...` not `/docs/changelog/...`
2. **Maintaining search inclusion**: The mounted source is fully indexed and searchable
3. **Preserving folder structure**: Your physical folder structure (`changelog/` separate from `docs/`) remains unchanged
4. **Unified metadata**: Agents see consistent canonical paths throughout the generated site
