# Answer

## 1. The `leadtype generate` Invocation

To mount the `changelog/` directory right beside `docs/` such that it is served under `/changelog/...` (not `/docs/changelog/...`) while keeping it fully searchable, run the following command:

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public
```

*(Note: You can additionally pass `--base-url <your-base-url>` to define the root URL for absolute canonical URLs in sitemaps, robots.txt, etc., as standard practice).*

---

## 2. Emitted Outputs for `changelog/v1.mdx`

Given a source file like `changelog/v1.mdx`, running the command above emits and registers the following:

1. **The Internal Generated Copy:** 
   * **Path:** `public/docs/changelog/v1.md`
   * **Purpose:** This copy is placed under the internal docs root directory. It is used to generate the static search index, search-content metadata, and feed other runtime documentation helpers, ensuring that your changelog pages remain fully searchable.

2. **The Public Mirror:** 
   * **Path:** `public/changelog/v1.md`
   * **Purpose:** A static markdown mirror is written directly to the mapped public URL prefix directory under the output folder. This is the file served directly to human visitors or agents request-negotiating markdown at `/changelog/v1.md`.

3. **The Canonical URL Agents See:** 
   * **URL:** `/changelog/v1.md` *(or `https://<your-base-url>/changelog/v1.md` if `--base-url` is specified)*
   * **Purpose:** This canonical path is published in LLM/Agent discoverability indexes such as `llms.txt`, sitemap files (`sitemap.xml`, `sitemap.md`), search metadata indexes, and the `agent-readability.json` manifest.
