# Answer

## 1. Single `leadtype generate` invocation

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public
```

The key is the `--docs-dir changelog=/changelog` syntax. It tells leadtype to treat the sibling `changelog/` folder as a **mounted source** with its own public URL prefix (`/changelog`), while still folding it into the same generated corpus as the main `docs/` tree.

## 2. What gets emitted for `changelog/v1.mdx`

| Artifact | Path / URL |
|----------|------------|
| **Internal generated copy** (used by the search index and runtime helpers) | `public/docs/changelog/v1.md` |
| **Public markdown mirror** (served at the mounted route) | `public/changelog/v1.md` |
| **Canonical URL agents see** | `/changelog/v1.md` (also referenced as `/changelog/v1` in some artifacts) |

In other words:

- The file is converted to markdown **twice** on disk: once inside the internal `public/docs/` tree so the search index and source-grounded answer helpers can find it, and once at the public mount point so HTTP requests to `/changelog/...` resolve directly.
- Agents reading `llms.txt`, the sitemap, search metadata, or `agent-readability.json` all receive the canonical **mounted** URL (`/changelog/v1.md`), not the internal `/docs/changelog/v1.md` path.
