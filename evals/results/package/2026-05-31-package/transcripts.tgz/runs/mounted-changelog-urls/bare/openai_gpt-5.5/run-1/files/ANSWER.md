# Answer

Use site mode (do **not** pass `--bundle`) and mount the sibling changelog source with its own URL prefix:

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://your-site.example
```

Replace `https://your-site.example` with the site's real origin.

For `changelog/v1.mdx`, leadtype still merges the changelog into the generated docs corpus for search/runtime artifacts, but it advertises the mounted public route:

- Internal generated copy used by search/runtime helpers: `public/docs/changelog/v1.md`
- Public markdown mirror served at the changelog mount: `public/changelog/v1.md`, i.e. `/changelog/v1.md`
- Canonical page URL in generated metadata: `https://your-site.example/changelog/v1` (and the agent-facing markdown link is `https://your-site.example/changelog/v1.md`, or `/changelog/v1.md` when shown as a path)

So agents/search see the changelog under `/changelog/...`, not `/docs/changelog/...`, while the internal `public/docs/changelog/...` copy remains available to build the search index.
