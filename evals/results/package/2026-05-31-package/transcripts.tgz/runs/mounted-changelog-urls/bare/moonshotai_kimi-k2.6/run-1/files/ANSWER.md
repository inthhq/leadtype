# Mounted Changelog URLs

## 1. Invocation

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public
```

Using `<dir>=<url-prefix>` tells leadtype to keep the changelog folder at its own public route (`/changelog/…`) instead of nesting it under `/docs/changelog/…`.

## 2. Emissions for `changelog/v1.mdx`

| Artifact | Location / Value |
|----------|------------------|
| **Internal generated copy** | `public/docs/changelog/v1.md` — kept in the docs tree so the static search index and runtime helpers can still index it. |
| **Public mirror** | `public/changelog/v1.md` — the file actually served at the public path. |
| **Canonical URL agents see** | `/changelog/v1.md` (leadtype also emits `/changelog/v1` in some link contexts) — used in `llms.txt`, search metadata, sitemap entries, and `agent-readability.json`. |
