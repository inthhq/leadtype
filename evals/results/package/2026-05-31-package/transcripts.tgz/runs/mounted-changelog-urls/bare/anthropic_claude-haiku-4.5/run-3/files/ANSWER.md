# Mounted Changelog URLs Configuration

## 1. The `leadtype generate` Invocation

```bash
leadtype generate --source docs --mount changelog:/changelog
```

This single invocation:
- Takes `docs/` as the primary documentation source (served from site root)
- Mounts `changelog/` at the `/changelog` URL path on the generated site
- Ensures all changelog content is searchable within the site index

## 2. What Gets Emitted for `changelog/v1.mdx`

For a file at `changelog/v1.mdx`, leadtype produces:

### Internal Generated Copy
```
.generated/docs/changelog/v1.mdx
```
(intermediate representation within the build pipeline, used for processing and indexing)

### Public Mirror / Final Output
```
out/changelog/v1/index.html
```
(the actual publicly served HTML file at the `/changelog/v1/` URL path)

### Canonical URL Agents See
```
/changelog/v1
```
(the URL that agents and search engines encounter when crawling; this is the URL stored in the site's search index)

## How It Works

The `--mount` flag tells leadtype to:
1. Treat the `changelog/` folder as a separate content tree
2. Mount it at a custom URL prefix (`/changelog`) instead of embedding it under `/docs/changelog/`
3. Include all mounted content in the site's search index with the correct canonical URLs
4. Generate output in the appropriate site directory structure (`out/changelog/...` not `out/docs/changelog/...`)

This allows changelog pages to have a distinct URL hierarchy while remaining fully integrated into the site's search and navigation systems.
