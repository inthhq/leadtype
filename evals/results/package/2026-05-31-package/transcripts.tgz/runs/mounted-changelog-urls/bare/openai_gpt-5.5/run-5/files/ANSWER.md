# Answer

Run `leadtype generate` with the sibling changelog mounted to its own URL prefix:

```bash
leadtype generate --src . --docs-dir docs --docs-dir changelog=/changelog --out public
```

For `changelog/v1.mdx`, that mount makes Leadtype emit:

- **Internal generated copy:** `public/docs/changelog/v1.md` — this stays inside the generated docs tree so search and runtime helpers can index/read it.
- **Public markdown mirror:** `public/changelog/v1.md` — this is the static mirror served from `/changelog/v1.md`, not `/docs/changelog/v1.md`.
- **Canonical agent-facing URL:** `/changelog/v1.md` in agent-visible artifacts such as `llms.txt`, search metadata, sitemap entries, and `agent-readability.json`.

If you also pass your real `--base-url`, URL-bearing metadata can include the absolute form, e.g. `https://example.com/changelog/v1.md`.
