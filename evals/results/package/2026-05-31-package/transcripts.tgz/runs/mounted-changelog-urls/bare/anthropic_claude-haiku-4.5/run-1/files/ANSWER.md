# Changelog URLs with leadtype

## The Command

```bash
leadtype generate --content docs --content changelog:/changelog
```

Or, depending on the leadtype syntax, it may be:

```bash
leadtype generate \
  --source docs:/ \
  --source changelog:/changelog
```

The key principle is using **mount mapping** syntax where `changelog:/changelog` instructs leadtype to:
- Source content from the `changelog/` folder
- Mount it at the `/changelog/` path on the generated site
- Rather than nesting it under the docs path

## What This Emits for `changelog/v1.mdx`

### Internal Generated Copy
- **Path**: `./.leadtype/changelog/v1.mdx` (or similar temp/cache directory)
  - This is the processed version maintained by the generator

### Public Mirror / Build Output
- **Path**: `./dist/changelog/v1.html` (or the configured build output directory)
  - The final HTML served directly under `/changelog/`

### Canonical URL for Agents
- **URL**: `https://yoursite.com/changelog/v1`
- Agents (search engines, link previews, etc.) see this URL directly
- Search indices include this canonical path, making it fully discoverable
- No `/docs/changelog/` nesting

## Why This Works for Searchability

1. **Single source of truth**: The canonical URL is the mount point (`/changelog/v1`), not a nested path
2. **Robots/SEO**: The public output structure matches the served path, so crawlers find the correct location
3. **Internal linking**: The generator knows the actual request path and generates correct internal links
4. **Unified site.json/index**: Changelog pages are listed alongside docs in the searchable index with their correct mount paths

## Example Structure

```
Repository:
  docs/
    index.mdx
    guide.mdx
  changelog/
    v1.mdx
    v2.mdx

Generated Site:
  /
    index.html
    guide.html
  /changelog/
    v1.html
    v2.html

Searchable Index:
  [
    { path: "/", title: "..." },
    { path: "/guide", title: "..." },
    { path: "/changelog/v1", title: "..." },
    { path: "/changelog/v2", title: "..." }
  ]
```
