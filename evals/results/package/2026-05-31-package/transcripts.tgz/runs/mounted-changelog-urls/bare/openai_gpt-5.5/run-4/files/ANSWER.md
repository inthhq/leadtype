```bash
leadtype generate --src . --docs-dir docs --docs-dir changelog=/changelog --out public
```

For `changelog/v1.mdx`, the `changelog=/changelog` mount keeps the sibling `changelog/` source searchable in leadtype's generated docs tree but gives it its own public URL prefix:

- Internal generated copy for search/runtime helpers: `public/docs/changelog/v1.md`
- Public static markdown mirror: `public/changelog/v1.md`
- Agent-facing markdown link emitted in leadtype artifacts: `/changelog/v1.md` (or `https://your-site.example/changelog/v1.md` if you add `--base-url https://your-site.example`)

In URL metadata, the page route itself is `/changelog/v1` (absolute when `--base-url` is provided), with `/changelog/v1.md` as the markdown mirror agents can fetch. The important part is that leadtype no longer advertises `/docs/changelog/v1.md` for that mounted source, while the internal `public/docs/changelog/v1.md` copy still feeds search.
