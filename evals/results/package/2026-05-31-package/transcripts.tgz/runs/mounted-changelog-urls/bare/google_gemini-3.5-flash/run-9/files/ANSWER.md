# Answer

To serve changelog pages under `/changelog/...` rather than `/docs/changelog/...` while remaining fully searchable, you can use `leadtype`'s multi-source mounting with the `<dir>=<url-prefix>` syntax.

---

### 1. `leadtype generate` Invocation

Assuming your project root contains `docs/` and `changelog/` folders, run:

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

*(Note: Replace `https://example.com` with your production base URL, or omit `--base-url` if not using absolute URLs for sitemaps or sitemap/robots generation).*

---

### 2. Output and Emitted Files for `changelog/v1.mdx`

When `changelog/v1.mdx` is processed by the pipeline above with `--out public`, it emits the following outputs:

* **Internal Generated Copy**: `public/docs/changelog/v1.md`
  * This copy is kept internally for the static search index, runtime helpers, and local content loading.
* **Public Mirror**: `public/changelog/v1.md`
  * A static markdown mirror page is written to this path so it can be served directly under `/changelog/...`.
* **Canonical URL Agents See**: `/changelog/v1` (or `/changelog/v1.md`)
  * If a `--base-url` is provided (e.g., `https://example.com`), it emits full canonical URLs like `https://example.com/changelog/v1` or `https://example.com/changelog/v1.md` inside `llms.txt`, search metadata, sitemap entries (`sitemap.xml`), and `agent-readability.json`.
