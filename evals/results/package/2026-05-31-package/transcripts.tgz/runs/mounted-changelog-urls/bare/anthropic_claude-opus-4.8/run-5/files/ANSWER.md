# Serving `changelog/` under `/changelog/...`

## 1. The `leadtype generate` invocation

Use a second `--docs-dir` with the `<dir>=<url-prefix>` form so the sibling
`changelog/` folder is merged into the docs pipeline but mounted under its own
public route:

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public
```

- `--docs-dir docs` is the primary source, mounted at the generated docs root
  (`/docs`).
- `--docs-dir changelog=/changelog` merges the sibling `changelog/` folder into
  the same generated docs tree (so it is converted, indexed, and searchable),
  but gives it the public URL prefix `/changelog` instead of `/docs/changelog`.

Without the `=/changelog` suffix, the folder would fall back to being mounted by
its name under the docs root and would be served at `/docs/changelog/...`, which
is exactly what we want to avoid.

## 2. What it emits for `changelog/v1.mdx`

For the input file `changelog/v1.mdx`, the pipeline produces three things:

- **Internal generated copy** — `public/docs/changelog/v1.md`
  This lives inside the normal docs tree so it stays in the search index and is
  resolvable by the runtime source/search helpers. It is the canonical
  build-time artifact the search content/index point at.

- **Public mirror** — `public/changelog/v1.md`
  A static markdown mirror written at the mounted URL prefix, so the page is
  actually served from `/changelog/...` rather than `/docs/changelog/...`.

- **Canonical URL** — `/changelog/v1.md` (page route `/changelog/v1`)
  This mounted path is what agents see. It is the URL emitted in `llms.txt`,
  search metadata, sitemap entries, and `agent-readability.json`.

So the changelog content remains fully searchable (via the internal
`public/docs/changelog/v1.md` copy), while every public/canonical link an agent
follows resolves under `/changelog/...`.
