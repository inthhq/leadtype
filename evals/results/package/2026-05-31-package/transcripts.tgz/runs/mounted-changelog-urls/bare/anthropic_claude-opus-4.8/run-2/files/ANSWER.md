# Serving `changelog/` under `/changelog/...`

## 1. The command

Mount the sibling `changelog/` folder with its own public URL prefix by
appending `=/changelog` to its `--docs-dir` entry:

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://docs.example.com
```

- The **first** `--docs-dir docs` is the primary source, mounted at the
  generated docs root (`/docs`).
- `--docs-dir changelog=/changelog` adds the sibling `changelog/` folder but
  remaps its public route from the default `/docs/changelog/...` to
  `/changelog/...`.
- `--base-url` is what stamps the canonical URLs into the URL-anchored
  artifacts (`llms.txt`, search metadata, sitemap, `agent-readability.json`).

Without the `=/changelog` suffix, the changelog would default to being mounted
under `/docs/changelog/...`, which is exactly what we want to avoid.

## 2. What it emits for `changelog/v1.mdx`

For a source file `changelog/v1.mdx`, the `=/changelog` mount produces three
distinct things:

1. **Internal generated copy** — `public/docs/changelog/v1.md`.
   This always stays under the docs root so the static search index and the
   runtime/source helpers can find and read it. It is not the public address.

2. **Public mirror** — `public/changelog/v1.md`.
   A static markdown mirror written at the remapped prefix, so the page is
   served from `/changelog/...` rather than `/docs/changelog/...`.

3. **Canonical URL agents see** — `/changelog/v1` (HTML) and `/changelog/v1.md`
   (markdown). These remapped canonical links are what gets emitted into
   `llms.txt`, the search metadata, sitemap entries, and
   `agent-readability.json`.

The net effect: the changelog is publicly addressed and canonicalized under
`/changelog/...`, while the internal `public/docs/changelog/v1.md` copy keeps it
inside the searchable corpus.
