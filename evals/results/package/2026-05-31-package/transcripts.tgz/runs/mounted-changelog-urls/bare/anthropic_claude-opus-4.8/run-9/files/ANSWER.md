# Serving the `changelog/` folder under `/changelog/...`

Our repo keeps `changelog/` as a sibling of `docs/`. We want those pages to be
mounted at the public route `/changelog/...` (not `/docs/changelog/...`) while
still being part of the searchable corpus. `leadtype generate` supports this
with the `--docs-dir <dir>=<url-prefix>` mount syntax: the folder is merged into
the same generated corpus (so it's converted, indexed, and searchable), but it
keeps its own public URL prefix.

## 1. The command

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://docs.example.com
```

- `--docs-dir docs` — the primary source folder, mounted at the docs root
  (`/docs`).
- `--docs-dir changelog=/changelog` — mounts the sibling `changelog/` folder at
  the public prefix `/changelog` instead of the default `/docs/changelog`.
- `--out public` — output root that gets served.
- `--base-url …` — base URL used for canonical links in `llms.txt`, search
  metadata, the sitemap, and `agent-readability.json`. (Adjust to your real
  host; it's only needed for the absolute-URL artifacts in site mode.)

> Without the `=/changelog` suffix, an extra `--docs-dir changelog` would mount
> it at `public/docs/changelog/v1.md` with the canonical URL `/docs/changelog/v1`
> — exactly the `/docs/changelog/...` layout we want to avoid. The `=<url-prefix>`
> form is what relocates the public route.

## 2. What it emits for `changelog/v1.mdx`

With the `changelog=/changelog` mount, the single page `changelog/v1.mdx`
produces three things:

| Artifact | Path / value | Purpose |
| --- | --- | --- |
| Internal generated copy | `public/docs/changelog/v1.md` | Stays under the docs root so search indexing and the runtime source helpers (search index, runtime loaders) find it. This keeps the changelog searchable. |
| Public markdown mirror | `public/changelog/v1.md` | A static markdown file written at the mounted prefix, so the file is actually served under `/changelog/...`. |
| Canonical URL agents see | `/changelog/v1` (page) and `/changelog/v1.md` (markdown) | The canonical links emitted into `llms.txt`, `llms-full.txt`, search metadata, sitemap entries, and `agent-readability.json` all point at the `/changelog/...` route — never `/docs/changelog/...`. |

So the page is internally generated at `public/docs/changelog/v1.md` for
search/runtime, mirrored publicly at `public/changelog/v1.md`, and advertised to
humans and agents under the canonical `/changelog/v1` (and `/changelog/v1.md`)
URLs.
