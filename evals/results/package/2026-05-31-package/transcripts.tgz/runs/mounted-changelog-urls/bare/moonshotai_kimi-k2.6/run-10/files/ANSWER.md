# Mounted Changelog URLs

## 1. Single `leadtype generate` invocation

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

* `--docs-dir changelog=/changelog` mounts the sibling `changelog/` folder under its own public URL prefix (`/changelog`) instead of nesting it inside `/docs/changelog`.
* The first source (`docs`) is mounted at the generated docs root as usual.
* `--base-url` is required so that canonical URLs in `llms.txt`, sitemaps, and search metadata are absolute.

## 2. What gets emitted for `changelog/v1.mdx`

| Artifact | Path / URL | Purpose |
|---|---|---|
| **Internal generated copy** | `public/docs/changelog/v1.md` | Used by the search index and runtime helpers (e.g., `createDocsSource`, `createAgentMarkdownResponse`). This is what makes the page searchable even though it is not served under `/docs/changelog/...`. |
| **Public mirror** | `public/changelog/v1.md` | The static markdown file actually served to agents and browsers at the public route. |
| **Canonical URL agents see** | `/changelog/v1.md` (or absolute `https://example.com/changelog/v1.md` with `--base-url`) | Emitted in `llms.txt`, `llms-full.txt`, search metadata, sitemap entries, and `agent-readability.json` as the canonical markdown mirror link. |

In short: the pipeline keeps one copy inside `public/docs/` for search/runtime, writes a second copy at `public/changelog/` for public serving, and tells agents to use the `/changelog/...` URL.
