# Serving the `changelog/` folder under `/changelog/...`

## 1. The `leadtype generate` invocation

Use a second `--docs-dir` for the sibling `changelog/` folder and give it an explicit
URL prefix with the `<dir>=<url-prefix>` form:

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://docs.example.com
```

- `--docs-dir docs` mounts the main docs folder at the generated docs root (`/docs`).
- `--docs-dir changelog=/changelog` merges the sibling `changelog/` folder into the same
  generated corpus (so it stays searchable) but assigns it the public URL prefix
  `/changelog` instead of the default `/docs/changelog`.
- `--base-url` is needed so the canonical links (sitemap, search metadata,
  `llms.txt`, `agent-readability.json`) resolve correctly.

Without the `=/changelog` suffix, an extra source folder defaults to mounting under
`/docs/<folder>`, i.e. `/docs/changelog/...` — which is exactly what we want to avoid.

## 2. What it emits for `changelog/v1.mdx`

With the `changelog=/changelog` mount, the file `changelog/v1.mdx` produces three things:

| Artifact | Path / URL | Purpose |
| --- | --- | --- |
| **Internal generated copy** | `public/docs/changelog/v1.md` | Lives under the generated docs tree. This is the copy search and the runtime helpers (search index, content readers, `createDocsSource`) read from — so the changelog stays fully searchable. |
| **Public mirror** | `public/changelog/v1.md` | A static markdown mirror written at the changelog's own route, so the page is actually served from `/changelog/...` and not `/docs/changelog/...`. |
| **Canonical URL agents see** | `/changelog/v1` (page) and `/changelog/v1.md` (markdown) | The canonical links emitted in `llms.txt`, search metadata, sitemap entries, and `agent-readability.json` all point at the `/changelog` prefix. |

In short: the internal copy under `public/docs/changelog/v1.md` keeps the page in the
searchable corpus, while the `/changelog` mirror at `public/changelog/v1.md` plus the
`/changelog/v1` canonical URLs make it look like a top-level `/changelog/...` route to
both humans and agents.
