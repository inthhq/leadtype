# Serving the sibling `changelog/` folder under `/changelog/...`

## 1. The single command

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://docs.example.com
```

Key points:

- `--src .` — repo root, which contains both `docs/` and `changelog/` side by side.
- `--docs-dir docs` — the primary docs folder; mounted at the generated docs root (URLs under `/docs`).
- `--docs-dir changelog=/changelog` — adds the sibling folder to the **same** generated corpus (so it's converted, indexed, and searchable), but the `=/changelog` suffix gives it its **own public URL prefix** instead of the default `/docs/changelog`.
- `--out public` — output root.
- `--base-url` — used for canonical artifacts (sitemap, robots, search metadata, full-context fallback URLs).

The `<dir>=<url-prefix>` form is the CLI shorthand for the library `mounts` array:

```ts
const mounts = [
  { pathPrefix: "", urlPrefix: "/docs" },
  { pathPrefix: "changelog", urlPrefix: "/changelog" },
];
```

Without the `=/changelog` suffix (i.e. plain `--docs-dir changelog`), the folder would instead be mounted under `/docs/changelog`, which is exactly what we want to avoid.

## 2. What gets emitted for `changelog/v1.mdx`

For a source file `changelog/v1.mdx`, the command produces three distinct things:

| Role | Location / URL | Purpose |
| --- | --- | --- |
| **Internal generated copy** | `public/docs/changelog/v1.md` | The flattened markdown the pipeline always keeps under `public/docs/`. Search index, runtime helpers, and `createDocsSource` read from here. |
| **Public mirror** | `public/changelog/v1.md` | A static markdown mirror written at the mounted URL prefix so the page is fetchable at the public route, not under `/docs/`. |
| **Canonical URL agents see** | `/changelog/v1` (and the markdown alternate `/changelog/v1.md`) | The canonical link emitted into `llms.txt`, `llms-full.txt`, navigation, sitemap entries, search metadata, and `agent-readability.json`. |

So the changelog pages are:

- **Served under `/changelog/...`** — via the public mirror and the canonical `/changelog/...` URLs in every URL-anchored artifact, **not** under `/docs/changelog/...`.
- **Still searchable** — because the internal generated copy stays at `public/docs/changelog/v1.md`, which is what the search index and runtime source primitive consume; the `mounts` metadata maps each search hit's canonical URL back to `/changelog/v1`.
