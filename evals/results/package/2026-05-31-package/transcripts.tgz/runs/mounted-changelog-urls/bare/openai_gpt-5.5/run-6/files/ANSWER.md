# Answer

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://docs.example.com
```

Replace `https://docs.example.com` with the site's real origin.

For `changelog/v1.mdx`, the `changelog=/changelog` mount means:

- Internal generated copy: `public/docs/changelog/v1.md`. This stays in the merged generated docs tree, so search/runtime helpers can index it along with the normal `docs/` pages.
- Public markdown mirror: `public/changelog/v1.md`. This is the served mirror for the changelog route, not `public/docs/changelog/v1.md`.
- Canonical route/URL: the page is mounted as `/changelog/v1` (`https://docs.example.com/changelog/v1` with the `--base-url` above). Agent-facing markdown links/manifests point at the mirror `/changelog/v1.md` (`https://docs.example.com/changelog/v1.md`), not `/docs/changelog/v1.md`.
