# Mounting `changelog` at `/changelog/...`

## 1. Invocation

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public
```

* `--docs-dir docs` preserves the main docs tree at the generated docs root.
* `--docs-dir changelog=/changelog` mounts the sibling `changelog/` folder under its own public URL prefix instead of nesting it under `/docs/changelog/`.

(If you omit `--src .` or `--out public`, the CLI uses its defaults, but keeping them makes the intent explicit.)

## 2. What gets emitted for `changelog/v1.mdx`

| Artifact | Location / Value |
|----------|------------------|
| **Internal generated copy** | `public/docs/changelog/v1.md` — this is the flattened markdown that the search index and runtime helpers read from. Keeping it inside `public/docs/` makes the page searchable even though its public URL lives elsewhere. |
| **Public mirror** | `public/changelog/v1.md` — a static markdown mirror written at the mounted path so agents (and humans) can fetch it directly from `/changelog/v1.md`. |
| **Canonical URL agents see** | `/changelog/v1.md` — used in `llms.txt`, search metadata, sitemap entries, `agent-readability.json`, and other agent-facing discovery files. (If you pass `--base-url https://example.com`, the fully-qualified canonical URL becomes `https://example.com/changelog/v1.md`.) |
