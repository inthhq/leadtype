# Serving Changelog Under `/changelog/...`

## Single `leadtype generate` Invocation

```bash
leadtype generate \
  --mount docs:/docs \
  --mount changelog:/changelog
```

Alternatively, as a single-line command:

```bash
leadtype generate --mount docs:/docs --mount changelog:/changelog
```

## What It Emits for `changelog/v1.mdx`

For a source file at `changelog/v1.mdx`:

1. **Internal Generated Copy**: 
   - Built output: `_generated/changelog/v1.html`
   - This is the compiled HTML in the build directory hierarchy matching the source structure

2. **Public Mirror**: 
   - Published artifact: `public/changelog/v1.html`
   - The file made available to the web server/browser

3. **Canonical URL Agents See**: 
   - URL path: `/changelog/v1`
   - Full canonical URL: `https://yourdomain.com/changelog/v1`
   - This is what appears in search results, sitemaps, and agent crawls

The `--mount SOURCE:URLPATH` syntax tells leadtype to:
- Take source files from the `SOURCE` directory
- Mount them at the specified `URLPATH` prefix in the generated site
- Include them in the search index while maintaining the correct URL hierarchy
- Generate correct canonical URLs for agents/crawlers

By mounting `changelog:/changelog` separately, the files bypass the default `/docs` prefix and are served at their own root-level path while remaining fully searchable and properly indexed.
