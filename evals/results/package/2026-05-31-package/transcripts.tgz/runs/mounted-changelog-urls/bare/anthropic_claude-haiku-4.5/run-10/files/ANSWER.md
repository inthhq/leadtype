# Serving Changelog at `/changelog/...` while keeping it searchable

## 1. The Single `leadtype generate` Invocation

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

**Key points:**
- `--docs-dir docs` — the primary docs folder, mounted at `/docs`
- `--docs-dir changelog=/changelog` — the changelog folder, mounted at the custom URL prefix `/changelog` instead of under `/docs`
- `--out public` — where generated artifacts are written
- `--base-url https://example.com` — required for canonical links in search metadata, sitemaps, robots.txt, and llms.txt

## 2. What This Emits for `changelog/v1.mdx`

### Internal Generated Copy
**Location:** `public/docs/changelog/v1.md`

- This is the internal representation used by the search index and runtime helpers.
- Contains flattened markdown (no complex MDX components).
- Kept under `/docs` internally so that search and agent tooling can index and reference the full corpus uniformly.
- Not directly served; this path is internal to the pipeline.

### Public Static Mirror
**Location:** `public/changelog/v1.md`

- Served directly at the custom URL prefix you specified (`/changelog`).
- This is the public-facing file that humans and agents fetch.
- Same flattened markdown content as the internal copy.
- Lets you serve changelog pages at `/changelog/v1.md` instead of `/docs/changelog/v1.md`.

### Canonical URL Agents See
**In search metadata, sitemaps, llms.txt, and agent-readability.json:** `/changelog/v1`

- The pipeline automatically emits the custom URL prefix (`/changelog/...`) in all external-facing metadata.
- This canonical URL appears in:
  - Search index hit metadata
  - `sitemap.xml` and `sitemap.md` entries
  - Links and routing references in `llms.txt` and `llms-full.txt`
  - Canonical paths in `agent-readability.json`
  - JSON-LD and SEO metadata

**Searchability:** The page remains fully searchable because:
- Content is indexed from the internal structure (`public/docs/changelog/v1.md`)
- Search results emit the custom URL prefix (`/changelog/v1`) as the canonical destination
- Runtime agents reading search results are directed to `/changelog/v1`, not `/docs/changelog/v1`

## Summary Table

| Aspect | Location | Purpose |
|--------|----------|---------|
| **Internal copy** | `public/docs/changelog/v1.md` | Search index source, runtime helpers |
| **Public mirror** | `public/changelog/v1.md` | Served directly at custom URL |
| **Canonical URL** | `/changelog/v1` | Canonical path in metadata, search results, sitemaps, agents |
| **Search status** | ✓ Fully searchable | Content indexed; results link to canonical `/changelog/v1` |

## Why This Works

The `<dir>=<url-prefix>` syntax tells leadtype to:

1. **Convert** the MDX content the same way as other sources
2. **Store internally** under `/docs` (in the `public/docs/` tree) for unified indexing and runtime helpers
3. **Emit a public mirror** at the custom URL prefix (in the `public/` root, not under `public/docs/`)
4. **Emit canonical links** everywhere agents look (search results, sitemaps, llms.txt, agent-readability.json) pointing to the custom URL

This decouples the internal organization from the public-facing URL structure, solving the "served at `/changelog/...` not `/docs/changelog/...`" requirement while maintaining searchability.
