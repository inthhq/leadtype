# Serving `changelog/` under `/changelog/...`

Our repo layout is:

```text
.
├── docs/
│   └── ... (.mdx)
├── changelog/
│   └── v1.mdx
└── ...
```

We want the changelog pages mounted at `/changelog/...` (their own public route,
**not** `/docs/changelog/...`), while still being part of the searchable corpus.

## 1. The command

`leadtype generate` lets you merge extra source folders into one generated docs
tree by repeating `--docs-dir`. Each extra folder defaults to being mounted under
`/docs/<folder>`. To give it its own public URL prefix, use the
`<dir>=<url-prefix>` form:

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://docs.example.com
```

- `--docs-dir docs` — the primary docs folder, mounted at the generated docs root (`/docs`).
- `--docs-dir changelog=/changelog` — the sibling `changelog/` folder, mounted at the public route `/changelog` instead of `/docs/changelog`.
- `--base-url` — needed so canonical links in `llms.txt`, search metadata, the sitemap, and `agent-readability.json` are emitted (site mode only).

## 2. What it emits for `changelog/v1.mdx`

With the `changelog=/changelog` mount, the file `changelog/v1.mdx` produces:

| Artifact | Path / URL | Purpose |
| --- | --- | --- |
| **Internal generated copy** | `public/docs/changelog/v1.md` | Lives under the docs tree so the static **search index** and the runtime/source helpers can find and index it. This is the page's home inside the generated corpus. |
| **Public mirror** | `public/changelog/v1.md` | A static markdown mirror written at the mounted route, so the page is actually served from `/changelog/...` rather than `/docs/changelog/...`. |
| **Canonical URL agents see** | `/changelog/v1` (and the markdown form `/changelog/v1.md`) | The canonical links emitted into `llms.txt`, search metadata, sitemap entries, and `agent-readability.json` all point at the `/changelog/...` route. |

### In short

The `=/changelog` mount keeps the page **searchable** (because the internal copy
still lives at `public/docs/changelog/v1.md` where the index and runtime helpers
look), while making its **public, canonical identity** `/changelog/v1` — served
from the mirror at `public/changelog/v1.md`. Agents browsing `llms.txt`, the
search results, the sitemap, or `agent-readability.json` only ever see the
`/changelog/...` URLs, never `/docs/changelog/...`.
