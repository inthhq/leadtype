# Mounting Changelog at Root-Level URL Path

## The Single `leadtype generate` Invocation

```bash
leadtype generate --source-dirs changelog:/ --source-dirs docs:/docs --include-in-search
```

Or, if using a configuration file approach with `leadtype.config.js`:

```bash
leadtype generate
```

With `leadtype.config.js` containing:

```javascript
export default {
  sourceDirs: [
    { path: 'changelog', mount: '/' },
    { path: 'docs', mount: '/docs' }
  ],
  search: {
    include: ['changelog/**', 'docs/**']
  }
};
```

## What Gets Emitted for `changelog/v1.mdx`

For a source file **`changelog/v1.mdx`**, the tool generates:

### 1. **Internal Generated Copy** (build cache)
```
.leadtype/build/changelog/v1/index.html
```
This is the intermediate compiled form, used for building and hot-reloading during development.

### 2. **Public Mirror** (published output)
```
out/changelog/v1/index.html
```
This is the publicly served version under the `/changelog/...` path structure, ready for a static site host or CDN.

### 3. **Canonical URL** (what agents see in metadata)
```
https://yourdomain.com/changelog/v1/
```
The search index and link metadata will point agents to this canonical path. The page itself will include appropriate `<link rel="canonical" href="/changelog/v1/">` metadata.

## Key Details

- **Mount point `:`** separates source directory from URL path: `changelog:` means mount at root `/`
- **Search inclusion**: Both `changelog/` and `docs/` are indexed and searchable via the unified search
- **No duplication**: The changelog remains under `/changelog/...` (not nested under `/docs/changelog/...`)
- **Consistent structure**: Each `.mdx` file becomes a directory with `index.html` for clean URLs
- **Metadata preservation**: Frontmatter, breadcrumbs, and sidebar configuration still work correctly
