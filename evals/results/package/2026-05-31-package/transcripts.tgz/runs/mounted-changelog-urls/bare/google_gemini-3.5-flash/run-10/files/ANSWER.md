# Answer

### 1. The `leadtype generate` Invocation

To mount the `changelog/` folder so its pages are served under the public URL path `/changelog/...` instead of `/docs/changelog/...` while remaining searchable, use the following `leadtype generate` command:

```bash
leadtype generate --src . --docs-dir docs --docs-dir changelog=/changelog --out public
```

*(Note: If you have a base URL for your website, you can also append `--base-url <url>`, for example `--base-url https://example.com`, to generate absolute canonical URLs in the sitemaps and search indexes.)*

---

### 2. Artifacts Emitted for `changelog/v1.mdx`

For a file like `changelog/v1.mdx`, the command emits the following:

1. **Internal Generated Copy:**
   * **Path:** `public/docs/changelog/v1.md`
   * **Purpose:** This file acts as the internal representation of the converted page, utilized by `leadtype` search indexing (e.g., in `search-index.json` and `search-content.json`) and other runtime helpers.

2. **Public Mirror:**
   * **Path:** `public/changelog/v1.md`
   * **Purpose:** This is a static markdown version of the source document generated directly in the public output tree, mirroring the `/changelog` public path.

3. **Canonical URL Agents See:**
   * **URL Path:** `/changelog/v1` (and `/changelog/v1.md`)
   * **Details:** `leadtype` registers `/changelog/v1` (with the configured `--base-url` prepended if provided, e.g. `https://example.com/changelog/v1`) as the canonical URL. This URL is written into the top-level index files (`llms.txt` and `llms-full.txt`), search metadata, sitemap entries (`sitemap.xml` and `sitemap.md`), and the agent manifest file (`agent-readability.json`).
