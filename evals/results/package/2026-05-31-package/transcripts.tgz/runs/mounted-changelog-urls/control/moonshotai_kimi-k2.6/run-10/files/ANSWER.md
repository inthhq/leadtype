1. **Invocation**

   ```bash
   npx leadtype generate --docs-dir docs --docs-dir changelog=/changelog --base-url https://example.com --out public
   ```

   * You must repeat `--docs-dir docs` because passing any `--docs-dir` overrides the default; without it only the changelog folder would be processed.
   * `changelog=/changelog` tells leadtype to stage the `changelog/` source under the mount path `changelog` but serve it at URL prefix `/changelog` instead of the default `/docs/changelog`.

2. **What it emits for `changelog/v1.mdx`**

   * **Internal generated copy** — `public/docs/changelog/v1.md`  
     This is the flattened markdown written by `convertAllMdx` inside the `docs/` output tree.
   * **Public mirror** — `public/changelog/v1.md`  
     `copyMountedMarkdownMirrors` copies the `.md` files from `docs/changelog/` into `changelog/` so they are reachable at the mounted root path.
   * **Canonical URL agents see** — `https://example.com/changelog/v1`  
     The search index, `llms-full.txt`, and `agent-readability.json` all resolve the page via `toDocsUrlPath` with the mount mapping, producing the page URL `/changelog/v1`. (The markdown mirror itself is reachable at `https://example.com/changelog/v1.md` for agents that request `text/markdown`.)
