# Mounting `changelog/` under `/changelog/...`

## 1. Invocation

```bash
npx leadtype generate \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

* `--docs-dir docs` keeps the main docs collection at `/docs/...`.
* `--docs-dir changelog=/changelog` mounts the `changelog/` folder at the URL prefix `/changelog` instead of the default `/docs/changelog`.
* `--base-url` is required so that canonical URLs in `llms.txt`, search indexes, and sitemaps are absolute.

## 2. What gets emitted for `changelog/v1.mdx`

| Artifact | Path | Purpose |
|---|---|---|
| **Internal generated copy** | `public/docs/changelog/v1.md` | This is where `convertAllMdx` writes the flattened markdown during staging (the changelog source is staged under `docs/changelog/` internally). |
| **Public mirror** | `public/changelog/v1.md` | `copyMountedMarkdownMirrors` sees that the mount’s URL prefix (`/changelog`) differs from the default docs path (`/docs/changelog`), so it mirrors the `.md` files to the mounted output directory. HTTP agents requesting `Accept: text/markdown` at `/changelog/v1` are served from here. |
| **Canonical URL agents see** | `https://example.com/changelog/v1` | All LLM bundles (`llms.txt`, `llms-full.txt`), the search index, and the agent-readability manifest compute URLs via `toDocsUrlPath` using the mount config `changelog → /changelog`. Agents therefore see `/changelog/v1` (or the absolute form with `--base-url`) as the canonical address, **not** `/docs/changelog/v1`. |
