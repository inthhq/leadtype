# Mounting `changelog/` under `/changelog/...`

## 1. Single `leadtype generate` invocation

Pass the default docs folder **and** the extra folder with a `=<url-prefix>` suffix using `--docs-dir`. The flag can be repeated to merge multiple source folders.

```bash
npx leadtype generate \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

* `--docs-dir docs` keeps the main docs tree mounted under `/docs` (the default when it is the first source).
* `--docs-dir changelog=/changelog` mounts the sibling `changelog/` folder at the URL prefix `/changelog` instead of the default `/docs/changelog`.
* `--out` and `--base-url` are shown here for completeness; `--out` defaults to `public` and `--base-url` is required for absolute URLs in `llms.txt`, sitemaps, and the search index.

## 2. What gets emitted for `changelog/v1.mdx`

| Artifact | Path / URL | Notes |
|---|---|---|
| **Internal generated copy** | `public/docs/changelog/v1.md` | The MDX is converted to markdown and staged inside the default `docs/` output tree. This copy feeds the search indexer and the mirror step. |
| **Public mirror** | `public/changelog/v1.md` | After conversion, `copyMountedMarkdownMirrors` copies the `.md` files from `public/docs/changelog/` into `public/changelog/` so they are servable at the mounted prefix. |
| **Canonical URL agents see** | `https://example.com/changelog/v1` | Because of the mount mapping (`changelog=/changelog`), the doc’s canonical `urlPath` is `/changelog/v1`. This is the ID used in `search-index.json`, the sitemap, and `agent-readability.json`. Agents reading `llms.txt` are linked to the markdown mirror at `/changelog/v1.md`. |
