## 1. Single `leadtype generate` invocation

```bash
npx leadtype generate \
  --src . \
  --out public \
  --base-url https://<your-domain> \
  --docs-dir docs \
  --docs-dir changelog=/changelog
```

**Why this works**
- `--docs-dir docs` keeps the main docs collection at `/docs/…`.
- `--docs-dir changelog=/changelog` mounts the sibling `changelog/` folder at the URL prefix `/changelog` instead of nesting it under `/docs/changelog`.
- Because any explicit `--docs-dir` overrides the default, both sources must be listed.

## 2. What it emits for `changelog/v1.mdx`

| Artifact | Emitted path / URL |
|---|---|
| **Internal generated copy** | `public/docs/changelog/v1.md` — produced by `convertAllMdx` inside the default `docs/` output folder. The mount path `changelog` is preserved as a subdirectory so the pipeline can resolve it. |
| **Public mirror** | `public/changelog/v1.md` — `copyMountedMarkdownMirrors` detects that the mount’s URL prefix (`/changelog`) differs from the default (`/docs/changelog`), so it mirrors all `.md` files from `public/docs/changelog/` into `public/changelog/`. |
| **Canonical URL agents see** | `https://<your-domain>/changelog/v1.md` — `llms.txt`, the agent-readability manifest, and the sitemap all use `toMountedMarkdownUrlPath`, which resolves the `changelog` mount and emits the markdown URL at the custom prefix. The search index also indexes the page under this mounted path, so it remains searchable. |
