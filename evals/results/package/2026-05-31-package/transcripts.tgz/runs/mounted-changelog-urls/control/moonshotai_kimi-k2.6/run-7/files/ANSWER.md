# Answer

## 1. Single `leadtype generate` invocation

```bash
npx leadtype generate \
  --src . \
  --out public \
  --base-url https://example.com \
  --docs-dir docs \
  --docs-dir changelog=/changelog
```

* `--docs-dir docs` keeps the main docs folder mounted at `/docs`.
* `--docs-dir changelog=/changelog` mounts the sibling `changelog/` folder at `/changelog` instead of the default `/docs/changelog`.
* `--out public` and `--base-url` are the normal site-mode arguments; the mounting behavior works in both site and bundle mode.

## 2. What is emitted for `changelog/v1.mdx`

| Artifact | Location / URL |
|----------|----------------|
| **Internal generated copy** | `public/docs/changelog/v1.md` — the flattened markdown output by `convertAllMdx`, stored inside the default docs tree. The static search index is built from this tree, so the page remains searchable. |
| **Public mirror** | `public/changelog/v1.md` — `copyMountedMarkdownMirrors` copies the markdown file to the mounted prefix so it is served at the public URL path matching the mount. |
| **Canonical URL agents see** | `https://example.com/changelog/v1` — the resolved `urlPath` from the mount (`/changelog` + `/v1`). It is the canonical page URL used in `llms-full.txt`, the search index, sitemap, and `agent-readability.json`. Agents that send `Accept: text/markdown` (or read `llms.txt`) can fetch the mirror directly at `https://example.com/changelog/v1.md`. |
