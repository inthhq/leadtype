# Mounting a sibling `changelog/` folder at `/changelog/...`

## 1. Single `leadtype generate` invocation

```bash
npx leadtype generate \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --base-url <YOUR_BASE_URL>
```

* `--docs-dir docs` includes the primary docs folder (once you pass any `--docs-dir`, the default `docs` is no longer implied, so you must list it explicitly).
* `--docs-dir changelog=/changelog` tells leadtype to treat the sibling `changelog/` directory as a docs source and mount its pages under the URL prefix `/changelog` instead of the default `/docs/changelog`.
* `--base-url` is required so that canonical absolute URLs can be written into search indexes, sitemaps, and `llms.txt`.

## 2. What is emitted for a file like `changelog/v1.mdx`

| Artifact | Path / URL | Description |
|----------|------------|-------------|
| **Internal generated copy** | `<outDir>/docs/changelog/v1.md` | The MDX-to-markdown conversion writes the flattened file into the default docs output tree, preserving the mount path (`changelog/`) as a subdirectory. |
| **Public mirror** | `<outDir>/changelog/v1.md` (served at `/changelog/v1.md`) | `copyMountedMarkdownMirrors()` sees that the mount’s URL prefix (`/changelog`) differs from the default staging prefix (`/docs/changelog`), so it copies the `.md` file into a top-level `changelog/` folder. This is the file agents actually fetch when they request the markdown mirror. |
| **Canonical URL agents see** | `<YOUR_BASE_URL>/changelog/v1` | Leadtype’s URL resolver strips the internal mount path and applies the custom prefix, producing the canonical page path `/changelog/v1`. This URL appears as the `id` in the search index, in `sitemap.xml`, in JSON-LD metadata, and as the `Link: <…>; rel="canonical"` header when the markdown mirror is served. |

Because the internal copy still lives inside `<outDir>/docs/`, `generateDocsSearchFiles()` picks it up automatically, so the changelog remains fully searchable while being served publicly under `/changelog/…`.
