# Answer

## 1. Single `leadtype generate` invocation

```bash
npx leadtype generate --docs-dir docs --docs-dir changelog=/changelog
```

> Add your usual `--out` and `--base-url` flags as needed (e.g. `--out public --base-url https://example.com`). The key is passing **both** `--docs-dir` arguments: once for the default docs tree and once for the `changelog` folder with an explicit URL prefix.

## 2. What `leadtype generate` emits for `changelog/v1.mdx`

| Artifact | Path / URL |
|----------|------------|
| **Internal generated copy** | `public/docs/changelog/v1.md` — the flattened markdown produced by `convertAllMdx` inside the output `docs/` tree. |
| **Public mirror** | `public/changelog/v1.md` — a copy of the internal file placed at the mounted prefix so the static host serves it directly. |
| **Canonical URL agents see** | `https://<base-url>/changelog/v1` (logical page path). In `llms.txt` and other agent-facing indexes the markdown mirror link is `/changelog/v1.md`. The search index also registers the page under this canonical path, so it remains searchable. |
