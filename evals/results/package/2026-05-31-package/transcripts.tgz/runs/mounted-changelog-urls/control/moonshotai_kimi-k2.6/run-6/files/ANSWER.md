1. **Single `leadtype generate` invocation**

   ```bash
   npx leadtype generate --docs-dir docs --docs-dir changelog=/changelog --out public --base-url https://example.com
   ```

   *Repeat `--docs-dir` for every source folder. The first entry (`docs`) keeps the default docs collection at `/docs/…`. The second entry uses the `<dir>=<url-prefix>` syntax to mount the side-car `changelog/` folder at the root URL prefix `/changelog/` instead of the default `/docs/changelog/`.*

2. **What is emitted for `changelog/v1.mdx`**

   | Artifact | Path / URL | Explanation |
   |---|---|---|
   | **Internal generated copy** | `public/docs/changelog/v1.md` | `convertAllMdx` flattens the MDX into markdown and writes it into the docs output tree using the staging mount path (`changelog/`). The search indexer, `llms.txt` builder, and readability pipeline all read from this location. |
   | **Public mirror** | `public/changelog/v1.md` | Because the mount’s URL prefix (`/changelog`) differs from the default `/docs/changelog`, `copyMountedMarkdownMirrors` copies the `.md` files out of `public/docs/changelog/` into `public/changelog/`. This is the file that agents (and humans requesting `Accept: text/markdown`) actually fetch when they hit `/changelog/v1.md`. |
   | **Canonical URL agents see** | `/changelog/v1` (absolute: `https://example.com/changelog/v1`) | `toDocsUrlPath` resolves the mount and strips the extension, so every index entry—search JSON, `agent-readability.json`, sitemap, and `llms.txt` metadata—uses `/changelog/v1` as the canonical page path. The `.md` mirror is the fetchable representation, but the canonical URL is the clean, extension-less route. |
