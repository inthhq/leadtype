# Leadtype navigation: `nav` vs. `group`

1. A curated `nav` in `docs.config.ts` is the preferred source of truth for navigation. When `nav` is present, it drives the sidebar/navigation manifest and the agent-facing maps such as `/docs/llms.txt`, `AGENTS.md`, and the agent-readability sitemap/manifest navigation. Page `group` frontmatter does **not** place the page in the sidebar in that mode.

   The legacy `group` field is still useful as taxonomy/metadata and as a fallback navigation mechanism for older or simpler configs that do not define `nav`. If you still keep a `groups` taxonomy in config, Leadtype can also use page `group` values for validation even though `nav` controls placement.

2. During `leadtype generate`, Leadtype resolves the navigation before writing artifacts and checks for pages whose `group` frontmatter names a slug that is not in the configured `groups` taxonomy. If it finds one, the build fails instead of silently continuing. The error is shaped like:

   ```text
   /docs/some-page declares unknown group "some-slug"
   ```

   In other words: unknown `group` slugs are treated as a build-time configuration/content mismatch. With curated `nav`, fix the stale `group` value or add the slug to the config taxonomy if you intentionally keep `groups` for validation/metadata; do not expect that `group` to affect nav placement.
