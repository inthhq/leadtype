# Onboarding: Leadtype Navigation & Grouping Answer

This document explains the relationship between the curated `nav` property in `docs.config.ts` and the legacy `group` frontmatter field, as well as the build-time validation behavior.

---

### 1. Curated `nav` vs. Legacy `group` Frontmatter Field

#### **Which one drives the sidebar and agent map?**
* **The Curated `nav` property** (configured in `docs.config.ts`) drives the sidebar, navigation summaries, and the agent map (`navigation` object in `agent-readability.json` / offline agent documentation in `AGENTS.md`). 
* When a curated `nav` is present, it is **preferred** over the `groups` configuration array. In this mode, pages are explicitly mapped to navigation nodes by matching their file paths/relative paths rather than their frontmatter `group` fields.

#### **What is the other still good for?**
Even when a curated `nav` is active, the legacy page-level `group` frontmatter fields (and the corresponding `groups` array in `docs.config.ts`) are still extremely useful for:
1. **Validation & Integrity Checks**: They are used at build time to validate document organization. The system checks all documents declaring a `group` slug and compares them against `config.groups`. This ensures that even as you customize navigation hierarchies with `nav`, pages continue to declare valid, known group taxonomy slugs.
2. **Consumer Sidebars & Filtering (e.g., Fumadocs)**: The page-level `group` slugs are parsed and preserved in page metadata (`groups: string[]`). Integrated adapters (like `leadtype/fumadocs`) pass this metadata down so that consumer-side sidebars or search layouts can filter, sort, or categorize pages programmatically.
3. **Fallback Navigation**: If `nav` is not defined or is empty, the legacy `group` frontmatter and `config.groups` array act as the fallback navigation driver, automatically constructing the sidebar hierarchy.

---

### 2. Declaring an Unknown `group` Slug at Build Time

If a documentation page specifies a `group` slug in its frontmatter that is not registered within the `groups` configuration in `docs.config.ts` (meaning `findUnknownGroups` identifies it as unrecognized):

* **A build-time Error is thrown**:
  During the artifact generation process, the CLI checks `navigation.unknown`. If any unrecognized groups are found, `cli.js` throws a fatal error:
  ```
  throw new Error(`${firstUnknownGroup.urlPath} declares unknown group "${firstUnknownGroup.slug}"`)
  ```
* **Impact**: This immediately aborts the build process and fails the build, preventing invalid or orphaned page-to-group mapping configurations from reaching production.
