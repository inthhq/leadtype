# Navigation in leadtype: `nav` vs. `group`

> Sourced from the installed `leadtype` package — the `DocsConfig` types in
> `node_modules/leadtype/dist/llm/index.d.ts` and the resolution/build logic in
> `node_modules/leadtype/dist/_shared/llm-DbiIv5JE.js` and
> `node_modules/leadtype/dist/cli.js`.

## 1. Curated `nav` vs. legacy `group` frontmatter — which one drives what?

There are two ways a single-collection leadtype project can describe its
navigation, and they are **alternatives, not partners**:

- **`nav` (curated, in `docs.config.ts`)** — an explicit, ordered tree of
  `DocsNavNode`s. Each node has a `title`, optional `slug`/`description`/`base`,
  an ordered `pages` list (extensionless paths or `{ include, exclude, sort,
  required }` globs), and optional `children`. You hand-author the structure and
  the page ordering.

- **`group` (legacy taxonomy)** — a `groups` tree of `{ slug, title,
  description, children }` in the config, combined with a `group:` field in each
  page's MDX frontmatter (`group: <slug>` or `group: [a, b]`). Pages "join" a
  group by matching its slug; ordering within a group comes from each page's
  `order:` frontmatter (then alphabetical by URL path).

**`nav` wins when present.** Throughout the pipeline the rule is the same:

```js
const hasNav = Boolean(config.nav && config.nav.length > 0);
const resolved = hasNav
  ? resolveNavGroups(config.nav ?? [])   // curated tree
  : resolveGroups(config.groups ?? []);  // group taxonomy
```

So when `docs.config.ts` exports a non-empty `nav`, **`nav` is the single source
of truth** that drives:

- the **docs UI sidebar** — `resolveDocsNavigation()` returns a navigation
  manifest built from `nav` (`buildNavigationFromNav`), which the runtime docs
  shell imports;
- the **agent map** — `AGENTS.md` (`generateAgentsMd`), the curated docs map in
  `/docs/llms.txt` (`generateLlmsTxt` → `renderDocsNavigationSummary`), the
  `/llms-full.txt` page ordering (`generateLLMFullContextFiles` →
  `orderMarkdownDocsByNavigation`), and the Agent Readability manifest /
  sitemaps (`generateAgentReadabilityArtifacts`).

The docstrings make the precedence explicit, e.g. on `DocsConfig.nav`:
*"When present, this drives docs UI and agent-facing indexes; `groups` remains
fallback taxonomy/navigation metadata."* Several config types (`LlmsTxtConfig`,
`AgentsMdConfig`, `ResolveDocsNavigationConfig`, …) repeat *"Curated navigation
tree. Preferred over `groups` when present."*

### What is the other (`group`) still good for?

When you adopt curated `nav`, the legacy `group` machinery does **not** lay out
the sidebar anymore, but it isn't dead weight:

1. **Fallback taxonomy / navigation when there's no `nav`.** If `nav` is absent
   (or empty), `groups` + frontmatter `group:` is exactly what builds the
   sidebar and agent map instead. It's the older mode and remains fully
   supported.
2. **Validation even while `nav` drives navigation.** In `nav` mode the build
   still passes your `groups` into `findUnknownGroups(docs, config.groups)`, so
   the per-page `group:` slugs keep getting validated against the configured
   group set (see Q2). This lets `group:` act as a typed label/taxonomy that is
   checked at build time.
3. **Per-page metadata that survives into artifacts.** Every page's declared
   group slugs are carried on the page object (`groups: [...]`) and emitted in
   the Agent Readability manifest's page entries and nav `pageView`s, so the
   group labels remain available as metadata regardless of which mode rendered
   the tree.
4. **Quick scaffolding.** When there's no config at all (or a collections config
   with no groups), the CLI *infers* groups by scanning every page's `group:`
   frontmatter (`inferGroups`), titleizing each slug — a zero-config starting
   point.

In short: with curated `nav`, `nav` is what humans and agents navigate by;
`group` degrades to a still-validated taxonomy label and the fallback layout
engine for projects that haven't adopted `nav`.

## 2. What happens at build time if a page declares an unknown `group` slug?

**The build fails.** When a page's frontmatter `group:` names a slug that the
config's `groups` tree doesn't define, `leadtype generate` throws and exits
non-zero.

Mechanically:

- `readSourceDocs` parses each page's `group:` into a `groups: string[]`.
- `buildGroupMembership` compares each page's slugs against the set of known
  (resolved) group slugs. A page whose slug isn't found is pushed into an
  `unknown` list as `{ page, slug }`. (A page that declares *only* unknown
  slugs also falls through to `ungrouped`, but the `unknown` record is what the
  build checks.)
- `resolveDocsNavigation` surfaces this as `navigation.unknown`. Crucially this
  happens in **both** modes: in `group` mode directly, and in `nav` mode via
  `findUnknownGroups(docs, config.groups)` — so unknown group slugs are caught
  even when the curated `nav` is what's driving the sidebar.
- The CLI then hard-fails on the first offender (per locale):

  ```js
  const navigation = await resolveDocsNavigation({ srcDir, groups, nav: effectiveNav, mounts, ... });
  const firstUnknownGroup = navigation.unknown[0];
  if (firstUnknownGroup) {
    throw new Error(
      `${firstUnknownGroup.urlPath} declares unknown group "${firstUnknownGroup.slug}"`
    );
  }
  ```

  The thrown message looks like: `**/docs/some-page declares unknown group
  "made-up-slug"**`, and `runGenerateCommand` reports it and returns exit code
  `1`. No artifacts are written for that run.

Notes / nuances:

- This check runs **before** MDX conversion and artifact generation, so an
  unknown slug stops the whole pipeline early.
- It runs per configured locale when i18n is enabled.
- If `groups` is empty/undefined (e.g. you only use `nav`), `findUnknownGroups`
  returns `[]` and there's nothing to validate against — so pages' `group:`
  fields aren't policed in that case. To get the build-time guardrail you must
  declare the group slugs in the config's `groups`.
- Defining the *config* groups themselves is also validated independently:
  duplicate sibling slugs or non-URL-safe slugs (`assertValidGroupSlug`) throw
  during `resolveGroups`/`resolveNavGroups`.
- Note `leadtype lint` does **not** check group membership; this validation is
  part of `leadtype generate` (the build), not the linter.
