# Navigation and Group Questions Answered

## 1. Curated `nav` in `docs.config.ts` vs. Legacy `group` Frontmatter Field

### Relationship & Precedence
* **Curated `nav` (Preferred):** The `nav` property in `docs.config.ts` is the modern and preferred approach to structuring your documentation. It acts as an author-facing curated tree. When present, **the curated `nav` drives both the docs UI (sidebar) and the agent-facing indexes / maps** (e.g., `/docs/llms.txt`, `AGENTS.md`, and agent-readability maps/sitemaps).
* **Legacy `group` Frontmatter (Fallback):** The `group` frontmatter field in individual MDX files and the corresponding `groups` array in `docs.config.ts` serve as legacy or fallback taxonomy/navigation metadata.

### What is the Legacy `group` Field Still Good For?
If the curated `nav` drives the main sidebar and agent indexes, the page's legacy `group` frontmatter field and the top-level `groups` config are still useful for:
1. **Fallback Navigation:** When `nav` is omitted from the configuration, `groups` serves as the primary fallback taxonomy/navigation scheme to automatically structure and build the navigation tree.
2. **Metadata & Filtering:** It exposes parsed group slugs directly via page metadata (`groups: string[]` in `DocsPageMeta`). Framework adapters (like Fumadocs) or custom client-side shells can utilize these slugs to filter, group, or query pages dynamically.
3. **Fallback Taxonomy:** It is preserved as fallback taxonomy metadata inside the generated sitemaps and agent summaries when curated `nav` is not in use.

---

## 2. Unknown `group` Slug at Build Time

If a page declares a frontmatter `group` slug that is unrecognized (meaning it doesn't match any slug defined in `docs.config.ts` or within your collection groups):

1. **Resolution & Identification:** During the build process, leadtype scans the page frontmatter and compares the declared groups against the resolved configuration. Any unrecognized slug is added to a `navigation.unknown` tracking array.
2. **Hard Build Failure:** The CLI checks if `navigation.unknown` contains any elements. If at least one unknown group is found, the build is immediately **halted and fails with a hard error**.
3. **Thrown Error Message:** Specifically, the leadtype CLI will throw an `Error` using the canonical URL path of the first offending page and the unknown slug:
   ```
   Error: <urlPath> declares unknown group "<slug>"
   ```
