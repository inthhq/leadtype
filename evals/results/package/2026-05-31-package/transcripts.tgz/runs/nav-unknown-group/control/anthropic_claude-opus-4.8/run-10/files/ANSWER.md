# Navigation in leadtype: `nav` vs `group`

Answers grounded in the installed package (`node_modules/leadtype`), specifically the
config types in `dist/llm/index.d.ts`, the resolution logic in
`dist/_shared/llm-DbiIv5JE.js`, and the `generate` command in `dist/cli.js`.

## 1. Curated `nav` vs legacy `group` frontmatter — which drives the sidebar/agent map?

**The curated `nav` in `docs.config.ts` wins. When `nav` is present it is the single
source of truth for the sidebar and every agent-facing index; the page-level `group`
frontmatter field becomes fallback/secondary taxonomy.**

### How leadtype decides

Every artifact generator (`generateLlmsTxt`, `generateAgentsMd`,
`generateAgentReadabilityArtifacts`, `resolveDocsNavigation`, `createDocsSource`) makes
the same branch:

```js
const hasNav = Boolean(config.nav && config.nav.length > 0);
const resolved = hasNav
  ? resolveNavGroups(config.nav ?? [])   // curated tree
  : resolveGroups(config.groups ?? []);  // group-frontmatter taxonomy
```

So:

- **If `nav` is set** → navigation is built from the curated tree
  (`buildNavigationFromNav`). Each nav node lists its pages by **path** (extensionless
  paths or `include` globs, with a cascading `base`), not by group slug. This ordered,
  hand-authored tree is what renders the docs sidebar, `/docs/llms.txt`, `AGENTS.md`
  sections, and the `agent-readability.json` / sitemap navigation. The `.d.ts` docs say
  it plainly: *"Curated navigation tree. Preferred over `groups` when present."* and for
  `nav`: *"When present, this drives docs UI and agent-facing indexes; `groups` remains
  fallback taxonomy/navigation metadata."*
- **If `nav` is absent** → leadtype falls back to `groups` + each page's `group:`
  frontmatter (`buildGroupMembership`), bucketing pages under the matching group slug.

In the `generate` CLI (`resolveGenerateMetadata` / `runGenerateCommand`), `nav` is
threaded into every generator and only falls back to `groups` when `nav` is empty
(and group inference fills `groups` only when no config/groups exist). Note one nuance:
if you pass `--include`/`--exclude` path filters, the CLI deliberately drops `nav`
(`effectiveNav = hasExplicitPathFilters ? undefined : nav`) and reverts to group-based
navigation, since a curated tree's fixed page paths don't survive arbitrary filtering.

### So what is `group:` frontmatter still good for?

Even when `nav` drives navigation, the `group:` field is never thrown away — it stays
useful as **metadata and as the fallback navigation model**:

1. **Fallback navigation.** Delete or empty `nav` and the same pages reorganize
   automatically from their `group:` slugs against `config.groups`. It's the
   zero-config / pre-curation taxonomy.
2. **Per-page taxonomy that travels with the content.** Each parsed doc keeps a
   `groups: string[]` (from `normalizeGroupValue`, supporting a single slug or an
   array). That array is preserved on:
   - the page metadata objects (`DocsPageMeta.groups`, `pageView`),
   - the agent-readability manifest pages (`toAgentReadabilityPage` copies `groups`),
   so downstream tools can label/categorize a page by group even though the sidebar
   order comes from `nav`.
3. **Validation.** `group:` slugs are still checked against `config.groups` at build
   time (see below), so they remain a meaningful, enforced classification.

In short: `nav` = the curated, ordered map for humans and agents; `group` = portable
per-page classification metadata and the automatic fallback when no curated tree exists.

## 2. What happens at build time when a page declares a `group` the config doesn't know?

**`leadtype generate` fails hard — it throws and exits non-zero.**

When navigation is resolved, any page whose `group:` slug isn't a known group is
collected into `navigation.unknown` (in groups mode by `buildGroupMembership`, which
splits pages into `byGroupSlug` / `ungrouped` / `unknown`; in nav mode by
`findUnknownGroups`, which still validates `group:` against `config.groups`). The CLI
then refuses to continue:

```js
const firstUnknownGroup = navigation.unknown[0];
if (firstUnknownGroup) {
  throw new Error(
    `${firstUnknownGroup.urlPath} declares unknown group "${firstUnknownGroup.slug}"`
  );
}
```

That error is reported via `reportFailure` and `runGenerateCommand` returns exit code
`1`, aborting the build before any artifacts are written. The check runs once per
locale, so it's enforced for i18n sites too.

Practical notes:

- The message names the offending page (`urlPath`) and the unknown slug, so the fix is
  either to add that slug to `groups` in `docs.config.ts` or correct the page's
  frontmatter.
- A page with **no** `group:` at all is *not* an error — it's simply treated as
  `ungrouped` and rendered under an "Other" section.
- The unknown-group check only bites when `config.groups` is non-empty. In a **nav-only**
  config (no `groups` declared), `findUnknownGroups` returns an empty list, so stray
  `group:` slugs aren't validated — they're just ignored as metadata, because nav
  references pages by path rather than by group.
- Group slugs must also be URL-safe and unique among siblings; `assertValidGroupSlug`
  and the duplicate-slug guards throw during `resolveGroups`/`resolveNavGroups`
  independently of the unknown-group check.
