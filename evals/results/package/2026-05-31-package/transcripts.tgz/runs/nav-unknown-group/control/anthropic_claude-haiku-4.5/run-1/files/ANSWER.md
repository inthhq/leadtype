# Navigation in Leadtype: Curated nav vs. Legacy groups

## 1. What is the relationship between curated `nav` and page `group` frontmatter?

### Which one drives the sidebar and agent map?

**The curated `nav` in `docs.config.ts` drives the sidebar and agent map** when it is present. It is the preferred, primary navigation system for shaping the docs UI and the agent-facing navigation manifest (used by `AGENTS.md`, `/docs/llms.txt`, the agent-readability manifest, etc.).

When `nav` is configured and present, leadtype uses it to:
- Structure the docs navigation hierarchy rendered in `AGENTS.md` and `llms.txt`
- Build the agent-readability navigation manifest
- Order and organize all generated navigation artifacts
- Determine which pages appear under which groups/sections

### What is the legacy `group` field still good for?

The page `group` frontmatter field is a **legacy fallback mechanism** that is still useful in these scenarios:

1. **When no `nav` is configured** — if a docs project only defines `groups` in the config (and no `nav`), then pages' `group:` frontmatter directly determines their sidebar placement via group membership.

2. **Ungrouped page detection** — pages without a `group` field (or with an empty group value) are collected into an "ungrouped" or "Other" section in generated navigation outputs.

3. **Legacy projects** — projects that haven't migrated to the curated `nav` approach can continue using the `groups` taxonomy + `group:` frontmatter to organize their docs.

**Key difference:** 
- **`nav`** is _curated_ — an author explicitly lists which pages go where and in what order, with glob patterns (`include:`, `exclude:`) for dynamic page inclusion.
- **`group`** is _declarative_ — each page claims membership in a predefined group slug, and pages are collected into that group.

When both `nav` and `groups` are present, `nav` takes precedence for generating navigation artifacts, and `groups` is preserved as fallback taxonomy metadata. However, `nav` does not consume or validate the `group` field at all — it is its own independent system.

---

## 2. What happens at build time if a page declares a `group` slug that the config doesn't know about?

### Error raised at generation time

When a page's frontmatter declares a `group:` that is not recognized by any group slug in the config, **leadtype raises a build-time error and stops the generation process**.

The error message is:
```
<page-url-path> declares unknown group "<group-slug>"
```

Example:
```
/docs/tutorials/getting-started declares unknown group "foo-bar"
```

### When does this validation run?

This validation occurs **during the `leadtype generate` command**, specifically after:
1. All source docs are scanned and their frontmatter parsed (including `group:` declarations)
2. The resolved `groups` tree is built from the config

The check is performed by the `findUnknownGroups()` function in leadtype's internal LLM generation pipeline, which compares every page's declared group slug against the flattened set of known group slugs from the config.

### Important caveat: only when `nav` is absent

This validation only applies if:
- **No `nav` is configured** — the groups-based validation runs
- **`nav` is configured** — unknown group validation is skipped because `nav` has its own independent page-matching system (includes/excludes) and does not rely on matching group slugs to page frontmatter

In other words, if you've migrated to a curated `nav` system, you can safely have pages with arbitrary (or outdated) `group:` values — they won't cause an error because the generation is no longer using group membership matching. However, if you're using the legacy `groups` + `group:` approach, all declared groups must be known.

### How to fix

To resolve this error, either:
1. **Add the missing group to the config's `groups` array**, giving it a slug and title that matches the page's `group:` value
2. **Remove or correct the `group:` field** in the page's frontmatter
3. **Migrate to a curated `nav`** system if this is a pattern of stale group references
