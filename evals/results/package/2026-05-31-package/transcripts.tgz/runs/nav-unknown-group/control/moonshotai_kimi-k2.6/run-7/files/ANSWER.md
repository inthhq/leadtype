# Navigation in leadtype: `nav` vs. `group`

## 1. Which drives the sidebar and agent map?

**The curated `nav` in `docs.config.ts` drives both the sidebar and the agent-readable navigation map.**

- `nav` is a tree of explicit navigation nodes. Each node lists the pages it contains (via concrete paths or glob `include`/`exclude` entries). When `nav` is present, leadtype builds the navigation tree from these curated entries, and pages that are not referenced anywhere end up in `ungrouped`.
- The page frontmatter `group` field is the **legacy** taxonomy mechanism. It works with the older `groups` config shape: you define `groups: [{ slug, title, children? }]` and pages declare which group they belong to via `group: <slug>` (or `group: [a, b]`).

### Relationship

| Config shape | Sidebar / agent map driven by | Role of frontmatter `group` |
|---|---|---|
| `nav` present | `nav` tree | **Not used for placement.** The page’s `groups` are still parsed, stored in the manifest (`AgentReadabilityPage.groups`, `DocsNavigationPage.groups`), and validated against `config.groups`, but they do not determine where the page appears in the tree. |
| `nav` absent, `groups` present | `groups` + frontmatter `group` | Used to bucket pages into the matching group. Pages with no matching group go to `ungrouped`. |

So `group` frontmatter is still good for:
- **Fallback taxonomy / metadata** — consumers (e.g., custom sidebars, fumadocs adapters, or agent tools) can read the `groups` array on each page for filtering or secondary grouping.
- **Validation** — leadtype checks every declared group slug against `config.groups` and will fail the build if a page names an unknown slug (see below).

## 2. What happens at build time if a page declares a `group` slug the config doesn’t know about?

**The build fails with a hard error.**

During `leadtype generate`, the pipeline calls `resolveDocsNavigation()` and then checks the resulting `navigation.unknown` array. If any page declared a `group` slug that is not present in the configured (or inferred) `groups` list, the CLI throws:

```
<urlPath> declares unknown group "<slug>"
```

For example:

```
/docs/features/auth declares unknown group "authentication"
```

This happens **before** any output is written, so no `AGENTS.md`, `llms.txt`, or search index is produced. The process exits with code `1`.

### When it triggers

- If you explicitly define `groups` in `docs.config.ts` and a page uses a slug missing from that list.
- If you have no config file, leadtype **infers** `groups` from all frontmatter in the source tree, so there will normally be no unknowns.
- If you use `nav` **without** any `groups` config, `findUnknownGroups` receives an empty list and skips validation, so no error occurs.
