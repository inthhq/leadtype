# Answers to Leadtype Navigation and Grouping Questions

### 1. Curated `nav` in `docs.config.ts` vs. Legacy `group` Frontmatter Field

#### **Which one drives the sidebar and agent map?**
* **The curated `nav` structure in `docs.config.ts`** directly drives both the sidebar and the agent map (including `AGENTS.md`, sitemap files, and the generated JSON schemas) whenever it is defined and non-empty. 
* When `nav` is configured, `resolveDocsNavigation` resolves the hierarchy based strictly on the nodes defined in the `nav` tree. Pages are explicitly matched and placed via relative path strings or patterns (using `include`/`exclude` globs) defined in the configuration. In this scenario, the page's legacy frontmatter `group` field is **ignored** for determining page placement or routing within the sidebar/agent map.
* If `nav` is omitted (or during builds utilizing path filters such as `--include` / `--exclude`, where curated `nav` is disabled), `leadtype` falls back to **group-based navigation**, which groups pages according to their frontmatter `group` slug.

#### **What is the other still good for?**
Even when a curated `nav` is driving the navigation, the legacy `group` frontmatter field is still highly useful for:
1. **Validation & Consistency Checking:** Page frontmatter `group` fields are still validated against the configuration's global `groups` definition (if `config.groups` is defined). This prevents orphaned/stale groups from going unnoticed.
2. **Cli/Filter Build Fallbacks:** When running targeted builds with path filters (like `--include` or `--exclude`), `leadtype` falls back to group-based navigation, temporarily bypassing the curated `nav`. Having correct `group` frontmatter ensures partial builds are cleanly structured instead of erroring out.
3. **Downstream Metadata & Custom Consumers:** The page's parsed `groups` list is preserved in the output metadata (e.g. `agent-readability.json` manifest output). Downstream consumers, search indexers, or AI-agent readability runners can leverage these tags for semantic categorization, ranking, and search relevance.

---

### 2. Behavior at Build Time for Unknown `group` Slugs

What happens at build time if a page declares a `group` slug that the configuration doesn't know about depends on the state of `config.groups`:

1. **If `groups` is defined and populated in `docs.config.ts`:**
   During the validation phase of `leadtype generate` or when building navigation, `leadtype` checks page-to-group mapping via the `findUnknownGroups` function. 
   If any documentation page's frontmatter contains a `group` slug not present in `config.groups`, the build will **fail with a hard error** and abort. 
   The CLI outputs the following error format:
   ```text
   <page_url_path> declares unknown group "<unknown_slug>"
   ```
   *Example:*
   ```text
   /docs/guides/intro declares unknown group "stale-group-slug"
   ```

2. **If `groups` is omitted or empty in `docs.config.ts`:**
   If `config.groups` is not defined or is empty, the validation check returns early. No error is thrown. Unmapped pages are safely routed to the `ungrouped` (or "Other") fallback list without failing the build.
