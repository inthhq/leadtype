# leadtype navigation: `nav` vs. `group`

Answers verified against the installed `leadtype@0.1.2` package
(`node_modules/leadtype/dist/llm/index.d.ts`, `dist/cli.js`, and the
internal navigation builder in `dist/_shared/llm-DbiIv5JE.js`).

## 1. Relationship between curated `nav` and a page's `group` frontmatter

There are two different ways to describe navigation in leadtype, and they
live in two different places:

- **`nav` (curated tree in `docs.config.ts`)** — an explicit,
  hand-authored `DocsNavNode[]`. Each node has a `title`, optional `slug`/
  `description`/`base`, and an ordered list of `pages` (extensionless paths,
  optionally via `{ include, exclude, sort }` globs) plus nested `children`.
  The config author decides exactly what appears, in what order, and under
  which section labels.

- **`group` (per-page frontmatter)** — a legacy taxonomy field on each MDX
  page (`group: <slug>` or `group: [a, b]`). Pages "opt in" to a section by
  naming a group slug that matches a `groups: DocsGroup[]` entry declared in
  the config. Ordering within a group comes from each page's `order`
  frontmatter (ascending, with un-ordered pages falling back to alphabetical
  `urlPath`).

**Which one drives the sidebar and agent map?**

`nav` wins whenever it is present. The leadtype types say so directly —
across `DocsConfig`, `LlmsTxtConfig`, `AgentsMdConfig`,
`AgentReadabilityConfig`, and `ResolveDocsNavigationConfig`, the `nav` field
is documented as *"Curated navigation tree. Preferred over `groups` when
present."* `DocsConfig.nav` specifically states: *"When present, this drives
docs UI and agent-facing indexes; `groups` remains fallback taxonomy/
navigation metadata."*

Concretely, at build time `resolveDocsNavigation` builds the navigation tree
from `nav` (via `buildNavigationFromNav`) when a curated tree is supplied;
otherwise it derives the tree from group membership. The same resolved
navigation feeds the docs UI sidebar **and** every agent-facing artifact —
`llms.txt`, `llms-full.txt`, `AGENTS.md`, and the agent-readability
manifest/sitemaps all receive the same `nav`/`groups` inputs and prefer
`nav`.

**What is `group` still good for, then?**

When `nav` is present, `groups` (and therefore the per-page `group` field)
is not the primary driver of the rendered sidebar, but it stays useful:

- **Fallback navigation/taxonomy.** If you don't author a `nav` tree, `group`
  + `groups` is what builds the sidebar and agent map. A config must export
  *either* `groups` *or* `nav` (or `collections`).
- **Validation surface.** Group slugs are still validated at build time (see
  Q2 below) even when `nav` drives the UI — the unknown-group check runs
  against the configured `groups` regardless of whether `nav` is set.
- **Page metadata.** `group` remains part of the standard frontmatter schema
  (a string or array of strings) and the per-page `groups` value is exposed
  on `DocsPageMeta.groups` / `SourceDoc.groups` for tooling that wants to
  reason about a page's membership.

In short: **`nav` is the source of truth for the rendered sidebar and agent
indexes when you provide it; `group`/`groups` is the legacy/fallback taxonomy
that still drives navigation in the absence of `nav`, still gets validated,
and still travels with each page as metadata.**

## 2. What happens at build time for a `group` slug the config doesn't know about?

**The build fails with a hard error.**

During `leadtype generate`, the CLI calls `resolveDocsNavigation(...)` for
each locale before converting any MDX. The resolver partitions pages into
`byGroupSlug`, `ungrouped`, and `unknown`: any page whose `group` slug does
**not** match a declared `groups` entry lands in `navigation.unknown`
(computed by `findUnknownGroups`). The CLI then does:

```js
const firstUnknownGroup = navigation.unknown[0];
if (firstUnknownGroup) {
  throw new Error(
    `${firstUnknownGroup.urlPath} declares unknown group "${firstUnknownGroup.slug}"`
  );
}
```

So a page declaring an unrecognized group slug aborts generation with a
message like:

```
/docs/some-page declares unknown group "made-up-slug"
```

`runGenerateCommand` catches that throw, reports it as a failure, and returns
a non-zero exit code (1) — nothing is emitted. This check runs even when a
curated `nav` tree is supplied, because the resolver still validates page
`group` slugs against the configured `groups`.

Notes / nuances:

- A page with **no** `group` at all is fine — it goes into `ungrouped`, not
  `unknown`, and does not fail the build.
- The strict check applies to the curated path too: leadtype validates group
  membership independently of which tree renders the sidebar, so stale
  `group` frontmatter is caught rather than silently dropped.
- When there is no config at all (or when path-include/exclude filters are
  used), leadtype *infers* groups from the frontmatter it finds, so every
  slug is "known" by construction and this error won't trigger — it's
  specifically about slugs that contradict a config-declared `groups` set.
