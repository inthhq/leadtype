# Leadtype navigation and `group` frontmatter

1. A curated `nav` in `docs.config.ts` takes precedence. When `nav` is present, it is the source of truth for the docs sidebar/navigation manifest and the agent-facing maps such as `/docs/llms.txt`, `AGENTS.md`, and the agent-readability navigation. Pages are placed according to the explicit `pages` / `include` entries in the nav tree, not by their frontmatter `group`.

   The legacy `group` frontmatter is still useful as taxonomy metadata on pages and as the fallback navigation mechanism when no `nav` is configured. If you keep a `groups` tree in config alongside `nav`, those group slugs also act as the known/valid set for frontmatter `group` values.

2. During `leadtype generate`, Leadtype resolves the navigation before writing artifacts. If a page declares a `group` slug that is not present in the configured `groups` tree, generation fails with an error like:

   ```text
   /docs/some-page declares unknown group "some-slug"
   ```

   This happens before the markdown/agent/site outputs are produced. Note that curated `nav` slugs are not what validate frontmatter `group`; the legacy `groups` config is the registry for that check. If a project uses only `nav` and has no `groups` tree, `group` frontmatter does not drive navigation and there is no group registry to validate against.
