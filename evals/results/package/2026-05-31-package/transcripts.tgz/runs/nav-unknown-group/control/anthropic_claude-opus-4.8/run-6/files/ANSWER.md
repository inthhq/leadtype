# leadtype navigation: `nav` vs. legacy `group`

These notes are grounded in the installed `leadtype` package
(`node_modules/leadtype/dist/_shared/llm-DbiIv5JE.js` and
`node_modules/leadtype/dist/cli.js`, with types in
`node_modules/leadtype/dist/llm/index.d.ts`).

## 1. Relationship between curated `nav` and the legacy `group` frontmatter field

There are two ways to express docs navigation, and **they are mutually
exclusive at the point of resolution — when both exist, `nav` wins.**

- **`nav` (curated, in `docs.config.ts`)** is an author-written tree of
  `DocsNavNode`s. Each node has a `title`/`slug`, an optional `base` that
  cascades to descendants, and explicit `pages` — either extensionless path
  strings or `{ include, exclude, sort, required }` glob entries. The config
  file lists, in order, exactly which pages go where. This is the
  **single source of truth that drives both the sidebar and the agent map.**

- **`group` (legacy, per-page frontmatter)** is the older model: each MDX page
  declares which group(s) it belongs to via `group: <slug>` or
  `group: [a, b]`, and the config supplies a flat/​nested `groups: DocsGroup[]`
  taxonomy of `{ slug, title, description, children }`. Membership is computed
  by matching each page's frontmatter `group` slug against a config group slug
  (`buildGroupMembership`), and pages are ordered by their frontmatter `order`
  then alphabetically by URL path.

### Which one drives the sidebar and agent map

`nav`. Every navigation-producing function branches on
`hasNav = Boolean(config.nav && config.nav.length > 0)` and prefers the curated
tree when it is present:

- `resolveDocsNavigation()` (the manifest the runtime docs shell imports) calls
  `buildNavigationFromNav(...)` when `nav` is set, otherwise falls back to the
  `groups` + frontmatter membership path.
- `generateAgentsMd()` (the bundled `AGENTS.md` agent map) renders
  `renderAgentsNavigationGroup` from the resolved `nav` when present, otherwise
  iterates `groups`.
- `generateLlmsTxt()` and `generateAgentReadabilityArtifacts()` do the same
  `hasNav ? nav : groups` selection.

The type docs say it directly: when `nav` is present "this drives docs UI and
agent-facing indexes; `groups` remains fallback taxonomy/navigation metadata,"
and for `AgentsMdConfig.nav`: "Curated navigation tree. Preferred over `groups`
when present."

Importantly, when `nav` drives navigation, the curated tree determines page
**placement and ordering**, and the per-page `group:` frontmatter is **not**
consulted to build the tree at all. Pages not referenced anywhere in `nav` are
collected into an `ungrouped` ("Other") bucket rather than placed by their
`group` slug.

### What the other (`group`) is still good for

- **Fallback navigation when there is no `nav`.** If `docs.config.ts` declares
  only `groups` (no `nav`), the legacy frontmatter-driven model fully drives the
  sidebar, `llms.txt`, `AGENTS.md`, and the readability manifest. The CLI even
  auto-infers a `groups` list from frontmatter `group:` values
  (`inferGroups`) when no config groups exist (e.g. no config file, or when
  path-filter flags are used).
- **Surviving as page metadata.** Even when `nav` is in charge, each resolved
  page view and agent-readability page still carries its `groups: string[]`
  (copied from frontmatter). So the `group` field remains useful taxonomy/labeling
  metadata that consumers can read off a page, independent of where `nav` places
  the page in the tree.
- **A migration path.** You can keep `group` frontmatter on pages while adopting
  `nav`; the curated tree takes over UI/agent ordering, and `group` quietly
  becomes descriptive metadata + the fallback for any future config that drops
  `nav`.

Note: `nav` and `group`/`groups` live at the same level — top-level `nav`/
`groups` are for the single-collection shape and are mutually exclusive with the
`collections` map (setting both is rejected at config load).

## 2. What happens at build time if a page declares an unknown `group` slug?

**The build fails.** During `leadtype generate`, after resolving navigation the
CLI inspects `navigation.unknown` and throws on the first entry:

```
<urlPath> declares unknown group "<slug>"
```

(see `runGenerateCommand` in `cli.js`, around the `firstUnknownGroup` check).
This is a hard error — `runGenerateCommand` returns exit code `1`. It is
enforced for every locale when i18n is configured.

How `unknown` is computed:

- In the **legacy `groups`-only** path, `buildGroupMembership` matches each
  page's frontmatter `group` slugs (case-insensitively) against the known group
  slugs from config. Any slug with no matching config group is pushed onto the
  `unknown` list as `{ urlPath, slug }`. (A page is only treated as "ungrouped"
  if it declares *no* groups at all; declaring a group the config doesn't know
  about is an error, not a silent demotion to "Other".)
- In the **`nav`** path, navigation placement comes from the curated tree, but
  the build still validates frontmatter `group` slugs against any `groups` you
  also declared, via `findUnknownGroups(docs, config.groups)`. So even with
  `nav` in charge, a frontmatter `group` that doesn't exist in `groups` is still
  reported as unknown and fails the build. (If you provide no `groups` alongside
  `nav`, there is nothing to validate against and `findUnknownGroups` returns an
  empty list.)

Related but distinct guards (not the unknown-group case):

- An **invalid** slug shape (not URL-safe alphanumerics/dashes) throws
  `Invalid group slug "..."` via `assertValidGroupSlug`.
- **Duplicate** sibling slugs throw `Duplicate group slug "..."`.
- A `nav` **page reference** that matches no doc throws
  `Nav page "..." did not match a documentation page`, and a `nav` `include`
  glob that matches nothing warns (or throws if `required: true`).
