# leadtype Navigation: `nav` vs. `group`

## 1. Which one drives the sidebar and agent map?

**`nav` in `docs.config.ts` drives the sidebar and agent map.**

- When `nav` is present and non-empty, leadtype uses the curated tree (`DocsNavNode[]`) to build the navigation that appears in the docs UI, `llms.txt`, `AGENTS.md`, the agent-readability manifest, and search.
- When `nav` is absent, it falls back to the legacy `groups` array in `docs.config.ts`. In that mode, pages declare which group they belong to via frontmatter (`group: <slug>`), and leadtype matches those slugs against the config `groups` to build the sidebar/agent map.

**What the `group` frontmatter is still good for:**

Even when `nav` is driving the layout, the page `group` field is **not ignored** — it is validated against the config’s `groups` array at build time. If a page declares a `group` slug that does not exist in the config, the build fails (see below). So `group` frontmatter and config `groups` remain useful as:

- **Taxonomy / navigation metadata** — they describe the logical buckets pages claim to belong to.
- **Validation guardrails** — they catch typos or stale group slugs in frontmatter before shipping.

In short: `nav` is the author-curated layout; `group` + `groups` is the legacy/fallback taxonomy layer that still gets checked for consistency.

## 2. What happens at build time if a page declares an unknown `group` slug?

The build **fails with an explicit error**.

During generation, `resolveDocsNavigation()` runs `buildGroupMembership()`, which compares every page’s frontmatter `group` slugs against the known slugs defined in `docs.config.ts`. Any mismatch is collected in an `unknown` array. The CLI then checks:

```js
const firstUnknownGroup = navigation.unknown[0];
if (firstUnknownGroup) {
  throw new Error(
    `${firstUnknownGroup.urlPath} declares unknown group "${firstUnknownGroup.slug}"`
  );
}
```

You will see an error like:

```
/docs/getting-started declares unknown group "onbording"
```

This happens in **both** modes:

- If you are using `nav`, the build still validates frontmatter `group` values against the config’s `groups` array (via `findUnknownGroups()`).
- If you are using `groups` directly, the same validation runs.

The only way an unknown group does **not** error is when `groups` is omitted from the config entirely and leadtype infers the groups automatically from frontmatter (in which case every declared slug is, by definition, known).
