# Navigation: `nav` vs. `group`

## 1. Relationship between curated `nav` and the legacy `group` frontmatter field

**`nav` in `docs.config.ts` drives the sidebar and the agent map.**

When `nav` is present, leadtype uses that curated tree to build the navigation that appears in the UI sidebar and in agent-facing artifacts (`llms.txt`, `AGENTS.md`, sitemap, etc.). Pages are placed according to `nav` node entries (`pages`, `include`, `children`) — not by their frontmatter `group` value.

**The page `group` frontmatter field is still useful as fallback taxonomy and metadata:**

- **Fallback navigation:** If you remove `nav` (or never define it), leadtype falls back to the `groups` config array. In that mode, pages are auto-bucketed into groups based on their frontmatter `group` slug(s).
- **Validation target:** If you keep `groups` defined alongside `nav`, leadtype validates every page’s declared `group` slugs against that list. This catches typos at build time.
- **Runtime metadata:** The parsed `group` slugs are still exposed on every page (for example, the fumadocs adapter passes them as `groups` in page data), so your own UI logic can filter or group by them even when the main tree is driven by `nav`.

In short: `nav` is the source of truth for the tree; `group` frontmatter becomes secondary metadata that can be validated, consumed by adapters, or used as a fallback when `nav` is absent.

## 2. What happens at build time if a page declares an unknown `group` slug?

**The build throws an error and fails.**

During generation, leadtype calls `resolveDocsNavigation()`, which collects any page whose frontmatter `group` does not exist in the config’s `groups` array into `navigation.unknown`. The CLI then explicitly checks for unknowns:

```js
const firstUnknownGroup = navigation.unknown[0];
if (firstUnknownGroup) {
  throw new Error(
    `${firstUnknownGroup.urlPath} declares unknown group "${firstUnknownGroup.slug}"`
  );
}
```

So if a page declares `group: foobar` and the config has no group with slug `foobar`, you will see a build error like:

```
/docs/some-page declares unknown group "foobar"
```

> **Note:** This validation only runs when the config defines `groups`. If `groups` is omitted entirely, there is no whitelist to validate against, so the build will not error for unknown slugs — the pages will simply be treated as ungrouped.
