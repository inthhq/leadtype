# Navigation in Leadtype

This document answers the relationship between the curated `nav` configuration and the page-level frontmatter `group` field, as well as the build-time validation behavior for unknown groups.

---

### 1. Curated `nav` vs. Legacy `group` Frontmatter Field

#### **Which one drives the sidebar and agent map?**
* **The curated `nav` configuration** (defined in `docs.config.ts`) drives both the **docs UI sidebar** and the **agent-facing indexes / agent maps** (including `llms.txt`, sitemaps, navigation summaries, and `AGENTS.md`) when it is present.

#### **What is the other (legacy `group` frontmatter / `groups` config) still good for?**
* **Primary Fallback Navigation:** If `nav` is omitted from the configuration, the `groups` configuration combined with page-level `group` frontmatter serves as the primary fallback taxonomy used to construct the navigation tree and the sections structure.
* **Page-Level Taxonomy & Classification:** The `group` frontmatter field attaches metadata directly to individual pages, providing structural context.
* **Downstream Consumers & UI Framework Adapters:** Downstream UI layers or integration adapters (for example, the `leadtype/fumadocs` adapter) map the parsed `group` slugs into the page's metadata so that custom framework sidebars can dynamically filter, search, or group pages in the rendered UI.

---

### 2. What happens at build time if a page declares an unknown `group`?

During the build process (when running `leadtype generate` or calling `resolveDocsNavigation`), the pipeline performs strict group validation:

1. **Detection:** All pages have their frontmatter analyzed. Any page declaring a `group` slug that does not exist in the configured `groups` (or globally registered group list across collections) is flagged as an unknown group and collected into `navigation.unknown`.
2. **Error Throwing:** If `navigation.unknown` contains any pages, the build pipeline immediately detects the first unknown group (using `navigation.unknown[0]`).
3. **Build Failure:** The pipeline throws a build-time validation error:
   ```text
   Error: <urlPath> declares unknown group "<slug>"
   ```
   This error halts the execution, causing the pipeline / site build process to **fail**.
