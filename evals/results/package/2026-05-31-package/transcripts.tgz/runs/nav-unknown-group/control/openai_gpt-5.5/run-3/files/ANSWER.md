# Leadtype navigation vs. `group` frontmatter

1. **Curated `nav` wins when it is present.** The navigation tree in `docs.config.ts` is the source of truth for the docs sidebar and the agent-facing maps/indexes (`AGENTS.md`, `/docs/llms.txt`, agent-readability navigation, etc.). Its `pages` entries explicitly list or glob the pages that belong under each nav node; pages not referenced by `nav` fall into the generated “Other” bucket.

   A page’s legacy `group` frontmatter is therefore **not what places the page in the sidebar/agent map when `nav` exists**. It is still useful as fallback taxonomy/navigation metadata for projects that do not define `nav`, and it is still preserved on page metadata for compatibility or custom uses such as filtering/search facets. If you keep a `groups` taxonomy in config alongside `nav`, Leadtype can also use it to validate that legacy `group` values still refer to known groups.

2. **Unknown `group` slugs fail the build.** During generation Leadtype resolves navigation and checks for pages whose frontmatter declares a `group` slug that is not in the configured group taxonomy. If it finds one, generation throws an error like:

   ```text
   /docs/some-page declares unknown group "some-slug"
   ```

   In the CLI this is reported as a `leadtype generate` failure and exits non-zero, before the agent/readability artifacts are completed.
