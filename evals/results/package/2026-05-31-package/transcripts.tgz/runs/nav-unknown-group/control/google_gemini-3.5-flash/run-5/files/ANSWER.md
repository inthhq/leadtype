# Answers to Leadtype Navigation Questions

## 1. What is the relationship between the curated `nav` in `docs.config.ts` and a page's legacy `group` frontmatter field?

### Driver of the Sidebar and Agent Map
* **When `nav` is present** in `docs.config.ts`: The **curated `nav` drives the sidebar, documentation UI, and agent-facing indexes** (including `sitemap.md`, `/docs/llms.txt`, and the offline agent map `AGENTS.md`).
* **When `nav` is absent**: The structure falls back to the `groups` tree defined in `docs.config.ts`, where pages' legacy `group` frontmatter fields **drive** the sidebar and agent map by mapping pages to their matching group slugs.

### What the other is still good for
When a curated `nav` tree is configured, the page's legacy `group` frontmatter field (and the configuration's `groups` list) remains useful for:
1. **Fallback Taxonomy & Metadata**: It serves as taxonomic classification metadata. The group slugs are preserved in the page metadata (`groups: string[]`), allowing consumer-side templates and sidebars (e.g. Next.js, SvelteKit, or Fumadocs wrappers) to filter, group, or query pages programmatically.
2. **Build-Time Typos/Stale Reference Validation**: It is used to validate page frontmatter. Even when `nav` drives the actual navigation layout, the build pipeline checks all pages' `group` fields against `config.groups` to catch typos or stale group references.


---

## 2. What happens at build time if a page declares a `group` slug that the config doesn't know about?

If a page declares a frontmatter `group` slug that is not declared in the `groups` list of the documentation configuration:

1. **Detection**: During the navigation-resolution stage of the build pipeline, the helper function `findUnknownGroups` runs. It compares the page's frontmatter `group` slugs with the known slugs in the configuration.
2. **Error Interruption**: If any unknown group is found, the generator throws a hard validation error:
   ```
   Error: <page-url-path> declares unknown group "<unknown-slug>"
   ```
3. **Build Failure**: This error bubbles up, aborts the generation pipeline, logs the failure to stderr, and exits the build command (e.g. `leadtype generate`) with an exit code of `1`, failing the build.
