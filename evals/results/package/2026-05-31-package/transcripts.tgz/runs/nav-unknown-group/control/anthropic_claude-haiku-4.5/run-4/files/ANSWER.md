# Navigation Architecture in leadtype

## Question 1: `nav` in `docs.config.ts` vs. page `group` frontmatter

### The Relationship

**`nav` drives the sidebar and agent map; `group` is legacy metadata still useful for other purposes.**

In the leadtype docs pipeline:

- **`nav`** (curated navigation tree in `docs.config.ts`): 
  - This is the **primary driver** for sidebar rendering, agent-facing docs indexes (`llms.txt`, `AGENTS.md`, `/docs/llms.txt`), and structured navigation manifests.
  - When `nav` is present, it is **preferred over `groups`** in all generation and runtime APIs (see `resolveDocsNavigation`, `generateLlmsTxt`, `generateAgentsMd`, etc.).
  - It provides an author-curated tree structure with fine-grained control over ordering, grouping, and nesting.
  - Referenced in types like `LlmsTxtConfig`, `AgentsMdConfig`, `ResolveDocsNavigationConfig` — all have `nav?: DocsNavNode[]` marked as "Preferred over `groups` when present."

- **`group` frontmatter field** (page-level metadata):
  - A **legacy fallback taxonomy** for grouping pages when `nav` is absent.
  - Still parsed and validated by the frontmatter schema (accepts `string | string[]`).
  - Declares which group(s) a page belongs to for sidebar/index organization.
  - Kept for backward compatibility and for cases where a project hasn't adopted curated navigation yet.
  - Also used for semantic metadata that frameworks and agents can read independently.

### What Each Is Still Good For

- **`nav` (curated):**
  - Complete control over UI and agent-readable sidebar structure.
  - The **single source of truth** for modern docs projects.
  - Enables multi-level nesting, custom titles, descriptions, and ordering granularity.
  - Required for building sophisticated docs sites (Next.js, TanStack, Astro, etc.).

- **`group` (legacy):**
  - Backward compatibility for older doc sets that haven't migrated to `nav`.
  - Semantic annotation: a page can declare its topical area even if `nav` doesn't reference it.
  - Useful in multi-collection setups where different collections have different nav strategies.
  - Can serve as fallback taxonomy for tools that need to understand page relationships independently.

---

## Question 2: Build-time Behavior for Unknown Group Slugs

### What Happens

**Pages with unknown `group` slugs are **collected but not surfaced in the primary navigation structure**. They appear in a dedicated `unknown` array in the navigation manifest and are included in generated artifacts with a warning or tracking mechanism.**

From the `DocsNavigation` type definition in the readability module:

```typescript
type DocsNavigation = {
  groups: DocsNavigationGroup[];
  ungrouped: DocsNavigationPage[];
  /** Pages that named a group slug not present in the config. */
  unknown: {
    urlPath: string;
    slug: string;
  }[];
  locale?: string;
};
```

### Detailed Behavior

1. **No Hard Error**: Build-time does **not fail** if a page declares a `group` slug that the config doesn't know about.

2. **Fallback Categorization**: Unknown group pages are:
   - Separated from known `groups` entries.
   - Listed in the `unknown` array so build tools can detect and report them.
   - Often treated similarly to "ungrouped" pages in rendering (no sidebar parent).

3. **Included in Outputs**: The pages themselves **are still included** in:
   - Generated markdown files (`docs/*.md`).
   - `llms.txt` and `AGENTS.md` files (though may appear unstyled).
   - Search indexes.
   - Agent-readability artifacts.

4. **Linting vs. Generation**:
   - `lintDocs()` may warn or error depending on schema configuration (unknown fields).
   - `generateLlmsTxt()`, `generateAgentsMd()`, `resolveDocsNavigation()` **succeed** but track unknowns in the manifest.
   - This allows incremental migration: add pages with future group slugs now, implement the group definition later.

### Design Rationale

This "soft fail" approach allows:
- **Progressive enhancement**: Pages can declare a group before that group is defined in the config.
- **Clear diagnostics**: The `unknown` array in the manifest tells you exactly which pages are misaligned.
- **No breaking changes**: Existing pages continue to render even if the nav config is incomplete.

If you want stricter validation, use a custom frontmatter schema or a build-time linter that treats unknown groups as errors.
