# Navigation in leadtype: `nav` vs `group` Frontmatter

## 1. The Relationship Between Curated `nav` and Legacy `group` Frontmatter

### Which One Drives the Sidebar and Agent Map?

The **curated `nav` in `docs.config.ts` is the primary driver** for both the sidebar UI and agent-facing navigation artifacts (like `AGENTS.md` and the discovery manifest).

Per the leadtype type definitions:
- `DocsConfig.nav` is documented as **"Curated navigation for the single-collection shape. When present, this drives docs UI and agent-facing indexes"**
- Functions like `generateAgentReadabilityArtifacts`, `generateAgentsMd`, and `resolveDocsNavigation` all state: **"Curated navigation tree. Preferred over `groups` when present."**

This means when you define both `nav` and `groups` in your config, the `nav` takes precedence for all artifact generation (sitemap, agent readability discovery, AGENTS.md structure, etc.).

### What Is `group` Frontmatter Still Good For?

The legacy `group` frontmatter field (e.g., `group: "api"` or `group: ["api", "reference"]`) serves as a **fallback categorization and page-to-group binding** when `nav` is absent:

1. **Fallback Navigation**: When only `groups` (not `nav`) is defined, leadtype builds navigation from the group taxonomy and the frontmatter declarations.

2. **Page-to-Group Binding**: Pages explicitly declare which group they belong to via their frontmatter, which is used to:
   - Organize pages into the navigation hierarchy
   - Populate the `groups` array in the resolved `DocsNavigationPage` and `AgentReadabilityPage` types
   - Maintain a record of page categorization even after `nav` is applied

3. **Metadata Preservation**: The frontmatter `group` field is always parsed and preserved — it's accessible in:
   - `DocsPageMeta.groups` (array of group slugs)
   - Agent readability manifests under each page's `groups` field
   - Search indexes and other downstream tools

In essence: **`nav` is what users see and agents navigate; `group` is the categorization metadata that pages carry about themselves**, regardless of whether the UI uses `nav` or `groups`.

---

## 2. Build-Time Behavior for Unknown Group Slugs

### What Happens If a Page Declares a `group` Slug That the Config Doesn't Know About?

At build time, **the page is not removed or rejected**, but instead:

1. **Collected in `navigation.unknown` Array**  
   The `DocsNavigation` type includes an `unknown` field:
   ```typescript
   unknown: {
     urlPath: string;
     slug: string;
   }[];
   ```
   Pages declaring unknown groups are accumulated here — a registry of orphaned category declarations.

2. **No Hard Error During Generation**  
   Leadtype does not throw an error or halt the build when it encounters an unknown group slug. The generation continues, and the page is still processed and included in other artifacts (markdown mirrors, search index, etc.).

3. **Linting Detects It (Optionally)**  
   The `leadtype lint` command can be configured to catch and report these issues. The linting system is strict about schema validation but does not enforce group slug matching by default — this is left to your lint rules and CI pipeline.

4. **Page Still Appears Under `ungrouped`**  
   In the resolved navigation, a page with an unknown group slug typically falls back to the `ungrouped` array:
   ```typescript
   ungrouped: DocsNavigationPage[];
   ```

### Summary

- **Pages are not dropped** — they remain in the build and appear in search, markdown mirrors, etc.
- **Unknown groups are tracked** in the `unknown` array of the navigation manifest so you can discover and fix them.
- **The build succeeds**, but agents and UIs can see which pages have orphaned group references.
- **You should lint or validate** these declarations in your CI to catch categorization mistakes before they ship.

This graceful degradation ensures docs remain accessible even if category metadata is incomplete or mismatched, while still surfacing the problem for repair.
