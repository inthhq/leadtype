# Navigation in leadtype: `nav` vs. `group`

Short version: the curated **`nav`** tree in `docs.config.ts` is the source of
truth for the sidebar and the agent-facing maps. A page's legacy **`group`**
frontmatter field is a *fallback* taxonomy — it only drives navigation when no
`nav` is configured. But `group` is still validated even when `nav` wins, and a
group that the config doesn't recognize is a hard build failure.

---

## 1. Relationship between curated `nav` and a page's `group` frontmatter

### `nav` is the primary, preferred driver

`DocsConfig` exposes two mutually-cooperating navigation inputs:

- **`groups`** — a flat/nested group taxonomy (`{ slug, title, description?, children? }`).
  Pages opt into a group by declaring `group: <slug>` (or `group: [a, b]`) in
  their MDX frontmatter.
- **`nav`** — an *author-curated* navigation tree (`DocsNavNode[]`) where you
  list pages explicitly by path (with `base` cascading, glob `include`/`exclude`
  entries, and per-node `sort`).

The type docs state the precedence directly: `nav` is

> "Curated navigation … When present, this drives docs UI and agent-facing
> indexes; `groups` remains fallback taxonomy/navigation metadata."

That precedence is enforced in code. Every generator computes
`hasNav = Boolean(config.nav && config.nav.length > 0)` and then branches:

```js
const resolved   = hasNav ? resolveNavGroups(config.nav) : resolveGroups(config.groups);
const membership = hasNav ? undefined : buildGroupMembership(docs, resolved);
```

- When `nav` is present, navigation is built with `buildNavigationFromNav(...)`,
  which places pages by the explicit path references in the tree. A page's
  `group:` frontmatter is **not** consulted for placement at all — pages not
  referenced by any nav node simply fall into `ungrouped` ("Other").
- When `nav` is absent, navigation is built from `group` membership
  (`buildGroupMembership` matches each page's `group:` slugs against the
  declared `groups`).

This single branch governs all the outputs that matter for onboarding:

- `resolveDocsNavigation()` → the navigation manifest your docs shell renders as
  the **sidebar**.
- `generateAgentsMd()` → the **agent map** (`AGENTS.md`, the bundled offline
  entry point).
- `generateLlmsTxt()` / `generateLLMFullContextFiles()` /
  `generateAgentReadabilityArtifacts()` → `llms.txt`, `llms-full.txt`, the
  sitemap, and `agent-readability.json`.

So: **`nav` (when configured) drives both the sidebar and the agent map.**

### What `group` frontmatter is still good for

Even when `nav` is in charge, the `group` field keeps earning its place:

1. **Fallback navigation.** If a project has no `nav` (or only `groups`), the
   `group` field is the *only* thing that organizes the sidebar and agent map.
   It is the simpler, frontmatter-driven mode.
2. **Per-page taxonomy metadata.** A page's resolved `groups` array is carried
   through to every page view and into the agent-readability manifest
   (`pageView(...)` and `toAgentReadabilityPage(...)` both emit
   `groups: [...doc.groups]`), regardless of whether `nav` or `groups` built the
   tree. So `group` remains a queryable label/tag on each page — useful for
   filtering, grouping in search, or other tooling — independent of sidebar
   placement.
3. **Group inference.** When there is *no* config at all (or collections without
   groups, or explicit `--include/--exclude` path filters with no groups), the
   CLI calls `inferGroups()`, which scans every page's `group:` frontmatter and
   synthesizes a group taxonomy from the distinct slugs it finds. In that mode
   `group` literally *becomes* the navigation.
4. **Validation anchor.** Even under `nav`, `group` is still cross-checked
   against the configured `groups` (see Q2) — so it doubles as a guardrail that
   catches typos/stale slugs.

---

## 2. What happens at build time if a page declares an unknown `group` slug

**It fails the build.** A `group` slug that the config doesn't know about is
treated as an error, not a warning — and this check runs *even when `nav` is the
active navigation driver*.

The mechanics:

- `buildGroupMembership()` partitions pages into three buckets: matched
  (`byGroupSlug`), `ungrouped` (no `group` at all), and **`unknown`** — pages
  whose declared `group` slug doesn't match any known group.
- In `nav` mode the navigation builder still validates `group` against the
  configured `groups` via `findUnknownGroups(docs, config.groups)`, attaching any
  offenders to `navigation.unknown`.
- The `generate` CLI then refuses to proceed:

  ```js
  const firstUnknownGroup = navigation.unknown[0];
  if (firstUnknownGroup) {
    throw new Error(
      `${firstUnknownGroup.urlPath} declares unknown group "${firstUnknownGroup.slug}"`
    );
  }
  ```

  This runs for every locale before any MDX is converted, so the whole
  `leadtype generate` run aborts with exit code 1 and a message naming the
  offending page URL and the bad slug, e.g.:

  ```
  /docs/quickstart declares unknown group "quikstart"
  ```

Notes / edge cases worth knowing during onboarding:

- A page with **no** `group` field is *not* an error — it's `ungrouped` and
  renders under an "Other" section.
- A page whose `group` is a **list** is fine as long as *at least one* slug
  matches a known group; any non-matching slug in that list still lands in
  `unknown` and trips the same build failure.
- Group slugs must be URL-safe (alphanumerics + dashes) and unique among
  siblings; violating either throws during config resolution
  (`assertValidGroupSlug` / duplicate-slug checks) — a separate but related
  build-time guard.
- The unknown-group check is keyed off the config's `groups`. So if you migrate
  fully to `nav` but delete `groups`, `findUnknownGroups` short-circuits
  (no groups to validate against) and stale `group:` frontmatter is simply
  ignored rather than flagged.

---

## TL;DR

| | Drives sidebar & agent map? | Still useful for |
| --- | --- | --- |
| **`nav` (config)** | **Yes, when present** — curated, explicit, preferred | the single source of truth for ordering/structure |
| **`group` (frontmatter)** | Only as the fallback when `nav` is absent | per-page taxonomy metadata, group inference, and validation |

An unknown `group` slug (one not declared in the config's `groups`) makes
`leadtype generate` **throw and exit non-zero**, naming the page and the bad
slug — even when `nav` is doing the actual navigation.
