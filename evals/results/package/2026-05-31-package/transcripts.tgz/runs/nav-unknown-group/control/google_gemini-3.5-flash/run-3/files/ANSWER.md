# Navigation and Frontmatter Relationship in Leadtype

Below are the answers regarding navigation and the relationship between `nav` and `group` in a Leadtype project.

---

### 1. What is the relationship between the curated `nav` in `docs.config.ts` and a page's legacy `group` frontmatter field?

* **Relationship & Priority:**
  The `nav` tree configured in `docs.config.ts` represents a **curated, highly structured navigation system** (defined as `DocsNavNode[]`). When `nav` is declared, it is preferred and overrides the legacy `groups` configuration as the primary structural representation.
  
* **Which one drives the sidebar and agent map?**
  * **Curated `nav`** drives both the **sidebar (docs UI)** and **agent-facing indexes / agent maps** (such as `/docs/llms.txt` and `AGENTS.md`) when it is defined.

* **What is the other still good for?**
  * **Fallback Taxonomy & Metadata:** If `nav` is driving the sidebar and agent map, the `groups` configuration and the page's `group` frontmatter fields still act as **fallback taxonomy/navigation metadata**.
  * **Build-Time Validation:** The legacy `groups` configuration remains a crucial asset for **validation**. Even when curated `nav` is active, the build pipeline scans MDX files and validates every `group` declared in a page's frontmatter against the `groups` list in your config (via `findUnknownGroups`). This ensures that stray, stale, or typoed category tags in your page frontmatter are caught during development.

---

### 2. What happens at build time if a page declares a `group` slug that the config doesn't know about?

* **Validation and Unknown Group Capture:**
  At build/generation time (specifically during `leadtype generate` or when `resolveDocsNavigation` is called), the pipeline parses page frontmatter and extracts `group` slugs. It checks these slugs against the configured groups list. Any declared slug that is not present in the configuration is added to a list of `unknown` groups.
  
* **Throwing an Error:**
  If the build runner finds any unknown groups, it extracts the first occurrence and **immediately throws a build-time Error** with the following format:
  ```text
  <urlPath> declares unknown group "<slug>"
  ```
  *(For example: `/docs/intro declares unknown group "stray-group"`)*

* **Build Failure:**
  This error **halts the build pipeline** and exits the CLI command with a **non-zero exit code (1)**. This ensures that any incorrect, missing, or mistyped group declarations in your content files are caught immediately and do not get published.
