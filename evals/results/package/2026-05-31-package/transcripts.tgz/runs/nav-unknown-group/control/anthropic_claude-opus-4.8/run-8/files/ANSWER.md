# Navigation in leadtype: `nav` vs. `group`

These notes are grounded in the installed package (`node_modules/leadtype`),
specifically the type definitions in `dist/llm/index.d.ts` /
`dist/llm/readability.d.ts` and the build logic in
`dist/_shared/llm-DbiIv5JE.js` and `dist/cli.js`.

## 1. Relationship between curated `nav` and per-page `group` frontmatter

There are two different ways to describe structure, and they live in two
different places:

- **`nav` (in `docs.config.ts`)** is a *curated navigation tree* authored by
  hand in the config. Each node has a `title`, optional `slug`/`description`/
  `base`, and a `pages` list that references docs **by path** (extensionless,
  relative to the nearest `base`, with a leading slash to escape to the root).
  Pages can be listed explicitly or pulled in with `include`/`exclude` globs
  and a `sort` order. It is an ordered, editorial layout.

- **`group` (page frontmatter)** is a *taxonomy slug* (or array of slugs) that
  each MDX/Markdown page declares about itself, e.g. `group: quickstart`. The
  config's `groups` array then defines the title/description/nesting for those
  slugs. Pages are bucketed into a group by matching their frontmatter `group`
  slug to a configured group slug; order within a group comes from a per-page
  `order` field (falling back to alphabetical `urlPath`).

**Which one drives the sidebar and agent map?** When `nav` is present in the
config, **`nav` wins** — it drives both the docs UI sidebar and the
agent-facing indexes. The generators all branch the same way:

```js
const hasNav = Boolean(config.nav && config.nav.length > 0);
const resolved = hasNav
  ? resolveNavGroups(config.nav ?? [])   // curated tree
  : resolveGroups(config.groups ?? []);  // frontmatter taxonomy
```

This branch appears in `resolveDocsNavigation` (the structured nav manifest the
docs shell imports), `generateLlmsTxt` (`/docs/llms.txt`), `generateAgentsMd`
(the bundled `AGENTS.md`), and `generateAgentReadabilityArtifacts`
(`agent-readability.json`, `sitemap.md`). The config's own doc-comment confirms
the precedence: *"Curated navigation for the single-collection shape. When
present, this drives docs UI and agent-facing indexes; `groups` remains fallback
taxonomy/navigation metadata."* The same "Preferred over `groups`" note is
attached to `nav` on every generator config type.

**So what is `group` still good for when `nav` exists?**

- **Fallback taxonomy / navigation** — if you *don't* author a `nav`, the
  `groups` taxonomy (driven by each page's `group` frontmatter) is what builds
  the sidebar and agent map instead. `groups` is the simpler, frontmatter-driven
  mode; `nav` is the curated upgrade.
- **Per-page metadata that travels with the content** — `group` (and `order`)
  is parsed off every page (`normalizeGroupValue(parsed.data.group)`), so the
  group slugs a page declares are always available on page metadata
  (`DocsPageMeta.groups`, `SourceDoc.groups`, `AgentReadabilityPage.groups`,
  and each `DocsNavigationPage.groups`) regardless of which mode renders the
  tree. It's a classification label on the page even when `nav` controls layout.
- **Build-time validation** — even in `nav` mode the build still checks every
  page's frontmatter `group` against the configured `groups` (see below), so a
  populated `groups` list keeps acting as the allow-list for the `group` field.

In short: `nav` is the authoritative, ordered structure for sidebar + agent
outputs when present; `group` is the page-level taxonomy that drives structure
in the absence of `nav`, and otherwise survives as per-page metadata and a
validation allow-list.

## 2. What happens at build time if a page declares an unknown `group` slug

**The build fails.** When `leadtype generate` runs, it resolves the navigation
and inspects the `unknown` bucket — *"Pages that named a group slug not present
in the config."* The first offender aborts the build:

```js
const navigation = await resolveDocsNavigation({ srcDir, groups, nav, mounts, ... });
const firstUnknownGroup = navigation.unknown[0];
if (firstUnknownGroup) {
  throw new Error(
    `${firstUnknownGroup.urlPath} declares unknown group "${firstUnknownGroup.slug}"`
  );
}
```

How a slug ends up in `unknown`: `buildGroupMembership` flattens the configured
groups into a known-slug set, and for each page group slug not in that set it
pushes `{ page, slug }` onto `unknown` (rather than placing the page in a
section). The error is raised once per build for the first such page and is
reported through the normal failure path (the command returns a non-zero exit
code).

This check runs in **both** modes:

- In **`groups` mode**, `unknown` comes directly from the membership pass over
  the configured `groups`.
- In **`nav` mode**, leadtype still validates frontmatter against `config.groups`
  via `findUnknownGroups(docs, config.groups)` and threads the result into the
  navigation's `unknown` array — so an unknown `group` slug is rejected even
  though `nav` (not `groups`) is what actually lays out the sidebar. (If the
  config provides no `groups` at all, `findUnknownGroups` returns an empty list
  and there is nothing to validate against.)

Practical upshot: a typo'd or stale `group:` slug is a hard error, not a silent
"ungrouped" fallback. Note the distinction from *no* group at all — a page with
no `group` frontmatter is simply treated as **ungrouped** (it lands in the
"Other" section), which is fine; the failure is specifically for naming a group
the config doesn't know about. Fix it by either correcting the slug to match a
configured group or adding the group to `groups` in `docs.config.ts`.
