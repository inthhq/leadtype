# leadtype Navigation: `nav` vs. `group` frontmatter

## 1. Relationship between curated `nav` and a page’s legacy `group` frontmatter

- **`nav` drives the sidebar and agent map.**  
  When `docs.config.ts` exports a `nav` array, leadtype builds the entire navigation tree (sidebar, `llms.txt`, `AGENTS.md`, sitemap, etc.) from that curated tree. Pages are included via explicit `pages` entries or glob patterns under each `DocsNavNode`; the page’s frontmatter `group` field is **ignored for navigation grouping** in this mode.

- **`group` frontmatter is fallback taxonomy.**  
  If `nav` is absent, leadtype falls back to the `groups` config and buckets pages by the `group` slug(s) declared in their frontmatter. Even when `nav` is present, the `group` value is still parsed and surfaced in generated page data (for example, the fumadocs adapter exposes it as `groups` in page metadata), so downstream UI code can still filter or label by group if it wants.

- **`groups` config remains fallback navigation metadata.**  
  The `DocsConfig` type comment explicitly states: *“When present, [`nav`] drives docs UI and agent-facing indexes; `groups` remains fallback taxonomy/navigation metadata.”*  If both `nav` and `groups` are configured, leadtype also validates frontmatter `group` slugs against the `groups` array to catch typos.

## 2. Build-time behavior for an unknown `group` slug

If a page declares a `group` slug that does **not** exist in the config’s `groups` array, `leadtype generate` throws a hard error and stops:

```
<urlPath> declares unknown group "<slug>"
```

This happens because `resolveDocsNavigation()` collects unknown slugs in the `unknown` array, and the CLI loop explicitly checks for the first one and throws:

```js
const firstUnknownGroup = navigation.unknown[0];
if (firstUnknownGroup) {
  throw new Error(
    `${firstUnknownGroup.urlPath} declares unknown group "${firstUnknownGroup.slug}"`
  );
}
```

No output is written until the mismatch is fixed.  
*(Note: this validation only runs when the config defines a `groups` array. If the project uses only `nav` with no `groups` config, the legacy `group` frontmatter is not validated against unknown slugs.)*
