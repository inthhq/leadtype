# Leadtype navigation and legacy groups

1. **`nav` is the source of truth when present.** The curated `nav` tree in `docs.config.ts` drives the generated navigation used by the docs UI/sidebar (`resolveDocsNavigation`) and the agent-facing maps/artifacts (`docs/llms.txt`, `AGENTS.md`, agent readability navigation, and ordering in full-context output). In `nav` mode, pages are placed by the explicit `pages`/`include` entries in the nav tree; a page's frontmatter `group:` value does **not** decide where it appears in the sidebar.

   The legacy `group` frontmatter field is still useful as taxonomy/metadata: Leadtype preserves the normalized group slugs on page metadata/manifests for consumers that want to filter or label pages, and a configured `groups` list remains the fallback navigation model when no `nav` is provided. If you keep `groups` alongside `nav`, it also acts as the known legacy taxonomy that Leadtype can validate page `group:` values against.

2. **Unknown configured group slugs fail generation.** During `leadtype generate`, Leadtype resolves navigation before writing the final artifacts. If a page declares `group: some-slug` and that slug is not present in the configured `groups` taxonomy, generation is treated as invalid and exits non-zero with an error like:

   ```text
   /docs/example declares unknown group "some-slug"
   ```

   In other words, a stale or misspelled legacy `group` is not silently used to create a sidebar section; fix the frontmatter slug or add it to `groups` if you still maintain that taxonomy. If a project uses only `nav` and defines no `groups` taxonomy at all, there is no legacy group list to validate against, so placement is governed solely by `nav`.
