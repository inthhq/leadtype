# Navigation in leadtype: `nav` vs. `group`

> Verified against the installed package `leadtype@0.1.2`
> (`node_modules/leadtype/dist/_shared/llm-DbiIv5JE.js` and `dist/cli.js`).

## 1. Curated `nav` vs. legacy `group` frontmatter

These are two **different** ways to organize the same set of MDX pages, and they
are mutually selected — not merged.

### `nav` wins when it exists

Every generator that produces a structured menu — `resolveDocsNavigation`
(the sidebar/runtime manifest), `generateAgentsMd` (the agent map), and the
`/docs/llms.txt` map — runs the same branch:

```js
const hasNav = Boolean(config.nav && config.nav.length > 0);
const resolved = hasNav
  ? resolveNavGroups(config.nav ?? [])   // curated tree
  : resolveGroups(config.groups ?? []);  // legacy group taxonomy
```

So **when `docs.config.ts` declares a non-empty `nav`, the curated `nav` is the
single source of truth** for:

- the docs-site sidebar (`resolveDocsNavigation` → `DocsNavigation`),
- the bundled `AGENTS.md` agent map (`generateAgentsMd`),
- the `/docs/llms.txt` curated map, the `llms-full.txt` page ordering, and the
  agent-readability `sitemap.md`.

Crucially, in `nav` mode the tree is assembled by **path** (`buildNavigationFromNav`):
each `nav` node lists pages by their extensionless path (or `include` globs),
and leadtype resolves those to documents directly. A page's **`group:`
frontmatter is not consulted at all** to decide where it lands in the curated
tree. Any page the `nav` tree never references falls into `navigation.ungrouped`
(rendered under an "Other" heading).

### What `group:` frontmatter is still good for

The `group` field is the older, **frontmatter-driven taxonomy**. When there is
no `nav`, `buildGroupMembership` matches each page's `group:` slug(s) against the
`groups` tree in the config to build the sidebar/agent map — that's its original
job, and it still works as the fallback navigation shape if you don't curate a
`nav`.

Even when `nav` *is* present, `group:` is **not dead weight**:

- It remains valid, validated frontmatter taxonomy/metadata. A page may declare
  one slug (`group: quickstart`) or several (`group: [build, reference]`), and
  those normalized slugs are still surfaced as `page.groups` on every page in
  the navigation manifest and on each `AgentReadabilityPage`. So it stays useful
  as page-level categorization/labeling metadata that tools can read even though
  it no longer drives the curated menu.
- leadtype keeps **validating** `group` against the config's `groups` list even
  in `nav` mode. During generation, `resolveDocsNavigation` is still called with
  *both* `nav` and `groups`, and it runs `findUnknownGroups(docs, config.groups)`
  to populate `navigation.unknown` — i.e. the legacy taxonomy is still policed as
  a correctness/consistency check (see Q2).

**Summary:** the curated `nav` drives the sidebar and the agent map (and all
generated maps) whenever it's present; the legacy `group` frontmatter is the
fallback navigation taxonomy when there's no `nav`, and otherwise lives on as
validated per-page categorization metadata (`page.groups`) plus a build-time
consistency guard.

## 2. What happens if a page declares an unknown `group` slug at build time

**The build fails.** A page's `group:` slug must correspond to a slug declared
in the config's `groups` tree. If it doesn't, the generator throws.

The mechanism:

1. `buildGroupMembership` flattens the known `groups` into a set of slug keys.
   Any page whose `group:` slug isn't in that set is pushed onto an `unknown`
   list (`{ urlPath, slug }`) rather than placed in a group.
2. `resolveDocsNavigation` surfaces that as `navigation.unknown`. This runs
   regardless of whether you use `nav` or `groups`, because in `nav` mode it's
   computed via `findUnknownGroups(docs, config.groups)`.
3. In `runGenerateCommand` (`leadtype generate`, both site and `--bundle`
   modes), right after resolving navigation for each locale:

   ```js
   const firstUnknownGroup = navigation.unknown[0];
   if (firstUnknownGroup) {
     throw new Error(
       `${firstUnknownGroup.urlPath} declares unknown group "${firstUnknownGroup.slug}"`
     );
   }
   ```

   The thrown error is caught by the command's handler, reported via
   `reportFailure`, and the CLI exits with a **non-zero exit code (1)** before
   writing any docs/markdown output.

So a typo or stray slug like `group: quikstart` produces a hard build error
(e.g. `/docs/quickstart declares unknown group "quikstart"`), not a silent
"ungrouped" page.

### Two important nuances

- **Empty / no `group` is fine.** A page with no `group:` (or an empty value)
  is simply treated as *ungrouped* — it goes to `navigation.ungrouped`
  ("Other"). Only a *present-but-unrecognized* slug triggers the error.
- **If the config has no `groups` at all**, `findUnknownGroups` returns an empty
  list (it early-returns when `groups` is missing/empty), so there is nothing to
  validate against and the unknown-group check can't fire. The guard only bites
  when you've declared a `groups` taxonomy and a page references a slug outside
  it. (This is also why a `nav`-only config still benefits from keeping a
  `groups` list: it's what makes the `group:` frontmatter validatable.)
