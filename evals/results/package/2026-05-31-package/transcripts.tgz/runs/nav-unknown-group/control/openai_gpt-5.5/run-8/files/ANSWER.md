# Navigation vs. `group` frontmatter in leadtype

1. A curated `nav` in `docs.config.ts` is the source of truth for navigation when it is present. It drives the generated navigation tree used by the docs UI/sidebar and the agent-facing maps/artifacts (`/docs/llms.txt`, `AGENTS.md`, agent readability navigation, etc.). In that mode, a page's legacy `group` frontmatter does **not** decide where the page appears in the sidebar; pages are placed by `nav` page entries/includes, and pages not referenced by `nav` are treated as ungrouped/"Other".

   The legacy `group` field is still useful as taxonomy/metadata and as the fallback navigation mechanism for projects that do not define `nav`. `group` values are preserved on page metadata, and configured `groups` can still act as the known taxonomy used to validate old frontmatter while a project migrates to curated `nav`.

2. During `leadtype generate`, leadtype resolves the navigation and checks for unknown group slugs before writing the rest of the artifacts. If a page declares a `group` slug that is not in the configured `groups` taxonomy, the CLI fails the build with an error like:

   ```text
   leadtype generate: /docs/some-page declares unknown group "some-slug"
   ```

   Internally, `resolveDocsNavigation()` reports these entries in `navigation.unknown`; the CLI treats the first one as fatal and exits non-zero. If a project uses only `nav` and has no `groups` taxonomy to validate against, `group` no longer drives placement, so there is no known-group list for that legacy field to be checked against.
