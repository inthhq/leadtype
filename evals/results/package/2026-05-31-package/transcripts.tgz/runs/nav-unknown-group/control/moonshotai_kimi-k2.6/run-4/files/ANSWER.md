# leadtype Navigation: `nav` vs. `group`

## 1. What drives the sidebar and agent map?

The **curated `nav` tree in `docs.config.ts`** drives both the sidebar and the agent-facing navigation map.

> "When present, this drives docs UI and agent-facing indexes; `groups` remains fallback taxonomy/navigation metadata."
> — `DocsConfig` type definition in `leadtype/dist/llm/index.d.ts`

A page's legacy **`group` frontmatter field** is the fallback. It is still useful for three things:

1. **Fallback navigation** — When `nav` is absent, pages are grouped by matching their frontmatter `group` slug against the `groups` array in the config.
2. **Consumer metadata** — `leadtype` still reads `group` into page metadata (e.g. `meta.groups` from `createDocsSource`), so UI adapters such as the fumadocs integration can filter or group pages by it.
3. **Config inference** — If you omit `groups` from the config entirely, `leadtype` scans all frontmatter `group` values and infers the group list automatically.

## 2. What happens if a page declares an unknown `group` slug?

The build **fails with a hard error**.

After resolving navigation, the pipeline checks for pages whose frontmatter `group` does not match any slug known to the config. The first offending page triggers an error like:

```
/docs/getting-started declares unknown group "internals"
```

This is enforced in both modes:

- **`groups`-driven mode** — `buildGroupMembership` collects mismatches into `navigation.unknown`.
- **`nav`-driven mode** — `findUnknownGroups` validates frontmatter `group` values against `config.groups` and also populates `navigation.unknown`.

The CLI (`leadtype generate`) then explicitly throws:

```js
const firstUnknownGroup = navigation.unknown[0];
if (firstUnknownGroup) {
  throw new Error(
    `${firstUnknownGroup.urlPath} declares unknown group "${firstUnknownGroup.slug}"`
  );
}
```

The only way to avoid this is to either (a) add the slug to `config.groups`, (b) remove it from the page's frontmatter, or (c) omit `config.groups` entirely so leadtype infers the groups from the frontmatter.
