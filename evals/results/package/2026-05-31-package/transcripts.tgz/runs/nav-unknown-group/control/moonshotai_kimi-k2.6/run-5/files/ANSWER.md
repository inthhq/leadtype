# Nav vs. Legacy `group` Frontmatter

## 1. Which one drives the sidebar and agent map?

The curated **`nav`** tree in `docs.config.ts` wins whenever it is present.

- **`nav`** is the explicit, author-facing navigation tree. It determines exactly which pages appear where in the sidebar, sitemap, `AGENTS.md`, `llms.txt`, and every other agent-facing index.
- The page-level **`group`** frontmatter field is the legacy assignment mechanism. When `nav` is present, `group` is **ignored for placement**.

From the leadtype source (`DocsConfig`):

> *"Curated navigation for the single-collection shape. When present, this drives docs UI and agent-facing indexes; `groups` remains fallback taxonomy/navigation metadata."*

**What the legacy `group` field is still good for:**

1. **Fallback taxonomy / metadata** – the value is still parsed and stored in the page’s `groups` array, so older consumers or custom transformers can read it.
2. **Validation** – if the config also defines a `groups` array, the build cross-checks every frontmatter `group` against that list and fails on unknown slugs (see below).
3. **Backward compatibility** – if you ever remove `nav`, the docs automatically fall back to being organized by `group` + config `groups`.

## 2. What happens at build time for an unknown `group` slug?

If a page declares a `group` slug that the config does **not** know about, `leadtype generate` treats it as a **hard error**.

During the build, `resolveDocsNavigation()` collects every mismatch into `navigation.unknown`:

```ts
type DocsNavigation = {
  groups: DocsNavigationGroup[];
  ungrouped: DocsNavigationPage[];
  /** Pages that named a group slug not present in the config. */
  unknown: { urlPath: string; slug: string }[];
};
```

The CLI then immediately throws on the first unknown entry (`dist/cli.js`):

```js
const firstUnknownGroup = navigation.unknown[0];
if (firstUnknownGroup) {
  throw new Error(
    `${firstUnknownGroup.urlPath} declares unknown group "${firstUnknownGroup.slug}"`
  );
}
```

**Result:** the build exits non-zero with a message like:

```
/docs/getting-started declares unknown group "missing-slug"
```

It does **not** silently drop the page, auto-create a group, or place it in `ungrouped`.
