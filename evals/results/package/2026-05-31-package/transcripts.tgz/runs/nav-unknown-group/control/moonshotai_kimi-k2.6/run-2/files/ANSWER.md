# Navigation in leadtype: `nav` vs. frontmatter `group`

## 1. Which one drives the sidebar and agent map?

**The curated `nav` tree in `docs.config.ts` wins whenever it is present.**

- `nav` is the “preferred” navigation driver. When `nav` is configured, leadtype uses it to build the sidebar, agent-readable indexes (`llms.txt`, `AGENTS.md`, `agent-readability.json`), and full-context bundles. Pages are slotted into nav nodes by the `pages` array on each node (explicit paths or glob patterns), not by frontmatter.
- The page frontmatter `group` field is **fallback taxonomy**. When `nav` is absent, leadtype falls back to the config `groups` array and assigns pages to groups based on their frontmatter `group:` slugs. 

### What the frontmatter `group` is still good for

Even when `nav` drives the tree, `groups` (and the frontmatter `group` field) are not dead code:

- **Validation.** If you define both `nav` and `groups` in `docs.config.ts`, leadtype still validates every page’s frontmatter `group` values against the known `groups` list. This catches typos or stale group slugs at build time.
- **Fallback metadata.** If you later remove `nav` or a framework adapter falls back to group-based rendering, the frontmatter `group` values are still meaningful.
- **Consumer filtering.** Some framework adapters (e.g. `leadtype/fumadocs`) expose `groups` on page metadata so sidebars can filter or annotate pages even when the primary tree comes from `nav`.

## 2. What happens at build time if a page declares an unknown `group`?

**The build fails with a hard error.**

During `leadtype generate`, the pipeline calls `resolveDocsNavigation()` before emitting any artifacts. If a page’s frontmatter declares a `group` slug that does not exist in the config’s `groups` array, the navigation result contains an `unknown` entry. The CLI then throws:

```
<urlPath> declares unknown group "<slug>"
```

For example:

```
/docs/features/auth declares unknown group "authenication"
```

This error aborts generation with exit code `1`. There is no silent fallback to “ungrouped” — leadtype treats an unknown group slug as a configuration mismatch that must be fixed (either add the group to `docs.config.ts` or correct the frontmatter typo).
