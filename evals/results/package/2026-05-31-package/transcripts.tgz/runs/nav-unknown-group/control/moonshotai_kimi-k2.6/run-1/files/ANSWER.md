# Nav vs. `group` frontmatter in leadtype

## 1. Which drives the sidebar and agent map?

**`nav` in `docs.config.ts` wins.**

- When `nav` is present (non-empty), it is the curated navigation tree that **drives the sidebar and all agent-facing indexes** (`llms.txt`, `AGENTS.md`, sitemap, search ordering, etc.).
- The page frontmatter field `group` is then **legacy fallback taxonomy**. It is still read and used for two things:
  1. **Validation** — if the config also defines `groups`, leadtype checks every page’s `group` slugs against that list. Any mismatch is treated as an error (see #2).
  2. **Fallback navigation** — if `nav` is omitted, the sidebar/agent map falls back to the `groups`-driven model, where pages are bucketed by the slugs they declare in frontmatter `group:`.

In short: `nav` drives the UI; `group` frontmatter is the old automatic-bucket system that only takes over when `nav` is absent.

## 2. What happens at build time for an unknown `group` slug?

**The build fails with a hard error.**

During `leadtype generate`, the pipeline resolves navigation and collects any pages whose frontmatter `group` slug does not exist in the configured group list into `navigation.unknown`. The CLI then explicitly checks:

```js
const firstUnknownGroup = navigation.unknown[0];
if (firstUnknownGroup) {
  throw new Error(
    `${firstUnknownGroup.urlPath} declares unknown group "${firstUnknownGroup.slug}"`
  );
}
```

So if a page declares `group: "magic"` but `"magic"` is not defined in `docs.config.ts` `groups` (and was not inferred), the build stops and emits something like:

```
/docs/features/wand declares unknown group "magic"
```

This is true whether you are using `groups`-only navigation or `nav`-based navigation with an explicit `groups` array for validation. If you rely entirely on `nav` with no `groups` config, there is no list to validate against and this error cannot occur.
