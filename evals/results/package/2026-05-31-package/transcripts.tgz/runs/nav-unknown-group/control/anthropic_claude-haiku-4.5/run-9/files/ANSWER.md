# Navigation in Leadtype Projects

## 1. The Relationship Between `nav` and Legacy `group` Frontmatter

### Which One Drives the Sidebar and Agent Map?

**The curated `nav` in `docs.config.ts` is the primary driver** of the sidebar, agent indexes, and `AGENTS.md` generation when present. According to the type definitions and CLI logic in the leadtype package:

- **`nav` (DocsNavNode[])**: The curated navigation tree drives:
  - Sidebar/UI navigation structure  
  - `llms.txt` and `llms-full.txt` section organization
  - `AGENTS.md` generation (bundled agent docs)
  - Agent readability artifact generation (sitemap.xml, sitemap.md, robots.txt)

- **`groups` (DocsGroup[])**: The hierarchical group taxonomy still provides:
  - A fallback taxonomy when `nav` is not present
  - Metadata for sidebar ordering within groups
  - Configuration validation and navigation structure when `nav` is omitted

### What Is the Legacy `group` Frontmatter Field Still Good For?

Pages declare their group membership via the **`group` frontmatter field** (a string or array of strings), which:

1. **Associates pages with configured groups** — this allows the navigation resolver to organize pages into the group hierarchy, creating the `DocsNavigation` structure with `.groups` and `.ungrouped` arrays.

2. **Enables sidebar ordering** — pages can set an `order:` frontmatter field to control sidebar position within a group (explicit orders sort first, then alphabetically by URL path).

3. **Drives group-based filtering** — when `nav` is used, the `group` field is still present on pages for runtime queries and filtering, even though `nav` controls the *displayed* structure.

The key insight: **`nav` controls the *curated presentation* to users and agents**, while **`group` records the *semantic classification* of pages**. Both coexist in the resolved navigation output:

```typescript
type DocsNavigation = {
  groups: DocsNavigationGroup[];    // Organized by nav structure
  ungrouped: DocsNavigationPage[];  // Pages outside any group
  unknown: { urlPath: string; slug: string }[];  // Pages with invalid groups
};
```

---

## 2. What Happens at Build Time When a Page Declares an Unknown Group

**The build fails with an error.**

When `leadtype generate` runs, it validates that every page's `group` frontmatter values match a slug in the configured `groups` or `nav` structure. The validation occurs in the CLI's `runGenerateCommand`:

```javascript
// From node_modules/leadtype/dist/cli.js (line ~1351–1355)
const firstUnknownGroup = navigation.unknown[0];
if (firstUnknownGroup) {
  throw new Error(
    `${firstUnknownGroup.urlPath} declares unknown group "${firstUnknownGroup.slug}"`
  );
}
```

### The Validation Flow

1. **Navigation resolution** calls `resolveDocsNavigation()` to walk the docs tree
2. **Group membership mapping** collects all `group` frontmatter values from pages
3. **Unknown group detection** compares declared groups against the configured group slugs
4. **Build failure** if any page declares a group slug not present in the config

The `unknown` array in `DocsNavigation` is built during navigation resolution and contains entries like:

```typescript
{ urlPath: "/docs/my-page", slug: "typo-group" }
```

**This is intentional:** Leadtype treats unknown groups as a hard error to prevent:
- Typos in group slugs that would silently orphan pages
- Pages referencing deleted or renamed groups
- Configuration drift between pages and the nav/groups config

**To fix:** Either:
1. Add the missing group slug to `groups` or `nav` in `docs.config.ts`
2. Correct the `group:` value in the page's frontmatter
3. Remove the `group:` field entirely if the page should be ungrouped
