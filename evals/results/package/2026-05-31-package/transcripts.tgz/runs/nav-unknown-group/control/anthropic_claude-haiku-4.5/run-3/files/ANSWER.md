# Leadtype Navigation: `nav` Config vs `group` Frontmatter

## 1. Relationship Between `nav` Config and `group` Frontmatter

### What Drives Sidebar and Agent Map

**The curated `nav` in `docs.config.ts` drives the sidebar and agent map.** This is the author-facing navigation tree that controls what users and agents see. It's the preferred, modern approach.

**The legacy `group` frontmatter field is still good for taxonomy/categorization metadata.** Pages declare their group membership via frontmatter (`group: <slug>` or `group: [a, b]`), which gets parsed into the `groups` array in the resolved navigation. This serves as a fallback metadata layer.

Here's how they interact according to the leadtype type definitions:

- **`nav` (curated):** Defined in `docs.config.ts` as an array of `DocsNavNode` objects with `title`, optional `slug`, optional `description`, optional `base`, `pages`, and `children`. This tree is the single source of truth for docs UI structure and agent-readable indexes (like `llms.txt`, `AGENTS.md`, and agent readability manifests).

- **`group` (legacy):** Pages declare group membership in their frontmatter. This field is optional (a page can have `group: <slug>`, multiple groups as `group: [slug1, slug2]`, or no group at all). The resolved `groups` array ends up in `DocsPageMeta`, and all groups are enumerated in the navigation result's `DocsNavigationGroup[]` and `ungrouped` arrays.

### Why Both Exist

The config type definition shows both fields are optional:

```typescript
type DocsConfig = {
  // ...
  groups?: DocsGroup[];        // Legacy taxonomy tree
  nav?: DocsNavNode[];         // Preferred curated navigation
  // ...
}
```

The comment in the source code clarifies the intent:

> Top-level navigation for the single-collection shape. Mutually exclusive with `collections`. Pages declare which group they belong to via MDX frontmatter (`group: <slug>` or `group: [a, b]`).

And for `nav`:

> Curated navigation for the single-collection shape. When present, this drives docs UI and agent-facing indexes; `groups` remains fallback taxonomy/navigation metadata.

**In summary:**
- **`nav` drives the sidebar and agent map** because it's the authoritative navigation structure consumed by `generateLlmsTxt()`, `generateAgentsMd()`, `generateAgentReadabilityArtifacts()`, and `resolveDocsNavigation()`.
- **`group` is still good for:** metadata tagging, backward compatibility, and as a fallback when `nav` is absent.

---

## 2. What Happens at Build Time When a Page Declares an Unknown Group

**The unknown group is tracked but does not cause a build failure.** Instead, the `resolveDocsNavigation()` function and related generation functions record it in the `unknown` array of the `DocsNavigation` result.

### Build Behavior

From the `DocsNavigation` type definition:

```typescript
type DocsNavigation = {
  groups: DocsNavigationGroup[];
  ungrouped: DocsNavigationPage[];
  /** Pages that named a group slug not present in the config. */
  unknown: {
    urlPath: string;
    slug: string;
  }[];
  locale?: string;
};
```

This design allows the build to:

1. **Complete successfully** even if a page references a non-existent group slug (e.g., `group: future-section` when `future-section` is not in the config).
2. **Collect and report unknowns** in the navigation manifest so you can inspect them programmatically (useful for CI checks or post-build validation).
3. **Isolate unknown pages** from the structured group hierarchy, preventing crashes in downstream code that expects group metadata to exist.

### Why This Approach

This is intentional by design: leadtype's generation pipeline (driven by `resolveDocsNavigation` with curated `nav` or fallback `groups`) treats the frontmatter `group` field as optional metadata. If a page declares a group that the config doesn't know about, the page still renders and is accessible, but it's flagged as `unknown` in the navigation result rather than silently dropped or causing an error.

If you want to enforce strict group validation, you would:
- Use the `leadtype lint` CLI or `lintDocs()` function to check for unknown group references before build time.
- Add a post-build check that inspects the navigation result and fails the build if the `unknown` array is non-empty.

The leadtype source does not raise an error at build time for unknown groups—it leaves that decision to the consuming build pipeline.
