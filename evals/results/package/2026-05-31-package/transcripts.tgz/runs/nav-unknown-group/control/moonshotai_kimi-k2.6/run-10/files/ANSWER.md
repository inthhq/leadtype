# Navigation: `nav` vs. `group`

## 1. Which one drives the sidebar and agent map?

**The curated `nav` tree in `docs.config.ts` is the source of truth.**
When `nav` is present, leadtype uses it exclusively to build the sidebar, the agent-readable navigation map (`llms.txt`, `AGENTS.md`, sitemaps), and the runtime navigation manifest.

The page-level `group` frontmatter field is the **legacy** mechanism. It remains useful as fallback taxonomy / navigation metadata:

- **No `nav` configured:** `groups` (defined in config and populated by matching `group` frontmatter) drives the entire sidebar and agent indexes.
- **Validation:** If both `nav` and `groups` are defined, leadtype still checks every `group` frontmatter value against the known `groups` slugs. A mismatch is reported as a build error.
- **Inference:** When no config file exports groups or nav, leadtype infers the group list by collecting all `group` values found in frontmatter.
- **Framework adapters:** Adapters such as `leadtype/fumadocs` expose the `groups` array on page metadata so consumer sidebars can still filter or cluster pages by legacy group slugs.

In short: **`nav` drives the sidebar and agent map; `group` frontmatter is fallback taxonomy that is still validated and exposed to adapters.**

## 2. What happens at build time if a page declares an unknown `group` slug?

During `leadtype generate`, the pipeline resolves the navigation and inspects the `navigation.unknown` array.

If a page declares a `group` slug that is **not** defined in the config’s `groups` array (and was not inferred from the filesystem), the build **fails with a hard error**:

```
<urlPath> declares unknown group "<slug>"
```

For example:

```
/docs/getting-started/migration.mdx declares unknown group "legacy"
```

This error is thrown before any artifacts are written, causing the process to exit non-zero.

> **Exception:** If the config defines **only** `nav` and omits `groups` entirely, the unknown-group check is skipped. In that mode, arbitrary `group` frontmatter values are silently ignored because `nav` already dictates the structure.
