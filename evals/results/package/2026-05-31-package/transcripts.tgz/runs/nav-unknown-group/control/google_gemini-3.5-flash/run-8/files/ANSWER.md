# Navigation and Grouping in Leadtype

Below are the answers regarding the relationship between the curated `nav` and the page-level `group` frontmatter, along with the build-time validation behavior.

---

### 1. Relationship Between Curated `nav` and Legacy `group` Frontmatter

#### Which one drives the sidebar and agent map?
When defined in `docs.config.ts`, **the curated `nav` configuration completely drives the sidebar, navigation summaries, and agent map.**
Specifically, if `config.nav` is configured, it is processed via `resolveNavGroups()` to construct the navigation tree. This tree directly powers:
- The website's sidebar navigation (and integration adapters like `leadtype/fumadocs`).
- The offline agent-readable map (`AGENTS.md` and `docs/llms.txt`).
- The `agent-readability.json` manifest.
- The sitemaps (`sitemap.xml` and `sitemap.md`).
- The compilation order for full-context files (`llms-full.txt`).

When `nav` is active, a page's individual `group` frontmatter property is **ignored** for determining the structural layout of the navigation because page paths or glob patterns listed under `nav[].pages` explicitly govern where pages belong in the curated hierarchy.

#### What is the other still good for?
Even when a curated `nav` is defined, the page-level `group` frontmatter (which gets parsed into each document's `groups` array) is still valuable for:

1. **Automatic Navigation Fallback**: If no curated `nav` is declared in `docs.config.ts`, the navigation engine automatically falls back to constructing the sidebar and agent maps by grouping files according to their `group` frontmatter values combined with the `groups` list inside the configuration (using `resolveGroups()` and `buildGroupMembership()`).
2. **Build-Time Frontmatter Validation / Linting**: If `config.groups` is defined in the configuration, `leadtype` will parse pages' `group` frontmatter properties and validate them against the configured group list (via `findUnknownGroups`). This flags typos and prevents stale or invalid group tags from lingering in your source files.
3. **Dynamic Client-Side UI & Filtering**: Each document object (`doc` / `meta`) exposed by the source loader (e.g. `createDocsSource()` or Next.js loader) retains the `groups` array from its frontmatter. This allows custom client-side components to filter, search, or label pages dynamically based on this frontmatter taxonomy independently of the primary `nav` structure.

---

### 2. Build-Time Behavior for Unknown `group` Slugs

At build time (during the execution of `leadtype generate`), the compiler runs a validation loop for each configured locale to ensure navigation consistency. 

If any page declares a `group` frontmatter value that is not recognized in `docs.config.ts` (i.e. not defined under `config.groups`), the following happens:

1. The page and its unknown group slug are collected into a list of unrecognized groups (`navigation.unknown`).
2. If this list contains any entries, the first offending entry is retrieved (`navigation.unknown[0]`).
3. The build process immediately **aborts and throws a hard error**:
   ```javascript
   throw new Error(`${firstUnknownGroup.urlPath} declares unknown group "${firstUnknownGroup.slug}"`);
   ```
4. This prints the error description to `stderr`, halts downstream asset generation (such as converting MDX, writing sitemaps, or compiling search indices), and exits the command with a non-zero exit code (`1`).
