# Navigation in Leadtype: `nav` vs. `group` Frontmatter

## Question 1: The Relationship Between Curated `nav` and Legacy `group` Frontmatter

### Which drives the sidebar and agent map?

**The curated `nav` in `docs.config.ts` drives the sidebar and agent map** when present. It is the authoritative source for the navigation structure and determines what appears in:
- `/docs/llms.txt` (docs navigation summary)
- `/docs/agent-readability.json` (agent navigation manifest)
- `AGENTS.md` (bundled offline docs index)
- `sitemap.md` and `sitemap.xml`

The `nav` config is "preferred over `groups`" in all artifact generation code, as seen throughout the leadtype library types and implementation.

### What is `group` frontmatter still good for?

The legacy `group:` frontmatter field remains useful for **metadata and fallback taxonomy**:

1. **Fallback grouping**: When a `nav` config is not present, `group:` directly drives navigation instead, and pages declare their membership via frontmatter.

2. **Documentation and intent**: The `group:` field tells readers (humans and agents) which logical collection a page belongs to, even if that group is not reflected in the curated navigation.

3. **Validation and discoverability**: If a page declares `group: api-reference` in frontmatter but your config doesn't define that group, leadtype tracks it in the `unknown` field of the navigation manifest (see Question 2).

### How they interact

- **With `nav` present**: The `nav` tree completely reshapes navigation output. Pages are included/excluded and ordered based on what the `nav` config specifies. The `group` field becomes metadata—stored in page objects and included in artifacts, but not structuring the navigation tree.
- **Without `nav`**: Pages self-organize using their `group:` field. The `groups:` tree in config provides the navigation structure.

**Key principle**: When both exist, `nav` wins for navigation structure, but `group` frontmatter still annotates every page with its logical group membership for agent/human context.

---

## Question 2: Build-Time Behavior When a Page Declares an Unknown Group Slug

### What happens

If a page's frontmatter declares `group: some-unknown-slug` and `some-unknown-slug` is not defined in your config's `groups` tree, **the build does not fail**. Instead:

1. **The page is placed in `ungrouped`** — it will not appear under any group in navigation output.

2. **The unknown group is tracked** in a special `unknown` array within the navigation manifest (`DocsNavigation.unknown`), recording:
   - The page's `urlPath`
   - The unknown `slug` that was declared

3. **The unknown entry is included in all downstream artifacts**:
   - `/docs/agent-readability.json` — the manifest contains the `unknown` array
   - Navigation functions return it for runtime inspection
   - Linting tools can optionally warn (but don't error)

### The tracking mechanism

In the leadtype source code (`buildGroupMembership` function):

```javascript
function buildGroupMembership(pages, resolved) {
  const all = flattenGroups(resolved);
  const known = new Map(all.map((g) => [g.slugKey, g]));
  const byGroupSlug = new Map();
  const ungrouped = [];
  const unknown = [];
  
  for (const page of ordered) {
    if (page.groups.length === 0) {
      ungrouped.push(page);
      continue;
    }
    let matchedAny = false;
    for (const slug of page.groups) {
      const slugKey = slug.toLowerCase();
      if (!known.has(slugKey)) {
        unknown.push({ page, slug });  // ← Unknown group recorded here
        continue;
      }
      // Known group: add to byGroupSlug
    }
    if (!matchedAny) {
      ungrouped.push(page);
    }
  }
  return { byGroupSlug, ungrouped, unknown };
}
```

The `unknown` array is then passed through to the navigation manifest and available for agents and tooling to report or act on.

### Practical implications

- **Silent but tracked**: The build succeeds, but the page is not in any group. Use the `unknown` array to:
  - Generate lint warnings in your CI/CD
  - Alert via logging that pages are orphaned
  - Implement custom validation rules
  
- **When using `nav`**: If you're using the curated `nav` config, the `group` field on pages becomes pure metadata and unknown groups are **not validated** — `nav` config determines inclusion/structure entirely.

- **When using `groups` only**: Unknown groups cause pages to become ungrouped, which is usually unintended and should be caught via linting or CI validation.

---

## Summary Table

| Aspect | `nav` (curated) | `group` (frontmatter) |
|--------|-----------------|----------------------|
| **Drives navigation structure** | ✅ Yes (when present) | ❌ No (if `nav` exists) |
| **Controls sidebar layout** | ✅ Yes | ❌ No |
| **Controls agent-readability manifest** | ✅ Yes (navigation tree) | ❌ Becomes metadata |
| **Metadata for agents** | ✅ Implicit in nav tree | ✅ Explicit field |
| **Unknown slug handling** | Config-complete validation ignored | Pages tracked in `unknown` |
| **Use case** | Production docs sites | Self-organizing doc sets, agent context |

---

## References

The behavior is defined in:
- **leadtype/dist/llm/readability.d.ts**: `DocsNavigation` type with `unknown` field
- **leadtype/dist/_shared/llm-DbiIv5JE.js**: `buildGroupMembership()` function (lines 565–595) which populates `unknown`
- **leadtype/dist/index.d.ts**: Type definitions for `DocsConfig`, showing `nav` as "preferred over `groups`"
