# Navigation System in leadtype

## 1. Relationship between curated `nav` and legacy `group` frontmatter

### Which drives the sidebar and agent map?

**The curated `nav` in `docs.config.ts` drives the sidebar and agent map.** When `nav` is present, it is the authoritative source for docs UI and agent-facing indexes.

### What is the `group` frontmatter still good for?

The legacy `group` frontmatter field (pages declare `group: <slug>` or `group: [a, b]` in frontmatter) serves as a **fallback taxonomy/navigation metadata** when `nav` is not provided. This allows:

- **Pages without curated navigation**: When you omit the `nav` configuration from your `docs.config.ts`, pages can still declare their logical group membership via frontmatter, and leadtype will construct a basic navigation tree from those groups.
- **Grouping metadata preserved**: Even when `nav` is present and drives the UI, the `group` frontmatter is preserved in the page metadata and available to framework adapters that need to query "which groups does this page belong to?"
- **Backward compatibility**: The `group` field allows docs to remain portable across different nav configurations.

**Key insight**: The type definitions show that:
- `nav?: DocsNavNode[]` is described as "**Curated navigation for the single-collection shape. When present, this drives docs UI and agent-facing indexes; `groups` remains fallback taxonomy/navigation metadata.**"
- Both functions like `generateLlmsTxt`, `resolveDocsNavigation`, and `generateAgentsMd` accept both parameters, with comments like "Curated navigation tree. **Preferred over `groups` when present.**"

## 2. Build-time behavior for undeclared `group` slugs

When a page declares a `group` slug that the config doesn't know about, **the page is tracked as "unknown" in the navigation manifest but does not cause a build failure**.

### What happens specifically:

1. **Silent categorization**: The page is added to the `unknown` array within the `DocsNavigation` structure:
   ```typescript
   type DocsNavigation = {
     groups: DocsNavigationGroup[];
     ungrouped: DocsNavigationPage[];
     /** Pages that named a group slug not present in the config. */
     unknown: {
       urlPath: string;
       slug: string;
     }[];
     locale?: string;
   };
   ```

2. **No validation error**: The leadtype lint system does **not** produce a lint violation for unknown group slugs. The frontmatter schema accepts `group` as a string or array of strings without enforcing that those slugs exist in the configured groups.

3. **Navigation is still generated**: The page remains discoverable:
   - It appears in the flat page list (`pages`) in the agent readability manifest
   - It's included in search indexes
   - It's present in sitemap generation

4. **Fallback behavior**: Pages with unknown groups are essentially **treated as if they have no group assignment** in the hierarchy — they won't appear under any group section in navigation trees that rely on the configured group structure.

### Why this design?

This permissive approach allows:
- **Decoupled content and config**: Pages can be created with group metadata without requiring the group to exist in the config first.
- **Migration flexibility**: You can add pages with forward-declared group slugs, then add those groups to the config later.
- **Linting at sync point**: The `lintDocs()` function validates **page content** (frontmatter syntax, internal links) separately from **navigation validation**, which happens at generation time.
