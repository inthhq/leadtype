# Leadtype navigation: `nav` vs. legacy `group`

1. **`nav` is the source of truth when it is present.** The curated `nav` tree in `docs.config.ts` drives the docs UI/sidebar navigation and the agent-facing maps/indexes such as `docs/llms.txt`, `AGENTS.md`, and agent readability navigation. In that mode, pages are placed by the paths/includes listed in `nav`, not by their frontmatter `group` value.

   The page-level `group` frontmatter is still useful as legacy/fallback taxonomy metadata: it is exposed on page metadata, can be used by consumers for filtering or categorization, and is what Leadtype uses to build navigation if you do **not** provide a curated `nav` and instead rely on configured `groups`.

2. **Unknown configured group slugs fail generation.** During `leadtype generate`, Leadtype resolves navigation and checks page `group` declarations against the configured `groups` taxonomy. If a page declares a slug that is not known there, generation stops before writing the normal artifacts with an error like:

   ```text
   /docs/some-page declares unknown group "missing-slug"
   ```

   Note the distinction: with curated `nav`, the `nav` entries still decide sidebar/agent-map placement. The unknown-group check is against the legacy `groups` taxonomy, not against `nav` section slugs. If a project is truly nav-only and has no `groups` taxonomy to validate against, the legacy `group` field does not drive navigation and this particular unknown-group validation has nothing to compare it to.
