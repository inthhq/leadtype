# Navigation and Group Frontmatter in Leadtype

Here are the answers to your onboarding questions about leadtype's navigation mechanics and build-time validation behavior.

---

### 1. Relationship Between Curated `nav` and Legacy `group` Frontmatter

#### **Which one drives the sidebar and agent map?**
* **The Curated `nav` in `docs.config.ts`** drives the docs UI (sidebar) and the agent-facing indexes/maps (including sitemaps, readability manifests, full-context lists, and `/docs/llms.txt`) when present. It represents an author-configured hierarchy (`DocsNavNode[]`) and is preferred over fallback systems.

#### **What is the other (`group` frontmatter/`groups` config) still good for?**
* **Fallback Navigation (when `nav` is omitted):** If no curated `nav` is defined in `docs.config.ts`, `leadtype` falls back to the configured `groups` tree. In this fallback mode, pages are organized in the sidebar automatically based on their frontmatter `group` slug(s).
* **Taxonomy and Logical Categorization:** Even with a curated `nav` in place, the page's `group` frontmatter remains the source of truth for the document's taxonomic metadata.
* **Build-Time Integrity Checks:** The `group` declarations continue to be parsed and validated during builds. This ensures that every page maps to a known taxonomical bucket, preventing orphaned, misclassified, or typo-ridden pages in the codebase.

---

### 2. What Happens at Build Time with an Unknown `group` Slug?

At build time (during `leadtype generate`), `leadtype` runs a validation pass over all pages to ensure reference integrity across your documentation:

1. **Detection:** The generator calls `resolveDocsNavigation()`, which maps page metadata against the configured group structure and populates an list of unknown groups.
2. **Build Failure:** If any page declares a `group` slug in its frontmatter that does not exist in the configured `groups` list (or in inferred collection groups), the build pipeline **throws a hard error** and immediately aborts.
3. **Error Output:** The error message specifies the exact URL path of the offending page and the invalid group slug:
   ```text
   Error: <page-urlPath> declares unknown group "<unknown-slug>"
   ```

This prevents broken links, misorganized documentation, or silent omissions from being deployed to production.
