# Leadtype navigation: `nav` vs. `group`

1. **`nav` is the source of truth when it is present.** The curated `nav` tree in `docs.config.ts` drives the generated docs navigation/sidebar manifest and the agent-facing maps/indexes (`docs/llms.txt`, `AGENTS.md`, agent-readability navigation, etc.). In this mode, pages appear where `nav.pages` / `nav.include` puts them; their legacy frontmatter `group:` value does not decide sidebar placement.

   The legacy `group` frontmatter is still useful as fallback taxonomy/navigation metadata: projects without `nav` can have sidebars/agent maps built from configured `groups`, pages still expose their `groups` metadata to adapters/runtime code, and a configured `groups` list can still act as the vocabulary Leadtype validates page `group:` values against.

2. **An unknown configured-group slug fails generation.** During `leadtype generate`, Leadtype resolves navigation before converting/writing artifacts. If it finds a page whose frontmatter declares a `group` slug that is not in the configured `groups` tree, generation stops with an error like:

   ```text
   /docs/some-page declares unknown group "missing-slug"
   ```

   With a curated `nav`, this validation is separate from sidebar placement: `nav` still controls placement, but any supplied `groups` config is used to validate legacy `group:` slugs. If a project is truly `nav`-only and supplies no `groups` vocabulary, there is no group list to validate against, so `group:` does not drive navigation and unknown-group validation has nothing to compare to.
