# Navigation in leadtype: `nav` vs. `group`

These answers are grounded in the installed `leadtype` package (`node_modules/leadtype`),
specifically the navigation pipeline in `dist/_shared/llm-DbiIv5JE.js` and the
`generate` command in `dist/cli.js`. The relevant types are documented in
`dist/llm/index.d.ts`.

## 1. Relationship between curated `nav` and a page's `group` frontmatter

**The curated `nav` tree in `docs.config.ts` is the source of truth when it
exists, and it drives both the sidebar and the agent-facing map.** A page's
legacy `group:` frontmatter is the older taxonomy mechanism; it only *drives*
navigation as a fallback when no `nav` is configured.

### Which one wins

Every generator (`resolveDocsNavigation`, `generateAgentsMd`, `generateLlmsTxt`,
`generateLLMFullContextFiles`, `generateAgentReadabilityArtifacts`) makes the
same decision:

```js
const hasNav = Boolean(config.nav && config.nav.length > 0);
const resolved = hasNav
  ? resolveNavGroups(config.nav ?? [])     // curated tree
  : resolveGroups(config.groups ?? []);    // group taxonomy + frontmatter
```

- **With `nav` present** the navigation is built by `buildNavigationFromNav`,
  which places pages by *explicit path references* (`pages: ["quickstart", …]`)
  and include globs (`{ include: "reference/*" }`) declared in the tree — not by
  each page's `group:` value. This single tree feeds:
  - the docs UI sidebar (via the `DocsNavigation` returned by
    `resolveDocsNavigation`, which build pipelines typically write to something
    like `docs-nav.json`),
  - the agent map: `AGENTS.md`, `/docs/llms.txt`, `llms-full.txt` ordering, and
    the `agent-readability.json` / `sitemap.md` manifests.
  This is exactly what the type docs mean by *"When present, this drives docs UI
  and agent-facing indexes; `groups` remains fallback taxonomy/navigation
  metadata."*

- **With no `nav`** (only `groups`), `buildGroupMembership` buckets each page
  into a group by matching the page's frontmatter `group:` slug(s) against the
  configured `groups` slugs. Here `group:` is what actually positions a page in
  the sidebar and agent map.

### What the other one is still good for

Even when `nav` drives everything, the `group:` frontmatter and the `groups`
config are **not dead**:

- **`group:` stays as per-page taxonomy metadata.** It is normalized into
  `doc.groups` (`normalizeGroupValue`) and carried through to every consumer:
  `pageView(...)` keeps `groups: [...doc.groups]` on each nav page, and
  `toAgentReadabilityPage(...)` emits `groups` into `agent-readability.json`. So
  it remains useful for tagging, faceting/filtering, search, and "related by
  group" features that are independent of sidebar position.
- **`groups` config stays as a validation taxonomy.** When `nav` is active, the
  build still calls `findUnknownGroups(docs, config.groups)` so the set of legal
  `group:` slugs is enforced (see Q2). It is the canonical list of allowed group
  slugs and their titles/descriptions, even though it no longer dictates order.

In short: `nav` = curated structure/ordering (sidebar + agent map); `group:` =
durable per-page classification + a checked vocabulary.

## 2. What happens at build time for an unknown `group` slug

**The build fails (non-zero exit) with an explicit error naming the page and the
offending slug.**

During `leadtype generate`, after computing navigation for each locale, the CLI
checks the `unknown` list returned by `resolveDocsNavigation`:

```js
const navigation = await resolveDocsNavigation({ srcDir, groups, nav, mounts, ... });
const firstUnknownGroup = navigation.unknown[0];
if (firstUnknownGroup) {
  throw new Error(
    `${firstUnknownGroup.urlPath} declares unknown group "${firstUnknownGroup.slug}"`
  );
}
```

The `unknown` entries are produced by `buildGroupMembership`, which walks the
flattened, resolved `groups` and records any page whose `group:` slug is not in
that known set:

```js
const slugKey = slug.toLowerCase();
if (!known.has(slugKey)) {
  unknown.push({ page, slug });   // → navigation.unknown
  continue;
}
```

Notes:

- This validation runs **whether you use `nav` or `groups`.** With `nav`,
  `findUnknownGroups(docs, config.groups)` re-derives membership against the
  `groups` taxonomy specifically to populate `navigation.unknown`, so a stray
  `group:` slug still aborts the build (slug matching is case-insensitive).
- If a page declares an unknown group **and** has no recognized group at all, it
  also won't be silently grouped — pages with no matching group fall into
  `ungrouped` ("## Other"), but any *unknown* slug is still reported and fails
  the build.
- A page can carry multiple groups (`group: [a, b]`); each unknown slug is
  recorded separately, and the build throws on the first one encountered.
- The thrown error is surfaced by the CLI's failure handler and causes
  `generate` to exit `1`, so misclassified pages are caught at build time rather
  than producing a broken sidebar/agent map.
