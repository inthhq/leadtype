# Nav vs. `group` frontmatter in leadtype

## 1. Which drives the sidebar and agent map, and what is the other still good for?

**`nav` in `docs.config.ts` drives the sidebar and agent map.**

The leadtype types explicitly state that `nav` is the "curated navigation tree" and, when present, it "drives docs UI and agent-facing indexes" (`DocsConfig.nav`). Internally, `resolveDocsNavigation` checks `hasNav` and, if true, builds the navigation tree from the curated `nav` nodes rather than from the legacy `groups` shape.

**The page `group` frontmatter field (and the matching `groups` config) remains useful as fallback taxonomy and metadata:**

* **Fallback navigation:** When `nav` is absent, `groups` is the navigation driver. Pages declare membership via frontmatter (`group: <slug>` or `group: [a, b]`), and leadtype sorts them into the matching config group.
* **Consumer-side filtering:** Framework adapters such as the fumadocs one surface `groups` on every page's data so that consumer sidebars can still filter or group pages by slug.
* **Agent metadata:** The `groups` array is emitted into `AgentReadabilityPage` and `DocsNavigationPage` objects, so agent-facing manifests still know a page's declared taxonomy even when the tree was built from `nav`.
* **Validation allow-list:** As long as `groups` is configured, it acts as the authoritative list of valid group slugs. Frontmatter that names a missing slug is caught at build time (see below).

In short: `nav` is the curated navigation driver; `group` frontmatter / `groups` config is the legacy membership system that still powers taxonomy, filtering, and validation.

## 2. What happens at build time if a page declares a `group` slug the config doesn't know about?

**`leadtype generate` throws a build-time error and fails.**

During generation the CLI calls `resolveDocsNavigation` and then checks the resulting `navigation.unknown` array:

```js
const firstUnknownGroup = navigation.unknown[0];
if (firstUnknownGroup) {
  throw new Error(
    `${firstUnknownGroup.urlPath} declares unknown group "${firstUnknownGroup.slug}"`
  );
}
```

A page ends up in `unknown` when its frontmatter `group` value does not match any slug defined in the configured `groups` tree. This validation runs **even when `nav` is present**, because `resolveDocsNavigation` still invokes `findUnknownGroups(docs, config.groups)` and surfaces mismatches in the returned `DocsNavigation.unknown` list.

**One important nuance:** if you use `nav` exclusively and omit `groups` entirely (so `config.groups` is undefined/empty), `findUnknownGroups` short-circuits and returns an empty array. In that case the frontmatter `group` values are ignored for navigation structure and no build error is thrown for unknown slugs.

### Summary

| Scenario | Build result |
|----------|--------------|
| `groups` configured, page declares missing slug | **Error:** `{urlPath} declares unknown group "{slug}"` |
| `nav` + `groups` both configured, page declares missing slug | **Error** (same as above) |
| `nav` configured, `groups` omitted entirely | No error; `group` frontmatter is ignored for nav |
| No config file at all | Groups are inferred from frontmatter, so all declared slugs are implicitly known |
