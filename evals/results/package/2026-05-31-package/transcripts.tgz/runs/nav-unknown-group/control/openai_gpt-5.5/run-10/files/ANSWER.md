# Leadtype navigation: `nav` vs. legacy `group`

1. **`nav` is the source of truth for navigation when it is present.** The curated `nav` tree in `docs.config.ts` drives the generated docs navigation/sidebar data and the agent-facing maps such as `docs/llms.txt`, `AGENTS.md`, and the agent-readability navigation manifest. A page's legacy `group` frontmatter no longer decides where that page appears in those maps when `nav` is configured; `nav.pages` / `nav.children` do.

   The legacy `group` field is still useful as taxonomy/metadata and as a compatibility/validation layer. The configured `groups` list can describe the allowed legacy group slugs, and each generated page still carries its declared `groups` metadata.

2. **Unknown legacy group slugs fail generation.** During `leadtype generate`, leadtype resolves the navigation and checks for pages whose `group:` value is not present in the configured `groups` taxonomy. If it finds one, generation stops before the rest of the build and reports an error like:

   ```text
   leadtype generate: /docs/some-page declares unknown group "bad-slug"
   ```

   In other words: a page can be placed by curated `nav`, but if it still declares a `group`, that slug must be known to the config's legacy `groups` list when such a list is being used.
