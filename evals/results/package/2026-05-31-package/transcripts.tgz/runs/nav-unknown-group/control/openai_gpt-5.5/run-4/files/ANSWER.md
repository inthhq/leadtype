# Navigation and legacy `group` frontmatter

1. **Curated `nav` is the source of truth when it is present.** The `nav` tree in `docs.config.ts` drives the docs navigation/sidebar and the agent-facing maps/indexes (`AGENTS.md`, `/docs/llms.txt`, agent readability navigation, etc.). A page's legacy `group` frontmatter does **not** decide where that page appears in the sidebar once `nav` is configured; pages appear where `nav.pages` / `nav.children` include them, and any pages not referenced by `nav` are treated as ungrouped/Other in the resolved navigation.

   The legacy `group` field is still useful as taxonomy metadata: it is preserved on page records, can be used by custom UI for filtering/badges, and remains the fallback grouping mechanism for projects that do not define `nav`. If you also keep a `groups` list in config, that list serves as the known taxonomy for validating those legacy `group` values.

2. **Unknown configured-group slugs fail the build.** During `leadtype generate`, leadtype resolves navigation before writing artifacts. If a page declares `group: some-slug` and that slug is not present in the configured `groups` taxonomy, generation exits non-zero with an error like:

   ```text
   leadtype generate: /docs/example declares unknown group "some-slug"
   ```

   This validation still happens even when curated `nav` is what drives the sidebar/agent map, as long as a `groups` taxonomy is configured. If a project uses `nav` without any `groups` taxonomy, there is no known group list to validate legacy `group` values against; the `group` values are then just page metadata and do not place the page in navigation.
