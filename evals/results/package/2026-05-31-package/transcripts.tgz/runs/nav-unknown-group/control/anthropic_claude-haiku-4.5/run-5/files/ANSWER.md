# Navigation: `nav` vs Legacy `group` Frontmatter

## 1. Relationship Between Curated `nav` Config and Page's `group` Frontmatter

### Which one drives the sidebar and agent map?

**The curated `nav` configuration drives the sidebar and agent-facing navigation structures.**

When you define `nav` in `docs.config.ts`:
- It explicitly declares the docs structure for the UI and agent maps (e.g., `/docs/llms.txt`, `/docs/agent-readability.json`, `/sitemap.md`)
- It's used to build the `DocsNavigation` structure (with `groups`, `ungrouped`, and `unknown` arrays)
- Pages are included in the navigation **only** if they match the page entries (`pages` field) in the nav tree
- Pages not referenced in any `nav` entry end up in the `ungrouped` section

**The legacy `group` frontmatter field remains functional but is secondary:**
- Pages still declare a `group:` slug in their frontmatter
- These group declarations are stored in the page metadata (`groups: string[]` array in `DocsPageMeta`)
- The `group` field is useful for **metadata, categorization, and agent guidance** — telling tools what domain a page belongs to
- However, the `group` field **does not determine sidebar placement or nav order** when `nav` is present

### Technical difference:

- **`nav` (curated)**: Drives **UI navigation hierarchy**, sidebar organization, and sitemap structure. It's a *prescriptive* structure.
- **`group` (legacy frontmatter)**: Preserved for **page metadata and tooling metadata**. It's a *declarative* tag that can be queried but doesn't control layout.

When both are present:
- `nav` wins for generating agent-readable indexes and sidebars
- `group` is still passed through to page metadata for agents or tools that want to understand a page's semantic domain
- Using `nav` is the modern pattern; `group` is maintained for backward compatibility

---

## 2. What Happens at Build Time When a Page Declares an Unknown Group Slug

**Build time fails with an error.**

At generation time (`leadtype generate`), the CLI explicitly validates that all pages declaring a `group` slug have corresponding groups defined in the config:

```javascript
// From the CLI (runGenerateCommand):
const navigation = await resolveDocsNavigation({
  srcDir: sourceMirror.srcDir,
  groups,
  nav: effectiveNav,
  mounts,
  i18n: metadata.i18n,
  locale
});

const firstUnknownGroup = navigation.unknown[0];
if (firstUnknownGroup) {
  throw new Error(
    `${firstUnknownGroup.urlPath} declares unknown group "${firstUnknownGroup.slug}"`
  );
}
```

### What gets tracked:

The `resolveDocsNavigation()` function returns a `DocsNavigation` structure with an `unknown` array:

```typescript
type DocsNavigation = {
  groups: DocsNavigationGroup[];
  ungrouped: DocsNavigationPage[];
  unknown: {
    urlPath: string;
    slug: string;
  }[];
  locale?: string;
};
```

The `unknown` array is populated during `buildGroupMembership()` when a page references a group slug that doesn't match any slug in the resolved group tree (case-insensitive lookup):

```javascript
// From llm-DbiIv5JE.js buildGroupMembership:
for (const page of ordered) {
  if (page.groups.length === 0) {
    ungrouped.push(page);
    continue;
  }
  let matchedAny = false;
  for (const slug of page.groups) {
    const slugKey = slug.toLowerCase();
    if (!known.has(slugKey)) {
      unknown.push({ page, slug });
      continue;
    }
    // ... add to byGroupSlug
    matchedAny = true;
  }
  if (!matchedAny) {
    ungrouped.push(page);
  }
}
```

### Build failure:

If **any** page declares a `group` slug that is not defined in `docs.config.ts` (either in `groups` or implicitly referenced in the `nav` structure), the generate command **fails immediately** with a readable error:

```
leadtype generate: /docs/my-page declares unknown group "nonexistent-group"
```

This ensures consistency: you cannot have orphaned pages referencing groups that don't exist in the site's navigation schema.

### Why this validation?

- **Consistency**: The agent-readability manifest and navigation indexes would have broken references if unknown groups were silently ignored
- **Developer feedback**: Unknown group slugs are likely typos or config oversights, so early failure is helpful
- **Contract safety**: Tools reading the generated navigation can trust that every `group` slug in page metadata refers to an actual configured group
