# Navigation and Group Frontmatter in Leadtype

Here are the answers to your questions about navigation in a `leadtype` project.

---

### 1. Relationship Between Curated `nav` and Legacy `group` Frontmatter

#### Which one drives the sidebar and agent map?
* **Curated `nav`** (when defined in `docs.config.ts` with non-zero length) takes precedence and **directly drives the sidebar, navigation summary, and agent map** (LLM readability manifest). 
* If `nav` is **omitted or empty**, the system falls back to using **`groups`** defined in `docs.config.ts`, where pages are dynamically placed into the navigation sidebar and agent map depending on their matching `group` frontmatter field.

#### What is the other still good for?
Even when curated `nav` is driving the layout, the legacy `group` frontmatter and `groups` configuration remain valuable for:
1. **Fallback Auto-Grouping:** If you ever disable or simplify the curated `nav`, the system can seamlessly fall back to automatic grouping based on the frontmatter.
2. **Metadata Filtering and Querying:** The `group` values are parsed and exposed on the page's metadata object returned by `loadPage` or `createDocsSource`. You can use this for frontend-only components, such as related articles, custom breadcrumbs, badges, tags, or search indexing.
3. **Integrity & Validation:** The build process checks the `group` fields in the markdown frontmatter against the configured `groups` list to maintain consistency and catch typos or retired group slugs project-wide.

---

### 2. Build-Time Behavior for Unknown `group` Slugs

If a documentation page declares a `group` slug in its frontmatter that is not registered in the configuration (e.g. `config.groups` or `collections.groups` in `docs.config.ts`):

1. **Unknown Group Identification:** During the build process, when compiling documentation navigation via `resolveDocsNavigation`, the system runs `findUnknownGroups` which compares the page's frontmatter group slugs against the declared config groups.
2. **Hard Build Failure:** If any mismatch is found, it populates `navigation.unknown`. When the CLI build runner (`runGenerateCommand`) detects any unknown groups, it immediately throws a hard `Error`:
   ```
   [urlPath] declares unknown group "[unknown-slug]"
   ```
3. **Process Abort:** This throws a blocking error and **fails the build immediately**, preventing invalid pages or broken navigation hierarchies from being generated and deployed.
