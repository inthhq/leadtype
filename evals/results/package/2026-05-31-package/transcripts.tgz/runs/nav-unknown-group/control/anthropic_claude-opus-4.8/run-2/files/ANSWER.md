# Navigation in leadtype: `nav` vs `group`

Answers below are grounded in the installed `leadtype` package
(`node_modules/leadtype/dist/_shared/llm-DbiIv5JE.js`, `dist/cli.js`, and the
type docs in `dist/llm/index.d.ts` / `dist/index.d.ts`).

## 1. Curated `nav` vs the page-level `group` frontmatter field

**The curated `nav` in `docs.config.ts` wins. When it's present it drives both
the sidebar and the agent-facing map; `group` becomes fallback/secondary.**

Every generator decides this the same way — it computes
`hasNav = Boolean(config.nav && config.nav.length > 0)` and branches:

- `generateLlmsTxt`, `generateAgentsMd`, `generateAgentReadabilityArtifacts`,
  and `resolveDocsNavigation` all do:
  `resolved = hasNav ? resolveNavGroups(config.nav) : resolveGroups(config.groups)`.
- With `nav` set, navigation is built by `buildNavigationFromNav(...)`, which
  places pages by **explicit path references** in the `nav` tree (literal page
  paths or `{ include, exclude, sort }` globs, with a cascading `base`). The
  page's own `group:` frontmatter is *not* consulted for placement.
- Without `nav`, navigation is built from `groups` plus each page's
  `group:` frontmatter via `buildGroupMembership(...)` — a page lands in a
  group when its `group:` slug matches a configured group `slug`.

The type docs say the same thing explicitly:

> "Curated navigation for the single-collection shape. When present, this
> drives docs UI and agent-facing indexes; `groups` remains fallback
> taxonomy/navigation metadata." — `DocsConfig.nav` (`dist/llm/index.d.ts`)

and the per-generator configs note: *"Curated navigation tree. Preferred over
`groups` when present."*

**What `group` is still good for (even when `nav` drives the UI):**

- **Validation / authoring guardrails.** Even in `nav` mode the build still
  calls `findUnknownGroups(docs, config.groups)` and surfaces the result as
  `navigation.unknown`. So `groups` + frontmatter `group` remain a
  consistency check on every page (see Q2).
- **Fallback taxonomy / zero-config navigation.** If you omit `nav`, `group`
  *is* the navigation mechanism. With no config at all, `leadtype generate`
  calls `inferGroups(...)`, which scans frontmatter `group:` values to
  synthesize the group tree automatically (titleized from the slug).
- **Per-page metadata that survives into outputs.** The resolved group slugs
  are carried on each page (`groups: [...doc.groups]`) into the
  agent-readability manifest and the navigation `pageView`, so the page's
  declared taxonomy is still queryable/labelable regardless of where `nav`
  positions it.
- **Pages `nav` doesn't reference.** Anything not referenced by the curated
  `nav` tree falls into `navigation.ungrouped` ("Other"); a page can keep a
  meaningful `group:` as supplemental categorization.

Note also `order:` in frontmatter still feeds sorting (group membership and the
`sort: ["order", ...]` option for `include` globs).

## 2. What happens at build time for an unknown `group` slug?

**The build fails with an error.**

`leadtype generate` (`runGenerateCommand` in `dist/cli.js`) calls
`resolveDocsNavigation(...)`, then checks:

```js
const firstUnknownGroup = navigation.unknown[0];
if (firstUnknownGroup) {
  throw new Error(
    `${firstUnknownGroup.urlPath} declares unknown group "${firstUnknownGroup.slug}"`
  );
}
```

So a page whose `group:` slug isn't found among the configured group slugs is
collected into `navigation.unknown` (by `buildGroupMembership`, where a slug not
in the `known` map is pushed to `unknown`), and the first such page makes the
generate command `throw` and exit non-zero. The message names the offending
page's URL path and the bad slug, e.g.:

```
/docs/quickstart declares unknown group "getting-startd"
```

Important details:

- This check runs **whether you use `groups` or `nav`.** In `nav` mode the
  navigation is built from `nav`, but `resolveDocsNavigation` still computes
  `findUnknownGroups(docs, config.groups)` and feeds it into
  `navigation.unknown`, so a typo'd `group:` slug still fails the build as long
  as `groups` is configured. (If no `groups` are configured at all,
  `findUnknownGroups` returns `[]` — there's nothing to validate against.)
- With i18n, the navigation is resolved per locale, so the unknown-group check
  runs for each configured locale.
- A page with **no** `group:` is fine — it's simply treated as `ungrouped`, not
  unknown. Only a declared-but-unrecognized slug is an error.
- Group slugs are also validated for shape elsewhere: they must be URL-safe
  (`assertValidGroupSlug`), unique among siblings, and (across collections)
  globally unique — those raise their own errors at config/resolve time.
