# Leadtype Navigation and Grouping

Below are the answers regarding how navigation, configuration, and build-time validation work within `leadtype`.

---

### 1. Curated `nav` in `docs.config.ts` vs. Legacy `group` Frontmatter

#### Which one drives the sidebar and agent map?
* **Curated `nav` (if defined)** completely drives the sidebar navigation and agent map (which is used to generate `llms.txt`, `sitemap.md`, and the `agent-readability.json` manifest). 
* When `docs.config.ts` exports a non-empty `nav` array, `leadtype` prefers it for generating the entire navigation tree and ordered page structures.
* If curated `nav` is omitted or empty, `leadtype` falls back to using the configuration's `groups` (or auto-inferred groups) combined with each page's `group` frontmatter field.

#### What is the other still good for?
Even when a curated `nav` is used, the legacy `group` frontmatter field and the `config.groups` array remain highly valuable for:
1. **Validation and Linting:** The CLI still performs validation checking on the frontmatter fields. Specifically, `resolveDocsNavigation` calls `findUnknownGroups` (which resolves the config's `groups` and runs `buildGroupMembership`). If a page's `group` frontmatter references a slug that isn't defined in the config's `groups`, it is flagged as unknown and fails the build. This ensures page-level frontmatter metadata remains accurate and clean.
2. **Graceful Fallback:** If the curated `nav` is ever removed or simplified, the navigation structure instantly falls back to grouping and sorting pages using the `group` frontmatter field.
3. **Build-Time Metadata & Routing Queries:** The frontmatter `group` field is fully parsed and validated during the build. This structured page metadata is exposed to framework adapters, enabling custom routing logic, component conditional rendering, or selecting custom layouts based on page group identities.

---

### 2. Declaring an Unknown `group` Slug at Build Time

If a documentation page's frontmatter declares a `group` slug that the configuration's `groups` definition doesn't know about, the **build fails and exits with status code `1`**.

#### The exact sequence of events at build time:
1. When `leadtype generate` is run, the command handler collects all MDX/markdown files and loads the config.
2. The CLI loops through the resolved locales and calls `resolveDocsNavigation(...)`.
3. Within `resolveDocsNavigation` (via the helper `buildGroupMembership`), any page that contains a `group` slug not present in the configuration's `groups` array gets pushed into the `navigation.unknown` array.
4. Back in the CLI command runner (`runGenerateCommand` in `cli.js`), the CLI checks if `navigation.unknown` is populated:
   ```javascript
   const firstUnknownGroup = navigation.unknown[0];
   if (firstUnknownGroup) {
     throw new Error(
       `${firstUnknownGroup.urlPath} declares unknown group "${firstUnknownGroup.slug}"`
     );
   }
   ```
5. If any unknown group is found, it immediately throws an error containing the offending page's URL path and the unknown group slug.
6. The CLI catches this error, logs the failure, cleans up any temporary staging directories, and exits with a non-zero exit code (`1`).
