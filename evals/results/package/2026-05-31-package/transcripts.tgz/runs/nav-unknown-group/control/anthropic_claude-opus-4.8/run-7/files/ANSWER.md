# Navigation in leadtype: `nav` vs `group`

## 1. Curated `nav` (in `docs.config.ts`) vs a page's `group` frontmatter

**Short version: when `nav` is present it wins — it drives both the sidebar and the agent-facing map. The legacy `group` frontmatter becomes taxonomy/validation metadata that is no longer used to place pages, but it's still validated and still useful as a per-page label.**

### `nav` is the curated, path-based source of truth

`nav` is an author-curated tree (`DocsNavNode[]`) declared in `docs.config.ts`. Each node has a `title`, an optional `slug`/`base`, and `pages` — and `pages` reference docs **by path**, not by frontmatter:

- a plain string is an extensionless path (resolved relative to the nearest `base`, with a leading `/` escaping to the collection root), and
- an include entry (`{ include, exclude?, sort?, required? }`) is a glob over relative paths.

At build time, leadtype resolves `nav` with `resolveNavGroups()` and assembles the navigation manifest with `buildNavigationFromNav()`. Pages are matched **by relative path** (exact path or glob), ordered by the node's order in the config (and `sort` for includes). Anything not referenced by any `nav` node falls into an `ungrouped` ("Other") bucket. The same resolved `nav` then feeds every consumer:

- the docs UI sidebar (via `resolveDocsNavigation`, which a build writes to e.g. `docs-nav.json`),
- the agent map — `AGENTS.md` (`generateAgentsMd`), `/docs/llms.txt` (`generateLlmsTxt` → `renderDocsNavigationSummary`), and the `agent-readability.json` manifest / sitemap (`generateAgentReadabilityArtifacts`).

Across all of these functions the rule in the code is the same: `const hasNav = Boolean(config.nav?.length); … hasNav ? resolveNavGroups(nav) : resolveGroups(groups)`. So when `nav` exists, the page's `group:` field plays no part in where the page appears.

This matches the type docs: `nav` is *"Curated navigation … When present, this drives docs UI and agent-facing indexes; `groups` remains fallback taxonomy/navigation metadata."*

### What `group` (and `groups`) is still good for

The legacy path is the `groups` config tree (`DocsGroup[]`) plus each page's `group:` frontmatter slug. When **no** `nav` is configured, leadtype falls back to `resolveGroups(groups)` + `buildGroupMembership()`, which places each page into a group **by matching its frontmatter `group` slug** (string or array) against a known group slug; pages with no `group` (or no matching one) become `ungrouped`. So `group` is the driver only in the `groups`-only (no-`nav`) shape.

Even when `nav` is in charge, the `group` field is not dead weight:

- **It's still validated.** `resolveDocsNavigation` (and the agent-readability builder) call `findUnknownGroups(docs, config.groups)` even on the `nav` path, so declaring a `group` that the config's `groups` list doesn't define is still an error (see #2). With `nav`, `groups` therefore acts as a fallback taxonomy whitelist.
- **It rides along as per-page metadata.** The `groups` array is carried into the navigation manifest (`pageView`/`toc` entries) and the agent-readability page records (`toAgentReadabilityPage` emits `groups: [...]`). UIs and agents can use it as a category/label, for filtering, badges, or search facets — independent of sidebar placement.
- **It's the migration/fallback path.** Drop `nav` and the very same `group` slugs immediately drive the sidebar and agent map again.

In short: **`nav` (config) drives placement/ordering of the sidebar and the agent map; `group` (frontmatter) is a validated per-page taxonomy label and the fallback navigation mechanism when no `nav` is present.**

## 2. What happens if a page declares a `group` slug the config doesn't know about

**The build fails.** `leadtype generate` calls `resolveDocsNavigation()` for each locale and then checks the resulting `navigation.unknown` list:

```js
const firstUnknownGroup = navigation.unknown[0];
if (firstUnknownGroup) {
  throw new Error(
    `${firstUnknownGroup.urlPath} declares unknown group "${firstUnknownGroup.slug}"`
  );
}
```

So if any page's `group:` slug isn't found among the config's known group slugs, generation throws an error like:

```
/docs/some-page declares unknown group "made-up-slug"
```

and `runGenerateCommand` catches it, reports it, and returns exit code **1** (a JSON run emits a `generate.fail` event). No artifacts are written for that run.

How `unknown` is populated:

- **`groups`-only shape:** `buildGroupMembership()` builds the set of known slugs from the (flattened) `groups` tree. For each page, every `group` slug not in that set is pushed onto `unknown` as `{ urlPath, slug }`. (Note: a page can match one known group *and* declare an unknown one — the known match still files it, but the unknown slug is still reported, so the build still fails.)
- **`nav` shape:** placement comes from paths, but `resolveDocsNavigation` still runs `findUnknownGroups(docs, config.groups)`, which resolves `config.groups` and runs the same membership check purely for validation. So a page's `group` slug must still exist in `config.groups` (when `groups` is defined) even though `nav` decides the sidebar. If no `groups` is configured at all, `findUnknownGroups` short-circuits to `[]` and `group` values aren't validated.

Related guardrails (separate from the unknown-group case): group slugs must be URL-safe (`assertValidGroupSlug` rejects non-`[a-z0-9-]` slugs) and unique among siblings, and in the multi-collection shape group slugs must be globally unique across collections.
