# Leadtype navigation: `nav` vs. frontmatter `group`

1. **`nav` wins when it exists.** The curated `nav` tree in `docs.config.ts` is the source of truth for the generated navigation/sidebar shape and for agent-facing maps such as `docs/llms.txt`, `AGENTS.md`, and the agent readability navigation. Its `pages` / `include` entries decide which pages appear in which section and in what order. A page's legacy frontmatter `group` does **not** place that page into a `nav` section.

   The `group` field is still useful as fallback taxonomy/navigation metadata: if no curated `nav` is configured, Leadtype uses configured `groups` plus each page's `group` frontmatter to build sections. Even with `nav`, `group` can remain as metadata/compatibility tagging, and configured `groups` can be used to validate that page-declared group slugs are not stale. Pages not referenced by `nav` are treated as ungrouped/`Other`; their `group` value does not rescue them into a `nav` section.

2. **Unknown configured group slugs fail generation.** During `leadtype generate`, Leadtype resolves navigation before writing artifacts. If a page declares a `group` slug that is not present in the configured `groups` tree, generation aborts with an error like:

   ```text
   /docs/some-page declares unknown group "missing-slug"
   ```

   This validation also applies when `nav` is present, as long as you have a `groups` list for validation/fallback metadata. If you configure only `nav` and no `groups`, there is no group registry to validate against, so arbitrary legacy `group` values are just page metadata and do not drive the sidebar or agent map.
