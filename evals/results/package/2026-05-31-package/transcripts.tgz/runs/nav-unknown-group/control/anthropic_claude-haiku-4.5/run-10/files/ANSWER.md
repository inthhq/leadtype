# Navigation Architecture: `nav` vs. Legacy `group` Frontmatter

## 1. Relationship Between Curated `nav` and Legacy `group` Frontmatter

### Which one drives the sidebar and agent map?

**The curated `nav` in `docs.config.ts` (or `DocsNavNode[]`) drives both the sidebar UI and agent-facing indexes when present.** This is the primary navigation source.

### What is the other still good for?

**The legacy `group` frontmatter field remains useful as fallback taxonomy and metadata:**

1. **Fallback navigation**: When `nav` is not present, `groups` (i.e., `DocsGroup[]`) become the fallback tree structure. Pages declare membership via frontmatter `group: <slug>` or `group: [a, b]`.

2. **Metadata and grouping**: Even when `nav` drives the UI, page frontmatter `group:` fields are **still parsed and preserved** in the navigation output. A page's `groups` array (from frontmatter) is always populated and visible in the API:
   - The `SourceDoc` type includes `groups: string[]` — group slugs declared in frontmatter
   - The `DocsNavigationPage` type includes `groups: string[]` — all group slugs the page declared
   - Search indexes and downstream systems can use this metadata

3. **Sidebar ordering within groups**: Frontmatter `order:` is still meaningful. Pages with an explicit `order` sort first (ascending) within their group. Pages without `order` fall back to alphabetical `urlPath` ordering.

### Configuration precedence summary

```typescript
type DocsConfig = {
  groups?: DocsGroup[];  // Fallback taxonomy/navigation metadata
  nav?: DocsNavNode[];   // Preferred navigation when present
  // ...
};
```

From the `llm/index.d.ts` (generateLlmsTxt config):
```typescript
type LlmsTxtConfig = {
  groups?: DocsGroup[];         // Used for `/docs/llms.txt` sections
  nav?: DocsNavNode[];          // Preferred over `groups` when present
  // ...
};
```

**Key principle**: `nav` is the **curated author-facing navigation** (what humans and UI use). `groups` is the **fallback taxonomy** (what pages declare about themselves). When both exist, `nav` drives the output but `groups` metadata is still read and preserved.

---

## 2. Build Time Behavior for Unknown Group Slugs

### What happens if a page declares a `group` slug that the config doesn't know about?

**The unknown group slug is captured in the `unknown` array of the `DocsNavigation` result.**

From `llm/readability.d.ts`:
```typescript
type DocsNavigation = {
  groups: DocsNavigationGroup[];      // Known groups
  ungrouped: DocsNavigationPage[];    // Pages with no group
  /** Pages that named a group slug not present in the config. */
  unknown: {
    urlPath: string;
    slug: string;
  }[];  // ← Unknown group slugs collected here
  locale?: string;
};
```

### Behavior details:

1. **No hard error at build time**: The build **does not fail**. Unknown group slugs are recorded for visibility but do not block generation.

2. **Pages are collected**: Pages that declare unknown group slugs are tracked in the `unknown` array so tooling can report them (e.g., lint warnings, CI diagnostics).

3. **Lint warnings available**: The `lintDocs()` function can be configured to validate frontmatter and catch references to undefined groups, but this is optional and depends on your lint configuration.

4. **Downstream tooling can act on it**: Build pipelines that invoke `resolveDocsNavigation()` or `generateLlmsTxt()` receive the `DocsNavigation` object with the `unknown` array populated, allowing custom validation or reporting before rendering.

### Example output structure:
```json
{
  "groups": [
    { "slug": "guides", "pages": [...], "children": [] }
  ],
  "ungrouped": [...],
  "unknown": [
    { "urlPath": "/docs/tutorial", "slug": "nonexistent-group" }
  ]
}
```

This design allows **graceful degradation**: pages with typos or forward references are captured for diagnosis without breaking the build, giving developers time to fix or rename groups intentionally.
