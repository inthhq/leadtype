# Navigation in Leadtype: `nav` Config vs. `group` Frontmatter

## 1. The Relationship Between `nav` and `group`

### Which One Drives the Sidebar and Agent Map?

**The curated `nav` in `docs.config.ts` is the primary driver** for sidebar UI and agent-facing navigation indexes (the agent map). When `nav` is present in your config, it is **preferred over** the `groups` taxonomy.

**The page's legacy `group` frontmatter field** (singular or array) is still good for:
- **Taxonomy and fallback grouping**: When `nav` is absent, `group` drives the sidebar structure via the `groups` array defined in the config.
- **Page-level categorization**: Even when `nav` exists, the `groups` array in each page's metadata (`DocsPageMeta.groups`) preserves the page's declared groups. This is useful for:
  - Breadcrumbs and contextual labeling in your docs UI.
  - Agent-readable page metadata (every page still reports which groups it belongs to in the navigation manifest).
  - Alternate filtering or faceting systems that don't follow the curated hierarchy.

### The Mental Model

- **`nav` (curated)**: Drives what users see in the sidebar and what agents read in the agent-readability sitemap (the structured, hand-authored navigation tree).
- **`group` (legacy)**: Drives fallback hierarchy when `nav` is absent; also preserved as metadata on every page for non-sidebar navigation purposes.

Both can coexist. When both are present:
- The **sidebar and agent indexes use `nav`** (from config).
- **Page metadata still includes `groups`** (from frontmatter), so your docs framework can still access group context in page layouts.

---

## 2. Build-Time Behavior: Unknown Group Slugs

If a page declares a `group` slug that the config doesn't know about (i.e., the slug is not present in the `groups` array or `nav` tree), **the build does not fail**. Instead:

1. **The page is collected under the `unknown` array** in the resolved navigation manifest (`DocsNavigation.unknown`).
   - The `unknown` array contains entries with:
     ```typescript
     { urlPath: string; slug: string }
     ```
   - This records the URL path and the unknown group slug.

2. **A warning is logged during build** (visible in `leadtype generate` output), pointing to the page and the unrecognized group slug.
   - Example from the CLI: `"<urlPath> declares unknown group "<slug>""`

3. **The page is still built and included in output**, but it won't be nested under the declared group in the sidebar or agent indexes (since the group doesn't exist in the config). It may appear under `ungrouped` or in a fallback section, depending on your docs framework's handling of the manifest.

4. **The unknown group slug is preserved in the page's metadata** (`groups` array in `DocsPageMeta`), so you can inspect or report on mismatches downstream if needed.

This design allows for graceful degradation: typos or forward-declarations of groups won't halt your build, but they will be flagged for developer attention.
