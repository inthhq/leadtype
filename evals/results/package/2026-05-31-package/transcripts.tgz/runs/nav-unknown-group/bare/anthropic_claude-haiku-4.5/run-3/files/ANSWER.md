# Navigation in Leadtype: Curated `nav` vs Legacy `group` Frontmatter

## 1. Relationship between `nav` in `docs.config.ts` and page's `group` frontmatter

### Which drives the sidebar and agent map?

The **curated `nav` in `docs.config.ts` drives both the sidebar and the agent map**. This is the authoritative source of truth for navigation structure in a leadtype project.

The **`group` frontmatter field is legacy** and exists for backward compatibility. While pages may still declare a `group`, it is no longer used to determine sidebar or agent map structure.

### What is the legacy `group` field still good for?

The legacy `group` frontmatter field still serves these purposes:

1. **Metadata and identification**: It provides semantic information about which logical group a page belongs to, which can be useful for templates, tooling, or custom processing.
2. **Migration aid**: It helps during the transition period when projects migrate from legacy group-based navigation to the new curated `nav` system.
3. **Validation and warnings**: The build system can use it to detect orphaned pages or provide hints when pages declare groups that don't exist in the config (see question 2).

The key point: **`nav` is prescriptive** (defines the structure), while **`group` is descriptive** (documents the page's purpose).

## 2. What happens at build time if a page declares an unknown `group` slug?

If a page declares a `group` slug that the `docs.config.ts` doesn't know about (i.e., a group that isn't defined in the `nav` configuration), the build process **generates a warning or diagnostic message** to alert the developer.

The page itself **will still build successfully** — unknown groups do not cause build failures. However, developers will be notified that there's a mismatch between the page's metadata and the configured navigation structure. This helps identify:

- Pages that are orphaned from the navigation hierarchy
- Stale group references that haven't been updated during refactoring
- Configuration drift where groups have been removed from the config but pages still reference them

This behavior supports the migration from legacy group-based navigation to curated `nav`, making the transition period safer and more observable.
