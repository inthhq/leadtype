# Navigation in Leadtype

Here are the answers regarding Leadtype's navigation structure and build-time validation behavior:

### 1. Relationship Between Curated `nav` and Legacy `group` Frontmatter

* **Which one drives the sidebar and agent map?**
  * The curated **`nav` array in `docs.config.ts`** is the modern, preferred single source of truth that drives both human-facing and agent-facing surfaces.
  * Specifically, `nav` drives:
    * The reader-facing sidebar navigation and top-level areas (tabs) in the docs UI.
    * The sections and routing hints inside the generated `llms.txt` index.
    * The relative-link structure in `AGENTS.md` (when bundled).
    * Generated sitemaps (`sitemap.xml`, `sitemap.md`).
    * The `agent-readability.json` manifest used by agents.

* **How are they related?**
  * **Legacy Fallback:** If a project does not configure `nav`, Leadtype falls back to the legacy group resolver. In this fallback mode, it infers the navigation tree from the intersection of page-level `group` frontmatter fields and `groups` declared in `docs.config.ts`.
  * **Curated Shift:** When you adopt `nav`, navigation management moves out of the page-level frontmatter and into the centralized config file. This provides much cleaner control over stable ordering, nesting, wildcard inclusions (`{ include: "folder/*" }`), and area-specific headings.

* **What is the `group` frontmatter field still good for?**
  * Even after adopting the curated `nav` system, the `group` frontmatter remains valid and is still useful as:
    * **Broad taxonomy and compatibility metadata**.
    * **Search facets and filtering** (to categorize search results).
    * **Legacy navigation fallback**.

---

### 2. Build-Time Behavior for Unknown `group` Slugs

If a page declares a `group` slug in its frontmatter that the loaded configuration does not know about:

* **The Build Fails Fast and Noisily:** 
  * The build/generation process (`leadtype generate`) will immediately fail. This is intentional to ensure that a bad configuration or a typo in a content file cannot be deployed (broken navigation is treated as a content bug, not a runtime render problem).
* **Error Message:**
  * It prints a specific error to `stderr` indicating which page has the problem, e.g.:
    `error: <urlPath> declares unknown group "<slug>".`
* **Exit Code:**
  * The CLI exits with a non-zero exit code **`1`** (indicating a runtime/validation error), halting any CI/CD pipeline or build wrapper.

*(Note: If no `docs.config.ts` file exists at all in the project, the CLI falls back to inferring groups dynamically from the union of all `group` fields across all MDX pages, meaning it will not fail since there is no configuration to check against. However, if any config file exists and is loaded, any undeclared group slug will trigger the build failure.)*
