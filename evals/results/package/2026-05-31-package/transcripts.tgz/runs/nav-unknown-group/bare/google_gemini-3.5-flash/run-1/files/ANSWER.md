# Navigation & Groups in Leadtype

Here are the answers to your questions about navigation in a leadtype project:

---

### 1. What is the relationship between the curated `groups` in `docs.config.ts` and a page's `group` frontmatter field — which one drives the sidebar and agent map, and what is the other still good for?

#### **The Relationship**
* **The Config Tree (`docs.config.ts`)** defines the structural skeleton of the navigation. It specifies titles, stable ordering, hierarchy/nesting (nested parent/child groups), descriptions, and curated entry points for the groups.
* **The Page Frontmatter (`group` field)** declares page-level membership. Each page uses `group: <slug>` or `group: [a, b]` to associate itself with one or more group slugs.

#### **What Drives the Sidebar and Agent Map**
Neither drives the navigation in isolation; rather, the **intersection** of both drives the sidebar and agent map. 

At build/generation time, the group resolver (`resolveDocsNavigation`) merges the filesystem state (reading every page's frontmatter `group` values) with the group schema defined in `docs.config.ts`. The resulting resolved navigation tree drives:
1. The **sidebar** navigation manifest/JSON (e.g., `docs-nav.json`).
2. The section headings in **`llms.txt`** and **`AGENTS.md`** (the agent maps).
3. Static search metadata groupings.

#### **What the Other is Still Good For**
* **`docs.config.ts` is still good for:**
  * Enforcing order and hierarchy (e.g., nested parent groups which act as summary headings).
  * Attaching descriptions to groups, which coding agents read to understand which documents to load.
  * Curating specific metadata like `bestStartingPoints` and `product` info at the global level.
* **The Page Frontmatter `group` field is still good for:**
  * **Excluding pages**: If you omit `group` from a page's frontmatter entirely, it is excluded from the sidebar navigation and group indexes. It will still be built as flattened markdown and included in the monolithic `llms-full.txt` fallback, allowing you to have linkable but "un-sidebarred" pages.
  * **Config Fallback**: For smaller doc sets without a `docs.config.ts`, the CLI will automatically infer groups alphabetically and title-case them based on the union of all found `group` frontmatter values.

---

### 2. What happens at build time if a page declares a `group` slug that the config doesn't know about?

If a page declares a `group` slug in its frontmatter that isn't defined in `docs.config.ts`, **the build fails fast and noisily**:

1. **Compilation/Generation Failure**: The CLI/build pipeline halts immediately and throws an error indicating `unknown group "<slug>"` (or `error: <urlPath> declares unknown group "<slug>"`).
2. **Process Exit Code**: The build process exits with code `1` (runtime error).
3. **Intentional "Same Source of Truth" Design**: This strict validation prevents navigation drift and broken links, ensuring that a bad configuration or typos in content frontmatter never make it to production or get published inside an npm tarball.
