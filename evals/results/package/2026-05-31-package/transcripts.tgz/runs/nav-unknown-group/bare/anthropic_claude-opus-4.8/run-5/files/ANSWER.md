# Navigation in leadtype: `nav`/`groups` config vs. `group` frontmatter

> Note on terminology: the curated navigation lives in `docs.config.ts` as the
> `groups` array (each entry has a `slug`, `title`, optional `description`,
> `order`, and nested `children`). That config-owned tree is the "curated nav"
> referenced here. A page's `group` frontmatter field is the legacy, per-page
> membership pointer that names one of those config slugs.

## 1. Relationship between curated config nav and a page's `group` frontmatter

They are two halves of **one source of truth**, and the config is the half that
drives both the sidebar and the agent map.

- **`docs.config.ts` (`groups`) is the curated structure.** It declares *which
  groups exist*, in what `order`, with what human-readable `title`,
  `description`, and any nested `children`. The group resolver consumes this
  config to build the navigation tree, the `llms.txt` section headings, search
  metadata, and the `AGENTS.md` grouping. So the config is what actually
  **drives the sidebar and the agent map** (`AGENTS.md` / agent-readability
  manifest) — it owns the shape, naming, and ordering of navigation.

- **A page's `group` frontmatter field is just a membership pointer.** It is a
  slug (or list of slugs — `group: [a, b]` lets a page live in multiple groups)
  that says *which* config-declared group(s) this page belongs to. It does **not**
  define titles, ordering, descriptions, or nesting; it only places the page
  into a slot that the config already defines.

In short: the **config decides the tree (and therefore the sidebar + agent map);
the frontmatter `group` only attaches each page to a node in that tree.** Per the
docs, "Pages declare `group:` in frontmatter; the config declares titles, order,
and descriptions." The intersection of the two is what the resolver turns into
nav, `llms.txt` sections, search metadata, and `AGENTS.md`.

### What the `group` frontmatter field is still good for

Even though the config owns the curated tree, the per-page `group` field remains
useful because it is the *one* field that links a page into everything
downstream. The same `group:` value still drives:

- the page's **sidebar position** (which group slot it lands in),
- its **`llms.txt` section**,
- **search metadata** and **`AGENTS.md` grouping**,
- the **search-filtering UI**, and
- **cross-framework link checks** during `leadtype lint`.

It is also the mechanism for **multi-group membership** (`group: [a, b]`) and for
placing a page into a **nested/leaf group** — only leaf groups (no children)
directly contain pages, so frontmatter is how a page targets a specific leaf.

Finally, `group` is the **fallback inference source**: if there is *no*
`docs.config.ts`, the CLI infers groups from the union of `group:` values it
finds (sorted alphabetically, title-cased). That fallback is fine for small docs
sets but loses stable order, descriptions, and nesting — which is exactly why the
curated config exists for anything larger.

## 2. What happens at build time for an unknown `group` slug

**The build fails — by design.** During `leadtype generate`, group resolution
runs as a fixed pipeline stage (step 3): after frontmatter is parsed and markdown
is converted, it **resolves groups from frontmatter and validates that every
page's `group:` matches a known slug** declared in `docs.config.ts`.

If a page declares a slug the config doesn't know about, generation stops with an
error of the form:

```
error: <urlPath> declares unknown group "<slug>".
```

(equivalently described as the build failing with `unknown group "<slug>"`).

The rationale, stated in the docs: this keeps a single source of truth with **no
drift** between the config and the pages, and "broken navigation is a content
bug, not a render-time problem" — so it's caught at build time rather than
shipping a broken sidebar/agent map. The CLI reflects this with **exit code `1`**
(runtime error: docs dir missing, config load error, **unknown group**,
conversion error).

You can also catch the same class of issue earlier in CI: `leadtype generate`
fails noisily on unknown groups, while `leadtype lint` surfaces content-schema
problems with file/line context before a build is even attempted.

(One caveat: the fail-fast check only applies when a `docs.config.ts` exists. With
no config, there is nothing to be "unknown" against — the CLI just infers the
group set from the `group:` values present.)
