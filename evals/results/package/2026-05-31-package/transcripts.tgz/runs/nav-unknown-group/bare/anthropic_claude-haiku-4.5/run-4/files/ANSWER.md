# Navigation in Leadtype: `nav` Config vs `group` Frontmatter

## 1. Relationship between `nav` config and `group` frontmatter

### Which drives the sidebar and agent map?

The **curated `nav` in `docs.config.ts` is the authoritative source** that drives both:
- The sidebar navigation structure
- The agent map generation

The **legacy `group` frontmatter field is still good for**:
- Backward compatibility with existing pages
- Providing fallback metadata when pages haven't been explicitly added to the curated `nav`
- Semantic documentation about page classification that may be useful for other tools or processes

### How they interact:

- **`nav` config wins**: If a page is listed in the curated navigation config, that positioning and grouping in `docs.config.ts` determines how it appears in the sidebar and is represented in the agent map.
- **`group` fallback**: If a page exists in the codebase but is not explicitly referenced in `docs.config.ts`, the `group` frontmatter can still provide organizational context, though it won't affect the sidebar display.
- **Migration path**: As projects migrate from the legacy `group` system to curated navigation, pages are gradually moved into the `nav` structure in `docs.config.ts`, where they become primary sources of truth for navigation intent.

## 2. What happens at build time if a page declares an unknown `group` slug?

If a page's frontmatter declares a `group` slug that is **not recognized** in the configuration:

- **Build continues successfully** — an unknown `group` does not cause a build error or failure.
- **No sidebar impact** — the unknown group does not create a new sidebar section, since the sidebar is driven by the curated `nav` config, not by frontmatter.
- **Validation/warning** — Depending on the build configuration, there may be:
  - A warning logged to alert the developer that a page references an unknown group
  - A validation message indicating the mismatch between frontmatter and configuration
- **Page still builds** — The page itself builds and renders normally; the unknown group is essentially ignored if the page isn't also in the curated `nav`.
- **Orphaned metadata** — The `group` value is retained in the page's frontmatter but has no effect on navigation structure. This can create confusion if the group is later expected to function but remains undeclared in the config.

This behavior supports gradual migration: pages can keep their old `group` values while teams incrementally populate `docs.config.ts` with the curated navigation structure.
