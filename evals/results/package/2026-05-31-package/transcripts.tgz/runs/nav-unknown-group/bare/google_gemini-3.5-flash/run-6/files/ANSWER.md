# Navigation and Group Resolution in Leadtype

## 1. Curated `groups` in `docs.config.ts` vs. Page Frontmatter `group`

### Relationship
* **`docs.config.ts` (The Curated Structure):** Centralizes the definition of your documentation groups. It defines the group metadata, including stable ordering, user-friendly titles, descriptions, and parent-child hierarchies (nested groups).
* **Page Frontmatter `group`:** Establishes the mapping of individual page files to one or multiple groups (e.g., `group: "guides"` or `group: ["guides", "reference"]`). 

The intersection of these two sources of truth—where the page frontmatter `group` slugs match the defined group slugs in `docs.config.ts`—produces the resolved navigation manifest.

### What Drives the Sidebar and Agent Map?
The **curated `groups` configuration in `docs.config.ts`** is what primarily drives the structure, stable order, titles, and descriptions of the sidebar and agent maps (`llms.txt` sections, sitemaps, search metadata, and `AGENTS.md` grouping). The page-level `group` field merely acts as the assignment mechanism mapping individual documents into those slots.

### What is the Other Still Good For?
The page's `group` frontmatter field is still highly useful because:
* **Assigns Page-Level Membership:** It determines which curated category or categories a specific file belongs to.
* **Ungrouped Utility:** If a page omits the `group` frontmatter field, it is excluded from the navigation tree, the sidebar, and grouped indexes, but it is **still converted to markdown** and included in the root `llms-full.txt` context file. This is useful for auxiliary or standalone docs (like a licensing page) that should be searchable or readable by direct link without cluttering the main navigation.
* **Zero-Config Fallback:** If you do not have a `docs.config.ts` file, the CLI dynamically infers groups from the union of all page-level `group` values it discovers, sorting them alphabetically and title-casing them. This provides an easy starting point for smaller documentation sets.

---

## 2. Declaring an Unknown `group` Slug at Build Time

If a page declares a `group` slug in its frontmatter that isn't defined in `docs.config.ts`, the build process handles this strictly as follows:

* **Build Failure:** The build fails loudly and terminates immediately (fail-fast behavior).
* **Error Message:** The build runner throws an error indicating the mismatched slug, e.g.:
  ```
  [page-url] declares unknown group "[slug]"
  ```
* **Exit Code:** The CLI exits with **exit code `1`** (indicating a runtime error), which safely fails CI pipelines before broken configurations can be published.
* **Design Rationale:** This strict validation is by design. Leadtype treats broken navigation as a **content bug** that must be resolved before deployment, preventing broken sidebars or incomplete agent indexes from shipping.
