# Navigation in Leadtype: Config `groups` vs. Frontmatter `group`

## 1. Relationship between curated `groups` in `docs.config.ts` and a page's `group` frontmatter field

The `groups` array in **`docs.config.ts`** is the **curated source of truth** that drives the sidebar structure, the agent map (`AGENTS.md` sections), `llms.txt` sections, and search metadata. It defines the tree shape: group titles, descriptions, nesting (via `children`), and order.

A page's frontmatter **`group`** field is a per-page **membership tag** that assigns the page to one or more groups (e.g., `group: authoring` or `group: [a, b]`). It is not deprecated, but it plays a supporting role to the config: the config declares *what groups exist and how they are structured*, while the frontmatter field declares *which pages belong to those groups*.

**Which drives what:**
- **Sidebar and agent map:** Driven by **`docs.config.ts` `groups`**. The `resolveDocsNavigation()` helper (and `source.getNavigation()`) builds the navigation manifest from the config tree, then slots in pages whose frontmatter `group` matches a config group slug.
- **What the frontmatter field is still good for:** It is the page-level opt-in into the navigation tree. Without it, a page is **ungrouped** — it is excluded from the nav, grouped indexes, and `llms.txt` sections, but it is still converted to markdown and included in the root `llms-full.txt` fallback. It also allows a single page to appear under multiple groups.

When no `docs.config.ts` exists, the CLI falls back to inferring groups directly from the union of `group:` values found in frontmatter (sorted alphabetically, title-cased). That fallback works for small docs sets, but the config is required for stable ordering, descriptions, or nested groups.

## 2. Build-time behavior when a page declares an unknown `group` slug

If a page's frontmatter references a group slug that does **not** exist in `docs.config.ts` `groups`, the build **fails hard**.

During `leadtype generate`, step 3 resolves groups and validates every page's `group:` against the known slugs from the config. The first unknown group triggers an error like:

```
/docs/<page-path> declares unknown group "<slug>"
```

This is intentional — leadtype treats broken navigation as a **content bug**, not a render-time warning. The same check applies to the lower-level `resolveDocsNavigation()` API, which returns an `unknown` array you can inspect programmatically, but the CLI throws to prevent drift between authored frontmatter and the curated config.

---

**Sources:**
- `node_modules/leadtype/docs/authoring/frontmatter.md` — group semantics and the "unknown group" build failure rule.
- `node_modules/leadtype/docs/how-it-works.md` — pipeline step 3 and the vocabulary definition of `group`.
- `node_modules/leadtype/dist/cli.js` — `runGenerateCommand` validates `navigation.unknown[0]` and throws the exact error.
- `node_modules/leadtype/dist/_shared/llm-oCakU9aZ.js` — `buildGroupMembership()` separates pages into `byGroupSlug`, `ungrouped`, and `unknown`.
