# Navigation in leadtype: `nav` config vs. `group` frontmatter

## 1. Relationship between the curated config and per-page `group`

They are two halves of a single, deliberately split contract — **structure lives in config, membership lives on the page** — and the config is the source of truth.

**`docs.config.ts` (the curated `nav`/`groups`) defines the structure.** It declares every group exactly once: each group's slug, human-readable `title`, optional `description`, ordering, and nesting (`children`). Only **leaf** groups (those with no `children`) can directly hold pages; non-leaf groups are heading-only summary nodes. This config is the single source of truth for the shape of the navigation tree.

**A page's `group` frontmatter field is just membership.** It's an optional slug (or array of slugs, `group: [a, b]`, so a page can live in several groups) that points at a group already declared in the config. It says *which* curated slot a page belongs to; it does **not** create or describe groups, set their order, or define nesting.

**Which one drives the sidebar and agent map?** The config drives them — but only by resolving *together* with the pages' `group` values. At build time the "group resolver" intersects the config's declared groups with the `group` slugs found on pages. That single resolved tree is what feeds, identically:

- the sidebar / navigation manifest (`resolveDocsNavigation()` → `docs-nav.json`),
- the section headings in `llms.txt`,
- search metadata,
- and the **AGENTS.md** grouping (the offline agent map in bundle mode).

Because the config is shared and authoritative, the sidebar and the agent-facing artifacts agree on structure — "same source of truth, no drift." (If your app's sidebar order disagrees with `llms.txt`, it's because the app and the CLI loaded *different* config files — centralize and import one `docs.config.ts` in both.)

**So what is the `group` field still good for?** It remains the per-page lever that does real work even though it doesn't define structure:

- It places each page into its curated slot — without it the page is **excluded from the nav, the grouped `llms.txt`/AGENTS.md sections, and grouped indexes** (though the page is still converted to markdown and still appears in the root `llms-full.txt` fallback).
- It supports multi-group membership (`group: [a, b]`) so one page can appear under several sections.
- The same value drives sidebar position, the `llms.txt` section, search metadata/filtering, and AGENTS.md grouping — "one field, one source of truth" at the *page* level.
- It also participates in lint's cross-framework link checks.

A useful way to hold it: **the config is the menu of valid sections (order, titles, nesting); the `group` field is each page checking the box for which section(s) it sits in.** Neither alone produces the tree — the resolver needs both.

> Note: leadtype can also *infer* groups from the `group:` values it finds when there is **no** `docs.config.ts`. That fallback is fine for small docs sets, but you lose stable ordering, group descriptions, and nested groups — which is exactly why the curated config exists.

## 2. What happens at build time if a page declares an unknown `group` slug

**The build fails.** During `leadtype generate`, after frontmatter parsing and markdown conversion, the third pipeline stage resolves groups and validates that every page's `group:` matches a slug declared in `docs.config.ts`. If a page declares a slug the config doesn't know about, the run errors with:

```
unknown group "<slug>"
```

This is by design: leadtype treats broken navigation as a **content bug to catch at build time**, not a render-time problem — keeping the config and the pages from drifting apart.

You can catch the same class of problem even earlier in CI: run `leadtype lint` before `leadtype generate`. Lint enforces the frontmatter schema (e.g. the `schema` rule for missing/mis-typed required fields and `invalid-link` for dead `/docs/...` links), so structural and link issues fail the PR before they ever reach a build.
