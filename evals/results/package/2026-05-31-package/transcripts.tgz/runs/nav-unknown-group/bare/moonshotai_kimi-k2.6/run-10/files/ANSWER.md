# Navigation in leadtype: config vs. frontmatter

## 1. Relationship between `docs.config.ts` groups and a page’s `group` frontmatter

The **curated group tree in `docs.config.ts`** is the source of truth that drives the sidebar, the agent map (`AGENTS.md`), `llms.txt` sections, and search metadata. It defines the order, hierarchy, titles, and descriptions of every group. Only *leaf* groups (those with no children) directly contain pages; non-leaf groups are section headings.

The page’s **`group` frontmatter field** is the **membership declaration**. It assigns the page to one or more leaf groups in that tree (`group: <slug>` or `group: [a, b]`), which is how a single page can appear in multiple sections. Without a `group`, a page is still converted to markdown and included in the root `llms-full.txt` fallback, but it is **excluded from the nav and all grouped indexes**.

So:
- **`docs.config.ts` groups** → drive the *structure* (sidebar, agent map, section order).
- **Page `group` frontmatter** → drives *membership* (which leaf groups the page lands in).

If you do not have a `docs.config.ts`, the CLI falls back to inferring groups from the union of all `group:` values it finds in frontmatter. That is enough for small docs sets, but the config is required when you need stable order, custom descriptions, or nested groups.

## 2. Build-time behavior for an unknown group slug

The build **fails hard**.

During `leadtype generate`, the pipeline resolves groups after converting MDX. If a page declares a `group` slug that is not defined in `docs.config.ts`, the CLI throws an error and exits non-zero:

```
<urlPath> declares unknown group "<slug>"
```

This is intentional — broken navigation is treated as a content bug, not a render-time problem. The same check is exposed in the library via `resolveDocsNavigation()`, which returns unknown groups in `navigation.unknown` so custom build scripts can fail identically.

In short: there is no silent fallback or auto-created group. The config and the frontmatter must stay in sync.
