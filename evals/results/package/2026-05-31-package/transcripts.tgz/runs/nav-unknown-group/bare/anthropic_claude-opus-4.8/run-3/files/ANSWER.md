# Navigation in leadtype: `nav`/`groups` config vs. page `group` frontmatter

Sourced from the installed `leadtype` package docs:
`node_modules/leadtype/docs/authoring/frontmatter.md`,
`node_modules/leadtype/docs/how-it-works.md`,
`node_modules/leadtype/docs/reference/llm.md`, and
`node_modules/leadtype/docs/reference/source.md`.

## 1. Curated config vs. the page `group` field

These are two halves of the **same** navigation system, not two competing
sources of structure:

- **The curated structure lives in `docs.config.ts`** (the `groups` tree you
  pass to `createDocsSource`, `resolveDocsNavigation`, `generateLlmsTxt`,
  `generateAgentsMd`, etc.). This is the **single source of truth for the shape
  and order** of navigation. Each group is **declared exactly once** here, with
  its `slug`, human-readable `title`, optional description, and any nested
  `children`. Only **leaf** groups (no children) hold pages directly; non-leaf
  groups are heading-only sections. Use the config when you need stable order,
  group descriptions, or nested groups.

- **A page's `group` frontmatter field is a pointer, not a definition.** It is a
  slug (or array of slugs — a page can belong to multiple groups) that says
  *"file this page under that already-declared group."* It does not invent or
  order sections; it just slots the page into the curated tree.

So: **the config drives both the sidebar and the agent map; the frontmatter
`group` only assigns a page to a slot the config defines.** Per the docs, "the
group resolver" takes the config groups + each page's `group` value and produces
the navigation tree, the `llms.txt` section headings, search metadata, and the
`AGENTS.md` grouping — one resolution feeds all of those (`resolveDocsNavigation`
is the helper, and `source.getNavigation()` returns the same shape).

**What the `group` field is still good for** even though the config owns the
structure:

- It is the **per-page membership signal** — without it a page is excluded from
  the nav, the grouped `llms.txt`/`AGENTS.md` sections, and grouped indexes.
  (Such a page still gets a generated `.md` mirror and still appears in the
  broad root `llms-full.txt` fallback — it's just unrouted.)
- It lets a single page appear in **multiple** groups (`group: [a, b]`).
- It feeds the same value into lint's **cross-framework link checks** and the
  search filtering/facets.
- If there is **no** `docs.config.ts` at all, the CLI **infers** groups from the
  `group:` values it finds. That fallback is fine for small docs sets, but you
  lose stable order, descriptions, and nesting — which is exactly why the
  curated config exists.

In short: the config decides *which sections exist, what they're called, and how
they nest*; the frontmatter `group` decides *which pages land in them*. Same
source of truth, no drift.

## 2. What happens at build time with an unknown `group` slug

**The build fails — by design.** If a page declares a `group` slug that
`docs.config.ts` doesn't declare, group resolution errors out with:

```
unknown group "<slug>"
```

This happens in stage 3 of `leadtype generate` ("Resolve groups from frontmatter,
validate every page's `group:` matches a known slug"), which runs *before* any
of the website/bundle artifacts are emitted. The docs state the rationale
explicitly: *"broken navigation is a content bug, not a render-time problem"* —
so it's caught loudly at build rather than producing a silently broken sidebar or
agent map.

If you call the library directly instead of the CLI, the same condition surfaces
as data rather than a thrown crash: `resolveDocsNavigation(...)` returns an
`unknown` array of `{ urlPath, slug }` entries, and the documented pattern is to
print each one and `process.exit(1)`:

```ts
const navigation = await resolveDocsNavigation({ srcDir: ".", groups: docsConfig.groups });

if (navigation.unknown.length > 0) {
  for (const { urlPath, slug } of navigation.unknown) {
    process.stderr.write(`error: ${urlPath} declares unknown group "${slug}".\n`);
  }
  process.exit(1);
}
```

You can also catch the typo earlier — before a build — with `leadtype lint`,
which enforces the frontmatter schema and navigation/link checks in CI.

**Fix:** either add the missing group to `docs.config.ts` (with a `slug`,
`title`, and placement in the tree) or correct the page's `group` value to an
existing slug.
