# Navigation and Grouping in Leadtype

Here are the answers to your questions about navigation, grouping, and config validation in a `leadtype` project.

---

### 1. The Relationship between Curated Config and Frontmatter Grouping

In `leadtype`, the navigation layout is designed around a single source of truth that is resolved from the **intersection** of the configuration file and the page content itself.

#### The Curated Config (`docs.config.ts`)
* **What it is:** This file contains the canonical structure of your docs site via the `groups` list (often referred to as the curated `nav` config). It defines the overarching hierarchy of groups/categories, including nested group structures (`children`), titles, ordering, descriptions, and metadata (e.g., icons, product summary, and agent instructions).
* **What it drives:** It drives the **structure, metadata, stable ordering, categories, and descriptions** of both the user-facing sidebar and the agent map (like `llms.txt` and `AGENTS.md` sections).

#### The Page Frontmatter field (`group: <slug>`)
* **What it is:** This is a page-level metadata property located in each `.mdx` or `.md` file's YAML frontmatter.
* **What it is still good for:** It declares **membership** — associating individual files/pages with their corresponding structural groups defined in `docs.config.ts`.
* **Key capabilities:**
  * **Many-to-many sharing:** A page can declare multiple groups (e.g., `group: [group-a, group-b]`) to appear under multiple navigation categories without duplicating content on disk.
  * **Auto-inference fallback:** If a small project doesn't have a `docs.config.ts`, `leadtype` will fallback to auto-generating group structures by inferring categories directly from the union of these page-level frontmatter slugs (sorting them alphabetically and title-casing them).

#### Summary of the Relationship
* **The Config (`groups` / `nav`)** acts as the structural blueprint (defining the categories, stable order, hierarchy, and descriptions).
* **The Page Frontmatter (`group`)** acts as the membership link (assigning specific documents to those categories).
* **Their Intersection** is resolved at build time to build the finalized navigation tree and agent sections.

---

### 2. Build-Time Behavior for Unknown Groups

If a page declares a `group` slug in its frontmatter that isn't defined anywhere within the `docs.config.ts` configuration file, the following happens at build time:

1. **The Build Fails Fast:** The execution of the build pipeline (`leadtype generate`) immediately stops and fails noisily.
2. **Detailed Error Reporting:** An error message is outputted to stderr detailing which page failed and the unrecognized group slug:
   ```
   error: <urlPath> declares unknown group "<slug>"
   ```
3. **Exit Code 1:** The process exits with a status code of `1` (indicating a runtime validation/generation error), which safely fails any CI/CD deployment pipelines before bad code/configuration is published.

#### The Design Philosophy
This strict validation is **by design**. In `leadtype`, broken navigation or drifting metadata is treated as a **content bug** that must block production deployments, rather than a render-time visual issue. This ensures that the generated developer sidebar, `llms.txt` sections, search metadata, and `AGENTS.md` indexes remain entirely consistent and never drift out of sync.
