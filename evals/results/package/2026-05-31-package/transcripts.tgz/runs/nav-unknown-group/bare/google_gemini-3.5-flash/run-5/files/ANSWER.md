# Leadtype Navigation Answers

Here are the answers regarding how navigation, groups, and config behave in a `leadtype` project:

---

### 1. Relationship between the Curated `groups`/`nav` in `docs.config.ts` and Page `group` Frontmatter

* **The Relationship**: 
  The relationship is a **schema-to-instance** mapping. 
  * **`docs.config.ts`** acts as the curated schema/blueprint, defining the overall structure, stable ordering, descriptions, and hierarchy (including nested child groups) of your documentation sections.
  * **The page-level `group` frontmatter field** acts as the instance declaration, where individual pages indicate which group(s) they belong to (e.g., `group: docs-site` or `group: [authoring, reference]`).

* **Which one drives the sidebar and agent map**:
  **Both work in tandem via intersection.** The build-time resolver (`resolveDocsNavigation()`) computes the intersection of the curated groups list from `docs.config.ts` and the `group:` values declared across page frontmatters. This intersection produces the final navigation tree/manifest, which simultaneously drives:
  1. The **sidebar** position in the website UI.
  2. The sections and descriptions in **`llms.txt`**.
  3. The directory sections and relative links of the offline **`AGENTS.md`** map.
  4. Search filtering metadata.

* **What each is still good for / Fallback behavior**:
  * **Page-level `group` frontmatter is still good for**:
    * **CLI Fallback Mode (No Config)**: If a `docs.config.ts` file is completely omitted, the CLI fallback automatically infers groups from the union of all page-level `group:` values it finds, title-casing them and sorting them alphabetically. This is perfect for small docs sets that don't need manual ordering or descriptions.
    * **Multi-group Sharing**: Pages can declare multiple group slugs (e.g. `group: [group-a, group-b]`) to appear under multiple navigation paths.
    * **Exclusion/Inclusion**: Leaving the `group` field blank/omitted allows you to exclude pages from sidebars, navigations, and grouped indexes while still building their markdown mirrors and keeping them in the monolithic `llms-full.txt` fallback.
  * **The Curated Config (`docs.config.ts`) is good for**:
    * **Stable Group Ordering**: Keeping groups ordered deliberately rather than alphabetically.
    * **Agent Routing & Descriptions**: Providing rich descriptions on groups which agents read to decide which topics/links to follow.
    * **Nested Navigation Hierarchies**: Designing parent-child group structures (where only leaf groups can directly hold pages, and parent groups serve as non-selectable section headings).

---

### 2. What happens at build time if a page declares a `group` slug that the config doesn't know about?

If a page declares a `group` slug in its frontmatter that isn't defined in the `docs.config.ts` configuration, the following happens:

1. **The build fails noisily and immediately (fails fast)**: The generation pipeline (`leadtype generate`) stops execution.
2. **Standard Error Output**: It prints an error message to `stderr` specifying the offending file and the unknown slug, such as:
   ```bash
   error: /docs/some-page declares unknown group "unknown-slug".
   ```
3. **Exit Code**: The CLI exits with code `1` (representing a runtime content error).
4. **By Design**: This strict, fail-fast behavior is fully intentional. Because broken navigation is treated as a **content bug** rather than a render-time framework problem, stopping the build immediately prevents inconsistent configuration, broken sidebars, or drifting links from ever shipping to production or being published.
