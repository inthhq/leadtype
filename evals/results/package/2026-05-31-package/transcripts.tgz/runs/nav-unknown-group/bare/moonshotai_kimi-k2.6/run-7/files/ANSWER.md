# Navigation in leadtype: config `groups` vs. page `group`

## 1. Which drives the sidebar and agent map?

The **curated `groups` array in `docs.config.ts`** is the source of truth for the navigation *structure*. It defines every group slug, its display title, description, order, and nesting. This is what drives:

- the sidebar tree (`resolveDocsNavigation` / `source.getNavigation()`)
- the agent-readable map (`AGENTS.md` sections)
- the `llms.txt` sections
- search metadata grouping

A page’s **`group` frontmatter field** is the *membership* signal. It declares which group(s) the page belongs to (`group: <slug>` or `group: [a, b]`). The pipeline intersects the config’s `groups` with the pages’ `group` values to produce the final nav tree. In other words:

- **Config `groups`** = “here are the sections and their order.”
- **Page `group`** = “put this page in that section.”

A page without a `group` is **ungrouped**: it is still converted to markdown and appears in the root `llms-full.txt` fallback, but it is excluded from the sidebar, grouped indexes, and `AGENTS.md` sections.

## 2. What happens if a page declares an unknown `group` slug?

**The build fails.**

During `leadtype generate`, the pipeline resolves navigation after converting MDX. If any page references a group slug that does not exist in the loaded `docs.config.ts`, the CLI throws an error and exits with code `1`, for example:

```
docs/my-page.mdx declares unknown group "foo"
```

This is by design — leadtype treats broken navigation as a content bug that should surface at build time, not silently at runtime. If no `docs.config.ts` exists, the CLI falls back to inferring groups from the union of all `group:` values it finds (alphabetical, title-cased), but once a config is present it is the strict source of truth.
