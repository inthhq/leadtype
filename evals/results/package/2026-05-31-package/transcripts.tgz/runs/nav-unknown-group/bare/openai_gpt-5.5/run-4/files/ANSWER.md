# Navigation and legacy `group`

1. The curated navigation in `docs.config.ts` is the source of truth for the sidebar and the agent-facing documentation map (`llms.txt` / `AGENTS.md` style grouping). It defines the structure agents and the UI see: section order, nesting, titles, descriptions, and the set of known group slugs. A page's legacy `group` frontmatter is not a separate sidebar definition. It is still useful as page metadata / membership metadata: it can associate a page with a known configured group, preserve compatibility with older leadtype flows, help search/filtering or migration scripts, and provide a fallback signal in setups that infer navigation instead of curating it.

2. If a page declares a `group` slug that is not known to the loaded config, leadtype treats that as a content/configuration error. Build-time navigation resolution records the page as an unknown group, and the CLI/build fails with an error like:

   ```text
   /docs/some-page declares unknown group "some-slug"
   ```

   In other words, the page is not silently dropped into the sidebar, auto-created as a new group, or treated as merely ungrouped; the build should be fixed by either adding the group to `docs.config.ts` or changing/removing the page's `group` value.
