# Nav vs. `group` frontmatter in leadtype

## 1. Which drives the sidebar and agent map?

The **curated `groups` array in `docs.config.ts`** is the source of truth for the sidebar, the agent map (`AGENTS.md`), `llms.txt` sections, and search metadata. It defines the structure, order, titles, and nesting of the navigation tree.

A page’s **`group` frontmatter field** is still used to declare **membership**: it points the page at one or more config groups (`group: <slug>` or `group: [a, b]`). The intersection of the config groups and the page `group` values produces the final nav tree. Without a `group`, a page is still converted and emitted, but it is **excluded from the nav and grouped indexes** — it only appears in the generated markdown mirrors and the root `llms-full.txt` fallback.

In short:
- **Config `groups`** → drives structure.
- **Page `group`** → declares membership; still required for a page to show up in the sidebar/agent map.

## 2. What happens at build time for an unknown group slug?

If a page declares a `group` slug that is **not present** in `docs.config.ts`, the build **fails** with an error such as:

```
/docs/<page> declares unknown group "<slug>"
```

This is intentional — leadtype treats broken navigation as a content bug, not a render-time problem, so the run stops instead of silently omitting the page or creating a drifting nav tree.
