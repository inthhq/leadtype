# Navigation System in Leadtype: `nav` Config vs. `group` Frontmatter

## 1. Relationship Between `nav` Config and `group` Frontmatter Field

### Which Drives the Sidebar and Agent Map?
**The curated `nav` in `docs.config.ts` drives the sidebar and agent map.**

The `nav` configuration is the primary source of truth for:
- **Sidebar structure**: The `nav` object defines the hierarchical organization of documentation pages that appears in the sidebar
- **Agent map**: The `nav` config determines which pages are included in the agent's knowledge map and how they're indexed

### What is the `group` Frontmatter Field Still Good For?
The legacy `group` frontmatter field serves as a **fallback mechanism** and provides:
- **Ungrouped page organization**: For pages that aren't explicitly listed in the `nav` config, the `group` field allows them to be organized into a logical group by slug
- **Backward compatibility**: It enables legacy documents to maintain organization without requiring the full config to be updated
- **Implicit categorization**: Pages with matching `group` slugs will be associated together even if not explicitly listed in `nav`

### Migration Pattern
The modern approach is to move away from relying on `group` frontmatter and instead explicitly define page structure in the curated `nav` config, which provides better control and clearer documentation organization.

## 2. What Happens at Build Time if a Page Declares an Unknown `group` Slug?

When a page declares a `group` slug that the `nav` config doesn't know about:

- **Build does not fail**: The build continues successfully — it's not a fatal error
- **Page is excluded from agent map**: The page won't be included in the agent's knowledge graph since it's not in the curated navigation structure
- **Page is not discoverable via navigation**: The page won't appear in the sidebar or standard navigation hierarchy
- **Page may become orphaned**: Without explicit `nav` config entry and with an unknown `group`, the page becomes effectively inaccessible through normal navigation paths
- **Warning or logging may occur**: Depending on build configuration, there may be warnings or logs about unknown group references, but the build proceeds

### Best Practice
To ensure pages are properly included in the sidebar and agent map, they should be:
1. Explicitly listed in the `nav` configuration in `docs.config.ts`, OR
2. Reference a `group` slug that is recognized in the nav hierarchy (for legacy pages)

The `nav` config should be the primary place where documentation structure is defined.
