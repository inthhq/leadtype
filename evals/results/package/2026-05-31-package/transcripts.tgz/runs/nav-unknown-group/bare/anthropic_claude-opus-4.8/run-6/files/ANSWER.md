# Navigation in leadtype: `docs.config.ts` vs. page `group` frontmatter

A quick framing note before the answers: in leadtype these two pieces are **not** a
"new curated nav replacing a legacy field." They are two halves of one contract, and
neither is deprecated. `docs.config.ts` is the curated *declaration* of the groups
(their identity, order, titles, descriptions, and nesting), while each page's `group`
frontmatter field is the *membership claim* that says which of those groups a page
belongs to. The two are joined by a build-time **group resolver**.

## 1. Relationship: which one drives the sidebar and agent map, and what is the other good for?

Both are required to produce navigation — they answer different questions, so neither
alone "drives" it. But if you have to assign roles:

- **The page `group` frontmatter field is what actually populates the sidebar and the
  agent map (AGENTS.md).** The resolver reads every page's `group:` slug and slots that
  page into the tree. The same `group:` string is the single source of truth that drives:
  - the **sidebar position**,
  - the **`llms.txt` section** the page lands in,
  - **search metadata / the search-filtering UI**, and
  - the **`AGENTS.md` grouping** (the agent map shipped in `--bundle` mode).

  In other words, membership is page-level. A page with no `group` is excluded from the
  nav, the grouped indexes, and AGENTS.md sections (it still appears in generated
  markdown and the root `llms-full.txt` fallback).

- **`docs.config.ts` is what the *other* part is good for: curating how those groups are
  presented.** It declares each group **once** and supplies the things frontmatter
  cannot express on its own:
  - stable **order** of groups,
  - human-readable **group titles**,
  - group **descriptions** (which agents read to decide what to load — these matter for
    routing, not flavor text),
  - **nested groups** via `children` (only leaf groups hold pages; non-leaf groups are
    headings only), and
  - product metadata, best starting points, and agent guidance.

So: the page `group` field decides *which pages go where*; `docs.config.ts` decides
*what the groups are called, in what order, and how they nest*. Because both the CLI and
the library helpers (`resolveDocsNavigation`, `source.getNavigation()`, the `llms.txt`
generator, and the `AGENTS.md` generator) read the **same** `docs.config.ts`, the
sidebar, `llms.txt` sections, and the agent map all agree — one source of truth, no
drift. (If sidebar order and `llms.txt` ever disagree, it's because the app and the CLI
loaded *different* config files.)

Worth knowing: `docs.config.ts` is technically *optional*. With no config file, the CLI
**infers** groups from the union of `group:` values it finds, sorts them alphabetically,
and title-cases them. That fallback is fine for small docs sets, but you lose stable
order, descriptions, and nesting — which is exactly why you keep the curated config.

## 2. What happens at build time if a page declares a `group` the config doesn't know about?

**The build fails — by design.** During `leadtype generate`, after frontmatter is parsed
and pages are converted to markdown, the third pipeline stage resolves groups and
**validates that every page's `group:` matches a known slug** in `docs.config.ts`. If a
page names a slug the config doesn't declare, generation aborts with an error of the form:

```
error: <urlPath> declares unknown group "<slug>".
```

Concretely:

- The `leadtype generate` CLI exits with **code `1`** (runtime error; "unknown group" is
  explicitly listed alongside missing docs dir, config load error, and conversion error).
- Custom build scripts that call the lower-level APIs get the same behavior: helpers like
  `resolveDocsNavigation` surface the unknown slug so the script can write the
  `unknown group "<slug>"` error to stderr and fail fast — the recommended pattern so a
  bad config can't ship in a bundle.

The rationale stated in the docs: a `group` that points at a nonexistent slug is a
**content/navigation bug**, not a render-time problem, so leadtype treats it as a hard,
noisy failure at generate time (and CI catches it) rather than silently dropping the page
or producing a broken sidebar.
