# Navigation in leadtype: config `groups` vs. page `group`

## 1. Relationship — who drives the sidebar and agent map?

`docs.config.ts` exports a curated **`groups`** array (via `defineDocsConfig`). Each entry declares a group `slug`, `title`, optional `description`, and optional nested `children`. That config is the **single source of truth** for the *shape* of the navigation tree: it decides which groups exist, how they are labeled, and how they nest.

A page opts into those groups by declaring one or more slugs in its frontmatter **`group:`** field:

```mdx
---
title: "My page"
group: guides
---
```

- **The config drives the structure** of the sidebar and agent map (`llms.txt` sections, `AGENTS.md` grouping, search metadata).
- **The frontmatter `group:` field drives membership** — it decides which pages appear under which groups.

The final output is the *intersection* of the two:

- A group only appears if it is defined in `docs.config.ts`.
- A page only appears under a group if its frontmatter names that group’s slug.
- Pages with **no `group:`** are excluded from the nav and grouped indexes, but they are still converted to markdown and included in the root `llms-full.txt` fallback.

### What is the frontmatter `group:` still good for?

Even though the config owns the structure, the page-level `group:` field is still essential for three things:

1. **Self-declaring placement** — authors choose a page’s nav bucket without editing the config.
2. **Cross-listing** — a page can belong to multiple groups (`group: [guides, reference]`).
3. **Fallback inference** — if you omit `docs.config.ts`, the CLI infers groups from the `group:` values it finds, which is enough for small docs sets.

> **Note:** The installed leadtype package (v0.1.2) documents `group:` as the current standard frontmatter field, not a legacy one. It works in tandem with the `groups` array in `docs.config.ts`.

## 2. What happens at build time with an unknown group?

If a page declares a `group:` slug that is **not** present in `docs.config.ts`, the build **fails hard** during group resolution — before any artifacts are written. The error looks like this:

```
/docs/<page-path> declares unknown group "<slug>"
```

This is by design. leadtype treats broken navigation as a content bug rather than a silent runtime issue, so there is no auto-creation of missing groups or quiet omission.
