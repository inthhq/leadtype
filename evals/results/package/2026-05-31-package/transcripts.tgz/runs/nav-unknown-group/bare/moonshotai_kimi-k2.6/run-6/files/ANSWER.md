# Navigation in leadtype: config groups vs. page `group` frontmatter

> Quick clarification on terminology: `docs.config.ts` exports `defineDocsConfig({ groups: [...] })`. The config field is **`groups`**, and the result of resolving those groups against page frontmatter is the **navigation manifest** (e.g. `docs-nav.json`). The questions below use "nav" to refer to that curated config structure.

## 1. Which drives the sidebar and agent map?

**They work together, but the config is the source of truth.**

- **`docs.config.ts` `groups`** — Defines the curated structure: which groups exist, their display titles, descriptions, order, and nesting (via `children`). This is the authoritative list of valid group slugs.
- **Page `group` frontmatter** — Declares membership: `group: <slug>` (or `group: [a, b]`) opt a page into one or more config groups.

The sidebar, `llms.txt` sections, `AGENTS.md` grouping, search metadata, and the `resolveDocsNavigation()` manifest are all built from the **intersection** of the two:

```
config groups  +  page frontmatter group  →  navigation tree
```

- The config provides the **shape** (sections and hierarchy).
- Frontmatter provides the **placement** (which pages live in which sections).

**What happens if a page has no `group`?**  
It is **excluded from the sidebar and grouped indexes**, but it is still converted to markdown and included in the root `llms-full.txt` fallback. So `group` is still the gate for nav inclusion.

**What is the config still good for on its own?**  
Even if every page had `group`, the config controls **stable ordering**, **nested sub-groups**, and **group-level metadata** (title, description) that would otherwise be inferred from raw slugs. Without a config, leadtype falls back to inferring flat groups from frontmatter values—enough for small docs sets, but not for curated hierarchy.

## 2. What happens if a page declares an unknown `group` slug?

**The build fails.**

At group-resolution time (step 3 of `leadtype generate`), the resolver compares every page's `group` value against the slugs declared in `docs.config.ts`. If a page references a slug that the config does not know about, the CLI throws an error and exits non-zero:

```
/docs/my-page declares unknown group "missing-slug"
```

This is intentional: leadtype treats broken navigation as a **content bug**, not a render-time problem, so that the config stays a single source of truth and nav cannot drift from the filesystem.
