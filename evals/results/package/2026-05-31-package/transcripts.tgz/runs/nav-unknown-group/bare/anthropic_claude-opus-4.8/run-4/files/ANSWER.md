# Navigation in leadtype: curated `nav` vs. per-page `group`

Short version: the **curated structure declared in `docs.config.ts` is the single
source of truth** for the navigation tree, while a page's `group` frontmatter
field is just the *membership pointer* that slots each page into that structure.
They are two halves of one system, not competing ones.

## 1. Relationship between `docs.config.ts` and a page's `group` frontmatter

leadtype resolves navigation by combining two inputs:

- **`docs.config.ts` (`groups`)** — the curated declaration. Each group is
  declared *once* here with its `slug`, `title`, ordering, descriptions, and any
  nested `children`. This is where the tree's *shape and order* live. The same
  config also carries the `product` block used by the LLM artifacts.
- **A page's `group` frontmatter** — a slug (or array of slugs, e.g.
  `group: [a, b]`) that says *which* declared group(s) the page belongs to. It
  contributes membership, not structure.

A "group resolver" intersects the two: it takes the curated groups from the
config and the `group:` membership from each page's frontmatter and produces the
**navigation tree / manifest** (via `resolveDocsNavigation()` /
`source.getNavigation()`).

### Which one drives the sidebar and the agent map?

The **curated `groups` in `docs.config.ts` drives the structure** — the order of
sections, their titles, descriptions, and nesting. That single resolved tree
then feeds *everything*:

- the website sidebar (through the navigation manifest / `docs-nav.json`),
- the `## section` headings and ordering in `llms.txt`,
- the section grouping in the package-bundled `AGENTS.md` (the "agent map"),
- search metadata and any search-filtering UI.

Because the same config feeds both the sidebar and the LLM/`AGENTS.md` output,
the sidebar and the agent map stay in agreement. (The docs explicitly note that
if your sidebar order and `llms.txt` order disagree, it's because the app and the
CLI loaded *different* `docs.config.ts` files — centralize one config and import
it in both.)

### What is the other field (`group`) still good for, then?

`group` is still doing essential, non-redundant work — it's the per-page
*placement* signal:

- It declares **membership**: which curated group(s) a given page lands in
  (including landing in a nested/leaf group, and being shared across multiple
  groups via an array).
- Pages **without** a `group` are intentionally excluded from the nav tree and
  grouped indexes, yet they are *not* lost: their flattened markdown is still
  generated and they still appear in the root `llms-full.txt` fallback. So
  omitting `group` is a deliberate "exists, but not in the curated nav" state.
- The same `group` slug a page declares is what ties that page into the sidebar
  position, the `llms.txt` section, search metadata, `AGENTS.md` grouping, and
  cross-framework link checks in lint — one field, reused everywhere.

So: **`docs.config.ts` owns the curated structure (order, titles, descriptions,
nesting); `group` frontmatter owns each page's membership in that structure.**
Neither replaces the other.

> Fallback note: if there is *no* `docs.config.ts`, the CLI infers groups from
> the `group:` values it finds. That's fine for small docs sets, but you lose
> stable ordering, group descriptions, and nested groups — which is exactly the
> value the curated config adds.

## 2. What happens at build time if a page declares an unknown `group` slug?

**The build fails, by design.** During `leadtype generate`, group resolution runs
as a fixed stage (after frontmatter parsing and markdown conversion, before the
LLM/site artifacts). At that stage leadtype validates every page's `group:`
against the slugs declared in `docs.config.ts`. If a page declares a slug the
config doesn't know about, the run errors out with a message of the form:

```
error: <urlPath> declares unknown group "<slug>".
```

- The CLI exits non-zero (exit code `1`, the "runtime error" bucket that also
  covers a missing docs dir, config load errors, and conversion errors).
- `leadtype generate` "fails noisily on unknown groups," and the programmatic
  `resolveDocsNavigation()` surfaces the same problem via a populated
  `navigation.unknown` array (`{ urlPath, slug }`), which callers typically use
  to print the error and `process.exit(1)`.

The rationale stated in the docs: a broken `group` slug is a **content bug, not a
render-time problem**, so leadtype treats config + frontmatter as the same source
of truth and refuses to ship navigation that would silently drift. To catch it
earlier, run `leadtype lint` in CI before `generate` (note: lint covers
schema/link rules; the unknown-group failure itself happens at generate/resolve
time).

---

### Sources (bundled leadtype docs)

- `node_modules/leadtype/docs/authoring/frontmatter.md` — group semantics, the
  resolver diagram, the `unknown group "<slug>"` failure, and the
  no-config fallback.
- `node_modules/leadtype/docs/how-it-works.md` — the "What runs when" stage list
  (step 3 resolves/validates groups; unknown group fails the run) and the
  `group` vocabulary entry.
- `node_modules/leadtype/docs/reference/llm.md` — `resolveDocsNavigation`,
  `navigation.unknown`, and how the same groups drive `llms.txt` / `AGENTS.md`.
- `node_modules/leadtype/docs/reference/cli.md` — exit code `1` includes
  "unknown group".
- `node_modules/leadtype/docs/build/validate-in-ci.md` — generate "fails noisily
  on unknown groups."
