# Navigation in leadtype: curated `nav` vs. page `group`

Short version: there is **one source of truth for structure** — the curated
group tree declared in `docs.config.ts`. A page's `group:` frontmatter field
only *points into* that tree; it doesn't define structure on its own. If a
page points at a slug the config has never heard of, the build fails by design.

References (read offline from the installed package):
`node_modules/leadtype/docs/authoring/frontmatter.md`,
`node_modules/leadtype/docs/how-it-works.md`,
`node_modules/leadtype/docs/reference/llm.md`.

---

## 1. Relationship between curated `nav`/`groups` and the page `group` field

Think of it as **a declaration in config + a reference in each page**:

- **`docs.config.ts` declares the tree (the curated `nav`).** Each group is
  declared exactly once here, with its `slug`, `title`, ordering, optional
  descriptions, and any nested `children`. This is what defines the *shape* of
  navigation: section order, headings, nesting, and the group descriptions
  agents read to decide what to load. Only **leaf** groups (no children)
  directly contain pages; non-leaf groups are headings only.

- **A page's `group:` frontmatter is a pointer, not a definition.** It is a
  slug (or array of slugs, `group: [a, b]`, so a page can live in multiple
  groups) that must match a group already declared in the config. The build's
  "group resolver" takes the config tree plus every page's `group:` value and
  computes the resolved navigation manifest, mapping each page into its slot.

### Which one drives the sidebar and agent map?

**The config-declared group tree is the source of truth that drives structure**
— the sidebar order/nesting, the `llms.txt` section layout, search metadata,
and the `AGENTS.md` grouping (the "agent map"). The resolver
(`resolveDocsNavigation` from `leadtype/llm`, also exposed via
`createDocsSource().getNavigation()`) produces a single navigation manifest from
that tree, so your sidebar component and your `llms.txt`/`AGENTS.md` sections all
agree on one structure ("same source of truth, no drift").

### So what is the page `group` field still good for?

The `group:` field is still the per-page **membership/placement signal** — it's
how each individual page declares *where it belongs* in that curated tree. The
config supplies the skeleton; the field is how a page claims its spot (and can
claim multiple spots). Concretely, that one field per page drives:

- the page's sidebar position,
- which `llms.txt` section it appears under,
- its search metadata / AGENTS.md grouping,
- search-filtering UI facets and cross-framework link checks in lint.

It also has a meaningful **absence** behavior: a page with **no** `group`
is excluded from the nav tree and grouped indexes, but is still converted to
markdown and still appears in the root `llms-full.txt` fallback. So omitting
`group` is the supported way to ship a page that exists as content without
placing it in navigation.

> Note on terminology: leadtype calls the config the `groups` tree rather than a
> field literally named `nav`. If your project's `docs.config.ts` exposes a
> `nav` field, it's the same idea — the curated, ordered group/section tree the
> resolver consumes. (There is a separate, unrelated `nav.sidebar` / `nav.label`
> / `nav.mode` set of optional per-page lint fields used purely as UI hints;
> those don't define the structure.)

> Fallback worth knowing: if there is **no** `docs.config.ts`, the CLI infers
> groups from the `group:` values it finds. That's fine for small docs sets, but
> you lose stable order, descriptions, and nested groups — which is exactly why
> the curated config is the recommended source of truth.

---

## 2. What happens at build time if a page declares an unknown `group` slug?

**The build fails.** When `leadtype generate` runs, step 3 of its fixed pipeline
resolves groups from frontmatter and *validates that every page's `group:`
matches a known slug declared in `docs.config.ts`*. If a page declares a slug
the config doesn't know about, the run errors with:

```
unknown group "<slug>"
```

This is intentional: per the docs, "broken navigation is a content bug, not a
render-time problem," so it's caught at build time rather than silently
producing a page that's missing from the sidebar and agent map.

If you drive navigation yourself via the library API
(`resolveDocsNavigation`), the unknown slugs don't throw silently — they come
back in a `navigation.unknown` array of `{ urlPath, slug }` entries, and the
documented pattern is to print each one and `process.exit(1)`:

```ts
const navigation = await resolveDocsNavigation({
  srcDir: ".",
  baseUrl: "https://example.com",
  groups: docsConfig.groups,
});

if (navigation.unknown.length > 0) {
  for (const { urlPath, slug } of navigation.unknown) {
    process.stderr.write(`error: ${urlPath} declares unknown group "${slug}".\n`);
  }
  process.exit(1);
}
```

You can also catch this earlier than the build: `leadtype lint`'s schema/nav
checks surface frontmatter and navigation problems in CI so a bad `group:` fails
the PR before it ever reaches a build.
