# Navigation in leadtype — `docs.config.ts` vs. frontmatter `group`

> Based on the installed `leadtype` package (v0.1.2) docs and source.

## 1. Relationship between config groups and frontmatter `group`

In leadtype, `docs.config.ts` exports a **curated `groups` array** (via `defineDocsConfig`).  The frontmatter `group` field is **not legacy** — it is the active membership mechanism that works together with that config.

* **What drives the sidebar and agent map:** the **`groups` array in `docs.config.ts`** is the source of truth for *structure*. It defines which groups exist, their order, titles, descriptions, and nesting. This group tree drives the sidebar, `llms.txt` sections, search metadata, and `AGENTS.md` grouping.
* **What the frontmatter `group` is still good for:** it declares *membership*. A page uses `group: <slug>` (or `group: [a, b]` to belong to multiple groups) to say “put me in that curated group.” The intersection of the config’s `groups` and the page’s `group` frontmatter produces the final navigation tree. Pages without a `group` are excluded from the nav and grouped indexes, but they are still converted to markdown and included in the root `llms-full.txt` fallback.

In short: **config `groups` = the map; frontmatter `group` = the pin on the map.**

## 2. Unknown `group` slug at build time

If a page declares a `group` slug that the config does **not** know about, the build **fails** with an error such as:

```
<urlPath> declares unknown group "<slug>"
```

This is by design. The docs state:

> “If a page declares a group slug that isn't in `docs.config.ts`, the build fails with `unknown group "<slug>"`. Same source of truth, no drift.”

And the CLI source (`cli.js`) explicitly throws on the first unknown group it encounters. Broken navigation is treated as a **content bug**, not a render-time problem.
