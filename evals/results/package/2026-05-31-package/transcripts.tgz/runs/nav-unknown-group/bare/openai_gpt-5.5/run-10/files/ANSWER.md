# Leadtype navigation notes

1. The curated navigation declared in `docs.config.ts` is the source of truth for the generated navigation surfaces. It is what should drive the runtime sidebar/navigation manifest and the agent-facing map/indexes such as `llms.txt`/`AGENTS.md`.

   A page's `group` frontmatter is legacy page metadata. Keep it when you need backwards compatibility, search/filter metadata, linting/migration signals, or fallback behavior in older/no-curated-nav setups, but do not treat it as the thing that orders or places pages in the curated sidebar/agent map when `docs.config.ts` navigation exists.

2. Leadtype validates legacy `group` slugs against the groups/slugs known to the config. If a page declares a `group` slug that the config does not know about, the build fails fast with an `unknown group "<slug>"`-style error. It does not silently create a new group, ignore the typo, or ship a drifted navigation map.
