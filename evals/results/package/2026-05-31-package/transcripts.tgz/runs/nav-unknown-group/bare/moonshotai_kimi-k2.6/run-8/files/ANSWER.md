# Navigation in leadtype: config groups vs. page `group`

> Note: In leadtype the config field is named **`groups`** (inside `docs.config.ts`). If your project refers to it as `nav`, the behavior described below is the same — `docs.config.ts` owns the curated structure, and pages declare membership via frontmatter.

## 1. Which drives the sidebar and agent map?

The **curated `groups` array in `docs.config.ts`** is the source of truth. It declares:

- Which groups exist (slugs, titles, descriptions)
- Their order in the sidebar
- Their nesting hierarchy (`children`)

The page-level **`group` frontmatter** is **not legacy** in current leadtype — it is the active membership signal. Each page uses it to declare which group(s) it belongs to:

```mdx
---
group: authoring        # single group
group: [authoring, api] # multiple groups
---
```

**How they relate:**
- **`docs.config.ts` drives structure** — the sidebar, `llms.txt` sections, `AGENTS.md` grouping, and search metadata all derive their shape from the config's `groups` tree.
- **Page `group` drives placement** — it determines which leaf group(s) the page lands in. The build intersects config groups + page frontmatter to produce the final nav tree.
- Pages without a `group` are **excluded from the nav and grouped indexes**, but they are still converted to markdown and included in the root `llms-full.txt` fallback.

If you need one concise answer: **the config drives the sidebar and agent map; the page `group` frontmatter is what still fills that structure with pages.**

## 2. What happens if a page declares an unknown `group` slug?

The build **fails with a hard error**.

During `leadtype generate`, the pipeline calls `resolveDocsNavigation`, which collects any page whose `group` slug does not match a group declared in `docs.config.ts`. If it finds any, the CLI throws immediately:

```
{urlPath} declares unknown group "{slug}"
```

This is intentional — leadtype treats mismatched groups as a **content bug, not a render-time problem** ("same source of truth, no drift"). If you delete or rename a group in `docs.config.ts` without updating the corresponding page frontmatter, the build breaks so the issue surfaces in CI rather than silently orphaning pages.

If you do not have a `docs.config.ts` at all, the CLI falls back to inferring groups from the union of all `group:` values it finds in your pages, sorting them alphabetically and title-casing them. That fallback works for small docs sets, but once you need stable order, nested groups, or custom titles, you should use `docs.config.ts` and accept the hard validation that comes with it.
