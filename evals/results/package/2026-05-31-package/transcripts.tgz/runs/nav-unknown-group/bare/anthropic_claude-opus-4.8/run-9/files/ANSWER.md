# Navigation in leadtype: curated `nav` vs. legacy `group` frontmatter

> Sourced from the version-matched docs in `node_modules/leadtype/` — chiefly
> `docs/authoring/frontmatter.md`, `docs/how-it-works.md`, and
> `docs/reference/llm.md`.

## 1. Relationship between the curated config groups (`nav`) and a page's `group` frontmatter

These two things are **two halves of one contract**, joined by the group resolver
at build time. They are not redundant copies of the same data:

- **The curated structure in `docs.config.ts` is the single source of truth for
  structure.** It declares each group **once** — its slug, title, description,
  order, and any nested `children`. This is what actually *drives* the rendered
  output:
  - the sidebar / navigation tree (via `resolveDocsNavigation`, written to
    something like `src/generated/docs-nav.json` for your sidebar component),
  - the section headings and ordering in `llms.txt`,
  - the section grouping in the bundled `AGENTS.md` (the "agent map"),
  - and search metadata / facets.

  Because the config owns order, descriptions, and nesting, it is what gives you
  stable, intentional structure. Group descriptions here are read by agents to
  decide which page to load, so they're routing instructions, not flavor text.

- **A page's `group` frontmatter field is just a *membership pointer*, not a
  structure definition.** It's the slug (or list of slugs — `group: [a, b]`) of a
  group already declared in the config, saying "this page belongs in that slot."
  It does **not** invent the group, set its title, or determine its position.

So the **resolver intersects** the two: config groups provide the skeleton, and
each page's `group` value drops the page into the matching leaf. Only **leaf**
groups (no children) directly hold pages; non-leaf groups are headings only.

**Which one drives the sidebar and agent map?** The curated config groups drive
the actual tree, ordering, and the `AGENTS.md` agent map. The `group` frontmatter
field only decides *which* config-defined slot a given page lands in.

**What is the other (the `group` field) still good for?** Per-page placement and
the things keyed off membership: it's the one string that simultaneously assigns
a page's sidebar position, its `llms.txt` section, its search metadata, and its
`AGENTS.md` section. It also enables sharing a page across multiple groups
(`group: [a, b]`), and it participates in lint (e.g. cross-framework link
checks). Pages with **no** `group` are excluded from the nav and the grouped
indexes, but they are *not* lost — they still get a generated `.md` file and are
captured by the root `llms-full.txt` fallback.

> Note on the "config" form: if you have **no** `docs.config.ts`, the CLI falls
> back to *inferring* groups from whatever `group:` values it finds. That's fine
> for small docs sets, but you lose stable order, descriptions, and nesting — the
> exact things the curated config exists to provide. Hence "one field, one source
> of truth": authors write `group` per page; the config owns the structure those
> slugs resolve into.

## 2. What happens at build time if a page declares an unknown `group` slug

**The build fails — by design.**

`leadtype generate` runs in a fixed order, and step 3 is "resolve groups from
frontmatter and validate every page's `group:` against a known config slug." If a
page declares a `group` slug that `docs.config.ts` doesn't know about, the run
**fails with an error like `unknown group "<slug>"`**. The docs frame this as a
deliberate choice: "broken navigation is a content bug, not a render-time
problem," and keeping config + frontmatter as the same source of truth means
"no drift."

If you call the library directly instead of the CLI, `resolveDocsNavigation`
surfaces the same problem as data rather than throwing: it returns a
`navigation.unknown` array listing each `{ urlPath, slug }` with an unknown
group, and the documented pattern is to print those and `process.exit(1)` — i.e.
you still fail the build.

A couple of clarifying boundaries:

- This unknown-group failure is a **generate/resolve-time** check, not a
  `leadtype lint` rule. `lint`'s frontmatter rules validate that `group` is a
  *string or string array* (the `schema` rule), but the "does this slug exist in
  the config" enforcement happens during group resolution in the build.
- A page with **no** `group` at all is not an error — it's simply omitted from
  navigation/grouped indexes while still being converted to markdown and included
  in `llms-full.txt`. The failure is specifically about declaring a slug the
  config can't match.
