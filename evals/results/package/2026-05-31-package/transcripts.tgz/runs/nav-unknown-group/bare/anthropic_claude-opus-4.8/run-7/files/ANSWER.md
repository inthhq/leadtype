# Navigation in leadtype: `nav`/groups config vs. page `group` frontmatter

## 1. Relationship between curated config and the page `group` field

leadtype uses **one source of truth, split across two places**, and the two are *complementary*, not competing:

- **The curated config (`docs.config.ts`)** declares the *set* of groups: each group's
  `slug`, `title`, optional `description`, ordering, and nesting (via `children`). This is
  what *defines the structure* — the stable, ordered, optionally-nested tree.
- **A page's `group` frontmatter field** is just a *slug (or list of slugs)* that says
  "this page belongs in that declared group." A page can declare one slug
  (`group: reference`) or several (`group: [a, b]`) to appear in multiple groups.

### Which one drives the sidebar and the agent map?

**Both, working together — the config decides shape, the page `group` decides membership.**

At build time the **group resolver** takes the groups declared in `docs.config.ts` and the
`group:` values on each page, intersects them, and that resolved tree drives *all* of:

- the **sidebar** / navigation tree (`resolveDocsNavigation()` → the `docs-nav.json` manifest),
- the **section headings in `llms.txt`** (site mode),
- **`AGENTS.md` grouping** (bundle mode — the agent map),
- search metadata / facets, and cross-framework link checks in lint.

So neither field alone "drives" navigation: the **config controls order, titles,
descriptions, and nesting** (the shape of the sidebar and agent map), while the **page's
`group` field controls which group each page lands in** (membership). Same string, one
source of truth, no drift.

> Note: if there is **no** `docs.config.ts`, the CLI *infers* groups from whatever `group:`
> values it finds. That fallback works for small docs sets, but you need the config when you
> want stable order, group descriptions, or nested groups. Only **leaf** groups (no children)
> directly contain pages; non-leaf groups are headings only.

### What is the *other* one still good for?

The page `group` field is still essential — it's the membership pointer that places the page.
But note what a page **without** any `group` is still good for: ungrouped pages are
**excluded from the nav and the grouped indexes (sidebar, `llms.txt` sections, AGENTS.md
grouping)**, yet they are **still converted to markdown** and **still included in the root
`llms-full.txt` fallback**. In other words, omitting `group` removes a page from the curated
navigation without removing it from the generated/agent-readable output.

## 2. What happens at build time if a page declares an unknown group slug?

**The build fails — by design.**

`leadtype generate` runs in a fixed order. After parsing frontmatter (step 1) and converting
each file to markdown (step 2), step 3 **resolves groups and validates that every page's
`group:` matches a known slug from the config**. If it finds a slug the config doesn't know
about, the run **fails with `unknown group "<slug>"`**.

- The CLI exits with **code `1`** (runtime error — same class as a missing docs dir or a
  config load error).
- When you drive the pipeline with the library APIs directly,
  `resolveDocsNavigation()` reports these in `navigation.unknown` (each entry has
  `{ urlPath, slug }`), so a build script can print
  `error: <urlPath> declares unknown group "<slug>".` and `process.exit(1)` — "fail fast so
  a bad config can't ship."

The rationale: **broken navigation is treated as a content bug, not a render-time problem**,
so it's surfaced loudly at generate time rather than producing a silently broken sidebar/agent
map. (CI typically runs `leadtype lint` too, but the hard stop on an unknown group is enforced
by `generate` itself.)
