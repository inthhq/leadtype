# Leadtype navigation and legacy `group`

1. The curated `nav` in `docs.config.ts` is the canonical source for the reader-facing sidebar and the agent-facing documentation map. It controls the structure, order, nesting, and which pages are surfaced there. A page's frontmatter `group` is legacy page metadata: useful for compatibility with older group-based leadtype tooling, search/filter facets, or other custom classification, but it should not be treated as the thing that places a page in the sidebar when curated nav is configured.

2. Leadtype still validates declared `group` slugs against the configured set. If a page says `group: some-slug` and that slug is not known to the config, the build fails fast with an unknown-group error naming the page and slug, rather than silently treating the page as ungrouped or inventing a new section. Fix it by adding the slug to the config or updating/removing the page's `group` value.
