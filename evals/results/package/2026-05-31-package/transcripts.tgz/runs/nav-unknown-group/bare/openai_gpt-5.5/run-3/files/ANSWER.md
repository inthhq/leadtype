# Leadtype navigation and legacy `group`

1. The curated `nav` in `docs.config.ts` is the source of truth for the docs structure. It is what should drive the website sidebar and the agent-facing documentation map/index. A page's frontmatter `group` field is legacy metadata: useful as a compatibility/categorization hint for older tooling, search/filtering, or linting/migration checks, but it should not be treated as the thing that places a page in the sidebar when a curated config nav exists.

2. Build-time validation still checks `group` values against the groups known to the config. If a page declares a `group` slug that is not declared/known in `docs.config.ts`, the build fails fast with an unknown-group error (for example, `... declares unknown group "<slug>"`) rather than silently inventing a new section or ignoring the mismatch.
