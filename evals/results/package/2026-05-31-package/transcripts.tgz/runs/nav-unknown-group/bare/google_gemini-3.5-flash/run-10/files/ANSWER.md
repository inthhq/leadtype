# Navigation and Grouping in Leadtype

Here are the answers to your onboarding questions regarding navigation and grouping in Leadtype.

---

### 1. Relationship Between the Curated `groups` in `docs.config.ts` and a Page's `group` Frontmatter

In Leadtype, navigation is not hardcoded per page. Instead, it is a unified intersection between a global blueprint and decentralized content annotations.

* **The Relationship**: 
  * `docs.config.ts` defines the **curated structural blueprint** (via the `groups` array of `DocsGroup` objects). It specifies the hierarchy, stable sorting order, display titles, nested (parent/child) grouping structures, and agent-readable descriptions of the navigation categories.
  * A page's frontmatter `group` field acts as a **decentralized membership tag** (e.g., `group: guides` or `group: [setup, reference]`). It declares which slot(s) in the global structural blueprint the page belongs to.
  * At build or resolve time (via `resolveDocsNavigation`), Leadtype intersects these two sources of truth to assemble the final navigation manifest.

* **Which One Drives the Sidebar and Agent Map**:
  * **The curated config (`docs.config.ts`)** drives the actual structural outline, nesting, descriptions, and ordering of both the user-facing sidebar and the agent map (i.e. section headings in `llms.txt`, `AGENTS.md`, search metadata, and sitemaps).
  * However, **neither works in isolation**—the final tree is built from their intersection. The config dictates *where* the sections go and *how* they are described, while the page frontmatter dictates *which* documents populate those sections.

* **What is the Other Still Good For**:
  * **Page-level `group` frontmatter** is still essential for:
    1. **Page Membership Assignment**: Letting content authors place files in the sidebar directly from the MDX source without editing a central routing file.
    2. **Multi-group Sharing**: A page can declare multiple groups (e.g., `group: [tutorial, reference]`) to be mirrored across different sidebar and agent map sections.
    3. **Exclusion / Fallback Control**: Pages without a `group` are cleanly excluded from the navigation tree/sidebar/sitemap, but are still compiled into static HTML/Markdown and included in the broad root-level `llms-full.txt` fallback context file.
    4. **CI Validation**: Linting tools use it to perform cross-framework and URL mapping checks.
  * **Global `groups` config (`docs.config.ts`)** is essential for:
    1. **Ordering & Metadata**: Enforcing custom display titles, category order (instead of default alphabetical), and adding descriptions for AI/crawlers.
    2. **Nesting**: Specifying parent-child categories (nested groups), where only leaf groups can directly hold pages.

---

### 2. Build-Time Behavior When a Page Declares an Unknown `group` Slug

If a page's frontmatter references a `group` slug that is not declared in `docs.config.ts`, the build pipeline strictly prevents drift with the following sequence:

1. **Resolution**: During the generation process (specifically inside the `resolveDocsNavigation` helper), Leadtype walks the filesystem and parses the frontmatter of every page.
2. **Identification**: Any page specifying a `group` slug that is absent from the `groups` array defined in the configuration is added to a special `navigation.unknown` list, with entries mapped to `{ urlPath, slug }`.
3. **Failure in Build**: The CLI command `leadtype generate` checks if `navigation.unknown` contains any elements. If it detects even a single unknown group, the build fails immediately.
4. **Error Output**: It throws a descriptive error and halts execution:
   ```
   <urlPath> declares unknown group "<slug>"
   ```
5. **Exit Code**: The CLI exits with a non-zero code (`1` or `2`), failing the CI pipeline.

This strict validation design guarantees that content authors can never break website navigation, sidebar menus, or AI routing paths silently before publishing.
