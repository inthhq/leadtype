# Navigation in Leadtype: `nav` Config vs `group` Frontmatter

## 1. Relationship between `nav` config and `group` frontmatter

The **curated `nav` in `docs.config.ts` drives the sidebar and agent map**. This is the source of truth for the documentation structure and navigation.

The **`group` frontmatter field is a legacy field** that is still good for:
- **Backward compatibility**: Older pages may still declare a `group` field that was previously used for organization
- **Page metadata**: It can be retained for reference or custom rendering in specific contexts
- **Future migration flexibility**: It allows pages to maintain information about their intended grouping even if not actively used by the nav system

**Key distinction**: The sidebar and agent map are **built from the curated `nav` configuration**, not from individual page `group` declarations. The `nav` config provides the authoritative structure, while `group` is largely decorative or historical.

## 2. Build-time behavior for unknown group slugs

If a page declares a `group` slug that the config doesn't know about, **the build will likely complete successfully but with potential warnings or logging**. 

Here's what happens:

- **Build does not fail**: The presence of an unknown `group` slug in frontmatter does not cause a build error
- **Validation or warnings**: Depending on leadtype's configuration, unknown group slugs may trigger:
  - A console warning/error message during the build process
  - A validation step that logs unrecognized groups
  - Potentially strict mode settings that could treat it as an error
- **Navigation impact**: The page will still be included in the build, but may not appear in the correct sidebar location (or any sidebar location) since its declared group doesn't match a known config entry
- **Agent map impact**: Similarly, agent mapping may be incomplete or incorrect if the group relationship is unknown

**Best practice**: All pages should declare a `group` that maps to a `nav` entry in `docs.config.ts`, or the page's placement in `nav` should be explicitly configured to avoid ambiguity during the build process.
