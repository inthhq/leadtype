# Navigation in a leadtype project

## 1. `nav` in `docs.config.ts` vs. a page's `group` frontmatter

These two things are **the same source of truth working from opposite ends** — they are not competing systems, and one does not override the other. They are *joined* at build time.

- **`docs.config.ts` (the curated `nav`/`groups`) declares the structure.** It is where each group is declared exactly once: its `slug`, human `title`, optional description, stable ordering, and any nested `children`. This config is the canonical, hand-curated definition of *what groups exist and in what order they appear*. `leadtype generate` loads it automatically when present.

- **A page's `group` frontmatter declares membership.** Each `.mdx` page sets `group: <slug>` (or `group: [a, b]` to live in several groups) to say *which* of the config's groups it belongs to. The slug must match a group declared in the config.

**What actually drives the sidebar and the agent map:** the **intersection** of the two — the config's declared groups joined with each page's `group` membership. The group *resolver* takes `docs.config.ts` + the pages' `group:` values and produces, from a single pass:

- the navigation/sidebar tree (order and nesting come from the config),
- the section headings in `llms.txt`,
- the AGENTS.md section grouping (the "agent map"),
- search metadata / filtering facets,
- cross-framework link checks in lint.

So neither field alone "wins": **`docs.config.ts` owns the shape and ordering of the nav; the per-page `group` field owns each page's placement within that shape.** If you ask which is authoritative for the *taxonomy* (what sections exist, their titles, order, nesting), it's `docs.config.ts`.

**What the legacy `group` field is still good for** (beyond placement): it remains the single per-page knob that decides everything downstream of placement — sidebar position, the page's `llms.txt` section, AGENTS.md grouping, search facets, and cross-framework link checks. It is also the basis for the **config-less fallback**: if a project has *no* `docs.config.ts`, the CLI will *infer* the groups purely from the `group:` values it finds across pages. That fallback is fine for small docs sets, but you lose stable ordering, group descriptions, and nested groups — which is exactly what the curated config adds back. In short, the `group` frontmatter is "still good for" being the page-level membership signal and the low-config bootstrap path, while the curated config is what you graduate to for stable order, descriptions, and nesting.

## 2. What happens if a page declares a `group` slug the config doesn't know about?

**The build fails.** When `docs.config.ts` exists, every `group` slug a page declares must be one of the slugs declared in that config. If a page references a slug that isn't in the config, `leadtype generate` errors out with:

```
unknown group "<slug>"
```

This is intentional: the config and the pages share one source of truth, so a typo or a stale slug can't silently drift a page into a phantom section — it stops the build instead.

(Note the contrast with a missing/empty `group`: a page with *no* group isn't an error — it's simply excluded from the nav and grouped indexes, while still appearing in generated markdown and the root `llms-full.txt` fallback. An *unknown* group, however, is a hard failure. And if there is no `docs.config.ts` at all, there is nothing to be "unknown," so the CLI just infers groups from whatever `group:` values exist.)
