# Navigation vs. legacy `group`

1. **The curated `nav` in `docs.config.ts` is the source of truth for navigation.** It is what should drive the runtime sidebar and the agent-facing documentation map/AGENTS-style index. A page's frontmatter `group` is legacy metadata: it can still be useful for compatibility with older leadtype/group-based consumers, linting/migration context, search or faceted metadata, and as a lightweight label for pages, but it should not be treated as the thing that orders or curates the sidebar/agent map when `nav` exists.

2. **Unknown groups fail the build.** If a page declares `group: some-slug` and the loaded config does not declare/recognize `some-slug`, leadtype treats that as a content/config drift bug and stops generation with an `unknown group "some-slug"`-style error (CLI runtime failure, exit code 1). This prevents a stale frontmatter value from silently producing broken or misleading navigation artifacts.
