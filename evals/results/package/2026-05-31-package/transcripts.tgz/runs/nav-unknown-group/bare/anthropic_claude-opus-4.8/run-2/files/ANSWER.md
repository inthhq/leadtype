# Leadtype navigation: `docs.config.ts` groups vs. page `group` frontmatter

> A note on the premise: in leadtype these two things aren't a "new curated nav"
> replacing a "legacy `group` field." They are **two halves of one mechanism**
> that work together. `docs.config.ts` *declares* the groups (slug, title,
> order, nesting); the per-page `group:` frontmatter field *assigns* each page
> into one or more of those declared groups. Neither is deprecated. The answers
> below describe the real relationship.

## 1. Relationship, and which drives the sidebar / agent map

There is a single source of truth split across two files:

- **`docs.config.ts` — the group registry.** It declares each group **once**:
  its `slug`, human `title`, ordering, and any nested `children`. This is the
  curated structure: stable order, section titles, and the shape of the tree
  (including nested groups, where only **leaf** groups can hold pages and
  non-leaf groups are headings only).

- **Page `group:` frontmatter — the assignment.** Each page sets
  `group: <slug>` (or `group: [a, b]` to live in several groups). The slug must
  match a group declared in the config.

At build time the **group resolver** intersects these two inputs. The result of
that intersection is what drives *everything* structural:

- the **sidebar** position (the navigation tree / `docs-nav.json` manifest built
  by `resolveDocsNavigation()`),
- the **agent map**, i.e. the section grouping in the bundled **`AGENTS.md`** and
  the `## …` sections of **`llms.txt`**,
- search metadata / filtering and cross-framework link checks.

So the answer to "which one drives the sidebar and agent map" is: **both,
together** — but if you must name the one that *curates* (orders, titles, nests)
the tree, it's the **`nav`/`groups` declaration in `docs.config.ts`**. The page
`group:` field is the per-page pointer into that curated structure; it decides
*membership*, not *order or shape*.

What the page `group:` field is still good for (its distinct, ongoing job):

- It's the **per-page assignment** that places a page into one or more groups —
  the config can't know which pages belong where without it.
- Because a page can list **multiple** slugs, `group:` is how you **share a
  single page across several sections** of the nav.
- It also gates inclusion: a page with **no** `group:` is **excluded from the
  nav and grouped indexes**, while still being emitted as generated markdown and
  appearing in the root `llms-full.txt` fallback. So omitting `group:` is the
  intended way to keep a page readable but off the sidebar/agent map.
- If there is **no `docs.config.ts` at all**, the CLI falls back to *inferring*
  groups directly from the `group:` values it finds. That fallback is fine for
  small docs sets, but you lose stable ordering, descriptions, and nesting —
  which is exactly what the config exists to provide.

In short: **the config curates the tree; `group:` populates it.** Same source of
truth, no drift.

## 2. What happens at build time for an unknown `group` slug

**The build fails.** During `leadtype generate`, after frontmatter parsing and
markdown conversion, the **group-resolution step (step 3)** validates that every
page's `group:` slug matches a group declared in `docs.config.ts`. If a page
declares a slug the config doesn't know about, the run errors with:

```
unknown group "<slug>"
```

This is **by design** — leadtype treats broken navigation as a *content bug that
fails fast*, not a render-time surprise. Because group resolution runs before
the site-mode artifacts (`llms.txt`, `llms-full.txt`, search index, sitemap,
robots, agent-readability) and before bundle-mode `AGENTS.md`, an unknown group
stops the build before any of those outputs are written.

You can catch the same class of problem earlier in CI with `leadtype lint`
(`schema` / navigation checks), so a bad or missing `group:` surfaces on the PR
rather than at build time.
