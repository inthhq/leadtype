# Navigation in leadtype: config `groups` vs. frontmatter `group`

## 1. Relationship between curated config navigation and the frontmatter `group` field

In leadtype, `docs.config.ts` exports a curated **`groups`** array (the navigation tree) and each MDX page declares one or more **`group`** slugs in its frontmatter.

|  | `groups` in `docs.config.ts` | `group` in page frontmatter |
|---|---|---|
| **Purpose** | Defines the nav *structure*: order, titles, descriptions, nesting. | Declares a page’s *membership* in one or more groups. |
| **Drives sidebar & agent map?** | **Yes.** The config `groups` produces the sidebar tree, `llms.txt` sections, search metadata, and `AGENTS.md` grouping. | No. It only slots the page into the group(s) the config already defined. |
| **Multi-group?** | Groups are declared once. | A page can list multiple slugs (`group: [a, b]`) to appear in several groups. |
| **Fallback behavior** | If there is **no** `docs.config.ts`, the CLI infers a flat group list from the `group` values it finds in frontmatter. | Pages without a `group` are still converted, but are excluded from the nav and grouped indexes; they live only in the root `llms-full.txt` fallback. |

**Bottom line:** the curated `groups` array is the source of truth for *shape and order*; the frontmatter `group` is the per-page tag that says “put me here.” One sets the table, the other picks the seat.

## 2. Build-time behavior for an unknown `group` slug

If a page declares a `group` slug that does **not** exist in `docs.config.ts`, the build **fails**.

- `resolveDocsNavigation()` collects all unknown group references in `navigation.unknown`.
- The CLI then throws immediately:

  ```
  {urlPath} declares unknown group "{slug}"
  ```

- This is **intentional** — leadtype treats broken navigation as a content bug, not a runtime rendering issue. (`leadtype lint` does not currently flag unknown groups; the error surfaces during the generation/build step instead.)
