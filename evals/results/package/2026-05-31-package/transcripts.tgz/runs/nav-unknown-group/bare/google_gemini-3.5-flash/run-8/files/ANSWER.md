# Leadtype Navigation & Groups

Here are the answers to your questions about navigation in a `leadtype` project.

---

### 1. Relationship between curated `nav` in `docs.config.ts` and a page's legacy `group` frontmatter field

#### **The Relationship & Roles**
In a `leadtype` project, navigation is resolved via the intersection of the centralized config file and the page-level frontmatter:
* **The curated `nav` (or `groups` array) in `docs.config.ts`** serves as the **structural skeleton** for navigation. It declares the groups, nesting hierarchy (parent-child relationships), display titles, descriptions, and stable order.
* **The `group` frontmatter field** in individual page files (`.md`/`.mdx`) acts as the **association mechanism**, mapping that specific page to its corresponding group(s).

#### **Which one drives the sidebar and agent map?**
The **intersection of both** drives the sidebar, `llms.txt` sections, and the `AGENTS.md` map. 
* The **`docs.config.ts` curated config** drives the overall layout, stable sorting, nested hierarchy, and group metadata (titles/descriptions).
* The **page's `group` frontmatter field** drives the page's membership inside those group containers, populating them with actual pages.

#### **What is the page-level `group` frontmatter still good for?**
Even with a curated central config, the page-level `group` frontmatter field is essential for:
1. **Self-Contained Content:** Authors can manage page metadata inside the file itself rather than updating a monolithic central index for every new file.
2. **Page Sharing & Reuse:** A page can belong to multiple groups simultaneously by declaring an array of slugs (e.g., `group: [authoring, docs-site]`).
3. **Downstream Pipelines:** The same field is reused as a single source of truth across other features:
   * **Search Indexing & Filtering:** Drives search metadata and search facet filtering.
   * **Lint Validation:** Drives cross-framework link checks.
   * **Excluding Pages:** Omitting the `group` field excludes a page from sidebar navigation and group indexes while still keeping it in the full-context LLM fallbacks (like `llms-full.txt`).

---

### 2. What happens at build time if a page declares an unknown `group` slug?

If a page declares a `group:` slug that is not defined in `docs.config.ts`, the build system **fails fast and noisily**:

1. **Build Termination:** The generation/build process is immediately aborted.
2. **Error Message:** An error is printed to `stderr` pointing to the exact file and the unknown slug, for example:
   ```bash
   error: <urlPath> declares unknown group "<unknown-slug>".
   ```
3. **Exit Code:** The process exits with code `1` (runtime error). This ensures that any broken navigation or mistyped group configuration fails CI/CD pipelines immediately, preventing broken sites and drift from shipping to production.
