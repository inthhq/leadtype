# Navigation System in Leadtype

## Question 1: Relationship between curated `nav` and legacy `group` frontmatter

### What drives the sidebar and agent map?

The **curated `nav` in `docs.config.ts`** is the primary driver for:
- **Sidebar generation**: The nav structure defines the hierarchical organization of pages in the documentation sidebar
- **Agent map**: The nav configuration is used to build the agent map, which determines how documentation is organized for AI agents

### What is the legacy `group` field still good for?

The **`group` frontmatter field** in individual page files serves as a fallback mechanism and metadata source. It is still useful for:
- **Legacy compatibility**: Supporting older documentation that pre-dates the centralized nav config
- **Page metadata**: Providing context about a page's logical grouping even if the curated nav is the source of truth
- **Search and filtering**: Used by indexing and search systems to categorize content
- **Fallback organization**: If a page is not explicitly listed in the curated nav, its group frontmatter may determine how it's indexed or categorized in dynamic contexts

**In summary**: The curated `nav` is authoritative and drives the actual sidebar navigation and agent map, while `group` is legacy metadata that provides context and serves as a fallback.

## Question 2: Build-time behavior for unknown group slugs

### What happens if a page declares a `group` slug that the config doesn't know about?

At build time, if a page declares a `group` slug in its frontmatter that **is not defined** in the `docs.config.ts` configuration:

1. **No build error**: The build process typically does not fail or throw an error
2. **Orphaned categorization**: The page remains categorized under its declared group slug in the page metadata
3. **Sidebar exclusion**: The page will **not appear in the generated sidebar** since the nav config doesn't include this group
4. **Agent map exclusion**: The page may be **excluded or incorrectly indexed** in the agent map, as the agent map generation relies on the curated nav structure
5. **Runtime warnings**: Some builds may emit warning messages to alert developers that a page references an unknown group
6. **Accessible via direct URL**: The page remains accessible directly (if it's a valid route), but won't be discoverable through normal navigation

**Best practice**: Ensure all pages either use groups defined in `docs.config.ts` or are explicitly included in the curated nav structure. This prevents orphaned pages and ensures consistent navigation and agent indexing.
