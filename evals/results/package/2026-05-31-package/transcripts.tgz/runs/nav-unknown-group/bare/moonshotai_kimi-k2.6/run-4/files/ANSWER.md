# Navigation in leadtype

## 1. Config `groups` vs. page `group` frontmatter

In leadtype 0.1.2, `docs.config.ts` exports a `groups` array that acts as the **curated navigation tree**. It is the single source of truth for:

* sidebar structure (order, nesting, section headings)
* `llms.txt` sections
* `AGENTS.md` grouping
* search metadata

A page opts into that structure with the **`group` frontmatter field** (string or array). It is **not legacy** in this version — it is the mechanism that assigns page membership. A page can belong to multiple groups (`group: [a, b]`), and within a group you can control ordering with the `order` field.

So the relationship is:
* **`groups` in `docs.config.ts`** → drives the *shape* of the sidebar and agent map.
* **`group` frontmatter** → drives *which pages land in which slots*, plus ordering and lint-time cross-framework link checks.

## 2. Unknown `group` slug at build time

If a page declares a `group` slug that the config does not define, `leadtype generate` fails with a hard error:

```
<page-path> declares unknown group "<slug>"
```

This happens during group resolution (step 3 of the pipeline). It is intentional — broken navigation is treated as a content bug rather than a silent runtime omission.
