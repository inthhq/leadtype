# Navigation notes

1. The curated `nav` in `docs.config.ts` is the source of truth for the generated navigation: it drives the site/sidebar structure and the agent-facing map (`llms.txt` / `AGENTS.md` grouping and ordering). A page's `group` frontmatter is legacy metadata now. It is still useful as a compatibility/migration tag, for older integrations or tooling that still reads group membership, and as a lintable hint about the page's intended area, but it should not be treated as the thing that orders or builds the sidebar when curated `nav` is present.

2. Leadtype still validates legacy `group` values against the groups/slugs known to the loaded config. If a page declares a `group` slug the config does not know about, generation fails at build time with an `unknown group "<slug>"` style error. The slug is not silently inferred, ignored, or added to the nav; fix it by removing/updating the page's `group` or declaring the corresponding group in config.
