# Navigation in Leadtype: Config vs. Legacy Group Frontmatter

## 1. Relationship Between `nav` Config and Legacy `group` Frontmatter

### Which drives the sidebar and agent map?

The **curated `nav` in `docs.config.ts` drives both the sidebar and agent map** in leadtype. This is the authoritative source of truth for the site's information architecture.

The **legacy `group` frontmatter field is deprecated but still supported** for backward compatibility and serves two purposes:
- **Fallback grouping**: If a page's `group` slug matches a known group in the config's nav structure, it can be used as a convenience to indicate group membership without explicit configuration.
- **Semantic metadata**: The `group` frontmatter remains useful as page-level metadata that tools, scripts, or documentation pipelines might reference independently of the sidebar structure.

**In practice**: The config's `nav` is what actually controls rendering and organization. Pages are included in the sidebar only if they are explicitly referenced in the config's navigation structure, not merely because they declare a `group` frontmatter field.

---

## 2. Build-Time Behavior: Unknown Group Slugs

If a page declares a `group` slug in its frontmatter **that the config doesn't know about**:

**At build time, leadtype will raise an error or warning** indicating that a page references an unknown group. This is a validation step designed to catch configuration mismatches and ensure consistency.

**Behavior**:
- The build will either **fail** (strict mode) or **warn** (permissive mode, depending on configuration)
- The unknown group reference indicates a mismatch between the page's metadata and the site's declared navigation structure
- The page itself may still be buildable, but its group association is considered invalid/unresolved

This validation helps maintain data integrity by ensuring that all pages reference only groups that are actually defined in the navigation config. It prevents orphaned pages and ensures the agent map and sidebar generation have complete, valid information to work with.
