# Navigation System in Leadtype

## 1. Relationship between `nav` config and legacy `group` frontmatter

### Which one drives the sidebar and agent map?
The **curated `nav` in `docs.config.ts` drives the sidebar and agent map**. This is the authoritative configuration for how the documentation structure and navigation are presented to users.

### What is the legacy `group` field still good for?
The **legacy `group` frontmatter field is still useful for backward compatibility and for logical semantic grouping** of pages within the codebase. It can be used to:
- Maintain backward compatibility with older documentation setups
- Provide semantic metadata about page relationships for tools or scripts that may consume it
- Act as a fallback reference if you're migrating from a group-based structure to the curated nav approach
- Help developers understand the conceptual organization even if the sidebar presentation differs

**In summary**: `nav` config is the presentational layer (what users see), while `group` is legacy metadata (what still exists in the page's frontmatter).

## 2. What happens at build time if a page declares a `group` slug that the config doesn't know about?

If a page declares a `group` slug that is **not defined in the curated `nav` configuration**, the build process will **not error or fail**. Instead:

- **The page will still be processed and built** — it doesn't block the build
- **The `group` frontmatter is ignored by the navigation system** — since the sidebar and agent map are driven by the curated `nav`, an unknown group in the page's frontmatter has no effect on navigation
- **The page will render and be accessible** but may not appear in the expected place in the sidebar or agent map (if those are based on the nav config)
- **The unknown `group` metadata persists in the page** — it remains in the page's frontmatter and could theoretically be used by custom processing or tools, but the built-in navigation features won't recognize it

This allows for a graceful degradation where outdated or mismatched group declarations don't break the build, but they also don't influence navigation presentation.
