# Navigation in leadtype: `nav` Config vs `group` Frontmatter

## 1. Relationship Between `nav` Config and `group` Frontmatter

### Which Drives the Sidebar and Agent Map?
**The `nav` array in `docs.config.ts` is the authoritative source** that drives both the sidebar and the agent map. It defines the canonical structure and hierarchy of the documentation.

The **`group` frontmatter field is legacy** and serves a different purpose: it provides metadata about which group a page logically belongs to, but it does not control sidebar generation or agent routing.

### What is the Other Still Good For?
- **`nav` config**: Drives sidebar structure, agent map generation, and the definitive navigation hierarchy for the build system.
- **`group` frontmatter**: Useful for:
  - Metadata/tagging purposes (e.g., for queries, filtering, or runtime lookups)
  - Backwards compatibility with older documentation systems
  - Page-level organization hints that don't necessarily change the sidebar structure
  - Agent routing supplementation when pages need to be associated with groups beyond what `nav` defines

In practice, the `nav` config is the **primary navigation driver**, while `group` is a **supplementary metadata field** that may be used for agent association or other runtime features.

## 2. What Happens at Build Time When a Page Declares an Unknown `group`?

When a page declares a `group` slug that the curated `nav` in `docs.config.ts` doesn't know about, **the build typically succeeds without error, but the page is assigned to an implicit/dynamically-created group**.

Specifically:
- The **sidebar navigation remains unaffected** because it's controlled by the explicit `nav` config, not by page frontmatter.
- The **agent map may create an implicit agent entry** for that unknown group, allowing the page to be routed to that group at runtime.
- The page is **still accessible** and renders normally, but it exists outside the explicitly curated navigation structure.
- This is a **graceful degradation pattern** — the system doesn't fail, but the page's group association is handled implicitly rather than explicitly in the navigation config.

This design allows pages to declare group memberships without requiring every possible group to be pre-declared in the `nav` config, providing flexibility while keeping the curated navigation structure explicit and manageable.
