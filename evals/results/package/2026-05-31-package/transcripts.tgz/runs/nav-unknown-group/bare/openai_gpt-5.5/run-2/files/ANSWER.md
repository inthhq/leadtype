# Leadtype navigation notes

1. The curated `nav` in `docs.config.ts` is the source of truth for the rendered navigation: it is what should drive the site sidebar and the agent-facing documentation map/index. A page's `group` frontmatter is legacy metadata; keep it only as a compatibility/classification hint for older consumers, filtering/search metadata, or migration/linting workflows. It should not be treated as the thing that decides where the page appears in the sidebar when a curated config nav exists.

2. `group` is still validated. If a page declares a `group` slug that is not declared/known by the config, the build fails fast instead of silently ignoring it or inventing a new group. The CLI reports an error like `/<page> declares unknown group "<slug>"` / `unknown group "<slug>"` and exits non-zero, so the stale frontmatter has to be fixed before publishing.
