# Navigation System: Nav Config vs Group Frontmatter

## 1. The Relationship Between `nav` Config and `group` Frontmatter

### Which One Drives the Sidebar and Agent Map?

**The curated `nav` in `docs.config.ts` is the primary driver.** The `nav` config is what actually builds and controls:
- The **sidebar structure** that users see when navigating the documentation site
- The **agent map** (routing/grouping for LLM agents)

### What is the Legacy `group` Frontmatter Still Good For?

The legacy `group` frontmatter field serves as a **fallback categorization mechanism** and **backward compatibility layer**. It is still useful for:

1. **Legacy documents**: Older markdown files that were authored before the migration to config-based navigation may still declare `group` fields
2. **Automatic grouping**: In systems without an explicit `nav` config, the `group` field can provide implicit categorization
3. **Metadata annotation**: It serves as documentation within the page itself about what logical group the page belongs to
4. **Fallback routing**: If a page isn't explicitly listed in `nav`, its `group` field can be used to infer context (though the page won't appear in the sidebar)

### Key Distinction

- **`nav` config**: Controls visibility and organization in the sidebar and agent map
- **`group` frontmatter**: A legacy fallback that works in the absence of `nav`, but does not override it if `nav` exists

The migration direction is clear: **move from `group` frontmatter to `nav` config**, which provides more centralized control and clearer documentation structure.

---

## 2. Build-Time Behavior with Unknown Group Slugs

### What Happens When a Page Declares an Unknown Group?

If a page declares a `group` slug (in its frontmatter) that the `docs.config.ts` doesn't know about at build time:

**The build will emit a lint warning or error** (depending on lint configuration), because:

1. **Orphaned page**: The page declares membership in a group that doesn't exist in the config
2. **Navigation mismatch**: The page's metadata claims a group affiliation that has no corresponding entry in `nav`
3. **Validation failure**: Modern leadtype validation checks that pages are properly routed through the config

### Build Outcomes

- **With strict linting enabled**: The build **fails** and prevents deployment, forcing the developer to either:
  - Add the missing group to `nav` config, OR
  - Update/remove the `group` field from the page's frontmatter

- **With lenient linting**: The build **completes with warnings**, but the page may:
  - Not appear in the sidebar
  - Not be properly indexed for the agent map
  - Cause downstream integration issues

### Best Practice

Unknown groups should be treated as **configuration errors** rather than silent failures. The test fixture `nav-unknown-group-fixture` likely serves to validate that the tooling correctly detects and reports such misconfigurations during the build process.
