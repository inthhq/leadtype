# Navigation in leadtype Projects

## 1. Relationship between `nav` in `docs.config.ts` and page `group` frontmatter

### Which drives the sidebar and agent map?

The **curated `nav` in `docs.config.ts` drives the sidebar and agent map**. This is the source of truth for:
- How pages are organized and displayed in the documentation sidebar
- How pages are grouped for the agent map
- The hierarchical structure and navigation flow

### What is the `group` frontmatter field still good for?

The legacy `group` frontmatter field on pages serves as a **fallback or validation mechanism**. It:
- Helps identify which conceptual group a page belongs to when the page is parsed
- Can be used for organizing or filtering pages outside of the explicit `nav` structure
- May be used by tooling or scripts that process pages independently of the build config
- Provides a way for pages to self-identify their category, useful for API documentation or auto-generated content

**In summary**: `nav` is the primary driver for sidebar structure and layout; `group` is legacy metadata that pages can carry for other purposes.

---

## 2. What happens at build time if a page declares a `group` slug that the config doesn't know about?

If a page declares a `group` slug that is not defined in `docs.config.ts`, the build process will **raise a validation error or warning**.

Specifically:
- The page's `group` reference is validated against the groups/categories defined in the curated `nav` configuration
- An undeclared group slug is treated as a configuration error because it represents a mismatch between:
  - What the page claims about its own categorization (via `group` frontmatter)
  - What the documentation site's navigation structure actually defines (via `nav` in config)
- This error surfaces during the build to help authors keep pages' self-declared groups in sync with the actual navigation structure

This validation ensures consistency and prevents orphaned or miscategorized pages from silently breaking the documentation structure.
