# Leadtype navigation: `nav` vs. legacy `group`

1. The curated `nav` in `docs.config.ts` is the source of truth for the docs structure. It is what should drive the runtime sidebar and the generated agent-facing map: ordering, nesting, section labels, and which pages appear in those curated sections come from the config, not from each page's legacy `group` value.

   The page-level `group` frontmatter is still useful as legacy/compatibility metadata: it can label pages for older Leadtype group-based consumers, search/filtering/migration workflows, linting, or other local tooling that still reads `group`. But in a project using curated config navigation, changing only `group` is not how you place or reorder a page in the sidebar/agent map; update `docs.config.ts` instead.

2. Leadtype still validates declared group slugs. If a page says `group: some-slug` (or includes it in a `group: [...]` array) and that slug is not known by the docs config, the build/generation fails with an unknown-group error, typically identifying the page URL/path and the missing slug. It is not silently ignored or treated as ungrouped; fix the typo, add the group to the config if it is intentional, or remove the stale `group` field.
