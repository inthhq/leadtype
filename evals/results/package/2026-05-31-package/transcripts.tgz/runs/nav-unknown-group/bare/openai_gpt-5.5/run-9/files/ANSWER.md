# Leadtype navigation answer

1. The curated navigation declared in `docs.config.ts` is the source of truth for the generated navigation surfaces: the sidebar/navigation manifest and the agent-facing docs map/sections (`llms.txt` / `AGENTS.md`). A page's frontmatter `group` is a legacy classification hint, not the thing that orders or places pages once curated config navigation is in use. It is still useful as page metadata/backwards compatibility: search or filtering facets, lint/schema compatibility, migration from older group-based docs, and fallback/inference in setups that do not provide curated navigation.

2. Leadtype still validates legacy `group` values against the configured group/nav slugs. If a page declares a `group` slug that the loaded config does not know about, generation fails fast at build time with an unknown-group error such as `... declares unknown group "<slug>"` rather than silently putting the page somewhere or emitting broken artifacts.
