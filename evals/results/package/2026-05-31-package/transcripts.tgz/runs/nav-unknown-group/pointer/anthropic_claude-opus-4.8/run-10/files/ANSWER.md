# Navigation in leadtype: `nav` vs. `group`

## 1. Relationship between curated `nav` and legacy `group`

**Curated `nav` in `docs.config.ts` is the source of truth for navigation.** It
drives every reader- and agent-facing surface from a single resolved tree:

- top-level docs areas / tabs (Docs, Frontend, Integrations, Changelog, …),
- the human sidebar (structure and order),
- `llms.txt`,
- `AGENTS.md` (the agent map),
- sitemap markdown,
- Agent Readability navigation metadata.

You build it with root nodes (top-level areas), nested `children` (sections),
`base` prefixes that cascade to children, explicit extensionless `pages`
strings for pinned entry points, and `{ include: "folder/*", sort: [...] }`
entries for inventory-style folders.

**A page's frontmatter `group` is legacy/optional taxonomy metadata** — it is
*not* the preferred driver of the sidebar or agent map when `nav` exists. It
remains useful for:

- **Legacy navigation fallback.** If a project has **no** `nav`, the CLI falls
  back to the legacy group resolver and infers the nav tree from the `group:`
  values it finds (declared once each in `docs.config.ts`). That's adequate for
  small docs sets, but `nav` is needed for stable top-level areas, sidebar
  order, descriptions, nested sections, and wildcard includes.
- **Search facets / broad taxonomy.** `group` (and a page can carry several
  via `group: [a, b]`) lets pages be classified/shared across taxonomy groups
  for search metadata.
- **Compatibility** for sites that have not yet migrated to config-owned `nav`.

In short: when `nav` is present it owns the curated structure and the agent map;
`group` degrades to taxonomy/search/compatibility metadata (and the
fallback navigation only when `nav` is absent). Same idea applies to `order`,
which survives only as a fallback sort for pages pulled in by `include`.

## 2. Build-time behavior for an unknown `group` slug

Group slugs must be declared in `docs.config.ts`. If a page declares a `group`
slug that the config doesn't know about, **the build fails** with the error:

```
unknown group "<slug>"
```

This is intentional: the config and the frontmatter share one source of truth,
so an undeclared group is treated as drift and is rejected rather than silently
ignored. (Note that only **leaf** groups — those with no `children` — can
directly contain pages; non-leaf groups act as headings only.) The companion
lint rule `schema` / `unknown-field` plus `leadtype lint` help catch related
problems in CI before a build is even attempted.
