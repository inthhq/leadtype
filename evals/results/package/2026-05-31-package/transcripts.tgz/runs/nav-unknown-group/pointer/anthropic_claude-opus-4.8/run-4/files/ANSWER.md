# Navigation in leadtype: `nav` vs. `group`

## 1. Relationship between curated `nav` and legacy `group` frontmatter

**The curated `nav` in `docs.config.ts` is the source of truth and drives the sidebar and agent map.** `group` is a legacy taxonomy field that is no longer the primary driver but still has secondary uses.

### What `nav` drives

`nav` is the config-owned, curated navigation structure. The single resolved tree it produces drives all of leadtype's human *and* agent surfaces:

- Top-level docs areas / tabs (e.g. Docs, Frontend, Integrations, Changelog — the root nodes)
- The sidebar (the active root node's pages and children)
- `llms.txt`
- `AGENTS.md` (the "agent map")
- Sitemap markdown
- Agent Readability navigation metadata

`nav` lets you control things `group` can't: stable top-level docs areas, explicit sidebar ordering, descriptions, nested sections, and wildcard `include` entries. `base` cascades down to children, page strings are extensionless paths relative to the nearest `base`, and `include` entries append matching pages (sorted by `order` then path).

### What `group` is still good for

`group` is **optional legacy taxonomy metadata** on a page. When `nav` is present, `group` no longer places pages in the curated navigation, but it remains useful for:

- **Legacy navigation fallback** — if a project has *not* adopted `nav`, the CLI falls back to a legacy group resolver that infers the nav tree from the `group:` values it finds (intersected with group declarations in `docs.config.ts`). This is fine for small docs sets.
- **Search facets** — `group` feeds search metadata.
- **Broad taxonomy** — a page may belong to multiple groups (`group: [a, b]`), so it's handy for cross-cutting categorization that the linear `nav` tree doesn't express.

Also useful to remember: `order` (like `group`) lives on as a fallback sort key for pages pulled in by `include`.

**Summary:** When `nav` exists it owns the sidebar and agent map; `group` falls back to fallback navigation, search facets, and broad multi-group taxonomy.

## 2. What happens if a page declares an unknown `group` slug at build time

**The build fails.** If a page declares a `group` slug that isn't declared in `docs.config.ts`, generation errors out with:

```
unknown group "<slug>"
```

This is by design — the config is the single source of truth for valid group slugs, so an undeclared slug is treated as drift and is rejected rather than silently dropped. (Note that only **leaf** groups — those without children — can directly contain pages; non-leaf groups act as headings only.)
