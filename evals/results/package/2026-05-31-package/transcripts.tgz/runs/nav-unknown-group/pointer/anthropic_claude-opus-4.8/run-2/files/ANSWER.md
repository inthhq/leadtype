# Leadtype navigation: `nav` vs. legacy `group`

## 1. Relationship between curated `nav` and a page's legacy `group` frontmatter

**Curated `nav` in `docs.config.ts` is the source of truth that drives navigation.** When a config defines a `nav` array, that resolved tree is what produces every navigation surface — for both humans and agents:

- Top-level docs areas / navbar tabs (root nodes like Docs, Frontend, Integrations, Changelog)
- The sidebar (the active root node's pages and children)
- `llms.txt` sections
- `AGENTS.md` grouping (the agent map)
- Sitemap markdown
- Agent Readability navigation metadata

Because all of these are generated from one resolved `nav` tree, the human sidebar and the agent-facing document map stay aligned with no drift.

**The legacy `group` frontmatter field is no longer the primary navigation mechanism — it's taxonomy/compatibility metadata.** It is still useful for:

- **Legacy navigation fallback.** If a project has *not* adopted `nav`, the CLI falls back to the legacy group resolver: it reads the `group:` values on pages, intersects them with the groups declared in `docs.config.ts`, and builds the fallback nav tree (plus `llms.txt` section headings, search metadata, and `AGENTS.md` grouping) from that. This is fine for small docs sets, but `nav` is preferred when you need stable top-level areas, sidebar order, descriptions, nested sections, or wildcard includes.
- **Search facets / broad taxonomy.** A page can carry one or more group slugs (`group: <slug>` or `group: [a, b]`), so the same page can be classified under multiple taxonomy groups and surfaced in search facets.

In short: **`nav` drives the sidebar and the agent map; `group` is retained for the legacy fallback nav resolver, search facets, and broad taxonomy/compatibility metadata.** (Likewise, `order` is no longer needed for curated ordering — it survives only as fallback sorting for pages pulled in by wildcard `include` entries.)

## 2. What happens at build time if a page declares an unknown `group` slug

**The build fails.** If a page declares a `group` slug that is not declared in `docs.config.ts`, the build errors out with:

```
unknown group "<slug>"
```

The config and the page frontmatter share a single source of truth for group slugs, so an undeclared slug is treated as a hard error rather than silently ignored — this prevents drift between authored taxonomy and the configured groups. (Group-slug validity is checked against the config; you can keep `groups` defined in config specifically so existing `group` frontmatter continues to validate.)
