# Leadtype navigation vs. legacy `group`

1. **`docs.config.ts` `nav` is the curated navigation source of truth.** When a project has adopted `nav`, that tree drives the human sidebar/top-level docs areas and the agent-facing map: generated navigation, `llms.txt` sections, `AGENTS.md`, sitemap markdown, and Agent Readability navigation.

   A page's frontmatter `group` is legacy metadata. It no longer decides curated page placement when `nav` is present. It is still useful for projects that have not migrated to `nav` (legacy/fallback navigation), and as broad taxonomy/compatibility metadata such as search or filter facets. Keep legacy `groups` in the config if you still want existing `group` frontmatter values to be validated during a migration.

2. **An unknown configured legacy group is a build-time error.** During generation, Leadtype resolves navigation before emitting artifacts. If a page declares a `group` slug that is supposed to be validated against the loaded config's legacy `groups` but that slug is missing, `leadtype generate` fails fast with an error like:

   ```txt
   /docs/some-page declares unknown group "some-slug"
   ```

   The page is not silently placed into the sidebar, auto-created as a new group, or moved to `Other`; the run exits non-zero so the config/content drift can be fixed. If there is no config to validate against, Leadtype can infer legacy groups from frontmatter as a fallback, but curated projects should use `nav` for structure.
