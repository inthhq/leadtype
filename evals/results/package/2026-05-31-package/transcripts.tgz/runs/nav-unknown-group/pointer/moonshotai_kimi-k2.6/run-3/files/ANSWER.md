# Leadtype Navigation: `nav` vs. `group`

## 1. Which drives the sidebar and agent map, and what is the other still good for?

**`nav` in `docs.config.ts` drives the sidebar and the agent map.**

When `nav` is present, it is the single source of truth for:
- Sidebar structure and ordering
- Top-level docs areas / tabs
- `llms.txt` sections
- `AGENTS.md` grouping
- Sitemap markdown
- Agent Readability navigation metadata
- Search metadata

**The page-level `group` frontmatter field is legacy taxonomy metadata.** It is no longer the best place to express polished navigation, but it is still useful for:
- **Fallback navigation** in projects that have not yet adopted `nav`
- **Search facets and broad taxonomy** (e.g. filtering or tagging)
- **Compatibility metadata** — keeping it on pages is valid and harmless

In short: product navigation goes in `docs.config.ts` `nav`; page taxonomy can stay in frontmatter `group`.

## 2. What happens at build time if a page declares a `group` slug the config doesn't know about?

**The build fails.**

During generation, leadtype resolves groups in step 3 after conversion. If a page frontmatter references a group slug that is not declared in `docs.config.ts` (or the relevant collection config), the run exits with an error like:

```
error: /docs/some-page declares unknown group "missing-slug".
```

This is intentional — leadtype treats broken navigation as a content bug rather than a render-time warning. The CLI exits with code `1` (runtime error). The same strictness applies whether you are running `leadtype generate` in site mode or with `--bundle`.

---

*Sources: leadtype docs on [frontmatter](node_modules/leadtype/docs/authoring/frontmatter.md), [how it works](node_modules/leadtype/docs/how-it-works.md), [LLM files](node_modules/leadtype/docs/reference/llm.md), and [CLI reference](node_modules/leadtype/docs/reference/cli.md).*
