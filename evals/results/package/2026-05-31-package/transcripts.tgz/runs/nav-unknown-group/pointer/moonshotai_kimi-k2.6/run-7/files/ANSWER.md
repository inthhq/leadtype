# Leadtype Navigation: `nav` vs. `group`

## 1. What drives the sidebar and agent map, and what is the other still good for?

- **Config-owned `nav`** is the source of truth for curated navigation. It drives the sidebar, top-level docs areas, `llms.txt` sections, `AGENTS.md` grouping, sitemap markdown, and Agent Readability metadata.
- **Frontmatter `group`** is legacy navigation metadata. It is still valid, but Leadtype treats it as **taxonomy and compatibility metadata** rather than the primary navigation structure.

In short: put intentional navigation structure in `docs.config.ts` `nav`; keep `group` on pages for broad taxonomy, search facets, or backward compatibility. If a project has not adopted `nav`, Leadtype falls back to the legacy group resolver and builds the nav tree from the `group` values it finds.

## 2. What happens at build time if a page declares a `group` slug the config doesn't know about?

The build **fails** with an error:

```
unknown group "<slug>"
```

Leadtype enforces a single source of truth for groups: every `group` slug declared in page frontmatter must be defined in `docs.config.ts` (or the relevant collection config). There is no silent drift — unknown groups surface as hard errors during generation or linting.
