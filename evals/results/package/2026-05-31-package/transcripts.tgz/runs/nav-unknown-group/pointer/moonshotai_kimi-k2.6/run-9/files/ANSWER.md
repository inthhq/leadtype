# Navigation: `nav` vs. legacy `group`

## 1. Which one drives the sidebar and agent map, and what is the other still good for?

- **`docs.config.ts` `nav` drives the sidebar and agent map.**  
  The curated `nav` tree is the shared source of truth for the sidebar, `llms.txt` sections, `AGENTS.md`, sitemap markdown, Agent Readability metadata, and the generated navigation manifest (`docs-nav.json`). When `nav` is present, the pipeline resolves pages from the config structure, not from frontmatter.

- **The page-level `group` frontmatter field is legacy taxonomy metadata.**  
  It is still valid and useful for:
  - **Fallback navigation** — if a project has not adopted `nav`, the CLI falls back to the legacy group resolver and infers the nav tree from the `group:` values it finds.
  - **Search facets** — `group` can still be used to filter or tag pages in search indexes.
  - **Broad taxonomy / compatibility metadata** — it lets pages declare shared categories without dictating curated placement.

In short: put intentional navigation structure in `nav`; keep `group` as taxonomy, fallback, or compatibility metadata.

## 2. What happens at build time if a page declares a `group` slug the config doesn't know about?

The build **fails fast**.

During the "resolve groups" step, the pipeline validates every page's `group:` against the known slugs declared in `docs.config.ts`. If a page names a group that isn't in the loaded config, generation stops with a runtime error (exit code `1`) and emits a message like:

```
error: /docs/some-page declares unknown group "missing-slug".
```

This is by design — broken navigation is treated as a content bug, not a render-time problem, so a bad config or stale frontmatter cannot ship silently.
