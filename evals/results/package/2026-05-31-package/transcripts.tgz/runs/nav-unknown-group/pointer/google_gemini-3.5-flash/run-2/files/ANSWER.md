# Leadtype Navigation & Taxonomy Questions

## 1. Curated `nav` vs. Legacy `group` Frontmatter

### Which one drives the sidebar and agent map?
**Curated `nav`** in `docs.config.ts` is the modern, preferred API that drives:
- The human-facing **sidebar structure** and top-level navigation tabs.
- The **agent map** and related discovery/indexing files, including `llms.txt`, `AGENTS.md`, sitemap markdown, and Agent Readability metadata (e.g., `agent-readability.json`).

---

### What is the relationship between them, and what is `group` still good for?
* **The Relationship:** `nav` is a centralized, config-owned navigation structure, whereas `group` is a legacy page-level frontmatter field used to assign pages to taxonomy groups. If `nav` is defined, Leadtype uses it to build the curated tree. If `nav` is absent, the CLI falls back to the legacy group resolver (matching the pages' frontmatter `group` fields to a declared `groups` array in `docs.config.ts`) to build a fallback navigation tree.
* **What `group` is still good for (after migrating to `nav`):**
  1. **Broad Taxonomy & Metadata:** It serves as categorization and taxonomy metadata for the page.
  2. **Search Facets:** It provides categorization filters/facets for search index files (e.g., `search-index.json`).
  3. **Compatibility/Migration Safety:** It ensures compatibility for legacy navigation components or systems that haven't yet transitioned to the newer `nav` config.

---

## 2. Unknown `group` Slug Build-Time Behavior

If a page declares a `group` slug that is not declared in the configuration (`docs.config.ts`):

1. **The build fails noisily:** At build time, the `leadtype generate` command runs in sequential stages. During **Step 3: Resolve groups**, Leadtype validates every page's declared `group:` slug against the known groups in `docs.config.ts`.
2. **Error Message:** The generation process fails and outputs an error to `stderr` resembling: 
   `error: <page-path> declares unknown group "<slug>"`.
3. **Design Philosophy:** This failure is by design. Leadtype treats drift or incorrect groups as content bugs (broken navigation/taxonomy) rather than a render-time issue, failing the CI/build run immediately to prevent shipping broken or incomplete documentation experiences.
