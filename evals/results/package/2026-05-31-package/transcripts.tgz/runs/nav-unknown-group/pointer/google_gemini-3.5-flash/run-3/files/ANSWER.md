# Leadtype Navigation & Group Resolution

## 1. Curated `nav` vs. Legacy `group` Frontmatter

### The Relationship
* **Curated `nav` (in `docs.config.ts`)**: This is the modern, configuration-driven approach to defining the Information Architecture (IA). It defines structured navigation nodes, stable top-level areas (tabs), sidebar order, and nested sections, and supports wildcard includes.
* **Legacy `group` (in frontmatter)**: This is page-level metadata (e.g., `group: [slug]`) declaring which legacy taxonomy group a page belongs to.

### Which one drives the sidebar and agent map?
* **Curated `nav`** in `docs.config.ts` drives the sidebar navigation, the agent map (`AGENTS.md`), sitemap markdown, sitemap navigation, `llms.txt` sections, and the Agent Readability metadata (`agent-readability.json`).

### What is the other still good for?
Even when curated `nav` is adopted, the `group` frontmatter field is still useful for:
* **Search and Taxonomy**: Serving as search facets, filtering metadata, and broad content taxonomy.
* **Legacy Fallback**: Acting as the fallback navigation tree generator for smaller docs sets or older projects that have not yet migrated to use the curated `nav` in `docs.config.ts`.

---

## 2. Unknown `group` Slugs at Build Time

If a page declares a `group` slug in its frontmatter that the loaded configuration (`docs.config.ts`) does not know about:
* **Fail-Fast Build Failure**: The build/generation run immediately fails.
* **Error Message**: It outputs an error to `stderr` in the format:
  ```
  error: <urlPath> declares unknown group "<slug>".
  ```
* **Exit Code**: The CLI exits with code `1` (runtime error).
* **Design Rationale**: This is by design. Broken navigation/metadata is treated as a critical content bug. Failing fast prevents shipping out-of-sync or broken documentation to production.
