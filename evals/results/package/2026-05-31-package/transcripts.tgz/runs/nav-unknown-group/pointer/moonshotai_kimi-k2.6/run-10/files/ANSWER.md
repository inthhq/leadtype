# Navigation: `nav` vs. `group`

## 1. Which one drives the sidebar and agent map, and what is the other still good for?

**`nav` in `docs.config.ts` is the driver.** It is the preferred, config-owned source of truth for curated navigation. It powers:
- The human sidebar (top-level docs areas and nested sections)
- The agent map (`llms.txt`, `AGENTS.md`, sitemap markdown, and Agent Readability navigation)
- The search index structure

**`group` in page frontmatter is legacy taxonomy metadata.** It is still valid, but it is no longer the best place to express polished navigation. It remains useful for:
- **Legacy fallback navigation:** If a project has not adopted `nav`, Leadtype falls back to the legacy group resolver to infer the nav tree from `group` values.
- **Search facets:** Broad taxonomy tags that help categorize pages in search.
- **Compatibility metadata:** Indicating which conceptual bucket a page belongs to without dictating exact placement in the curated UI.

As the Leadtype docs put it: *"Treat [`group`] as taxonomy and compatibility metadata. Put intentional navigation in `nav`."* (see `node_modules/leadtype/docs/changelog/nav-migration-prompts.md` and `node_modules/leadtype/docs/authoring/frontmatter.md`).

## 2. What happens at build time if a page declares a `group` slug the config doesn't know about?

**The build fails.** During `leadtype generate`, step 3 resolves groups from frontmatter and validates every page's `group` against the known slugs in `docs.config.ts`. If a page declares an unknown group slug, the run exits with an error such as:

```
unknown group "<slug>"
```

This is by design — broken navigation is treated as a **content bug**, not a render-time problem. The same validation applies whether you are running site mode (`leadtype generate`) or bundle mode (`leadtype generate --bundle`).

> *"If step 3 finds an unknown group, the run fails. That is by design — broken navigation is a content bug, not a render-time problem."* — `node_modules/leadtype/docs/how-it-works.md`
