# Leadtype navigation: `nav` vs. `group`

1. **`docs.config.ts` `nav` is the curated source of truth.** When present, it drives the human navigation/sidebar and the agent-facing map: generated navigation, `llms.txt` sections, `AGENTS.md`, sitemap markdown, and Agent Readability navigation. A page's frontmatter `group` field is legacy metadata; it is still useful for projects that have not migrated to `nav` as the fallback group-based navigation, and it remains useful as broad taxonomy / search-filter metadata. It should not be treated as the primary way to place pages in a curated sidebar once `nav` exists.

2. **An unknown legacy group is a build-time error when groups are being validated from config.** If a page declares `group: some-slug` and the loaded config's legacy `groups` list does not contain that slug, generation/navigation validation fails fast with an error like:

   ```txt
   /docs/page declares unknown group "some-slug"
   ```

   The page is not silently added to a new group or dropped into the sidebar; Leadtype treats that drift as broken navigation metadata. If there is no config/group list to validate against, the CLI can fall back to inferring legacy groups from page frontmatter, but curated projects should keep `groups` defined when they want existing `group` frontmatter to continue being checked.
