# Leadtype Navigation & Grouping Q&A

### 1. What is the relationship between the curated `nav` in `docs.config.ts` and a page's legacy `group` frontmatter field — which one drives the sidebar and agent map, and what is the other still good for?

* **Which one drives the sidebar and agent map?**
  * The curated **`nav`** configuration defined inside `docs.config.ts` is what drives the sidebar, agent map, sitemap markdown, Agent Readability metadata, `llms.txt`, and `AGENTS.md` in modern `leadtype` projects.

* **The relationship & what the other is still good for:**
  * **`nav`** is config-owned and allows you to curate precise, structured documentation information architecture (IAs) — providing custom sidebar order, top-level tabs, nested sections, descriptions, and wildcard includes.
  * **`group`** (declared at the page level in YAML frontmatter, e.g., `group: slug` or `group: [a, b]`) is considered legacy taxonomy metadata. Although it is no longer the primary driver for curated page placement on modern sites, it remains useful for:
    1. **Legacy Navigation Fallback**: For projects that have not yet adopted the curated `nav` block, the CLI falls back to the legacy group resolver (inferring or matching group associations to form section headings and sidebar structures).
    2. **Search Facets and Filtering**: It serves as categorized metadata to generate search index categories/facets.
    3. **Broad Taxonomy/Compatibility Metadata**: It allows associating a page with one or more taxonomy groups across the docs set, keeping content categorizations separate from the structural sidebar layout.

---

### 2. What happens at build time if a page declares a `group` slug that the config doesn't know about?

* **Strict Validation Failure**: If a page frontmatter declares a `group` slug that is omitted or unrecognized by the loaded `docs.config.ts`, **the build/generation process fails noisily**.
* **Exit Code and Messages**: 
  * The command (e.g. `leadtype generate`) immediately exits with **exit code `1`** (indicating a runtime error).
  * It prints a specific error to `process.stderr` outlining the exact file and the unknown slug, e.g.:
    `error: <urlPath> declares unknown group "<slug>".`
* **By Design**: This "fail-fast" behavior is fully intentional. It ensures there is no configuration drift and prevents shipping broken navigation, treating unknown groups as severe content bugs that must be resolved before deployment.
