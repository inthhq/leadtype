# Navigation in Leadtype

Below are the answers regarding the relationship between curated `nav` configuration and legacy `group` frontmatter fields, and the build-time validation behavior.

---

### 1. Curated `nav` in `docs.config.ts` vs. Legacy `group` Frontmatter Field

#### **Which one drives the sidebar and agent map?**
* **Curated `nav` in `docs.config.ts`** is the primary driver of both the website sidebar and the agent map. 
* It is used to generate the structured page placement, top-level tabs/sections, nested menus, and wildcard inclusion rules.
* The resolved `nav` tree drives:
  * The active human-facing sidebar structure via `getNavigation()`.
  * The **Agent Map** and agent-routing artifacts, including `llms.txt`, `AGENTS.md` (the root-level relative-link index for offline packages), sitemap markdown (`sitemap.md`), and the navigation manifest in the Agent Readability metadata (`agent-readability.json`).

#### **What is the other still good for?**
The legacy page-level **`group`** frontmatter field remains useful and supported for:
* **Legacy Navigation Fallback:** In projects that have not yet migrated to or adopted the config-level `nav` format, `group` frontmatter is intersected with the `groups` array in `docs.config.ts` to produce the sidebar hierarchy, `llms.txt` sections, and `AGENTS.md` categories.
* **Search Facets and Taxonomy:** It acts as metadata for search indexing and categorization, making it easy to filter or query docs by taxonomy groups.
* **Multi-group Association:** Unlike hierarchical `nav` paths, a page can declare multiple groups (e.g., `group: [group-a, group-b]`), allowing single pages to be cross-referenced or shared across multiple taxonomy buckets.

---

### 2. Build-Time Behavior for Unknown `group` Slugs

If a page declares a `group` slug in its frontmatter that the loaded configuration does not know about:

* **The build fails noisily:** The `leadtype generate` command will output a clear error to stderr and terminate with exit code `1` (or linting will fail if enforcing strict validation):
  ```bash
  error: <page-path> declares unknown group "<slug>".
  ```
* **Why it fails:** This is a deliberate "fail-fast" design decision. Leadtype treats broken or drifted navigation as a content bug rather than a render-time warning. Failing the build prevents shipping broken references, invalid navigation artifacts, or mismatched layouts.
* **Exception (Fallback Mode):** If the project has **no config file at all**, the CLI falls back to inferring groups dynamically from the union of all `group:` values discovered across your markdown files (alphabetizing and title-casing them automatically). But once a `docs.config.ts` config is present, any page-level `group` slug must match a group defined in that config, or the run will fail.
