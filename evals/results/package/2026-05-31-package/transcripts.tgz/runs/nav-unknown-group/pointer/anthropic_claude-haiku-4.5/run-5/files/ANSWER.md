# Navigation in Leadtype: `nav` Config vs. Legacy `group` Frontmatter

## 1. Relationship Between Config `nav` and Legacy `group` Frontmatter

### Which Drives Sidebar and Agent Map?
**The curated `nav` in `docs.config.ts` is the primary driver** of the sidebar, agent map, llms.txt structure, and AGENTS.md organization.

### What is the Legacy `group` Still Good For?
The `group` frontmatter field **remains useful for fallback navigation and taxonomy metadata**:

- **Fallback navigation**: In projects that have not yet adopted the newer `nav` config pattern, each page can declare a `group` slug, and when a `groups` array is declared in `docs.config.ts`, the intersection of page groups and config groups produces a fallback navigation tree that still drives llms.txt sections, AGENTS.md grouping, and search metadata.
- **Taxonomy and compatibility**: Pages can be shared across multiple taxonomy groups using `group: [a, b, c]`, enabling cross-cutting organization even after `nav` is the primary navigation structure.

### The Migration Path
When a project adopts the newer `nav`-first approach:

- Move curated navigation structure out of `group` declarations and into the `nav` array in `docs.config.ts`.
- Keep frontmatter `group` only as optional taxonomy/compatibility metadata (and only where needed for legacy reasons).
- Keep frontmatter `order` only where wildcard includes need fallback sorting.

The same resolved navigation tree then drives:
- Generated navigation artifacts (`docs-nav.json`)
- `llms.txt` sections and headings
- `AGENTS.md` sections  
- Sidebar rendering
- Agent Readability metadata and maps

---

## 2. Build-Time Behavior for Unknown Group Slugs

**If a page declares a `group` slug that the config doesn't know about, the build fails immediately.**

### Error Details
The exact failure occurs during **step 3** of the `leadtype generate` pipeline — the "group resolution" stage:

> If step 3 finds an unknown group, the run fails. That is by design — broken navigation is a content bug, not a render-time problem.

The CLI will exit with code `1` (runtime error) and print an error message to stderr:

```
error: <urlPath> declares unknown group "<slug>"
```

### Why This Happens
This is a deliberate safety constraint. The `group` field (whether in fallback mode or as explicit taxonomy) creates an implicit contract: every group slug referenced by a page must be defined somewhere in the config. By failing loudly at build time instead of silently ignoring or inferring groups, Leadtype ensures:

- **Same source of truth, no drift**: The config and page frontmatter cannot diverge invisibly.
- **Early feedback**: Content bugs (bad group slugs) surface immediately in the build pipeline, not at render time or in agent consumption.
- **Consistency across outputs**: The same navigation tree drives llms.txt, AGENTS.md, sidebar, and agent metadata — so validating it once prevents inconsistencies everywhere.

### The Solution
When migration to `nav`-first structure is complete and the project no longer needs `groups` config, pages should simply remove the `group` field entirely. If legacy group metadata must be retained for compatibility, ensure that every slug declared in any page's `group` field (or `group: [...]` array) is defined in `docs.config.ts` — or remove it.
