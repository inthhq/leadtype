# Answer

1. `docs.config.ts` `nav` is the curated source of truth for navigation. When present, the resolved `nav` tree drives the human docs sidebar/top-level docs areas and the agent-facing map: `llms.txt` sections, `AGENTS.md`, sitemap markdown, and Agent Readability navigation. A page's frontmatter `group` field is legacy metadata; keep it for fallback navigation in projects that have not adopted `nav`, broad taxonomy/compatibility metadata, and search/filter facets—not for curated sidebar placement.

2. If a page declares a legacy `group` slug that the loaded config does not know about, build/generation fails fast with an `unknown group "<slug>"` error, usually tied to the page URL/path, and exits non-zero. Leadtype treats that as a content/config bug so bad navigation does not silently ship. It does not invent the missing group or ignore the mismatch.
