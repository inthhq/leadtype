# Navigation in Leadtype: `nav` vs. `group`

## 1. Relationship between curated `nav` and page `group` — which drives what?

**The curated `nav` in `docs.config.ts` is the primary driver.** It owns:
- The sidebar structure
- The agent map (`AGENTS.md`, `llms.txt`)
- Generated navigation JSON
- Agent Readability metadata

The legacy `group` frontmatter field is still valid but is **secondary**. It serves as:
- **Taxonomy and compatibility metadata** — still useful for search facets and broad categorization
- **Fallback navigation** — only when `nav` is not defined (small docs sets or legacy projects)
- **Cross-cutting classification** — pages can declare `group: [a, b]` to appear in multiple groups

### The modern pattern

When you have config-owned `nav`:
- Use `nav` to describe intentional site structure: top-level docs areas, sidebar order, nested sections, and wildcard includes
- Keep `group` only as metadata for pages that need legacy compatibility or multi-group membership
- The `nav` tree resolves to become the sidebar, the agent map, and all generated navigation artifacts

### The legacy fallback

If you have no `nav` defined:
- Leadtype infers the navigation tree directly from `group` values it finds in frontmatter
- The CLI reads all pages, collects their group slugs, and builds a fallback nav tree
- This is enough for small docs sets but lacks curated order, descriptions, and nested structure
- Each group slug must still be declared once in `docs.config.ts` for validation

### Resolution flow

```
docs.config.ts (nav defined)
          ↓
nav tree drives: sidebar, llms.txt sections, AGENTS.md grouping, search metadata
page frontmatter (group field)
          ↓
used for: taxonomy, backwards compatibility, cross-group membership
```

vs.

```
docs.config.ts (no nav, groups declared)
          ↓
page frontmatter (group field collected from all pages)
          ↓
inferred nav tree drives: sidebar, llms.txt sections, AGENTS.md grouping
```

## 2. What happens at build time if a page declares a `group` slug that the config doesn't know about?

**The build fails immediately with exit code 1**, and the error message is:

```
error: <path-to-page> declares unknown group "<slug>"
```

This is **by design**. Leadtype treats unknown groups as a content bug, not a render-time warning:

- There is one source of truth: the declared group slugs in `docs.config.ts`
- If a page's frontmatter references a group that doesn't exist in config, there is no valid place to put that page in the navigation tree
- The build fails fast rather than silently dropping the page or creating undefined behavior
- This happens during the `leadtype generate` or `leadtype lint` runs, before any artifacts are written

### Prevention

To prevent this error:
1. When you add a page with `group: my-slug`, ensure `docs.config.ts` either:
   - Declares `my-slug` in the `groups` array (legacy pattern), or
   - Includes a `nav` node with slug matching `my-slug` (modern pattern)
2. Run `leadtype lint` in CI to catch frontmatter schema violations and unknown groups before publish
3. If you're migrating from `group` to config-owned `nav`, the `nav` must cover all group slugs used in frontmatter, or you can remove the frontmatter `group` field entirely

### Examples

**This fails:**
```yaml
# docs/guide.mdx
---
title: "My Guide"
group: "advanced"  # ← Error! "advanced" not in config
---
```

**This works (legacy):**
```ts
// docs.config.ts
export default defineDocsConfig({
  groups: ["docs", "advanced", "reference"],
  // ...
});
```

**This also works (modern):**
```ts
// docs.config.ts
export default defineDocsConfig({
  nav: [
    { slug: "docs", title: "Documentation", ... },
    { slug: "advanced", title: "Advanced", ... },
    { slug: "reference", title: "Reference", ... },
  ],
});
```

In both cases, the page's `group: "advanced"` is valid because `"advanced"` is registered somewhere in the config.
