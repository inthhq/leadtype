# Navigation in Leadtype: `nav` vs `group`

## 1. Relationship between `nav` and `group`

### What drives the sidebar and agent map?

**`nav` in `docs.config.ts` is the primary driver.** The curated `nav` structure controls:
- **Sidebar structure** — the order and nesting of pages users see in the UI
- **Agent map** — the navigation tree driving `llms.txt`, `AGENTS.md`, sitemap markdown, and Agent Readability metadata
- **Document discovery** — how agents and tools understand docs hierarchy

### What is `group` still good for?

The legacy `group` frontmatter field serves two purposes:

1. **Taxonomy and compatibility metadata** — `group` allows pages to declare category membership for search facets and broad taxonomy classification, even if they aren't explicitly placed in the curated `nav`.

2. **Fallback navigation for projects without `nav`** — In projects that have not yet adopted config-owned `nav`, the `group` field on each page drives navigation. Each page declares one or more group slugs with `group: <slug>` or `group: [a, b]`, and the config declares these groups once in `docs.config.ts`:

```ts
// docs.config.ts (legacy mode)
groups: [
  { slug: "authoring", title: "Authoring" },
  { slug: "docs-site", title: "Build an Agent-Ready Site" },
  { slug: "reference", title: "Reference" },
]
```

The group resolver then produces the navigation tree, section headings in `llms.txt`, search metadata, and AGENTS.md grouping.

### Recommended migration path

Use `nav` when you need:
- Stable top-level docs areas (e.g., Docs, Frontend, Integrations, Changelog as tabs)
- Sidebar order and nesting
- Nested sections
- Wildcard includes with `{ include: "folder/*" }`

Keep `group` only as supplementary taxonomy metadata once you've adopted `nav`.

---

## 2. Build-time behavior for unknown group slugs

### When a page declares a group slug not in the config

**The build fails with exit code 1** and the error message:

```
unknown group "<slug>"
```

This happens only in **legacy group fallback mode** (when `nav` is not defined in the config). The rationale is "same source of truth, no drift" — if a page references a group that isn't declared in `docs.config.ts`, it's caught immediately rather than silently creating orphaned pages.

### The safety check in detail

From the CLI documentation:

> Exit codes: `0` success, `1` runtime error (docs dir missing, config load error, **unknown group**, conversion error, sync failure), `2` CLI usage error.

And from the frontmatter documentation:

> If a page declares a group slug that isn't in `docs.config.ts`, the build fails with `unknown group "<slug>"`. Same source of truth, no drift.

### When `nav` is in use

If your config already uses curated `nav`, the page's `group` field becomes optional metadata and doesn't participate in the fallback group resolver. Pages without explicit `nav` placement can still function using `group` as a classification mechanism, but it won't cause a build error if the group isn't declared.

### Example

**Page frontmatter:**
```yaml
---
title: "Build a docs site"
description: "..."
group: "agent-artifacts"  # ← declared here
---
```

**Config missing this group:**
```ts
// docs.config.ts (NO nav)
groups: [
  { slug: "authoring", title: "Authoring" },
  { slug: "docs-site", title: "Build an Agent-Ready Site" },
  // ❌ "agent-artifacts" is not declared
]
```

**Result:** `leadtype generate` exits with code 1 and reports the unknown group, preventing the build.

---

## Key Insight

The `nav` and `group` systems are **mutually exclusive at the config level**:
- **Use `nav`** for modern curated navigation (sidebar, agent maps, llms.txt)
- **Use `group`** only when you have a legacy single-folder setup without config `nav`

Leadtype prevents mixing both approaches at the config level to keep the source of truth clear. See [Nav migration prompts](./node_modules/leadtype/docs/changelog/nav-migration-prompts.md) in the leadtype package for prompts to guide a migration.
