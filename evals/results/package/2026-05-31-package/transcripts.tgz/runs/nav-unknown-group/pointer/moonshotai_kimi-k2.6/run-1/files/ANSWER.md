# Nav vs. `group` frontmatter in leadtype

## 1. Which drives the sidebar and agent map, and what is the other still good for?

- **`docs.config.ts` `nav`** is the curated, config-owned source of truth. It drives the sidebar, the agent map (`llms.txt`, `AGENTS.md`), sitemap markdown, Agent Readability navigation, and search metadata.
- **`group` frontmatter** is a legacy taxonomy field. It is no longer the best place to express polished navigation, but it remains useful as fallback navigation for projects that have not adopted `nav`, and it still works as search/filter taxonomy and broad categorization metadata.

## 2. What happens at build time if a page declares a `group` slug the config doesn't know about?

The build **fails** with an error like:

```
error: /docs/some-page.mdx declares unknown group "<slug>".
```

This happens during the group-resolution stage of `leadtype generate` (or when calling `resolveDocsNavigation()`). It is intentional — broken navigation is treated as a content bug, not a render-time problem. The CLI exits with code `1`.
