# Navigation in leadtype: `nav` vs. `group`

## 1. Relationship between curated `nav` and legacy `group` frontmatter

**Curated `nav` (in `docs.config.ts`) is the source of truth that drives the
sidebar and the agent map. `group` is legacy taxonomy/compatibility metadata.**

When you define a `nav` array in `docs.config.ts`, that resolved tree is what
powers every navigation surface — human and agent alike:

- top-level docs areas / tabs (e.g. Docs, Frontend, Integrations, Changelog)
- the human sidebar (structure + order)
- `llms.txt` sections
- `AGENTS.md` grouping
- sitemap markdown
- Agent Readability navigation metadata

So `nav` is the single curated structure that keeps the website sidebar and the
agent-facing document map in sync, with no drift between them.

`group` frontmatter is **not** the recommended way to express polished
navigation anymore. It is still valid and still useful for:

- **Legacy navigation fallback** — if a project has *no* `nav` defined, the CLI
  falls back to the legacy group resolver, inferring the tree from the `group:`
  values it finds (combined with the groups declared in `docs.config.ts`). This
  is fine for small docs sets, but `nav` is preferred when you need stable
  top-level areas, sidebar order, descriptions, nested sections, or wildcard
  includes.
- **Search facets** — `group` values feed search metadata/faceting.
- **Broad taxonomy / classification** — a page can carry one or more group
  slugs (`group: <slug>` or `group: [a, b]`) so it can belong to multiple
  taxonomy buckets independent of where it sits in the curated `nav`.

In short: **`nav` decides placement and ordering; `group` describes what a page
*is about* and provides a fallback for projects that haven't migrated.**

### How they relate in practice

- Page strings in `nav` are extensionless paths (relative to the nearest
  `base`, or from the docs root if they start with `/`); `base` cascades to
  child nodes, and `{ include: "folder/*", sort: ["order", "path"] }` entries
  pull in the rest of a folder. This is the curated structure.
- `group` keeps validating as taxonomy. The migration guidance is to move
  curated structure into `nav`, keep `group` only as taxonomy/compatibility
  metadata, and keep frontmatter `order` only where wildcard includes need a
  stable fallback sort.

## 2. What happens at build time for an unknown `group` slug

**The build fails.** If a page declares a `group` slug that the config
(`docs.config.ts`) does not know about, `leadtype generate` errors out with:

```
unknown group "<slug>"
```

This is intentional, not a render-time edge case — leadtype treats broken
navigation as a *content bug* that should fail loudly rather than silently
produce a wrong tree. The failure surfaces as:

- a noisy `generate` failure (`error: <urlPath> declares unknown group
  "<slug>".`), and
- a CLI **exit code `1`** (runtime error), which fails the build/CI step.

The design goal is "same source of truth, no drift": every group a page
references must be declared once in the config, so the website nav, `llms.txt`,
and `AGENTS.md` can never diverge from what the pages actually claim.

> Sources: `docs/authoring/frontmatter.md`, `docs/how-it-works.md`,
> `docs/reference/cli.md`, `docs/changelog/nav-migration-prompts.md` in the
> bundled `leadtype` package docs.
