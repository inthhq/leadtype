# Nav vs. `group` frontmatter in Leadtype

## 1. Which one drives the sidebar and agent map, and what is the other still good for?

**Config `nav` drives everything.** The curated `nav` array in `docs.config.ts` is the source of truth for the sidebar, `llms.txt` sections, `AGENTS.md` grouping, sitemap markdown, search metadata, and Agent Readability navigation. Root `nav` nodes become top-level docs areas (tabs), and their children become sidebar sections.

**`group` frontmatter is legacy taxonomy metadata.** It is still valid, but it is no longer where polished navigation lives. It remains useful for three things:

1. **Fallback navigation** — in projects that have not adopted `nav`, Leadtype falls back to the legacy group resolver and builds the nav tree from the intersection of config `groups` and page `group` frontmatter.
2. **Search facets** — group slugs can still feed search/filter taxonomy.
3. **Compatibility** — existing docs that rely on `group` continue to work until you migrate them to `nav`.

In short: put intentional product navigation in `nav`; keep `group` only as broad taxonomy or during a migration.

## 2. What happens at build time if a page declares a `group` slug that the config doesn't know about?

**The build fails.** Leadtype treats unknown groups as a content bug, not a runtime warning.

Specifically:

- The CLI exits with code `1` (runtime error).
- The error message names the offending file and slug, e.g.:
  ```
  error: /docs/some-page declares unknown group "missing-slug".
  ```
- This happens during the group-resolution step of `leadtype generate`, before any LLM files, search index, or nav manifest are written.

If you are using the `resolveDocsNavigation` API directly, the returned object has an `unknown` array you can inspect; the CLI turns any entries in that array into the fatal error above. This applies in legacy/fallback mode when `nav` is not present or when `groups` are explicitly declared in config.
