# Navigation in Leadtype: Nav Config vs. Legacy Group Frontmatter

## 1. Relationship Between Curated `nav` and Legacy `group` Frontmatter

### The Hierarchy: Which Drives What?

**The curated `nav` in `docs.config.ts` is the primary driver** for the sidebar and agent map. It defines the canonical navigation structure and is the modern, recommended approach for curated docs sites.

**The `group` frontmatter field is a legacy taxonomy field** that provides secondary functionality:

```
docs.config.ts nav → drives sidebar, llms.txt sections, AGENTS.md structure, sitemap, robots
group frontmatter → supports legacy fallback, search facets, broad taxonomy
```

### What Each Does

#### `nav` (Curated Navigation)
The `nav` structure in `docs.config.ts` is the **authoritative navigation specification**. It:
- **Drives the sidebar structure** — determines page order and nesting
- **Drives the agent map** — generates `AGENTS.md`, `llms.txt` sections, and sitemap entries
- **Drives search metadata** — provides context for search facets
- **Enables advanced features** — supports nested sections, wildcard includes with `include: "path/*"`, and sort directives

Example from `docs.config.ts`:
```ts
export default defineDocsConfig({
  product: { name: "c15t", summary: "Developer-first consent management." },
  nav: [
    {
      title: "Frontend",
      children: [
        {
          title: "Next.js",
          base: "frameworks/next",
          children: [
            { title: "Start", pages: ["quickstart", "optimization"] },
            {
              title: "Concepts",
              pages: [
                "concepts/client-modes",
                { include: "concepts/*", sort: ["order", "path"] },
              ],
            },
          ],
        },
      ],
    },
  ],
});
```

#### `group` Frontmatter (Legacy)
The `group` field in page frontmatter is **optional taxonomy metadata** that:
- **Provides fallback navigation** — only used if `nav` is absent from the config
- **Enables page sharing** — allows a single page to belong to multiple groups with `group: [slug-a, slug-b]`
- **Supports search facets** — can be used for filtering in search interfaces
- **Keeps broad taxonomy** — useful for rough classification even when `nav` is the primary driver

Example page frontmatter:
```mdx
---
title: "Advanced Patterns"
description: "..."
group: guides
---
```

### When to Use Each

| Situation | Use `nav` | Use `group` |
|-----------|-----------|-----------|
| Need stable top-level docs areas | ✓ | — |
| Need sidebar ordering | ✓ | — |
| Want nested sections | ✓ | — |
| Using wildcard includes | ✓ | — |
| Page shared across multiple categories | — | ✓ |
| Small docs with minimal structure | Can omit | ✓ |
| Search facets or broad taxonomy | — | ✓ |

### Practical Example

For a curated docs site (recommended), put navigation in `nav`:

```ts
// docs.config.ts
nav: [
  { title: "Getting Started", pages: ["intro", "setup"] },
  { title: "Guides", pages: [{ include: "guides/*" }] },
  { title: "API Reference", pages: [{ include: "reference/*" }] },
]
```

The `group` field in page frontmatter becomes **optional taxonomy metadata** for search or advanced features, not the primary navigation driver:

```mdx
---
title: "useAuth Hook"
group: [reference, hooks]  // Multi-category membership, not primary navigation
---
```

---

## 2. What Happens at Build Time When a Page Declares an Unknown Group Slug

### The Behavior: Build Failure with Explicit Error

**If a page declares a `group` slug that isn't in `docs.config.ts`, the build fails immediately with an error.**

This is intentional behavior to prevent silent navigation inconsistencies.

### The Error

When `leadtype generate` runs and encounters an unknown group, it exits with:

- **Exit code: `1`** (runtime error)
- **Error message:** `error: <page-url-path> declares unknown group "<slug>"`
- **Example:**
  ```
  error: /docs/advanced-patterns declares unknown group "tutorials"
  ```

### Why It Fails

From the leadtype documentation:

> "If a page declares a group slug that isn't in `docs.config.ts`, the build fails with `unknown group "<slug>"`. Same source of truth, no drift."

And from the how-it-works guide:

> "If step 3 finds an unknown group, the run fails. That is by design — broken navigation is a content bug, not a render-time problem."

### The Design Principle

This strict validation enforces a **single source of truth for navigation groups**:

1. **All group slugs must be declared** in `docs.config.ts` (either in `nav` or legacy `groups` config)
2. **Pages cannot reference undefined groups** — this prevents accidental orphaned or miscategorized pages
3. **Errors surface early** — at build time, not at runtime or silently in generated artifacts

### Fallback Behavior

The build has two modes:

| Mode | Condition | Behavior |
|------|-----------|----------|
| **Config mode** | `docs.config.ts` with `nav` or `groups` exists | Uses config groups; any undeclared group slug → **build fails** |
| **Inference mode** | No config file, or no `groups`/`nav` | Infers groups from union of `group:` values found in pages; works for small docs but no validation |

In inference mode, unknown groups don't fail because the config doesn't exist. But once you create `docs.config.ts` with explicit group declarations, all pages must reference only declared groups.

### Practical Guidance

To avoid build failures:

1. **Declare all groups in `docs.config.ts`** before pages reference them
2. **Use `nav` for new docs** — it's the modern, recommended approach
3. **Run `leadtype lint`** in CI before `leadtype generate` to catch group mismatches early with file/line context
4. **Check the error message** — it tells you the exact page and the offending slug

Example CI validation:
```bash
# Fail fast on content schema problems with context
leadtype lint docs

# Then generate artifacts safely
leadtype generate --src . --out public
```

---

## Summary

| Aspect | `nav` Config | `group` Frontmatter |
|--------|-------------|-------------------|
| **Purpose** | Curated navigation structure | Legacy taxonomy & fallback |
| **Drives sidebar** | ✓ | — |
| **Drives agent map** | ✓ | — |
| **Multi-group support** | — | ✓ |
| **Recommended for new docs** | ✓ | — |
| **Unknown slug handling** | **Build fails with error** | **Build fails with error** |

Both are validated against the same source of truth, and both will cause build failure if a page references a slug not declared in the config. This strict validation ensures navigation consistency and prevents silent errors in generated artifacts.
