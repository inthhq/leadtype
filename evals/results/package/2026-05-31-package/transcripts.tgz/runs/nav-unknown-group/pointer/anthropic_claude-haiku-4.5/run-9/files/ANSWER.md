# Navigation in Leadtype: Nav Config vs. Group Frontmatter

## 1. Relationship Between Config `nav` and Page `group` Frontmatter

### What Drives the Sidebar and Agent Map?

**The curated `nav` in `docs.config.ts` drives the sidebar and agent map.** This is the primary and preferred source of truth for:
- Top-level docs areas (e.g., Docs, API Reference, Changelog tabs)
- Sidebar structure and page ordering
- Generated navigation for `llms.txt`, `llms-full.txt`, and `AGENTS.md`
- Agent-facing document maps and Agent Readability metadata
- Sitemap and robots.txt

### What is `group` Still Good For?

The legacy `group` frontmatter field serves as **taxonomy and compatibility metadata** only. Its remaining purposes are:

1. **Fallback navigation** — In projects without a `nav` config, groups are inferred from frontmatter and used to build a basic navigation tree (alphabetically sorted and title-cased).
2. **Broad taxonomy** — Pages can declare one or more groups (`group: slug` or `group: [a, b]`) to indicate thematic belonging across the site, even if they're not explicitly listed in nav.
3. **Search facets** — Groups can be used for filtering and categorization in search systems.
4. **Validation and consistency** — Declared groups are validated against a known set (either in config or inferred), ensuring no drift between docs and navigation.

### The Resolution Order

According to the Leadtype docs:

> For curated docs sites, put the navigation structure in `docs.config.ts` with `nav`. The active root node's pages and children usually become the sidebar. The same resolved tree drives generated navigation, `llms.txt`, `AGENTS.md`, sitemap markdown, and Agent Readability metadata.
>
> If a page declares a group slug that isn't in `docs.config.ts`, the build fails with `unknown group "<slug>"`. Same source of truth, no drift.

**In summary:**
- **`nav` in config** = primary structure → drives sidebar, agent docs, routing
- **`group` in frontmatter** = metadata + fallback → for taxonomy, compatibility, and legacy projects without nav

---

## 2. Build-Time Behavior: Unknown Groups

### What Happens When a Page Declares an Unknown Group?

**The build fails with an error.**

Specifically:
- If a page's `group` frontmatter declares a slug that is not listed in the project's `docs.config.ts` (or inferred from other pages when no config exists), `leadtype generate` exits with code `1` (runtime error).
- The error message is: `unknown group "<slug>"`

This is enforced to maintain a **single source of truth** for navigation. The config and frontmatter must be in sync.

### When This Check Occurs

The unknown group check happens during:
- **`leadtype generate`** — the main build command. Exit code is `1` on unknown group.
- **`leadtype lint`** — frontmatter validation can be extended to check groups, but the default lint schema accepts `group` as optional and does not validate against config (the check is part of the generation pipeline, not lint).

### How to Declare Groups Properly

To use legacy `group` frontmatter, you must first declare the group in `docs.config.ts`:

```ts
export default defineDocsConfig({
  product: { name: "My Library", summary: "..." },
  groups: [
    { slug: "get-started", title: "Getting Started" },
    { slug: "reference", title: "API Reference" },
  ],
  // ... nav structure
});
```

Or, if the project is small and has no `nav` config, groups are **inferred** from the union of all `group:` values across pages. In that case, no explicit declaration is needed (Leadtype infers and sorts them alphabetically).

### Practical Implications

1. **Migration path**: When migrating to config-owned `nav`, you can keep `group` declarations in frontmatter for backward compatibility and taxonomy, but they are no longer required to drive navigation.
2. **Validation**: Use `leadtype lint` in CI to catch missing required fields and schema errors. The unknown group error surfaces during `generate`, ensuring you catch it before a failed build reaches production.
3. **No silent fallback**: If a group is unknown, the build fails hard rather than silently dropping the page or misplacing it. This prevents accidental loss of content.
