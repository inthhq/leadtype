# Navigation in Leadtype

Below are the answers regarding the navigation system and legacy frontmatter in `leadtype`.

---

### 1. Curated `nav` in `docs.config.ts` vs. Legacy `group` Frontmatter

#### Which one drives the sidebar and agent map?
The curated **`nav` structure in `docs.config.ts`** drives the curated sidebar, navigation tree, and the entire agent map (including `llms.txt` sections, `AGENTS.md`, sitemap markdown, and Agent Readability metadata like `agent-readability.json`).

#### What is the other still good for?
The legacy **`group` frontmatter field** is still useful for:
* **Fallback Navigation**: It acts as the navigation fallback for smaller or simpler projects that have not yet adopted a curated `nav` configuration.
* **Search Facets & Filtering**: It serves as structured taxonomy metadata used for search indexing, filtering, and facets.
* **Broad Taxonomy Metadata**: It allows categorization of pages across multiple groups (since pages can declare multiple group slugs with `group: [a, b]`).

---

### 2. Build-Time Behavior for Unknown `group` Slugs

If a page declares a `group` slug that is not defined in `docs.config.ts`, the following happens at build time during the **Resolve groups** validation stage (Step 3 of the `leadtype` CLI pipeline):

1. **The build fails fast and noisily**: The run immediately aborts with exit code `1` (runtime/build error). This prevents shipping broken configuration or out-of-sync navigation to production or into package bundles.
2. **Error Logging**: An error message is written to `process.stderr` indicating the path and the offending slug:
   ```bash
   error: <urlPath> declares unknown group "<slug>".
   ```
3. **Design Philosophy**: This fail-fast constraint is intentional. Broken navigation is treated as a **content bug** that must be resolved at authoring/compilation time to prevent drift between frontmatter declarations and the configuration.
