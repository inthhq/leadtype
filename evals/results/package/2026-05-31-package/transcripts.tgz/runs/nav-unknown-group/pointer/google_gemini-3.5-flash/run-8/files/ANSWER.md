# Leadtype Navigation & Taxonomy Q&A

### 1. What is the relationship between the curated `nav` in `docs.config.ts` and a page's legacy `group` frontmatter field — which one drives the sidebar and agent map, and what is the other still good for?

* **Driving Sidebar & Agent Map**: 
  The curated config-owned `nav` in `docs.config.ts` is the active driver for the curated sidebar, sitemap markdown, Agent Readability navigation, `llms.txt` sections, and the `AGENTS.md` file. It models the documentation Information Architecture (IA) as product navigation rather than a flat or loosely-linked taxonomy of files.

* **What legacy `group` is still good for**: 
  While `nav` is the preferred way to curate structure and page placement, the legacy `group` frontmatter field is still useful for:
  1. **Fallback Navigation**: It acts as the navigation fallback for projects or sections that have not adopted the config-owned `nav` layout.
  2. **Search Facets and Filters**: It provides structured metadata useful for grouping search indexes and applying taxonomy filters.
  3. **Broad Taxonomy Metadata**: It allows a page to express taxonomy categorizations and can accept multiple values (e.g. `group: [a, b]`) to share pages across multiple taxonomy categories.

---

### 2. What happens at build time if a page declares a `group` slug that the config doesn't know about?

At build time, `leadtype` validates all group declarations to prevent drift. If a page declares a `group` slug that is not defined or known in `docs.config.ts`:

* **Build Failure**: The build/generation fails noisily and fast, terminating with exit code `1` (runtime error).
* **Error Logging**: It writes a descriptive error to standard error (`stderr`), e.g., `error: <urlPath> declares unknown group "<slug>".`.
* **Rationale**: This fail-fast behavior is by design. Broken navigation or an unknown legacy group is treated as a severe content bug rather than a minor render-time issue, ensuring a bad config/broken state cannot be shipped to production.
