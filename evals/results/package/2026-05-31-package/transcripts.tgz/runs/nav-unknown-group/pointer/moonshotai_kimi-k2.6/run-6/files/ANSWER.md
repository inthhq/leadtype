# Navigation: `nav` vs. legacy `group`

## 1. Which one drives the sidebar and agent map, and what is the other still good for?

- **`nav` in `docs.config.ts` is the driver.**  
  It produces the sidebar, the top-level docs areas (tabs), and every agent-facing navigation artifact: `llms.txt`, `AGENTS.md`, sitemap markdown, Agent Readability metadata, and the navigation manifest consumed by `resolveDocsNavigation()`.

- **`group` in page frontmatter is legacy taxonomy metadata.**  
  It is no longer the best place to express curated navigation, but it is still valid and useful for:
  - **Fallback navigation** in projects that have not adopted `nav` yet.
  - **Search facets** and broad taxonomy tagging.
  - **Compatibility metadata** (e.g. indicating which conceptual bucket a page belongs to without dictating sidebar order).

As the docs put it:

> *Config `nav` drives `llms.txt` sections, navigation, sitemap markdown, Agent Readability navigation, and `AGENTS.md` when present. Legacy `group` metadata remains the fallback for projects that have not adopted `nav`, and still works as search/filter taxonomy.*

---

## 2. What happens at build time if a page declares a `group` slug that the config doesn't know about?

The build **fails**.

During `leadtype generate`, the pipeline resolves groups from frontmatter and validates that every `group:` value matches a known slug defined in the config. If a page references an unknown group, the run stops with an error like:

```
/docs/some-page declares unknown group "missing-slug"
```

This is intentional: broken navigation is treated as a content bug, not a render-time problem. The CLI exits with code `1`, and no artifacts (`llms.txt`, `AGENTS.md`, search index, etc.) are produced until the mismatch is fixed.
