# Leadtype navigation and legacy groups

1. Curated `nav` in `docs.config.ts` is the source of truth for intentional navigation. When present, it drives the human sidebar/navigation tree and the agent-facing map: `llms.txt`, `AGENTS.md`, sitemap markdown, and Agent Readability navigation all use the resolved `nav` structure. A page's frontmatter `group` is legacy metadata; keep it for projects that still need fallback group-based navigation, compatibility with older pipelines, broad taxonomy, and search/filter facets. If you want existing `group` values to keep being validated after migrating to `nav`, keep a legacy `groups` list in the config too.

2. If a page declares a legacy `group` slug that is not declared in the loaded config's legacy `groups`, the build fails instead of silently placing it somewhere else. `resolveDocsNavigation()` reports it in `navigation.unknown`, and the CLI turns that into a non-zero build error like:

   ```text
   /docs/some-page declares unknown group "bad-slug"
   ```

   In other words: unknown legacy groups are treated as a content/config drift bug to fix at build time, not as a runtime/sidebar fallback.
