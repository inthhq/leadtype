# Navigation in Leadtype: Nav Config vs. Legacy Group Frontmatter

## 1. Relationship Between `nav` Config and `group` Frontmatter

### Which one drives the sidebar and agent map?

**`nav` in `docs.config.ts` drives both the sidebar and agent map.** This is the curated, config-owned navigation structure that determines:

- Rendered sidebar ordering and structure
- Section headings and hierarchy in generated `llms.txt`
- Structure of generated `AGENTS.md` (for bundled package docs)
- Agent Readability JSON metadata
- Sitemap and robots.txt organization

### What is `group` frontmatter still good for?

The legacy `group` field in frontmatter remains available for **three purposes**:

1. **Backward compatibility** — Pages can continue declaring `group: <slug>` or `group: [a, b]` without breaking builds, allowing gradual migration to config-owned nav.

2. **Taxonomy and multi-group assignment** — A single page can belong to multiple groups via `group: [a, b]`, enabling pages to be categorized under different taxonomies without physical duplication.

3. **Fallback navigation and search facets** — When a project hasn't yet adopted `nav`, the group resolver uses `group` values from frontmatter to infer a navigation tree. This is a **legacy fallback** — "enough for small docs sets, but use config `nav` when you need stable top-level docs areas, sidebar order, descriptions, nested sections, or wildcard includes."

### The mental model

Think of it this way:
- **`nav` config** = intentional, curated structure (like defining a book's table of contents)
- **`group` frontmatter** = taxonomy labels (like labeling articles with subject tags)

Once you adopt `nav`, your `group` declarations become optional metadata—they **validate** against the config but no longer **drive** the navigation tree.

---

## 2. What Happens at Build Time with Unknown Groups

**If a page declares a `group` slug that the config doesn't know about, `leadtype generate` fails with an error.**

### The exact failure

The build fails during **step 3 of the generation pipeline** — after markdown conversion but before artifact generation. The error message is:

```
error: <file-path> declares unknown group "<slug>".
```

This is intentional design. From the Leadtype documentation:

> If step 3 finds an unknown group, the run fails. That is by design — broken navigation is a content bug, not a render-time problem.

### Why this is strict

The CLI enforces a **"same source of truth, no drift" principle**. By failing the build on unknown groups, Leadtype prevents:

1. **Silent navigation bugs** — A page with a mistyped group slug wouldn't silently disappear from navigation; the error surfaces immediately.
2. **Inconsistency between human and agent outputs** — If the build allowed unknown groups, the page's placement in `llms.txt` or `AGENTS.md` would be undefined, causing agent docs to diverge from the human sidebar.
3. **Confidence errors from agents** — Without explicit documentation of this behavior, agents reading bundled docs about an unknown-group edge case consistently gave **wrong answers with high confidence** (only 10–20% correct). The Leadtype evals benchmark found this gotcha so important that **"what happens if a page declares an unknown group"** is a core test case: docs visibility on this single issue improved agent correctness from 20% (without docs) to 100% (with docs).

### Exit code

The failure sets exit code `1` (runtime error), which causes CI pipelines to fail the build before deploy.

### No override or fallback

There is no flag to "warn instead," no `--allow-unknown-groups` escape hatch, and no fallback behavior to omit the page silently. The config and frontmatter must agree.

---

## Summary

| Aspect | `nav` Config | `group` Frontmatter |
|--------|--------------|-------------------|
| **Drives sidebar?** | ✅ Yes (primary) | ❌ No (legacy only) |
| **Drives agent map?** | ✅ Yes (primary) | ❌ No (legacy only) |
| **Use case** | Curated structure, top-level sections, nested sidebars | Taxonomy tags, multi-group membership, fallback navigation |
| **Unknown value behavior** | N/A | **Build fails** with "unknown group" error |
| **Validation** | Pages in nav must exist | Pages' group slugs must be declared in config |

When a page declares a group the config doesn't recognize, the build stops immediately. This strict validation ensures that all navigation is intentional, consistent, and documented — a critical design choice that measurably improves agent reliability.
