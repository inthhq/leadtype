# Navigation in Leadtype: `nav` config vs. legacy `group` frontmatter

## 1. Relationship between `nav` config and `group` frontmatter

### Which one drives the sidebar and agent map?

**The curated `nav` in `docs.config.ts` drives the sidebar and agent map.** When present, it becomes the source of truth for:
- Rendered sidebar structure
- `llms.txt` sections
- `AGENTS.md` sections
- Generated navigation
- Agent Readability metadata
- Sitemap markdown

### What is the legacy `group` field still good for?

The `group` frontmatter field is **legacy taxonomy metadata** that remains available for:
- **Fallback navigation** — if you haven't adopted `nav` yet, each group slug declared in pages' `group:` fields automatically infers the nav tree
- **Search facets** — groups can still be used as taxonomy for filtering search results
- **Broad taxonomy** — if you need to categorize content beyond what the curated `nav` structure provides

This is summarized in the leadtype docs as:
> `nav` drives top-level docs areas, sidebar structure, `llms.txt`, `AGENTS.md`, sitemap markdown, and Agent Readability navigation. `group` remains available for legacy navigation fallback, search facets, and broad taxonomy.

**The design principle**: Config-owned `nav` is explicit and stable, while legacy groups allow gradual migration from older docs structures.

---

## 2. Build-time behavior for unknown `group` slugs

If a page declares a `group` slug that **isn't declared in `docs.config.ts`**, **the build fails with an error**:

```
unknown group "<slug>"
```

This enforces a **single source of truth** — pages and config must stay in sync. You cannot reference a group that hasn't been registered in the configuration, preventing silent misconfigurations or typos that might cause pages to disappear from navigation.

From the frontmatter documentation:
> If a page declares a group slug that isn't in `docs.config.ts`, the build fails with `unknown group "<slug>"`. Same source of truth, no drift.

This is validated via the lint rules: the `schema` rule in `leadtype lint` will flag these as errors before generation runs.
