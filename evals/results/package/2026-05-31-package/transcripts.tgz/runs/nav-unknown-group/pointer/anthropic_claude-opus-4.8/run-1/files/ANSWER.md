# Navigation in leadtype: `nav` vs. legacy `group`

## 1. Relationship between curated `nav` and the `group` frontmatter field

**The curated `nav` in `docs.config.ts` is the source of truth that drives the sidebar and the agent map.** When a project defines `nav`, that resolved navigation tree is what produces:

- top-level docs areas / tabs (e.g. Docs, Frontend, Integrations, Changelog),
- the sidebar structure and ordering,
- `llms.txt`,
- `AGENTS.md`,
- the sitemap markdown,
- and the Agent Readability navigation metadata.

So both the human surface (sidebar) and the agent surface (the "agent map" — `llms.txt`, `AGENTS.md`, `agent-readability.json`) come from the same config-owned `nav` tree. This is deliberate: one source of truth, no drift between what humans and agents see.

**The page-level `group` frontmatter field is optional legacy taxonomy metadata.** It does *not* drive a curated site's sidebar or agent map. It is still useful for:

- **Legacy navigation fallback** — if a project has *not* adopted `nav`, the CLI falls back to a legacy "group resolver." It infers the navigation tree by intersecting the `group:` slugs found on pages with the group declarations in `docs.config.ts`, producing the fallback nav tree, the `llms.txt` section headings, and the `AGENTS.md` grouping. This fallback is fine for small docs sets, but `nav` is recommended once you need stable top-level areas, explicit sidebar order, descriptions, nested sections, or wildcard includes.
- **Search facets** — `group` remains available as search/taxonomy metadata.
- **Broad taxonomy / categorization** — a page can belong to one or more groups (`group: <slug>` or `group: [a, b]`), so it can be shared across multiple taxonomy buckets.

In short: in a curated project, **`nav` placement is authoritative**, while `group` stays around for legacy fallback navigation, search faceting, and broad cross-cutting taxonomy.

## 2. What happens at build time when a page declares an unknown `group` slug

**The build fails.** If a page declares a `group` slug that is not declared in `docs.config.ts`, `leadtype generate` errors out with a message like:

```
unknown group "<slug>"
```

This is by design — a broken/unknown group is treated as a content bug rather than something tolerated at render time. Concretely:

- `generate` fails noisily on unknown groups (and broken includes), which surfaces the problem in CI before it reaches a build.
- The CLI exits with code `1` (runtime error) for an unknown group, alongside other runtime failures like a missing docs dir, config load error, or conversion error.

The intent is to keep the config and the pages as a single source of truth so the navigation never silently drifts.
