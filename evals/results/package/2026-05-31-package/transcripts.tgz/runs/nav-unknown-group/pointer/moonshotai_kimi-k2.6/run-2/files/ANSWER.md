# Navigation: `nav` vs. `group`

## 1. Which one drives the sidebar and agent map, and what is the other still good for?

**Config-owned `nav` drives the sidebar and agent map.**

When `docs.config.ts` contains a curated `nav` array, that tree is the single source of truth for:
- Sidebar structure
- `llms.txt` sections
- `AGENTS.md` grouping
- Sitemap markdown
- Agent Readability navigation metadata
- Search metadata

**The page-level `group` frontmatter field is a legacy fallback.** It is still useful for:
- **Fallback navigation** — in small projects that have not adopted `nav`, leadtype falls back to the legacy group resolver, which infers groups from the `group:` values it finds on pages.
- **Search facets and broad taxonomy** — even when `nav` is present, `group` can still feed search/filter categorization.

The docs explicitly state: *“Config `nav` drives `llms.txt` sections, navigation, sitemap markdown, Agent Readability navigation, and `AGENTS.md` when present. Legacy `group` metadata remains the fallback for projects that have not adopted `nav`, and still works as search/filter taxonomy.”*

## 2. What happens at build time if a page declares a `group` slug the config doesn't know about?

**The build fails.**

During group resolution, if a page frontmatter declares a `group` slug that is not declared in `docs.config.ts` (or not matched by the `nav` tree), the generator emits an error and exits non-zero:

```
error: /docs/some-page declares unknown group "missing-slug".
```

This is by design — the docs call it a *content bug, not a render-time problem*. The CLI returns exit code `1` for this case, and `leadtype lint` is recommended to catch related issues earlier in CI.
