# Leadtype navigation notes

1. **`docs.config.ts` `nav` is the curated source of truth.** When present, `nav` drives the resolved navigation tree used for the human sidebar/top-level docs areas and the agent-facing map: `llms.txt` sections, `AGENTS.md`, sitemap markdown, and Agent Readability navigation. A page's legacy `group` frontmatter does **not** decide curated sidebar placement in a `nav`-based project. It remains useful as compatibility/taxonomy metadata: legacy fallback navigation for projects that have not adopted `nav`, broad grouping/search/filter facets, and optional validation if you still keep `groups` in config.

2. **Unknown legacy groups fail the build when group validation is in play.** If a page declares `group: some-slug` and the loaded config's legacy `groups` tree does not contain `some-slug`, Leadtype fails during generation/navigation validation with an error like:

   ```text
   /docs/page declares unknown group "some-slug"
   ```

   That is intentional: Leadtype treats broken navigation metadata as a content/config bug and stops before shipping inconsistent artifacts. If there is no config to validate against, Leadtype can infer fallback groups from frontmatter; with curated `nav`, page placement still comes from `nav`, not from `group`.