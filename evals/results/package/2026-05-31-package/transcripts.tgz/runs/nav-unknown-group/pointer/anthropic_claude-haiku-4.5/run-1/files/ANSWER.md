# Navigation and Legacy Groups in Leadtype

## 1. The Relationship Between `nav` Config and Legacy `group` Frontmatter

### Which Drives What

**`nav` in `docs.config.ts` drives the sidebar and agent map.**

The curated `nav` structure is the authoritative navigation configuration. It controls:
- Top-level docs areas (tabs like Docs, Frontend, Integrations, Changelog)
- Sidebar structure and section hierarchy
- Generated navigation files (`llms.txt`, `AGENTS.md`, sitemap markdown)
- Agent Readability metadata
- Page ordering and nesting

### What Is `group` Still Good For

The legacy `group` frontmatter field is still useful, but primarily as:
- **Taxonomy/compatibility metadata** — labeling pages for categorization beyond nav structure
- **Fallback navigation** — in projects that have not yet adopted `nav`, each declared group slug produces a fallback navigation tree from page `group` values
- **Search facets** — pages can continue to be tagged with one or more group slugs for search filtering and classification
- **Backward compatibility** — allows old docs to validate without migration to `nav`

From the documentation:
> `group` remains available for legacy navigation fallback, search facets, and broad taxonomy.

### Practical Shape

For a modern leadtype project:
- Use `nav` in config for intentional, curated navigation structure
- Use `group` in page frontmatter as supplementary taxonomy if needed
- If your docs site has not adopted `nav` yet, pages' `group` values are used to infer a fallback tree (one group slug per page implies one tree path)

---

## 2. What Happens at Build Time With Unknown Group Slugs

**The build fails with an explicit error.**

If a page declares a `group` slug (via `group: <slug>` or `group: [a, b, c]`) that is not recognized in `docs.config.ts`, the generation process terminates with an error exit code and outputs:

```
error: <urlPath> declares unknown group "<slug>".
```

This is **by design** — it is treated as a content bug, not a render-time problem. The same configuration file serves as the source of truth for both what groups are valid and how the navigation tree is built. This prevents silent navigation misconfigurations from slipping through.

### When This Validation Happens

This validation occurs during:
- `leadtype generate` (site-mode artifact generation)
- `createDocsSource()` loading (framework-integrated source primitive)
- Any navigation resolution that consumes `group` values

### Related Linting

While the group-mismatch error happens at generation/load time, `leadtype lint` (which runs earlier in the pipeline) validates the frontmatter schema—making it a good practice to run lint in CI *before* generation so problems surface with file/line context.

### Exit Code

A build failure due to unknown groups results in exit code `1` (runtime error).
