# Navigation: `nav` vs. legacy `group`

## 1. Which drives the sidebar and agent map, and what is the other still good for?

**`nav` in `docs.config.ts` drives the sidebar and the agent map.** It is the preferred, config-owned way to declare top-level docs areas, sidebar order, nested sections, wildcard includes, and agent-facing document structure. The resolved `nav` tree feeds `llms.txt`, `AGENTS.md`, sitemap markdown, search metadata, and the human sidebar.

**`group` in page frontmatter is legacy taxonomy metadata.** It is still valid and useful for:
- **Fallback navigation** — if a project has not adopted `nav`, leadtype falls back to the legacy group resolver and builds a nav tree from the `group` values it finds in frontmatter.
- **Search facets** — broad taxonomy tagging that can surface pages across curated sections.
- **Compatibility** — existing docs sets that have not migrated to `nav` continue to work.

When both are present, `nav` wins. As the leadtype docs put it: *"Config nav now drives curated sidebar and agent-map structure; group remains useful for fallback navigation and search facets."*

## 2. What happens at build time if a page declares a `group` slug the config doesn't know about?

**The build fails.** Leadtype validates every page's `group` against the known slugs in `docs.config.ts` (or the collection's `groups` array). If a page declares a group slug that is not defined in the config, the run exits with an error like:

```
unknown group "<slug>"
```

This is intentional: *"If step 3 finds an unknown group, the run fails. That is by design — broken navigation is a content bug, not a render-time problem."* The single source of truth in the config prevents silent drift between frontmatter and navigation output.
