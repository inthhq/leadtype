# Navigation: `nav` vs. legacy `group`

## 1. Which drives the sidebar and agent map, and what is the other still good for?

**`docs.config.ts` `nav` drives the sidebar and agent map.**

When present, `nav` is the source of truth for:
- Curated sidebar structure
- `llms.txt` sections
- `AGENTS.md` grouping
- Sitemap markdown
- Agent Readability navigation metadata
- The navigation manifest consumed by `createDocsSource().getNavigation()`

**The page-level `group` frontmatter field is legacy taxonomy metadata.** It is no longer the best place to express polished navigation, but it remains useful for:
- **Fallback navigation** — if a project has not adopted `nav`, the CLI falls back to the legacy group resolver and builds the nav tree from the intersection of frontmatter `group` values and the `groups` array in `docs.config.ts`.
- **Search facets** — group slugs are still indexed and can be used for filtering/search taxonomy.
- **Compatibility** — keeping `group` in frontmatter allows older tooling or custom pipelines that read it to keep working.

In short: put intentional navigation structure in config `nav`; keep frontmatter `group` as taxonomy/compatibility metadata only.

## 2. What happens at build time if a page declares a `group` slug the config doesn't know about?

**The build fails with a runtime error.**

During `leadtype generate`, the pipeline resolves groups from frontmatter and validates that every page's `group:` matches a known slug in the loaded config. If a page names a group that is not declared in `docs.config.ts` (or the relevant collection config), generation halts and emits an error like:

```
/docs/my-page declares unknown group "my-unknown-group"
```

The CLI exits with code `1` — same as other runtime errors (missing docs dir, config load error, conversion error, etc.).

This is **intentional by design**: broken navigation is treated as a content bug that must be fixed at build time, not silently ignored at render time.

If no `docs.config.ts` exists at all, the CLI falls back to inferring groups from the union of `group:` values found across the generated pages, sorting them alphabetically and title-casing them. In that fallback mode there is no config to be "unknown" against, so the build succeeds.
