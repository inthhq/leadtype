# Navigation in Leadtype: Curated `nav` vs. Legacy `group`

Below are the detailed answers to your questions regarding Leadtype's navigation systems and build-time validation.

---

### 1. Curated `nav` vs. Legacy `group` Frontmatter

#### Which one drives the sidebar and agent map?
* **Curated `nav` (in `docs.config.ts`):** This is the **primary driver** of the polished reader-facing sidebar, top-level tabs/areas, sitemap markdown, sitemap XML, `llms.txt` sections, `AGENTS.md` relative links (in bundle mode), and the agent-facing document map (`agent-readability.json` metadata). Placing navigation structure directly in the configuration file keeps human and agent surfaces completely aligned.

#### What is the other still good for?
* **Legacy `group` frontmatter field:** While curated `nav` is the preferred approach, `group` frontmatter remains supported and serves several key purposes:
  * **Fallback Navigation:** For smaller or legacy projects that have not adopted the curated `nav` API, Leadtype falls back to resolving navigation automatically by combining the page-level `group` fields with a list of `groups` defined in `docs.config.ts`.
  * **Search Facets and Taxonomy:** It acts as metadata for search indexes, enabling the search UI to offer facets and filters.
  * **Compatibility / Metadata:** It remains useful as legacy or compatibility metadata to maintain stable routing taxonomy across various third-party integrations and custom index pipelines.

---

### 2. Build-Time Behavior with Unknown `group` Slugs

If an authored page declares a `group` slug in its frontmatter that isn't defined in the loaded configuration (`docs.config.ts`):

* **The build fails noisily:** At step 3 of the build pipeline ("Resolve groups"), the generation command (`leadtype generate`) will fail with an error message like:
  ```
  error: <urlPath> declares unknown group "<slug>"
  ```
  And the CLI will terminate with exit code `1` (runtime error).
* **The philosophy behind this:** This strict fail-fast behavior is **by design**. Leadtype treats a broken or mismatched navigation state as a **content bug** rather than a render-time warning. Failing the build prevents shipping broken navigation, inaccurate agent maps, or invalid taxonomy to either human readers or search and coding agents.
