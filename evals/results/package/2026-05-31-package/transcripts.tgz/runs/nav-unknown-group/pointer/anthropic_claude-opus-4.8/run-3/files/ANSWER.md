# Leadtype navigation: `nav` vs `group`

## 1. Relationship between curated `nav` and a page's legacy `group` frontmatter

**The curated `nav` in `docs.config.ts` is the source of truth that drives the sidebar and the agent map. The frontmatter `group` field is legacy taxonomy/compatibility metadata that does *not* drive curated navigation.**

### What `nav` drives

`nav` lives in `docs.config.ts` (via `defineDocsConfig`) and describes intentional, curated navigation. The same resolved `nav` tree feeds *every* navigation surface, keeping human and agent views aligned:

- Top-level docs areas / navbar tabs (e.g. Docs, Frontend, Integrations, Changelog) — these come from the root nav nodes.
- The human **sidebar** structure and ordering (the active root node's pages/children).
- `llms.txt` (including nested section headings).
- `AGENTS.md` grouping — i.e. the **agent map**.
- Sitemap markdown and Agent Readability navigation metadata.

`nav` supports `base` (cascading path prefixes), explicit extensionless page strings (a leading `/` starts from the docs root), nested sections, and `{ include: "folder/*", sort: ["order", "path"] }` wildcard includes. This is what you want when you need stable top-level areas, deliberate sidebar order, descriptions, nested sections, or wildcard includes.

### What `group` is still good for

`group` is an optional frontmatter field (a single slug `group: <slug>` or multiple `group: [a, b]`, so a page can belong to several taxonomy groups). Once you have adopted config-owned `nav`, `group` is **no longer** the place to express polished navigation. It remains useful for:

- **Legacy navigation fallback** — if a project has *no* `nav`, the CLI falls back to a legacy group resolver. It infers groups from the `group:` values it finds, intersects them with the `groups` declared in `docs.config.ts`, and produces a fallback nav tree, `llms.txt` section headings, search metadata, and AGENTS.md grouping. This is adequate for small docs sets only.
- **Search facets** — `group` (alongside `tags`) provides taxonomy used in search metadata/faceting.
- **Broad taxonomy / compatibility** — categorizing pages and keeping older content validating during/after a migration.

In short: with `nav` present, `nav` owns the sidebar and the agent map; `group` is retained as taxonomy, search-facet, and fallback-compatibility metadata. The two share the same config so there is no drift.

## 2. What happens at build time if a page declares an unknown `group` slug

**The build fails.** If a page declares a `group` slug that is not known to `docs.config.ts` (it isn't among the declared `groups`), Leadtype errors out with:

```
unknown group "<slug>"
```

This is deliberate: the config and the page frontmatter share a single source of truth, so a typo or an undeclared group is caught at build time rather than silently producing a misplaced or missing navigation entry. To fix it, either correct the slug on the page or declare the group (including nested children, where only leaf groups directly contain pages) in `docs.config.ts`.

Related guardrails come from `leadtype lint`, which enforces the frontmatter schema in CI (e.g. `schema`, `unknown-field`, `invalid-link`) so many problems surface before a build is even attempted.
