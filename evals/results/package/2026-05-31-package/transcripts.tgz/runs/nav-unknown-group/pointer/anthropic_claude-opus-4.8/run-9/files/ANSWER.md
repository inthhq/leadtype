# Navigation in a leadtype project

## 1. Curated `nav` (in `docs.config.ts`) vs. legacy `group` frontmatter

**Config `nav` is the source of truth that drives the sidebar and the agent map.** `group` is legacy taxonomy metadata that no longer drives curated structure — but it still has real uses.

### What `nav` drives

For curated docs sites, you put the navigation structure in `docs.config.ts` under `nav`. The same *resolved* tree is the shared source of truth for:

- Top-level docs areas / tabs (root nav nodes become tabs like Docs, Frontend, Integrations, Changelog)
- The human **sidebar** structure and order (the active root node's pages and children)
- `llms.txt` sections
- `AGENTS.md` sections
- Sitemap markdown
- **Agent Readability** navigation metadata

Because all of these read the one resolved `nav` tree, the human sidebar and the agent-facing surfaces never drift apart. `nav` is what you reach for when you need stable top-level areas, explicit sidebar order, descriptions, nested sections, or wildcard `include` entries.

### What `group` is still good for

`group` is an **optional, legacy taxonomy field** on a page's frontmatter. A page can declare one slug (`group: <slug>`) or several (`group: [a, b]`), so a page can belong to multiple taxonomy groups. It is *not* how you do curated page placement anymore, but it remains useful for:

- **Fallback navigation** — in projects that have **not** adopted `nav`, leadtype falls back to the legacy *group resolver*: each group is declared once in `docs.config.ts`, and the intersection of those declarations with the `group:` values on pages produces the fallback nav tree, the `llms.txt` section headings, and the `AGENTS.md` grouping. If there is no config at all, the CLI infers groups from the union of `group:` values across pages (sorted alphabetically, title-cased).
- **Search facets / broad taxonomy** — `group` continues to work as a search/filter dimension even when `nav` owns the curated structure.

So: **`nav` drives the sidebar and the agent map; `group` is a fallback navigation mechanism for projects without `nav`, plus a durable search/taxonomy facet.**

## 2. What happens at build time if a page declares an unknown `group` slug

**The build fails.** If a page declares a `group` slug that isn't known to the loaded `docs.config.ts`, generation errors out in fallback mode with `unknown group "<slug>"`. This is deliberate "same source of truth, no drift" behavior — a bad config can't silently ship.

Concretely:

- `leadtype generate` treats this as a runtime error and exits with **code `1`** (the same exit code used for a missing docs dir, config load errors, conversion errors, etc.). The CLI lists "unknown group" explicitly among the conditions that cause exit `1`.
- The library API surfaces the same condition: `resolveDocsNavigation(...)` returns an `unknown` array of `{ urlPath, slug }` entries. Custom build/bundle scripts are expected to check it and fail fast — e.g. printing `error: <urlPath> declares unknown group "<slug>".` and calling `process.exit(1)` — so a bad config never reaches `npm publish`.

Note this is specifically the fallback/group path. The point of moving curated structure into config `nav` is exactly to keep page placement and the config in lockstep, so unknown-group drift simply can't happen unnoticed.
