# Navigation and legacy groups in Leadtype

1. **`nav` is the curated source of truth for navigation.** When `docs.config.ts` defines `nav`, that resolved tree drives the human docs navigation/sidebar and the agent-facing maps: generated navigation, `llms.txt`, `AGENTS.md`, sitemap markdown, and Agent Readability metadata. A page's frontmatter `group` is legacy metadata in that mode. It is still useful as taxonomy/compatibility data, for search facets or broad classification, and as the fallback navigation mechanism for projects that have not adopted `nav` yet. Keeping `groups` in config can also preserve validation of those legacy `group` values.

2. **An unknown configured group is a build error.** During `leadtype generate`, Leadtype resolves the docs navigation and checks page `group` values against the configured `groups` taxonomy. If a page declares a slug that is not known to the config, generation fails instead of silently putting the page in the wrong place. The error is reported in the form:

   ```text
   /docs/... declares unknown group "<slug>"
   ```

   In other words: `nav` controls placement, but any legacy `group` values you choose to keep should still match the configured `groups` list so taxonomy does not drift.