# Navigation in Leadtype: `nav` vs. `group`

## 1. Relationship between `nav` in `docs.config.ts` and legacy `group` frontmatter

In Leadtype, there is a clear distinction and a progressive relationship between the curated `nav` in `docs.config.ts` and the legacy `group` frontmatter field:

* **Curated `nav` in `docs.config.ts`** is the modern, preferred, and config-owned approach to defining a documentation site's Information Architecture (IA). It supports nested sections, stable top-level tabs/areas, and wildcard include directives (e.g., dynamically matching pages using path patterns).
* **`group` frontmatter** is an optional legacy taxonomy and compatibility metadata field declared on individual markdown pages (e.g., `group: authoring`). It maps pages to flat, config-defined groups or falls back to alphabetical/title-cased inferred groups.

### Which one drives the sidebar and agent map?
* **Curated `nav`** is the primary driver of all navigation artifacts. When configured, it is the single source of truth that drives:
  * The **human-facing sidebar** and top-level navigation tabs.
  * The **agent map** and AI-discovery surfaces, including `llms.txt`, `llms-full.txt`, `AGENTS.md` (relative-link offline index), sitemap markdown, and Agent Readability metadata (such as `agent-readability.json`).
* *Note:* If a project has not yet migrated to or adopted the `nav` configuration, Leadtype falls back to the legacy group resolver (intersecting `group` frontmatter with the `groups` array in `docs.config.ts` or inferring them automatically) to build a basic fallback navigation tree and headings.

### What is the other still good for?
The legacy `group` frontmatter remains supported and is still highly useful for:
1. **Fallback/Legacy Navigation:** For small doc sets or sites that have not yet adopted/migrated to config-owned `nav`, it provides an automated fallback tree.
2. **Search Facets & Broad Taxonomy:** It is used as categorization/filter metadata for search queries and indexing.
3. **Multi-taxonomy Placement:** Since a page's frontmatter can declare multiple groups (e.g., `group: [a, b]`), it is useful for sharing pages across multiple taxonomy categories.


## 2. Build-Time Behavior for Unknown `group` Slugs

At build time, during the group resolution stage (Step 3 of the `leadtype generate` or `leadtype build` pipeline), Leadtype parses and validates the `group` metadata:

* **Strict Fail-Fast Validation:** If a page declares a legacy `group` slug (e.g., `group: unknown-slug`) that is not declared or recognized in `docs.config.ts` (or in the loaded configuration), **the build/generation run fails completely** with an `unknown group "<slug>"` error (exiting with exit code `1`).
* **Why this happens:** This behavior is **by design**. Leadtype treats inconsistent or broken navigation/taxonomy as a critical **content bug** that should prevent publishing entirely, rather than a runtime layout/render problem. Failing fast in CI prevents drifted, broken, or unlinked documents from reaching production.
