# Leadtype Navigation & Build-time Validation

This document answers the questions regarding navigation configuration and build-time validation in a `leadtype` project.

---

### 1. Curated `nav` vs. Legacy `group` Frontmatter

#### **The Relationship**
* **Curated `nav` (in `docs.config.ts` / `leadtype.config.ts`):** This is the modern, centralized, and config-owned API preferred for organizing documentation. Instead of scattering layout/order logic in individual files, the entire structure is defined as a unified tree in your configuration.
* **Legacy `group` (page-level frontmatter field):** This is a file-level metadata field where an MDX page declares one or more taxonomy slugs it belongs to (e.g., `group: getting-started` or `group: [auth, security]`).

#### **What Drives the Sidebar and Agent Map?**
* **Curated `nav`** drives the modern human-facing sidebar, the top-level nav tabs, and the entire agent map. This includes the generated `llms.txt` sections, `AGENTS.md` sitemaps, sitemap markdown, and Agent Readability discovery metadata (`agent-readability.json`).

#### **What is `group` Still Good For?**
* **Taxonomy and broad categorization:** It defines stable conceptual buckets for the content.
* **Search Facets:** It provides filtering, faceting, and categorization metadata inside the static search index.
* **Fallback Navigation:** For projects that have not yet migrated to config-owned `nav`, the build pipeline falls back to the legacy group resolver, matching page-level `group` fields with defined `groups` in `docs.config.ts` to construct the navigation tree.

---

### 2. Unknown `group` Slugs at Build Time

If an MDX page declares a `group` slug that is not defined or known in the loaded configuration, the following happens during build/generation time:

* **The build fails fast and noisily:** Leadtype's generation pipeline halts with an error. It prints a descriptive error to standard error, such as:
  ```
  error: <urlPath> declares unknown group "<slug>".
  ```
* **Exit Code `1`:** The `leadtype generate` or build script exits with a non-zero exit code (`1`), immediately failing CI/CD runs and local builds.
* **The Design Principle:** This fail-fast design treats mismatched or unrecognized group slugs as a **content bug**. By halting compilation, it prevents broken navigation pathways, drift between content and config, or incomplete indexes from being published to production.
