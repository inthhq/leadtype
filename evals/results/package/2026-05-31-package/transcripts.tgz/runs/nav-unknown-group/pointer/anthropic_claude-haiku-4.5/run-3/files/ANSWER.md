# Navigation in Leadtype: `nav` vs Legacy `group`

## 1. The relationship between `nav` and `group` — which drives what?

### The Current Model: `nav` is Primary, `group` is Legacy

**`nav` (in `docs.config.ts` or `leadtype.config.ts`) drives:**
- The **sidebar structure** in your rendered docs site
- The **agent map** (navigation structure in generated `llms.txt`, `AGENTS.md`, and agent metadata)
- Top-level docs areas (like Docs, Frontend, Integrations, Changelog tabs)
- Nested sections and their headings
- The structure of sitemap markdown and Agent Readability navigation

**`group` (in page frontmatter) is now used for:**
- **Legacy navigation fallback** — when a project has not adopted `nav`, each page's `group` slug is still resolved to build navigation
- **Taxonomy metadata** — marking pages with broad categories for compatibility or search facets
- **Fallback sorting** — pages pulled in by `include` can use `order` frontback if not explicitly listed

### Why the Split?

Leadtype evolved to separate **intentional curation** (config-owned `nav`) from **broad taxonomy** (frontmatter `group`). This keeps human and agent surfaces aligned:

- When you use `nav`, one source of truth drives sidebar, llms.txt, AGENTS.md, and agent metadata. No drift.
- `group` remains available for backward compatibility and for projects that have not yet migrated.
- A page can still declare `group: [a, b]` (one or more slugs) for multi-category tagging, but this no longer controls navigation placement.

### The Legacy Fallback Path

If a project has **no `nav`** in its config, Leadtype falls back to discovering group slugs from frontmatter `group:` fields. That fallback is sufficient for small docs sets, but **config `nav` is strongly preferred** when you need:
- Stable top-level docs areas
- Explicit sidebar order
- Descriptions and nested sections
- Wildcard includes (e.g., `{ include: "reference/*" }`)

---

## 2. What happens at build time if a page declares an unknown `group` slug?

### The Build Fails with an Error

If a page declares a `group` slug that **isn't declared in `docs.config.ts`** (or the relevant collection's `groups` definition), the build will **fail** with:

```
unknown group "<slug>"
```

This is **intentional design**: Leadtype enforces one source of truth to prevent drift.

### Where This Check Happens

1. **During `leadtype lint`** — frontmatter validation catches unknown groups before generation runs
   - Rule: `schema` (or implicit during group resolution)
   - Severity: error
   - A page with an unknown `group` slug will report a violation

2. **During `leadtype generate`** — the group resolver validates all group slugs against the config
   - If the resolver finds a page with a group slug not in the config, generation fails loudly
   - This prevents silent data loss or incorrect navigation structure

### Why This Matters

- **No silent failures** — an unknown group doesn't get ignored; it causes a build error you must fix
- **Config is the source of truth** — every group slug that appears in frontmatter must be explicitly declared in config
- **Prevents orphaned pages** — a typo in frontmatter can't accidentally hide a page from navigation

### Practical Guidance

When migrating from a `group`-only model to config `nav`:
1. Keep the `groups` array in your config if you still use `group` frontmatter
2. Declare every group slug you use: `{ slug: "tutorials", title: "Tutorials" }`
3. Run `leadtype lint` in CI to catch unknown groups before they reach `generate`
4. For nested groups, only **leaf groups** (with no children) can directly contain pages

---

## Summary Table

| Aspect | `nav` (config) | `group` (frontmatter) |
|--------|---|---|
| **Drives sidebar?** | Yes — primary | No — fallback only if no `nav` |
| **Drives agent map?** | Yes — primary | No — fallback only if no `nav` |
| **Drives llms.txt structure?** | Yes | No (unless fallback is active) |
| **Taxonomy/multi-category?** | No | Yes — still useful for broad tagging |
| **Backward compatible?** | New API (but preferred) | Legacy but still supported |
| **Unknown slug behavior?** | N/A | Build fails with `unknown group` error |

When you have `nav`, `group` becomes optional metadata. When you don't have `nav`, Leadtype falls back to inferring structure from `group` values in the source files — but **unknown groups always cause build failures**, same in both modes.
