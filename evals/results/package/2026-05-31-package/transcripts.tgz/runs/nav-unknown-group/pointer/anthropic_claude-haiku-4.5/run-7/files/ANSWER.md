# Navigation in Leadtype: Config Nav vs Legacy Groups

## 1. The Relationship Between Config `nav` and Legacy Frontmatter `group`

### Which Drives the Sidebar and Agent Map?

**Config-owned `nav` in `docs.config.ts` is the primary driver.** It controls:
- **Sidebar structure** — top-level docs areas and nested sections
- **Agent-readable navigation** — the section hierarchy in `llms.txt` and `AGENTS.md`
- **Agent Readability manifest** — the structured discovery data in `agent-readability.json`
- **Both humans and agents see the same structure** via the resolved navigation tree

### What Is the Frontmatter `group` Still Good For?

The legacy `group` field is now **taxonomy and compatibility metadata**. It remains useful for:

1. **Fallback navigation** — In projects that haven't adopted `nav` yet, frontmatter `group` values are resolved into a navigation tree. Each `group` is declared once in `docs.config.ts`, and the intersection of page groups and config groups produces the fallback nav structure, section headings, search metadata, and `AGENTS.md` grouping.

2. **Search facets** — Pages can still be tagged with a `group` slug for filtering search results by category or taxonomy.

3. **Broad taxonomy** — When a page belongs to multiple conceptual categories (e.g., a page that's both "advanced" and "API reference"), `group` can hold `[a, b]` to mark that relationship, separate from curated navigation order.

4. **Backwards compatibility** — Existing docs that rely on frontmatter groups continue to work; migration to config `nav` is optional but recommended for new projects or major migrations.

### The Mental Model

```
┌─────────────────────────────────────────────────┐
│  docs.config.ts                                │
│  nav: [                    ← curated structure   │
│    { title: "Docs", ... }                      │
│  ]                                              │
└─────────────────────────────────────────────────┘
                    ↓
        ┌─────────────────────┐
        │ Group Resolver      │
        │ (builds nav tree)   │
        └─────────────────────┘
                    ↓
    ┌───────────────────────────────────┐
    │ Outputs (same tree structure):    │
    │ • Sidebar (human-facing)          │
    │ • llms.txt sections               │
    │ • AGENTS.md sections              │
    │ • Agent Readability manifest      │
    └───────────────────────────────────┘

Page frontmatter group: [a, b]
  ↓
  Still useful for search facets and legacy fallback,
  but does NOT drive primary navigation.
```

---

## 2. What Happens at Build Time if a Page Declares an Unknown Group?

### The Build Fails with an Error

If a page declares a `group` slug that isn't defined in `docs.config.ts`, **the build fails immediately** with an error like:

```
error: docs/my-page.mdx declares unknown group "undefined-slug".
```

### Why This Design?

This is **intentional and by design**. The leadtype documentation explicitly states:

> "If step 3 finds an unknown group, the run fails. That is by design — **broken navigation is a content bug, not a render-time problem.**"

And in the frontmatter guide:

> "If a page declares a group slug that isn't in `docs.config.ts`, the build fails with `unknown group "<slug>"`. **Same source of truth, no drift.**"

### The Safety Guarantee

This strict validation ensures:
1. **No silent failures** — typos or stale group references are caught immediately
2. **One source of truth** — config and pages must align; they can't drift
3. **Fail fast in CI** — `leadtype generate` catches the issue before any artifacts are written
4. **Clear error messages** — developers see exactly which page and which group caused the problem

### Related CLI Behavior

The CLI exit codes reflect this severity:
- Exit code `0` = success
- Exit code `1` = runtime error **including unknown group** (same severity as config load error or conversion error)
- Exit code `2` = CLI usage error

This makes unknown-group failures visible to CI/CD pipelines and prevents invalid docs from shipping.
