# Leadtype navigation notes

1. The curated `nav` in `docs.config.ts` is the source of truth for intentional navigation. When present, it drives the resolved navigation tree used for the human sidebar/top-level docs areas and the agent-facing map: `llms.txt`, `AGENTS.md`, sitemap markdown, and Agent Readability navigation. A page's frontmatter `group` is legacy taxonomy metadata; it is still useful for projects that have not migrated to `nav` as fallback navigation, and as broad taxonomy/search facet metadata. It does not decide curated sidebar placement when `nav` is configured.

2. If a page declares a legacy `group` slug that the loaded config's legacy `groups` tree does not declare, Leadtype treats that as a content/config drift error. Build/generation fails fast with an error like:

   ```text
   /docs/some-page declares unknown group "some-slug"
   ```

   It does not silently create a new sidebar section, infer the missing configured group, or move the page into the curated `nav`. If there is no config at all, the CLI can infer legacy groups as a fallback, but once the config is the source of truth, unknown declared groups are a build-time failure.
