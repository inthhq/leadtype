# Navigation in leadtype: `nav` vs. `group`

## 1. Curated `nav` vs. legacy `group` frontmatter

**The curated `nav` array in `docs.config.ts` is the source of truth for navigation.** It drives both the human-facing surfaces and the agent-facing map:

- top-level docs areas / tabs (e.g. Docs, Frontend, Integrations, Changelog),
- the sidebar structure and ordering,
- generated `llms.txt`,
- the bundled `AGENTS.md`,
- sitemap markdown,
- Agent Readability navigation metadata.

Because all of these are derived from the same resolved `nav` tree, the human sidebar and the agent document map stay in sync — same source of truth, no drift.

In `nav`, `base` cascades a path prefix to child nodes, page strings are extensionless paths relative to the nearest `base` (a leading `/` starts from the docs root), and `{ include: "folder/*", sort: ["order", "path"] }` entries append matching pages with `order`-then-path sorting.

**The legacy `group` frontmatter field is no longer how you express polished navigation.** It is now best treated as *taxonomy and compatibility metadata*, and it remains useful for:

- **Legacy / fallback navigation** — if a project hasn't adopted `nav`, the CLI falls back to the legacy group resolver, inferring the nav tree, `llms.txt` section headings, and `AGENTS.md` grouping from the `group:` values it finds. Each group is declared once in `docs.config.ts`. This fallback is fine for small docs sets, but you should move to config `nav` when you need stable top-level areas, sidebar order, descriptions, nested sections, or wildcard includes.
- **Broad taxonomy and search facets** — a page can declare one or more group slugs (`group: <slug>` or `group: [a, b]`), letting a page belong to multiple taxonomy groups for classification and search.

(Likewise, `order` survives only as a fallback sort key for pages pulled in by wildcard `include` entries.)

## 2. What happens if a page declares an unknown `group` slug at build time?

**The build fails.** If a page declares a `group` slug that isn't defined in `docs.config.ts`, leadtype errors out with:

```
unknown group "<slug>"
```

This is intentional: because the config is the single source of truth for the set of valid groups, an undeclared slug is treated as drift and is rejected rather than silently ignored. (`leadtype lint` similarly enforces frontmatter/nav consistency in CI so these problems surface before a build.)
