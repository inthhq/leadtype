# Leadtype navigation and legacy groups

1. **`docs.config.ts` `nav` is the curated source of truth.** When `nav` is present, it drives the reader-facing navigation: top-level docs areas, sidebar sections/order, `llms.txt`, `AGENTS.md`, sitemap markdown, and Agent Readability/agent-map navigation. A page's frontmatter `group` field is legacy metadata; keep it for compatibility, broad taxonomy, search/filter facets, and as the fallback navigation mechanism for projects that have not adopted `nav`.

   Important distinction: `nav` page placement is explicit/path-based (`pages`, `base`, `include`), not driven by matching a page's `group` value to a nav node. If you still want old `group` values validated, keep a `groups` list in config as the legacy taxonomy vocabulary.

2. **An unknown legacy group is a build-time error when legacy groups are configured/validated.** During generation Leadtype resolves navigation and reports any page whose `group` slug is not in the configured `groups` tree; the CLI fails fast with an error like:

   ```text
   /docs/some-page declares unknown group "bad-slug"
   ```

   In the lower-level API, `resolveDocsNavigation()` exposes these as `navigation.unknown` so custom build scripts can fail before publishing. A `nav`-only config with no `groups` list does not use `group` for placement; in that shape, there is no legacy group vocabulary to validate against, so keep `groups` if you want unknown `group` slugs caught.
