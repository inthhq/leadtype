# Navigation and Taxonomy in Leadtype

Below are the answers regarding navigation configurations (`nav` in `docs.config.ts`) and legacy page-level `group` frontmatter fields.

---

### 1. Relationship Between `nav` in `docs.config.ts` and legacy `group` Frontmatter

#### Which drives the sidebar and agent map?
* **`nav` (in `docs.config.ts`)** is the primary, curated source of truth that drives the sidebar, top-level tabs, `llms.txt`, `AGENTS.md`, sitemap markdown, and **Agent Readability** navigation. Putting navigation configuration here ensures that human-facing sidebars and agent-facing maps stay perfectly aligned.

#### What is the relationship and what is each still good for?
* **`nav`** allows you to structure the documentation tree hierarchically, define custom sections, nested groups, order pages explicitly, and support wildcard includes.
* **`group`** is a legacy, page-level frontmatter field (and its corresponding configuration `groups` key in config) used for assigning pages to broad categories or taxonomy sections.
* While `nav` is the preferred way to curate stable sidebars and agent maps, the `group` frontmatter field remains useful for:
  1. **Fallback navigation** (for smaller or legacy documentation setups that have not yet migrated to the structured `nav` config, where the CLI falls back to inferring/resolving groups and sorting pages alphabetically/by order).
  2. **Search facets and filtering taxonomy** (offering structured categorizations of pages within search metadata).
  3. **Compatibility metadata** across documentation tools and platforms.

---

### 2. What Happens at Build Time if a Page Declares an Unknown `group` Slug?

* **The build fails noisily and fast.**
* During the validation phase of `leadtype generate` (specifically during Step 3 of the pipeline, **Resolve groups**), the build process validates every page's `group` frontmatter field against the configured group slugs.
* If a page declares a group slug that `docs.config.ts` does not know about, the CLI halts and throws a runtime error (e.g., `error: <urlPath> declares unknown group "<slug>".`) and exits with code `1` (indicating a runtime error).
* **The Philosophy:** This fail-fast mechanism is **by design**. Broken or drifted navigation is treated as a **content bug** that must be resolved before deployment, preventing broken site maps or fragmented agent references from shipping.
