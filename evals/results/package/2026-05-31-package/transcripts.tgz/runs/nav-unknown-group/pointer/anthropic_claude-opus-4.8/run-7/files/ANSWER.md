# Navigation in leadtype: `nav` vs. legacy `group`

## 1. Relationship between curated `nav` and a page's legacy `group` frontmatter

**The curated `nav` in `docs.config.ts` is the source of truth and drives the sidebar and the agent map.** The legacy `group` frontmatter field is no longer the recommended way to express navigation — it has been demoted to taxonomy/compatibility metadata.

What `nav` drives:

- Top-level docs areas / navbar tabs (e.g. Docs, Frontend, Integrations, Changelog) from root nodes.
- The human sidebar structure (sections, nesting, order, descriptions) for the active root node.
- The same resolved tree feeds the **agent map and generated surfaces**: `llms.txt`, `AGENTS.md`, sitemap markdown, and Agent Readability navigation.

Because all of these come from one resolved tree, the human sidebar and the agent-facing document map stay aligned — no drift.

What `group` is *still* good for:

- **Legacy navigation fallback.** In projects that have not adopted `nav`, the CLI falls back to a legacy group resolver: it reads the `group:` values across pages, intersects them with the `groups` declared in `docs.config.ts`, and builds the fallback nav tree, `llms.txt` sections, and `AGENTS.md` grouping. This is fine for small docs sets, but `nav` is preferred when you need stable top-level areas, sidebar order, descriptions, nested sections, or wildcard includes.
- **Broad taxonomy / compatibility metadata.** A page can belong to one or more group slugs (`group: <slug>` or `group: [a, b]`), so pages can be shared across multiple taxonomy groups.
- **Search facets / search metadata.**

In short: once you adopt `nav`, it owns curated placement and the agent map; `group` keeps working as a fallback navigation mechanism and as taxonomy/search metadata, but it should not be where you express your intentional, polished navigation.

## 2. What happens at build time for an unknown `group` slug

If a page declares a `group` slug that `docs.config.ts` does not know about (i.e. it isn't declared in the config's `groups`), **the build fails with the error `unknown group "<slug>"`.**

This is intentional: the config and the pages share the same source of truth, so an undeclared group slug is treated as an error rather than being silently dropped, preventing drift between page frontmatter and the configured group taxonomy. (The `leadtype lint` `schema`/field rules can also catch frontmatter problems in CI before a build is attempted.)
