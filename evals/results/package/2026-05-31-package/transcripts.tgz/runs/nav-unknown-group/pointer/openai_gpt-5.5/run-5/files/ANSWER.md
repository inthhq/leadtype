# Leadtype navigation vs. legacy groups

1. **`docs.config.ts` `nav` is the source of truth for curated navigation.** When present, it drives the resolved navigation tree used by the human sidebar/top-level docs areas and the agent-facing maps/artifacts such as `llms.txt`, `AGENTS.md`, sitemap markdown, and Agent Readability navigation. A page's frontmatter `group` is legacy taxonomy metadata: it is still useful for projects that have not adopted `nav` (fallback group-based navigation), for compatibility, validation against a retained `groups` list, and for search/filter facets or broad taxonomy. It does **not** override curated page placement in `nav`.

2. **An unknown legacy group is a build-time error when groups are configured.** If a page declares `group: some-slug` and the loaded config's legacy `groups` do not include `some-slug`, Leadtype reports the page in `navigation.unknown`; the CLI (`leadtype generate`) fails fast with an error like:

   ```txt
   /docs/page declares unknown group "some-slug"
   ```

   The CLI exits non-zero, so bad taxonomy/navigation metadata is caught before publishing instead of being silently inferred or placed somewhere unexpected. If there is no config at all, the CLI can infer legacy groups from frontmatter; but once the config is the authority for groups, unknown slugs are treated as content bugs.