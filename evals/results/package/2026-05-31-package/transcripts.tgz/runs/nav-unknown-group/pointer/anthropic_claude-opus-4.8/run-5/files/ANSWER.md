# Leadtype Navigation: `nav` vs legacy `group`

## 1. Relationship between curated `nav` and a page's legacy `group` frontmatter

**Curated `nav` (in `docs.config.ts`) is the source of truth that drives the sidebar and the agent map.** The `group` frontmatter field is legacy taxonomy/compatibility metadata that no longer drives polished navigation.

### What `nav` drives

When a docs site adopts the config-owned `nav` array, that single resolved tree drives **all** human- and agent-facing surfaces at once:

- Top-level docs areas / top navbar tabs (e.g. Docs, Frontend, Integrations, Changelog) — these come from the root `nav` nodes.
- The human sidebar (structure and order) — usually the active root node's pages and children.
- `llms.txt` (section structure and entries).
- `AGENTS.md` (the agent map / document map).
- Sitemap markdown.
- Agent Readability navigation metadata.

`nav` lets you express intentional ordering, nested sections, `base` path cascading, explicit pinned pages, and wildcard `{ include }` entries — things `group` alone can't express.

### What `group` is still good for

`group` remains valid and useful, just not as the place to express curated navigation. It is kept around for:

- **Legacy navigation fallback.** If a project has **no** `nav` in its config, the CLI falls back to the legacy *group resolver*, which infers the navigation tree from the `group:` values it finds (intersected with the `groups` declared in `docs.config.ts`). This produces the fallback nav tree, `llms.txt` section headings, and `AGENTS.md` grouping. It's adequate for small docs sets, but `nav` is recommended when you need stable top-level areas, sidebar order, descriptions, nested sections, or wildcard includes.
- **Search facets / broad taxonomy.** Pages can carry one or more group slugs (`group: <slug>` or `group: [a, b]`), letting a page belong to multiple taxonomy groups for search and classification — independent of where it sits in `nav`.

In short: **`nav` drives the sidebar and the agent map; `group` is taxonomy/compatibility metadata used for the legacy fallback nav and search facets.** (The related `order` field is likewise kept only as a fallback sort for pages pulled in by wildcard `include` entries.)

## 2. Build-time behavior for an unknown `group` slug

**If a page declares a `group` slug that `docs.config.ts` doesn't know about, the build fails with the error `unknown group "<slug>"`.**

Group slugs must be declared once in the config (`groups`, possibly nested via `children`), and the build validates each page's `group` values against that declared set. This keeps the page frontmatter and the config in sync — the same source of truth, with no drift. (Only **leaf** groups — those with no children — may directly contain pages; non-leaf groups are headings only.)

You can also catch this earlier than build time: `leadtype lint` enforces the frontmatter schema in CI, so group/schema problems surface before they ever reach a build.
