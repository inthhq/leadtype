# Navigation in leadtype: `nav` vs. legacy `group`

## 1. Relationship between curated `nav` and the legacy `group` frontmatter field

**The curated `nav` in `docs.config.ts` is the source of truth that drives the
sidebar and the agent map.** When you define `nav`, that single resolved tree
drives every navigation surface at once:

- top-level docs areas / tabs (e.g. Docs, Frontend, Integrations, Changelog),
- the sidebar (the active root node's pages and children),
- generated navigation,
- `llms.txt` sections,
- `AGENTS.md` grouping,
- sitemap markdown, and
- the Agent Readability navigation metadata.

In `nav`, `base` cascades to child nodes, page strings are extensionless paths
relative to the nearest `base` (a leading `/` starts from the docs root), and
`include` entries pull in matching pages (sorted by `order` then path by
default). This keeps the human sidebar and the agent-facing map aligned from one
config.

**The page's `group` frontmatter field is optional, legacy taxonomy metadata.**
It is *not* the curated placement mechanism once you adopt `nav`. What it's still
good for:

- **Legacy navigation fallback** — in projects that have *not* adopted `nav`,
  the CLI falls back to the legacy group resolver. Each group is declared once
  in `docs.config.ts`, pages declare `group: <slug>` (or `group: [a, b]` to
  share a page across multiple groups), and the intersection produces the
  fallback nav tree, `llms.txt` section headings, search metadata, and
  `AGENTS.md` grouping. Only **leaf** groups directly contain pages; non-leaf
  groups are headings only.
- **Search facets** and **broad taxonomy** — `group` remains available as a
  classification dimension even alongside `nav`.

In short: when `nav` exists, it owns curated placement (sidebar + agent map) and
`group` becomes supplementary taxonomy/search-facet metadata and the
fallback-only navigation source. The fallback is fine for small docs sets, but
`nav` is what you want for stable top-level areas, sidebar order, descriptions,
nested sections, and wildcard includes.

(Related: `order` likewise remains available as fallback sorting for pages
pulled in by an `include`.)

## 2. What happens at build time for an unknown `group` slug

**The build fails.** If a page declares a `group` slug that isn't declared in
`docs.config.ts`, the build errors out with:

```
unknown group "<slug>"
```

Because the config and the page frontmatter share the same source of truth, this
hard failure is deliberate — it prevents drift between declared groups and the
groups pages actually reference.
