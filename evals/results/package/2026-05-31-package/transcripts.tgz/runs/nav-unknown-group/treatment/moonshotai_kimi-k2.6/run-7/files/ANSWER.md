# Navigation: `nav` vs. legacy `group`

## 1. Relationship between curated `nav` and frontmatter `group`

**`nav` in `docs.config.ts` drives the sidebar and agent map.**

The curated `nav` tree is the source of truth for:
- Sidebar structure in the docs site
- `llms.txt` sections
- `AGENTS.md` grouping
- Sitemap markdown and Agent Readability navigation
- Search metadata organization

**`group` frontmatter is legacy taxonomy metadata.** It is no longer the best place to express polished navigation, but it is still valid and useful for:
- Fallback navigation when a project has not adopted `nav`
- Search facets and broad taxonomy
- Compatibility metadata during migrations

In short: put intentional navigation in `nav`; keep `group` as taxonomy/compatibility metadata only.

## 2. Build-time behavior for an unknown `group` slug

If a page declares a `group` slug that the config does not know about, **`leadtype generate` fails fast with exit code 1**.

The CLI emits an error like:

```
error: /docs/<page> declares unknown group "<slug>".
```

This happens during the **Resolve groups** step (step 3 of the pipeline), before any artifacts are generated. The design treats broken navigation as a content bug, not a render-time problem.

### Important nuance when using `nav`

If your config uses `nav` but **omits** the legacy `groups` array, any `group` frontmatter is considered unknown and will fail validation. The migration docs explicitly recommend:

> Keep `groups` defined when existing `group` frontmatter should continue to validate.

So if you are migrating to `nav` but still have pages with `group:` in their frontmatter, leave the `groups` array in `docs.config.ts` so those slugs remain valid. If you remove `groups`, you must also remove (or stop using) the `group` frontmatter field.
