# Leadtype navigation: `nav` vs. `group`

1. **Curated `nav` is the source of truth for navigation.** When `docs.config.ts` defines `nav`, Leadtype resolves that tree to drive the human sidebar/top-level docs areas and the agent-facing maps: `llms.txt`, `AGENTS.md`, sitemap markdown, and Agent Readability navigation. A page’s legacy `group` frontmatter does **not** place the page in the curated sidebar in that mode; placement comes from explicit `nav.pages` entries or `nav` include globs.

   The `group` field is still useful as legacy/taxonomy metadata: it supports fallback navigation for projects that have not adopted `nav`, can be kept for compatibility, and remains useful for broad taxonomy and search/filter facets.

2. **Unknown legacy group slugs fail the build when validated against config groups.** If a page declares `group: some-slug` but the loaded config’s legacy `groups` list does not define `some-slug`, Leadtype reports it as an unknown group and `leadtype generate` fails, e.g.:

   ```text
   /docs/some-page declares unknown group "some-slug"
   ```

   In lower-level APIs, `resolveDocsNavigation()` exposes these as `navigation.unknown`; the CLI treats the first unknown entry as a build error so broken navigation/taxonomy drift is caught at build time rather than shipped.
