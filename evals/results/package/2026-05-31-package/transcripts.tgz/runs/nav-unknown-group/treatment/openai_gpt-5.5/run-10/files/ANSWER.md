# Leadtype navigation vs. legacy `group`

1. **`docs.config.ts` `nav` is the source of truth for curated navigation.** When a project defines `nav`, that resolved tree drives the human sidebar/top-level docs areas and the agent-facing maps: generated navigation, `llms.txt`, `AGENTS.md`, sitemap markdown, and Agent Readability navigation. A page's frontmatter `group` is legacy metadata; it is still useful for projects that have not adopted `nav` as fallback navigation, and it can still serve as broad taxonomy/search-filter metadata or compatibility data.

2. **An unknown configured legacy group is a build-time error.** If a page says `group: some-slug` and the loaded config's legacy `groups` do not contain that slug, Leadtype fails generation instead of silently inventing or misplacing the group. The error is reported like:

   ```txt
   <urlPath> declares unknown group "some-slug"
   ```

   In other words, use `nav` for placement, but keep any legacy `groups` list in sync if you rely on `group` validation/taxonomy.