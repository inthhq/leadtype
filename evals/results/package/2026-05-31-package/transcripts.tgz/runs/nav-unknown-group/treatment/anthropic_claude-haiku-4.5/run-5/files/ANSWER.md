# Leadtype Navigation: `nav` Config vs. Legacy `group` Frontmatter

## 1. Which one drives sidebar and agent map — config `nav` or page `group` frontmatter?

**The config-owned `nav` in `docs.config.ts` is the primary driver.** It controls the sidebar, the agent map, and all curated navigation surfaces.

### How they work together:

- **`nav` (config)** — The _canonical_ source of truth for navigation structure. It defines:
  - Top-level docs areas (tabs or root nodes)
  - Sidebar hierarchy and ordering
  - Section headings in generated outputs (`llms.txt`, `AGENTS.md`, sitemap)
  - Agent Readability metadata
  - Page inclusion via explicit paths or wildcard `include` entries
  
  ```ts
  nav: [
    { title: "Start", pages: ["", "quickstart"] },
    { title: "Guides", base: "guides", pages: [{ include: "*" }] },
  ]
  ```

- **`group` (frontmatter)** — A _legacy taxonomy field_ that is still valid but subordinate to `nav`. It serves as:
  - Backward compatibility for older docs that haven't migrated to config nav
  - Taxonomy/faceting metadata for search
  - A fallback validation point (if declared, must match a group defined in config)
  - Multi-group membership when a page should appear in multiple logical categories

### The relationship:

When **`nav` is defined** in the config, it takes precedence. The page's `group` frontmatter is treated as optional metadata, not as the navigation driver.

When **`nav` is not defined** (legacy projects), leadtype falls back to inferring navigation from the `group` values found in page frontmatter. This fallback works but lacks the stability, nesting, and section descriptions that `nav` provides.

From the docs:

> "If you do not have `nav`, the CLI falls back to the legacy group resolver and infers groups from the `group:` values it finds. That fallback is enough for small docs sets, but use config `nav` when you need stable top-level docs areas, sidebar order, descriptions, nested sections, or wildcard includes."

## 2. What happens at build time if a page declares a `group` slug that the config doesn't know about?

**The build fails with an error: `unknown group "<slug>"`.**

This is enforced by the `schema` lint rule in `leadtype lint`. From the lint documentation:

- **Rule**: `schema` (error severity)
- **Catches**: Required field missing or wrong type

If a page declares `group: unknown-slug` and that slug isn't in the `docs.config.ts` groups list, the generation fails loudly.

### Why this design:

This is a **safety mechanism to prevent drift** between content and configuration. The docs architecture treats the config as the source of truth:

```mermaid
flowchart LR
cfg["docs.config.ts<br/>groups: [authoring, docs-site, reference]"]
page1["page A<br/>group: authoring"]
page2["page B<br/>group: docs-site"]
page3["page C<br/>unknown-slug"]
resolver["group resolver"]
cfg --> resolver
page1 --> resolver
page2 --> resolver
page3 --> resolver
```

If `unknown-slug` isn't declared in the config, the resolver can't map it to any section in the navigation tree, so it errors out rather than silently omitting the page or creating a dangling section.

### How to fix:

Either:
1. Add the slug to the config's `groups` array, or
2. Change the page's `group` value to one that is declared in the config

This ensures the sidebar, agent map, `llms.txt`, and `AGENTS.md` all have consistent structure with no orphaned pages.
