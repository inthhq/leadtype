# Navigation in Leadtype

Here are the answers to your questions about navigation, `docs.config.ts`, and the legacy `group` frontmatter field.

---

### 1. Curated `nav` vs. Legacy `group` frontmatter

#### **Which one drives the sidebar and agent map?**
* **Curated `nav` (in `docs.config.ts`)** is the preferred and modern way to drive the sidebar and agent map. It defines a highly structured, curated navigation tree. This same tree is used to build the website's sidebar navigation, the `llms.txt` and `llms-full.txt` sections, `AGENTS.md` (for bundle mode), sitemap markdown, and Agent Readability metadata.
* **Legacy `group` frontmatter field** (and the legacy `groups` config array) acts as a **fallback**. In projects that have not yet adopted/configured a curated `nav` object, Leadtype relies on a group resolver that matches each page's `group: <slug>` frontmatter field to the configured groups to build a fallback navigation tree.

#### **What is the other (legacy `group`) still good for?**
Even when you use a curated `nav` in `docs.config.ts`, the page's legacy `group` frontmatter field is still useful for:
1. **Search facets & metadata:** Group associations are indexed and can be used for filtering/categorizing search results.
2. **Broad taxonomy:** Group fields help categorize documents by broad subject areas.
3. **Legacy navigation fallback:** It ensures small documentation sets can be generated/navigated without requiring a full, complex `nav` tree configuration.

---

### 2. Declaring an unknown `group` slug at build time

If a page declares a `group: <slug>` frontmatter field with a slug that `docs.config.ts` (or the loaded config) doesn't know about:

1. **The build/generation run fails.** 
2. The CLI throws an error indicating the issue (e.g. `"<path> declares unknown group "<slug>"` or `unknown group "<slug>"`), and exits with exit code `1` (runtime error).
3. **The Design Goal:** This behavior is by design to ensure that drift does not occur and broken navigation/taxonomy is treated as a **content bug** that fails the build before it ever reaches a publication stage.
