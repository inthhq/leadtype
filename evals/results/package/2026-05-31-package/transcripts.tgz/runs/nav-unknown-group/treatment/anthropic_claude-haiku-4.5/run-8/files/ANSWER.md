# Navigation in Leadtype: `nav` vs `group`

## 1. Relationship Between `nav` and `group`, and Which Drives What

### The Modern Design Pattern

**`nav` in `docs.config.ts` drives the sidebar and agent map.** This is the curated, intentional navigation structure. It declares:
- Top-level docs areas (e.g., "Docs", "API Reference", "Changelog")
- Sidebar sections and hierarchies
- Section descriptions and ordering
- Wildcard includes for inventory-like content

**`group` in page frontmatter is now legacy taxonomy metadata** — a fallback field that still works but is no longer the source of truth for navigation. It's useful for:
- Search faceting and filtering
- Multi-group page membership (a single page can belong to multiple groups)
- Projects that haven't migrated to `nav` yet

### What Actually Drives Sidebar and Agent Map

The `nav` configuration is what gets used to produce:
- **Sidebar structure** — organized as top-level tabs and nested sections
- **Agent map** — `llms.txt`, `AGENTS.md`, and agent-readability navigation
- **Sitemap markdown** — the hierarchical structure visible to agents
- **Search metadata** — group context for ranked results

The `leadtype generate` command runs in this order:
1. Parse frontmatter from every `.mdx` file
2. Convert each file through the remark stack to markdown
3. **Resolve groups** from frontmatter and validate them against config
4. In site mode: generate `llms.txt`, `llms-full.txt`, search index, and Agent Readability files using the resolved navigation
5. In bundle mode: generate `AGENTS.md` using the same navigation

The documentation states:
> Config `nav` drives `llms.txt` sections, navigation, sitemap markdown, Agent Readability navigation, and `AGENTS.md` when present. Legacy `group` metadata remains the fallback for projects that have not adopted `nav`, and still works as search/filter taxonomy.

### Fallback Behavior

If you do **not** have a `nav` field in `docs.config.ts`, leadtype falls back to the **legacy group resolver**, which infers groups from the `group:` frontmatter values it finds. That's enough for small docs sets, but the documented recommendation is to use config `nav` for stable top-level areas, sidebar order, descriptions, nested sections, or wildcard includes.

---

## 2. Build-Time Behavior for Unknown Groups

**If a page declares a `group` slug that the config doesn't know about, the build fails with an error: `unknown group "<slug>"`.**

This happens during step 3 of the pipeline (resolve groups). The validation is intentional — it prevents silent navigation drift. Here's the explicit contract from the documentation:

> If a page declares a group slug that isn't in `docs.config.ts`, the build fails with `unknown group "<slug>"`. Same source of truth, no drift.

### Why This Matters

This strict validation ensures:
1. **No silent failures** — typos in frontmatter are caught immediately, not at render time
2. **Lint-friendly** — `leadtype lint` can validate every page's `group:` matches a known slug before `leadtype generate` runs
3. **CI-safe** — broken navigation fails the build in CI before publishing, preventing outdated docs from reaching agents

The proper workflow is:
1. Define all groups in `docs.config.ts` (either as `nav` nodes or legacy `groups` array)
2. Run `leadtype lint` to validate all pages match known groups
3. Run `leadtype generate` to produce artifacts

If you want to use a new group, add it to the config first, then assign it to pages.
