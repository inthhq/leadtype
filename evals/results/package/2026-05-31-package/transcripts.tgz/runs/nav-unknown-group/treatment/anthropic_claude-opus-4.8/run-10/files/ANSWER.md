# Navigation in leadtype: `nav` vs `group`

## 1. Relationship between curated `nav` and legacy `group` frontmatter

**Curated `nav` in `docs.config.ts` is the source of truth that drives the sidebar and the agent map.** `group` frontmatter is legacy taxonomy/compatibility metadata that only acts as a *fallback* navigation mechanism.

### `nav` drives navigation (and the agent map)

When you define `nav` in `docs.config.ts`, that single resolved tree drives every navigation surface — human and agent — so they can't drift apart:

- Top-level docs areas / top tabs (e.g. Docs, Frontend, Integrations, Changelog) — root nav nodes.
- The human **sidebar** (the active root node's pages and children).
- `llms.txt` (including its nested section headings).
- `AGENTS.md` grouping.
- Sitemap markdown.
- Agent Readability navigation metadata (`agent-readability.json`).

`nav` is where you express intentional structure: stable top-level areas, explicit sidebar order, descriptions, nested sections, `base` path cascading, and wildcard `include` entries.

### What `group` is still good for

`group` (which can be a single slug or a list, e.g. `group: authoring` or `group: [a, b]`) is **legacy taxonomy and compatibility metadata**. It remains useful for:

- **Legacy navigation fallback** — if a project has *not* adopted `nav`, the CLI falls back to the legacy group resolver, inferring the nav tree (and `llms.txt` sections / `AGENTS.md` grouping) from the `group:` values it finds plus the `groups` declared in config. That fallback is fine for small docs sets.
- **Search facets / broad taxonomy** — letting a page belong to multiple taxonomy buckets, and feeding search metadata.

In short: prefer config-owned `nav` for curated placement; keep `group` as taxonomy/compatibility metadata (and keep `order` only as a fallback sort for pages pulled in by wildcard `include`).

## 2. What happens at build time if a page declares an unknown `group` slug

**The build fails.** If a page declares a `group` slug that `docs.config.ts` doesn't know about, generation errors out with:

```
unknown group "<slug>"
```

This is intentional: config and frontmatter share the same source of truth, so an undeclared group is treated as drift and blocks the build rather than silently producing a stray or empty navigation section. (Note that only **leaf** groups — those without children — can directly contain pages; non-leaf groups are headings only.)

You can also catch related issues earlier in CI with `leadtype lint`, which enforces the frontmatter schema (e.g. the `schema` rule for missing/wrong-typed fields), before a build is ever attempted.
