# Leadtype navigation and legacy `group`

1. **`docs.config.ts` `nav` is the source of truth for curated navigation.** When a project defines `nav`, Leadtype resolves that tree and uses it for the human sidebar/top-level docs areas and the agent-facing map: generated navigation, `llms.txt`, `AGENTS.md`, sitemap markdown, and Agent Readability metadata.

   The page frontmatter `group` field is still valid, but it is legacy taxonomy/compatibility metadata. It is useful for projects that have not adopted `nav` yet, for fallback group-based navigation, and for broad taxonomy/search or filter facets. It should not be treated as the place to express polished sidebar structure once `nav` exists.

2. **An unknown legacy group is a build-time error when groups are configured for validation.** If a page says `group: some-slug` and the loaded config's legacy `groups` tree does not contain `some-slug`, Leadtype reports it as an unknown group, e.g. `unknown group "some-slug"` / `<page> declares unknown group "some-slug"`, and generation fails instead of shipping broken navigation.

   In short: keep `groups` in config if existing `group` frontmatter should remain validated; put intentional sidebar and agent-map structure in `nav`.
