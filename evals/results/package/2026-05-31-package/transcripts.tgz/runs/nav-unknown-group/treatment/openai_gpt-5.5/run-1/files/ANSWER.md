# Leadtype navigation and legacy groups

1. In current Leadtype projects, the curated `nav` in `docs.config.ts` is the source of truth for intentional navigation. It drives the resolved docs navigation used by the human sidebar/top-level docs areas and by agent-facing maps such as `llms.txt`, `AGENTS.md`, sitemap markdown, and Agent Readability navigation.

   A page's frontmatter `group` is still valid, but it is legacy/taxonomy metadata rather than the preferred way to place pages in a curated sidebar. Keep it for older projects that have not adopted `nav`, compatibility with the legacy group resolver, broad taxonomy, search/filter facets, and validation of existing group metadata.

2. If a page declares a `group` slug that is not known to the loaded config's legacy `groups`, Leadtype treats that as a content/config error. During generation it resolves navigation first, reports the offending page and slug, and fails the build with an error like:

   ```text
   /docs/some-page declares unknown group "bad-slug"
   ```

   In other words, it does not silently create a new group or let the page drift into the wrong navigation; the run exits non-zero so the mismatch is fixed before publishing.
