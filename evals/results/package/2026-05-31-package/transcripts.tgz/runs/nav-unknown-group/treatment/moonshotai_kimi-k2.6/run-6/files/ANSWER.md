# Navigation in Leadtype: `nav` vs. `group`

## 1. Relationship between curated `nav` and legacy `group`

**The config-owned `nav` array in `docs.config.ts` drives the sidebar and the agent map.**

When you declare `nav`, Leadtype uses it to produce:
- the site sidebar,
- `llms.txt` sections,
- `AGENTS.md` grouping,
- sitemap markdown,
- Agent Readability navigation metadata.

**The page-level `group` frontmatter field is legacy taxonomy metadata.** It is still valid, but it is no longer the source of truth for curated navigation. It remains useful for:
- **fallback navigation** in projects that have not yet adopted `nav`,
- **search facets** and broad taxonomy tags,
- **compatibility metadata** (e.g. sharing a page across multiple taxonomy groups).

In other words: put intentional product navigation in `docs.config.ts` `nav`; keep `group` on pages only when you need taxonomy or are maintaining a legacy setup.

> Source: `node_modules/leadtype/docs/authoring/frontmatter.md` ("How nav becomes site navigation and the agent map", "Legacy groups", and the summary bullets at the end).

## 2. Build-time behavior for an unknown `group` slug

**The build fails fast.**

If a page declares a `group` slug that the loaded config does not know about, Leadtype treats it as a content bug and stops generation. You will see an error message such as:

```
error: <path> declares unknown group "<slug>".
```

The process exits with code `1` (runtime error). This applies to the legacy group resolver path; Leadtype does not silently ignore mismatched group references.

> Sources:
> - `node_modules/leadtype/docs/authoring/frontmatter.md`: "If a page declares a group slug that isn't in `docs.config.ts`, the build fails with `unknown group \"<slug>\"`."
> - `node_modules/leadtype/docs/how-it-works.md`: "If step 3 finds an unknown group, the run fails. That is by design — broken navigation is a content bug, not a render-time problem."
> - `node_modules/leadtype/docs/reference/cli.md`: Exit code `1` includes "unknown group".
> - `node_modules/leadtype/docs/reference/llm.md` / `package-docs/bundle.md`: shows the exact stderr output format.
