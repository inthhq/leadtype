# Navigation in Leadtype

## 1. Curated `nav` in `docs.config.ts` vs. Legacy `group` Frontmatter Field

### **Which one drives the sidebar and agent map?**
* **The curated `nav` in `docs.config.ts`** is the primary driver of the sidebar, top-level tabs, and the agent map (including `llms.txt`, `AGENTS.md`, sitemaps, sitemap markdown, robots.txt, and Agent Readability metadata). It is the preferred way to design an intentional, polished, and structured information architecture (IA).

### **What is the other still good for?**
The legacy page-level **`group`** frontmatter field remains available and is useful for:
* **Legacy navigation fallback:** In projects that have not fully adopted `nav` (or omit it), the CLI falls back to the legacy group resolver to build the navigation tree from frontmatter groups and the top-level `groups` array in `docs.config.ts`.
* **Search facets:** Categorizing and filtering search results by taxonomical groups.
* **Broad taxonomy and compatibility metadata:** Labeling pages to share them across multiple taxonomies or legacy groupings.

---

## 2. Build-Time Behavior for Unknown `group` Slugs

If a page declares a `group` slug in its frontmatter that the configuration does not know about (i.e., it is not declared in `docs.config.ts` or in the collection's groups):
* **The build fails fast and noisily:** The `leadtype generate` or bundle process will fail during the group resolution step (specifically step 3 of the generation pipeline) and output an error such as:
  ```
  [path] declares unknown group "<slug>"
  ```
* **Why this happens:** This fail-fast behavior is by design. Leadtype treats broken or drifted navigation as a content bug that must be resolved at build time before deployment, ensuring that a bad configuration or broken links cannot be shipped.
