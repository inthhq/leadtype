# Nav vs. Legacy `group` Frontmatter

## 1. Which drives the sidebar and agent map?

**`nav` in `docs.config.ts` is the source of truth.** It drives:
- the human sidebar (`source.getNavigation()`)
- `llms.txt` / `AGENTS.md` sections
- sitemap markdown
- Agent Readability navigation metadata

**The page-level `group` frontmatter field is legacy taxonomy metadata.** It is no longer the best place to express polished navigation, but it is still useful for:
- fallback navigation when a project has not adopted `nav` yet
- search facets / filtering
- broad taxonomy tags

If both are present, `nav` wins. If you do not have `nav`, the CLI falls back to the legacy group resolver and infers groups from the `group:` values it finds.

## 2. What happens if a page declares an unknown `group` slug?

**The build fails fast.** `leadtype generate` resolves groups from frontmatter and validates that every page's `group:` matches a known slug in the loaded config. If a page names a group the config does not know about, you get a runtime error such as:

```
error: /docs/some-page declares unknown group "missing-slug".
```

The CLI exits with code `1` (runtime error). This is by design — broken navigation is treated as a **content bug**, not something to silently paper over at render time. The `resolveDocsNavigation` API also surfaces these mismatches in `navigation.unknown`, which custom build scripts are expected to check and fail on.
