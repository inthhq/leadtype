# Leadtype navigation: `nav` vs legacy `group`

## 1. Relationship between curated `nav` and the legacy `group` frontmatter field

**Curated `nav` in `docs.config.ts` is the source of truth that drives the sidebar and the agent map.** The legacy per-page `group` frontmatter field is taxonomy/compatibility metadata that is no longer the recommended way to express navigation.

When you define `nav` in `docs.config.ts`:

- Root nodes become top-level docs areas / tabs (e.g. Docs, Frontend, Integrations, Changelog).
- The active root node's pages and children become the human **sidebar**.
- That *same resolved tree* drives generated navigation, `llms.txt`, `AGENTS.md`, the sitemap markdown, and the Agent Readability navigation metadata (the "agent map").

So one curated structure keeps the human sidebar and every agent-facing surface aligned, with stable top-level areas, sidebar order, descriptions, nested sections, and wildcard includes (`base`, explicit page strings, and `{ include: "folder/*", sort: ["order", "path"] }`).

**What `group` is still good for:**

- **Legacy navigation fallback.** If a project has *not* adopted `nav`, the CLI falls back to the legacy group resolver: it infers groups from the `group:` values it finds (declared once in `docs.config.ts`), and their intersection produces the fallback nav tree, `llms.txt` section headings, search metadata, and `AGENTS.md` grouping. This is fine for small docs sets.
- **Broad taxonomy / shared categorization.** A page can declare one or more slugs (`group: <slug>` or `group: [a, b]`) so it can belong to multiple taxonomy groups.
- **Search facets.**
- **Compatibility metadata**, so existing pages keep validating during/after a migration to `nav`.

In short: prefer `nav` for intentional, curated navigation (it owns the sidebar and agent map); keep `group` only as taxonomy/compatibility metadata, search faceting, and the fallback path when no `nav` exists. (Likewise, `order` is retained only as a fallback sort for pages pulled in by wildcard `include`.)

## 2. What happens at build time when a page declares an unknown `group` slug

**The build fails.** If a page declares a `group` slug that is not declared in `docs.config.ts`, the build errors out with:

```
unknown group "<slug>"
```

This is intentional: the config and the frontmatter share a single source of truth, so unknown slugs are rejected rather than silently dropped, preventing drift between declared groups and what pages reference.
