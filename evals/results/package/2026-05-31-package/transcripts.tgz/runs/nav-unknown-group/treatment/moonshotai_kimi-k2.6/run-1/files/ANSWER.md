# Nav vs. `group` frontmatter — quick reference

## 1. Which drives the sidebar and agent map, and what is the other still good for?

- **`nav` in `docs.config.ts` is the driver.** It controls the curated sidebar tree, top-level docs areas, `llms.txt` sections, `AGENTS.md` grouping, sitemap markdown, Agent Readability navigation, and search metadata. When `nav` is present, the pipeline uses it as the single source of truth for navigation and agent-facing document maps.

- **The page-level `group` frontmatter field is legacy taxonomy metadata.** It is no longer the best place to express polished navigation, but it is still valid and useful for:
  - **Fallback navigation** — if a project has not adopted `nav`, leadtype falls back to resolving groups from the `group:` values it finds in frontmatter.
  - **Search facets and broad taxonomy** — `group` can still feed search/filter categorization even when `nav` owns the sidebar.
  - **Compatibility** — existing docs that rely on `group` continue to work until they are migrated.

In short: use `nav` for product navigation; keep `group` as taxonomy or compatibility metadata.

## 2. What happens at build time if a page declares a `group` slug the config doesn't know about?

The build **fails fast**.

If a page sets `group: <slug>` and that slug is not declared in the loaded config (either in `nav` or in the legacy `groups` array), leadtype reports an error and exits with code `1`. The exact message looks like:

```
error: <urlPath> declares unknown group "<slug>".
```

This is intentional — broken navigation is treated as a content bug, not a runtime rendering issue. The "same source of truth, no drift" rule means every frontmatter group must match a config-known slug; otherwise the pipeline stops so an invalid nav tree can never ship.
