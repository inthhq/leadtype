# Navigation: `nav` vs. legacy `group`

## 1. Which drives the sidebar and agent map?

**The curated `nav` in `docs.config.ts` is the source of truth.**

When `nav` is present, it drives the sidebar tree, `llms.txt` sections, `AGENTS.md`, sitemap markdown, search metadata, and Agent Readability navigation. The legacy `group` frontmatter field is no longer used for curated placement.

**`group` is still valid, but it is legacy taxonomy metadata.** It remains useful for:

- **Fallback navigation** — in projects that have not yet adopted `nav`, leadtype falls back to the legacy group resolver to build the nav tree from frontmatter.
- **Search facets / filtering** — broad taxonomy tags that help search UIs categorize pages.
- **Compatibility** — keeping `group` on pages eases migration and supports mixed workflows.

## 2. What happens at build time if a page declares an unknown `group` slug?

**The build fails with a runtime error.**

During the group-resolution step, leadtype validates every page's `group:` value against the slugs declared in the config. If a page references a group slug the config does not know about, the CLI throws an error of the form:

```
<urlPath> declares unknown group "<slug>"
```

This is intentional — the docs describe it as "broken navigation is a content bug, not a render-time problem." The same validation applies whether the project is using legacy `groups` or a mix of `nav` + `groups` for validation. Generation exits with code `1` so a bad config cannot ship.
