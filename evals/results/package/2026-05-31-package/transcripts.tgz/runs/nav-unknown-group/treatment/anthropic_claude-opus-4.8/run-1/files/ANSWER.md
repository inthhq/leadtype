# Leadtype navigation: `nav` vs. legacy `group`

## 1. Relationship between curated `nav` and a page's `group` frontmatter

**The curated `nav` in `docs.config.ts` is the source of truth for navigation.** When
a project adopts `nav`, that resolved tree is what drives every navigation surface
for both humans and agents:

- Top-level docs areas / tabs (e.g. Docs, Frontend, Integrations, Changelog) come
  from the root nav nodes.
- The active root node's pages and children become the sidebar.
- The *same* resolved tree also feeds the agent-facing map and generated artifacts:
  `llms.txt`, `AGENTS.md`, the sitemap markdown, and the Agent Readability
  navigation metadata.

So `nav` drives **both** the human sidebar **and** the agent map — they stay aligned
because they're generated from one structure. In `nav`, `base` cascades to children,
page strings are extensionless paths relative to the nearest `base` (a leading `/`
starts from the docs root), and `{ include: "folder/*", sort: ["order", "path"] }`
entries pull in the rest of a folder.

**The legacy `group` frontmatter field is now taxonomy / compatibility metadata, not
the primary navigation driver.** Once `nav` exists, `group` is still good for:

- **Legacy navigation fallback** — if a project has *no* `nav`, the CLI falls back to
  the legacy group resolver and infers the nav tree (plus `llms.txt` sections and
  `AGENTS.md` grouping) from the `group:` values it finds. This is fine for small
  docs sets, but `nav` is preferred when you need stable top-level areas, sidebar
  order, descriptions, nested sections, or wildcard includes.
- **Broad taxonomy / search facets** — a page can belong to multiple groups
  (`group: [a, b]`), which is useful for classifying and faceting content beyond a
  single sidebar position.

(The related `order` field similarly survives as a fallback sort for pages pulled in
by `include`.)

In short: **`nav` is the curated, intentional navigation that drives the sidebar and
the agent map; `group` is downgraded to taxonomy/compatibility metadata that still
powers the legacy fallback nav (when `nav` is absent) and search facets.**

## 2. What happens at build time if a page declares an unknown `group` slug?

**The build fails.** Group slugs must be declared in `docs.config.ts`. If a page's
`group` value isn't known to the config, generation errors with:

```
unknown group "<slug>"
```

This is intentional: the config is the single source of truth for valid groups, so an
undeclared slug is treated as drift and stops the build rather than silently creating
a phantom group. (To make a slug valid you declare it once in the config — for
example as an entry in `groups`, optionally nested via `children`, where only leaf
groups directly contain pages.)
