# Navigation in Leadtype: `nav` vs `group`

## 1. Relationship Between Config `nav` and Page `group` Frontmatter

### Which one drives the sidebar and agent map?

**Config `nav` drives the sidebar and agent map.**

The curated `nav` array in `docs.config.ts` is the **primary navigation system** and controls:
- Sidebar structure and page ordering
- Generated `llms.txt` sections (for hosted sites)
- `AGENTS.md` organization (for bundled package docs)
- `llms-full.txt` fallback structure
- Sitemap markdown and XML navigation
- Agent Readability metadata
- The resolved navigation tree used by site UIs (tabs, sidebars, breadcrumbs)

When you define `nav` in your config, you're explicitly declaring the docs information architecture. This is **intentional navigation** with stable top-level docs areas (e.g., "Docs", "API Reference", "Changelog"), explicit page ordering, section grouping, and nested hierarchies.

### What is the `group` field still good for?

The `group` field in page frontmatter remains available for **legacy fallback and taxonomy metadata**:

1. **Legacy navigation fallback** — In projects that have *not adopted* `nav`, each page declares a `group` slug (e.g., `group: authoring` or `group: [docs-site, reference]`). If `docs.config.ts` also declares those groups, the intersection produces a navigation tree. This is the migration path for older projects.

2. **Search and filter taxonomy** — The `group` field remains useful for faceted search, even when you're using config `nav`. You can use it as broad taxonomy metadata without it driving the primary navigation.

3. **Page sharing across taxonomy** — A page can declare `group: [a, b]` to appear in multiple taxonomy groups without duplicating files. This flexibility is independent of whether you use config `nav`.

### The mental model

From the frontmatter documentation:

> `nav` drives top-level docs areas, sidebar structure, `llms.txt`, `AGENTS.md`, sitemap markdown, and Agent Readability navigation.  
> `group` remains available for legacy navigation fallback, search facets, and broad taxonomy.

**Once you adopt config `nav`, the hierarchy of concerns is:**

1. **Config `nav`** — declares the product IA and drives all agent-facing outputs
2. **Page frontmatter `title` + `description`** — provides content for nav entries
3. **Page frontmatter `group`** — optional taxonomy for search/compat, not navigation
4. **Page frontmatter `order`** — only needed for fallback sorting within wildcard `include` entries

---

## 2. What Happens at Build Time When a Page Declares an Unknown `group`?

### The build fails with a clear error

If a page declares a `group` slug that `docs.config.ts` doesn't know about, **the build fails immediately** with:

```
error: unknown group "<slug>"
```

This is **by design** — it prevents silent data drift and ensures consistency. From the frontmatter documentation:

> If a page declares a group slug that isn't in `docs.config.ts`, the build fails with `unknown group "<slug>"`. Same source of truth, no drift.

### When this happens

This only applies when you have both:
1. A `docs.config.ts` with declared `groups` (the legacy approach)
2. Pages that reference a `group` value not listed in that config

### The resolution

You have two options:

1. **If you're still using the legacy group resolver** (no `nav` defined yet): Add the unknown group slug to your `docs.config.ts` `groups` array.

   ```ts
   export default defineDocsConfig({
     groups: ["authoring", "docs-site", "reference", "new-group"], // ← add it here
     // ...
   });
   ```

2. **If you're migrating to config `nav`** (recommended): Define your navigation structure in the `nav` config and remove the `groups` declaration. Pages then use `group` only for optional taxonomy, without strict validation.

### Why strict validation?

The error prevents a common problem: a page is authored with `group: typo-slug`, sits in the repo, and nobody notices because the group is silently skipped. By failing the build, you catch these mistakes before generation—the same reason the lint rules are strict.

For more on the migration path, see the [Nav migration prompts](node_modules/leadtype/docs/changelog/nav-migration-prompts.md) in the leadtype package docs.
