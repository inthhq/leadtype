# Leadtype navigation notes

1. **`docs.config.ts` `nav` is the curated source of truth.** When `nav` is present, its resolved tree drives the human navigation/sidebar structure and the agent-facing maps: generated navigation, `llms.txt`, `AGENTS.md`, sitemap markdown, and Agent Readability navigation. A page's frontmatter `group` is legacy metadata; it does not place the page in the curated sidebar. It remains useful for projects that have not adopted `nav` yet, for fallback navigation, for validating old taxonomy, and as broad taxonomy/search facet metadata.

2. **Unknown legacy groups fail the build when groups are being validated.** If a page says `group: some-slug` and the loaded config's legacy `groups` tree does not contain `some-slug`, `leadtype generate` fails fast with an error like:

   ```txt
   /docs/page declares unknown group "some-slug"
   ```

   That is intentional: a stale group is treated as broken navigation/taxonomy, not something deferred to render time. If a project has no configured legacy `groups` at all, Leadtype can infer groups for the legacy fallback; but once the config defines known group slugs, page frontmatter must match them.
