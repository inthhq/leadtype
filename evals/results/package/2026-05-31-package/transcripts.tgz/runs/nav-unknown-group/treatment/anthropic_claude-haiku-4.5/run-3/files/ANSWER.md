# Navigation System in Leadtype: `nav` vs. `group`

## 1. The Relationship Between Config `nav` and Page `group` Frontmatter

### Which one drives the sidebar and agent map?

The **curated `nav` in `docs.config.ts`** is the modern, primary driver of:
- **Sidebar structure** (top-level nav, sections, page order)
- **Agent map** (llms.txt organization, AGENTS.md grouping, Agent Readability metadata)
- **Generated navigation** (all framework adapters and static artifact manifests)

The `nav` config is the **single source of truth** for intentional, curated navigation hierarchy.

### What is the `group` frontmatter still good for?

The **legacy `group` field** in page frontmatter remains useful for:
- **Taxonomy and compatibility metadata** — marking which product area or feature a page belongs to, independent of sidebar placement
- **Search faceting** — filtering search results by topic
- **Fallback routing** — in projects that have not yet adopted config `nav`, leadtype falls back to inferring navigation structure from `group` values found in frontmatter
- **Backward compatibility** — existing pages can keep their `group` declarations without needing immediate refactoring

### The mental model

```
┌─────────────────────────────────────────────────────────────┐
│  Curated docs sites: Use config 'nav' for all navigation    │
├─────────────────────────────────────────────────────────────┤
│  docs.config.ts nav        →  Sidebar, llms.txt, AGENTS.md  │
│  Page group (optional)     →  Taxonomy, search facets       │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│  Legacy projects without nav: Use group for fallback nav    │
├─────────────────────────────────────────────────────────────┤
│  Page group values         →  Inferred nav (fallback mode)  │
│  docs.config.ts groups     →  Declare expected group slugs  │
└─────────────────────────────────────────────────────────────┘
```

**Key point:** Once frontmatter and config are consistent, Leadtype keeps human and agent surfaces aligned. The `nav` is the polished, curated navigation; `group` is optional taxonomy that's useful for broad categorization and search.

---

## 2. What Happens at Build Time with Unknown Groups

### The error behavior

If a page declares a `group` slug that **isn't defined** in `docs.config.ts`, the build **fails immediately** with an error like:

```
error: docs/my-page.mdx declares unknown group "undefined-slug".
```

### Why this is intentional

This strict validation is **by design** — Leadtype treats unknown groups as a content bug, not a render-time problem to work around. The philosophy is:

> "Same source of truth, no drift."

Enforcing the constraint prevents:
- **Config/frontmatter desync** — where pages reference groups that no longer exist in config
- **Silent bugs** — pages accidentally being omitted from navigation
- **Agent map inconsistency** — llms.txt and AGENTS.md becoming fragmented because some pages reference undefined groups

### Exit codes

The `leadtype generate` command exits with code `1` on unknown groups (along with other fatal errors like docs dir missing, config load errors, or conversion failures). This makes the error observable in CI and prevents broken builds from being deployed.

### Related validation

- `leadtype lint` does **not** independently enforce group validation in frontmatter schema (since `group` is optional)
- However, `leadtype generate` performs this check automatically when it loads the config
- `leadtype generate` also fails on other navigation issues like broken includes and missing referenced pages

---

## Summary

| Aspect | `nav` (config) | `group` (frontmatter) |
|--------|---|---|
| **Purpose** | Curated navigation structure | Taxonomy & compatibility metadata |
| **Drives sidebar?** | ✅ Yes (modern approach) | ❌ No (legacy fallback only) |
| **Drives llms.txt/AGENTS.md?** | ✅ Yes | ❌ No (legacy fallback only) |
| **Search faceting?** | N/A | ✅ Yes |
| **Must be defined?** | Required for modern sites | Only if page declares it |
| **Unknown value handling** | N/A | ❌ Build fails (exit code 1) |

For new projects, **use `nav` for all intentional navigation and skip `group`** unless you need backward compatibility or search faceting. For existing projects migrating from frontmatter-only groups, **keep `group` as taxonomy metadata and move navigation to `nav`**.
