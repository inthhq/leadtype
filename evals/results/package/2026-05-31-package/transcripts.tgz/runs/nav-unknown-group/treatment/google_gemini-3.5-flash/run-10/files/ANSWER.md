# Navigation in Leadtype

Here are the answers to your questions about navigation in Leadtype:

## 1. Curated `nav` in `docs.config.ts` vs. Legacy `group` Frontmatter

### The Relationship
* **Curated `nav` (Modern, Config-Owned)**: This is the preferred, modern approach to defining documentation structure in Leadtype. It is a configuration-level array in `docs.config.ts` (or `leadtype.config.ts`) that describes top-level areas, sidebar sections, and folder-based wildcards.
* **Legacy `group` (Page-Owned)**: This is a page-level YAML frontmatter field (`group: <slug>` or `group: [slug-a, slug-b]`) that assigns pages to taxonomy categories. In older or smaller projects that have not adopted `nav`, Leadtype uses a fallback group resolver that maps these page frontmatter fields to groups declared in `docs.config.ts` to build an implicit navigation tree.

### Which One Drives the Sidebar and Agent Map?
* The curated **`nav`** defined in `docs.config.ts` drives the active reader-facing sidebar, top navbar tabs, and all agent-facing document maps (including `llms.txt`, `AGENTS.md`, sitemap markdown, and Agent Readability metadata / `agent-readability.json` manifests).

### What is the Legacy `group` Field Still Good For?
Even when a curated `nav` is fully configured, `group` is still valid and serves several purposes:
1. **Taxonomy & Metadata**: It serves as broad taxonomy metadata for organizing documents.
2. **Search Facets**: It acts as search facets/filters to help users drill down into search results.
3. **Compatibility**: It acts as compatibility metadata for existing external systems or legacy pipelines.
4. **Fallback Navigation**: It provides fallback/implicit navigation in projects or collections that have not yet adopted explicit config-level `nav`.

---

## 2. Unrecognized `group` Slug Build-Time Behavior

If a page declares a legacy `group` slug that is not defined in the `docs.config.ts` configuration, **the build will fail at build time with an explicit error**:

```text
unknown group "<slug>"
```

Leadtype enforces this strict check to ensure there is a single source of truth across all documentation surfaces and to prevent configuration drift between authored files and build-time configurations.
