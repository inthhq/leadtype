# Leadtype Navigation: Config Nav vs. Legacy Group Frontmatter

## Question 1: Relationship between `nav` and `group` — which drives what?

### The Hierarchy

**`nav` in `docs.config.ts` is the source of truth** for:
- **Sidebar structure** — which pages appear where, nesting, and order
- **Agent map generation** — the navigation structure in `llms.txt`, `AGENTS.md`, and `agent-readability.json`
- **Top-level docs areas** — root nodes become tabs (Docs, Frontend, Integrations, Changelog, etc.)

**`group` frontmatter remains valid but is secondary** — it now serves as:
- **Legacy taxonomy metadata** — for backwards compatibility with systems that parsed pages by group
- **Search facets** — pages can still be tagged with group slugs for filtering
- **Fallback navigation** — in projects without `nav`, the CLI falls back to resolving groups from page `group:` values

### Driving the Build

When `nav` is present in config, it **completely drives** sidebar structure, `llms.txt` sections, `AGENTS.md` organization, and Agent Readability navigation. The `group` field is not consulted for structural decisions.

When `nav` is **absent** from config, Leadtype falls back to the legacy group resolver: it scans all pages for their `group:` values, validates each against the groups defined in config (if any), and infers a navigation tree from the intersection of frontmatter groups and config groups.

### The Data Flow

```
docs.config.ts (nav array)
        ↓
[drives sidebar, llms.txt sections, AGENTS.md structure, agent-readability.json]

page frontmatter (group field)
        ↓
[used for validation if nav exists]
[fallback resolver input if nav is absent]
```

## Question 2: What happens at build time if a page declares an unknown `group`?

### The Outcome: Build Failure

**The build fails with an error: `unknown group "<slug>"`**

This is intentional. From the documentation:

> If a page declares a group slug that isn't in `docs.config.ts`, the build fails with `unknown group "<slug>"`. Same source of truth, no drift.

### Why This Design

This strict validation ensures:
1. **No silent navigation drift** — typos in group slugs are caught immediately, not discovered later when a page is missing from the sidebar
2. **Predictable output** — the same source documents always produce the same navigation structure
3. **CI safety** — broken navigation is a content bug that should fail in CI before publish, not a render-time problem

### How to Fix It

Either:
- **Add the group to config**: Declare the slug in `docs.config.ts` (either in the legacy `groups:` array for fallback navigation, or integrate it into the `nav:` structure if migrating to config-owned navigation)
- **Remove or rename the `group` field** in the page frontmatter to match a known group slug
- **Migrate to config-owned `nav`**: If you're adopting the recommended `nav` structure, you may not need to declare the group in frontmatter at all—pages are placed by explicit `pages:` entries or `include:` wildcards in config instead

### The Validation Stage

This check happens during the "Resolve groups" stage of the `leadtype generate` pipeline, **before** any output is written. It's stage 3 of 4-5:

1. Parse frontmatter
2. Convert MDX through remark stack → write `.md` files
3. **Resolve groups and validate** ← unknown group error happens here
4. Generate `llms.txt`, search index, etc. (site mode) or `AGENTS.md` (bundle mode)

---

## Summary

| Aspect | `nav` | `group` |
|--------|-------|--------|
| **Drives sidebar?** | ✅ Yes (when present) | ❌ No (fallback only) |
| **Drives agent map?** | ✅ Yes (when present) | ❌ No (fallback only) |
| **Enables nesting?** | ✅ Full tree support | ❌ Flat/simple only |
| **Purpose now** | Curated navigation structure | Taxonomy, search facets, compatibility |
| **Where it lives** | `docs.config.ts` | `.mdx` frontmatter |
| **Unknown slug handling** | N/A (explicit entries) | Build fails with `unknown group` error |

