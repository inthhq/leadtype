# Navigation in leadtype: `nav` vs. legacy `group`

## 1. Relationship between curated `nav` and the legacy `group` frontmatter field

**Curated `nav` in `docs.config.ts` is the source of truth — it drives the sidebar and the agent map.** The legacy `group` frontmatter field is now demoted to *taxonomy / compatibility metadata*.

### What `nav` drives

The `nav` array you define in `docs.config.ts` is the curated, intentional navigation structure. Its resolved tree feeds **every human and agent surface from one place**:

- Top-level docs areas / tabs (root `nav` nodes like Docs, Frontend, Integrations, Changelog).
- The reader-facing sidebar (the active root node's `pages` and `children`).
- Generated navigation (e.g. `docs-nav.json`).
- `llms.txt` section headings.
- `AGENTS.md` grouping (the agent-readable document map).
- Sitemap markdown and Agent Readability navigation metadata.

Because all of those come from the same resolved `nav` tree, the human sidebar and the agent map stay aligned — no drift. `nav` lets you express things `group` cannot: stable top-level areas, explicit sidebar order, nested sections, descriptions, `base` prefixes, pinned entry pages (`quickstart`, `installation`, `cli`), and wildcard `{ include: "folder/*", sort: ["order", "path"] }` entries.

### What `group` is still good for

`group` is **still valid**, but it's no longer where you express polished navigation. It remains useful as:

- **Taxonomy / broad classification metadata** — tagging which conceptual area a page belongs to (a page can belong to several: `group: [a, b]`).
- **Search facets** — `group` values can be used to facet/filter search.
- **Compatibility / legacy navigation fallback** — in projects that have **not** adopted `nav`, the CLI falls back to a legacy group resolver. It declares each group once in `docs.config.ts` (`groups: [...]`), reads the `group:` values from page frontmatter, and the intersection produces a fallback nav tree, `llms.txt` sections, search metadata, and AGENTS.md grouping. That fallback is fine for small docs sets, but `nav` is recommended once you need real IA.

A companion field, `order`, similarly survives only as a fallback sort for pages pulled in by wildcard `include` entries.

**Summary:** `nav` (config) = curated navigation that drives the sidebar and the agent map. `group` (frontmatter) = taxonomy/compatibility metadata, search facets, and the legacy nav fallback for projects without `nav`.

## 2. What happens at build time when a page declares an unknown `group` slug?

**The build fails.** If a page declares a `group` slug that `docs.config.ts` doesn't know about (i.e. isn't declared in the config's `groups`), `leadtype generate` errors out with:

```
<urlPath> declares unknown group "<slug>"
```

This is intentional. As the docs put it, broken navigation is treated as a *content bug*, not a render-time problem — so it's caught during generation rather than silently producing a malformed nav. The `generate` run exits with **exit code `1`** (runtime error). This enforces a single source of truth between page frontmatter and config, preventing drift between declared groups and known groups.
