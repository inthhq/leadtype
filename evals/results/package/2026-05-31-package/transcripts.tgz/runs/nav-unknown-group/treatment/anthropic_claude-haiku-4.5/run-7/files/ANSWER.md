# Navigation in Leadtype: `nav` vs `group`

## 1. Relationship Between `nav` Config and `group` Frontmatter

### What Drives the Sidebar and Agent Map

**The curated `nav` in `docs.config.ts` is the primary driver** of the sidebar, agent map, and all generated navigation outputs.

When you define `nav` in your `docs.config.ts`:
- It drives the **top-level docs areas** (e.g., "Docs", "Frontend", "Integrations", "Changelog")
- It drives the **sidebar structure** within each docs area
- It drives the **resolved navigation tree** that powers generated artifacts
- It drives **`llms.txt` sections and hierarchy**
- It drives **`AGENTS.md` sections and grouping**
- It drives **sitemap markdown and Agent Readability metadata**

The `nav` config becomes the single source of truth for intentional, curated page placement and ordering.

### What the Legacy `group` Frontmatter is Still Good For

The `group` field in page frontmatter remains available for:

1. **Legacy navigation fallback** — If you don't have a `nav` config, `leadtype generate` falls back to the legacy group resolver. The CLI infers groups from the `group:` values it finds in pages and uses them to build a navigation tree. This fallback is enough for small docs sets.

2. **Search facets** — The `group` field can continue to be used for search filtering and categorization.

3. **Broad taxonomy metadata** — `group` serves as compatibility and taxonomy metadata that pages can declare, allowing pages to belong to multiple conceptual categories even if they don't appear in multiple nav locations.

4. **Backward compatibility** — Existing docs that declared `group:` values continue to work.

### The Key Insight

- **`nav`** = intentional, curated, polished navigation structure for readers and agents
- **`group`** = taxonomy metadata for compatibility and search, plus legacy fallback when `nav` doesn't exist

Once `nav` is defined, treat `group` as optional metadata. Put your navigation structure in `nav`. Per the documentation: *"Keep frontmatter `group` only as taxonomy/compatibility metadata."*

---

## 2. What Happens at Build Time with Unknown Group Slugs

If a page declares a `group` slug that the config doesn't know about, **the build fails with an error**.

Specifically, the error message is: `unknown group "<slug>"`

### Why This Happens

From the Leadtype documentation:

> If a page declares a group slug that isn't in `docs.config.ts`, the build fails with `unknown group "<slug>"`. **Same source of truth, no drift.**

This is intentional design: when you have groups defined in your config, Leadtype enforces that **every page's `group` value must correspond to a declared group in `docs.config.ts`**. This prevents:

- Typos in group names that silently create wrong navigation
- Pages getting lost or misplaced due to undefined groups
- Configuration drift between what the config claims and what pages actually use

### How to Avoid This

You have two options:

1. **Define the group in `docs.config.ts`** — Add the missing slug to your config's `groups` array:
   ```ts
   export default defineDocsConfig({
     groups: ["authoring", "docs-site", "reference"], // add missing slug here
   });
   ```

2. **Migrate to config-owned `nav`** — Move your navigation structure into `nav` and remove the legacy group declarations from frontmatter. This eliminates the group validation altogether and makes the navigation fully explicit in the config.

The second approach is recommended for new or actively maintained docs sites, as it makes the navigation structure clearer and gives you more control over page placement and ordering.
