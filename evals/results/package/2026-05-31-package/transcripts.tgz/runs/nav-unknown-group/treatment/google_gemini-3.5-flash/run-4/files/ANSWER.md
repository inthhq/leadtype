# Navigation in Leadtype

## 1. Relationship between `nav` and legacy `group`

* **What drives the sidebar and agent map:** 
  The curated `nav` in `docs.config.ts` serves as the preferred, modern, and shared source of truth. It directly drives the human sidebar structure, the agent map, `llms.txt`, `AGENTS.md` sections, sitemap markdown, and Agent Readability navigation.
* **What `group` is still good for:** 
  The legacy `group` frontmatter field is still useful as taxonomy/compatibility metadata. It is used for:
  - **Fallback navigation:** If a project has not yet migrated to or adopted the `nav` configuration, the CLI falls back to inferring the navigation structure from the `group:` values declared in frontmatter.
  - **Search facets and broad taxonomy:** Organizing and filtering search results/facets.

---

## 2. What happens at build time if a page declares an unknown `group` slug

At build time (such as when running `leadtype generate` or calling `resolveDocsNavigation`), if a page declares a `group` slug that the configuration doesn't know about:
* **The build fails fast and noisily:** The run terminates with an exit code of `1` and prints an error like `unknown group "<slug>"` (or `error: <urlPath> declares unknown group "<slug>"`).
* **Why this happens:** This behavior is by design. Leadtype treats broken navigation as a critical content bug rather than a minor render-time problem, ensuring that a broken or drifting configuration is caught in CI and never shipped.
