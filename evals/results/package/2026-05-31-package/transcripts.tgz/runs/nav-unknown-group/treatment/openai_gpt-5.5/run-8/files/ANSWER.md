# Leadtype navigation: `nav` vs `group`

1. **`docs.config.ts` `nav` is the source of truth for curated navigation.** It drives the resolved navigation tree used for the human sidebar/top-level docs areas and the agent-facing map: `llms.txt`, `AGENTS.md`, sitemap markdown, and Agent Readability navigation metadata.

   A page's frontmatter `group` is a **legacy taxonomy field**. When a project has not adopted `nav`, Leadtype can still use configured/inferred `groups` plus page `group:` values as fallback navigation. In projects that do use `nav`, `group` is still useful for broad taxonomy, compatibility with older pipelines, search/filter facets, and validating old group assignments when `groups` are kept in config.

2. **An unknown configured legacy group is a build error.** If a page declares `group: some-slug` and the loaded config's legacy `groups` list does not include that slug, Leadtype reports it as an unknown group and `leadtype generate` fails fast with a non-zero exit, e.g.:

   ```text
   /docs/example declares unknown group "some-slug"
   ```

   It is not silently ignored, auto-created, or placed into the sidebar. Fix it by correcting/removing the page's `group` value or adding the group slug to the config. In custom API usage, `resolveDocsNavigation()` exposes these as `navigation.unknown`; the CLI checks that list and fails the build.