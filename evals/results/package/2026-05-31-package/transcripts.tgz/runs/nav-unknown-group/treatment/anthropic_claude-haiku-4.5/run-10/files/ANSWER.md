# Navigation in Leadtype: `nav` Config vs Legacy `group` Frontmatter

## 1. Relationship between `nav` config and `group` frontmatter — which drives what?

### What drives the sidebar and agent map

**The curated `nav` in `docs.config.ts` is the primary driver.**

The `nav` configuration defines:
- The **sidebar structure** and page placement
- The **agent map** (how pages appear in `llms.txt` and `AGENTS.md`)
- **Top-level docs areas** (e.g., Docs, Frontend, Integrations, Changelog)
- **Section headings and nesting** throughout the navigation tree
- Agent-facing document organization

### What the legacy `group` frontmatter is still good for

The `group` field in page frontmatter remains useful for:
- **Fallback navigation** in projects that haven't adopted config-owned `nav` yet
- **Search facets and taxonomy metadata** — pages can declare one or more group slugs (`group: slug` or `group: [slug1, slug2]`) for broad categorization
- **Compatibility with legacy projects** — if you don't have `nav`, the CLI falls back to the legacy group resolver and infers navigation from `group:` values it finds

### How they work together

When both exist:
- `nav` drives the curated, intentional navigation structure
- `group` is a backward-compatible taxonomy field that can be used for search filtering or multi-group membership
- They are **separate concerns**: `nav` is structural and intentional; `group` is organizational metadata

The best practice is to put intentional navigation in `nav` and use `group` only when needed for taxonomy or compatibility.

---

## 2. What happens at build time if a page declares a `group` slug that the config doesn't know about?

**The build fails with an error: `unknown group "<slug>"`**

This is intentional and by design:

- When `leadtype generate` runs, it resolves groups from frontmatter in step 3 of the pipeline
- If any page declares a `group:` value that isn't defined in the config, the build **fails loudly and immediately**
- The build process exits with code 1 (runtime error)
- The error message clearly identifies which page declares the unknown group and what the unknown slug is

### Why this happens

According to the leadtype documentation: *"Broken navigation is a content bug, not a render-time problem."*

This strict validation ensures:
- **Same source of truth** — no drift between what pages declare and what the config recognizes
- **Early failure** — content bugs surface during the build, not at runtime
- **Clear error messages** — developers see exactly what needs to be fixed
- **Predictable behavior** — declared groups always match known configuration

### Avoiding the error

Ensure that every `group:` value in your pages is either:
1. Declared in `docs.config.ts` if you're using the legacy group resolver, OR
2. Removed if you've migrated to config-owned `nav` and don't need it anymore

As you adopt `nav`, you can keep `group` defined in the config for backward compatibility, or remove it entirely once all pages are placed via `nav`.
