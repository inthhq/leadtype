# Leadtype Navigation & Taxonomy Q&A

This document clarifies the relationship between the curated `nav` configuration and legacy `group` frontmatter fields in a `leadtype` project.

---

### 1. What is the relationship between the curated `nav` in `docs.config.ts` and a page's legacy `group` frontmatter field — which one drives the sidebar and agent map, and what is the other still good for?

#### Relationship
- **Curated `nav`** in `docs.config.ts` is the modern, preferred API for defining the site’s information architecture (IA). It lives directly in the configuration file, allowing you to explicitly organize pages, nested folders, order, and wildcards (via `{ include: "..." }`) from a single central source of truth.
- **Legacy `group`** is a page-level frontmatter field (e.g., `group: slug` or `group: [a, b]`) paired with a `groups` list in `docs.config.ts` (or inferred if not defined). It represents the legacy, flat taxonomy/classification-based approach to docs.

#### Which one drives the sidebar and agent map?
- **Curated `nav`** drives the modern sidebar, navigation, and agent map (including `llms.txt` sections, sitemap markdown, Agent Readability metadata like `agent-readability.json`, and `AGENTS.md` for bundled environments). 
- If `nav` is absent, Leadtype's CLI falls back to the legacy group resolver to build a fallback navigation tree, section headings, and `AGENTS.md` grouping.

#### What is the other (`group` frontmatter) still good for?
Even when you adopt the modern config-owned `nav`, page-level `group` fields remain useful for:
- **Broad taxonomy and compatibility metadata.**
- **Search facets and filtering** (helping search indexers/engines slice content into taxonomy filters).
- **Legacy navigation fallback** in projects or collections that have not yet migrated to the modern `nav` structure.

---

### 2. What happens at build time if a page declares a `group` slug that the config doesn't know about?

- **The build fails noisily:** At build/generation time (`leadtype generate`), during the "Resolve groups" stage, the generation script fails fast and exits with a runtime error (exit code `1`).
- **Error output:** It prints a descriptive error to standard error (stderr), indicating which page has the problem and what the unknown group is, in the following format:
  ```text
  error: <urlPath> declares unknown group "<slug>".
  ```
- **Why this design exists:** This strict fail-fast mechanism prevents broken navigation or incorrect taxonomy configurations from shipping. By treating navigation/group mismatches as a hard build error rather than a runtime rendering glitch, Leadtype ensures absolute consistency between the content files and the central configuration, preventing drifting metadata and "wrong-group" agent reading issues.
