# Leadtype navigation and legacy groups

1. **`docs.config.ts` `nav` is the curated source of truth.** It drives the resolved navigation tree used for the human sidebar/top-level docs areas and for agent-facing maps/artifacts such as `llms.txt`, `AGENTS.md`, sitemap markdown, and Agent Readability navigation.

   A page's frontmatter `group` is **legacy taxonomy metadata**. It is still useful for projects that have not adopted `nav` yet, where Leadtype can fall back to the old group resolver, and it can still be used as broad taxonomy/search-filter metadata. It should not be treated as the place to express polished sidebar ordering or curated IA once `nav` exists.

2. **Unknown legacy groups fail the build when Leadtype is validating against configured groups.** If a page says `group: some-slug` and the loaded config's legacy `groups` tree does not contain `some-slug`, `leadtype generate` fails before shipping artifacts with an error like:

   ```text
   /docs/some-page declares unknown group "some-slug"
   ```

   That fail-fast behavior is intentional: a stale or misspelled group is considered a content/config bug, not something to silently render around. If there is no configured legacy `groups` source of truth, Leadtype may infer groups for the fallback path; with curated `nav`, page placement comes from `nav`, not from `group`.