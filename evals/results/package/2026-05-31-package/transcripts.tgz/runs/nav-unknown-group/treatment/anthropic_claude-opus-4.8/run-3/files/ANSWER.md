# Navigation in leadtype: `nav` vs. legacy `group`

## 1. Relationship between curated `nav` and the legacy `group` frontmatter field

**Curated `nav` in `docs.config.ts` is the source of truth and drives the sidebar and the agent map.** When you define `nav` in `docs.config.ts`, that resolved tree is what produces:

- top-level docs areas / tabs (e.g. Docs, Frontend, Integrations, Changelog),
- the sidebar structure and order,
- `llms.txt` sections,
- `AGENTS.md` grouping,
- sitemap markdown,
- Agent Readability navigation metadata.

In `nav`, page placement is config-owned: nodes use `base` (which cascades to children), extensionless page paths relative to the nearest `base` (a leading `/` starts from the docs root), and `include` entries with `order`-then-path sorting for wildcard matches. Because all of these human and agent surfaces come from the same resolved tree, there's a single source of truth and no drift.

**The legacy `group` frontmatter field is optional taxonomy metadata.** It is *not* what drives navigation once you've adopted `nav`. It remains useful for:

- **Legacy navigation fallback** — if a project has *not* adopted `nav`, the CLI falls back to the legacy group resolver. It infers groups from the `group:` values it finds on pages, intersects them with the groups declared in `docs.config.ts`, and produces the fallback nav tree, `llms.txt` section headings, search metadata, and AGENTS.md grouping. This fallback is fine for small docs sets, but `nav` is preferred when you need stable top-level areas, sidebar order, descriptions, nested sections, or wildcard includes.
- **Search facets / broad taxonomy** — `group` (and a page can declare several, `group: [a, b]`) lets a page belong to multiple taxonomy groups and feed search faceting, independent of where it sits in the curated sidebar.

In short: `nav` curates placement and drives the real sidebar + agent map; `group` is legacy/taxonomy metadata that still powers the no-`nav` fallback and search facets.

## 2. What happens at build time when a page declares an unknown `group` slug

**The build fails.** If a page declares a `group` slug that isn't declared in `docs.config.ts`, leadtype errors out with:

```
unknown group "<slug>"
```

This is intentional: the config and the page frontmatter share the same source of truth for groups, so an undeclared slug is treated as an error rather than silently dropped — preventing navigation/taxonomy drift. (Groups are declared in the config, and only leaf groups—those with no children—directly contain pages; non-leaf groups are headings only.)
