# Leadtype navigation: `nav` vs. legacy `group`

## 1. Relationship between curated `nav` and a page's legacy `group` frontmatter

In current leadtype, the **curated `nav` array in `docs.config.ts` is the single source of truth** for navigation. It drives every structured surface:

- top-level docs areas / navbar tabs (e.g. Docs, Frontend, Integrations, Changelog),
- the human sidebar (the active root node's pages and children),
- the generated `llms.txt`,
- the agent map in `AGENTS.md`,
- the sitemap markdown,
- and the Agent Readability navigation metadata.

Because they're all resolved from the same `nav` tree, the human-facing and agent-facing surfaces stay aligned with no drift.

The page-level **`group` frontmatter field is now legacy taxonomy/compatibility metadata** — it is *not* the preferred place to express polished navigation. It still earns its keep in a few ways:

- **Legacy navigation fallback.** If a project has *not* adopted `nav`, the CLI falls back to the legacy group resolver: it infers groups from the `group:` values it finds, intersects them with the `groups` declared in `docs.config.ts`, and produces the fallback nav tree, `llms.txt` section headings, and `AGENTS.md` grouping. This fallback is fine for small docs sets, but `nav` is what you want for stable top-level areas, sidebar order, descriptions, nested sections, and wildcard includes.
- **Taxonomy / search facets.** `group` (a page may declare one slug or several via `group: [a, b]`) provides broad taxonomy that pages can share across multiple groups, and feeds search metadata/facets.

So: **`nav` drives the sidebar and the agent map.** `group` is kept around for the legacy no-`nav` fallback resolver, for search/taxonomy facets, and as compatibility metadata. (Likewise, `order` lives on as fallback sorting for pages pulled in by wildcard `include` entries.)

## 2. What happens at build time with an unknown `group` slug

When a `nav`-less project uses the legacy group resolver, each group slug must be declared once in `docs.config.ts` (the `groups` definitions). The page-declared `group` slugs and the config's declared groups are intersected against the same source of truth.

If a page declares a `group` slug that the config does **not** know about, the build **fails** with the error:

```
unknown group "<slug>"
```

This deliberate failure keeps the config and page frontmatter in sync — "same source of truth, no drift" — so a typo'd or orphaned group slug can't silently produce a broken or partial navigation tree. (You can also catch these earlier in CI via `leadtype lint`, which enforces the frontmatter schema before a build runs.)
