# Leadtype Navigation and Grouping

## 1. Relationship Between Curated `nav` and Legacy `group`

In Leadtype projects:

* **Curated `nav` (`docs.config.ts`):** This is the modern, central configuration for site structure. It **drives the sidebar, agent map**, top-level docs areas, `llms.txt` sections, `AGENTS.md` grouping, sitemap markdown, and Agent Readability navigation. It is the best place to express your information architecture, offering nested sections, descriptions, custom ordering, and wildcard includes.
* **Legacy `group` (Frontmatter field):** In projects that have not yet adopted or migrated to `nav`, `group` defines which taxonomy group a page belongs to. When `nav` is configured, the legacy `group` frontmatter field is still useful for:
  * **Fallback navigation** (for smaller docs sets or collections that have not yet transitioned to `nav`).
  * **Search facets** (providing filters for users/agents to segment search results).
  * **Broad taxonomy / compatibility metadata**.

---

## 2. What Happens at Build Time on Unknown Legacy Group Declaration

If a page declares a legacy `group` slug in its frontmatter that isn't defined or known in `docs.config.ts` (or in the loaded configuration):

* **The build fails noisily and exits with Code `1` (Runtime Error).**
* The CLI outputs an error message like: `error: <urlPath> declares unknown group "<slug>".`
* This **fail-fast design** ensures that broken navigation and taxonomy drift are caught in CI/locally as a compile-time content bug, preventing broken navigation from reaching production.
