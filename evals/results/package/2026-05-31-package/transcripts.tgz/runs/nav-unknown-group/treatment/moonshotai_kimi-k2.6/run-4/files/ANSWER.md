# Navigation: `nav` vs. legacy `group`

## 1. Which drives the sidebar and agent map, and what is the other good for?

**The curated `nav` tree in `docs.config.ts` drives the sidebar and the agent map.**

- `nav` is the preferred source of truth for page placement. It controls top-level docs areas, sidebar structure, `llms.txt`, `AGENTS.md`, sitemap markdown, and Agent Readability metadata.
- The page-level `group` frontmatter field is a **legacy taxonomy slug**. It is no longer the best place to express polished navigation, but it is still useful for:
  - **Fallback navigation** — when `nav` is not present, the CLI falls back to the legacy group resolver and infers the nav tree from the `group:` values it finds in frontmatter.
  - **Search facets** — `group` values feed search metadata and taxonomy filtering.
  - **Broad compatibility metadata** — it can act as a loose tag for topics that cross multiple curated sections.
  - **Fallback sorting** — when an `include` entry pulls pages in via wildcard, `order` (which pairs with `group`) provides a stable secondary sort key.

If both `nav` and `group` are present, `nav` wins for sidebar and agent-map generation. The migration guidance recommends keeping `groups` defined in the config when you still want frontmatter `group` values to validate, while using `nav` for the actual reader-facing structure.

## 2. What happens at build time if a page declares a `group` slug the config doesn't know about?

**The build fails.**

During `leadtype generate`, the pipeline resolves groups and validates that every page's `group:` matches a known slug. If a page names a group that is not declared in the loaded config, the run errors out with a message like:

```
error: <urlPath> declares unknown group "<slug>".
```

The CLI exits with code `1` (runtime error). This is intentional — broken navigation is treated as a content bug, not a render-time problem. It surfaces at build time so it can be caught in CI before anything is published.

> This validation also applies when you are using `nav` **if** you keep `groups` defined in the config for validation purposes. If `groups` is omitted entirely, the `group` frontmatter is ignored for validation, but the recommended practice is to keep config and frontmatter in sync.
