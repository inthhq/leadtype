# Leadtype navigation: `nav` vs. legacy `group`

1. **`docs.config.ts` `nav` is the curated source of truth for navigation.** When present, it drives the resolved navigation tree used by the human sidebar/top-level docs areas and the agent-facing document maps: `llms.txt`, `AGENTS.md`, sitemap markdown, and Agent Readability navigation metadata.

   A page's frontmatter `group` field is still valid, but it is legacy/taxonomy metadata rather than the place to model polished navigation. It remains useful for:

   - fallback navigation in projects that have not adopted `nav`,
   - validating compatibility with older `groups` config,
   - broad taxonomy/search/filter facets.

   In short: put intentional IA/sidebar structure in config `nav`; keep `group` only as metadata or for legacy fallback.

2. **Unknown legacy groups fail the build.** If a page declares `group: some-slug` and the loaded config's legacy `groups` list does not contain that slug, Leadtype treats it as a content/config drift bug and exits non-zero. The CLI reports an error like:

   ```text
   <urlPath> declares unknown group "some-slug"
   ```

   This validation happens before shipping generated artifacts, so a bad sidebar/agent map does not publish. If there is no config-owned group list at all, Leadtype can infer legacy groups as a fallback; but once the config declares known groups, page `group` values must match them.
