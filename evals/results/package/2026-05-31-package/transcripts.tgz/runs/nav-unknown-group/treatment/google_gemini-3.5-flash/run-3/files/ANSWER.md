# Navigation in Leadtype: Answers

## 1. Relationship between Curated `nav` in `docs.config.ts` and Legacy `group` Frontmatter

* **The Relationship**: 
  * `nav` (configured in `docs.config.ts` or per-collection in `leadtype.config.ts`) is the modern, preferred, config-driven API for describing the curated information architecture of a documentation site in one centralized place.
  * `group` (a field inside a page's frontmatter, e.g., `group: <slug>`) is a legacy taxonomy field that was historically used to associate pages with a flat group of docs.

* **Which one drives the sidebar and agent map?**
  * **`nav`** is the primary driver for both the human-facing sidebar and all AI/agent-facing navigation structures (including `llms.txt`, `AGENTS.md`, sitemap markdown, and Agent Readability navigation metadata). It aligns human and agent surfaces to prevent navigation drift.

* **What is `group` still good for?**
  * **Legacy Navigation Fallback**: For smaller or older projects that have not yet migrated to the `nav` configuration, Leadtype falls back to the legacy group resolver, inferring or mapping groups to build a fallback navigation tree.
  * **Search Facets and Taxonomy**: Categorizing pages for search engines, broad taxonomy organization, and filters.
  * **Compatibility/Taxonomy Metadata**: Retaining metadata tags for backward compatibility.

---

## 2. What happens at build time if a page declares an unknown `group` slug?

* **The Build Fails Fast**: The build/generation process (such as `leadtype generate`) immediately fails and exits noisily. 
* **Error Message**: It outputs a specific error message to stderr, such as:
  `error: <urlPath> declares unknown group "<slug>".` or `unknown group "<slug>"`.
* **Exit Code**: The CLI exits with code **`1`** (representing a runtime build error).
* **Why it does this**: This is a deliberate, fail-fast design choice. Leadtype treats broken navigation or drift between frontmatter and configuration as a content bug. Failing at build time ensures that broken navigation or orphaned pages cannot be shipped to production.
