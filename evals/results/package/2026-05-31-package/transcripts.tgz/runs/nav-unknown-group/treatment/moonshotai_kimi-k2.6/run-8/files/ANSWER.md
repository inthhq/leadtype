# Navigation: `nav` vs. `group`

## 1. Which one drives the sidebar and agent map?

**`nav` in `docs.config.ts` is the curated source of truth.** It drives:

* Sidebar structure
* `llms.txt` and `AGENTS.md` sections
* Sitemap markdown
* Agent Readability navigation metadata
* Search metadata

**`group` frontmatter is legacy taxonomy metadata.** It is no longer the best place to express polished navigation, but it is still valid and useful for:

* **Fallback navigation** — when a project has not adopted `nav`, leadtype falls back to the legacy group resolver and infers the nav tree from the `group:` values it finds in frontmatter.
* **Search facets / taxonomy** — broad categorization that can feed search filters or compatibility metadata.

In short: put intentional navigation in `nav`; keep `group` only for legacy fallback or taxonomy.

## 2. What happens at build time if a page declares an unknown `group` slug?

`leadtype generate` **fails with a runtime error** (exit code `1`).

During the group-resolution step — which runs before conversion — the pipeline validates every page's `group:` value against the known groups loaded from the config. If a page names a group slug that is not declared in `docs.config.ts`, the build throws an error like:

```
<urlPath> declares unknown group "<slug>"
```

This is by design: broken navigation is treated as a content bug, not a render-time problem.

> **Note on `nav`-only configs:** The validation above runs against the `groups` array in `docs.config.ts`. If your config uses **only** `nav` and omits `groups`, frontmatter `group` values are not validated and will not fail the build. If you want frontmatter `group` values to continue validating while you use `nav`, keep the `groups` array defined in the config (see the nav-migration docs in `leadtype/docs/changelog/nav-migration-prompts.md`).
