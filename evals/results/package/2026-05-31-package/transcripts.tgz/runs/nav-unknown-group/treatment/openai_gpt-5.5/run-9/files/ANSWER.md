# Leadtype navigation and legacy groups

1. **`docs.config.ts` `nav` is the curated source of truth.** When present, it drives the human sidebar/top-level docs structure and the agent-facing map: generated navigation, `llms.txt`, `AGENTS.md`, sitemap markdown, and Agent Readability navigation all use the resolved `nav` tree.

   A page's frontmatter `group` is legacy taxonomy metadata. It is still useful for projects that have not adopted `nav` yet, where Leadtype can fall back to group-based navigation. It can also remain as broad taxonomy/search/filter metadata or compatibility data, but it should not be treated as the place to curate sidebar placement once `nav` exists.

2. **Unknown legacy groups fail the build.** If a page declares a `group` slug that is not known by the loaded config's legacy `groups`, Leadtype fails fast during generation/navigation validation with an error like:

   ```text
   /docs/some-page declares unknown group "some-slug"
   ```

   It does not silently create a new section or drop the page into that group; the mismatch is treated as a content/config bug so navigation and agent artifacts cannot drift.
