# Nav vs. `group` — Onboarding Notes

## 1. `nav` vs. `group`: which drives the sidebar and agent map?

**`nav` in `docs.config.ts` drives everything.**

When `nav` is present, it is the source of truth for:
- Sidebar structure
- Top-level docs areas (tabs)
- `llms.txt` sections
- `AGENTS.md` grouping
- Sitemap markdown and Agent Readability navigation
- Search metadata

**`group` frontmatter is legacy taxonomy metadata.** It is still valid, but it is no longer the best place to express polished navigation. It remains useful for:
- **Fallback navigation** in projects that have not yet adopted `nav`
- **Search facets** and broad taxonomy filtering
- **Compatibility/metadata** (e.g., marking a page as belonging to a conceptual category)

In short: put intentional navigation in `nav`; keep `group` only as taxonomy/compatibility metadata.

## 2. What happens at build time if a page declares an unknown `group`?

The build **fails**.

During `leadtype generate` (or when `resolveDocsNavigation` runs), the pipeline validates every page's `group` against the slugs known to the config. If a page declares a `group` slug that the config does not recognize, the run exits with an error like:

```
error: /docs/<path> declares unknown group "<slug>".
```

This is intentional: broken navigation is treated as a content bug, not a render-time problem. The CLI returns exit code `1` (runtime error), so unknown groups will fail CI if you run `leadtype generate` or `leadtype lint` there.
