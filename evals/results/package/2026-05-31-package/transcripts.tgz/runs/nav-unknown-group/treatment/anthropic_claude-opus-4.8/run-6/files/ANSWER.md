# Leadtype navigation: `nav` vs. legacy `group`

## 1. `nav` in `docs.config.ts` vs. a page's legacy `group` frontmatter

**The curated `nav` in `docs.config.ts` is the source of truth that drives navigation.** When a project has adopted `nav`, that one resolved tree drives all the human- and agent-facing surfaces at once:

- the top-level docs areas / tabs (e.g. Docs, Frontend, Integrations, Changelog),
- the sidebar structure and ordering,
- generated `llms.txt` sections,
- the agent map in `AGENTS.md`,
- the sitemap markdown, and
- the Agent Readability navigation metadata.

`nav` is intentional, config-owned navigation: you pin important entry points with explicit page strings (`quickstart`, `installation`, etc.), reuse folder prefixes with `base`, build nested sections with `children`, and sweep up the rest with `{ include: "folder/*", sort: ["order", "path"] }`. Because everything reads from this single resolved tree, the sidebar and the agent map stay aligned — "same source of truth, no drift."

**The `group` frontmatter field is legacy taxonomy / compatibility metadata.** It is still valid, but it's no longer the place to express polished navigation. Once you've moved to `nav`, `group` remains useful for:

- **Legacy navigation fallback** — if a project has *not* adopted `nav`, the CLI falls back to a legacy group resolver. It infers the navigation tree, `llms.txt` section headings, search metadata, and `AGENTS.md` grouping from the `group:` values it finds (intersected with the `groups` declared in `docs.config.ts`). This fallback is fine for small docs sets, but you want `nav` once you need stable top-level areas, sidebar order, descriptions, nested sections, or wildcard includes.
- **Search facets and broad taxonomy** — a page can declare one or more group slugs (`group: <slug>` or `group: [a, b]`), so a page can belong to several taxonomy groups and be surfaced across search facets even when `nav` owns its actual placement.

In short: **`nav` drives the sidebar and the agent map; `group` is kept around for the legacy/no-`nav` navigation fallback plus search facets and general taxonomy.** (Related: `order` is similarly retained only as a fallback sort for pages pulled in by `include`.)

## 2. What happens at build time when a page declares an unknown `group` slug?

**The build fails.** If a page declares a `group` slug that is not declared in `docs.config.ts`, the build errors out with:

```
unknown group "<slug>"
```

The config is the single source of truth for valid group slugs (declared in the `groups` list, where non-leaf groups are headings only and pages attach to leaf groups). Because group resolution is validated against that config, an unrecognized slug is rejected rather than silently creating a phantom group — which is what keeps the human and agent navigation surfaces from drifting apart.

To fix it, either add the slug to the `groups` definition in `docs.config.ts` (declaring its `title`, and nesting under `children` if needed) or correct the `group` value on the page to an existing slug.
