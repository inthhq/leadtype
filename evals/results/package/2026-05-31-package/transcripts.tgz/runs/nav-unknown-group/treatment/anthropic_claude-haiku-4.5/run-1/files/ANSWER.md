# Navigation in Leadtype: `nav` Config vs Legacy `group` Frontmatter

## 1. The Relationship Between `nav` Config and `group` Frontmatter

### Which One Drives Sidebar and Agent Map?

**The `nav` in `docs.config.ts` is the primary driver** for the sidebar, generated navigation, agent artifacts, and all curated navigation surfaces.

**The `group` frontmatter field is legacy taxonomy metadata.**

### How They Work Together

```
docs.config.ts (nav)
       ↓
    [drives]
       ↓
• Top-level docs areas (sidebar structure)
• Agent-readable maps (llms.txt structure)
• AGENTS.md organization
• Sitemap markdown
• Agent Readability navigation metadata
```

The `nav` config is the source of truth for **intentional, polished navigation** — it defines top-level tabs, sidebar hierarchy, section headings, and page ordering. It's meant for curated site structure.

### What Is `group` Still Good For?

The `group` frontmatter field persists for **three purposes**:

1. **Taxonomy/Compatibility Metadata**: Mark a page as belonging to certain categories (`group: [authoring, reference]`) for search faceting, filtering, or internal classification.

2. **Legacy Navigation Fallback**: In projects that have not yet adopted `nav`, the group resolver can infer a fallback navigation tree. If you don't define `nav` in `docs.config.ts`, leadtype will auto-detect groups from pages' `group:` frontmatter values and build navigation from that.

3. **Broad Classification**: Keep a page's broad category when specific sidebar placement is different or when it needs to appear in multiple conceptual groupings.

### The Mental Model

Think of it as:
- **`nav`** = the polished, curated site structure (what you _want_ people to see)
- **`group`** = optional taxonomy tags (what pages belong to conceptually)

Once you adopt `nav`, treat `group` as annotation-only—it doesn't change what the sidebar or agent maps look like. Only `nav` does that.

---

## 2. Build-Time Behavior: Unknown Groups

### What Happens If a Page Declares an Unknown Group Slug

**The build fails with an error:**

```
unknown group "<slug>"
```

This is by design—it enforces a single source of truth.

### The Rule

- Every group slug that appears in a page's frontmatter (`group: my-slug`) **must** be declared in `docs.config.ts`.
- Leadtype loads the config automatically when it exists.
- If a page's `group:` value doesn't match any slug in the config's `groups` array, generation stops with an error.

### Why

This prevents accidental typos, drift between frontmatter and config, and orphaned pages. The error is **strict validation**—it's telling you:

> "You said this page belongs to group `<slug>`, but I don't know what that group is. Either add it to the config, or fix the typo in the page's frontmatter."

### Example

If your `docs.config.ts` defines:

```ts
groups: ["docs-site", "reference"]
```

And a page declares:

```yaml
---
group: "authroing"  # typo!
---
```

The build fails immediately: `unknown group "authroing"`. You'll catch it before it reaches production.

### Config-to-Group Relationship

```mermaid
flowchart LR
    cfg["docs.config.ts<br/>groups: [authoring, reference]"]
    page["page frontmatter<br/>group: authoring"]
    resolver["build-time resolver"]
    check{"matches?"}
    
    cfg --> resolver
    page --> resolver
    resolver --> check
    check -->|yes| nav["✓ navigation tree built"]
    check -->|no| error["✗ build error:<br/>unknown group"]
```

---

## Summary

| Aspect | `nav` in `docs.config.ts` | `group` in frontmatter |
|--------|--------------------------|----------------------|
| **Drives sidebar?** | ✓ Yes | ✗ No (legacy) |
| **Drives agent maps (llms.txt, AGENTS.md)?** | ✓ Yes | ✗ No |
| **Purpose** | Curated, intentional site structure | Taxonomy tags & legacy fallback |
| **Required?** | ✓ For modern projects | ✗ Optional |
| **Unknown values at build?** | Fails build with error | Fails build with error |

Adopt `nav` for new or migrated docs. Keep `group` only for taxonomy and backwards compatibility.
