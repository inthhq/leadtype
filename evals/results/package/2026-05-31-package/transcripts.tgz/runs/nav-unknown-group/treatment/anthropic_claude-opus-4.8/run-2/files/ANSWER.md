# Navigation in leadtype: `nav` vs. `group`

Answers based on the bundled package docs (`node_modules/leadtype/docs/authoring/frontmatter.md`
and `docs/changelog/nav-migration-prompts.md`).

## 1. Relationship between curated `nav` and a page's legacy `group`

**Curated `nav` in `docs.config.ts` is the source of truth and drives both the sidebar and the agent map.** The legacy `group` frontmatter field is now demoted to taxonomy/compatibility metadata.

- **`nav` (config-owned) is what drives navigation.** You describe the navigation tree directly in `docs.config.ts` via the `nav` array. Root nodes become top-level docs areas / tabs (e.g. Docs, Frontend, Integrations, Changelog), and the active root's pages and children become the sidebar. Critically, **the same resolved `nav` tree drives every surface**: generated site navigation, the human sidebar, `llms.txt` sections, `AGENTS.md` grouping, sitemap markdown, and the Agent Readability navigation metadata. So `nav` is the single thing that keeps the human sidebar and the agent-facing document map aligned. It's also what you reach for when you need stable top-level docs areas, explicit sidebar ordering, descriptions, nested sections, or wildcard `include` entries.

- **`group` (frontmatter) is the "other" — still useful, but not the driver.** A page may declare one or more group slugs (`group: <slug>` or `group: [a, b]`), letting a page belong to multiple taxonomy groups. It remains good for:
  - **Search facets / broad taxonomy** — categorizing pages for search and filtering.
  - **Legacy navigation fallback** — *if a project has no `nav`*, the CLI falls back to the legacy group resolver: it infers groups from the `group:` values it finds, intersects them with the groups declared in `docs.config.ts`, and produces a fallback nav tree plus `llms.txt`/`AGENTS.md` sections. This fallback is fine for small docs sets but lacks the ordering, nesting, descriptions, and wildcard includes that `nav` provides.

In short: when `nav` exists it owns navigation and the agent map; `group` then survives purely as taxonomy/compatibility metadata (and as the fallback mechanism for projects that haven't adopted `nav` yet).

## 2. What happens at build time with an unknown `group` slug?

**The build fails.** If a page declares a `group` slug that is not declared in `docs.config.ts`, `leadtype generate` errors out with:

```
unknown group "<slug>"
```

`leadtype generate` loads `docs.config.ts` automatically when it exists, and the group resolver requires every page's group slug to be a known, config-declared group. This enforces a single source of truth so the config and page frontmatter can't drift apart — an undeclared slug is treated as an error rather than silently creating a new group. (You can also catch this earlier in CI via `leadtype lint`, which validates navigation/frontmatter before a build runs.)
