# Navigation and Group Frontmatter in Leadtype

## 1. Relationship between `nav` in `docs.config.ts` and legacy `group` frontmatter

* **What drives the sidebar and agent map?**
  The curated **`nav` field in `docs.config.ts`** is the modern source of truth that drives the sidebar, sitemap markdown, sitemap XML, `llms.txt` sections, `AGENTS.md` sections, and Agent Readability metadata (`agent-readability.json`). 

* **The relationship between `nav` and `group`:**
  Historically, the legacy `group` frontmatter was used alongside a simple `groups` list in `docs.config.ts` to automatically generate the navigation tree. `nav` represents a transition to a more powerful, curated product navigation structure (allowing nested sidebars, wildcard includes, stable order, etc.) defined in config rather than distributed in page frontmatter.

* **What `group` is still good for:**
  The legacy `group` frontmatter remains useful for several purposes:
  - **Fallback navigation**: For smaller projects or documentation collections that have not migrated to config-owned `nav`, the build system will fall back to resolving group navigation from the union of page `group` declarations.
  - **Search facets and broad taxonomy**: Filtering and categorizing search results based on taxonomy groups.
  - **Taxonomy metadata**: Retaining compatibility metadata for search indexes and downstream tools.

---

## 2. Build-time behavior when a page declares an unknown `group` slug

If a page declares a `group` slug that is not defined in the loaded configuration file (`docs.config.ts` or `leadtype.config.*`):
* **The build fails noisily and immediately**: The build/generation pipeline (`leadtype generate`) stops execution and exits with an exit code of `1` (runtime error).
* **An error message is outputted**: It writes a clear error message to `stderr`, specifying the page and the unknown group slug: 
  `error: <urlPath> declares unknown group "<slug>".`
* **Why it does this**: This is a fail-fast design to prevent navigation drift, broken links, or invalid taxonomies from shipping to production. Broken navigation is treated as a content bug rather than a render-time problem.
