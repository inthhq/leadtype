# Navigation: `nav` vs. legacy `group`

## 1. Which drives the sidebar and agent map, and what is the other still good for?

- **`docs.config.ts` `nav`** is the curated, config-owned navigation tree. It drives the sidebar, the agent map, `llms.txt` sections, `AGENTS.md`, sitemap markdown, and Agent Readability navigation.
- **Frontmatter `group`** is legacy taxonomy metadata. It is no longer the source of truth for curated structure, but it remains useful for:
  - **Fallback navigation** – when a project has not yet adopted `nav`, the CLI falls back to the legacy group resolver (inferring groups from the `group:` values it finds).
  - **Search facets** – group slugs can still filter or classify pages in search.
  - **Broad taxonomy / compatibility metadata** – labeling pages with shared categories without controlling their place in a curated nav tree.

## 2. What happens at build time if a page declares a `group` slug that the config doesn't know about?

The build **fails**.

During `leadtype generate`, the pipeline resolves groups from frontmatter and validates that every page's `group:` matches a known slug declared in the loaded config (either in `groups` or via the `nav` tree). If a page names an unknown group, generation stops with exit code `1` and an error like:

```
<urlPath> declares unknown group "<slug>"
```

This is intentional: broken navigation is treated as a content bug, not a render-time problem, so it surfaces at build time rather than silently producing a broken sidebar or agent map.
