# Navigation in leadtype: `nav` vs. `group`

## 1. Relationship between curated `nav` and the legacy `group` frontmatter field

**The curated `nav` in `docs.config.ts` is the source of truth for navigation.** It is
what drives both the human-facing sidebar and the agent-facing document map. The
`group` frontmatter field is legacy taxonomy/compatibility metadata that is *not* the
recommended way to express curated navigation anymore.

### What `nav` drives

When a project adopts config-owned `nav`, a single resolved tree feeds every
navigation surface — human and agent — so they can't drift apart:

- Top-level docs areas / top tabs (e.g. Docs, Frontend, Integrations, Changelog) from root nav nodes.
- The sidebar structure and ordering (the active root node's pages and children).
- `llms.txt` (including its nested section headings).
- `AGENTS.md`.
- Sitemap markdown.
- Agent Readability navigation metadata (the "agent map").

`nav` lets you express things `group` can't: stable top-level docs areas, explicit
sidebar order, descriptions, nested sections, and wildcard `{ include }` entries with
`order`-then-path sorting.

### What `group` is still good for

`group` remains valid and useful as taxonomy/compatibility metadata, specifically for:

- **Legacy navigation fallback** — if a project has *not* adopted `nav`, the CLI falls
  back to the legacy group resolver and infers the nav tree (plus `llms.txt` sections
  and `AGENTS.md` grouping) from the `group:` values it finds, intersected with the
  groups declared in `docs.config.ts`. This fallback is fine for small docs sets.
- **Search facets / broad taxonomy** — a page can belong to multiple group slugs
  (`group: [a, b]`), which is handy for categorizing/searching even when curated
  placement lives in `nav`.

In short: **`nav` drives the sidebar and the agent map; `group` is for the legacy
fallback nav, search facets, and broad taxonomy.** (`order` similarly stays useful as
the fallback sort for pages pulled in via `include`.)

## 2. What happens if a page declares a `group` slug the config doesn't know about

**The build fails.** If a page declares a `group` slug that isn't defined in
`docs.config.ts`, leadtype errors out with:

```
unknown group "<slug>"
```

This is intentional: groups must be declared once in the config, so the config and page
frontmatter share a single source of truth and the navigation can't silently drift. Note
that only **leaf** groups (those with no children) directly contain pages — non-leaf
groups in the config are headings only.
