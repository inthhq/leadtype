# Answers to Leadtype Navigation Questions

## 1. Relationship Between Config `nav` and Legacy Frontmatter `group`

### Which one drives the sidebar and agent map?
The curated config-owned **`nav`** defined in `docs.config.ts` drives the sidebar structure, sitemap markdown, Agent Readability navigation, top-level tabs/areas, and the agent map (including `llms.txt`, `AGENTS.md` sections, and metadata).

### Relationship
- **`nav`** is the modern, centralized, and preferred way to organize documentation. It defines the structured hierarchy directly in the configuration file, allowing for nested directories, descriptions, precise page ordering, and wildcard includes.
- **`group`** is a legacy, page-level YAML frontmatter field. In older setups, navigation was inferred by mapping these page-level group slugs to a top-level `groups` array in `docs.config.ts`.

### What `group` is still good for
Even in projects that have adopted the modern `nav` API, the `group` frontmatter field remains useful for:
1. **Fallback Navigation:** Serving as the navigation/section resolver for smaller docs or legacy projects that have not yet migrated to the `nav` format.
2. **Search Facets & Filtering:** Serving as broad taxonomy/metadata for search engines to categorize, index, and filter pages.
3. **Broad Taxonomy/Compatibility Metadata:** Categorizing articles for broad programmatic grouping or third-party integrations (e.g., populating Schema.org `articleSection` properties in JSON-LD).

---

## 2. Build-Time Behavior for Unknown `group` Slugs

If a page declares a `group` slug in its frontmatter that is not defined/known in the loaded config:

1. **The Build Fails Fast and Noisily:** The generation/build process fails immediately with an exit code of `1` (Runtime Error). 
2. **Error Message:** It logs a clear error message to standard error, such as:
   ```
   error: <urlPath> declares unknown group "<slug>".
   ```
3. **Rationale:** This strict failure is by design. Leadtype treats broken navigation or drift between content frontmatter and configuration as a high-priority content bug rather than a minor render-time layout problem, ensuring broken links or misplaced pages never reach production or AI agents.
