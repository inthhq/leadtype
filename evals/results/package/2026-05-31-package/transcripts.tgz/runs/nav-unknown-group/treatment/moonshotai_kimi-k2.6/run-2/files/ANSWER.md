# Navigation: `nav` vs. legacy `group`

## 1. Which drives the sidebar and agent map, and what is the other still good for?

- **`nav` in `docs.config.ts` drives the sidebar and agent map.**  
  It is the curated source of truth for top-level docs areas, sidebar structure, `llms.txt` sections, `AGENTS.md` grouping, sitemap markdown, and Agent Readability navigation.

- **`group` frontmatter is legacy taxonomy metadata.**  
  In projects that have **not** adopted `nav`, Leadtype falls back to the legacy group resolver and builds the navigation tree from the `group` values it finds in page frontmatter. When `nav` is present, `group` remains useful for:
  - fallback navigation (if you ever drop `nav`)
  - search facets
  - broad taxonomy / compatibility metadata

## 2. What happens at build time if a page declares a `group` slug the config doesn't know about?

The build **fails** with an error such as:

```
unknown group "<slug>"
```

During generation, Leadtype resolves groups from frontmatter and validates that every page's `group` matches a known slug defined in the config. An unknown group is treated as a content bug by design, not a render-time problem.
