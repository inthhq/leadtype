# Leadtype Navigation and Grouping

Below are the answers to your questions regarding navigation in a Leadtype project.

---

### 1. Curated `nav` vs. Legacy `group` frontmatter

#### Which one drives the sidebar and agent map?
* **Curated `nav` in `docs.config.ts`** is the modern, preferred way to define the information architecture. It directly drives:
  - The human-facing sidebar and top-level navigation tabs.
  - The agent-facing document map (including `llms.txt` sections, `AGENTS.md` group listings, and Agent Readability metadata like `agent-readability.json`).

#### What is the other still good for?
The legacy page-level **`group` frontmatter field** is still useful for:
* **Taxonomy and broad categorization:** Organizing pages for search facets, filtering, and content tagging.
* **Fallback navigation:** Maintaining compatibility and providing navigation structure for projects that have not yet migrated to or adopted the config-owned `nav` API.
* **Wildcard Sorting:** Functioning as metadata for ordering and inclusion rules when combined with `{ include: "folder/*", sort: ["order", "path"] }`.

---

### 2. Build-Time Behavior for Unknown `group` Slugs

If a page declares a `group` slug in its frontmatter that the config doesn't know about:
* **The build fails noisily.** The generation process halts and exits with an error such as:
  ```
  error: <urlPath> declares unknown group "<slug>"
  ```
* **Why this happens:** This fail-fast behavior is by design. Leadtype treats broken navigation as a critical **content bug** rather than a render-time warning. Failing the build ensures that bad configs or drift between content files and navigation schemas are caught in CI before shipping to production.
