# Navigation in Leadtype: `nav` vs `group`

## 1. The Relationship Between `nav` in `docs.config.ts` and `group` Frontmatter

### Which One Drives the Sidebar and Agent Map?

**The curated `nav` in `docs.config.ts` is the primary driver** of the sidebar, agent map, and all navigation outputs.

When a project has defined `nav` in its config, it takes precedence and controls:
- **Sidebar structure** — the order and hierarchy of pages displayed to humans
- **Agent map** — the navigation tree used in `llms.txt`, `AGENTS.md`, and Agent Readability metadata
- **Sitemap structure** — how generated markdown mirrors are organized
- **Top-level docs areas** — root nodes in `nav` can become top-level tabs (Docs, Frontend, Integrations, etc.)

### What Is the `group` Field Still Good For?

The `group` frontmatter field now serves as **taxonomy and compatibility metadata**:
- **Compatibility/tagging** — marks pages for cross-cutting concerns (e.g., `group: ["framework-react", "advanced"]`)
- **Legacy fallback** — in projects without `nav` defined, groups are inferred from page frontmatter
- **Search facets** — can be used to enable filtering by group in search results
- **Broad taxonomy** — provides backward compatibility for docs sites migrating from the old system

### The Key Mental Model

```
docs.config.ts nav
    ↓
[drives sidebar, agent map, llms.txt, AGENTS.md, Agent Readability]

page frontmatter group
    ↓
[taxonomy metadata, legacy fallback, search facets, broad categorization]
```

**New projects should use config-owned `nav` for intentional navigation.** Only use `group` as supplementary taxonomy when needed.

---

## 2. What Happens at Build Time If a Page Declares an Unknown `group`?

**The build fails with an error: `unknown group "<slug>"`**

### The Validation Rule

If a page declares a `group` slug that isn't defined in `docs.config.ts`, the `leadtype generate` or `leadtype lint` command exits with a schema validation error.

This is intentional: **same source of truth, no drift.** All group slugs referenced in page frontmatter must be declared in the config, preventing silent bugs where:
- A typo in a page's `group` value goes unnoticed
- Navigation inconsistencies accumulate as the docs grow
- Agents receive incomplete or mismatched navigation metadata

### How to Avoid This

1. **Define all groups in `docs.config.ts`** — List every `slug` that pages will reference:
   ```ts
   groups: [
     { slug: "authoring", title: "Authoring" },
     { slug: "docs-site", title: "Build an Agent-Ready Site" },
     { slug: "reference", title: "Reference" },
   ]
   ```

2. **Or migrate to config-owned `nav`** — Don't use `group` at all; define all navigation structure in `docs.config.ts` with `nav` instead. This is the recommended approach for new projects and provides stricter organization.

3. **Run `leadtype lint` in CI** — Catch group validation errors before they reach production:
   ```bash
   leadtype lint
   ```

---

## Summary

- **`nav` in `docs.config.ts`**: Primary driver of sidebar, agent map, and all navigation outputs for curated docs sites.
- **`group` in frontmatter**: Legacy taxonomy metadata; still valid for compatibility but no longer the source of truth for navigation structure.
- **Unknown `group` at build**: Causes the build to fail with `unknown group "<slug>"` — encouraging consistency between frontmatter and config.
