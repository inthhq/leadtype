# Navigation System: `nav` vs `group`

## Question 1: Relationship between curated `nav` and legacy `group` frontmatter

### Which drives sidebar and agent map?

**The `nav` in `docs.config.ts` drives the sidebar and agent map.**

The curated `nav` array is the **primary source of truth** for navigation structure. It determines:
- The sidebar order and structure
- The top-level docs areas (e.g., Docs, Frontend, Integrations, Changelog)
- Generated navigation for `llms.txt`
- The agent map for `AGENTS.md`
- Sitemap markdown and Agent Readability metadata

### What is `group` still good for?

**The legacy `group` frontmatter field remains valid for:**
- **Taxonomy and compatibility metadata** — pages can declare which semantic groups they belong to
- **Search facets** — filtering documents by broader categories
- **Backward compatibility** — existing pages with `group` fields continue to work
- **Fallback navigation** (if `nav` is not defined) — in small docs sets without a `nav` config, leadtype falls back to inferring groups from page `group:` values

### The Design Model

When a `nav` config exists, it takes precedence. The `group` field becomes auxiliary metadata rather than the navigation source. This separation allows:
- **Intentional, curated navigation** via `nav` — reflecting product UX and desired docs structure
- **Flexible page taxonomy** via `group` — pages can belong to multiple groups for search and metadata purposes
- **Same output surfaces** — both resolved nav trees drive the sidebar, `llms.txt`, and `AGENTS.md` consistently

---

## Question 2: Build-time behavior for unknown group slugs

### What happens if a page declares a `group` that the config doesn't know about?

**The build fails with an error:** `unknown group "<slug>"`

This is a validation error from the lint system. Here's why:

- When a page declares `group: some-slug` in its frontmatter, leadtype expects that slug to be defined somewhere in the config (specifically in `docs.config.ts`).
- If the slug doesn't exist in the `groups` array of the config, the CLI/build raises an error.
- **The error forces you to maintain a single source of truth:** declared groups must be registered in the config.

### How this enforces consistency

This strict validation prevents:
- Typos in group names spreading silently through the codebase
- Pages mapping to "groups" that don't actually exist in your navigation structure
- Drift between the docs config and the pages that claim to belong to configured groups

The lint rule that catches this is `leadtype lint` with its frontmatter schema validation. You can run it in CI to fail PRs before they reach a build.
