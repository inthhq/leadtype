# What `--enrich-git` Does

The `--enrich-git` flag on `leadtype generate` automatically adds two frontmatter fields to pages from git history: `lastModified` (the timestamp of the last commit that changed the file) and `lastAuthor` (the author of that last commit). These fields are extracted from the git repository's history and populated into the frontmatter of each generated page, allowing your documentation site to display when pages were last updated and by whom without requiring manual authoring of these values.
