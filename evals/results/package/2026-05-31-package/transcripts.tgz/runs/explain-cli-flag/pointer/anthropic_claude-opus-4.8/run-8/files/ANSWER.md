# What `--enrich-git` does on `leadtype generate`

The `--enrich-git` flag (off by default) tells `leadtype generate` to add two
frontmatter fields—`lastModified` and `lastAuthor`—to each converted document,
deriving them from the source file's git history rather than from hand-authored
frontmatter. During the MDX-to-Markdown conversion step, for every source file
LeadType runs `git log -1 --format=%aI%x00%an -- <file>` (executed with the
file's own directory as the working directory). The most recent commit's
author-date (`%aI`, an ISO-8601 timestamp) becomes `lastModified`, and the
commit's author name (`%an`) becomes `lastAuthor`; these are then merged into
the document's existing frontmatter (overriding any same-named keys). The
enrichment is best-effort and silently skipped when git is unavailable, when the
file is untracked, or when the file wasn't touched in the available history
(e.g. a shallow `--depth 1` remote clone returns an empty log), in which case
neither field is added. Because these two fields are produced automatically,
they are intentionally excluded from the lint schema and should never be
authored by hand—the linter flags a source-authored `lastModified` as an
unknown field.
