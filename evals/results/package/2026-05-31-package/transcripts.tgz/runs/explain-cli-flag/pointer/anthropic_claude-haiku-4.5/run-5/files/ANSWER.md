# The `--enrich-git` Flag

The `--enrich-git` flag on `leadtype generate` automatically adds two frontmatter fields, `lastModified` and `lastAuthor`, to every generated page by extracting the information from git history. These fields are populated from the most recent commit that modified each file, allowing you to track when a page was last updated and who made that update without manually authoring them into the YAML frontmatter of your documentation files.
