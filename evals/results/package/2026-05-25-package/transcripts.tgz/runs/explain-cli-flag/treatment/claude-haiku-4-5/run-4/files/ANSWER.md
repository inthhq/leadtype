# The `--enrich-git` Flag

The `--enrich-git` flag on `leadtype generate` automatically enriches the frontmatter of generated documents by adding two fields sourced from git history: `lastModified` and `lastAuthor`. When this flag is enabled, leadtype inspects the git repository's commit history to populate these frontmatter fields for each page, allowing generated documentation to display when a page was last updated and which author made the most recent change. These fields are filled in automatically and should not be authored by hand.
