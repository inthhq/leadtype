# Leadtype Docs Search — What It Provides

## 1. What Leadtype Provides by Default

Leadtype builds a **static, edge-safe search index using BM25 ranking** — no database required.

### The Default Approach

- **Build time**: Converts your MDX docs to markdown, then generates two compact JSON files:
  - `search-index.json` — The inverted index with BM25-ranked term postings and document references (keeps the index small for every query)
  - `search-content.json` — The actual chunk text, fetched lazily for excerpts and answers
- **Runtime**: The browser or edge worker imports/fetches these files and queries them locally, with no remote calls
- **Chunking**: Heading-aware slicing so results link to exact sections, not entire pages
- **Ranking signals**: Titles get 4× weight, headings 2×, body 1×, code 0.35× (tunable)
- **Query features**: Lexical matching + lightweight stemming + prefix matches + typo-tolerant fallbacks + a built-in synonym map
- **Optional AI answers**: Can stream source-grounded answers via provider adapters (Vercel, TanStack, Cloudflare) that retrieve chunks and pass them to any LLM with a constrained prompt

## 2. When to Add Embeddings — and What to Keep

### Conditions That Warrant Adding Embeddings

Only adopt embeddings (and a hosted vector database) when **both** of these are true:

1. **Users search with vocabulary that doesn't match your docs**
   - Example: Users type "make it faster" but your docs say "performance optimization"
   - The lexical index cannot bridge this vocabulary gap

2. **Your docs exceed tens of thousands of chunks**
   - The cold-start memory hit of loading the BM25 index becomes material
   - At smaller scales, the static index is cheap and fast

### What You Must Keep Even With Embeddings

**Never replace the lexical index.** Instead, layer embeddings on top:

- **Exact API names, config keys, error messages, and paths** must stay precise — these are lexical matches and BM25 handles them well
- Use embeddings to *supplement* lexical results for semantic similarity on conceptual searches
- Keep both search paths: exact matches from BM25 + semantic matches from embeddings; let users see results from both
- The two approaches are **complementary, not replacements**

### The Architecture for Hybrid Search

1. Generate and serve the static `search-index.json` and `search-content.json` as always
2. Build or connect to a vector store (local embeddings or hosted service)
3. Query the static BM25 index for exact matches
4. Query the vector store for semantic matches
5. Merge and rank results, or display both sets to the user

This gives you:
- **Zero database latency** for exact queries (API names, config keys)
- **Semantic coverage** for natural language questions
- **Offline-safe** fallback (the static index works without the vector DB)
- **Cost control** (embed expensive features only when needed)
