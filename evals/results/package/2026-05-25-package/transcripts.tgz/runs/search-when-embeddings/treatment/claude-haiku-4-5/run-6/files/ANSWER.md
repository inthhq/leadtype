# Leadtype Docs Search: What You Already Get

## 1. What Leadtype Uses by Default

Leadtype's docs search uses **BM25 lexical ranking** with a **static, edge-safe search index** — no database required.

### The Default Tech Stack

- **Index Format**: BM25 ranking function applied at build time, generating two JSON files:
  - `search-index.json` — compact term postings and document references (loaded on every search)
  - `search-content.json` — actual chunk text for excerpts and context (loaded lazily on result hover or answer generation)
  
- **Query Expansion**: Beyond exact token matching, the search includes:
  - Lightweight stemming
  - Prefix matching
  - Typo-tolerant fallbacks
  - Small built-in synonym map (extensible with product-specific aliases)

- **Chunking Strategy**: Markdown is split at heading boundaries so results jump to the right section, not just the right page.

- **Ranking Weights**: Tunable per-field weights — titles get 4× boost, headings 2×, body 1×, code 0.35×.

- **Query Processing**: Runtime validation, trimming, capping, and rate limiting via helpers like `validateDocsQuery`, `readJsonWithLimit`, and `createMemoryRateLimiter`.

### Why This Matters

The default index is:
- **Static** — generated at build time, no server-side indexing needed
- **Edge-safe** — runs anywhere (Vercel, Cloudflare, browsers, Node)
- **Zero-dependency** — pure JavaScript, no external services
- **Fast** — binary search on small, compressed JSON files
- **Cheap** — minimal bandwidth and compute

Exact API names, config keys, error messages, and documentation paths work extremely well out of the box.

---

## 2. When to Add Embeddings (And What to Keep)

### Conditions That Warrant Embeddings

Add embeddings **only** when your docs exhibit one or both of these patterns:

1. **Vocabulary mismatch**: Users search with terms your docs don't explicitly use.
   - Example: Users say "make it faster" but your docs say "performance optimization"
   
2. **Corpus scale**: You have tens of thousands of chunks and cold-start memory overhead becomes noticeable during queries.

### What You Must Keep Even With Embeddings

**Do not replace the lexical index.** Instead, layer embeddings on top:

- Keep BM25 for **exact matches** — API names, config keys, error messages, and code identifiers must remain precise and unambiguous
- Keep the static JSON files — they're complementary strengths:
  - Use BM25 first for keyword-driven queries (what developers actually search)
  - Use embeddings to catch semantic mismatches and improve recall on paraphrased queries
  - Let both signals influence ranking, but privilege exact matches

### Implementation Implications

Even when adding embeddings:
- Maintain the build-time generation pipeline for `search-index.json` and `search-content.json`
- Do not move indexing to runtime or add a database dependency
- Hybrid search (BM25 + embeddings with deduplication and reranking) still keeps search edge-safe
- The content store remains your source of truth for all retrieval

**In short**: The static lexical index scales further and performs better than your intuition suggests. Embeddings are an accelerator for specific use cases, not a replacement.
