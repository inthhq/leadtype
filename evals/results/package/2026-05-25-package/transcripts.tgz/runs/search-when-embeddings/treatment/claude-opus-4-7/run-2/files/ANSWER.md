# Docs search with `leadtype`: what we already have, and when embeddings matter

Before we stand up a hosted, DB-backed vector index, here is what `leadtype` already provides out of the box and what the package's own docs say about when to layer embeddings on top. Sources: `node_modules/leadtype/docs/reference/search.md` and `node_modules/leadtype/docs/build/add-search.md`.

## 1. What leadtype's docs search uses by default

**A static, edge-safe, lexical index built at build time. No database. No embeddings. No external service.**

Concretely, `leadtype generate` (or `generateDocsSearchFiles` from `leadtype/search/node`) produces two JSON files alongside the rest of the site output:

- `public/docs/search-index.json` — compact tuple-format index with term postings, document refs, and chunk refs. Loaded on every search.
- `public/docs/search-content.json` — the actual chunk text, separated so you can search first and only load content for excerpts, hovers, or answers.

How the index is structured and ranked:

- **Chunks, not pages.** Each chunk is a heading-aware slice of a page, so results jump to the right section (with hash URLs), not just the right document.
- **BM25 ranking** with tunable field weights: title 4×, headings 2×, body 1×, code 0.35×.
- **Lexical matching with smart fallbacks**: stemming, prefix matching, typo-tolerant fallbacks, and a small built-in synonym map. Exact matches keep the highest weight so API names and config keys stay precise.
- **Per-product synonyms** can be passed at query time via the `synonyms` option — no rebuild required.

At runtime you call `searchDocs(index, query, { content })` from `leadtype/search`. The runtime is dependency-free and uses no Node APIs, so it works on Vercel, Cloudflare Workers, or any edge runtime. The same files double as a virtual filesystem (`listDocsContentFiles`, `readDocsContentFile`, `readDocsContentChunk`) and as the retrieval layer for optional source-grounded AI answers via `createAnswerContext` / `streamDocsAnswer` (Vercel, TanStack, or Cloudflare provider entry points).

For request-path safety, the package also ships `validateDocsQuery`, `readJsonWithLimit`, `getClientIdentifier`, and `createMemoryRateLimiter` (swap for Redis/KV/Durable Objects in production).

**Net result:** two JSON files served as static assets give us chunk-aware, BM25-ranked, typo-tolerant, edge-safe search with optional grounded answers — with zero infrastructure to operate.

## 2. When adding embeddings is actually warranted

The leadtype docs are explicit: **start with the local lexical index.** It is "static, cheap, edge-safe, and fast for exact API names, config keys, error messages, and paths" — exactly the queries that dominate docs search.

Per `docs/reference/search.md` ("When to add embeddings"), add embeddings **only when** one of these is true:

1. **Vocabulary mismatch.** Users search with words our docs do not use, and synonym aliases aren't enough to bridge the gap. The canonical example from the docs: a query like *"make it faster"* needs to match a *"performance optimization"* page.
2. **Scale.** Docs grow past **tens of thousands of chunks** and the cold-start memory hit of loading `search-index.json` becomes noticeable.

**What to keep even then:** the lexical index. The docs are direct about this:

> Even then, keep the lexical index for exact matches and layer embeddings on top — they're complementary, not replacements.

Embeddings are weak at exact-token retrieval (API names, config keys, error strings, file paths) — the very things BM25 nails. So the supported architecture is *lexical first, embeddings layered on for semantic recall*, not lexical replaced by a vector DB.

## Recommendation

Before commissioning a hosted vector index:

- Ship `leadtype generate` output and wire `searchDocs` into the UI. This is essentially free.
- If users hit vocabulary-mismatch problems, try the `synonyms` option first — it's a config change, not infrastructure.
- Only if (1) synonyms can't close the gap or (2) we cross the tens-of-thousands-of-chunks threshold should we add embeddings — and even then, as a **second pass on top of** the leadtype lexical index, not a replacement for it.

A hosted DB-backed vector index as the *default* RAG layer is not what the leadtype pipeline expects, and adopting it preemptively would mean operating infrastructure we don't yet need and losing exact-token precision we currently get for free.
