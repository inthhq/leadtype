# What Leadtype Already Gives Us for Docs Search

## 1. Default docs search

Leadtype does **not** default to a hosted, database-backed vector index.

By default, Leadtype builds a **static, edge-safe lexical search index** at build time:

- `public/docs/search-index.json` — compact ranking/index data
- `public/docs/search-content.json` — the chunk text used for snippets and answer context

The runtime imports or fetches those JSON files and queries them **without a database**. The index is a BM25-ranked inverted index over heading-aware chunks, so results can point to a specific section rather than only a whole page.

Leadtype's default ranking is lexical/BM25, with weighted fields:

- titles: `4x`
- headings: `2x`
- body: `1x`
- code: `0.35x`

It is not just exact-token matching. The runtime also includes lightweight stemming, prefix matches, typo-tolerant fallbacks, and a small built-in synonym map. Product-specific synonyms can be added when users search with terms the docs do not use.

Leadtype can also provide optional source-grounded AI answers, but those layer on top of the same static search/content files: it retrieves chunks from the local index, builds a constrained prompt, and expects the answer to cite the retrieved sources.

## 2. When embeddings are actually warranted

Leadtype's docs recommend starting with the local static index because it is cheap, fast, edge-safe, and especially good for exact API names, config keys, error messages, paths, and other docs-search queries where lexical precision matters.

Adding embeddings is warranted only when one of these conditions is true:

1. **Users search with vocabulary that does not match the docs.**  
   Example: a user searches for "make it faster" but the relevant page is titled "performance optimization."

2. **The docs grow past tens of thousands of chunks and the cold-start memory hit becomes noticeable.**

Even then, embeddings should be added as a layer, not used as a replacement. We should **keep Leadtype's lexical/BM25 index for exact matches** and combine embeddings with it, because lexical search and semantic/vector search are complementary. If we serve AI answers, we should also keep the source-grounded retrieval/citation pattern rather than letting a model answer from memory.
