# Leadtype Docs Search — What You Already Have

## 1. What leadtype's docs search uses by default

Leadtype's search is **fully static and database-free by default.** No server, no hosted index, no embedding model, no vector store.

At build time, `leadtype generate` (or the `generateDocsSearchFiles` API) reads your converted markdown and writes two plain JSON files:

```
public/docs/search-index.json   ← compact term postings + ranking data
public/docs/search-content.json ← raw chunk text for excerpts and answer context
```

At runtime, the `searchDocs` function from `leadtype/search` loads those two files and queries them entirely in memory — **no network call, no database round-trip, edge-safe everywhere** (Vercel, Cloudflare Workers, etc.).

### How ranking works under the hood

- Documents are split into **heading-aware chunks**, so results deep-link to the right *section*, not just the right page.
- Ranking uses **BM25** with field-weighted scoring: titles 4×, headings 2×, body 1×, code 0.35×.
- Query terms expand via **lightweight stemming, prefix matches, typo-tolerant fallbacks, and a built-in synonym map** — so results aren't limited to exact tokens, but exact matches (API names, config keys, error codes) keep the highest weight.
- You can inject **product-specific synonyms** at query time for vocabulary mismatches that are known in advance:

```ts
searchDocs(index, "starter", {
  content,
  synonyms: { starter: ["quickstart", "getting started"] },
});
```

### What the two files provide beyond plain search

The same static files also power:
- **Source-grounded AI answers** via `createAnswerContext` / `streamDocsAnswer` (Vercel, TanStack, Cloudflare adapters) — the model is constrained to the retrieved chunks and must cite sources; no hallucination from memory.
- **A virtual filesystem** (`listDocsContentFiles`, `readDocsContentFile`, `readDocsContentChunk`) for agent/bash-tool access to docs content.

**The bottom line:** a hosted database-backed vector index is not part of the default setup and is not required to get fast, section-level, typo-tolerant search across your docs.

---

## 2. When adding embeddings is actually warranted — and what to keep even then

The leadtype docs state the conditions precisely:

> *"Start with the local index. It is static, cheap, edge-safe, and fast for exact API names, config keys, error messages, and paths. Add embeddings only when:*
> - *Users search with vocabulary that doesn't match the docs (e.g. "make it faster" matching a "performance optimization" page).*
> - *Your docs grow past tens of thousands of chunks and the cold-start memory hit becomes noticeable."*

In other words, embeddings are warranted only when **both** of the following are true:

1. **Semantic gap** — your users habitually search using natural-language descriptions or paraphrases that share no surface tokens with the words actually in your docs, AND the built-in synonym map cannot bridge that gap because the vocabulary mismatch is too broad or unpredictable.
2. **Scale** — your corpus has grown to tens of thousands of chunks, making the in-memory cold-start cost of the static index a measurable problem.

### What you must keep even if you do add embeddings

> *"Even then, keep the lexical index for exact matches and layer embeddings on top — they're complementary, not replacements."*

The static BM25 index must be **retained alongside** any embedding layer because it outperforms dense retrieval on the queries that dominate a docs surface: exact API names, CLI flag spellings, config key lookups, error message strings, and precise paths. Throwing it away in favour of a pure vector index would make those common, high-intent queries worse, not better.

### Practical takeaway for the team

Before standing up a hosted vector database, verify that users are actually hitting the semantic gap condition — i.e., that real search queries are failing because of vocabulary mismatch, not because of missing synonyms or missing docs content. If that failure mode isn't observed in production, the static index already covers your use case at zero infrastructure cost.
