# Docs search with `leadtype` — what we already have, and when embeddings actually help

Before standing up a hosted, database-backed vector index, here's what the `leadtype` package already provides out of the box, and the narrow conditions under which adding embeddings is warranted.

Sources in the installed package:
- `node_modules/leadtype/docs/reference/search.md`
- `node_modules/leadtype/docs/build/add-search.md`
- `node_modules/leadtype/README.md`

---

## 1. What leadtype's docs search uses by default

**A static, edge-safe BM25 index built at build time. No database. No embeddings. No server.**

Concretely:

- **Build step.** `leadtype generate` (or `generateDocsSearchFiles` from `leadtype/search/node`) reads the converted markdown under `<outDir>/docs/` and emits two JSON files:
  - `public/docs/search-index.json` — compact ranking data (term postings, document refs, chunk refs).
  - `public/docs/search-content.json` — the chunk text, kept separate so the index can be loaded on every search while content is loaded lazily for excerpts and answers.
- **Chunking.** Each page is sliced into **heading-aware chunks** so results jump to the right section, not just the right page.
- **Ranking.** **BM25** with field-weighted boosts: titles 4×, headings 2×, body 1×, code 0.35× (tunable in the generator).
- **Query handling (still local, dependency-free).** Not just exact-token match — query terms expand through **lightweight stemming, prefix matches, typo-tolerant fallbacks, and a small built-in synonym map**. Exact matches still get the highest weight so API names, config keys, error messages, and paths stay precise. Product-specific vocabulary can be added via the `synonyms` option on `searchDocs`.
- **Runtime.** `searchDocs(index, query, { content })` from `leadtype/search` is edge-safe (no Node APIs) — runs on Vercel, Cloudflare Workers, anywhere. The index is just imported/fetched JSON.
- **Same index doubles as a virtual filesystem.** `listDocsContentFiles`, `readDocsContentFile`, `readDocsContentChunk`, plus the `leadtype/search/bash` adapters (read-only `ls`/`cat`/`find`/`grep`/`rg` over a virtual `/docs`) let agents explore docs without a separate retrieval layer.
- **Source-grounded answers (optional).** `createAnswerContext` plus provider wrappers (`leadtype/search/vercel`, `/tanstack`, `/cloudflare`) build a constrained `{ system, prompt, sources }` from the same static index and stream a Response. Citations come back as `sources` metadata — no vector DB involved.
- **Request hardening.** `validateDocsQuery`, `readJsonWithLimit`, `getClientIdentifier`, and a `RateLimiter` interface (with an in-memory implementation for demos) are provided for the request path.

**Net result:** for our docs we already get chunked retrieval, ranked search, snippets, deep links to the right heading, and grounded AI answers — served from two static JSON files at the edge, with zero infrastructure to operate.

---

## 2. When adding embeddings is actually warranted — and what we keep

Per `leadtype`'s own guidance ("When to add embeddings" in `docs/reference/search.md`), the default position is: **start with the local index. Add embeddings only when one of these is actually true:**

1. **Vocabulary mismatch is real and measured.** Users search with words our docs don't use — e.g. "make it faster" needs to find a page titled "performance optimization" — and adding entries to the `synonyms` map is no longer enough to cover the gap.
2. **Scale.** Our docs grow past **tens of thousands of chunks** and the cold-start memory cost of loading the lexical index becomes noticeable in the runtime that serves search.

If neither of those is documented with evidence from real query logs, building a hosted vector index is premature. It adds an operational surface (ingestion job, vector DB, embedding-model bill, drift between commits and indexed vectors, an extra failure mode in the search path) that the static index does not have.

### What we keep even if we do add embeddings

> "Even then, keep the lexical index for exact matches and layer embeddings on top — they're complementary, not replacements."

That means:

- **Keep `search-index.json` + `search-content.json`** as the system of record for retrieval. They're generated from the same MDX our site is, so they can't drift from the published docs.
- **Keep BM25 / lexical ranking as the authoritative path for exact matches** — API names, config keys, CLI flags, error messages, file paths. Embeddings routinely under-rank these; BM25 with the title/heading/code weighting is exactly what we want for them.
- **Layer embeddings as a secondary recall signal** for natural-language / paraphrased queries, then merge or rerank with the lexical results — don't replace lexical retrieval with vector retrieval.
- **Keep the existing answer pipeline** (`createAnswerContext` + the provider stream wrappers). Embeddings change *which chunks* go into the context; they don't replace the "answer only from retrieved context, cite with `[1]`" contract that's already implemented.
- **Keep the abuse guards** (`validateDocsQuery`, `readJsonWithLimit`, rate limiter) on the request path regardless of retrieval backend.

### Recommended sequence before we build anything new

1. Ship the static index that `leadtype generate` already produces.
2. Instrument queries: capture the query, top result, whether the user clicked, and zero-result queries.
3. Triage zero-result and low-CTR queries. If they cluster around vocabulary mismatch, **first try the `synonyms` option** to `searchDocs` — that's a config change, not infrastructure.
4. Only if (a) synonyms can't close the gap on a measurable share of real queries, or (b) chunk count crosses the tens-of-thousands threshold and we see cold-start pain, do we add an embedding layer — on top of, not instead of, the existing BM25 index.

In short: **we don't need a hosted vector DB to "do RAG." `leadtype` already gives us chunked, grounded, cited retrieval from static JSON.** A vector index is an upgrade we earn with evidence, and it sits next to the lexical index, not in its place.
