# Leadtype docs search: what we get before adding a vector database

## Default search model

Leadtype's docs search is **static by default**. At build time, it generates two JSON artifacts:

- `public/docs/search-index.json` — a compact search index.
- `public/docs/search-content.json` — the actual chunk text used for snippets and answer context.

At runtime, `leadtype/search` imports or fetches those files and queries them **without a hosted database or vector store**. The runtime is edge-safe and dependency-free.

The default index is a **BM25-ranked lexical index** over heading-aware chunks of the docs. It is not just exact token matching: Leadtype also applies lightweight stemming, prefix matches, typo-tolerant fallbacks, and a small built-in synonym map. Product-specific synonyms can be added when needed.

Ranking weights are tuned for docs:

- Titles: `4x`
- Headings: `2x`
- Body: `1x`
- Code: `0.35x`

Leadtype can also provide optional source-grounded AI answers, but those answers are layered on top of retrieval from the static index: Leadtype retrieves chunks, builds a constrained prompt, and expects the model to answer only from the returned context with citations.

## When embeddings are warranted

Start with Leadtype's local static index. It is cheap, fast, edge-safe, and especially good for docs queries involving exact API names, config keys, error messages, file paths, headings, and code identifiers.

Add embeddings only when one of these conditions is true:

1. **Users search with vocabulary that does not match the docs.**  
   Example: users type "make it faster" but the docs say "performance optimization".

2. **The docs corpus grows past tens of thousands of chunks and the cold-start memory cost of the local index becomes noticeable.**

Even then, embeddings should be **layered on top of**, not used as a replacement for, Leadtype's lexical index. Keep the BM25/static lexical search for exact matches and identifiers, and use embeddings as a complementary semantic retrieval path.