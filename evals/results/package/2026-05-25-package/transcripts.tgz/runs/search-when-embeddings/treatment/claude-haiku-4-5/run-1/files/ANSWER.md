# What `leadtype` Provides for Docs Search

## 1. Default Docs Search Implementation

By default, **`leadtype` builds a static, edge-safe search index using BM25 lexical ranking**. Here's what this means:

- **Build-time**: `leadtype generate` creates two JSON files:
  - `search-index.json` — compact ranking data with term postings and document references
  - `search-content.json` — the actual chunk text, separated for lazy loading
  
- **Runtime**: Zero database required. Your application imports these JSON files and queries them locally using the `searchDocs()` function.

- **Ranking algorithm**: BM25 with tuned weights:
  - Titles: 4× weight
  - Headings: 2× weight  
  - Body text: 1× weight
  - Code: 0.35× weight

- **Query capabilities**: 
  - Lexical matching with lightweight stemming
  - Prefix matching for partial terms
  - Typo-tolerant fallbacks
  - Small built-in synonym map
  - Exact matches weighted highest (preserves API names and config keys)

- **Granularity**: Heading-aware chunking — search results jump to the right section, not just the page.

- **Cost/Performance profile**: 
  - Static files = no database, no hosting costs for the index itself
  - Edge-safe = can run on Vercel, Cloudflare, or any serverless platform
  - Fast cold starts (no network calls to retrieve rankings)
  - Optional source-grounded AI answers layer on top (streaming via provider entry points: Vercel, TanStack, Cloudflare)

---

## 2. When Embeddings Are Actually Warranted

Add embeddings (a hosted vector index) **only** under these specific conditions:

### Condition 1: Vocabulary Mismatch
Users search with words your docs don't use. Example: "make it faster" should find a "performance optimization" guide. Lexical search fails here; semantic similarity helps.

### Condition 2: Scale
Your docs grow past **tens of thousands of chunks** and the cold-start memory hit of loading a large JSON index becomes noticeable.

### Critical: What to Keep Even Then

**Do not replace the lexical index.** Keep both systems:

- **Keep BM25 lexical search** for:
  - Exact API names, function signatures, config keys
  - Error messages
  - Path patterns
  - Common acronyms
  
- **Layer embeddings on top** for:
  - Vocabulary mismatch scenarios (semantic matching)
  - Exploratory queries where users don't know exact terminology
  - Secondary ranking or re-ranking

They are **complementary, not replacements**. Users searching for `create` should find exact matches before semantic neighbors.

---

## Summary

**Default = static BM25 lexical search.** No database, no hosting, fully edge-safe, perfectly adequate for most docs. Add embeddings only when vocabulary mismatch frustrates users or scale demands it — and when you do, layer them alongside lexical ranking, never instead of it.
