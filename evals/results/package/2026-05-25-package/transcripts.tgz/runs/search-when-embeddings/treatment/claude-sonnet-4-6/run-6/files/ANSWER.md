# Leadtype Docs Search — What You Already Have

## 1. What leadtype's docs search uses by default

Leadtype's docs search is **fully static and database-free by default**.

At build time, `leadtype generate` (site mode) writes two plain JSON files:

```
public/docs/search-index.json    ← compact BM25 inverted index
public/docs/search-content.json  ← raw chunk text for excerpts and answer context
```

At runtime, `searchDocs()` imports those two files and queries them **entirely in
process — no network call, no database, no external service**. The runtime is
edge-safe (no Node APIs) and works on Vercel, Cloudflare Workers, or any other
edge environment out of the box.

### What "static BM25" actually means here

| Layer | Detail |
|---|---|
| **Ranking** | BM25 with field weights: titles 4×, headings 2×, body 1×, code 0.35×. |
| **Unit of scoring** | Heading-aware *chunks* (not whole pages), so results link to the right section, not just the right page. |
| **Query expansion** | Lightweight stemming, prefix matches, typo-tolerant fallbacks, and a small built-in synonym map. Exact matches retain highest weight, keeping API names and config keys precise. |
| **Custom vocabulary** | Pass a `synonyms` map to `searchDocs()` for product-specific terms — no re-indexing required. |
| **AI answers (opt-in)** | `createAnswerContext()` / `streamDocsAnswer()` retrieves chunks from the *same static index*, builds a constrained prompt, and streams a source-grounded answer. The model is supplied by you; the index does the retrieval. |

Everything lives in two static files that are generated once and served as
ordinary assets. There is no vector database, no embedding model, no external
API call in the search path.

---

## 2. When embeddings are actually warranted — and what to keep even then

Leadtype's own reference docs state the conditions directly:

> *"Add embeddings only when:*
> - *Users search with vocabulary that doesn't match the docs (e.g. "make it
>   faster" matching a "performance optimization" page).*
> - *Your docs grow past tens of thousands of chunks and the cold-start memory
>   hit becomes noticeable."*

In plain terms:

| Condition | Why embeddings help |
|---|---|
| **Vocabulary mismatch at scale** | BM25 is lexical — it matches terms that actually appear in the text. If your users consistently phrase things in ways your docs don't, semantic embeddings can bridge that gap. Note that the built-in synonym map handles the common cases without a vector index. |
| **Corpus so large cold-start memory matters** | Tens of thousands of chunks means `search-index.json` grows large. At that scale loading the full index on every cold start becomes noticeable and a vector store with ANN (approximate nearest-neighbor) lookup can be more efficient. |

### What to keep even when you do add embeddings

The docs are explicit: **embeddings complement the lexical index, they do not
replace it.**

> *"Even then, keep the lexical index for exact matches and layer embeddings on
> top — they're complementary, not replacements."*

Keep the BM25 static index because it does things embeddings are bad at:

- **Exact token matching** — API names, config keys, CLI flags, error codes, and
  file paths all need precise term lookup, not semantic approximation.
- **Zero latency, zero cost** — the static index is free to query and needs no
  embedding inference at query time.
- **No hallucination surface** — BM25 results are deterministic and
  auditable; there is no model in the retrieval path.

The correct architecture when you do reach the embedding threshold is a
**hybrid retriever**: BM25 for exact / high-precision hits, embeddings for
semantic / vocabulary-mismatch hits, then rank-fuse the two result sets before
passing chunks to `createAnswerContext()`.

---

### Bottom line for the team

A hosted, database-backed vector index is not warranted yet. Leadtype already
provides a production-grade, edge-safe, BM25 search index with typo tolerance,
stemming, prefix matching, synonym support, and optional AI answer streaming —
all from two static JSON files with no infrastructure to stand up or pay for.
Reach for a vector store only when users demonstrably fail to find content
because of vocabulary mismatch, or when the index file itself grows large enough
to hurt cold-start performance. Even then, keep the BM25 index running
alongside it.
