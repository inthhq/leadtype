# Leadtype's Default Docs Search

## What Leadtype Provides by Default

Leadtype builds a **static, lexical search index** at build time without requiring embeddings or a database.

### The Default Index

- **Format**: Two JSON files generated at build time
  - `search-index.json` — compact ranking data (loaded on every search)
  - `search-content.json` — chunk text for excerpts and answer context (loaded lazily)
- **Indexing Algorithm**: BM25 with tunable weights
  - Titles: 4×
  - Headings: 2×
  - Body text: 1×
  - Code: 0.35×
- **Search Granularity**: Heading-aware chunks (not just pages)
  - Each heading generates a separate searchable document
  - Results link directly to the right section with hash anchors
- **Runtime**: Edge-safe, zero-dependency
  - Works on Vercel, Cloudflare, any serverless platform
  - Local queries — no network calls, no database required
  - Query expansion through:
    - Lightweight stemming
    - Prefix matching
    - Typo-tolerant fallbacks
    - Small built-in synonym map
    - Product-specific synonyms (configurable)

### What You Get Out of the Box

1. **Fast, cheap exact matching** for API names, config keys, error messages, and documentation paths
2. **Instant results** with no latency or cost from database queries
3. **Small payload**: Index loads once; content loads on demand
4. **Offline-ready**: Ship the index in your npm package or static CDN
5. **Optional AI answers** via source-grounded context
   - Leadtype retrieves relevant chunks from the static index
   - Passes a constrained prompt to any LLM provider
   - Sources surface separately for proper citations
   - No vector database required for this either

---

## When Embeddings Are Actually Warranted

Add embeddings **only when both conditions hold**:

1. **Users search with vocabulary that doesn't match the docs**
   - E.g., "make it faster" should match a "performance optimization" page
   - The static index fails because exact terms don't overlap
   - Lexical synonyms (added as config) don't cover the semantic gap

2. **Scale becomes a problem**
   - Docs grow past tens of thousands of chunks
   - Cold-start memory footprint for the BM25 index becomes noticeable
   - Search latency becomes unacceptable even with edge hosting

### What to Keep When You Add Embeddings

**Never replace the lexical index.** Keep both:

- **Lexical index for exact matches** — API names, config keys, error codes stay precise
- **Embedding index for semantic coverage** — catch vocabulary mismatches
- **Hybrid ranking** — exact matches win, embeddings fill gaps

This is the complementary approach: exact matches (fast, cheap, precise) layer with semantic search (catches intent-based queries). You lose nothing by keeping the static index — it's already generated and costs almost nothing at query time.

---

## Summary: Before You Host a Vector Database

The default `leadtype` search is sufficient for most docs. Start with it, measure user behavior, and only add embeddings if:

1. Users search with vocabulary your docs don't use, *and*
2. Adding synonyms and rephrase suggestions doesn't solve it, *and*
3. You have enough scale and search volume to justify the infrastructure.

Even then, keep the BM25 index. It's static, queryable anywhere, searchable offline, and makes exact technical searches work perfectly.
