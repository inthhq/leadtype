# Leadtype docs search and embeddings

## What Leadtype uses by default

Leadtype’s docs search is **static and lexical by default**, not hosted or database-backed.

In site mode, `leadtype generate` builds two JSON files from the generated markdown under `docs/`:

- `docs/search-index.json` — a compact search index with ranking data.
- `docs/search-content.json` — the chunk text used for snippets, excerpts, and source-grounded answer context.

At runtime, app code imports or fetches those files and queries them with `searchDocs()` from `leadtype/search`. The runtime is edge-safe and does not require Node APIs, a search service, or a database.

The ranking model is **BM25 over heading-aware chunks**. Leadtype weights fields roughly as:

- titles: 4×
- headings: 2×
- body: 1×
- code: 0.35×

It is not only exact-token matching. The default search also includes lightweight stemming, prefix matches, typo-tolerant fallbacks, and a small built-in synonym map. Product-specific synonyms can be added when users search with vocabulary the docs do not use.

Leadtype can also layer source-grounded AI answers on top of this same static index: it retrieves relevant chunks, builds constrained context, and lets a provider-specific adapter stream an answer. The model is instructed to answer from retrieved docs context and cite sources.

## When embeddings are warranted

Start with Leadtype’s local lexical index. It is static, cheap, fast, edge-safe, and especially good for docs queries involving exact API names, config keys, error messages, commands, and paths.

Add embeddings only when one of these conditions is actually true:

1. **Users search with vocabulary that does not match the docs.**
   For example, users search for “make it faster” but the relevant page is titled “performance optimization.” If aliases and product-specific synonyms are not enough, semantic retrieval may help.

2. **The docs grow past tens of thousands of chunks and the cold-start memory cost of the static index becomes noticeable.**
   At that scale, moving part of retrieval to a hosted/vector service may be justified operationally.

Even then, keep Leadtype’s lexical index. Embeddings should be layered on top as a complement, not used as a replacement. The lexical/BM25 index remains the right tool for precise matches on API names, config keys, paths, error strings, and code-oriented queries, while embeddings can help with broader semantic vocabulary mismatches.
