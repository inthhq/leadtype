# Leadtype docs search: do we need a hosted vector DB?

## 1. What Leadtype uses by default

Leadtype's docs search is **static by default**, not database-backed.

In site mode, `leadtype generate` writes two files under `public/docs/`:

- `search-index.json` — a compact search index.
- `search-content.json` — the chunk text used for snippets, excerpts, and answer context.

At runtime, your app imports or fetches those JSON files and queries them with `searchDocs()` from `leadtype/search`. The runtime is edge-safe, dependency-free, and does **not** touch a database.

The default ranking is lexical/BM25 over heading-aware chunks:

- Titles are weighted highest.
- Headings, body text, and code are indexed with different weights.
- Results can point to the right section hash, not only the page.
- Search includes lightweight stemming, prefix matching, typo-tolerant fallbacks, and a small built-in synonym map.
- Product-specific synonyms can be added when users search for terms your docs do not use.

Leadtype can also produce optional source-grounded AI answers, but those sit on top of the same retrieved docs chunks. The model is instructed to answer from retrieved context and cite sources; this is not a hosted vector index by default.

## 2. When embeddings are warranted

Start with Leadtype's local static index. Add embeddings only if one of these conditions is true:

1. **Vocabulary mismatch is a real user problem.**  
   Users regularly search with language that does not appear in the docs, such as `make it faster` when the relevant page says `performance optimization`.

2. **The docs corpus becomes very large.**  
   The docs grow past tens of thousands of chunks and the cold-start memory cost of the local index becomes noticeable.

Even then, embeddings should be layered on top of Leadtype's lexical index, not replace it. Keep the BM25/static lexical index for exact API names, config keys, error messages, file paths, and other precise lookups. Embeddings and lexical search are complementary.