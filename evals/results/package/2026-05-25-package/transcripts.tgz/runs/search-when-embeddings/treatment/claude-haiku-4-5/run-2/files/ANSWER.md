# What Leadtype's Docs Search Already Gives You

## 1. What Leadtype Uses By Default

Leadtype's docs search is **static, build-time generated, and lexical** by default — no database required.

### The Default Implementation

- **Index type**: BM25-ranked inverted index built at build time
- **Storage**: Two JSON files generated during the build
  - `search-index.json` — the compact ranking data (loaded on every search)
  - `search-content.json` — the actual text for excerpts and answers (loaded lazily)
- **Runtime**: Edge-safe (no Node.js APIs) — works anywhere: Vercel, Cloudflare, browsers
- **Querying**: Lexical matching with built-in enhancements:
  - **Stemming** — term variants (e.g., "running" matches "run")
  - **Prefix matching** — partial terms work
  - **Typo tolerance** — slight misspellings handled
  - **Built-in synonym map** — common variants pre-loaded
  - **Exact match prioritization** — API names and config keys stay precise

### Ranking Weights (Configurable)

- Titles: 4×
- Headings: 2×
- Body text: 1×
- Code: 0.35×

### Chunking

The index scores heading-aware chunks independently, not just full pages. Search results jump to the right section, not just the right page. Each heading (H1, H2, H3, etc.) becomes a separate searchable unit.

---

## 2. When to Add Embeddings (and What to Keep)

### Do NOT add embeddings if:

- Users search with exact API names, config keys, error messages, or paths
- Your docs are under tens of thousands of chunks
- You want cold-start speed and low operational complexity
- Your team doesn't have the infrastructure to host a vector database

### DO add embeddings only when:

1. **Semantic vocabulary mismatch**: Users search with words your docs don't use (e.g., "make it faster" not matching a "performance optimization" page)
2. **Scale**: Your docs grow past tens of thousands of chunks and the in-memory cold-start hit becomes noticeable

### If You Do Add Embeddings

**Keep the lexical index.** These approaches are **complementary, not replacements**:

- Use the BM25 index for exact API names, config keys, error messages, and code terms
- Add embeddings on top for semantic similarity and vocabulary variants
- Rank results by combining both signals

This hybrid approach preserves the precision that exact-match users rely on while adding fuzzy-match capabilities for conversational queries.

### Optional Infrastructure Layer

If you do go beyond the default, keep these leadtype primitives in your tech stack:

- **Static content store** — the `.md` files and content JSON. These are cheap to serve and let you search without loading a database.
- **Stateless query layer** — no session state, no connection pooling. This lets you scale horizontally and deploy to edge runtimes.
- **Source-grounded answers** — the `createAnswerContext` helper constrains LLM responses to retrieved chunks regardless of your retrieval mechanism. Don't ask the model to answer from memory.

---

## Summary

Leadtype gives you **everything most teams need** out of the box: fast, cheap, accurate lexical search that works offline and on the edge. Adding a hosted vector index is premature for nearly all doc projects. Start with the built-in search. Only add embeddings when you hit the specific conditions above — and when you do, keep the lexical index running in parallel.
