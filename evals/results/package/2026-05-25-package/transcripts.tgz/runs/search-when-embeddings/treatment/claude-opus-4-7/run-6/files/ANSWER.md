# Docs search in `leadtype`: what you already have, and when embeddings actually pay off

Source: `node_modules/leadtype/docs/reference/search.md` and `docs/build/add-search.md` (shipped inside the installed package).

## 1. What leadtype gives you by default

Leadtype builds a **static, edge-safe, BM25 lexical search index** over your docs at build time. There is **no database and no server-side index** in the default path.

The pipeline:

- **Build time** — `leadtype generate` (or `generateDocsSearchFiles` from `leadtype/search/node`) reads the converted markdown under `<outDir>/docs/` and writes two JSON files:
  - `public/docs/search-index.json` — compact tuple format: term postings, document refs, chunk refs. Loaded on every search; kept small on purpose.
  - `public/docs/search-content.json` — the actual chunk text, separated so excerpts/answers can be loaded lazily.
- **Chunking** — heading-aware. Each chunk is its own document, so results jump to the right section (with hash URLs), not just the right page.
- **Ranking** — BM25 with field weights: **title 4×, headings 2×, body 1×, code 0.35×** (tunable).
- **Query handling** — `searchDocs(index, query, { content })` from `leadtype/search`. It is local and dependency-free but **not** exact-token-only:
  - lightweight stemming
  - prefix matches
  - typo-tolerant fallbacks
  - a small built-in synonym map
  - exact matches keep the highest weight, so API names / config keys stay precise
  - optional per-call `synonyms` map for product-specific vocabulary
- **Runtime** — edge-safe (no Node APIs). Runs on Vercel, Cloudflare Workers, etc. The same index also acts as a virtual filesystem via `listDocsContentFiles` / `readDocsContentFile` / `readDocsContentChunk`.
- **Optional AI answers** — `createAnswerContext` plus provider wrappers (`leadtype/search/vercel`, `/tanstack`, `/cloudflare`) build a source-grounded prompt from retrieved chunks and stream a response with a separate `sources` array for citations. There are also bash-tool adapters (`leadtype/search/bash`) that expose a read-only virtual `/docs` FS (`ls`, `cat`, `find`, `grep`, `rg`) for agents that prefer to explore.
- **Abuse guards** — `validateDocsQuery`, `readJsonWithLimit`, `getClientIdentifier`, `createMemoryRateLimiter` (swap for Redis / Vercel KV / Cloudflare KV / Durable Objects in production).

Net effect: two static JSON files served from your CDN give you chunk-level search, snippets, and grounded answers — **no vector DB, no embedding API, no hosted index service**.

## 2. When adding embeddings is actually warranted

Leadtype's own guidance (`reference/search.md`, "When to add embeddings") is explicit: **start with the local index**. It is the right tool for exact API names, config keys, error messages, and paths — which is most docs traffic.

Only add embeddings when one of these is demonstrably true:

1. **Vocabulary mismatch** — users search with words your docs do not use (e.g. "make it faster" needs to match a "performance optimization" page) and adding `synonyms` to `searchDocs` is no longer sufficient to cover it.
2. **Scale** — docs grow past **tens of thousands of chunks** and the cold-start memory cost of the in-memory index becomes noticeable.

If neither condition holds, a hosted DB-backed vector index is overhead, not RAG.

### What to keep even if we do add embeddings

- **Keep the lexical BM25 index.** Embeddings are **complementary, not a replacement**. Semantic search is weak on exactly the queries lexical search is strong on — exact API names, flags, config keys, file paths, error strings. Layer embeddings on top; do not swap them in.
- **Keep the static build-time pipeline** (`generateDocsSearchFiles`, the two JSON artifacts, the edge runtime). It stays the fast path; the embedding store is consulted for vocabulary-mismatch fallback or as a second retriever fused with BM25.
- **Keep `createAnswerContext` / the provider streamers** for grounding. Whatever retriever you add still feeds chunks into the same source-grounded prompt with citations — don't let the model answer from memory.
- **Keep the abuse guards** (`validateDocsQuery`, rate limiter, JSON size limit) on any new endpoint.

### Recommendation for the team

Ship the default leadtype search first. Instrument zero-result and low-CTR queries. If those logs show a real vocabulary-mismatch pattern that synonyms cannot absorb, *then* introduce embeddings as a second retriever behind the existing BM25 index — not as a replacement, and not as a reason to stand up a hosted vector DB on day one.
