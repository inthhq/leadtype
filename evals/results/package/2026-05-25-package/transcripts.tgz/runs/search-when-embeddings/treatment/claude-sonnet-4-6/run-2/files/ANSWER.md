# Leadtype Docs Search — What You Already Have

## 1. What leadtype's docs search uses by default

Leadtype's search is **fully static and database-free by default.** No hosted
index, no vector store, no embedding model, no network call at query time.

Here is exactly what happens:

### Build time
Running `leadtype generate` (or calling `generateDocsSearchFiles` from
`leadtype/search/node`) writes two plain JSON files into your output directory:

```
public/docs/search-index.json   ← compact ranking data (term postings, doc refs, chunk refs)
public/docs/search-content.json ← chunk text for excerpts and answer context
```

The two files are intentionally split: the index is small and loaded on every
search; the content store is loaded lazily only when a snippet or AI answer is
needed.

### What the index contains
The index is **chunk-aware and heading-aware.** Each heading section of each
page is its own chunk, so a search result can point directly to the right
heading (with a hash URL), not just the right page.

### Runtime ranking — BM25
At query time the runtime (`leadtype/search`) queries the static JSON entirely
in-process — no network, no Node.js APIs, edge-safe on Vercel, Cloudflare
Workers, and anywhere else. The ranking function is **BM25** with deliberately
tuned field weights:

| Field | Weight |
|-------|--------|
| Title | 4× |
| Headings | 2× |
| Body | 1× |
| Code blocks | 0.35× |

This keeps API names and config keys from being buried by long prose.

### Query expansion — not just exact tokens
The default runtime is not a raw keyword matcher. Every query automatically
gets:

* **Lightweight stemming** (e.g. "running" → "run")
* **Prefix matches** (partial tokens still score)
* **Typo-tolerant fallbacks**
* **A built-in synonym map** for common English variants

Exact matches retain the highest weight so precise API names and error strings
stay pinned to the top. You can extend with product-specific synonyms via the
`synonyms` option when users search with vocabulary your docs don't use.

### Optional (not default): AI answer streaming
On top of the static index, leadtype can stream source-grounded answers via
`createAnswerContext` / `streamDocsAnswer`. This is opt-in and still uses the
same static JSON for retrieval — the chunks are pulled from the local index and
packed into a constrained prompt; the model is told to answer only from that
context. Provider-specific thin wrappers exist for Vercel AI SDK, TanStack AI,
and Cloudflare AI Gateway. This is _not_ a vector search; it is lexical
retrieval feeding an LLM, not semantic retrieval.

---

## 2. When adding embeddings is actually warranted — and what to keep

The leadtype docs are explicit about this (from `docs/reference/search.md`,
"When to add embeddings"):

### Add embeddings only when **both** of these are true

| Condition | Why it matters |
|-----------|----------------|
| **Users search with vocabulary that doesn't appear in the docs** — e.g. typing "make it faster" when the relevant page is titled "Performance Optimization" | BM25 and stemming rely on token overlap. When user intent and doc wording are genuinely far apart in token space, semantic similarity (embeddings) can bridge the gap. |
| **OR your docs grow past tens of thousands of chunks and cold-start memory becomes noticeable** | Loading a very large JSON index into memory on every cold start has a measurable cost. A hosted vector index can offload retrieval at that scale. |

If neither condition applies — and for most docs sites they won't — adding
embeddings is pure overhead: a database to maintain, an embedding model to
call, latency on every query, and cost.

### What to keep even when you do add embeddings

> "Even then, keep the lexical index for exact matches and layer embeddings on
> top — they're complementary, not replacements."
> — `docs/reference/search.md`

**Keep the static BM25 index regardless.** Embeddings are weak at exact
matches: API method names, CLI flag strings, error codes, config key names, and
paths score poorly in cosine similarity when the user types them verbatim.
Lexical search handles those cases precisely and instantly. The right
architecture is a **hybrid retrieval** step — run both, then merge or
reciprocal-rank-fuse the result sets — not a wholesale replacement of the
static index with a vector database.

---

### Bottom line for the team

The "database-backed vector index because that's how RAG is done" framing gets
the causality backwards. Leadtype already gives you:

* Static JSON index generated at build time
* BM25 ranking with stemming, prefix matching, typo tolerance, and synonyms
* Heading-level chunk granularity so results land on the right section
* Edge-safe runtime with zero dependencies
* An optional path to source-grounded AI answers using the same static files

You should ship that first. Reach for embeddings only if real users demonstrably
can't find pages because their search vocabulary doesn't overlap with your doc
text — and even then, run the static index in parallel for exact-token queries.
