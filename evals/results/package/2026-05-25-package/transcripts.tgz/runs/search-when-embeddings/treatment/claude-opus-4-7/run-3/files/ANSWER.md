# Docs search with `leadtype`: what we already have, and when embeddings are warranted

## 1. What leadtype gives us by default

Leadtype builds a **static, edge-safe, database-free search index** over our docs at build time. There is no server, no vector DB, no embedding pipeline involved.

### Build time

`leadtype generate` (or `generateDocsSearchFiles` from `leadtype/search/node`) emits two JSON files after MDX conversion:

- `public/docs/search-index.json` — compact tuple format with term postings, document refs, and chunk refs. Small, loaded on every search.
- `public/docs/search-content.json` — the actual chunk text, kept separate so we can rank without loading bodies, then read text lazily for excerpts and answer context.

Indexing is **heading-aware chunking**: each section of a page is its own document, so results jump to the right heading (hash URL), not just the right page.

### Ranking

BM25 with field weights:

- Titles ×4
- Headings ×2
- Body ×1
- Code ×0.35

(Tunable in the index generator.)

### Runtime

`searchDocs(index, query, { content })` from `leadtype/search`. It is edge-safe — no Node APIs — runs on Vercel, Cloudflare, etc. Out of the box the query path already includes:

- Lexical/exact-token matching (so API names, config keys, error strings, and paths stay precise)
- Lightweight stemming
- Prefix matches
- Typo-tolerant fallbacks
- A small built-in synonym map, plus an optional per-call `synonyms` map for our product vocabulary

Results carry page URLs, heading paths, hash URLs, and snippets — ready to render in a search UI.

### Bonus capabilities riding on the same two JSON files

- **Virtual filesystem readers** — `listDocsContentFiles`, `readDocsContentFile`, `readDocsContentChunk`.
- **Source-grounded answer context** — `createAnswerContext` builds a `{ system, prompt, sources }` constrained to retrieved chunks (model is told to answer only from context and cite `[1]`-style).
- **Streaming answer wrappers** — `leadtype/search/vercel`, `/tanstack`, `/cloudflare` return `{ response, sources }`.
- **Bash tool adapters** — `createDocsBashTool` / `createDocsBashTools` expose a read-only `/docs` filesystem (`ls`, `cat`, `find`, `grep`, `rg`) for agents that prefer to explore.
- **Abuse guards** — `validateDocsQuery`, `readJsonWithLimit`, `getClientIdentifier`, `createMemoryRateLimiter`.

**Net result:** two static JSON files deployed with the site give us search, snippets, heading-deep links, RAG context construction, streamed grounded answers, and agent tool access — with no database and no per-query inference cost.

## 2. When adding embeddings is actually warranted

Per leadtype's own guidance, start with the local lexical index. Add embeddings **only** when one of the following is true:

1. **Vocabulary mismatch is hurting recall.** Users search with terms our docs do not use — e.g. "make it faster" should hit a "performance optimization" page. First try the cheaper fix: pass a `synonyms` map to `searchDocs`. Reach for embeddings only if the synonym surface area becomes unmanageable.
2. **Scale exceeds the lexical index's comfort zone.** Our docs grow past *tens of thousands of chunks* and cold-start memory or load time becomes noticeable.

A hosted DB-backed vector index "because that's how RAG is done" is not on that list. Our docs almost certainly fit in the lexical index, and the static index already supplies the retrieval step for RAG via `createAnswerContext` / `streamDocsAnswer`.

### What to keep even after adding embeddings

- **Keep the lexical BM25 index.** Embeddings are *complementary, not a replacement*. Exact matches for API names, config keys, error messages, and file paths must stay precise — that is lexical's job, and semantic search is bad at it.
- **Keep the static two-file artifact and the edge-safe runtime.** Layer embeddings on top (hybrid retrieval), don't replace the existing path.
- **Keep the chunking, heading-deep links, source citations, and abuse guards** — they are independent of how retrieval ranks candidates.

### Recommendation

Do not stand up a hosted vector DB yet. Ship `leadtype generate` + `searchDocs` + (optionally) `streamDocsAnswer` first. Measure: are misses caused by vocabulary, scale, or something else? If vocabulary, add `synonyms`. Only if that proves insufficient at our actual corpus size do we add an embedding layer — *next to*, not *instead of*, the lexical index.
