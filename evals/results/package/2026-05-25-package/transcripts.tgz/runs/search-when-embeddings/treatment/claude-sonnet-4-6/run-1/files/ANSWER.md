# Leadtype Docs Search: What You Already Have

## 1. What leadtype's docs search uses by default

Leadtype's search is **fully static and database-free by default**. At build
time, `leadtype generate` (or `generateDocsSearchFiles()`) produces two plain
JSON files:

```
public/docs/search-index.json   ← compact BM25 inverted index with term postings,
                                   document refs, and chunk refs
public/docs/search-content.json ← the actual chunk text, kept separate so the
                                   index loads on every search while content is
                                   fetched lazily for excerpts and answers
```

The **ranking function is BM25**, applied over heading-aware chunks of each
page. Field weights are tuned out of the box: titles 4×, headings 2×, body 1×,
code 0.35×. Each chunk maps to a heading-level slice of a page, so results jump
directly to the right section (with a hash URL), not just the right page.

At runtime, the `searchDocs()` helper from `leadtype/search` queries those two
JSON files **entirely in-process** — no network call, no database, no server.
It is edge-safe and works on Vercel, Cloudflare Workers, or any other runtime.
The query pipeline is not bare exact-match: it expands terms through lightweight
stemming, prefix matching, typo-tolerant fallbacks, and a small built-in synonym
map, while keeping exact matches at the highest weight so API names and config
keys stay precise.

Source-grounded AI answers (`streamDocsAnswer` / `createAnswerContext`) are also
built on top of the same static files — the retrieved chunks feed a constrained
prompt; there is no separate vector store or embedding lookup involved in the
default setup.

**Summary of the default stack:**

| Layer | What it is | Infrastructure required |
|---|---|---|
| Index | BM25 inverted index (JSON) | None — static file |
| Runtime | `searchDocs()` — in-process, edge-safe | None — no DB, no server |
| Ranking | BM25 + stemming + prefix + typo fallback + synonyms | None |
| AI answers (optional) | Chunks from the same static index → constrained LLM prompt | LLM API only |

---

## 2. When adding embeddings is actually warranted — and what to keep even then

Leadtype's own docs are explicit on this point
(`docs/reference/search.md`, "When to add embeddings"):

> *Start with the local index. It is static, cheap, edge-safe, and fast for
> exact API names, config keys, error messages, and paths.*

**Add embeddings only when both of these conditions are true:**

1. **Vocabulary mismatch** — users search with natural-language phrasing that
   does not overlap with your docs text (e.g. "make it faster" needs to match
   a page titled "performance optimization"). BM25 cannot bridge that gap
   because it requires shared tokens.

2. **Scale problem** — your docs corpus has grown past tens of thousands of
   chunks and the cold-start memory cost of loading the JSON index on every
   request becomes measurably noticeable. At normal docs-site scale (hundreds
   to a few thousand pages) this threshold is never reached.

**What to keep regardless:**

Even if you add a vector index for semantic recall, **keep the BM25 lexical
index and layer embeddings on top of it — they are complementary, not
replacements.** Exact API names, config keys, error codes, and file paths are
reliably served by lexical matching. Throwing those queries at a vector index
introduces noise and latency where precision is exactly what the user needs.
The recommended pattern is hybrid retrieval: lexical first (or in parallel),
semantic as a supplemental recall pass when lexical scores are low.

**The practical answer for your team:**

A hosted, database-backed vector index is not warranted for docs search until
you have demonstrated, with real user queries, that vocabulary mismatch is
causing missed results that cannot be fixed by adding synonyms to `searchDocs()`
— and you have grown to a corpus size where the static JSON approach strains
memory. Neither of those conditions requires standing up infrastructure in
advance. The default static BM25 approach ships zero infrastructure, costs
nothing to operate, and already handles stemming, prefix matches, and typo
tolerance out of the box.
