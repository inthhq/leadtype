# Leadtype docs search and embeddings

## 1. What leadtype uses by default

Leadtype docs search is **static and lexical by default**, not a hosted database-backed vector index.

In site mode, `leadtype generate` builds two files at build time:

- `public/docs/search-index.json` — a compact BM25 inverted index
- `public/docs/search-content.json` — the chunk text used for snippets and answer context

At runtime, `leadtype/search` imports or fetches those JSON files and queries them **without a database**. The index is edge-safe and dependency-free.

The default ranking is BM25 over heading-aware chunks, with field weights:

- title: 4×
- headings: 2×
- body: 1×
- code: 0.35×

It is not exact-token-only: leadtype also applies lightweight stemming, prefix matches, typo-tolerant fallbacks, and a small built-in synonym map. Product-specific aliases can be added when users search with terms the docs do not use.

Leadtype can also layer **source-grounded AI answers** on top of this same static index: it retrieves relevant chunks, builds a constrained prompt, and asks the model to answer only from retrieved docs with citations. That is RAG-style retrieval, but it still starts from the local static index rather than a vector database.

## 2. When embeddings are actually warranted

Start with leadtype’s local BM25 index. It is cheap, fast, static, edge-safe, and especially good for docs queries involving exact API names, configuration keys, error messages, CLI flags, and file paths.

Add embeddings only when at least one of these is true:

1. **Vocabulary mismatch is a real user problem.** Users search for intent or paraphrases that do not appear in the docs, such as “make it faster” when the relevant page says “performance optimization.”
2. **The corpus is very large.** The docs grow past tens of thousands of chunks and the cold-start memory cost of the local index becomes noticeable.

Even then, keep the lexical index. Embeddings should be layered on top as a complement, not used as a replacement, because lexical BM25 remains the reliable path for exact matches like API names, config keys, errors, and paths.
