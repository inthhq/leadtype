# Leadtype Docs Search: What You Already Get

## 1. What Leadtype Uses by Default

Leadtype's docs search is **static and lexical by default**, built entirely at compile time with zero runtime database dependencies:

### The Index
- **BM25-based full-text search** — a proven ranking algorithm that weights different content types:
  - Titles: 4× weight
  - Headings: 2× weight
  - Body text: 1× weight
  - Code: 0.35× weight

### The Architecture
- **Two JSON files generated at build time:**
  - `search-index.json` — compact ranking data, minimal size for every page load
  - `search-content.json` — actual chunk text, loaded lazily for excerpts and answers

- **Heading-aware chunking** — each heading becomes a separate searchable document, so results jump to the right section, not just the right page

### Query Features (No Database Required)
- **Stemming** — understands word variations ("run" matches "running", "ran")
- **Prefix matching** — "optim" finds "optimization"
- **Typo tolerance** — handles common misspellings
- **Synonym expansion** — small built-in synonym map, customizable with product-specific terms
- **Exact-match prioritization** — API names and config keys stay precise even with fuzzy matching

### What It's Good For
Perfect for:
- Exact lookups (API names, config keys, error messages)
- Common guide phrases ("How do I...?")
- Path-based navigation
- Projects up to tens of thousands of chunks
- Edge-safe deployment (Vercel, Cloudflare, etc.)

## 2. When to Add Embeddings (And What to Keep)

### Conditions That Actually Warrant Embeddings

Add embeddings **only when:**

1. **Vocabulary mismatch is a real problem** — users consistently search with terms that don't appear in your docs (e.g., "make it faster" when your docs say "performance optimization")
   
2. **Scale creates cold-start pain** — your docs exceed tens of thousands of chunks and the in-memory index becomes a noticeable cold-start hit on first search

### What You Must Keep Even After Adding Embeddings

**Keep the lexical index as your primary layer.** Embeddings are a complement, not a replacement:

- Keep BM25 for exact matches (API names, config keys, error messages must stay precise)
- Keep the static JSON files (they're cheap, edge-safe, and require zero infrastructure)
- Layer embeddings on top via re-ranking, not as the sole search mechanism
- Use embeddings to improve results for vocabulary-mismatched queries, not to replace lexical ranking

### Why Both Matter Together

The BM25 index is deterministic, fast, cheap, and works offline. Embeddings are fuzzy and require a model. Combined, you get:
- **Precision** from lexical search (catches exact API names)
- **Recall** from embeddings (catches conceptual matches)
- **No vendor lock-in** (you still have the static index if your embedding service goes down)
- **Minimal infrastructure** (use your existing docs pipeline, add embeddings only where they help)

---

**Bottom line:** Leadtype already gives you production-grade search. Before standing up a hosted vector database, verify that users actually need semantic search—not just better docs content or query synonyms.
