# What leadtype's Docs Search Uses By Default

## 1. Default Search Implementation

**Leadtype uses a static, locally-queryable BM25 search index by default.** It requires no database, no API calls, and no embeddings:

- **Build-time output:** Two JSON files
  - `search-index.json` — compact ranking data using the BM25 algorithm
  - `search-content.json` — actual chunk text for excerpts and answer context
  
- **Runtime:** Edge-safe JavaScript that queries these files locally
  - Works on Vercel, Cloudflare, and any browser/edge runtime
  - No external service calls required
  - Queries are instant and local

- **Query mechanism:** Lexical + semantic text processing
  - Exact token matching (API names, config keys stay precise)
  - Lightweight stemming
  - Prefix matching and typo-tolerant fallbacks
  - Small built-in synonym map
  - Optional product-specific synonym configuration

- **Ranking:** BM25 algorithm with weighted document fields
  - Titles: 4× weight
  - Headings: 2× weight
  - Body text: 1× weight
  - Code: 0.35× weight

## 2. When Adding Embeddings Is Actually Warranted

Add embeddings **only if both conditions are true**:

1. **Users search with vocabulary that doesn't match your docs** — e.g., "make it faster" should find a "performance optimization" page that doesn't use the word "faster." Lexical matching fails here.
   
2. AND

3. **Your docs have grown past tens of thousands of chunks** — making the cold-start memory hit of the lexical index noticeable.

## 3. What to Keep Even With Embeddings

**Always keep the lexical (BM25) index.** Embeddings should layer on top as a complementary system, not a replacement:

- Use the lexical index for exact matches first (API names, error messages, config keys)
- Fall back to or combine with embeddings for vocabulary mismatch
- They're complementary, not mutually exclusive

This hybrid approach gives you both precision (lexical) and semantic understanding (embeddings) without the cost of embeddings-only search.

---

## Summary

**The verdict:** You already have a production-ready, edge-safe search system that costs nothing to host, requires no database, and works out of the box for most docs. Before you invest in a hosted vector index, verify that your users actually encounter vocabulary gaps and that your docs have reached the scale where index size becomes a real problem. For typical-sized docs, the answer is "keep what you have."
