# What leadtype already gives us for docs search

## Default search model

Leadtype does **not** default to a hosted, database-backed vector index. Its docs search is static by default:

- At build time, `leadtype generate` in site mode writes:
  - `public/docs/search-index.json`
  - `public/docs/search-content.json`
- The runtime imports or fetches those JSON files and queries them **without a database**.
- The index is a static, edge-safe lexical index over docs chunks.
- Ranking uses **BM25** over heading-aware chunks:
  - titles: 4× weight
  - headings: 2× weight
  - body: 1× weight
  - code: 0.35× weight
- Search is not just exact-token matching. It includes lexical matching, lightweight stemming, prefix matches, typo-tolerant fallbacks, and a small built-in synonym map.
- The content store is split from the index so the index can stay small while chunk text remains available for snippets and source-grounded answers.

Leadtype can also stream AI answers, but those answers are layered on top of the same static retrieval path: it retrieves chunks from the static index, builds a constrained/source-grounded prompt, and lets the chosen provider stream the answer.

## When embeddings are actually warranted

Start with leadtype's local static index. It is cheap, edge-safe, fast, and especially good for exact API names, config keys, error messages, paths, and other docs-search queries where precision matters.

Add embeddings only when one of these conditions is true:

1. **Users search with vocabulary that does not match the docs.**  
   Example: users type "make it faster" but the docs say "performance optimization."

2. **The docs grow past tens of thousands of chunks and cold-start memory becomes noticeable.**

Even then, embeddings should be layered **on top of** leadtype's lexical index, not used as a replacement. Keep the lexical/BM25 index for exact matches, API names, config keys, error messages, paths, snippets, and source grounding; use embeddings only to improve semantic recall where lexical search is insufficient.
