# Leadtype docs search and embeddings

Leadtype does **not** require a hosted, database-backed vector index by default.

By default, Leadtype docs search is a **static, local, edge-safe lexical search index** generated at build time. In site mode, `leadtype generate` writes:

- `public/docs/search-index.json` — a compact BM25-ranked inverted index with term postings, document refs, and chunk refs.
- `public/docs/search-content.json` — the chunk text used for snippets, excerpts, content reads, and source-grounded answer context.

At runtime, `searchDocs()` imports or fetches those JSON files and queries them without a database. The index is chunk-based and heading-aware, so results can jump to a specific section. Ranking uses BM25, with titles, headings, body text, and code weighted differently. Search is not limited to exact tokens: it also includes lightweight stemming, prefix matches, typo-tolerant fallbacks, a small built-in synonym map, and optional product-specific `synonyms`.

Leadtype can also stream source-grounded AI answers, but those are layered on top of the static search index: it retrieves chunks from the static index, builds constrained context, and passes that to the model/provider. The model should answer from retrieved docs context and cite returned sources, not answer from memory.

## When embeddings are warranted

Start with Leadtype's local lexical index. It is static, cheap, fast, edge-safe, and especially good for exact API names, config keys, error messages, paths, and other docs-search queries where wording matters.

Add embeddings only when one of these is true:

1. **Users consistently search with vocabulary that does not appear in the docs.**  
   Example: users search for "make it faster" but the docs use "performance optimization." Before adding embeddings, also consider Leadtype's supported synonym aliases for product-specific vocabulary gaps.

2. **The docs corpus grows past tens of thousands of chunks and the cold-start memory cost of the static index becomes noticeable.**

Even then, keep Leadtype's lexical/BM25 index. Embeddings should be layered on top for semantic recall, not used as a replacement. The lexical index remains the right tool for exact matches, identifiers, config names, error strings, filenames, routes, and other precision-sensitive queries.
