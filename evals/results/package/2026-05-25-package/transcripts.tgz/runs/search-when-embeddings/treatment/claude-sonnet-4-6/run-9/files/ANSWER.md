# Leadtype Docs Search — What You Already Have

## 1. What leadtype's docs search uses by default

Leadtype ships a **fully static, database-free, BM25 lexical search engine** — no hosted index, no vector database, no embeddings, no external service.

### How it works end-to-end

| Stage | What happens |
|---|---|
| **Build time** | `generateDocsSearchFiles()` (or `npx leadtype generate`) reads your converted MDX/Markdown and writes exactly two plain JSON files: `search-index.json` and `search-content.json`. |
| **Runtime** | `searchDocs(index, query, { content })` queries those two files in memory. No network call, no database round-trip. |
| **Deployment target** | Edge-safe — runs identically on Vercel Edge, Cloudflare Workers, Node, or any other JS runtime. |

### What the index actually does

- **Chunk granularity** — pages are split into heading-aware chunks so results link to the exact section, not just the page.
- **BM25 ranking** with tuned field weights: titles 4×, headings 2×, body prose 1×, code blocks 0.35×.
- **Query expansion** — lightweight stemming, prefix matching, typo-tolerant fallbacks, and a built-in synonym map, so results aren't restricted to exact tokens.
- **Custom synonyms** — pass a `synonyms` map to `searchDocs()` for product-specific vocabulary (e.g. `starter → ["quickstart", "getting started"]`).
- **Split file design** — `search-index.json` (compact term postings, loaded on every search) is kept small; `search-content.json` (actual chunk text) is loaded lazily for snippets and answer context only.

### Optional AI-answer layer (still no vector DB)

When basic search is working, leadtype can stream grounded answers by:
1. Retrieving the relevant chunks from the **same static index** via `createAnswerContext()`.
2. Building a constrained prompt that instructs the model to answer only from those chunks and cite sources.
3. Streaming through whichever runtime adapter matches your deploy target (`leadtype/search/vercel`, `/cloudflare`, `/tanstack`).

This is retrieval-augmented generation, but the "retrieval" step is the local BM25 index — not a vector database.

---

## 2. When embeddings are actually warranted — and what to keep even then

The docs are explicit on this. Add embeddings **only when both of the following real-world problems appear:**

### Condition A — Vocabulary mismatch at scale
Users consistently search with language that does not appear in the docs. Classic example: a user types *"make it faster"* but the relevant page is titled *"Performance optimization."* BM25 finds nothing because no term overlaps. A semantic/embedding index can bridge that gap.

> This is the actual signal to watch for. Vocabulary mismatch is a discovered problem, not an assumed one — instrument your search UI's zero-result rate first.

### Condition B — Corpus size causes a cold-start memory problem
The static files grow past **tens of thousands of chunks** and the memory overhead of loading the full index on a cold edge function start becomes measurably noticeable.

### What to keep even when you add embeddings

**Keep the lexical BM25 index regardless.** The docs are unambiguous:

> *"Even then, keep the lexical index for exact matches and layer embeddings on top — they're complementary, not replacements."*

Why this matters in practice:
- Exact API names, CLI flags, config keys, error codes, and file paths match perfectly via BM25 and are **degraded** by semantic similarity (embeddings will pull in "related" but wrong results for a precise token like `--out-dir`).
- The lexical index is free to run, has zero latency overhead on an in-flight request, and requires no external service or embedding model.
- The right architecture is **hybrid retrieval**: lexical first (always on, high precision for exact terms) + semantic layer on top (engaged when lexical returns weak or no results for open-ended queries).

### What you should not do

- Do **not** replace the static index with a hosted vector database as a first step. You would be trading zero infrastructure for a hosted service, an embedding model call on every query, a network round-trip, and ongoing cost — before you have evidence the current approach falls short.
- Do **not** assume RAG requires a vector database. Leadtype already implements RAG: it retrieves chunks from a static index and grounds a model's answer in them. The vector database is one possible retrieval back-end, not a prerequisite for RAG.
