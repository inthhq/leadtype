# Leadtype Docs Search — What You Already Have

## 1. What leadtype's docs search uses by default

Leadtype ships a **fully static, database-free, edge-safe search engine built on BM25** — no vector database, no embeddings, no external service required.

### How it works end-to-end

| Phase | What happens |
|---|---|
| **Build time** | `leadtype generate` (or `generateDocsSearchFiles()`) reads all converted markdown under your output directory and writes two JSON files: `search-index.json` and `search-content.json`. |
| **Runtime** | Your code imports or fetches those two files and calls `searchDocs(index, query, { content })` entirely in-process — no network hop, no database round-trip. |

### What the index contains

- **`search-index.json`** — a compact BM25 inverted index with term postings, document refs, and chunk refs. It stays small so it can be loaded on every search interaction.
- **`search-content.json`** — the actual chunk text, stored separately so you can search without loading it upfront, then fetch it lazily for result snippets and answer context.

### How chunks are built and ranked

Documents are split into **heading-aware chunks**, so a result jumps to the right *section*, not just the right page. BM25 ranks terms with weighted fields:

| Field | Weight |
|---|---|
| Title | 4× |
| Headings | 2× |
| Body | 1× |
| Code | 0.35× |

### Query expansion that ships out of the box

The runtime is not exact-token-only. Every query automatically passes through:

- **Stemming** — "running" matches "run"
- **Prefix matching** — partial words still find results
- **Typo-tolerant fallbacks** — small edit distances are handled
- **A built-in synonym map** — common term variants are covered without configuration

Exact matches keep the highest weight, so API names, config keys, and error messages stay precise. You can add product-specific synonyms via a `synonyms` option when your docs use vocabulary the library hasn't seen.

### Deployment characteristics

- **Zero runtime dependencies** — the `leadtype/search` core imports no Node APIs; it runs on Vercel Edge, Cloudflare Workers, and any other edge/serverless runtime.
- **No database to stand up, migrate, or pay for.**
- **No embedding model to call at query time.**
- **Doubles as a virtual filesystem** — `listDocsContentFiles`, `readDocsContentFile`, and `readDocsContentChunk` let agents and answer pipelines explore docs without pre-selected chunks.

### Optional AI answers — already built in

If you want LLM-powered answers on top of this index, leadtype already includes that too. `createAnswerContext` turns the query + retrieved chunks into a grounded system/prompt pair, and thin provider wrappers (`leadtype/search/vercel`, `/tanstack`, `/cloudflare`) stream a response. **This is layered on the same static index** — still no vector database needed.

---

## 2. When embeddings are actually warranted — and what to keep even then

The authoritative guidance from leadtype's own reference docs is direct:

> *"Start with the local index. It is static, cheap, edge-safe, and fast for exact API names, config keys, error messages, and paths."*

### Add embeddings only when **both of these conditions are true**:

1. **Vocabulary mismatch at scale** — Users are searching with natural-language phrasing that doesn't textually overlap with your docs. The canonical example: a user types *"make it faster"* and the relevant page is titled *"Performance Optimization"*. BM25 won't bridge that gap. Embeddings capture semantic intent.

2. **Corpus size crosses a meaningful threshold** — Your docs grow past **tens of thousands of chunks** and the cold-start memory cost of loading the index becomes noticeable in practice.

If only one condition is true, the mitigation is cheaper than embeddings: add `synonyms` entries for the vocabulary gaps you observe, or split your index by section.

### What you must keep even when you add embeddings

**Keep the lexical BM25 index and run both in parallel.** Embeddings and lexical search are *complementary*, not replacements:

- The lexical index wins on **exact matches** — API names, CLI flags, config keys, error codes, specific file paths. These are the highest-intent queries in a developer docs context, and embeddings frequently *under-rank* them relative to semantically similar but less relevant results.
- Embeddings win on **semantic/natural-language queries** where the user's words don't appear verbatim in the docs.

A hybrid retrieval approach (BM25 for precision, embeddings for recall) outperforms either alone. Throwing away the lexical index in favor of a pure vector store is a regression for the queries that matter most to developers.

### The practical upshot for your team

Before standing up a hosted vector database:

1. **Verify the lexical index actually fails your users.** Run real queries against `searchDocs`. If the results are correct, you're done.
2. **Check the corpus size.** Unless you have tens of thousands of chunks, cold-start is not your bottleneck.
3. If you do reach that threshold, add embedding retrieval *on top of* the static index — don't replace it. The static files remain the source of truth for chunk text, exact matching, and offline/edge use.
