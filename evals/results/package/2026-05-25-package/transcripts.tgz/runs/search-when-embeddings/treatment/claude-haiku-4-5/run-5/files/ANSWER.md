# Leadtype's Default Docs Search

## 1. What leadtype gives you by default

Leadtype provides a **static, edge-safe, BM25-based lexical search index** that requires no database or external services.

### How it works:

- **Build time**: Markdown is chunked (heading-aware slices), indexed with BM25 ranking, and written to two JSON files:
  - `search-index.json` — compact term postings and ranking data
  - `search-content.json` — the actual chunk text for excerpts and answer context

- **Ranking**: BM25 with document-specific weights:
  - Titles: 4×
  - Headings: 2×
  - Body text: 1×
  - Code: 0.35×

- **Runtime**: The index is imported/fetched and queried entirely client-side or at the edge (Vercel, Cloudflare, etc.) — no database lookups, no cold starts, no per-request latency.

### Query features (built-in, no configuration needed):

- Exact matches (highest weight — API names and config keys stay precise)
- Stemming (e.g., "running" matches "run")
- Prefix matches (e.g., "install" matches "installer")
- Typo-tolerant fallbacks
- Small built-in synonym map
- Optional product-specific synonyms you can add

### Chunking:

Each heading-aware slice is a separate document in the index, so search results jump to the right section, not just the right page. The index splits concept/lookup from content — you can search cheaply without loading all text.

---

## 2. When embeddings are actually warranted — and what to keep

**Start with the default lexical index. Add embeddings only when:**

1. **Users search with vocabulary that doesn't match your docs** — e.g., users type "make it faster" but your docs use "performance optimization."
2. **Your docs grow past tens of thousands of chunks and cold-start memory becomes noticeable** — the lexical index is fast, but at massive scale you may want approximate search.

**Even when you add embeddings:**

- **Keep the lexical index.** They are complementary, not replacements. BM25 is superior for exact matches (API names, error codes, configuration keys, paths) and provides fast, deterministic fallback when embeddings fail to disambiguate.
- **Use both in a hybrid search** — retrieve with lexical first, rerank with embeddings if needed, or blend results.
- **You still need source-grounded answers** — the same answer-context pipeline works with both lexical and embedding-backed retrieval.

The default search index is cheap, edge-safe, fast, and accurate for all the cases where users have the right keywords. Embeddings add cost (model calls, vector DB queries, cold-start latency) and noise. Add them only when you observe the problem they solve, and layer them on top of what already works.
