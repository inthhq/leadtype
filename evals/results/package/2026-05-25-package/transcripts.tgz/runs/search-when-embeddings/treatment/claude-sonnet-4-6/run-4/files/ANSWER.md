# What leadtype Already Gives Us for Docs Search

## 1. What leadtype's docs search uses by default

leadtype's search is **fully static and database-free by default**. At build time,
`generateDocsSearchFiles` (or `npx leadtype generate`) produces two plain JSON
files:

```
public/docs/search-index.json    ← compact term postings + ranking data
public/docs/search-content.json  ← raw chunk text for excerpts & answer context
```

At runtime, `searchDocs` (from `leadtype/search`) queries those files directly
in the browser or on an edge runtime — no server round-trip, no database, no
embedding model, no external API call.

Under the hood the default pipeline does the following automatically:

| Capability | How it works out of the box |
|---|---|
| **Indexing unit** | Heading-aware *chunks* — each heading section is a separate index document, so results link to the exact section, not just the page |
| **Ranking function** | BM25 with field weights: titles 4×, headings 2×, body 1×, code 0.35× |
| **Query expansion** | Lightweight stemming, prefix matching, typo-tolerant fallbacks, and a built-in synonym map |
| **Exact-match bias** | Exact token hits keep the highest weight, so API names, config keys, and error strings rank precisely |
| **Custom synonyms** | Pass a `synonyms` map to `searchDocs` for product-specific vocabulary without touching the index |
| **Edge safety** | No Node APIs; runs on Vercel Edge, Cloudflare Workers, or any standard runtime |
| **Split loading** | The index is loaded first (small); content is loaded lazily for hover previews and AI answer context |
| **AI answers (optional)** | `createAnswerContext` / `streamDocsAnswer` retrieves chunks from the *same static index*, builds a constrained prompt, and streams a source-grounded answer — still no vector DB required |

The upshot: you get a fast, precise, dependency-free search index for free as
part of the normal build. There is nothing to host, provision, or keep in sync.

---

## 2. When adding embeddings is actually warranted — and what to keep

The leadtype docs state this directly in the Search reference:

> *Start with the local index. It is static, cheap, edge-safe, and fast for
> exact API names, config keys, error messages, and paths. Add embeddings only
> when:*

### Condition A — Vocabulary mismatch at scale

A user searches **"make it faster"** but your docs say **"performance
optimization."** The BM25 index can't bridge that gap because the terms don't
overlap. If you're seeing consistent zero-result or low-relevance queries caused
by vocabulary mismatch — not just one-off cases you could fix with a `synonyms`
entry — that's the signal that semantic embeddings would add real value.

### Condition B — Very large corpora with noticeable cold-start cost

The static index is loaded into memory on every cold start. If your docs grow
**past tens of thousands of chunks** and that memory hit becomes perceptible to
users (measurably slow first-query latency), offloading retrieval to a vector
index can reclaim that startup time.

### What to keep even when you add embeddings

**Keep the lexical index regardless.** Embeddings and BM25 are complementary,
not alternatives:

- The lexical index stays precise for **exact matches**: API names, CLI flags,
  config keys, error codes, and file paths. These are exactly the terms where
  embedding similarity is weakest (e.g. `--dry-run` and `--wet-run` may be
  semantically close in embedding space even though they mean opposite things).
- A standard production pattern is **hybrid retrieval**: run both lexical and
  vector search in parallel, then fuse the ranked results (e.g. Reciprocal Rank
  Fusion) before passing chunks to the answer context.

### Summary verdict for the team

The "RAG needs a vector database" assumption is not true here. leadtype already
implements the retrieval half of RAG — static BM25 chunks fed into
`createAnswerContext` — with zero infrastructure. Before standing up a hosted
vector index, confirm you have *measured* one of the two conditions above:
real vocabulary-mismatch misses that synonyms can't cover, or a provably
slow cold-start on a genuinely large corpus. Until then, the static index is
the right default, and adding a vector store would add operational cost and
complexity without improving the results developers and users actually care about
most (exact API lookups).
