# Leadtype Docs Search — What We Already Have

## 1. What leadtype's docs search uses by default

Leadtype ships a **fully static, database-free search engine** built on **BM25** (term-frequency/inverse-document-frequency ranking). No external service, no vector database, no embeddings model — just two plain JSON files written once at build time and queried entirely at runtime in memory.

### How it works end-to-end

**Build time** — `generateDocsSearchFiles()` (or `npx leadtype generate`) reads your converted markdown and writes two files:

```
public/docs/search-index.json   ← compact BM25 postings, term index, document/chunk refs
public/docs/search-content.json ← raw chunk text for excerpts and answer context
```

The index is split from the content store deliberately: the index is small enough to load on every search request; content is loaded lazily only when a result is hovered or an AI answer is generated.

**The index is chunk-aware**: each heading-delimited section of a page is a separate document in the index, so results jump directly to the right heading, not just the right page.

**Field weights are tuned for docs**: titles rank 4×, headings 2×, body copy 1×, code blocks 0.35×, keeping API names and config keys precise.

**Runtime query expansion** layers on top of exact matching so the engine is not limited to literal token matches:

| Technique | What it covers |
|---|---|
| Stemming | "running" → "run", "configured" → "configure" |
| Prefix matching | Partial API names typed so far |
| Typo-tolerant fallbacks | Small edit-distance mismatches |
| Built-in synonym map | Common equivalents already known |
| Custom `synonyms` option | Product-specific vocabulary you add per-query |

Exact matches keep the highest weight, so precise API names and error codes are never outranked by fuzzy results.

**The runtime is edge-safe** — no Node.js APIs, no network calls, works on Vercel Edge, Cloudflare Workers, and any other edge environment. `searchDocs()` is imported directly from `leadtype/search` alongside the two JSON files.

**Optional AI answers are layered on top** via `createAnswerContext` / `streamDocsAnswer` (Vercel, TanStack, Cloudflare adapters). These build a context window from *already-retrieved BM25 chunks* and pass it to a model with a system prompt that restricts the answer to that context. The model is a citation layer over the static index — it does not replace it, and it is explicitly optional.

---

## 2. When embeddings are actually warranted — and what to keep even then

Leadtype's own reference documentation states the condition precisely:

> **"Start with the local index. It is static, cheap, edge-safe, and fast for exact API names, config keys, error messages, and paths. Add embeddings only when:**
>
> * **Users search with vocabulary that doesn't match the docs** (e.g. "make it faster" matching a "performance optimization" page).
> * **Your docs grow past tens of thousands of chunks** and the cold-start memory hit becomes noticeable."

In practice, this means embeddings are warranted only when **both of the following are true**:

1. **You have real evidence of vocabulary mismatch** — users are consistently failing to find content not because they misspelled a term, but because they describe concepts with language your docs don't literally use (semantic paraphrase gap). This is something you discover from search-failure analytics, not something you assume in advance.

2. **Your corpus has actually scaled to tens of thousands of chunks** — at smaller scales the JSON files load instantly and the memory footprint is negligible.

### What to keep even if you add embeddings

Even when those thresholds are met, **the lexical BM25 index should be kept and remain the primary layer**. Embeddings are *complementary*, not a replacement:

- BM25 is unbeatable for **exact string matches** — API method names, CLI flags, error codes, config key names. Semantic similarity models can actually *hurt* precision on these because they treat near-synonyms as equivalent.
- The static index is **free to query** (no embedding inference cost per request), **zero-latency** (local JSON, no round trip), and **fully auditable** (you can read the postings directly).
- The correct architecture is **hybrid retrieval**: run the lexical index first (or in parallel), use embeddings to catch the semantic paraphrase cases it misses, then merge or re-rank results. Throwing away BM25 in favour of a pure vector database loses the precision that makes API reference search reliable.

### What this means for the proposed hosted vector database

A hosted, database-backed vector index is not warranted yet. The search capability already available — static BM25 with stemming, prefix matching, typo tolerance, synonym expansion, and optional LLM answer streaming grounded in retrieved chunks — covers the vast majority of real documentation search needs at zero infrastructure cost. Before standing up a vector database, the right next step is to ship the static search, collect actual query failure data, and check whether failures are caused by vocabulary mismatch (the one gap embeddings address). If they are, add a hybrid layer *on top* of the existing index — don't replace it.
