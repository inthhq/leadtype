# Docs search with `leadtype`: what we already have

Before standing up a hosted, DB-backed vector index, here's what `leadtype` ships out of the box and the narrow conditions where embeddings actually pay for themselves.

## 1. What leadtype's docs search uses by default

Leadtype search is **static, local, and database-free**. There is no service to run and nothing to host beyond the static files themselves.

**Build time** — `leadtype generate` (or `generateDocsSearchFiles` from `leadtype/search/node`) walks the converted markdown and writes two JSON files:

- `public/docs/search-index.json` — compact tuple-format **BM25 index** with term postings, document refs, and chunk refs. Documents are **heading-aware chunks**, so results jump to the right section, not just the right page. Weighting is title 4× / headings 2× / body 1× / code 0.35×.
- `public/docs/search-content.json` — the actual chunk text, kept separate so search can run without loading content; content is read lazily for excerpts and answers.

**Runtime** — `searchDocs(index, query, { content })` from `leadtype/search` is **edge-safe** (no Node APIs; runs on Vercel, Cloudflare, etc.). It does **not** require exact-token matches. Query terms expand through:

- lightweight stemming
- prefix matches
- typo-tolerant fallbacks
- a small built-in synonym map (extendable per-call via the `synonyms` option for product-specific vocabulary)

Exact matches keep the highest weight, so API names, config keys, error strings, and paths stay precise.

**Optional source-grounded answers** layer on top of the same static index via `createAnswerContext` and provider-specific streamers (`leadtype/search/vercel`, `/tanstack`, `/cloudflare`). They retrieve chunks from the static index, build a constrained prompt that forbids answering from memory, require `[1]`-style citations, and return `sources` metadata separately for citation UI. There is still no vector DB in this path.

Request-path utilities (`validateDocsQuery`, `readJsonWithLimit`, `getClientIdentifier`, `createMemoryRateLimiter`) are provided for guarding the endpoint; production should back the rate limiter with a shared store (Redis / KV / Durable Objects).

**Net effect:** for exact API names, config keys, error messages, and paths — the bulk of real docs queries — we already have fast, cheap, edge-deployable search and grounded AI answers with zero infrastructure beyond static JSON.

## 2. When adding embeddings is actually warranted

Per leadtype's own guidance, add embeddings **only** when one of these is true:

1. **Vocabulary mismatch is hurting recall.** Users routinely search with words the docs don't use — e.g. "make it faster" should match a "performance optimization" page — and per-call `synonyms` aren't enough to keep up.
2. **Scale crosses the threshold.** Docs grow past **tens of thousands of chunks** and cold-start memory or index load becomes noticeable.

If neither condition holds, a hosted vector index is overhead, not progress. "That's how RAG is done" is not one of the conditions.

### What to keep even then

**Keep the lexical BM25 index** and layer embeddings on top of it. They are **complementary, not a replacement**:

- BM25 / the static index stays best at exact API names, config keys, error strings, and paths — where embeddings routinely miss.
- Embeddings cover the semantic / paraphrase gap.

Also keep the heading-aware chunking, the separated index/content split, the edge-safe runtime, and the source-grounded answer pipeline (`createAnswerContext` + provider streamers with mandatory citations). A vector store, if added, should plug into retrieval — not replace the answer-context construction, citation contract, or abuse guards we already have.

## Recommendation

Ship the static index first (it's two JSON files and a function call). Instrument query logs. Only if we see persistent vocabulary-mismatch failures or cross the tens-of-thousands-of-chunks threshold do we add embeddings — and even then, as a second retriever alongside BM25, not as a replacement for the current pipeline.
