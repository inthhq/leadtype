# What leadtype Already Gives Us for Docs Search

## 1. What leadtype's docs search uses by default

Leadtype ships a **fully static, database-free search engine** that requires no external infrastructure at all. Here is exactly how it works, end-to-end:

### Build time
Running `leadtype generate` (or calling `generateDocsSearchFiles()` from `leadtype/search/node`) produces two plain JSON files:

| File | Purpose |
|---|---|
| `public/docs/search-index.json` | Compact **BM25** term postings, document refs, and chunk refs — the data needed to run a ranked search. |
| `public/docs/search-content.json` | The raw chunk text used for snippets and answer context. Kept separate so the index can load on every search while content loads lazily. |

**BM25 ranking weights are pre-tuned:** titles 4×, headings 2×, body 1×, code 0.35×. These are tunable in the generator but work well out of the box.

### Indexing unit
The index is **chunk-aware**: each page is split into heading-scoped slices. Search results therefore jump directly to the right *section* (with a `#hash` URL), not just the right page.

### Runtime
`searchDocs()` from `leadtype/search` runs entirely in memory against those two JSON files — no network call, no database, no server process. It is **edge-safe** (no Node APIs) and works on Vercel, Cloudflare Workers, and anywhere else. Query terms are expanded through:
- Lightweight **stemming**
- **Prefix matches**
- **Typo-tolerant fallbacks**
- A small built-in **synonym map** (exact matches retain the highest weight, so API names and config keys stay precise)

Product-specific synonyms can be added via a `synonyms` option passed to `searchDocs()` — no re-indexing required.

### Optional AI answers (still layered on the static index)
`streamDocsAnswer()` (via `leadtype/search/vercel`, `/tanstack`, or `/cloudflare`) retrieves chunks from the **same static index**, builds a source-constrained prompt, and streams a grounded answer. The model is told to answer only from retrieved context and to say so when that context is insufficient. This is opt-in and additive — the static search layer stays in place underneath it.

**The bottom line:** the default is static files + BM25 + in-memory query. Zero database, zero vector store, zero hosted infrastructure required.

---

## 2. When embeddings are actually warranted — and what to keep even then

The leadtype docs are explicit on this point (`docs/reference/search.md`, "When to add embeddings"):

### Add embeddings only when **both** conditions apply:

1. **Vocabulary mismatch at scale** — users search with language that doesn't appear in the docs (e.g. "make it faster" needs to surface a "performance optimization" page). Lexical search with BM25, stemming, and synonym expansion handles a wide range of surface variation; embeddings are warranted only when that gap is genuinely large and measurable in user queries.

2. **Index size pressure** — the docs corpus has grown past **tens of thousands of chunks** and the cold-start memory cost of loading the JSON index becomes noticeable in practice.

If only one condition is true, the mitigation is cheaper than embeddings: add explicit `synonyms` entries for vocabulary gaps, or split the content store to defer content loading for size pressure.

### What to keep regardless

Even if both conditions are met and a vector index is added, **keep the lexical BM25 index and run both in parallel.** The docs state this directly: *"keep the lexical index for exact matches and layer embeddings on top — they're complementary, not replacements."*

The reason is straightforward: embeddings are weak at exact-token retrieval (API names, CLI flags, config keys, error codes, file paths). BM25 is strong there. A hybrid approach — lexical for precision, semantic for recall on fuzzy vocabulary — outperforms either one alone. Replacing the static index with a hosted vector database discards the precision half of the equation, adds operational overhead, and solves a problem you may not have yet.

### What this means for the team's proposal

Before standing up any hosted vector infrastructure, verify that the two warranting conditions above actually exist in your usage data. If users are searching for exact API names and getting good results, the static index is already doing the right job. The cost of a hosted, database-backed vector index (latency, operational complexity, cold-start for embeddings, cost) is only justified after the static-first baseline is running and measured — and even then, it supplements rather than replaces the BM25 layer leadtype already provides.
