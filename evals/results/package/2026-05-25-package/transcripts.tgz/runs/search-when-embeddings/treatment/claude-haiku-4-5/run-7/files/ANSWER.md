# What leadtype Gives You for Docs Search

## 1. Default Search: Static BM25 Index

By default, `leadtype` builds a **static, edge-safe search index** using **BM25** ranking — no database required.

### How it works:
- At build time, `leadtype generate` produces two JSON files:
  - `search-index.json` — compact ranking data (terms, postings, document/chunk references)
  - `search-content.json` — actual chunk text for excerpts and answer context
- At runtime, the `searchDocs()` function queries these files locally (no network round-trip to a database)
- Results are heading-aware: each heading gets its own index entry, so search jumps to the right section, not just the page

### Search capabilities out of the box:
- **Lexical matching** with stemming, prefix matches, and typo-tolerant fallbacks
- **Weighted relevance**: titles 4×, headings 2×, body 1×, code 0.35×
- **Built-in synonym map** for common terms; extendable with domain-specific synonyms
- **Optional source-grounded AI answers** via provider entry points (Vercel, TanStack, Cloudflare)
- **Edge-safe runtime** — works on Vercel, Cloudflare, and anywhere without Node APIs

### Why this matters:
- ✅ Static files = deploy to a CDN, not a database
- ✅ Fast & cheap = no cold-start latency, no per-query costs
- ✅ Ship inside npm packages = version-matched docs offline
- ✅ Works everywhere = runs on serverless, edge, and browser

---

## 2. When to Add Embeddings (And What to Keep)

### Only add embeddings when:

1. **Users search with vocabulary that doesn't match your docs**
   - Example: users type "make it faster" but your docs say "performance optimization"
   - The lexical index won't match; embeddings bridge that gap

2. **Docs scale past tens of thousands of chunks**
   - Memory footprint of the loaded index becomes noticeable
   - Embeddings let you pre-filter to a smaller candidate set

### What you must keep even with embeddings:

- **The static BM25 index** — embeddings should *layer on top*, not replace it
- **Exact match weighting** — API names, config keys, error messages, and paths must stay precise (embeddings are fuzzy)
- **The content store** — chunks are still read for excerpts, context, and answer grounding
- **The edge-safe runtime** — don't move to a hosted database that requires authentication, regions, or online access

### How to layer them:
- Use embeddings as a **pre-filter** (semantic reranking) on top of lexical results
- Run BM25 first to catch exact matches, then use embeddings to rerank or expand results
- Keep both available — let users choose the ranking strategy if needed

---

## Bottom line

**Don't pay for a hosted vector database to host your docs.** Start with leadtype's static search — it's faster, cheaper, and works offline. Add embeddings only when lexical search genuinely fails your users, and even then, run them on top of the index you already have.
