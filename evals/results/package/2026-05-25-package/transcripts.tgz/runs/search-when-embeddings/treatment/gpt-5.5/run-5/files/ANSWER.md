# Leadtype docs search: default vs. embeddings

## What Leadtype uses by default

Leadtype's docs search is **static and database-free by default**.

At build time, `leadtype generate` / `generateDocsSearchFiles()` writes two files:

- `public/docs/search-index.json` — a compact static search index.
- `public/docs/search-content.json` — the chunk text used for snippets and answer context.

At runtime, app code imports or fetches those JSON files and calls `searchDocs()` from `leadtype/search`. The runtime is edge-safe and does not require a hosted search service, vector database, or Node-only APIs.

The index is **lexical/BM25-based**, not embedding-based. It indexes heading-aware chunks so results can link directly to the relevant section. Ranking weights titles most heavily, then headings, body text, and code. Search also includes lightweight query expansion: stemming, prefix matches, typo-tolerant fallbacks, a small built-in synonym map, and optional product-specific synonyms.

Leadtype can also layer **source-grounded AI answers** on top of this same static index: it retrieves relevant chunks, builds constrained answer context, and streams via provider-specific adapters. The model should answer from retrieved docs context and cite the returned sources, not answer from memory.

## When embeddings are actually warranted

Start with Leadtype's local static index. It is cheap, fast, edge-safe, and especially good for docs queries involving exact API names, config keys, error messages, commands, paths, and headings.

Add embeddings only when one of these is true:

1. **Users search with meaning that does not share vocabulary with the docs.**
   Example: users type "make it faster" but the docs call the topic "performance optimization." If synonym aliases are not enough, semantic retrieval can help.

2. **The docs grow beyond tens of thousands of chunks and the static index's cold-start memory cost becomes noticeable.**
   At that scale, a hosted retrieval layer may be useful for operational reasons.

Even then, keep Leadtype's lexical index. Embeddings should be layered on top, not used as a replacement. The lexical index remains the right tool for exact matches, API names, config keys, commands, error strings, and paths, while embeddings can supplement it for semantic/vocabulary-mismatch queries.
