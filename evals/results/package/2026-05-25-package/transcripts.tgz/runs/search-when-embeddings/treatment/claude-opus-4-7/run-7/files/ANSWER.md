# Do we need a hosted vector DB for docs search?

Short answer: **no, not by default.** `leadtype` already ships a docs search system. Stand that up first; only consider embeddings if you hit one of the two specific conditions below.

## 1. What `leadtype` gives us by default

Leadtype builds a **static, edge-safe lexical search index** over your docs at build time and queries it at runtime with no database.

**Build time** (`leadtype generate`, or `generateDocsSearchFiles` from `leadtype/search/node`) produces two JSON files under `public/docs/`:

- `search-index.json` — compact tuple format: term postings, document refs, and chunk refs. Loaded on every search.
- `search-content.json` — the chunk text, kept separate so the index stays small and content is loaded lazily for excerpts/answers.

**Indexing model:**

- Pages are sliced into **heading-aware chunks**, so results jump to the right section, not just the right page.
- Ranking is **BM25**, with field weights: titles 4×, headings 2×, body 1×, code 0.35×.

**Runtime** (`searchDocs` from `leadtype/search`) is edge-safe (no Node APIs — runs on Vercel, Cloudflare Workers, etc.) and is **not** exact-token-only. Out of the box it does:

- Lightweight stemming
- Prefix matches
- Typo-tolerant fallbacks
- A small built-in synonym map (extendable via the `synonyms` option for product-specific vocabulary)
- Exact matches still get the highest weight, so API names, config keys, and error strings stay precise.

The same index doubles as a virtual filesystem (`listDocsContentFiles`, `readDocsContentFile`, `readDocsContentChunk`), and is reusable for:

- **Source-grounded LLM answers** via `createAnswerContext` + provider streaming wrappers (`leadtype/search/vercel`, `/tanstack`, `/cloudflare`) — the model is constrained to answer from retrieved chunks and cite `[1]`-style sources.
- **Agent bash-style exploration** via `createDocsBashTool` (read-only `ls`/`cat`/`find`/`grep`/`rg` over a virtual `/docs`).

Request-path helpers (`validateDocsQuery`, `readJsonWithLimit`, `getClientIdentifier`, `createMemoryRateLimiter`) are included for guarding query endpoints.

**Net effect:** no database, no hosting cost for an index service, no cold-start vector lookups. Two static JSON files served from the edge.

## 2. When embeddings are actually warranted

Per the upstream guidance in `leadtype/docs/reference/search.md` ("When to add embeddings"), add embeddings **only** when one of these is true:

1. **Vocabulary mismatch is hurting recall.** Users routinely search with words that don't appear in the docs — e.g. "make it faster" needs to find a page titled "performance optimization" — and product-specific `synonyms` aren't enough to bridge the gap.
2. **Scale problems.** The corpus grows past *tens of thousands of chunks* and the cold-start memory cost of loading the lexical index becomes noticeable in the runtime environment.

If neither condition holds, a hosted vector index is premature. The lexical index is cheap, fast, and strong on the queries that dominate docs search: exact API names, config keys, error messages, and file paths — exactly where embeddings tend to be *worse*.

### What to keep even if we do add embeddings

**Keep the lexical index.** Embeddings are layered *on top*, not substituted in:

- Lexical search continues to handle exact matches for API names, config keys, error strings, and paths — embeddings degrade these.
- Embeddings handle the semantic/vocabulary-mismatch tail.
- They are complementary; results are typically combined (hybrid retrieval).

Also keep, regardless of retrieval choice:

- Heading-aware chunking (so answers and links land on the right section).
- The `search-content.json` content store (excerpts, answer context, virtual FS).
- `createAnswerContext` / the provider streaming wrappers (source-grounded prompting and citations).
- The endpoint guards (`validateDocsQuery`, `readJsonWithLimit`, rate limiting backed by a shared store like Redis / Vercel KV / Cloudflare KV / Durable Objects in production).

## Recommendation

Ship leadtype's static index first. Instrument query logs. Only invest in a hosted vector DB once we have evidence of condition (1) or (2) above — and even then, run it alongside the lexical index, not instead of it.
