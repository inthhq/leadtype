# Leadtype Docs Search — What You Already Have

## 1. What leadtype's docs search uses by default

Leadtype ships a **fully static, database-free search system** out of the box. There is no hosted index, no vector store, and no external API call required. Here is exactly how it works:

### Build time
Running `leadtype generate` (or calling `generateDocsSearchFiles()` from `leadtype/search/node`) writes two plain JSON files:

```
public/docs/search-index.json   ← compact term postings, document refs, chunk refs
public/docs/search-content.json ← actual chunk text for excerpts and answer context
```

The indexer is **heading-aware**: each page is sliced into chunks at heading boundaries, so a search result can link directly to the right section (`/docs/guide#installation`), not just the right page. The two files are split deliberately — the index is small enough to load on every search; the content store is loaded lazily only when you need excerpts or AI answers.

### Runtime
The `searchDocs()` function from `leadtype/search` is **edge-safe** (no Node.js APIs; works on Vercel Edge, Cloudflare Workers, etc.) and queries the index entirely in-process — no network hop, no database, no latency budget beyond what it takes to fetch the JSON file once.

**Ranking is BM25**, with field weights already tuned for documentation:
- Titles: **4×**
- Headings: **2×**
- Body: **1×**
- Code: **0.35×**

Query terms are not limited to exact tokens. The runtime expands queries through:
- Lightweight **stemming**
- **Prefix matching**
- **Typo-tolerant fallbacks**
- A small **built-in synonym map**

Exact matches retain the highest weight, so API names and config keys remain precise. You can layer in product-specific synonyms via the `synonyms` option when your docs use terminology that differs from what users type.

### Optional AI answers (still no database)
Even the optional AI-answer layer (`streamDocsAnswer`, `createAnswerContext`) works off the same two static JSON files. Leadtype retrieves chunks from the local index, builds a constrained prompt (model is told to answer only from retrieved context and cite sources), and streams a response through whichever provider adapter you choose (`leadtype/search/vercel`, `/tanstack`, `/cloudflare`). No vector store, no embedding model, no external retrieval service.

**Summary of the default stack:**

| Concern | What leadtype provides |
|---|---|
| Index storage | Two static `.json` files on disk / CDN |
| Retrieval algorithm | BM25 with field weights |
| Query expansion | Stemming, prefix, typos, synonym map |
| Runtime environment | Edge-safe, no database, no Node APIs |
| AI answers | Source-grounded via local index chunks; model/provider is your choice |
| Infrastructure cost | Zero — just static file hosting you already have |

---

## 2. When embeddings are actually warranted — and what to keep

The leadtype docs are explicit on this. From `docs/reference/search.md`:

> **Start with the local index.** It is static, cheap, edge-safe, and fast for exact API names, config keys, error messages, and paths. Add embeddings only when:
>
> - Users search with **vocabulary that doesn't match the docs** (e.g. "make it faster" matching a "performance optimization" page).
> - Your docs grow **past tens of thousands of chunks** and the cold-start memory hit becomes noticeable.

### The two specific conditions, unpacked

1. **Vocabulary mismatch at scale.** The built-in synonym map and typo-tolerant fallbacks already handle a lot of common divergence. Embeddings only add real value when users consistently phrase queries in ways that share *no lexical overlap* with the docs — conceptual or colloquial queries like "make it faster" vs. "performance optimization." If your users search by API names, error messages, config keys, or guide titles, BM25 beats or equals embeddings for those cases every time.

2. **Index size / cold-start memory.** The static JSON approach is fast precisely because it fits in memory. If your docs corpus grows to tens of thousands of chunks, the cold-start cost of loading the full index becomes noticeable — at that scale an ANN (approximate nearest-neighbor) vector index may be warranted to keep startup fast.

### What to keep even if you add embeddings

> **"Even then, keep the lexical index for exact matches and layer embeddings on top — they're complementary, not replacements."**

This is the critical point. A vector index is *worse* at exact lookups (API names, config keys, error strings, paths). A hosted vector store does not replace BM25; it augments it. The right architecture if you ever reach that threshold is a **hybrid retrieval pipeline**: BM25 for precision on exact terms + embeddings for recall on conceptual/vocabulary-mismatched queries. Throwing away the static index in favor of a pure vector store would be a regression for the majority of docs-search queries.

### What this means for the team's proposal

A hosted, database-backed vector index is **not warranted yet**. Before building it, you would need evidence of both triggers:

1. Real query logs showing users phrasing searches in ways the synonym map and stemming cannot bridge (not hypothetical).
2. A corpus large enough that the static JSON cold-start is measurably hurting you.

Until those conditions are met, the static BM25 index leadtype already generates is the correct solution — it's cheaper to operate, faster for the queries your users actually run, and requires zero additional infrastructure.
