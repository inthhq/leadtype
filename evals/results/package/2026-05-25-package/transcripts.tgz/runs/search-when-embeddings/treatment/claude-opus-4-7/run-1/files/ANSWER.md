# Does our docs search actually need a hosted vector DB?

Short answer: **probably not — leadtype already ships a working search path that doesn't require any database, embedding model, or hosted service.** Stand that up first, measure it, and only add embeddings if a specific failure mode shows up.

Source: `node_modules/leadtype/docs/reference/search.md` and `docs/build/add-search.md`.

## 1. What leadtype gives us by default

Leadtype builds **a static, edge-safe search index at build time** and queries it at runtime without touching a database.

- **Built at build time.** In site mode, `leadtype generate` (or `generateDocsSearchFiles` from `leadtype/search/node`) writes two JSON files under `public/docs/`:
  - `search-index.json` — compact tuple-format inverted index with term postings, document refs, and chunk refs. Loaded on every search.
  - `search-content.json` — the actual chunk text, kept separate so the index stays small and content can be loaded lazily for excerpts/answers.
- **Ranking: BM25 over chunks.** Pages are sliced into heading-aware *chunks*, each indexed as its own document, so a result jumps to the right section rather than just the right page. Field weights: titles 4×, headings 2×, body 1×, code 0.35× (tunable).
- **Runtime is edge-safe and dependency-free.** `searchDocs(index, query, { content })` from `leadtype/search` runs on Vercel, Cloudflare Workers, anywhere — no Node APIs, no service calls, no DB.
- **Not naive token matching.** Query terms expand through lightweight stemming, prefix matches, typo-tolerant fallbacks, and a built-in synonym map you can extend per project. Exact matches still get the highest weight, so API names, config keys, file paths, and error strings stay precise.
- **The index doubles as a virtual filesystem.** `listDocsContentFiles`, `readDocsContentFile`, and `readDocsContentChunk` let agents read whole pages or single chunks from the same artifact. There are also bash-tool adapters (`createDocsBashTool`) that expose a read-only `/docs` with `ls`, `cat`, `find`, `grep`, `rg`.
- **Source-grounded answers are built in.** `createAnswerContext` turns a query plus retrieved chunks into a `{ system, prompt, sources }` payload for any model. Provider wrappers (`leadtype/search/{vercel,tanstack,cloudflare}`) stream answers and return citation metadata separately — all still backed by the same static JSON.
- **Abuse guards included.** `validateDocsQuery`, `readJsonWithLimit`, `getClientIdentifier`, `createMemoryRateLimiter` cover the request path.

So "RAG" against our docs is already a solved problem in the package: BM25 over chunks → grounded prompt → streamed answer with citations. No vector index, no embedding pipeline, no hosted service.

## 2. When adding embeddings is actually warranted

Per `docs/reference/search.md` ("When to add embeddings"), start with the local lexical index. **It is static, cheap, edge-safe, and fast for exact API names, config keys, error messages, and paths.** Add embeddings *only* when one of these specific conditions is true:

1. **Vocabulary mismatch is measurably hurting retrieval.** Users search with words that don't appear in the docs — e.g. a query like *"make it faster"* failing to surface a *"performance optimization"* page — and the built-in synonym map isn't enough to bridge it.
2. **Scale breaks the lexical path.** The corpus grows past tens of thousands of chunks and the cold-start memory hit of loading `search-index.json` becomes noticeable.

If neither of those is demonstrably true today, a hosted vector DB is solving a problem we don't have.

### What we keep even then

Embeddings are **complementary, not a replacement**:

- **Keep the lexical BM25 index** for exact matches — API names, config keys, error strings, file paths — which is where dense retrieval is *worst*.
- **Layer embeddings on top** for fuzzy/semantic queries, then merge results.
- Keep the chunking, the citation contract from `createAnswerContext`, and the provider streaming wrappers — none of that changes when a second retriever is added.

## Recommended next step

Before scoping a hosted vector DB:

1. Wire up `generateDocsSearchFiles` + `searchDocs` (or the framework adapter under `leadtype/search/*`) and ship it.
2. Log real queries and the top results.
3. If — and only if — we see the vocabulary-mismatch failure mode at meaningful frequency, or we cross the tens-of-thousands-of-chunks threshold, add embeddings as a *second* retriever alongside the lexical one.
