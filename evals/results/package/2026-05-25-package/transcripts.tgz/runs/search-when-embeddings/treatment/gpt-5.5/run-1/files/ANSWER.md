# Leadtype docs search: do we need a hosted vector index?

## What leadtype uses by default

Leadtype's docs search is **static, lexical, database-free search** by default.

At build time, Leadtype generates two files for a docs site:

- `public/docs/search-index.json` — a compact **BM25-ranked inverted index**.
- `public/docs/search-content.json` — the chunk text used for snippets and source-grounded answer context.

The index is built over **heading-aware chunks**, so results can point at the relevant section rather than only the page. BM25 scoring weights content by field: titles are weighted highest, then headings, then body text, with code weighted lower.

At runtime, `leadtype/search` queries those JSON files locally/at the edge. It does **not** require a hosted search service, database, vector store, or embedding pipeline. It is also not just exact-token matching: query handling includes lightweight stemming, prefix matches, typo-tolerant fallbacks, and a small built-in synonym map, with optional product-specific synonyms.

Leadtype's optional AI answer helpers still start from this static index: they retrieve docs chunks, build a constrained source-grounded prompt, and return sources for citation. The model should answer from retrieved docs context, not from memory.

## When embeddings are actually warranted

Start with Leadtype's local lexical index. It is cheap, fast, edge-safe, and especially strong for docs queries involving exact API names, config keys, error messages, commands, package paths, and URLs.

Add embeddings only if one of these conditions is true:

1. **Users search with vocabulary that does not appear in the docs.**  
   Example: users type "make it faster" but the docs page says "performance optimization." If product-specific synonyms are not enough, semantic retrieval can help bridge that vocabulary gap.

2. **The docs corpus grows past tens of thousands of chunks and the static index's cold-start memory cost becomes noticeable.**  
   At that scale, a hosted or database-backed retrieval layer may be useful for operational reasons.

Even then, embeddings should be **layered on top of Leadtype's lexical index**, not used as a replacement. Keep the BM25/static lexical index for exact matches and precision-sensitive docs queries, then combine or re-rank with embedding results for semantic recall. Lexical search and embeddings are complementary.