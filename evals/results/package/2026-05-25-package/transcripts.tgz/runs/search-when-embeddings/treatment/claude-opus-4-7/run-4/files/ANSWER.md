# Docs search with `leadtype`: do we need a hosted vector DB?

**Short answer: almost certainly not yet.** `leadtype` ships a docs search system out of the box, and its own docs are explicit about when embeddings are warranted (and what to keep even then). Sources: `node_modules/leadtype/docs/reference/search.md` and `node_modules/leadtype/docs/build/add-search.md`.

## 1. What `leadtype`'s docs search uses by default

A **static, edge-safe, BM25 lexical index built at build time** — no database, no embedding model, no vector store.

Key properties:

- **Build step.** `generateDocsSearchFiles({ outDir, baseUrl })` (from `leadtype/search/node`) reads markdown under `<outDir>/docs/` and writes two artifacts:
  - `search-index.json` — compact tuple-format term postings, document refs, and chunk refs.
  - `search-content.json` — the actual chunk text, kept separate so the index can be loaded on every search while content is fetched lazily (for excerpts and answers).
- **Heading-aware chunking.** Each chunk is its own document in the index, so results jump to the right section, not just the right page.
- **BM25 ranking** with field weights: titles 4×, headings 2×, body 1×, code 0.35× (tunable in the generator).
- **Edge-safe runtime.** `searchDocs(index, query, { content })` from `leadtype/search` runs on Vercel, Cloudflare Workers, etc. — no Node APIs, no DB, no network call.
- **Not naive exact-match.** The runtime adds lightweight stemming, prefix matching, typo-tolerant fallbacks, and a small built-in synonym map (extensible via a `synonyms` option). Exact matches still win, so API names and config keys stay precise.
- **Doubles as a virtual filesystem.** `listDocsContentFiles`, `readDocsContentFile`, and `readDocsContentChunk` let runtime/agents read pages or single chunks from the same artifacts.
- **Source-grounded answers included.** `createAnswerContext` plus provider streamers (`leadtype/search/vercel`, `/tanstack`, `/cloudflare`) turn the same index + chunks into a system prompt + user prompt for any LLM, with `[1]`-style citations. There is also a read-only bash-tool adapter (`createDocsBashTool`) so an agent can explore `/docs` with `ls`/`cat`/`grep`/`rg` instead of being handed pre-selected chunks.

So the default RAG-style pipeline (retrieve relevant chunks → ground an LLM answer → cite sources) is already there, with **two static JSON files** as the entire "index infrastructure."

## 2. When adding embeddings is actually warranted

Per `leadtype`'s own guidance ("When to add embeddings" in `search.md`), add an embedding/vector layer only if **one of these** is true:

1. **Vocabulary mismatch is the real failure mode.** Users phrase queries in language that doesn't appear in the docs — e.g. searching "make it faster" expecting to land on a "performance optimization" page. Synonyms and stemming can't bridge that gap; semantic similarity can.
2. **Scale stops being trivial.** The corpus grows past **tens of thousands of chunks** and the cold-start memory cost of loading `search-index.json` becomes noticeable on the edge runtime.

If neither of those is true for our docs, a hosted vector DB is overhead with no win. The lexical index is already strong for the things docs search most needs to nail: exact API names, config keys, error messages, file paths.

### What to keep even if we add embeddings

> "Even then, keep the lexical index for exact matches and layer embeddings on top — they're complementary, not replacements." — `search.md`

Concretely, that means:

- **Keep `search-index.json` + `search-content.json` and `searchDocs`** as the lexical layer. Don't replace it.
- **Layer embeddings on top** (hybrid retrieval): use vectors to recover semantic recall, but merge/rerank with BM25 so exact tokens (API names, config keys, error strings) still rank highest.
- **Reuse the same chunks.** The heading-aware chunks `leadtype` already produces are the right unit to embed; don't invent a parallel chunking scheme.
- **Reuse `createAnswerContext` / the provider streamers** for grounding and citations. Only the retrieval step needs to change; the answer-generation contract stays the same.

## Recommendation

Before standing up a hosted, DB-backed vector index, ship `leadtype`'s built-in search first:

1. Add `generateDocsSearchFiles(...)` to the docs build.
2. Wire `searchDocs` into the docs UI (and optionally `streamDocsAnswer` for grounded answers).
3. Measure: which real user queries fail? Are failures dominated by vocabulary mismatch, or by ranking/coverage issues that synonyms and tuning could fix?
4. Only if vocabulary mismatch is the dominant failure mode, or the corpus crosses the tens-of-thousands-of-chunks threshold, add embeddings — as a **hybrid** layer on top of the existing lexical index, not a replacement.
