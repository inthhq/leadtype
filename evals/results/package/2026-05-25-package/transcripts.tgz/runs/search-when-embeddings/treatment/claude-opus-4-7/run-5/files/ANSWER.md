# Docs Search with `leadtype` — Before You Build a Vector Index

Short version: **don't stand up a hosted, DB-backed vector index yet.** `leadtype` already ships a static search system that covers the common docs-search case without any infrastructure. Embeddings are a layer you add later, *if* specific symptoms appear — and even then you keep the existing index.

Sources used: `node_modules/leadtype/docs/reference/search.md` and `node_modules/leadtype/docs/build/add-search.md`.

## 1. What `leadtype` gives us by default

`leadtype generate` produces a **static, edge-safe search index** at build time. No database, no server, no embeddings model.

**Build output** (written to `<outDir>/docs/`):

- `search-index.json` — compact ranking data (term postings, document refs, chunk refs).
- `search-content.json` — the actual chunk text, split out so the index loads on every search while content is fetched lazily for excerpts/answers.

**How it indexes:**

- Pages are split into **heading-aware chunks**, so results jump to the right section, not just the right page.
- Ranking is **BM25** with field weights: titles 4×, headings 2×, body 1×, code 0.35×.

**How it queries (`searchDocs` from `leadtype/search`):**

- Lexical matching with **lightweight stemming**, **prefix matches**, **typo-tolerant fallbacks**, and a small **built-in synonym map**.
- **Exact matches keep the highest weight**, so API names, config keys, error strings, and paths stay precise.
- Optional per-call `synonyms` map for product-specific vocabulary.
- Runtime is edge-safe (no Node APIs) — runs on Vercel, Cloudflare Workers, etc.
- The same index doubles as a virtual filesystem: `listDocsContentFiles`, `readDocsContentFile`, `readDocsContentChunk`.

**On top of that, still no DB required:**

- `createAnswerContext` builds a constrained `{ system, prompt, sources }` for source-grounded answers from retrieved chunks.
- `streamDocsAnswer` provider wrappers exist for Vercel AI SDK, TanStack AI, and Cloudflare AI Gateway / Workers AI.
- `leadtype/search/bash` exposes a read-only `/docs` filesystem (`ls`, `cat`, `find`, `grep`, `rg`) for agent-driven exploration.
- Request guards are included: `validateDocsQuery`, `readJsonWithLimit`, `getClientIdentifier`, `createMemoryRateLimiter` (swap for Redis/KV/Durable Objects in prod).

**What this means for the proposal:** the default already covers retrieval, chunking, ranking, snippets, and source-grounded answers — without any hosted vector DB. A DB-backed embedding service is *additional* infrastructure, not the baseline.

## 2. When embeddings are actually warranted

Per `leadtype`'s own guidance ("When to add embeddings"), add embeddings **only** when one of these is true:

1. **Vocabulary mismatch.** Users search with words the docs don't use — e.g. a query like "make it faster" needs to find a page titled "performance optimization." Lexical search with synonyms isn't closing the gap.
2. **Scale.** Docs grow past **tens of thousands of chunks** and the cold-start memory hit of the static index becomes noticeable.

Before either of those is demonstrated with real query logs, embeddings are speculative work.

### What to keep even after adding embeddings

**Keep the lexical (BM25) index.** They are complementary, not replacements:

- Exact API names, config keys, error messages, and file paths must keep matching precisely — that is BM25's strength and embeddings tend to blur it.
- Layer embeddings *on top* of the existing index (hybrid retrieval), do not swap it out.

### Recommendation

1. Ship the default `leadtype` static index now. Wire `searchDocs` into the UI and add request guards.
2. Add a small product-specific `synonyms` map for any vocabulary gaps surfaced by query logs.
3. Instrument search: log zero-result queries and low-CTR queries.
4. Revisit embeddings only if (1) those logs show real vocabulary-mismatch failures, or (2) chunk count crosses the tens-of-thousands threshold. Even then, run hybrid (BM25 + embeddings), don't replace.
