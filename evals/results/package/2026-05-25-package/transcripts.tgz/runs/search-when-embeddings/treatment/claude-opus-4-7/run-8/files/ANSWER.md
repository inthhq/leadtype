# Docs search with `leadtype`: do we need a vector index?

Short answer: **not by default, and probably not at all for a typical docs corpus.** `leadtype` already ships a docs search pipeline. We should use it first and only add embeddings if we hit specific failure modes documented below.

## 1. What `leadtype` gives us by default

`leadtype` builds a **static, edge-safe search index** from our docs at build time. There is no database and no server-side index process.

**Build-time output** (`leadtype generate`, or `generateDocsSearchFiles` from `leadtype/search/node`):

- `public/docs/search-index.json` — compact ranking data (term postings, document refs, chunk refs).
- `public/docs/search-content.json` — the chunk text, kept in a separate file so search can run without loading every excerpt.

**Indexing model:**

- Docs are sliced into **heading-aware chunks**, so a result jumps to the right section, not just the right page.
- Ranking is **BM25** (lexical), with field weights: title 4×, headings 2×, body 1×, code 0.35×. The weights are tunable in the generator.

**Runtime (`searchDocs` from `leadtype/search`):**

- Edge-safe — no Node APIs. Runs on Vercel, Cloudflare Workers, etc.
- Pure lexical matching, but **not exact-token only**. Queries expand through:
  - lightweight stemming,
  - prefix matches,
  - typo-tolerant fallbacks,
  - a small built-in synonym map,
  - and a user-supplied `synonyms` map for product-specific vocabulary.
- Exact matches keep the highest weight, so API names, config keys, and error strings stay precise.

**On top of the same index, for free:**

- Virtual-FS readers: `listDocsContentFiles`, `readDocsContentFile`, `readDocsContentChunk`.
- `createAnswerContext` to build a constrained `system` + `prompt` + `sources` payload for source-grounded LLM answers.
- Provider-specific streaming wrappers: `leadtype/search/vercel`, `leadtype/search/tanstack`, `leadtype/search/cloudflare`.
- Read-only bash tool adapters (`ls`, `cat`, `find`, `grep`, `rg` over a virtual `/docs`) for agents that prefer to explore.
- Request-path guards: `validateDocsQuery`, `readJsonWithLimit`, `getClientIdentifier`, `createMemoryRateLimiter`.

What this means for our "hosted, DB-backed vector index" plan: the default already covers indexing, ranking, snippets, edge-safe querying, and even RAG-style answer streaming — **without any hosted service, vector DB, or embedding API**.

## 2. When adding embeddings is actually warranted

Per `node_modules/leadtype/docs/reference/search.md` ("When to add embeddings"), we should add embeddings **only when one of these conditions is true**:

1. **Vocabulary mismatch.** Users search with words that don't appear in our docs — e.g. "make it faster" needs to match a page titled "Performance optimization". Lexical + synonyms can't bridge this if the gap is large or open-ended.
2. **Scale.** The corpus grows past **tens of thousands of chunks** and the cold-start memory cost of the static index becomes noticeable.

Before either of these is true, the right moves are:

- Ship the static index as-is.
- Add a `synonyms` map for product-specific vocabulary (the docs explicitly call this out as the first lever, not embeddings).
- Use `createAnswerContext` / `streamDocsAnswer` if we want grounded AI answers — that's RAG without a vector store, using BM25 retrieval.

### What we keep even after adding embeddings

The leadtype docs are explicit: embeddings are **complementary, not a replacement**. Even when we add them, we keep the **lexical (BM25) index** so that:

- API names, config keys, file paths, CLI flags, and error messages still match exactly and rank highest.
- Exact-token queries don't get smeared by semantic similarity.

The pattern is: lexical first, embeddings layered on top — not the other way around, and never lexical removed.

## Recommendation

Do **not** stand up a hosted vector DB yet. Wire up `generateDocsSearchFiles` + `searchDocs`, add a synonyms map for our product vocabulary, and optionally turn on source-grounded answers through one of the provider entry points. Revisit embeddings only if we hit the vocabulary-mismatch or scale conditions above — and even then, keep the BM25 index.
