# Leadtype docs search: what we get by default

Leadtype does **not** require a hosted, database-backed vector index for docs search by default.

By default, Leadtype generates a **static, edge-safe search index** at build time and queries it locally at runtime:

- `public/docs/search-index.json` — compact ranking/index data.
- `public/docs/search-content.json` — chunk text for snippets, excerpts, and answer context.

The index is a **BM25-ranked lexical index** over heading-aware chunks of the docs. It weights fields roughly as:

- title: 4×
- headings: 2×
- body: 1×
- code: 0.35×

Runtime search uses `leadtype/search` and does not touch a database. It is designed to run at the edge and works from imported or fetched JSON files. Search is not limited to exact token matches: Leadtype also includes lightweight stemming, prefix matches, typo-tolerant fallbacks, and a small built-in synonym map. Product-specific synonyms can be added when our users search with terms our docs do not use.

Leadtype can also produce source-grounded AI answers, but those answers layer on top of the same retrieved docs chunks. The model is instructed to answer from the retrieved context and cite sources; the static search index remains the retrieval source.

## When embeddings are actually warranted

Start with Leadtype's local static index. It is cheap, fast, database-free, edge-safe, and especially good for exact API names, config keys, error messages, code terms, and paths.

Add embeddings only when one of these is true:

1. **Users search with vocabulary that does not match the docs.**
   - Example: users type “make it faster,” but the relevant page says “performance optimization.”
   - Before jumping to embeddings, try Leadtype's product-specific `synonyms` support for known vocabulary gaps.

2. **The docs corpus grows beyond tens of thousands of chunks and the cold-start memory cost of the static index becomes noticeable.**
   - At that point, an external retrieval layer may be useful for scale or memory management.

Even then, we should **keep Leadtype's lexical/BM25 index** and layer embeddings on top of it. Embeddings are complementary, not a replacement: lexical search is still the right tool for precise matches such as API names, config keys, error strings, code identifiers, and file paths.
