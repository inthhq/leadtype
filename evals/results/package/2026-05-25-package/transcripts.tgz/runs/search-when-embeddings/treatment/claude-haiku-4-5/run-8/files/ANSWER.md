# What Leadtype Already Gives Us for Docs Search

## 1. What Leadtype Uses by Default

Leadtype provides a **static, edge-safe search index** that requires **no database**. Here's what it gives you:

### Default Search Mechanism: BM25 Lexical Ranking
- **Algorithm**: BM25 (a proven ranking function used in production search systems)
- **Weighting scheme**: Titles weigh 4×, headings 2×, body text 1×, code 0.35×
- **Query processing includes**:
  - Lightweight stemming (grammatical variants)
  - Prefix matching (partial word matches)
  - Typo-tolerant fallbacks (handles misspellings)
  - Built-in synonym map
  - Exact matches kept at highest weight (API names and config keys stay precise)

### Build-Time Output
Two static JSON files generated at build time:
- **`search-index.json`**: Compact tuple format with term postings, document refs, and chunk refs (small, loaded on every search)
- **`search-content.json`**: Actual chunk text, separated from index so you search without loading content, then read content lazily for excerpts and answers

### Chunk-Level Indexing
- Each heading-aware section (chunk) is a separate searchable document
- Search results jump to the right section within a page, not just the page itself

### Runtime: Edge-Safe & Database-Free
- No Node.js APIs — works on Vercel, Cloudflare, and anywhere else
- Imported as local JSON, queried in-process
- Fast and cheap (no network calls, no cold starts to a database)

### Built-In Extensions
- **Request guards**: `validateDocsQuery`, `readJsonWithLimit`, `getClientIdentifier`, `createMemoryRateLimiter`
- **Content readers**: Access whole pages or individual chunks via the index as a virtual filesystem
- **Source-grounded answers**: Built-in prompt construction that constrains answers to retrieved chunks only
- **Provider adapters**: Streaming answer integration for Vercel AI SDK, TanStack AI, and Cloudflare Workers AI

---

## 2. When Embeddings Are Actually Warranted

Add embeddings **only** when one of these conditions is true:

### Condition 1: Vocabulary Mismatch
Users search with language that doesn't appear in your docs.
- Example: Users searching "make it faster" when your docs say "performance optimization"
- Solution: Start with synonyms (`synonyms` parameter) before jumping to embeddings

### Condition 2: Scale Beyond Tens of Thousands of Chunks
Your docs grow large enough that the cold-start memory hit of loading the lexical index becomes noticeable.

### What to Keep Even Then
**Do not replace the lexical index.** Keep both and use them together:

- **Lexical index** (BM25): Handles exact matches on API names, config keys, error messages, and paths with high precision
- **Embeddings**: Layer on top for semantic/conceptual matches

They are **complementary, not replacements**. The lexical index stays fast, cheap, and precise for the queries it handles well. Embeddings add capability without removing the foundation.

### What This Means for Your Team

Before building hosted vector infrastructure:
1. ✅ Use the static BM25 index that leadtype provides
2. ✅ Add custom synonyms for your domain vocabulary
3. ✅ Validate that users are actually hitting vocabulary mismatch (not just needing synonyms)
4. ✅ Measure memory impact as you scale — most teams don't hit the tens-of-thousands threshold
5. ✅ Only then layer embeddings on top while keeping the lexical index

The database-backed vector index is a last resort, not the default.
