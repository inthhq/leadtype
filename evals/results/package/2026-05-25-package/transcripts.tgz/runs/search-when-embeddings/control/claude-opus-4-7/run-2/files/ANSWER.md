# Docs search with `leadtype` — what we already have, and when embeddings are warranted

Source: `node_modules/leadtype/README.md` and `node_modules/leadtype/dist/_shared/search-*.js` (the runtime that backs `leadtype/search` and `leadtype/search/node`).

## 1. What `leadtype` gives us by default

`leadtype generate` already emits a complete docs search system as a build artifact. There is no database, no embedding model, and no hosted service involved.

**Default architecture**

- **Algorithm:** BM25 lexical ranking (`BM25_K1 = 1.2`, `BM25_B = 0.75`), implemented in `dist/_shared/search-TL9muun_.js`.
- **Artifact:** a single static JSON file — `public/docs/search-index.json` — generated alongside `llms.txt`, `llms-full.txt`, and the markdown mirrors.
- **Runtime:** edge-safe. The index is loaded as JSON and queried in-process; no server, no DB, no network call to a vector store. Adapters exist for Next.js, TanStack, Cloudflare, Vercel AI SDK, and a framework-free client (`createSearchClient` / `useLeadtypeSearch`).
- **Indexing unit:** documents are split into section blocks at markdown headings, then into overlapping chunks (`maxChunkChars = 1200`, `overlapChars = 160`). Each chunk keeps its heading path and anchor so results deep-link to the right `#section`.
- **Field weighting:** title ×4, heading ×2, body ×1, code ×0.35 — already tuned for docs.
- **Query understanding (built-in, no model required):**
  - Unicode-aware tokenization with diacritic folding and a stopword list.
  - Stemming (`-ing`, `-ed`, `-es`, `-ies`, `-s`) at weight 0.82.
  - A baseline synonym table (`ai`/`agent`/`llm`, `auth`/`login`, `config`/`settings`, `ts`/`typescript`, etc.) at 0.72, extendable via `SearchDocsOptions.synonyms`.
  - Prefix expansion at 0.55 (autocomplete-style).
  - Typo tolerance via bounded edit distance (1 for short tokens, 2 for length ≥7) at 0.45.
  - Phrase / ordered-proximity boosts (×1.4 / ×0.8) for multi-word queries.
- **Excerpts:** `buildExcerpt` returns a ~240-char window centered on the first matching token, with leading/trailing ellipses.
- **Source-grounded answers (RAG-style, no embeddings):** `createAnswerContext(index, query, …)` runs the same BM25 search, takes the top `maxSources` (default 6) chunks up to `maxContextChars` (default 12 000), and assembles a `{ sources, system, prompt }` bundle. The system prompt already instructs the model to cite `[1]`, `[2]`, treat excerpts as untrusted reference text, and refuse to invent APIs. Streaming adapters for Vercel AI Gateway, TanStack AI, and Cloudflare Workers AI consume this directly.
- **Request hygiene:** `validateDocsQuery` (length and control-char checks), `readJsonWithLimit`, `createMemoryRateLimiter`, and `getClientIdentifier` (handles `cf-connecting-ip` / `x-forwarded-for`) are shipped for the API route.

**What this means in practice.** "RAG over our docs" is already done. The retrieval step is BM25 over a static JSON file; the generation step is `createAnswerContext` feeding a normal LLM call. We do not need a vector DB to do retrieval-augmented generation — we need a *retriever*, and we have one with citations, chunk anchors, and prompt scaffolding.

## 2. When adding embeddings is actually warranted

Default to the built-in BM25 index. Only add an embeddings layer if you can point to a *measured* failure of lexical search that one of the following conditions explains, **and** the failure shows up in real query logs (not hypotheticals):

1. **Heavy vocabulary mismatch between users and docs.** Users consistently search with words that do not appear in the docs at all, and synonyms + stemming + the user-extendable `synonyms` option in `SearchDocsOptions` have already been tried and are not enough. Symptom: top-3 hit rate in query logs is low despite the answer existing in the corpus under different wording.
2. **Genuinely conceptual / paraphrase questions** ("how do I make my agent remember things?" when the docs talk about "session state persistence") where prefix, stem, and typo expansion cannot bridge the gap.
3. **Cross-lingual retrieval** — users query in a language the docs are not authored in, and a translated synonym table is not viable.
4. **Corpus scale where BM25 quality degrades** — many thousands of pages where lexical scoring returns too many equally plausible hits. Our docs are nowhere near this.
5. **Domain where exact tokens are misleading** (e.g. natural-language Q&A over prose without stable terminology). Developer docs are the opposite of this — they are full of stable, exact identifiers (API names, flags, file paths) that BM25 ranks *better* than embeddings do.

If none of (1)–(5) is demonstrably true from logs, a hosted vector DB is solving a problem we do not have, and it adds: infra cost, an embedding model dependency, index-staleness on every docs change, a network hop on every query (giving up the edge-safe property), and a second source of truth to keep in sync with the markdown.

**If we do add embeddings, keep the following from leadtype — do not replace them:**

- **BM25 as the first-stage retriever or as a hybrid signal.** Embeddings are weak at exact-token matches (API names, CLI flags, error strings, file paths) where BM25 is strongest. The standard pattern is hybrid: BM25 + vector, fused (e.g. RRF). Leadtype's `searchDocs` is the BM25 half.
- **leadtype's chunking, heading path, and anchors.** `createDocsSearchIndex` already does section-aware chunking with overlap and emits the `urlWithHash` / `headingPath` metadata needed for citations. Embed leadtype's chunks; do not re-chunk from raw markdown.
- **`createAnswerContext` and its system prompt.** The citation contract, the "treat excerpts as untrusted reference text" guard, and the "do not invent APIs" instruction are the right defaults regardless of how the candidate chunks were retrieved. Swap the retriever inside; keep the prompt assembly.
- **The request-side primitives:** `validateDocsQuery`, `readJsonWithLimit`, `createMemoryRateLimiter`, `getClientIdentifier`. These are independent of the retrieval algorithm.
- **The static `search-index.json` artifact.** Even with embeddings, keeping the lexical index lets the docs site degrade gracefully (and stay edge-safe) when the vector service is down.

**Recommended sequence before approving the vector-DB project:**

1. Ship the default `leadtype` search and `createAnswerContext`-based answers.
2. Log queries and click-throughs for at least a few weeks.
3. Extend the `synonyms` option for the top failing queries.
4. Only then, if measurable gaps remain that match conditions (1)–(5) above, add embeddings as a *second* retriever fused with BM25 — not as a replacement.
