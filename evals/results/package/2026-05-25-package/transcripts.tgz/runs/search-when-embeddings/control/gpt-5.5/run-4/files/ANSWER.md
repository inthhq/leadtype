# Leadtype docs search: do we need a hosted vector index?

## What leadtype uses by default

Leadtype does **not** require a hosted database or vector store for docs search. Its default docs search is a generated, static, edge-safe lexical index:

- `leadtype generate` emits website search artifacts such as `docs/search-index.json` and, when content is split out, `docs/search-content.json`.
- The runtime in `leadtype/search` queries that JSON index directly; the client helper fetches `/<collection>/search-index.json` and `/<collection>/search-content.json` by default.
- Ranking is BM25-style keyword search over chunks, with weights for title, headings, body, and code.
- It also includes pragmatic lexical recall features: token normalization, stopword removal, light stemming, configured/default synonyms, prefix matching, typo tolerance, phrase/proximity boosts, excerpts, and result limits.
- For “ask the docs”/RAG-style answers, leadtype first retrieves sources from that same search index, builds a source-grounded context with citations, and then streams an answer through the AI adapter. The model is used to answer from retrieved documentation context, not to run retrieval by default.

In short: by default, leadtype gives us a static BM25 docs search index plus optional source-grounded answer generation. It is cheap to host, CDN/edge-friendly, versioned with the docs build, and has no database to operate.

## When embeddings are actually warranted

Add embeddings only if we can show that lexical retrieval is the limiting factor. Concretely, embeddings are warranted when all of these are true:

1. We have real query logs, support tickets, or a golden-query test set showing important searches fail because the relevant document uses different wording from the query.
2. Reasonable lexical fixes have already been tried: better titles/headings/descriptions, improved docs wording, synonyms, chunk tuning, and query/result UI improvements.
3. The failures are semantic-recall problems rather than freshness, content quality, navigation, or ranking bugs.
4. The value of those recovered queries justifies the operational cost: embedding generation, re-indexing on docs changes, vector storage, access control, latency, observability, and provider/model drift.

Typical cases that can meet that bar are large or jargon-heavy corpora, many paraphrased “how do I…” questions, cross-product terminology mismatches, or multilingual/cross-lingual search where exact terms are not reliable.

Even then, we should **keep leadtype’s default search artifacts and retrieval path**. Use embeddings as an additional recall signal or hybrid reranking layer, while preserving:

- the static BM25 index as a fast, high-precision fallback;
- leadtype’s markdown chunks/content store as the source of truth for answer context;
- source-grounded answers with citations and “don’t invent” instructions;
- query validation, size limits, rate limiting, and simple edge/CDN serving where possible.

So the default decision should be: start with leadtype’s built-in static BM25 search and source-grounded answers. Add embeddings only after measured lexical-recall failures prove they are needed, and keep BM25 plus leadtype’s source-grounding even in a hybrid system.
