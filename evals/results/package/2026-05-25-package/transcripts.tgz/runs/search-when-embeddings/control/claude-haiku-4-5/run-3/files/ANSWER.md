# What leadtype Gives You for Docs Search

## 1. Default Search: Static BM25 Full-Text Index

By default, `leadtype` builds a **static, edge-safe BM25 search index** — not embeddings, not a hosted database.

### What this means:
- **BM25 ranking**: Industry-standard full-text search algorithm (also used by Elasticsearch, Solr). It ranks documents by relevance based on term frequency and document length normalization.
- **Static artifact**: The search index is a JSON file (`search-index.json`) + optional content store (`search-content.json`) generated at build time and served from your edge or CDN — no backend required.
- **No embeddings by default**: No vector/semantic search, no external API calls, no hosted database setup needed.
- **Edge-safe**: Runs entirely on the client or edge runtime (Cloudflare Workers, Vercel Edge Functions, etc.). Query execution happens in-browser or at the edge.

### What gets indexed:
The search index captures:
- **Terms** (words from documents, titles, headings, code blocks)
- **Positional metadata** (which doc, section, heading level a term appears in)
- **Chunk-level scoring** (documents are split into chunks for finer-grained results)
- Optional content store: excerpts and full text for display

### Default limits (from `docsSearchDefaults`):
- Search limit: **8 results**
- Max query length: **400 characters**
- Max context for answers: **12,000 characters**
- Chunk size: **1,200 characters** with **160 character overlap**

---

## 2. When to Add Embeddings — and What to Keep

Adding a hosted vector index is warranted under these specific conditions:

### ✅ Add embeddings if:
1. **Semantic/concept-based search matters more than exact-match**: Your docs have complex domain knowledge where similar *concepts* appear with different terminology (e.g., "login" vs "authentication", "error handling" vs "exception management").
2. **Query patterns are vague or synonymous**: Users search for ideas ("how do I secure my app?") not keywords ("security configuration").
3. **You can tolerate extra latency**: Embedding lookups require network calls; BM25 is instant on the client.
4. **You have a large corpus** (100s of pages+): BM25 alone starts to return less relevant results as the pile grows.
5. **Your team has resources** to operate a vector DB, embeddings pipeline, and ongoing maintenance.

### ⚠️ What to keep even with embeddings:
- **The BM25 index**: Keep generating it. Use it as a **hybrid search fallback** or **pre-filter**. Many production RAG systems (including those from major AI companies) use BM25 + embedding reranking together because:
  - BM25 is fast, deterministic, and requires no external API
  - It catches exact-match queries perfectly
  - It's searchable offline (users don't need network access)
  - It's a sanity check: if BM25 returns nothing, embeddings won't help
  
- **The static content artifacts** (`llms.txt`, `llms-full.txt`, `AGENTS.md`): These provide broader context for LLMs beyond just search results. Keep them for:
  - Offline agent access (bundled in npm packages or local copies)
  - Up-front context before any search is needed
  - Fallback when search fails

- **Answer grounding**: leadtype's `createAnswerContext()` and `streamDocsAnswer()` functions build source-grounded LLM responses from search results. Keep this pattern — it ensures answers cite which docs were used.

### The hybrid approach:
```
Query → BM25 search → Embedding lookup (if enabled)
       ↓              ↓
     Fast wins + keyword matches → Semantic matches
                    ↓
          Rerank together, choose top K
                    ↓
        Generate answer with source citations
```

---

## Summary

**Default**: BM25 full-text search in a static JSON index. No database, no embeddings, runs at the edge.

**Before adding a vector index**, ask:
- Do my users search by concept/semantic similarity, or by keywords?
- Is offline searchability important?
- Do I have resources to maintain a vector DB?

**If yes to all**, build the vector index **alongside** the BM25 index, not instead of it. Hybrid search (BM25 for recall, embeddings for semantic depth) is what production RAG systems use.
