# Leadtype docs search and embeddings

## What leadtype uses by default

Leadtype already ships a docs-search pipeline. By default, `leadtype generate` builds website search artifacts such as `docs/search-index.json` (and search content) from the flattened markdown docs. The installed package describes this as a “static, edge-safe search index (BM25, optional source-grounded answers).”

Concretely, the runtime is not a hosted vector database and it does not require embeddings. It is a static JSON BM25 lexical index that can be queried from client/framework helpers or an edge/server route:

- documents are split into heading-aware chunks;
- default chunking is about 1,200 characters with 160 characters of overlap;
- title, heading, body, and code tokens are indexed with different weights;
- query matching includes BM25 scoring plus exact terms, stemming, built-in/custom synonyms, prefix expansion, typo tolerance, and phrase/proximity boosts;
- results include URLs/anchors, excerpts, and scores;
- optional answer helpers retrieve the top source chunks and build a source-grounded prompt with citations, instructing the model to answer only from provided docs context.

So for normal docs search/RAG, leadtype’s default is static lexical retrieval plus optional grounded answer generation — no database, embedding model, ingestion service, or vector index is required.

## When embeddings are warranted

Add embeddings only if we have evidence that the default BM25 search is failing for the kind of queries users actually ask. The specific warrant is: relevant docs exist, but users commonly phrase questions with vocabulary that does not appear in the docs, and synonym/stemming/prefix/typo tuning is not enough to recover them.

Examples where embeddings can be justified:

- repeated misses on semantic/paraphrase queries after reviewing search logs and expected results;
- conceptual “how do I accomplish X?” queries where the docs describe the same concept in different words;
- cross-language or highly domain-specific terminology mismatches that cannot reasonably be handled with curated synonyms;
- a measured improvement in recall/answer quality from a prototype hybrid retriever, not just a preference for vector infrastructure.

Even then, keep leadtype’s BM25/static pipeline. Use embeddings as an additional semantic signal, not a replacement:

- keep BM25 for exact API names, CLI flags, config keys, error messages, code symbols, package names, and URLs — cases where lexical matching is usually superior;
- keep leadtype’s generated markdown/search artifacts as the source of truth for docs chunks and links;
- keep source-grounded answer construction and citations so generation stays tied to retrieved docs;
- prefer hybrid retrieval/reranking: combine vector candidates with BM25 candidates, then answer only from the selected source chunks.

In short: start with leadtype’s built-in static BM25 search. Add embeddings only when real query data shows a semantic-recall gap, and keep BM25 plus source-grounded citations even if a vector index is introduced.
