# What leadtype Provides for Docs Search

## 1. Default Search Implementation

By default, **leadtype uses BM25 (Best Matching 25)**, a lexical ranking algorithm that requires **no machine learning, no embeddings, and no vector database**.

### How It Works

The search system:

- **Tokenizes** markdown content into normalized words
- **Chunks** documents (default 1200 characters) with semantic overlap (160 characters) to preserve context at boundaries
- **Indexes** terms from titles (4× weight), headings (2× weight), body text (1× weight), and code blocks (0.35× weight)
- **Computes BM25 scores** at query time using:
  - **Term frequency** (weighted by section type)
  - **Inverse document frequency** (rarity boost)
  - **Document length normalization** (prevents long documents from dominating)
  - **Exact matches, stemming, synonyms, prefix, and typo tolerance** (built-in query expansion)
  - **Phrase and proximity boosts** (multi-word queries get a score bonus for ordered/nearby terms)

### Output Format

- **`search-index.json`** — Static, edge-safe BM25 postings (terms → chunks with frequencies)
- **`search-content.json`** (optional) — Full chunk text, loaded on-demand by the browser or API
- **Framework clients** — `createSearchClient()` (React, Vue, Svelte, Next.js, TanStack, Cloudflare, Vercel)

### Why This Is Sufficient for Most Teams

- ✅ **Zero operational overhead** — pure static JSON, no database, no embeddings service, no vector costs
- ✅ **Zero latency** — client-side search in the browser, or instant server-side queries in workers/edges
- ✅ **Works offline** — consumers of bundled docs (npm packages) get search without external calls
- ✅ **Semantic enough** — stemming, synonyms, phrase matching, and typo tolerance handle real queries well
- ✅ **Framework-agnostic** — same index works in Next.js, Astro, Remix, plain HTML, agents, CLIs, etc.

---

## 2. When Embeddings Are Actually Warranted

Add embeddings **only if**:

1. **Your docs are enormous** (10,000+ pages) AND users search by concept rather than keywords
   - Example: A large reference API or scientific docs where "rate limiting" might be called "backpressure," "request throttling," or "flow control"
   - BM25 will miss concept-level synonymy that embeddings capture

2. **You have high query diversity** and users phrase things in ways your docs don't
   - Example: Users ask "How do I make my app faster?" and your docs say "Performance tuning," "Optimization," "Caching strategies" — but the connections aren't linguistically close
   - Embeddings excel at semantic similarity across rephrasing

3. **Search quality metrics drop significantly** (A/B tests show embeddings help click-through rate or relevance)
   - This is the only proof that embeddings are justified; assume BM25 is winning otherwise

### What You Must Keep Even With Embeddings

- ✅ **BM25 as the fallback** — Embeddings fail silently or degrade for rare/novel terms; BM25 still matches the exact words
- ✅ **Static, deterministic indexing** — Reindex only on doc updates, not continuously
- ✅ **The chunk structure** — Don't embed entire documents; keep semantic overlap so context is available at boundaries
- ✅ **Multi-factor scoring** — Blend BM25 score + embedding similarity, don't replace one with the other
- ✅ **Term-based metadata filtering** — Keep title/heading/code weights; these are high-signal anchors that improve precision

### Architecture Pattern (If Embeddings Are Added)

```
Request → BM25 candidate set (20–50 chunks) → Re-rank with embeddings → Top 8 results

Not:
Request → Vector similarity only → Top 8 results
(This loses lexical precision and fails on edge cases.)
```

---

## Summary

**Default:** BM25 (static, zero infrastructure, good UX for 90%+ of doc sites)  
**When to add embeddings:** Only after proving (via metrics) that concept-level search is a real gap, and always as a re-ranker, never as the sole ranker.  
**What stays:** BM25, chunking, term weights, static generation, multi-factor scoring.
