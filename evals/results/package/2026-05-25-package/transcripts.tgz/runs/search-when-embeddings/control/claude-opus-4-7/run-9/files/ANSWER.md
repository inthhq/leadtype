# Do we need a hosted vector index for docs search?

Short answer: **no, not by default.** `leadtype` already ships a docs search system, and it is deliberately not a vector store. Build on what's there first; add embeddings only when you can name the specific failure mode they fix.

## 1. What leadtype's docs search does by default

From the package's own README and the `leadtype/search` module:

- **Algorithm: BM25.** Classic lexical ranking. The constants are literally in the source (`BM25_K1 = 1.2`, `BM25_B = 0.75` in `node_modules/leadtype/dist/_shared/search-TL9muun_.js`). No embeddings, no ANN index, no model calls at query time.
- **Artifact: a static JSON file.** `leadtype generate` emits `public/docs/search-index.json` alongside the markdown mirrors and `llms.txt`. That's it — one file, generated at build time.
- **Runtime: edge-safe, no database.** The runtime in `leadtype/search` (`createDocsSearchIndex`, `searchDocs`, `attachDocsSearchContent`) loads that JSON and runs BM25 in-process. It is designed to run on edge workers and serverless — no Postgres, no pgvector, no Pinecone/Weaviate/Qdrant, no hosted index to operate.
- **Chunking + content store.** The index is chunk-based (`DocsSearchChunk`, `readDocsContentChunk`, `listDocsContentFiles`), so results carry enough context to render snippets and feed downstream tools.
- **Optional source-grounded answers (still BM25 under the hood).** `createAnswerContext` + the adapters in `leadtype/search/vercel`, `leadtype/search/tanstack`, and `leadtype/search/cloudflare` take the BM25 results as the retrieval step and stream an LLM answer grounded in those chunks. The retrieval is still lexical; the LLM only sees the top BM25 hits as sources.
- **Built-in request hygiene.** `validateDocsQuery`, `createMemoryRateLimiter`, `getClientIdentifier`, and `DocsSearchRequestError` exist so the search endpoint isn't a free LLM/abuse vector.
- **Client integrations included.** `leadtype/next/client` (`useLeadtypeSearch`, `createSearchClient`) and framework hooks in `leadtype/search/react|svelte|vue` wire the static index into a UI without extra infra.
- **Read-only docs adapters for agents.** `leadtype/search/bash` exposes the same index to coding agents — no separate retrieval stack needed for them either.

Net effect: out of the box you get keyword search + optional RAG-style answer streaming, served as static files from your existing CDN/edge. Zero new services, zero index to keep in sync with the docs, zero embedding bill. The docs change → `leadtype generate` → new `search-index.json` ships with the site.

## 2. When adding embeddings is actually warranted

A hosted vector DB is justified only if BM25 demonstrably fails on real query logs, in ways embeddings specifically fix. Concretely, only consider it when **all** of the following are true:

1. **You have evidence, not vibes.** Real user queries are logged and a measurable fraction of them return poor BM25 results — typically:
   - heavy synonym / paraphrase mismatch (users say "auth", docs say "sign-in"; users say "rate limiting", docs say "throttling") that you can't solve with a synonym list or better headings;
   - genuinely conceptual / cross-document questions where no single chunk contains the keywords;
   - multilingual queries against single-language docs.
2. **The cheap fixes are already exhausted.** Better titles/headings, frontmatter keywords, a small synonym map, fixing broken navigation, and re-chunking are all faster, free, and usually move the needle more than embeddings. `leadtype lint` plus tightening the source is the first move.
3. **Corpus and traffic justify the operational cost.** A few hundred MDX pages with modest traffic do not need a vector DB. You're taking on an embedding pipeline, a hosted index, drift between docs and vectors, a re-embed step on every change, and a new failure domain — pay that only when scale demands it.
4. **You actually need semantic recall, not better answers.** If the complaint is "answers are wrong/ungrounded," the fix is usually the answer layer (prompt, top-k, citation rendering via `createAnswerContext`), not the retrieval algorithm.

### What to keep even then

If you do add embeddings, do **not** replace leadtype's pipeline — extend it:

- **Keep `leadtype generate` as the source of truth.** The flattened markdown in `public/docs/*.md` and the chunk boundaries from `search-index.json` should be what you embed. That guarantees your vector store and your lexical store describe the same chunks, with the same URLs and headings.
- **Keep BM25 and run hybrid retrieval.** Lexical search wins on exact identifiers (API names, error codes, CLI flags, package names) — exactly the queries docs users send most. Use BM25 + vector and fuse the results; don't drop BM25.
- **Keep the static index as the fallback.** Edge/offline/agent contexts (`leadtype/search/bash`, bundled package docs, CI) should keep working without your vector service. If the vector DB is down, search should degrade to BM25, not 500.
- **Keep `createAnswerContext` and the streaming adapters.** They're agnostic to how `DocsSearchResult[]` was produced. Plug hybrid retrieval in, leave the grounding/citation/rate-limit/validation layer alone.
- **Keep re-embedding tied to `leadtype generate`.** Treat the vector index as a derived artifact of the same build, not a separately-maintained database. Otherwise the docs and the embeddings will drift, which is the most common failure mode of hosted RAG.

### Recommendation

Ship the default leadtype pipeline now. Log queries and click-throughs. Revisit embeddings only when the logs name a concrete query class BM25 cannot answer — and even then, add embeddings *alongside* the existing static index, not instead of it.
