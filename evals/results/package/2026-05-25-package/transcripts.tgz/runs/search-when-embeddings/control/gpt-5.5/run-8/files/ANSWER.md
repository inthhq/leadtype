# Leadtype docs search vs. hosted vector search

## What Leadtype uses by default

Leadtype already generates a docs search index from the same resolved Markdown it emits for agent-readable docs. By default this is **not** a hosted database-backed vector index and it does **not** require embeddings.

The default search path is:

- `leadtype generate` emits a static `search-index.json` for the docs site.
- The runtime in `leadtype/search` queries that static artifact with an edge-safe, in-process **BM25 lexical index**.
- Documents are split into overlapping chunks; Leadtype defaults to 1,200-character chunks with 160-character overlap.
- Ranking weights title, heading, body, and code matches, then adds useful lexical expansion/boosting: exact terms, stemming, built-in/custom synonyms, prefix matches, typo tolerance, phrase matches, and proximity matches.
- The default client/runtime fetches the generated static index/content artifacts and searches them directly; there is no required search server, vector database, or embedding pipeline.
- If we want generated answers, Leadtype’s AI adapters build a source-grounded answer context from the same search results and ask a model to answer only from those cited documentation excerpts. That is RAG-style answering over the Leadtype index, but retrieval is still the static BM25-based docs search unless we add something else.

## When embeddings are actually warranted

Add embeddings only after the default Leadtype search has been evaluated and shown to fail on real docs-search needs that lexical search cannot reasonably cover. The concrete bar should be something like:

1. We have production/search-test queries where the right page has little or no vocabulary overlap with the query, and Leadtype’s BM25 + stemming + synonyms + prefix/typo/phrase/proximity handling does not retrieve it.
2. The missed queries are important and common enough to justify the extra system: embedding generation, re-indexing, hosted storage, latency, cost, observability, deletion/versioning, and security controls.
3. The problem is genuinely semantic, for example broad conceptual paraphrases, cross-language/natural-language queries, or fuzzy task descriptions where users do not know our product terms.
4. We have an evaluation set showing that embeddings or hybrid retrieval improve recall/quality without hurting exact API, option, error-code, heading, and code-symbol lookups.

Even then, we should keep Leadtype’s generated Markdown artifacts and BM25/static index. Use embeddings as an additional semantic recall layer or reranker, not as a replacement. Keep the lexical index for exact matches, code/API names, errors, versioned docs behavior, deterministic edge fallback, and fast zero-infrastructure search. Also keep Leadtype’s source-grounded answer pattern: final answers should cite retrieved documentation chunks and be constrained to those sources rather than trusting the model or the vector store as the source of truth.
