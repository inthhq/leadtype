# leadtype Docs Search — What It Already Gives You

## 1. What leadtype's docs search uses by default

leadtype's search is **purely static and lexical — no database, no server, no embeddings**.

### How it is built

`generateDocsSearchFiles` (from `leadtype/search/node`) reads every markdown file
under `<outDir>/docs/`, parses frontmatter, and calls `createDocsSearchIndex`.
The output is two plain JSON files written to disk alongside the markdown:

| File | Contents |
|---|---|
| `search-index.json` | Inverted term index (documents, chunks, posting lists, `averageChunkLength`) |
| `search-content.json` | The raw chunk text for excerpt generation (kept separate to allow lazy loading) |

No external process, no database, no network call — the files are generated once
at build time and served as static assets.

### How the index is structured

* **Chunking** — each document is split into section blocks (heading-delimited),
  then body and code are each sliced into overlapping windows
  (`maxChunkChars = 1 200`, `overlapChars = 160` by default).
* **Inverted index** — every token maps to a list of postings:
  `[chunkIndex, titleTF, headingTF, bodyTF, codeTF]`.
  The four term-frequency slots are stored separately so field weights can be
  applied at query time.
* **No vectors or embeddings** — the `DocsSearchIndex` type contains
  `documents`, `chunks`, `terms` (the inverted index), and
  `averageChunkLength`. There is no embedding field, no similarity field,
  no external store reference.

### How queries are executed

`searchDocs` runs entirely in-memory after loading the two JSON files:

1. **Tokenisation & normalisation** — Unicode NFKD, diacritic strip, lower-case,
   stop-word removal.
2. **Multi-strategy term expansion** — for each query token:
   - Exact match (weight 1.0)
   - Stem match (`-ing`, `-ed`, `-ies`, `-es`, `-s` rules; weight 0.82)
   - Built-in synonym expansion (e.g. `install → setup, add`; weight 0.72)
   - Prefix expansion up to 24 terms (weight 0.55)
   - Typo tolerance via Levenshtein distance ≤ 2 for tokens ≥ 4 chars (weight 0.45)
3. **BM25 scoring** — `k1 = 1.2`, `b = 0.75`, with field weights
   (title × 4, heading × 2, body × 1, code × 0.35).
4. **Phrase / proximity boost** — exact phrase match in a chunk adds +1.4;
   ordered proximity within an 8-token window adds +0.8.
5. **Result assembly** — top-N scored chunks become `DocsSearchResult` objects,
   each with a contextual excerpt, heading path, anchor hash, and absolute URL.

### The optional "answer" layer

`createAnswerContext` (also in `leadtype/search`) takes the same BM25 results,
picks the top sources (default 6), trims them to fit a context budget
(default 12 000 chars), and composes a `{ system, prompt }` pair ready to pass
to any LLM. The streaming adapters in `leadtype/search/vercel`,
`leadtype/search/tanstack`, and `leadtype/search/cloudflare` wrap that context
in a `streamDocsAnswer` call. The retrieval step is still BM25 from the static
index — the LLM only synthesises the answer, it does not do the retrieval.

### Summary

Everything — chunking, term indexing, BM25 scoring, synonym expansion, typo
correction, phrase boosting, and LLM-context assembly — runs on a pair of flat
JSON files. No database. No embedding model. No vector store. Works on any edge
runtime or CDN.

---

## 2. When embeddings are actually warranted — and what to keep regardless

### When adding embeddings is warranted

Embeddings (and the database-backed vector index that stores them) are only
warranted when **all three** of the following are true simultaneously:

1. **The query is genuinely semantic, not keyword-based.**
   A user types "how do I not get locked out after a bad deploy?" and the
   relevant page uses words like "rollback", "canary", "feature flag" — no
   token in the query appears in the document.
   leadtype's synonym table and prefix/typo expansion handle a wide band of
   keyword mismatch; pure semantic drift (e.g. a question phrased as a
   problem statement vs. a doc section phrased as a solution) is where BM25
   degrades and dense retrieval helps.

2. **You have measured a real retrieval gap, not assumed one.**
   Before standing up an embedding pipeline, run the existing static search
   against your actual query log. If recall@5 or recall@10 is already
   acceptable for the queries users actually type, there is no gap to close.
   The phrase/proximity boost and multi-strategy expansion mean recall is often
   better than naive BM25 would suggest.

3. **The operational cost is justified.**
   A hosted vector index adds: an embedding model call at index time and at
   query time, a vector database (Pinecone, pgvector, Weaviate, …), latency
   from a network round-trip, an API key, a monthly bill, and a freshness
   problem (the index must be re-embedded whenever docs change). That is only
   worth it if the retrieval improvement is real and material to user outcomes.

### What to keep even when you add embeddings

**Keep the BM25 static index and use it alongside embeddings (hybrid retrieval).**

leadtype's lexical index is faster (no network hop), cheaper (no per-query
embedding call), and more precise for exact names, CLI flags, API identifiers,
and error codes — exactly the queries that dense retrieval handles worst.
Hybrid retrieval (BM25 + cosine similarity, fused via Reciprocal Rank Fusion or
a simple weighted sum) consistently outperforms either approach alone.

Concretely:
- Continue generating `search-index.json` and `search-content.json` at build time.
- Continue calling `searchDocs` for the lexical pass.
- Add a vector pass only for queries that fail the lexical pass, **or** run both
  in parallel and fuse the ranked lists.
- Continue using `createAnswerContext` for LLM prompt assembly — it already
  handles context budgeting and citation formatting correctly, and it is
  model-agnostic; it will work equally well with sources that came from a
  vector store.

Throwing away the static index in favour of a pure vector store would regress
precision on identifier-heavy queries, add latency, add cost, and remove the
ability to serve search from a CDN with zero backend infrastructure.
