# What Leadtype's Docs Search Already Provides

## 1. Default Search Implementation: Static BM25 Index

By default, **leadtype generates a static, JavaScript-based BM25 search index** with no external dependencies or hosted infrastructure required.

### How It Works

- **Algorithm**: BM25 (Best Matching 25), a proven information retrieval ranking function that balances term frequency, document frequency, and field-specific weightings
- **Storage**: Serialized JSON index file (`search-index.json`) that's edge-safe and edge-deployable
- **Chunking**: Automatically segments markdown content with smart overlap (default: 1200 chars per chunk, 160 char overlap)
- **Field Weighting**: Differentiates term importance by location:
  - **Title**: 4× weight
  - **Headings**: 2× weight  
  - **Body text**: 1× weight
  - **Code blocks**: 0.35× weight
  
### Query Intelligence Built-In

The search implementation includes sophisticated query expansion **without embeddings**:

1. **Exact Term Matching** (weight: 1.0) — direct token lookup
2. **Stemming** (weight: 0.82) — morphological variants (e.g., "installing" → "install")
3. **Synonym Expansion** (weight: 0.72) — built-in domain synonyms (`ai`↔`agent`↔`llm`, `cli`↔`command`, `config`↔`settings`, etc.)
4. **Prefix Matching** (weight: 0.55) — auto-completes for tokens ≥4 chars
5. **Typo Tolerance** (weight: 0.45) — 1–2 edit distances for misspellings
6. **Phrase Matching Boost** (1.4× multiplier) — exact phrase matches get an extra score boost
7. **Proximity Matching** (0.8× multiplier) — tokens appearing close together in order

### Output Files Generated

```
generate --src . --out public --base-url https://example.com
```

Creates:
- **`search-index.json`** — The BM25 index (terms, postings, chunk metadata)
- **`search-content.json`** (optional) — Chunk text content (separate for bandwidth control)
- **Framework adapters** — Ready-to-use search clients for Next.js, React, Vue, Svelte, TanStack Start, Nuxt
- **Answer context builder** — Structured grounding for LLM responses with cited sources

### Example: Framework Integration

```typescript
// Next.js example (from leadtype/next/client)
import { useLeadtypeSearch } from 'leadtype/next/client'

const { results } = await useLeadtypeSearch('vector database')
// Returns: { id, title, url, excerpt, headingPath, score }
// No embeddings model needed; runs instantly in browser or edge
```

---

## 2. When to Add Embeddings — And What to Keep

### DON'T Add Embeddings If:

- Your docs are **≤10K pages** (BM25 scales exceptionally well)
- Users perform **keyword-forward searches** (technical docs, API references)
- You want **instant, zero-latency responses** (static index works client-side or on edge)
- Your search queries are **≤400 characters** (BM25 doesn't degrade; embeddings models do)
- You need **deterministic, reproducible results** (embeddings drift with model updates)
- You lack a strong **semantic ambiguity problem** (e.g., "activate" vs. "enable" — synonyms already solve this)

### DO Consider Embeddings If:

1. **Semantic ambiguity dominates**  
   - Users ask questions in natural language that synonyms don't cover  
   - Example: "How do I make my code faster?" should match "performance optimization"  
   - BM25's synonym expansion may not cover all cognitive distances

2. **Cross-lingual or dense concept matching**  
   - Docs in multiple languages, users query in one
   - Highly multi-faceted concepts needing fuzzy matching

3. **Very large doc sets (100K+ pages)**  
   - Post-filter: Use embeddings to narrow candidates, then rank with BM25

4. **Users explicitly ask for it**  
   - They've indicated semantic search matters to their workflow

### What to Keep Even When Adding Embeddings

**Do not replace BM25.** Implement a **hybrid strategy**:

1. **Keep the static BM25 index as the primary retrieval layer**
   - Remains your edge-deployable, zero-latency fallback
   - Handles keyword queries perfectly
   - Requires zero external API calls

2. **Use embeddings as a *secondary*, re-ranking layer only**
   - Generate embeddings during build time (not at query time)
   - Store them alongside the static index
   - Query BM25 first to get top-N candidates (e.g., top 20)
   - Re-rank those candidates with semantic similarity if needed
   - Users never wait for embedding lookups; they get instant BM25 results

3. **Keep the structure: index + optional content file**
   - BM25 returns `{ id, score, excerpt, url }`
   - Embedding re-ranking only changes the **sort order** of what BM25 already found
   - This preserves all existing client integrations

### Example: Hybrid Implementation

```typescript
// 1. Query BM25 first (instant, no network)
const bm25Results = searchDocs(index, query, { limit: 20 })

// 2. Optional: Re-rank with embeddings (if available)
const queryEmbedding = await generateEmbedding(query)
const reranked = bm25Results
  .map(r => ({
    ...r,
    semanticScore: cosineSimilarity(queryEmbedding, r.embedding)
  }))
  .sort((a, b) => (a.semanticScore + a.score) - (b.semanticScore + b.score))
  .slice(0, 8) // Return top 8

// If embeddings fail or aren't available, return the BM25 results unchanged
```

### Cost-Benefit Analysis

| Scenario | BM25 Only | BM25 + Embeddings |
|----------|-----------|------------------|
| **Time to first result** | <10ms (static) | 10ms (BM25) + X (embedding API) |
| **Infrastructure** | None (static file) | Vector DB + embedding API |
| **Failures/Degradation** | User gets results | User gets BM25-only results (acceptable) |
| **Keyword queries** | Perfect | Good (may over-rank semantic matches) |
| **Semantic queries** | Good | Better, but slower |
| **Cost** | $0 | $0.01–10K+/month depending on scale |

---

## Summary

**leadtype's default BM25 search is production-ready for 99% of docs use cases.** It includes query intelligence (stemming, synonyms, typo tolerance, phrase matching) that feels semantic without the latency, cost, or infrastructure.

**Only add embeddings** if you've validated that:
1. Users are losing because of lexical mismatches your synonyms don't cover, AND
2. You're willing to pay latency + infrastructure cost for the marginal improvement

**When you do**, keep BM25 as your primary layer and use embeddings only to re-rank BM25's top candidates. This preserves reliability, speed, and cost-efficiency while gaining semantic benefits.
