# Leadtype Docs Search: What It Provides By Default

## 1. What Leadtype Uses by Default

**Leadtype's docs search uses BM25 (Best Match 25)** — a proven, lexical-ranking algorithm.

### The Core BM25 Implementation

The search index (`search-index.json`) is built at **build time** (via `generateDocsSearchFiles`) and contains:

- **Tokenized terms** extracted from document titles, headings, body text, and code blocks
- **Weighted posting lists** that track term frequency across indexed content regions
- **Linguistic features**: stemming (e.g., `running` → `run`), stopword removal, diacritics normalization
- **Query expansion** through synonyms (both built-in and custom), prefix matching, typo tolerance, and stemming
- **Multi-field scoring** with weights: titles (4×), headings (2×), body (1×), code (0.35×)
- **BM25 scoring parameters**: K1 = 1.2, B = 0.75
- **Phrase and proximity matching boosts** for multi-token queries
- **Edge-safe, zero-dependency runtime** — the index loads entirely client-side, works in Cloudflare Workers, browsers, CLI, Node.js

### Artifact Structure

The build produces:

1. **`search-index.json`** — the inverted index structure (can be embedded or separate)
2. **`search-content.json`** — the full chunk text (split with overlap for context) — can be embedded in the index or served separately
3. **On-disk searchability** when bundled as `AGENTS.md` for offline agent docs

### Search Workflow

1. Query is **validated** (max 400–600 chars, control character check)
2. Query tokens are **expanded** via stemming, synonyms, prefixes, typos, and exact matches
3. Each expanded term is **scored** using weighted BM25 (IDF × normalized frequency, weighted by field)
4. Results are **sorted** by score, then by URL
5. Top 8 results (default) are returned with **excerpts** (first 220 chars, or 80 chars before/after match)
6. Optionally, results feed into **`createAnswerContext()`** for LLM-grounded answers (up to 12 KB of context, with citations)

---

## 2. When Embeddings Are Actually Warranted

### Conditions That Justify Vector Search

**Add embeddings only if:**

1. **Your docs are semantically complex** — terminology, concepts, and intent matter more than exact keyword matches.
   - *Example:* API docs where "request timeout" and "connection reset" are semantically related but lexically disjoint.
   - *Not needed:* Step-by-step tutorials, CLI reference docs, quick-start guides.

2. **You have language or domain-specific synonymy** that BM25's built-in expansion doesn't capture.
   - *Example:* Machine learning docs where "neural net," "deep learning," and "transformer" are semantically proximate.
   - *Not needed:* Most product docs. Customize BM25's `synonyms` option instead.

3. **Your query traffic includes paraphrases and question-phrasing** that don't match keyword structure.
   - *Example:* "How do I make requests faster?" vs. indexed "performance tuning."
   - *Not needed:* User searches are already keyword-dense ("install," "auth," "API").

4. **Your index is large (1000+ pages) and BM25 recall is demonstrably poor** in user testing.
   - *Example:* Exhaustive academic or reference docs. 
   - *Not needed:* Smaller, curated doc sets where humans wrote for discoverability.

5. **You can afford the hosted infra cost** and want ranking re-training from user behavior.
   - *Example:* Elastic Search, Pinecone, or Weaviate for live, user-feedback-driven ranking.
   - *Not needed:* Static, version-locked docs; one-time generation is simpler.

### What to Keep Even With Embeddings

**Do not abandon BM25 for retrieval alone.** Instead:

- **Hybrid search**: Use BM25 as the primary filter (fast, lexical recall) and embeddings as re-ranker or supplementary retriever.
  - BM25 finds candidates; embeddings disambiguate when multiple results are relevant.
  - Avoids paying inference cost on *every* query.

- **Keep the static index as fallback** (`search-index.json`). If your embedding service is down, BM25 continues to work.

- **Preserve the chunk structure and content store** — both BM25 and embedding retrieval benefit from searchable units (titles, headings, code blocks); don't abandon the metadata.

- **Maintain build-time generation**. Don't move search off the critical path:
  - Generate the BM25 index and optionally embed chunks at build time.
  - Query-time embedding (via API) is acceptable; index-time embedding (re-generating vectors) is expensive and slow.

- **Keep excerpt generation and answer-grounding**. Embeddings are better at *finding* relevant docs, but BM25's field-weighted scoring and `createAnswerContext()` are better at *extracting* source-grounded LLM answers (they already know which fields to cite).

---

## Summary

**BM25 is your default and likely sufficient.** It's fast, static, and works everywhere. Embeddings are a re-ranking or supplementary retrieval layer for large, semantically complex, or live-feedback-driven docs — not a replacement for the core pipeline.

If you're not hitting the conditions above, you'll get more value out of:
1. Expanding BM25's `synonyms` with domain-specific terms.
2. Tuning chunk size and overlap.
3. Improving doc titles and headings for better field-weighted scoring.

Build the hosted vector index when your docs and user behavior justify it — not because "that's how RAG is done."
