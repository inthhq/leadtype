# What leadtype already gives you for docs search

## 1. What the default search uses

leadtype's docs search is **fully static and entirely BM25-based — no database, no server, no embeddings, no external API**.

Here is exactly what happens, sourced directly from the package code:

### Build time (`leadtype/search/node` → `generateDocsSearchFiles`)

1. Every MDX/markdown file under `outDir/docs/` is read and parsed.
2. Each document is **chunked** into overlapping text segments (default: 1 200-char chunks with 160-char overlaps, split on sentence boundaries where possible).
3. Each chunk is tokenised: diacritics are stripped, text is lower-cased, stopwords are dropped, and every remaining word is added to an **inverted index**.
4. Two JSON files are written to disk:
   - `search-index.json` — the inverted-index structure (terms → postings lists) plus compact chunk metadata.
   - `search-content.json` — the raw text of every chunk (loaded lazily for excerpt rendering and LLM context assembly).

No embedding model is called. No vector store is written. The artefacts are plain JSON files that can be served from any static CDN.

### Query time (`leadtype/search` → `searchDocs`)

Every query goes through a pure in-memory pipeline:

| Step | Detail |
|---|---|
| **Tokenise** | Normalise, strip diacritics, remove stopwords. |
| **Expand terms** | Exact match, stemming, **synonyms** (a built-in table plus custom overrides), prefix expansion (up to 24 terms), and typo-tolerance via Levenshtein edit-distance (up to 2 edits for tokens ≥ 7 chars). |
| **Score** | BM25 (k₁ = 1.2, b = 0.75) with **field weights**: title ×4, heading ×2, body ×1, code ×0.35. |
| **Boost** | +1.4 for exact phrase matches, +0.8 for ordered proximity within an 8-token window. |
| **Return** | Top-*k* results (default 8) with document metadata, anchor URL, and a query-centred excerpt. |

The search client (`createSearchClient`, `useLeadtypeSearch`) fetches both JSON files from the CDN once, caches them in memory, and runs every subsequent query locally — **zero round-trips after the first load**.

### Optional AI-answer layer (`streamDocsAnswer`, `createAnswerContext`)

When the answer-streaming feature is used, the exact same BM25 index selects up to 6 source chunks (default 12 000-char budget), assembles them into a grounded prompt, and streams an LLM response. The retrieval step is still BM25 — the LLM only handles generation, not retrieval.

**Summary:** the entire search stack is a static JSON file + BM25 in-memory scoring. It is edge-safe, zero-latency after hydration, requires no infrastructure, and is already chunked and retrieval-ready for the optional LLM answer layer.

---

## 2. When adding embeddings is actually warranted — and what to keep even then

### The genuine threshold

Add a vector index only when **all three** of these are true simultaneously:

1. **Semantic mismatch is a proven, measured problem.** Users are searching with natural-language phrasings ("how do I handle rate limits") that share no lexical overlap with the docs ("429 back-off strategy"), and your search analytics show those queries returning empty or irrelevant results. Discard anecdotes; look at real zero-result rates and user-satisfaction signals.

2. **The corpus is large and semantically diverse enough to benefit.** BM25 with synonym expansion and prefix/typo tolerance handles the vast majority of navigational and known-item queries very well. The crossover point where dense retrieval meaningfully outperforms BM25 on a typical structured docs set is generally in the tens-of-thousands-of-chunks range with highly varied vocabulary. If you are below that, the operational cost of a vector database will exceed the accuracy gain.

3. **You can afford the operational complexity.** A hosted vector database adds: an embedding-model call at index build time (cost, latency, API key management), a re-embedding step on every doc change, a persistent networked service (availability, latency, cost), and an additional failure mode in the search path. This is real infrastructure, not a config flag.

### What you must keep regardless

Even if you add embeddings, **do not remove the BM25 index**. The reasons are direct consequences of how leadtype's answer layer works:

- **Exact-term and code queries.** BM25 will always outperform cosine similarity on queries that contain identifiers, version numbers, flag names, or code snippets. These are extremely common in docs search.
- **The LLM answer context path.** `createAnswerContext` / `streamDocsAnswer` are already wired to the BM25 index. They depend on `search-index.json` and `search-content.json` being present. Replacing retrieval entirely would require rewriting that integration.
- **Zero-latency offline / edge use.** The static JSON index works in Cloudflare Workers, at the edge, and in the browser with no egress to a vector service. A vector DB is always a networked call.
- **The bash/agent adapter** (`leadtype/search/bash`) mounts the content store as a file map for coding agents reading the installed package. It has no concept of vector retrieval.

### Recommended pattern if you do add embeddings

Use **hybrid retrieval**: run BM25 first (it is free because the index is already in memory), run the embedding query in parallel, and merge the ranked lists with Reciprocal Rank Fusion before passing sources to `createAnswerContext`. The BM25 leg costs nothing extra and acts as a strong baseline and safety net for exact-match queries.
