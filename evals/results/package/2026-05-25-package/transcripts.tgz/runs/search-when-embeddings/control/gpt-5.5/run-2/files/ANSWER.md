# What leadtype already provides for docs search

## 1. Default docs search

leadtype does **not** require a hosted database-backed vector index by default. Its docs search is a **static, edge-safe lexical search index** generated from the same flattened Markdown that leadtype produces for humans and agents.

By default, leadtype:

- generates `docs/search-index.json` during `leadtype generate`;
- builds the index from cleaned, flattened Markdown/MDX docs;
- chunks docs by section, with defaults of about **1,200 characters per chunk** and **160 characters of overlap**;
- uses **BM25** ranking, not embeddings;
- weights matches by field: titles highest, then headings, then body text, with code weighted lower;
- expands matching with built-in search behavior such as stemming, synonyms, prefix matches, typo tolerance, phrase boosts, and proximity boosts;
- can run in browser/server/edge environments because the index is just JSON plus the leadtype search runtime;
- can produce source-grounded answer context from the same search results via `createAnswerContext` / AI streaming adapters, with sources and citations.

So the baseline architecture is: **build-time static index + runtime BM25 search over leadtype-generated doc chunks**. The default RAG path is source-grounded retrieval from that index, not a vector database.

## 2. When embeddings are actually warranted

Add embeddings only after we have evidence that leadtype's default search is failing for cases embeddings are good at solving.

Embeddings are warranted when all of the following are true:

1. We have real query logs or an evaluation set showing that relevant docs exist but BM25 does not retrieve them in the top results.
2. The misses are caused by **semantic vocabulary mismatch** rather than missing/poor docs — for example, users ask conceptual or paraphrased questions that do not share terms with the page title, headings, API names, flags, or examples.
3. Cheaper fixes have not solved it: improving titles/headings, adding synonyms, adding redirect/metadata terms, better examples, or using leadtype transformers to enrich searchable text.
4. The added operational cost is justified: embedding generation, re-embedding on docs changes, vector storage, retrieval latency, security/tenant boundaries, backup/restore, and monitoring.

Even then, embeddings should be added as a **hybrid recall/reranking layer**, not as a replacement for leadtype search.

Keep leadtype's BM25/static index because it is still better for exact technical retrieval:

- API names, package names, CLI flags, config keys, error strings, file paths, code symbols, and version-specific terms;
- deterministic source URLs, headings, chunks, excerpts, and citations;
- fast local/edge fallback when the vector service is down or stale;
- source-grounded answer construction that tells the model to use only provided docs context and cite sources.

In short: start with leadtype's static BM25 search and source-grounded answer context. Add embeddings only if measured retrieval quality shows semantic misses that lexical search plus doc/search tuning cannot fix, and keep BM25 + leadtype-generated chunks/citations as the grounding layer.