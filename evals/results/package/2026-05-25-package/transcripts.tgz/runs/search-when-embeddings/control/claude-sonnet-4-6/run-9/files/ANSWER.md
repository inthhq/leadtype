# What leadtype already gives us for docs search

## 1. What leadtype's docs search uses by default

leadtype's search is **fully static, client-side BM25** — no database, no server, no embeddings, no hosted index.

### How it works end-to-end

**Build time** (`leadtype/search/node` → `generateDocsSearchFiles`):  
All MDX source files are processed through leadtype's remark pipeline, flattened to plain markdown, then split into overlapping text chunks (default 1 200 chars, 160-char overlap). Each chunk is tokenised, stemmed, and term-frequency counted. The result is serialised into two static JSON files:

| File | What's in it |
|---|---|
| `search-index.json` | Inverted-term index: every token → array of `[chunkIndex, titleTF, headingTF, bodyTF, codeTF]` postings. Also stores document metadata and average chunk length for BM25 normalisation. |
| `search-content.json` | Parallel array of raw chunk text strings (fetched lazily, only when excerpts or answer context are needed). |

These files are served as plain static assets from your CDN/edge — there is nothing to keep running.

**Query time** (`searchDocs` in `leadtype/search`):  
The index JSON is fetched once (or preloaded) and held in memory. Every query:

1. **Tokenises** the query string (unicode word boundaries, lowercased, diacritics stripped, stopwords removed).
2. **Expands** each token into a weighted term set via:
   - Exact match (weight 1.0)
   - Stemmed variants (0.82) — a minimal English suffix-stripper built into the runtime
   - Built-in synonyms table, e.g. `config → configure, configuration, settings, options` (0.72)
   - Prefix matches up to 24 expansions (0.55)
   - Typo-tolerant Levenshtein-1/2 matches up to 16 expansions (0.45)
3. **Scores** every matching chunk with **BM25** (k₁ = 1.2, b = 0.75), with per-field weights: title × 4, heading × 2, body × 1, code × 0.35.
4. **Boosts** multi-token results by phrase-match (× 1.4) or ordered proximity within an 8-token window (× 0.8).
5. Returns the top *N* results (default 8), each with a contextual excerpt, URL, heading breadcrumb, and relevance score.

The framework hooks (`useLeadtypeSearch` for React, equivalent for Vue/Svelte/TanStack) debounce the query (default 120 ms) and manage loading state on top of this same runtime.

### The AI "Ask" layer (also ships without a vector database)

When you want natural-language answers, `createAnswerContext` runs the same BM25 search, grabs the top *N* chunks (default 6, up to 12 000 chars of context), and assembles a grounded system prompt + user prompt. The caller then pipes that into any LLM via the streaming adapters (`leadtype/search/vercel`, `leadtype/search/tanstack`, `leadtype/search/cloudflare`). The LLM gets source-grounded context and is instructed not to invent APIs, paths, or behaviour. This is a full RAG answer loop — **BM25 is the retriever**, the LLM is the reader — and it requires no vector database.

---

## 2. When adding embeddings is actually warranted — and what to keep even then

### The honest bar for adding a vector index

Embeddings + a hosted vector database add real operational cost, cold-start latency, and a sync pipeline. They are warranted only when **all three** of the following are true:

1. **Your queries are semantically distant from your doc vocabulary.** BM25 fails when users ask in completely different words than the docs use and there is no synonym or prefix overlap to bridge the gap — e.g. a user asks "how do I make the font bigger" and the docs say "configure `fontSize` in the theme." If A/B testing on real query logs shows a measurable recall gap that synonyms and stemming cannot close, embeddings help.

2. **Your doc corpus is large enough that the index JSON is a transfer problem.** `search-index.json` grows with the number of unique terms × postings. For typical docs sites (hundreds to a few thousand pages) it stays well under a few hundred KB and loads in milliseconds from a CDN. If your corpus is so large that the static JSON is genuinely too heavy for acceptable initial load time *and* you have already exhausted chunking/trimming options, a server-side vector index removes the client download.

3. **You need cross-lingual or embedding-model-specific retrieval.** If your users query in languages whose morphology BM25 stemming doesn't handle well, or you need multimodal retrieval (images, diagrams), embeddings may be necessary.

### What you must keep regardless

Even if you add a vector index, **keep the static BM25 layer**:

- **BM25 handles exact-term and keyword queries with higher precision.** Embeddings are noisy for short, specific queries like API names, CLI flags, or error codes — the very queries most likely to appear in a docs search box.
- **The static index is zero-latency after first load** (all in-memory) and works offline/at the edge with no round-trip. A hosted vector DB adds a network hop per query.
- **`createAnswerContext` + the streaming answer adapters already implement RAG** using BM25 as the retriever. Swapping in embeddings means re-implementing that entire retrieval-and-context-assembly pipeline; BM25 gives you the same end-to-end RAG loop for free today.
- **The synonym table, proximity boost, and typo tolerance** are things a vanilla embedding retriever does not give you without extra infrastructure; they are already tuned for docs vocabulary.

### Recommended path before committing to a vector database

1. Collect real user query logs.
2. Identify specific queries that return zero or poor results from BM25.
3. Check whether adding entries to the `synonyms` option in `searchDocs` / `createAnswerContext` fixes them — it often does.
4. Only if a statistically significant fraction of queries remain unresolvable by keyword means should you layer in embeddings — and even then, run them as a **re-ranker or fallback** on top of BM25, not as a replacement.
