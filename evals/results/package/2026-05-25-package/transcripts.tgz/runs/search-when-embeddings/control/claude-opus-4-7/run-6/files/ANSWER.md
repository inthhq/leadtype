# Docs Search: What `leadtype` Already Gives Us

## 1. Default behavior

`leadtype generate` builds a **static, edge-safe BM25 search index** out of your
MDX, with **no database, no embedding model, and no hosting dependency**.

Concretely, every `leadtype generate` run emits (alongside `llms.txt`,
`llms-full.txt`, and per-page markdown mirrors):

- `public/docs/search-index.json` — a single JSON file containing the inverted
  index (terms, postings, chunk metadata) tuned with classic BM25 parameters
  (`k1 = 1.2`, `b = 0.75`, visible in `dist/_shared/search-TL9muun_.js`).
- Optional separate content store, or content inlined into the index when
  `embedContent: true` is set on `generateDocsSearchFiles` (note: this flag
  means "embed the page text *into the JSON*" — it has nothing to do with
  vector embeddings).

The runtime side (`leadtype/search`, `leadtype/search/react`, the Next.js
`useLeadtypeSearch` client hook, plus the TanStack / Cloudflare / Vercel
adapters) is a thin lexical query layer over that JSON. It runs on the edge
or in the browser: fetch the index, score with BM25, return ranked chunks.

For "AI answers," `leadtype/search/ai` (`streamDocsAnswer`) uses the **same
BM25 index** to retrieve `DocsAnswerSource[]`, then streams a grounded answer
from an LLM you bring. The retrieval step is still BM25 — the LLM only
summarizes the retrieved chunks. This is the source-grounded answer mode the
README advertises.

What this means for the team's proposal:

- We do **not** need to "stand up a hosted, database-backed vector index" to
  ship docs search or RAG-style grounded answers. leadtype already does both
  with a static JSON file on a CDN.
- There is no embedding model in the pipeline, no vector DB client, no server
  to operate, and no per-query inference cost for retrieval.
- "That's how RAG is done" is folklore. RAG just means *retrieve, then
  generate*. BM25 is a perfectly legitimate retriever — often the stronger
  baseline on technical docs, where users type the exact API names that
  appear in the text.

## 2. When embeddings are actually warranted

Add a vector/embedding layer **only** when you have concrete evidence of all
of the following, not before:

1. **Measured BM25 recall failures on real user queries.** You have logged
   queries where the right page exists, BM25 misses it, and the miss is
   because of vocabulary mismatch (synonyms, paraphrase, conceptual
   questions) — not because of a content gap, bad titles, or missing
   keywords that should just be fixed in the MDX.
2. **The gap is genuinely semantic.** Users ask "how do I make my site
   bilingual" and we only document "i18n configuration." Re-titling, adding
   aliases, or improving frontmatter doesn't close it.
3. **Scale justifies the operational cost.** Enough traffic and enough
   distinct natural-language queries that the embedding inference cost,
   index-refresh pipeline, and on-call surface for a vector DB are cheaper
   than the alternative (better docs, better titles, query-time LLM rewrite).
4. **You've already tried the cheap wins:** hybrid lexical tweaks, synonym
   lists in content, an LLM query-rewrite step in front of BM25, and the
   built-in `streamDocsAnswer` flow. These usually fix the "semantic"
   complaints without a new system.

### What we keep, even then

Even if all four conditions hold and we add a vector index, **do not
replace** what leadtype gives us. Keep:

- **The leadtype BM25 index as the primary or hybrid retriever.** On API
  docs, exact-token matching ("`generateDocsSearchFiles`", "`embedContent`",
  error strings, CLI flags) beats dense vectors. The standard production
  pattern is *hybrid*: BM25 + vectors, fused (e.g. RRF). leadtype is the
  BM25 half — don't throw it away.
- **The static `search-index.json` deploy path.** It stays edge-cacheable,
  has zero runtime dependencies, and is your fallback when the vector
  service is degraded.
- **The grounded-answer flow via `streamDocsAnswer`.** Swap or augment its
  retrieval step with hybrid results; keep the source-citation contract and
  the existing adapters (`leadtype/search/vercel`, `/tanstack`,
  `/cloudflare`, `/next/client`).
- **The MDX-as-source-of-truth pipeline.** Whatever vector store we add must
  be rebuilt from the same `leadtype generate` output, not maintained by
  hand.

### Recommendation

Don't build the hosted vector index yet. Ship leadtype's default BM25 +
optional `streamDocsAnswer`, instrument query logs, and revisit only if (1)–(4)
above are demonstrably true. If they become true, add vectors *next to* BM25,
not *instead of* it.
