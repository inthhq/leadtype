# Leadtype docs search vs. a hosted vector index

## What leadtype uses by default

Leadtype already ships a database-free docs search pipeline. In normal site generation (`leadtype generate`, not `--bundle`) it converts the MDX docs to markdown and writes static search artifacts under the generated docs output, including `docs/search-index.json` and, by default in the installed package, a separate `docs/search-content.json` content store.

The retrieval model is lexical BM25, not embeddings:

- the index is static JSON, so it can be served from the docs site/CDN and queried from browser or edge/server code without a hosted database;
- docs are split into heading-aware chunks, with defaults of about 1200 characters and 160 characters of overlap;
- title, heading, body, and code terms are indexed separately and weighted differently;
- query handling includes normalization, stopword removal, stemming-ish expansion, default/custom synonyms, prefix matching, typo tolerance, and phrase/proximity boosts;
- answer helpers such as `createAnswerContext` / `streamDocsAnswer` can produce source-grounded LLM answers, but their retrieval context still comes from the leadtype search index and citations point back to docs chunks.

So the default is already a RAG-style retrieval layer for docs: static BM25 retrieval over generated markdown chunks, optionally followed by an LLM answer step using the retrieved source excerpts. It is not a hosted vector DB.

## When embeddings are actually warranted

Add embeddings only if we can show, with real or representative queries, that the default BM25/hybrid lexical behavior is failing in ways embeddings are meant to solve. Good reasons include:

1. **Persistent vocabulary mismatch**: users ask conceptual or paraphrased questions where the relevant docs use different words, and leadtype synonyms/metadata fixes do not recover the right pages.
2. **Cross-lingual or highly semantic retrieval needs**: queries and docs may be in different languages, or relevance depends more on meaning than on shared API names, flags, error strings, headings, or code terms.
3. **Corpus/runtime scale beyond the static artifact model**: the generated index/content files become too large or too slow for our target client/edge delivery, even after scoping with include/exclude or splitting indexes.
4. **Measured answer quality requires semantic recall**: an evaluation set shows source-grounded answers are missing required sources because lexical retrieval cannot find them, not because the docs are poorly titled, chunked, or written.

Even then, do **not** replace leadtype search outright. Keep:

- leadtype's generated markdown docs, `llms.txt` / `llms-full.txt`, and search artifacts as the canonical docs/search substrate;
- BM25 keyword search for exact API names, CLI flags, config keys, error messages, code identifiers, and version-specific terms, where embeddings often underperform;
- leadtype's chunk/source/citation discipline for grounded answers;
- query validation, limits, rate limiting, and source-only answer instructions from the leadtype answer helpers;
- a hybrid retrieval path: use embeddings to add semantic recall, then combine/rerank with BM25 and cite the underlying leadtype docs chunks.

In short: start with leadtype's static BM25 search and source-grounded answer context. Add embeddings only after evaluations prove semantic recall is the bottleneck, and keep BM25 plus leadtype's generated docs artifacts as the exact-match and grounding layer.
