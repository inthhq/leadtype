# What leadtype already gives you for docs search

## 1. What the default search uses

leadtype's docs search is **entirely static and runs BM25 entirely on the
client** — no database, no hosted index, no embeddings, no external service.

Here is exactly what happens at each stage:

### Build time (`leadtype/search/node` → `generateDocsSearchFiles`)

1. Every markdown file under `<outDir>/docs/` is read and parsed.
2. Each document is split into overlapping text chunks (default 1 200 chars,
   160-char overlap) organised by heading section.
3. Every chunk is tokenised (Unicode word-character regex, lower-cased,
   diacritic-stripped, stop-words removed).
4. Term → posting-list entries are written for every chunk, carrying separate
   raw frequencies for **title**, **heading**, **body**, and **code** fields.
5. The result is serialised to two plain JSON files that sit next to your
   other static assets:
   - **`search-index.json`** — the inverted index (documents, chunks, terms,
     posting lists).
   - **`search-content.json`** — the raw chunk text store used for excerpts
     and LLM context. (When `embedContent: true` is set, both files are merged
     into `search-index.json` instead.)

No vector store, no remote API call, no runtime database query touches these
files during the build.

### Query time (`searchDocs` in `leadtype/search`)

When a user types a query the runtime:

1. Tokenises the query the same way as the index.
2. Expands tokens with **stemming** (suffix-strip), **synonyms** (a built-in
   table plus optional custom synonyms), **prefix matching** (up to 24
   expansions), and **fuzzy / typo matching** (Levenshtein ≤ 1–2, up to 16
   expansions).
3. Scores every matching chunk with weighted **BM25** (k₁ = 1.2, b = 0.75),
   with separate field weights: title × 4, heading × 2, body × 1,
   code × 0.35.
4. Applies a post-scoring **phrase-match boost** (× 1.4) and an
   **ordered-proximity boost** (× 0.8) when multiple query tokens appear
   near each other in order.
5. Returns the top-*N* results (default 8) with excerpts centred on the
   first matching token.

The entire search round-trip is **in-process, zero-latency, zero-cost**: the
JSON artifacts are fetched once (or pre-loaded), and every subsequent query
is pure synchronous JavaScript with no network hop.

### The optional LLM / "ask" layer (`createAnswerContext`, `streamDocsAnswer`)

leadtype also ships a thin RAG wrapper:

- `createAnswerContext` runs `searchDocs` (BM25 as above), slices up to
  `maxSources` (default 6) chunks to fit `maxContextChars` (default 12 000),
  and assembles a `system` + `prompt` string ready to pass to any LLM.
- `streamDocsAnswer` (`leadtype/search/vercel`, `/tanstack`, `/cloudflare`)
  calls whatever `LanguageModel` you hand it with that context and streams
  the reply back to the browser.

The retrieval step is **still BM25 from the static JSON** — the LLM only
handles generation. There is no separate embedding or vector retrieval step.

---

## 2. When embeddings are actually warranted — and what to keep either way

### Keep BM25 regardless

BM25 over the static JSON is not a stopgap to be replaced. It should stay
**in every configuration** because:

- It is exact-term and synonym-aware, so it never hallucinates a "similar"
  document that merely sounds related.
- It handles code identifiers, CLI flags, and API names precisely — things
  embeddings often blur together.
- It has zero latency, zero cost, zero infrastructure, and no rate limits.
- It already includes stemming, prefix, and typo expansion, so it degrades
  gracefully for near-miss queries.

### The specific conditions under which adding a vector index is warranted

Add embeddings only when **all three** of the following are true:

1. **Semantic-gap queries are measurably hurting users.** BM25 fails when the
   user's vocabulary does not share any tokens with the docs — e.g. "how do I
   make my docs machine-readable?" returns nothing because neither
   "machine-readable" nor its synonyms appear in the index, while the relevant
   page is titled "LLM bundles". This must be confirmed by real failed-query
   logs, not assumed.

2. **The doc corpus is large and diverse enough that semantic retrieval
   outperforms expansion.** leadtype's built-in synonym table, prefix
   expansion (≤ 24), and typo tolerance (Levenshtein ≤ 2) already close most
   vocabulary gaps for a focused docs set. Embeddings add meaningful recall
   lift only once the corpus is broad enough that a static synonym table
   cannot be maintained and the query space is genuinely open-ended.

3. **You can accept the operational cost.** A hosted vector index introduces
   an external service dependency (network latency, API keys, billing,
   uptime), an embedding model that must be kept in sync with the index every
   time docs change, and a more complex retrieval pipeline that can fail
   silently.

### If you do add embeddings: keep BM25 as the primary retrieval tier

Use a **hybrid reranking** pattern:

1. Run `searchDocs` (BM25) to get an initial candidate set.
2. Re-rank or augment with vector similarity scores.
3. Pass the merged, deduplicated results to `createAnswerContext` for LLM
   context assembly.

This preserves exact-term precision for identifiers and API names while
gaining semantic recall for natural-language queries. A pure vector index
with BM25 removed will lose recall on the exact technical terms that matter
most in docs search.
