# Leadtype docs search and embeddings

## What Leadtype uses by default

Leadtype already builds docs search without a hosted database or vector store. Its default search output is a **static, edge-safe JSON search index** generated from the resolved/flattened markdown docs.

The runtime search is lexical **BM25** over document chunks, not embeddings. From the installed package, the indexer/searcher:

- chunks docs with overlap (`maxChunkChars` default 1200, `overlapChars` default 160);
- tokenizes and normalizes text;
- indexes title, heading, body, and code fields with different weights;
- uses BM25 scoring (`k1 = 1.2`, `b = 0.75`);
- expands matches with stems, configured/default synonyms, prefixes, and typo tolerance;
- boosts phrase and ordered-proximity matches;
- returns source chunks with URLs, headings, excerpts, and scores.

Leadtype also supports optional **source-grounded answers**: it retrieves sources from the same BM25/static index, builds a constrained prompt/context with citations, and streams an answer through supported AI adapters. That is already a RAG-style flow, but retrieval is static lexical search by default rather than a hosted vector database.

## When embeddings are actually warranted

Do not add embeddings just because the feature is called “RAG.” Add them only if we can show that Leadtype’s default BM25 search is insufficient for our docs after normal tuning.

Embeddings are warranted when we have one or more measured requirements like:

1. **Semantic recall failures:** real user queries consistently do not share vocabulary with the relevant docs, and synonyms/content fixes are not enough.
2. **Large conceptual query surface:** users ask broad natural-language questions where the right page is described indirectly, not by API names, option names, error text, or headings.
3. **Cross-lingual or paraphrase-heavy search:** queries and docs often use different languages or substantially different phrasing.
4. **Empirical quality gap:** evaluation on production/search-log queries shows BM25 misses relevant chunks at acceptable recall, while embedding or hybrid retrieval improves it enough to justify the extra cost and operations.
5. **Corpus scale/shape demands it:** the docs corpus grows beyond what static JSON search can reasonably ship/query for the target clients, or we need centralized query-time retrieval services for other product reasons.

Even then, we should **keep Leadtype’s BM25/static index and generated source chunks**. Use embeddings as an additional retrieval signal, preferably in a **hybrid** pipeline:

- keep BM25 for exact matches on API names, config keys, CLI flags, code symbols, error messages, and versioned terms;
- keep Leadtype’s markdown-derived chunks as the source of truth for citations and answer grounding;
- combine or rerank BM25 and vector results rather than replacing lexical search with vector-only search;
- preserve the no-database/static path as a fast fallback and for edge/client-side docs search where possible.

In short: Leadtype already provides static BM25 search plus source-grounded answer context. Embeddings should be added only to solve demonstrated semantic-recall problems, and they should augment—not replace—the existing lexical index and grounded source pipeline.
