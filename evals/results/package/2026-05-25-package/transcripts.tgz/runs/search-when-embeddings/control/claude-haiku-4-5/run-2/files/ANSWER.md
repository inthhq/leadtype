# What leadtype's Docs Search Provides by Default

## 1. Default Search Implementation: BM25 Full-Text Search (No Embeddings)

**leadtype** builds a **static, compressed BM25 full-text search index** by default. Here's what that means:

### The Technology
- **Algorithm**: BM25 (Best Matching 25) — a probabilistic ranking function based on term frequency and relevance scoring
- **No embeddings**: Zero vector databases, no neural network inference, no hosted infrastructure
- **Static index**: Pre-computed at build time, served as a JSON file (`search-index.json`) alongside your docs
- **Edge-safe**: The entire index runs client-side or on any edge runtime (Cloudflare Workers, Vercel Edge, etc.)

### The Index Structure
The generated `search-index.json` contains:
- **Documents**: Page-level metadata (title, description, URL, etc.)
- **Chunks**: Sub-document text segments (grouped by heading) for granular scoring and result ranking
- **Terms**: An inverted index mapping each term to chunk references with positional weights:
  - `title` matches (highest relevance)
  - `heading` matches (high relevance)
  - `body` matches (standard relevance)
  - `code` matches (lower relevance by default)
- **Average chunk length**: Used by the BM25 scoring function
- **Content store** (optional): Raw text stored separately if `embedContent: true`

### What You Get Out of the Box
```typescript
const results = await searchDocs(index, "install", {
  limit: 8,           // max results per query (default)
  synonyms?: {...}    // optional: define term aliases
});

// Returns: DocsSearchResult[]
// - id, title, description, URL anchors
// - excerpt (text snippet around the match)
// - score (BM25 relevance ranking)
```

### Key Characteristics
| Aspect | Default Behavior |
|--------|------------------|
| **Chunking** | Text split by headings with 160-char overlap to preserve context |
| **Max chunk size** | 1,200 characters (configurable) |
| **Query length** | Max 400 characters for search queries |
| **Index size** | Typically 50–200 KB for 100–500 docs (highly compressible) |
| **Latency** | Milliseconds (no network calls; runs in-process on client/edge) |
| **Cost** | Zero (no hosted inference, no API calls) |

---

## 2. When Embeddings Are Actually Warranted

Embeddings (vector search) are **only needed when BM25 is insufficient**. Specifically:

### Genuine Use Cases for Embeddings
1. **Semantic search requirements**
   - Users search for *concepts* that don't share exact terms with your docs
   - *Example*: Query "how do I install?" should match "getting started" or "setup" pages
   - *leadtype still helps*: You can add synonyms to BM25 instead: `{ synonyms: { "install": ["setup", "getting started"] } }`

2. **High vocabulary mismatch** 
   - Your docs use industry jargon; users use common language
   - Dense docs with low keyword density
   - *Prerequisites for embeddings to help*: You've already:
     - Built and tested BM25 search with good chunk sizing
     - Validated that term-based search alone is failing user tests
     - Confirmed semantic queries would improve retrieval quality

3. **Multi-language semantic matching** across translation boundaries
   - Embedding models can bridge languages better than lexical search
   - *But first*: Verify leadtype's i18n + BM25 per-locale indexing isn't sufficient

### What You **Must Keep Even When Adding Embeddings**
1. **The BM25 index itself**
   - BM25 is fast, deterministic, and works offline
   - Use it as a **retrieval pre-filter** or **fallback** when embedding inference fails or is too costly
   - Modern RAG systems use hybrid search: BM25 + embeddings together

2. **Chunk-based structure**
   - Don't index full documents; keep the heading-aware chunking
   - Embeddings need the same granularity (1,000–1,500 char chunks) for useful context windows

3. **The content store** (`search-content.json`)
   - Raw text must still be accessible for rendering excerpts and context
   - LLMs need this for grounding (not embeddings)

4. **Metadata** (titles, descriptions, URLs, heading paths)
   - BM25 scores metadata separately (matches in title > body)
   - Embeddings can't rank by metadata; you still need BM25's positional weighting

5. **Client-side search** as a first resort
   - Even with embeddings, **run BM25 client-side immediately**
   - Only call your embedding service if BM25 results don't satisfy the user query

---

## 3. The Real Picture: When to Host an Index

**Don't build a hosted vector index just because "that's how RAG is done."**

### Decision Tree
```
Does your docs search need semantic matching?
  ├─ NO → Use BM25 (leadtype default). Done.
  ├─ YES (questionable) → Try adding synonyms to BM25 first
  └─ YES (confirmed by user testing) →
       Does query latency need to be <100ms for edge compute?
         ├─ YES → Embed client-side (e.g., with local ONNX models)
         └─ NO → Host embeddings server + keep BM25 as pre-filter/fallback
```

### The Cost of Hosted Vector Index
- **Infrastructure**: Managed vector DB, embedding API, or DIY Weaviate/Pinecone/Milvus
- **Latency**: Network roundtrip vs. millisecond BM25 client queries
- **Cost**: Per-query or per-month charges; BM25 is free
- **Coupling**: Tightly bound to one embedding model; switching is hard
- **Cold starts**: API endpoints or serverless cold-starts add latency

### Why BM25 Wins for Most Docs
- Docs are **structured, high-signal text** (not raw web data)
- Search queries are **intentional and specific** (not vague user intent)
- Docs use **consistent terminology** (API references, guides)
- False positives are less costly (user can scan results quickly)

---

## Summary

**Default**: leadtype provides **static, client-side BM25 full-text search**. No embeddings, no database, no hosting needed.

**When embeddings make sense**: Only after confirming BM25 + tuned chunking + synonyms cannot meet your semantic retrieval goals.

**What to preserve**: BM25 index, chunk structure, content store, and metadata. Use embeddings as a *secondary* re-ranker or *augment* BM25 with a hybrid approach—never replace it.
