# What leadtype Already Gives You

## 1. Default Docs Search: BM25 + Static Index

By default, `leadtype` provides **keyword-based search powered by BM25**, a proven probabilistic ranking function that:

- **Runs entirely client-side** from a static `search-index.json` generated at build time
- **Chunks documents intelligently** (1200 chars per chunk by default, 160 chars overlap)
- **Indexes with term frequency scoring** — BM25 ranks results by relevance without requiring embeddings
- **Outputs structured search results** with:
  - `score` (BM25 relevance ranking)
  - `excerpt` (surrounding context)
  - Heading path and URL hash for precise navigation
  - Document metadata (title, description, locale)
- **Supports synonyms** via `SearchDocsOptions.synonyms` for semantic flexibility
- **Generates two optional companion artifacts**:
  - `search-index.json` — the inverted index and metadata (~50–100 KB typical)
  - `search-content.json` — optional full chunk text for answer generation

**Result**: Users get fast, relevant docs search without a backend database or embedding service.

## 2. When Embeddings Are Actually Warranted — and What to Keep

Add vector embeddings **only if**:

1. **Keyword matching fails regularly** — users search with natural language queries that don't match doc vocabulary (e.g., "how do I start?" vs. "quickstart"). BM25 + synonyms should be the first fix.

2. **Semantic intent matters more than terminology** — e.g., "error handling" and "exception catching" mean the same thing but use different words, or queries ask *conceptual* questions rather than searching for *specific terms*.

3. **Scale justifies the cost** — your docs are large enough (1000+ pages) and traffic is high enough that improved accuracy justifies the embedding compute and storage overhead.

### What to **Keep** Even When Adding Embeddings:

- **The BM25 index as the primary retrieval layer** — it's fast, static, and ship-able offline. Embeddings should be *supplementary* for re-ranking or for queries where keyword matching fails.
- **Static generation at build time** — embed your docs at CI/CD time into the static artifacts, not on-demand. This keeps search fast and predictable.
- **The chunk-based architecture** — splitting docs into 1000–1200 character sections with overlap is ideal for both BM25 and embedding retrieval; keep it.
- **Source-grounded answer generation** — use `createAnswerContext()` to synthesize answers from search results with citations, regardless of whether you use BM25 alone or add vector retrieval. This is the *correctness layer* that embeddings alone cannot provide.

**Bottom line**: A hosted vector database is a scaling optimization, not a foundation. Build with BM25 + synonyms first, measure whether users are actually failing to find docs, then add embeddings only to *re-rank* results when keyword search doesn't suffice — while keeping the static index as your reliable baseline.
