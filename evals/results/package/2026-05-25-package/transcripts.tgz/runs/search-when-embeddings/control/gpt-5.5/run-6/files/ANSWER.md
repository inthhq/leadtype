# Leadtype docs search and when embeddings are worth adding

## What Leadtype uses by default

Leadtype already ships a docs-search pipeline. Its default search is **not** a hosted vector database and does **not** require embeddings.

By default, `leadtype generate` produces static docs artifacts, including a static search index under the generated docs output, e.g. `docs/search-index.json` plus `docs/search-content.json` unless content is embedded. The installed package describes this as a “static, edge-safe search index (BM25, optional source-grounded answers).”

The runtime in `leadtype/search` searches that static JSON index with lexical BM25-style ranking:

- docs are converted to flattened markdown first;
- content is split into heading-aware chunks;
- default chunking is about `1200` characters with `160` characters of overlap;
- terms are tokenized, normalized, stopword-filtered, and indexed;
- fields are weighted: title highest, then headings, body, and code lower;
- query expansion includes built-in synonyms, stemming, prefix matches, and typo-tolerant matches;
- results also get phrase/proximity boosts;
- it runs in edge/browser/server contexts over static JSON, with no database service required.

Leadtype also has optional answer helpers (`createAnswerContext`, `streamDocsAnswer` adapters for Vercel/TanStack/Cloudflare-style providers). Those helpers still use the Leadtype search index to retrieve source chunks, then build a source-grounded prompt with citations. In other words: the “RAG” part Leadtype provides by default is **BM25 retrieval over generated markdown chunks + grounded answer context**, not embedding retrieval.

## When embeddings are actually warranted

Embeddings are worth adding only if we can show that Leadtype’s default retrieval is the bottleneck for our real users. Concretely, add embeddings only when all of these are true:

1. **We have real query data or an evaluation set** showing relevant pages/chunks are not appearing in the top results.
2. **The misses are semantic vocabulary-mismatch misses**, not fixable by docs changes or lexical tuning. Examples: users ask broad conceptual questions that do not share product/API terms with the docs, or they use domain language that consistently differs from our docs language.
3. **We have already tried the cheaper fixes**: improve page titles/headings/descriptions, add synonyms, tune chunking, expose better frontmatter, and use Leadtype transformers where needed.
4. **Hybrid retrieval beats BM25 alone in measurement**, e.g. better recall@k / answer success on the evaluation set without unacceptable latency, cost, operational complexity, or worse precision.

A hosted vector database may be separately justified if the index is too large or dynamic to ship as static JSON, if private/per-tenant filtering is required, or if we need near-real-time indexing. But those are hosting/index-management reasons; they still do not prove embeddings are needed unless semantic retrieval improves measured results.

## What to keep even if we add embeddings

Even if we add embeddings, we should keep Leadtype’s default pipeline as the backbone:

- keep Leadtype’s flattened markdown as the source text to embed and cite;
- keep its chunking/source metadata so results point to exact docs URLs and headings;
- keep BM25 as a lexical retriever, fallback, and/or part of a hybrid ranker;
- keep source-grounded answer prompts with citations and the “use only provided context” guardrails;
- keep the static index where possible for fast client/edge search and graceful degradation if the embedding service is down.

So the recommended path is: start with Leadtype’s static BM25 search and source-grounded answer context; add embeddings only as a measured hybrid enhancement, not as a replacement just because “that’s how RAG is done.”
