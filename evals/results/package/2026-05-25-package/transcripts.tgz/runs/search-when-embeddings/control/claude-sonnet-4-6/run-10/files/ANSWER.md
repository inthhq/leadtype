# What leadtype already gives you for docs search

## 1. What the default search uses

leadtype's docs search is **fully self-contained and runs on static JSON files with no database**.  
Here is exactly what it builds and how it works, drawn directly from the source code.

### Build time (`leadtype/search/node` → `generateDocsSearchFiles`)

1. **Markdown ingestion.** All `.md` files under the output `docs/` directory are
   read. Title, description, and body are extracted from frontmatter and content.
2. **Chunking with overlap.** Each document is split into section blocks
   (heading-delimited), then each block is further split into overlapping text
   windows (`maxChunkChars: 1200`, `overlapChars: 160` by default). Code fences
   are tokenised separately.
3. **Inverted-index construction (`createDocsSearchIndex`).** For every chunk,
   every token is added to an in-memory `terms` dictionary as a posting:
   `[chunkIndex, titleCount, headingCount, bodyCount, codeCount]`. This is the
   entire index — a plain JavaScript object.
4. **Two output files written to disk:**
   - `search-index.json` — the inverted index (documents + chunks + term
     postings). Terms are the only thing that drives ranking.
   - `search-content.json` — a parallel array of raw chunk text strings, fetched
     lazily so the initial index payload stays small (the two files can
     optionally be merged with `embedContent: true`, but that is an output
     packing option, not a change in algorithm).

Nothing is sent to an API. No embeddings. No database. The artefacts are plain
JSON files that can live in `public/` and be served from a CDN or edge function.

### Query time (`leadtype/search` → `searchDocs`)

`searchDocs(index, query)` runs entirely **in-memory in the browser or on the
edge** against the loaded JSON:

| Step | Detail |
|---|---|
| **Tokenisation** | Unicode word-character extraction, lower-case, NFKD normalisation, stopword removal. |
| **Term expansion** | For each query token: exact match (`weight 1.0`), stem match (`0.82`), synonym match (`0.72`, built-in table for `auth`, `config`, `install`, `ts`, etc.), prefix match (`0.55`, up to 24 expansions), typo/edit-distance match (`0.45`, up to 16 expansions, Levenshtein ≤ 2 for tokens ≥ 7 chars). |
| **Scoring** | BM25 (`k1 = 1.2`, `b = 0.75`) with field weights (title ×4, heading ×2, body ×1, code ×0.35). |
| **Phrase / proximity boost** | Exact phrase in chunk → ×1.4 boost; ordered proximity within a window of 8 tokens → ×0.8 boost. |
| **Result assembly** | Top-8 chunks ranked by final score, with an extracted excerpt centred on the first matching token. |

Everything runs synchronously in a single JS call — no network round-trips, no
latency tail, no auth tokens, no per-query cost.

### AI "ask" layer (optional, also built-in)

`createAnswerContext(index, query)` runs `searchDocs`, assembles the top-6 chunk
texts (capped at 12,000 chars) into a grounded system + user prompt, and returns
it. The framework adapters (`leadtype/search/vercel`, `/tanstack`, `/cloudflare`)
then pipe that context to any LLM of your choice with `streamDocsAnswer(...)`.
The retrieval step is still the same BM25 index — no vector store involved.

---

## 2. When embeddings are actually warranted — and what to keep regardless

### What BM25 cannot do well

Embeddings (vector search) outperform BM25 only in a narrow set of scenarios:

| Scenario | Why BM25 struggles | Why vectors help |
|---|---|---|
| **Severe vocabulary mismatch at scale** | A user asks "how do I stop the agent from hallucinating?" and your docs say "reducing model confabulation." No shared tokens, no synonym hit, no prefix overlap. | Semantic similarity in embedding space bridges the lexical gap. |
| **Very large corpora (thousands of pages)** | BM25 term expansion is O(vocabulary × query tokens); at extreme scale the in-memory JSON grows large and rankings can be noisy. | ANN indexes (HNSW, etc.) are sub-linear at retrieval time. |
| **Multi-lingual queries with no shared roots** | Cross-lingual search (e.g., Japanese query → English docs) breaks tokenisation entirely. | Multilingual embedding models handle this natively. |
| **Conceptual / paraphrase queries** | "What's the recommended way to structure nested routes?" has no term overlap with any specific heading. | Embeddings capture semantic intent, not just words. |

For a **typical software docs site** (tens to low hundreds of pages, English,
developer audience using domain vocabulary), these scenarios rarely materialise.
BM25 + stemming + synonyms + prefix expansion + phrase-proximity boosts handles
the vast majority of real search queries with zero infrastructure overhead.

### The specific conditions under which adding a vector index is warranted

Add embeddings **only when all of the following are true:**

1. **You have observability data showing BM25 misses.** You have measured
   real-user queries against `searchDocs` results and found a meaningful
   proportion returning zero or irrelevant results that cannot be fixed by
   adding synonym entries or improving doc titles/descriptions. Gut feeling is
   not a trigger.
2. **Your corpus is large enough that the JSON payload becomes a problem.**
   leadtype warns at 5 MB (index) / 10 MB (total) / 10,000 chunks. If you are
   well below those thresholds, you have no scalability problem to solve.
3. **You have sustained multi-language or severe paraphrase query patterns**
   that cannot be addressed with targeted synonym entries in
   `SearchDocsOptions.synonyms`.
4. **You can afford the operational complexity:** an embedding model (with API
   cost or self-hosting), a vector database, index rebuild on every doc change,
   an additional network hop per query, and auth/rate-limiting for the search
   endpoint.

### What to keep even if you do add embeddings

Even if all four conditions above are met, **do not replace BM25 — use it as a
pre-filter or re-ranker in a hybrid pipeline:**

- **Keep `search-index.json` and `createDocsSearchIndex`.** BM25 is exact on
  keyword / API-name / CLI-flag queries (e.g., `--base-url`, `defineDocsConfig`)
  where vector cosine similarity is actually worse because embeddings smooth over
  exact token identity.
- **Keep `createAnswerContext` and `streamDocsAnswer`.** The grounded-prompt
  pattern — retrieve relevant chunks first, then pass them as context to the LLM
  — is exactly what RAG is. The retrieval backend is interchangeable; the
  guardrails in the system prompt ("Do not invent APIs, options, behaviour, paths,
  or package names", "cite sources") are what make the answer trustworthy.
  Those guardrails live in leadtype's `createAnswerContext` and should be
  preserved regardless of whether you swap BM25 for vectors.
- **Keep the static-file delivery model for the keyword tier.** Serving
  `search-index.json` from a CDN with no server process means zero cold starts,
  zero per-query cost, and edge latency. A vector index adds a server round-trip
  that does not exist today; the keyword tier should remain the fast, cheap path
  for the common case.

### Bottom line

leadtype already implements a complete, production-grade, zero-infrastructure RAG
retrieval pipeline. The cost of adding a hosted vector database is real
(operational complexity, latency, per-query cost, index freshness). The benefit
is real only for large or semantically diverse corpora with demonstrated BM25 gaps.
Build the observability to detect those gaps before committing to the vector
infrastructure — and when you do add it, treat BM25 as the first tier, not as
something to remove.
