# Do we need a hosted vector index for docs search?

Short version: **almost certainly not yet.** `leadtype` already gives us a
production-quality docs search with zero infrastructure. Embeddings are a
real tool, but they're a second stage you bolt on *only* when measurable
recall problems appear — and even then, you keep the BM25 layer.

---

## 1. What `leadtype` gives us by default

When you run `leadtype generate`, the search story is fully baked in. From
the package's own README:

> Builds a static, edge-safe search index (BM25, optional source-grounded
> answers).

Concretely, the default pipeline is:

- **Lexical BM25 over chunked markdown.** The package ships a real BM25
  inverted index — confirmed in `node_modules/leadtype/dist/_shared/search-*.js`
  with the canonical constants `BM25_K1 = 1.2`, `BM25_B = 0.75`. Term
  postings are weighted per field (title / heading / body / code), so
  matches in a heading outrank matches buried in prose.
- **Static JSON artifact.** Output is `public/docs/search-index.json` — a
  single file containing documents, chunks, term postings, and the
  average chunk length. No database, no service, no network round-trip
  to a vector store. It's served as a static asset.
- **Edge-safe runtime.** `leadtype/search` runs the query in-process
  (browser, edge worker, Node — all fine). The Next.js, TanStack,
  Cloudflare, and Vercel adapters all consume the same index.
- **Sensible defaults** (from `docsSearchDefaults` in
  `dist/_shared/transformers-*.d.ts`):
  - `maxChunkChars: 1200`, `overlapChars: 160` — chunking is already
    tuned for retrieval, not just whole-page hits.
  - `searchLimit: 8` results, `maxSources: 6`, `maxContextChars: 12000`
    for grounded answers.
  - `maxQueryChars: 400`, `askMaxQueryChars: 600`, plus a built-in
    memory rate limiter and request-size guard (`readJsonWithLimit`,
    `createMemoryRateLimiter`, `getClientIdentifier`,
    `DocsSearchRequestError`).
- **Source-grounded answers without a vector DB.** `createAnswerContext`
  takes the BM25 results and assembles a system+prompt payload with
  numbered citations pointing at real `urlWithHash` anchors. The LLM
  formats the answer; the *retrieval* is still BM25. This is what most
  teams actually mean when they say "RAG."
- **No embeddings code is shipped.** Searching the package for
  `embedding|vector|hybrid` returns zero hits. The library is opinionated:
  it does lexical retrieval well and stops there.

What we get out of the box, then: chunked retrieval, field-weighted
ranking, citations, rate limiting, query validation, and grounded-answer
plumbing — all from a static file. No hosted index to operate, no
embedding bill, no reindex job, no staleness window.

## 2. When embeddings are actually warranted

Standing up a hosted vector index is justified **only when you can point
at a concrete failure of the BM25 layer that embeddings would fix**, not
because "that's how RAG is done." Specifically, all of the following
should be true:

1. **You have measured recall, and lexical search is losing on
   semantically-phrased queries.** Users search "how do I make the
   sidebar collapse on mobile" and the docs say "responsive navigation
   drawer." BM25 + the synonyms option on `searchDocs` can't bridge that
   gap and you have a query log proving it. Without a query log, you
   don't have a problem — you have a guess.
2. **The corpus is large enough for vector retrieval to matter.** For a
   few hundred chunks at 1200 chars each, BM25 with field weighting is
   typically at or above embedding recall and dramatically cheaper. The
   crossover is usually thousands-to-tens-of-thousands of chunks plus
   heterogeneous vocabulary (community Q&A, support tickets, multiple
   product surfaces).
3. **Cross-lingual or paraphrase-heavy retrieval is in scope.** If
   queries and docs are in different languages, or users routinely use
   completely different terminology than the docs, embeddings earn
   their keep. Pure product docs in one language rarely qualify.
4. **You're prepared to own the operational cost.** Hosted vector index
   = embedding pipeline on every doc change, a vector DB to monitor,
   index versioning vs. the deployed app, a re-embed bill when you
   change models, and a network hop on every query. That's real, and
   it should be paid for by a measured recall win, not vibes.

### What to keep, even if embeddings are added

If we ever do add a vector layer, we **do not rip out what `leadtype`
gives us**. The right architecture is hybrid:

- **Keep BM25 as a first-class retriever.** Exact-term matches
  (`useLeadtypeSearch`, error codes, API names, file paths, version
  numbers) are where lexical search dominates and embeddings regress.
  Run both and fuse (e.g. reciprocal rank fusion) before passing to
  `createAnswerContext`.
- **Keep the static index shipped with the site.** It works offline, at
  the edge, and during vector-DB outages. It's also what the bundled
  `AGENTS.md` / `llms.txt` / `docs/*.md` outputs rely on for
  agent-readable docs — that surface is independent of any vector store.
- **Keep `leadtype`'s chunking, citations, rate limiter, query
  validator, and answer-context assembly.** Those aren't "the BM25
  part"; they're the docs-RAG plumbing. A vector store only replaces
  *one* stage (candidate retrieval). Reusing the rest is what keeps the
  citation-grounded behavior consistent.
- **Keep `searchDocs`' synonyms option as the first escalation.** Before
  reaching for embeddings, push known query→term mappings through the
  built-in synonyms map. It costs nothing and often closes the gap that
  motivated the embeddings discussion in the first place.

### Recommendation

Ship `leadtype generate` as-is, wire up `useLeadtypeSearch` / the
relevant framework adapter, turn on logging for queries with zero or
low-scoring results, and revisit the embeddings question in a quarter
with data. If the log shows a real semantic-recall gap on a corpus large
enough to matter, add a vector retriever *alongside* BM25 — not instead
of it.
