# Leadtype docs search: what we already have

## Default behavior

Leadtype does **not** default to a hosted vector database or embeddings. Its docs search is a **static, edge-safe lexical search index** generated from the flattened markdown docs.

By default, `leadtype generate` in site mode emits docs artifacts under `public/docs`, including `search-index.json` and a `search-content.json` content store. The runtime helpers (`leadtype/search`, `leadtype/search/client`, React/Vue/Svelte hooks, etc.) load those JSON artifacts and search them directly from the browser, an edge function, or any fetch-capable runtime.

The ranking implementation is BM25-style lexical retrieval over chunks of the markdown content:

- content is chunked by markdown sections, with defaults of about **1200 chars per chunk** and **160 chars overlap**;
- terms are indexed from title, heading, body, and code fields;
- title and headings are weighted higher than body text; code is weighted lower;
- queries get practical expansions: exact terms, simple stemming, built-in/custom synonyms, prefix matches, typo tolerance, plus phrase/proximity boosts;
- default result limit is **8**.

Leadtype also has optional source-grounded answer helpers (`leadtype/search/vercel`, `leadtype/search/tanstack`, `leadtype/search/cloudflare`, etc.). Those do **not** require embeddings either: they first retrieve sources from the same BM25 search index, build a bounded context with citations, and instruct the model to answer only from that documentation context.

## When embeddings are actually warranted

Adding embeddings is warranted only when we can show a retrieval problem that the default BM25 search is not solving. Specifically:

1. We have real query logs or an eval set showing important searches where Leadtype's default search returns no useful source, or consistently ranks the right source too low.
2. The missed queries are genuinely semantic/paraphrase-heavy — users ask in terms that do not appear in the docs, and the gap cannot be fixed by better headings, page titles, descriptions, terminology, or Leadtype's synonym support.
3. The desired behavior is conceptual/natural-language recall, not exact lookup. For API names, CLI flags, error messages, config keys, package names, and code snippets, lexical BM25 is usually the stronger signal and should not be replaced by embeddings.
4. The extra operational cost is justified: embedding generation, reindexing, hosted storage, latency, privacy/security review, and failure modes are acceptable for the measured recall improvement.

Even then, we should keep Leadtype's search pipeline as the backbone:

- keep the generated flattened markdown chunks and URL/anchor metadata as the source of truth;
- keep BM25 lexical retrieval as a hybrid leg and fallback, especially for exact identifiers and code/API searches;
- keep Leadtype's source-grounded answer pattern: retrieve bounded docs context, cite sources, and tell the model not to invent APIs or behavior;
- if we add vectors, embed the same Leadtype-generated chunks and merge/rerank vector hits with BM25 hits rather than replacing the static index outright.
