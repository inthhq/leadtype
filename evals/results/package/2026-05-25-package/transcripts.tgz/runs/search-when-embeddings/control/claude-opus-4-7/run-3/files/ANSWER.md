# Docs search with `leadtype`: what we already have, and when embeddings are actually warranted

## 1. What leadtype ships by default

`leadtype generate` emits a **static, edge-safe search index** as a plain JSON file: `public/docs/search-index.json`. There is no server, no database, and no embedding model in the loop. Everything that matters runs from one JSON file plus the markdown chunks that sit next to it. Confirmed from `node_modules/leadtype/README.md` and the runtime in `node_modules/leadtype/dist/_shared/search-TL9muun_.js`.

### The retrieval algorithm

It is lexical, not semantic. Specifically:

- **BM25** scoring (`BM25_K1 = 1.2`, `BM25_B = 0.75`) over an inverted index of tokens → chunks.
- **Field weighting** so title/heading hits outrank body hits, and code is down-weighted:
  - `TITLE_WEIGHT = 4`, `HEADING_WEIGHT = 2`, `BODY_WEIGHT = 1`, `CODE_WEIGHT = 0.35`.
- **Term expansion** beyond exact match, each at a tuned weight:
  - exact (1.0), light suffix **stemming** (0.82 — e.g. `ies → y`, `ing`, `ed`, `es`, `s`),
  - **synonyms** (0.72 — both a built-in `DEFAULT_SYNONYMS` map and a user-supplied `synonyms` option on `searchDocs`),
  - **prefix** expansion (0.55, capped at 24 expansions),
  - **typo / edit-distance** fuzzy match (0.45, Levenshtein ≤ 1 for short tokens, ≤ 2 for ≥7 chars, capped at 16 expansions).
- **Phrase and proximity boosts** on top of BM25: a literal phrase match adds `×1.4`, an ordered in-window match adds `×0.8` (window = 8 tokens).
- Unicode-aware tokenization (`\p{L}\p{N}` with NFKD + diacritic stripping), a small built-in stopword list, and section-aware chunking (~1200 chars with 160-char overlap, heading path preserved for anchors).

### What you query and how it's served

- Client side: `leadtype/search` (and `leadtype/next/client`'s `useLeadtypeSearch` / `createSearchClient`) runs `searchDocs(index, query)` against the fetched JSON — i.e. **the index can run entirely in the browser or on the edge**, no backend required.
- Server/edge side: Next.js / TanStack / Cloudflare / Vercel adapters wrap the same `searchDocs` plus `createAnswerContext` for grounded LLM answers, with built-in `validateDocsQuery`, `readJsonWithLimit`, `createMemoryRateLimiter`, and `getClientIdentifier` guards.
- Grounded answers (`createAnswerContext`) feed the top-`maxSources` (default 6) BM25 chunks, up to `maxContextChars` (default 12,000), into a prompt that hard-instructs the model to cite `[n]` and refuse to invent APIs. **The retrieval feeding the LLM is still BM25 — the LLM only synthesizes.**

### Defaults worth knowing (`docsSearchDefaults`)

| Knob | Default |
| --- | --- |
| `maxChunkChars` | 1200 |
| `overlapChars` | 160 |
| `searchLimit` | 8 |
| `maxQueryChars` | 400 |
| `askMaxQueryChars` | 600 |
| `maxSources` | 6 |
| `maxContextChars` | 12,000 |
| `maxBodyBytes` | 16 KiB |

Notably, `leadtype` contains **zero references** to embeddings, vectors, or hybrid search anywhere in the package. It is a deliberate design choice, not an oversight.

## 2. When adding embeddings is actually warranted

For a docs corpus, the BM25 + stemming + synonyms + typo + phrase/proximity stack above already covers the long tail of queries that people naively assume requires semantic search. **Do not stand up a hosted vector DB by default.** It adds:

- a runtime dependency (DB + network) on what is currently a static JSON file,
- an embedding model in the build *and* query path (cost, latency, versioning),
- a re-index pipeline that has to stay in sync with `leadtype generate`,
- and prompt-injection / data-exfil surface area that the static index does not have.

Add embeddings **only** if you can point to a concrete, measured failure of the lexical pipeline. Reasonable trigger conditions:

1. **Vocabulary-mismatch queries dominate your miss log.** Users consistently search with words that genuinely never appear in the docs (different jargon, customer terminology, translated terms) — and extending `synonyms` on `searchDocs` and/or fixing the docs themselves doesn't close the gap. Until you've tried the synonyms map, you have not actually tested whether you need embeddings.
2. **Cross-lingual retrieval.** Users query in language A against docs in language B and you can't just generate localized docs. BM25 won't bridge that; multilingual embeddings will.
3. **Conceptual / "describe the problem" queries** that don't share surface tokens with the answer ("my build is slow on cold start" → an article titled "Edge runtime warmup"). If your miss log is full of these and the docs themselves can't be re-titled, embeddings help.
4. **You have measured top-k quality and it's bad.** Concretely: an offline eval set of real queries with known correct chunks, where BM25's recall@10 is unacceptable *after* you've tuned synonyms. Without this, "we need embeddings" is vibes.
5. **Corpus scale where BM25 ranking actually saturates.** This is unlikely for docs — leadtype's index is built for docs-sized corpora and ships compressed to the edge. If you have millions of chunks, revisit; if you have hundreds or thousands, you don't.

If none of (1)–(5) is true with evidence, the answer is: ship `leadtype generate`, wire up the static index, instrument the miss log, and revisit in a quarter.

### What to keep even if you do add embeddings

Embeddings should be **additive to**, not a replacement for, what leadtype already provides. Specifically, keep:

- **The BM25 lexical index as the primary or co-equal retriever.** Lexical wins decisively on exact identifiers — function names, error codes, CLI flags, package names, file paths, version strings. These are the highest-stakes queries in docs and embeddings routinely rank them worse than BM25. Combine with reciprocal rank fusion or a weighted blend; do not drop BM25.
- **The chunking, heading paths, anchors, and `urlWithHash`** produced by `createDocsSearchIndex`. Use the same chunks as the unit you embed, so retrieval results still deep-link into the right section.
- **`createAnswerContext` and its system prompt** (untrusted-context framing, mandatory `[n]` citations, refusal to invent APIs). This is the part that makes the "RAG" actually grounded; swapping the retriever doesn't change that you still need it.
- **The request guards**: `validateDocsQuery`, `readJsonWithLimit`, `createMemoryRateLimiter`, `getClientIdentifier`. A vector backend doesn't give you these.
- **The static index as a fallback.** If the vector service is down, the edge can still serve search from the JSON file. Don't regress from "works offline at the edge" to "hard dependency on a hosted DB."

### Practical recommendation

Default position: ship leadtype's static index, expose the `synonyms` option to product/docs owners, log zero-result and low-CTR queries for a quarter. Only then decide whether to layer embeddings as a *second* retriever feeding the same `createAnswerContext`. The team's stated reason ("that's how RAG is done") is not one of conditions (1)–(5).
