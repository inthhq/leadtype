# What leadtype already gives you for docs search

## 1. What leadtype's docs search uses by default

leadtype's search is **fully self-contained, static, and purely lexical — no database, no embedding model, no external service**.

### How it works end-to-end

**Build time** (`leadtype/search/node` → `generateDocsSearchFiles`)

1. Every converted Markdown file under `<outDir>/docs/` is read and parsed.
2. Each document is split into overlapping text chunks (default **1 200 chars** per chunk, **160-char overlap**) using section-aware splitting: frontmatter is stripped, headings start new blocks, code fences are tracked separately, and sentence boundaries are preferred for split points.
3. Each chunk is tokenised (`[\p{L}\p{N}]+` Unicode word characters), normalised (NFKD, diacritic-stripped, lower-cased), stopword-filtered, and term-frequency-counted — separately for **title**, **heading**, **body**, and **code** fields.
4. The result is a **BM25 inverted index** written to two static JSON files:
   - `search-index.json` — the term → postings map plus document/chunk metadata. Each posting stores per-field term frequencies `[chunkIndex, titleTF, headingTF, bodyTF, codeTF]`.
   - `search-content.json` — the raw chunk text strings (loaded lazily at query time).

Both files are plain JSON served from your CDN/edge, so **no server process is needed**.

**Query time** (`searchDocs` in `leadtype/search`)

For each query the runtime:
1. Tokenises the query the same way documents were tokenised.
2. Expands each token into a **weighted term set** using four strategies, applied in priority order:
   - **Exact match** (weight 1.0)
   - **Stem match** — light English stemmer strips `-ing`, `-ed`, `-ies`, `-es`, `-s` suffixes (weight 0.82)
   - **Synonym expansion** — a built-in table covers common dev-docs pairs (`config↔configuration↔settings↔options`, `install↔setup`, `search↔find`, `ai↔agent↔llm`, `cli↔command`, `ts↔typescript`, …) plus any custom synonyms you configure (weight 0.72)
   - **Prefix expansion** (≥4-char tokens, up to 24 expansions, weight 0.55)
   - **Typo tolerance** — Levenshtein distance 1 for tokens 4–6 chars, distance 2 for ≥7 chars, anchored on first character (up to 16 expansions, weight 0.45)
3. Scores every matching chunk with **BM25** (k₁ = 1.2, b = 0.75), weighting title hits 4×, heading hits 2×, body hits 1×, code hits 0.35×.
4. Applies a **post-BM25 boost** for phrase matches (1.4×) and ordered-proximity matches within an 8-token window (0.8×).
5. Returns up to 8 results (configurable) with a context-aware excerpt.

**For AI answer ("ask") mode** (`createAnswerContext` / `streamDocsAnswer`)

The same BM25 search retrieves the top-N chunks (default 6 sources, 12 000 chars of context). Those chunks become a grounded prompt sent to whatever LLM you configure via the Vercel AI SDK, TanStack AI, or Cloudflare Workers AI adapters. The index is still the sole retrieval mechanism — **the LLM is only the answer synthesiser, not the retriever**.

### What this means for infrastructure

| Concern | leadtype's answer |
|---|---|
| Index storage | Two static JSON files on disk / CDN |
| Query execution | In-process (edge Worker, serverless function, browser) |
| External services at query time | None |
| Embedding model | None |
| Vector database | None |
| Index rebuild | Re-run `leadtype generate` (or `generateDocsSearchFiles`) at build time |
| Cold start / latency | Index is pre-loaded or lazily fetched; all scoring is synchronous in-memory arithmetic |

---

## 2. When adding embeddings is actually warranted — and what to keep even then

### The specific conditions that justify embeddings

Add a vector/embedding layer only when **all three of the following are true** at the same time:

1. **Your corpus is large enough that BM25 misses semantically related terms at a measurable rate.**  
   In practice this means: users are querying for *concepts* that your docs express with completely different vocabulary (e.g. they type "how do I authenticate" but every doc says "log in" or "sign in" with zero token overlap), *and* the built-in synonym table and typo tolerance are not closing that gap, *and* you have evidence of the misses (zero-result queries in analytics). For a typical product docs site of a few hundred pages, BM25 + synonyms covers this very well.

2. **You need cross-lingual retrieval** (a user queries in French, the docs are in English) **or very long, conversational natural-language queries** that contain almost no keywords.  
   BM25 is token-based; it degrades when there is no lexical overlap whatsoever between query and document.

3. **You can afford the operational cost**: an embedding model to run at index time (and at query time if you embed the query), a vector store to host and query, added latency, and a rebuild pipeline that calls the embedding API whenever docs change.

### What you must keep even if you add embeddings

- **Keep the BM25 index as your primary retrieval layer** (or at minimum as a co-retriever in a hybrid search). Embeddings routinely underperform BM25 on exact-term, version-number, API-name, and code-symbol queries — exactly the high-value queries in a dev-docs context. leadtype's index already handles those well.
- **Keep the static-file deployment model.** The BM25 index is served from your CDN with zero infra. Even if you add a vector store for semantic expansion, use it to *re-rank or supplement* results, not to replace the static index entirely — you'd be adding latency and a runtime dependency for marginal gains on the common case.
- **Keep `createAnswerContext` / `streamDocsAnswer` as the answer layer.** These already take the top BM25 chunks and build a grounded LLM prompt with source citations. Swapping retrieval to a vector DB does not change this part of the pipeline; you would just feed vector-retrieved chunks into the same context-building logic instead of (or alongside) BM25 results.

### The short version

leadtype ships a production-quality BM25 engine with stemming, synonyms, typo tolerance, field weighting, phrase boosting, and an LLM answer layer — all from static JSON files, with no database or embedding model required. Add embeddings only if you have *measured* semantic-gap failures that the synonym table cannot fix, you need cross-lingual retrieval, and you are prepared to absorb the infra cost. If and when you do, run BM25 and vector retrieval side-by-side and keep the static index.
