# What leadtype Already Gives You for Docs Search

## 1. What the default search uses

leadtype's docs search is **fully static and entirely self-contained — no database, no embeddings, no external service**.

Here is exactly what it does by default:

### Build time (`leadtype/search/node` → `generateDocsSearchFiles`)

When you run `leadtype generate` (or call `generateDocsSearchFiles` directly), it:

1. **Reads every MDX/markdown page**, strips frontmatter, flattens MDX components to clean markdown, and walks the heading tree.
2. **Splits each page into overlapping text chunks** (default: 1,200 characters per chunk, 160 characters of overlap, split on sentence and word boundaries).
3. **Tokenizes each chunk** — Unicode word extraction, lowercasing, NFKD normalization, diacritic removal, stopword filtering.
4. **Applies a lightweight Porter-style stemmer** to tokens (handles `-ing`, `-ed`, `-ies`, `-es`, `-s` endings).
5. **Builds an inverted index** keyed on stems/tokens, with per-chunk BM25 posting entries that carry four separately-weighted term-frequency fields: `title`, `heading`, `body`, and `code` (weights 4 / 2 / 1 / 0.35).
6. **Serializes the result to two plain JSON files** that are written to your `outDir` (e.g. `public/docs/`):
   - `search-index.json` — the inverted index: document records, chunk entries, and the full term → postings map.
   - `search-content.json` — a flat array of chunk text strings, referenced by index from the postings.

No server process, no network call, no API key.

### Query time (`leadtype/search`, `leadtype/search/client`, `leadtype/search/react`, etc.)

When a user types a query, the runtime (running entirely in the browser or on the edge, with no server round-trip needed):

1. **Tokenizes the query** the same way as at build time.
2. **Expands the query** across four match tiers, each with a downweighted score:
   - Exact term match (weight 1.0)
   - Stem match — any index term whose stem equals the query token's stem (0.82)
   - Synonym match — from a built-in synonym table (`config → configure → configuration → settings → options`, `install → setup → add`, `ts → typescript`, `ai → agent → llm`, etc.) plus optional user-provided synonyms (0.72)
   - Prefix match — any index term that starts with the query token (≥4 chars, up to 24 expansions) (0.55)
   - Typo/edit-distance match — Levenshtein distance ≤1 for tokens 4–6 chars long, ≤2 for ≥7 chars (first character must match, up to 16 expansions) (0.45)
3. **Scores every matching chunk with BM25** (k1=1.2, b=0.75) using the four weighted TF fields and IDF, multiplied by the tier weight.
4. **Boosts phrase and proximity matches**: an exact ordered phrase in the chunk text gets +1.4; ordered proximity within an 8-token window gets +0.8.
5. **Returns the top N results** (default 8) sorted by score, each result carrying `title`, `description`, `urlPath`, `urlWithHash`, `absoluteUrl`, `anchor`, `headingPath`, `excerpt`, and `score`.

The `useLeadtypeSearch` React hook (and equivalent Vue/Svelte composables) adds a 120 ms debounce and lazy-loads the index on first keystroke. `createSearchClient` gives you the same thing framework-free. The index is fetched once and cached in memory for the lifetime of the page.

### Optional source-grounded answer layer (`leadtype/search/ai`, `/vercel`, `/tanstack`, `/cloudflare`)

On top of search results, leadtype can **assemble a RAG prompt and stream an LLM answer** — entirely through the same static index. `createAnswerContext` runs the BM25 search, picks the top 6 chunks (up to 12,000 characters of context total), and assembles a structured `{ system, prompt }` object with numbered citation blocks. The `streamDocsAnswer` adapters pass that directly to the Vercel AI SDK, TanStack AI, or Cloudflare AI Gateway. No vector database is involved at any point; the retrieval is still just BM25 over the static files.

There is also a `leadtype/search/bash` adapter that exposes the same index as a virtual filesystem for coding agents (AI tools that read docs via bash commands).

---

## 2. When adding embeddings is actually warranted — and what to keep even then

### The conditions that genuinely warrant a vector index

Add embeddings only when **all three** of the following are true for your specific use case:

1. **Your queries are consistently semantic rather than lexical.** BM25 excels at exact and near-exact keyword matching with stemming and synonym expansion. It struggles with purely paraphrastic or concept-level queries ("how do I stop the thing from re-running?" → `idempotency`) where the user's words share no stems or synonyms with the doc text. If your analytics (once you have real traffic) show a meaningful proportion of zero-result or low-quality-result queries that are clearly semantic in nature — not just misspellings or abbreviations, which BM25 already handles — then embeddings close that gap.

2. **Your docs corpus is large enough that the BM25 recall gap is measurable.** For a typical product docs site (tens to a few hundred pages), BM25 + stemming + synonyms + prefix + typo tolerance already achieves very high recall. The gap where semantic search outperforms only becomes statistically meaningful at a scale where you also have enough real queries to measure it.

3. **You can absorb the operational cost and latency of a hosted database.** A vector index requires: an embedding model (run at index build time and at query time), a vector database (hosted, managed, billed by dimension and query volume), a network round-trip from your edge function to the DB on every search request, and operational overhead for index freshness. These costs are real. They are not warranted speculatively.

### What to keep even if you add embeddings

**Keep the BM25 static index regardless.** The right architecture if you move to embeddings is a hybrid retriever — BM25 results and vector results fused (e.g. Reciprocal Rank Fusion) — not a replacement. Here is why:

- **BM25 wins on exact terms, version numbers, API names, CLI flags, and code identifiers** — the exact queries docs users type most often. Embeddings regularly mis-rank or miss these.
- **The static index is zero-latency from the user's perspective** (loaded once, queried in-memory), while vector queries add a network round-trip.
- **The static index is zero-cost at query time** (no per-query API calls, no database fees).
- **The static index works offline and on the edge** (Cloudflare Workers, Vercel Edge, any runtime) with no external dependency.
- **`createAnswerContext` and `streamDocsAnswer` already give you a working RAG pipeline** right now, using the BM25 top-k chunks as the retrieval step. The LLM answer quality is bounded by the quality of your docs, not by the retrieval mechanism, for most docs corpora.

In short: measure first. If real user queries reveal a semantic retrieval gap that BM25 + synonyms cannot close, add embeddings as a second retrieval lane and fuse the results. Do not replace the static BM25 index — it handles the common case better and for free.
