# What leadtype already gives us for docs search

## Default docs search

Leadtype's default docs search is **not** a hosted vector database. In default `leadtype generate` mode it emits a static search artifact, typically:

- `public/docs/search-index.json`
- flattened markdown docs and LLM files such as `llms.txt` / `llms-full.txt`

The search runtime is an **edge-safe, static BM25 lexical index**. It chunks the flattened docs, indexes terms, and ranks matches with BM25 plus docs-oriented scoring behavior: title/heading/body/code weighting, stemming, default synonyms, prefix/typo expansion, and phrase/proximity boosts. It can run from a JSON file without a database or embedding service.

Leadtype also includes optional source-grounded answer helpers (`createAnswerContext`, `streamDocsAnswer` adapters for Vercel/TanStack/Cloudflare). Those helpers still start from the leadtype search index: they retrieve matching doc chunks, build a bounded context, and instruct the model to answer only from those sources with citations.

## When embeddings are actually warranted

Add embeddings only if we can show that the default lexical index is failing a real retrieval requirement, not just because the feature is called “RAG.” Good reasons would be:

1. **Measured semantic-recall failures:** search logs/evals show users ask valid questions whose answers exist, but BM25 cannot retrieve the right chunks because the queries and docs use substantially different language.
2. **Conceptual or natural-language queries dominate:** users mostly ask broad paraphrased questions rather than product terms, API names, option names, commands, or error messages.
3. **The corpus needs cross-language or deep semantic matching** that token overlap, synonyms, stemming, typo tolerance, and phrase/proximity boosts cannot cover.
4. **Scale or operational constraints exceed the static artifact model:** the corpus is too large, updates too frequently, or requires dynamic per-user filtering/access control that cannot be handled by serving a static index plus content files.

Even then, we should keep leadtype's lexical/static search path. Use embeddings as a complement — for recall expansion, hybrid search, or reranking — while retaining:

- BM25 keyword search for exact API names, flags, commands, package names, and error strings.
- Leadtype's generated markdown chunks/content store as the canonical source material.
- Source-grounded answer construction with citations and bounded context.
- The static index as a fast, cheap, deterministic fallback when the vector service is slow, down, expensive, or returns semantically plausible but wrong matches.
