# What leadtype Gives Us for Docs Search

## 1. Default Search Implementation

By default, `leadtype` provides a **static, client-side BM25 full-text search index** with no external dependencies or infrastructure:

- **Algorithm**: BM25 with sophisticated term weighting (exact match, stemming, synonyms, typo tolerance, prefix matching, phrase/proximity boosts)
- **Storage**: Static JSON files (`search-index.json` + optional `search-content.json`)
- **Execution**: Runs entirely in the browser or edge environment (Cloudflare Workers, Vercel, etc.)
- **Cost**: Zero infrastructure cost; can be served from a static CDN
- **Latency**: Instant; all data loaded client-side with optional preload
- **Weights**: Searches title (4x) > headings (2x) > body (1x) > code (0.35x)
- **Features**:
  - Splits docs into overlapping chunks (1200 chars by default, 160 char overlap)
  - Handles markdown cleaning, frontmatter stripping, code fence detection
  - Supports custom synonyms (defaults include ai↔agent↔llm, install↔setup, etc.)
  - Enforces stopwords to skip common articles (a, the, for, etc.)
  - Includes excerpt extraction from matched content
  - Built-in answer context builder for RAG (grounded responses with citations)

## 2. When to Add a Hosted Vector Index

Adding embeddings and a database-backed vector index is warranted **only when**:

1. **Query scale requires faster ranking over massive doc sets**  
   - BM25's exhaustive term enumeration becomes expensive with >10K chunks or highly repetitive queries
   - Real hybrid search (semantic + lexical) adds meaningful precision

2. **Docs change frequently or need real-time updates**  
   - Static index requires rebuild on every change
   - Hosted index can ingest updates without redeploying

3. **Relevance suffers for conceptual queries with no exact term match**  
   - E.g., "How do I stop my script?" → semantically similar to "abort", "terminate", "halt"
   - BM25 + synonyms often solve this; embeddings are overkill unless domain is highly specialized

4. **Multi-language or domain-specific nuance is critical**  
   - Embeddings trained on your domain can capture intent better than generic synonyms

### What to Keep Even When Adding Embeddings

**Do not abandon the static BM25 index.** Instead, use it as a **complementary lexical tier**:

- **Keep the static index as the primary retrieval method**
  - BM25 is deterministic, debuggable, and fast for exact-match queries
  - Serves as a safety net if the vector DB fails

- **Use embeddings as a secondary re-ranker for ambiguous queries**
  - Query both simultaneously; combine scores (e.g., 70% BM25, 30% semantic)
  - Only necessary if A/B testing shows >5–10% precision gain

- **Always include exact-match verification**
  - A vector DB can return "similar but wrong" results if training data misaligned
  - BM25's term frequency gives you auditability

- **Preserve searchable metadata and chunk boundaries**
  - Embeddings work on dense vectors; you lose term-level debugging
  - Keep headings, URLs, and code indicators in metadata for post-processing

---

### Recommendation for Your Team

**Start with leadtype's default BM25.** It is production-ready for up to ~10K docs and provides:
- Instant search (no API calls)
- Transparent ranking (you can see why each result matched)
- Zero operational burden
- Full offline support

Revisit a hosted vector index only if:
- Users report bad results on real queries (not hypotheticals)
- Latency profiling shows BM25 is genuinely the bottleneck
- Your doc corpus or update frequency justifies the complexity

If you do add embeddings, keep BM25 as the foundation and use vector search to *refine* the top results, not replace them.
