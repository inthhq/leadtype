# Leadtype docs search and embeddings

## 1. What Leadtype uses by default

Leadtype does **not** require a hosted database, a vector index, or embeddings for docs search.

By default, `leadtype generate` builds static, website-hostable search artifacts from the generated markdown docs:

- `docs/search-index.json` — the compact term index
- `docs/search-content.json` — chunk text used for excerpts/context, unless content is explicitly embedded into the index

The runtime search is an edge-safe lexical search engine implemented in `leadtype/search`:

- Markdown docs are split into heading-aware chunks.
- Terms are normalized/tokenized with stopword removal.
- Ranking uses BM25-style scoring.
- Matches are weighted by field: title, heading, body, and code.
- It includes practical lexical expansions: simple stemming, default/custom synonyms, prefix matches, typo-tolerant matches, phrase boosts, and proximity boosts.
- The generated artifacts are plain JSON and can be fetched by a browser, worker, or framework client without a server-side database.

For answer generation, Leadtype also provides source-grounded answer context helpers/adapters. Those still start from the generated search index: search retrieves chunks, `createAnswerContext` builds a constrained prompt with citations, and Vercel/TanStack/Cloudflare adapters can stream an LLM answer from that context. That is RAG-style retrieval without a vector database by default.

## 2. When embeddings are actually warranted

Adding embeddings is warranted only if we can show that Leadtype's default lexical/BM25 search is failing a real retrieval need, for example:

1. **Measured semantic-recall failures:** real query logs or an evaluation set show users ask conceptually correct questions using vocabulary that is consistently absent from the docs, and BM25 plus better titles/headings/descriptions/synonyms still misses the right chunks.
2. **Large or heterogeneous corpus:** the docs span many products, APIs, versions, or domains where natural-language intent search matters more than exact terms and identifiers.
3. **Cross-lingual or paraphrase-heavy search:** users query in a different language or with heavily paraphrased wording where lexical matching is inherently weak.
4. **Validated answer quality gap:** source-grounded answers built from Leadtype's default retrieval regularly lack the necessary sources, and retrieval evaluation shows vectors improve recall enough to justify the extra infrastructure.

Even then, we should **keep Leadtype's default search path**:

- Keep the generated markdown/LLM artifacts as the canonical ingestion source.
- Keep BM25 lexical search for exact API names, option names, error strings, code identifiers, and quoted terms — vectors are often worse at these.
- Use embeddings as part of **hybrid retrieval**, not as a replacement: combine vector candidates with Leadtype/BM25 candidates, then rerank/dedupe.
- Keep Leadtype's chunk URLs, headings, excerpts, and citation/source-grounding behavior so answers remain traceable to docs.
- Keep the static JSON index as an edge-safe fallback and fast docs-site search, even if a hosted vector service is added for advanced semantic retrieval.

In short: start with Leadtype's static BM25 search. Add embeddings only after evaluation proves a semantic recall problem that the built-in index, content quality, and synonyms cannot solve; if we add them, keep BM25 and source-grounding as the backbone of the system.
