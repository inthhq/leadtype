# Do we need a hosted vector index for docs search?

Short answer: **almost certainly not yet.** Here is what `leadtype` already
ships, and the narrow conditions under which adding embeddings is justified.

## 1. What leadtype's docs search uses by default

leadtype generates a **static, edge-safe BM25 search index** at build time.
Confirmed from the installed package:

- `node_modules/leadtype/README.md`:
  > "Builds a static, edge-safe search index (BM25, optional source-grounded
  > answers)."
- `node_modules/leadtype/dist/_shared/search-TL9muun_.js` contains the actual
  ranking implementation — classic Okapi BM25 with `BM25_K1 = 1.2` and
  `BM25_B = 0.75`, scoring against precomputed chunk term frequencies and
  document length normalization.
- The React adapter (`dist/search/react.d.ts`) describes its debounce as
  *"Delay in milliseconds between query updates and BM25 execution"* — i.e.
  ranking runs **client-side / edge-side** against the static index.

Concretely, `leadtype generate` emits `public/docs/search-index.json`
alongside `llms.txt`, `llms-full.txt`, and the per-page markdown mirrors.
That JSON is served as a static asset; the query runs against it without a
database, without a backend service, and without an embedding model call.

There is **no embedding code, no vector store, and no semantic search path**
anywhere in the package — `grep` for `embedding|vector|semantic` across
`node_modules/leadtype` returns zero hits in the search runtime. That is a
deliberate design choice, not an oversight.

What this gets us for free:

- Zero-infra search: a static JSON file on the CDN, no DB to provision,
  back up, scale, or rotate keys for.
- Deterministic results: lexical ranking is reproducible and debuggable;
  there is no "the model drifted" failure mode.
- Edge-safe: runs inside Workers/Edge functions or fully in the browser.
- Versioned with the docs: the index is rebuilt from the same MDX in the
  same `leadtype generate` step, so search can never go out of sync with
  content.
- Optional source-grounded answers: the `leadtype/search/vercel`,
  `leadtype/search/tanstack`, and `leadtype/search/cloudflare` adapters
  let an LLM answer over BM25-retrieved chunks — still no vector store
  required.

## 2. When adding embeddings is actually warranted

Adding a hosted, DB-backed vector index is justified **only** when you can
point to a concrete failure of lexical retrieval that you have measured,
not assumed. Specifically, all of the following should be true:

1. **You have evaluation data showing BM25 misses.** Real user queries (or
   a curated eval set) where the correct doc exists but BM25 does not
   surface it in the top-k. Without this you are buying a solution to a
   problem you have not demonstrated.
2. **The misses are semantic, not fixable upstream.** Users search with
   vocabulary that genuinely does not appear in the docs (synonyms,
   paraphrases, cross-language, conceptual queries). If the gap is
   missing keywords, fixing the docs (or adding aliases/frontmatter
   keywords) is cheaper and improves the docs themselves.
3. **The corpus is large enough that synonyms can't be curated.** For a
   few hundred pages, a hand-maintained synonym list or improved
   headings beats standing up a vector pipeline.
4. **You have an owner for the new failure modes.** Embedding model
   versioning, reindex cost, hosted DB availability, cost per query,
   and answer-quality regressions when the model is swapped — somebody
   needs to own all of that.

Even when those conditions are met, **keep BM25**, don't replace it:

- Run **hybrid retrieval**: BM25 + vector, then fuse (RRF or weighted).
  Lexical is still the strongest signal for exact identifiers, error
  codes, CLI flags, API names, and version strings — exactly the terms
  docs searches are dominated by. Pure-vector retrieval regresses on
  these.
- Keep leadtype's static index as the **offline / edge / fallback path**
  so search keeps working when the vector service is degraded.
- Keep the build-time generation step. The vector store should be a
  *consumer* of the same chunked content leadtype already produces, not
  a parallel content pipeline.

## Recommended next step

Before approving any vector-DB work, ask for:

- a 50–100 query eval set drawn from real logs,
- top-5 recall numbers for the current BM25 index on that set,
- the specific query classes where it fails.

If BM25 recall is already >90% on that set — which is common for
well-structured technical docs — the hosted vector index is solving a
problem we do not have, and the right move is to ship leadtype's default
search and revisit only if the eval numbers say otherwise.
