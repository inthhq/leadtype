# Docs search with `leadtype`: what we already have, and when embeddings actually pay off

## 1. What `leadtype` gives us by default

`leadtype generate` emits a **static, edge-safe search index** as part of the normal docs build — no service to run, no database, no embedding model. Key properties (verified against the installed `leadtype` package — README plus `dist/search/*` and `dist/_shared/search-TL9muun_.js`):

- **Algorithm: BM25** (lexical ranking). The constants `BM25_K1 = 1.2` and `BM25_B = 0.75` are hard-coded in `dist/_shared/search-TL9muun_.js`. Scoring uses term frequency weighted per field (title / heading / body / code) with length normalization against `averageChunkLength`. There is **no embedding model, no vector store, and no semantic similarity** anywhere in the package — `grep` for "embedding" / "vector" returns nothing in the package source.
- **Build output: a single JSON file.** `leadtype generate` writes `public/docs/search-index.json` (search index version 2, schema in `dist/_shared/transformers-CHP6LNcn.d.ts`: `documents`, `chunks`, inverted `terms` postings, optional `content` store). It is plain JSON — servable from any CDN / edge / static host. The README explicitly calls this a "static, edge-safe search index."
- **Chunking is built in.** `createDocsSearchIndex` chunks each page on heading boundaries with `maxChunkChars: 1200` and `overlapChars: 160` (see `docsSearchDefaults`). Each chunk keeps `headingPath`, `anchor`, `urlWithHash`, etc., so results deep-link straight to the right section.
- **Query runtime is edge-safe and framework-agnostic.** `leadtype/search` exposes `searchDocs(index, query, options)`, returning ranked `DocsSearchResult[]` with title/heading/body/code-weighted scores and excerpts. Adapters ship for Next.js (`leadtype/next`), TanStack (`leadtype/search/tanstack`), Vercel AI / AI Gateway (`leadtype/search/vercel`), Cloudflare (`leadtype/search/cloudflare`), plus client hooks (`useLeadtypeSearch`, `createSearchClient`).
- **Production hardening is included.** `validateDocsQuery` (length caps, `maxQueryChars: 400`), `readJsonWithLimit` (body-size cap), `createMemoryRateLimiter` + `getClientIdentifier`, and `DocsSearchRequestError` are all part of `leadtype/search`. We do not need to write our own input guards or rate limiter.
- **Source-grounded "Ask" / RAG-style answers — without embeddings.** `createAnswerContext(index, query, options)` returns a `DocsAnswerContext` with `sources` (top BM25 chunks with citations), a `system` prompt, and a `prompt` — i.e. ready-made RAG context built from BM25 retrieval. The Vercel and TanStack streaming adapters consume this directly. Defaults: `maxSources: 6`, `maxContextChars: 12000`, `askMaxQueryChars: 600`.
- **Agent-readable artifacts ship with the same build.** `llms.txt`, `llms-full.txt`, and `docs/*.md` mirrors come out of the same `leadtype generate` invocation, so HTTP agents and coding agents have first-class entry points alongside human search.

In short: out of the box we already have **chunked retrieval, ranked search, citations, an answer-context builder, edge deployment, rate limiting, and query validation** — the entire surface a hosted vector DB is usually proposed to provide for a docs site.

## 2. When adding embeddings is actually warranted

BM25 is lexical: it ranks by tokens the query and the doc share. That is a great fit for docs because users tend to search for the exact API/option/error string they are looking at. Embeddings are worth the extra moving parts **only** when *all* of the following are true:

1. **You have measured BM25 recall and it is genuinely failing.** Log queries, label a sample, and compute recall@k from `searchDocs` results. If users are finding what they need (or one round of synonym tuning fixes it — `searchDocs` already accepts a `synonyms` map), stop here.
2. **The failures are dominated by vocabulary mismatch**, not by missing/poor content. Concretely: users describe symptoms or use third-party terminology that genuinely does not appear in our docs (e.g. "my build is slow on a Mac M-series" vs. docs that only say "darwin-arm64 cache cold start"). Synonyms can't paper over open-ended natural-language paraphrase at scale.
3. **The corpus is large and heterogeneous enough that lexical recall actually degrades** — hundreds-to-thousands of pages spanning conceptual guides, blog posts, and Q&A. A typical product docs site (tens to low hundreds of pages) does not hit this regime; BM25 with leadtype's heading-aware chunking is usually at the ceiling.
4. **Agent / "Ask" answer quality is bottlenecked by retrieval, not generation.** Inspect failures from `createAnswerContext`: are the wrong chunks being cited, or is the model summarizing the right chunks badly? Only the first is a retrieval problem.
5. **You can afford the operational cost honestly:** an embedding model, an index to (re)build on every docs change, a vector store to host, a freshness/version-skew story between code-shipped docs and the index, plus a private query path so user questions don't leak to a third-party embedding API.

### What to keep even if we do add embeddings

Embeddings should be a **second retriever layered on top of leadtype**, not a replacement. Keep:

- **leadtype's build pipeline as the source of truth** — chunks, `headingPath`, `urlWithHash`, frontmatter, citations. The vector store should index *these same chunk IDs* so results stay deep-linkable and versioned with the docs.
- **BM25 as one arm of a hybrid retriever.** Run `searchDocs` and the vector search in parallel and fuse (e.g. reciprocal rank fusion). BM25 wins decisively on exact identifiers, error strings, flag names, and code — the bulk of real docs queries. Dropping it regresses those.
- **`createAnswerContext`'s contract** — `sources`, `citation`, `context`, `system`, `prompt`. Swap only the candidate-selection step inside it; keep the citation-grounded prompt shape so the Vercel / TanStack / Cloudflare adapters keep working.
- **`validateDocsQuery`, `readJsonWithLimit`, `createMemoryRateLimiter`, `getClientIdentifier`, `DocsSearchRequestError`.** These are independent of the retrieval algorithm and we'd otherwise have to reimplement them on the new service.
- **Edge / static delivery for everything that doesn't strictly require the vector DB.** Search-as-you-type stays on the static `search-index.json`; the embedding path is reserved for the "Ask" flow where its cost is justified.

### Recommendation

Ship leadtype's default index now, instrument it (log queries + click-throughs from `DocsSearchResult.id`), and revisit embeddings only if measured recall@k on real query logs is unacceptable *and* synonyms + content fixes can't close the gap. The hosted vector DB is a cost we should pay against evidence, not against a vibe that "RAG needs embeddings" — leadtype already does grounded retrieval-augmented answers without them.
