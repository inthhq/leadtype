# What leadtype Provides for Docs Search by Default

## 1. Default Search Implementation

**leadtype uses static BM25 full-text search** by default — not embeddings, vector indices, or semantic search.

### How it works:

- **Indexing:** Documents are split into overlapping chunks (~1200 chars with 160-char overlap, configurable).
- **Tokenization:** Text is normalized (NFKD diacritics, lowercase) and split into tokens; stopwords and single-character tokens are filtered out.
- **Term frequency:** Each chunk is indexed with weighted term frequencies across four content regions:
  - **Title** (4× weight)
  - **Headings** (2× weight)
  - **Body text** (1× weight)
  - **Code blocks** (0.35× weight)
- **Ranking:** Scores are computed using **BM25 algorithm** with:
  - Inverse document frequency (IDF) weighting
  - Field-length normalization (k₁=1.2, b=0.75)
  - Exact term match (1.0×), stemming (0.82×), synonym expansion (0.72×), prefix matching (0.55×), typo tolerance (0.45×)
  - Phrase match boost (1.4×) and proximity match boost (0.8×)
  - Built-in English stemming and a curated set of tech synonyms (e.g., `ai ↔ agent`, `llm`, `config ↔ settings`, `ts ↔ typescript`)
- **Output:** A static JSON search index (~semantic versioning, fully serializable) shipped with docs or embedded in markdown bundles.

### Generated artifacts:

```
search-index.json       # The BM25 index
search-content.json     # Optional: embedded full chunk text for fast client-side retrieval
```

Both files are **edge-safe** (no runtime database queries) and can be:
- Served from a static CDN
- Bundled into npm packages
- Queried from the browser via JavaScript
- Used by CLI tools and agents offline

## 2. Specific Conditions When Embeddings/Vector Search Are Warranted

**Add embeddings only if:**

1. **Semantic relevance significantly improves recall** — i.e., documents contain similar concepts expressed with different vocabularies (e.g., "authentication" vs. "login" vs. "session management"), and BM25's synonym table is too manual/incomplete to cover them.

2. **Your docs are dense or highly interconnected** — queries address implicit relationships that keyword matching cannot capture (e.g., abstract architectural patterns, oblique cross-references).

3. **User intent diverges from exact terminology** — queries are vague, conversational, or rely on external domain knowledge not present in docs (rare for **reference documentation**, more common for **tutorial/conceptual search**).

4. **Query volume justifies the infrastructure cost** — database-backed vectors require hosting, scaling, maintenance, and latency management. Static BM25 has zero operational overhead.

### What to keep regardless:

- **The BM25 static index** — it remains essential for:
  - **Exact/prefix/typo-tolerant matching** — users often search by function name, class, flag, or config key.
  - **Offline access** — agents, CLIs, and bundled packages need search to work without network.
  - **Deterministic ranking** — BM25 is transparent and reproducible; embedding similarity is opaque and model-dependent.
  - **Edge compute** — static search runs on CDN workers, browsers, and air-gapped environments.
  
- **The chunk structure** — both BM25 and embeddings benefit from semantic chunking (headings, sections, code blocks). Reuse the existing chunk boundaries.

- **Field-weighted scoring** — title/heading/body/code weighting is valuable signal for both ranking strategies. Use it as a post-processing filter or re-ranker if you add embeddings.

---

**In short:** leadtype gives you a production-grade, zero-maintenance full-text search out of the box. Only add vectors if you've measured that BM25 misses semantically relevant results *and* you can operationalize the database cost. Until then, invest in synonym tables and better chunking.
