# What leadtype already gives us for docs search

## 1. What the default search uses

leadtype's search is **fully static and purely lexical — no database, no embeddings, no external service.**

### How it works (verified from the source)

**Build time** — `generateDocsSearchFiles` (`leadtype/search/node`) reads every `.md` file under your output `docs/` directory, runs them through `createDocsSearchIndex`, and writes two plain JSON files:

| File | Default name | Contents |
|---|---|---|
| Search index | `search-index.json` | Inverted-term index, chunk metadata, BM25 posting lists |
| Content store | `search-content.json` | Raw text of every chunk (lazy-loaded separately) |

The `embedContent` flag on `GenerateDocsSearchFilesConfig` can inline the content store into the index file; by default it is split so the heavier text payload is fetched only when needed.

**Run time** — `searchDocs` (`leadtype/search`) runs entirely in-process:

1. **Tokenise** — unicode word-character extraction, stopword removal, unicode normalisation (NFKD + diacritic strip, lowercased).
2. **Multi-strategy term expansion** — for each query token the engine looks up:
   - **Exact match** (weight 1.0)
   - **Stem match** — light suffix-stripping (`-ing`, `-ed`, `-ies`, `-es`, `-s`) matched against every index term that shares a stem (weight 0.82)
   - **Synonym expansion** — a built-in table (`install↔setup`, `search↔find`, `config↔configure`, `ts↔typescript`, `ai↔llm`, etc.) plus caller-supplied synonyms (weight 0.72)
   - **Prefix match** — any index term that starts with the query token (≥ 4 chars, capped at 24 expansions, weight 0.55)
   - **Typo tolerance** — Levenshtein distance ≤ 1 (tokens 4–6 chars) or ≤ 2 (tokens ≥ 7 chars), first-character anchored, capped at 16 expansions (weight 0.45)
3. **BM25 scoring** — `k1 = 1.2`, `b = 0.75`, with per-field weights: title × 4, section heading × 2, body × 1, code × 0.35.
4. **Phrase / proximity boost** — exact phrase in chunk text gets a +1.4× multiplier; ordered proximity within an 8-token window gets +0.8×.
5. **Chunking** — documents are split into overlapping segments (default 1 200 chars max, 160-char overlap) so section-level results and heading-path anchors are returned.

The entire index lives in JSON files served from your CDN/edge — no round-trips to a database, no vector store, no embedding model.

The `createSearchClient` helper (`leadtype/search/client`) fetches those two files once (lazy on first query, or via `preload()`), then runs all queries locally against the in-memory index.

**Optional AI-answer layer** — `streamDocsAnswer` (`leadtype/search/vercel`, `/tanstack`, `/cloudflare`) *does* call an LLM, but it is a **RAG answer stream on top of the BM25 results**, not a replacement for them. `createAnswerContext` runs a normal `searchDocs` call first, bundles the top-6 chunks into a grounded system prompt, and streams the answer. The retrieval step is still BM25 — the LLM only synthesises prose.

---

## 2. When adding embeddings is actually warranted — and what to keep regardless

### The bar is specific

Embeddings add meaningful value only when **all three of the following are true simultaneously**:

1. **Vocabulary mismatch is measured and material.** Users are phrasing queries in language that shares no morphological or synonym overlap with your doc terms — e.g. they write "rate cap" and your docs say "throttling limit", or they write in a different language entirely. leadtype's synonym table, stem matching, and typo tolerance already close most single-domain gaps. Add embeddings only after you have query logs proving a significant fraction of zero-result or low-precision queries that are *not* covered by the built-in expansion strategies.

2. **The corpus is large enough for approximate nearest-neighbour retrieval to matter.** For a typical product docs site (tens to a few hundred pages, well under 10 000 chunks — leadtype warns above that threshold) an exact-scan BM25 pass over an in-memory index is cheaper and faster than a network round-trip to a vector DB. Embeddings earn their complexity when the chunk count is in the tens of thousands and keyword recall genuinely degrades.

3. **You can afford and operate the infrastructure.** A hosted vector database adds a persistent service, embedding model API calls at index-build time (and re-index on every doc change), query-time latency for the embedding round-trip, cost per token, and a new failure mode (the vector DB being unavailable). That cost is only justified when points 1 and 2 are satisfied.

### What you must keep even if you add embeddings

**Keep the BM25 index regardless.** The right architecture if you ever reach the embedding threshold is **hybrid retrieval** (BM25 + dense vector, scores fused with RRF or a similar combiner), not a replacement. BM25 wins on:

- Exact term and identifier matching (API names, CLI flags, error codes, package names) — things where semantic similarity is actively unhelpful or misleading.
- Predictable, zero-latency, zero-cost query execution at the edge with no external dependency.
- The synonym, prefix, and typo-tolerance layers that leadtype already ships.

leadtype's static index is the right default, and the right retrieval backbone, for the vast majority of product docs sites. Build a measured case — with real query logs showing recall failures the built-in strategies cannot fix — before adding a vector database.
