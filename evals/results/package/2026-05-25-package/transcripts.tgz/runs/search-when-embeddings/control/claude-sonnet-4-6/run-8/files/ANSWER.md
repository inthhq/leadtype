# What leadtype Already Gives You for Docs Search

## 1. What leadtype's docs search uses by default

leadtype ships a **fully self-contained, static BM25 search engine** — no database, no hosted index, no embedding model, no API calls at query time.

### How it is built (`leadtype/search/node`)

At build time, `generateDocsSearchFiles` reads every markdown file under the output `docs/` directory, parses frontmatter, and calls `createDocsSearchIndex`. That function:

1. **Chunks** each document into overlapping text segments (default: 1 200-character chunks with 160-character overlap, split at sentence or word boundaries).
2. **Tokenises** each chunk — Unicode-aware word extraction, lower-casing, diacritic normalisation, and a stopword list.
3. **Inverted-index builds** a `terms` map: every token → array of `[chunkIndex, titleFreq, headingFreq, bodyFreq, codeFreq]` postings.
4. **Writes two static JSON files** to the same directory:
   - `search-index.json` — the inverted index (documents, chunks, term postings, average chunk length).
   - `search-content.json` — the raw chunk text store used for excerpts and LLM context.

The content file can alternatively be embedded directly inside the index (the `embedContent` flag), but by default they are separate so the heavier content payload is only loaded when needed.

### How it runs at query time (`leadtype/search`)

`searchDocs(index, query, options)` executes entirely in memory, in the same process or browser tab that loaded the two JSON files — no network call beyond the initial JSON fetch:

| Scoring layer | Detail |
|---|---|
| **Exact match** | Weight 1.0 — token found verbatim in the index |
| **Stem match** | Weight 0.82 — suffix-stripped token (e.g. `"running"` → `"run"`) matches an index term |
| **Synonym expansion** | Weight 0.72 — built-in synonym table (`config`→`settings`, `install`→`setup`, `ts`→`typescript`, `ai`→`agent/llm`, etc.) plus caller-supplied synonyms |
| **Prefix match** | Weight 0.55 — index term starts with the query token (up to 24 expansions) |
| **Typo tolerance** | Weight 0.45 — Levenshtein distance ≤ 1 (tokens < 7 chars) or ≤ 2 (tokens ≥ 7 chars), anchored on first character (up to 16 expansions) |

Each candidate chunk is scored with **BM25** (k₁ = 1.2, b = 0.75) weighted across four fields: title (×4), heading (×2), body (×1), code (×0.35). A **phrase-match boost** (+1.4) is applied when the entire normalised query appears verbatim in the chunk, and a **proximity boost** (+0.8) when all query tokens appear in order within an 8-token window.

The result is a ranked list of up to 8 `DocsSearchResult` objects (configurable), each carrying `title`, `excerpt`, `absoluteUrlWithHash`, `headingPath`, and `score`. The `buildExcerpt` helper centres the snippet on the first matching token, showing ±80/160 characters around it.

### LLM answer generation (`leadtype/search/vercel`, etc.)

`createAnswerContext` re-uses the same BM25 search to pick up to 6 top chunks (12 000 chars of context total), assembles a grounded `system` + `prompt` pair, and returns `sources` with citation numbers. `streamDocsAnswer` then pipes that straight to an AI SDK `streamText` call. The retrieval step is still BM25 over the static files — the LLM is only involved in *generating the prose answer*, not in finding the documents.

### Edge / browser safety

Because it is plain JSON + pure JavaScript maths, the entire search runtime runs on Cloudflare Workers, Vercel Edge, a browser, or a Node.js server without any native binaries, database drivers, or secret API keys.

---

## 2. When adding embeddings is actually warranted — and what to keep

### Warranted only when BM25's structural blindspot is a real, measured problem

BM25 fails in one specific scenario: **the user's vocabulary does not overlap with the doc's vocabulary, and none of the synonym/stem/prefix expansions bridge the gap.** Concretely:

- A user asks *"how do I make the search box appear instantly?"* but the docs say *"configure the `debounceMs` option to reduce latency"* — no shared token, no synonym mapping, no typo path.
- Your docs use heavily domain-specific jargon and your users are newcomers who reach for everyday synonyms you haven't manually added.
- The corpus is large enough (thousands of pages, many concepts per page) that relevant chunks are routinely ranked below three BM25 pages of noise before the user's real target appears.

Before reaching for embeddings, first audit whether the gap is actually in tokenisation (in which case adding entries to the synonym table — which the library supports natively via `options.synonyms` — closes it for free).

**Embeddings are warranted when:**

1. You have concrete evidence (search analytics, user feedback) that a material share of zero-result or low-recall queries cannot be fixed by extending the synonym table or improving doc phrasing.
2. The corpus is large enough that a hosted vector store doesn't dominate your infrastructure cost and latency budget relative to a cold JSON fetch.
3. You can afford the embedding generation step at build time and the embedding inference step (or cached ANN lookup) at query time.

### What to keep even then

Even if you add a vector retrieval layer, **keep the BM25 index and the static JSON files**:

- **Exact / keyword queries still win on BM25.** Searches like `"useLeadtypeSearch"`, `"--base-url flag"`, or a specific error code produce perfect results via exact-match scoring that no general embedding model will beat for precision.
- **The BM25 layer is free at query time.** It runs client-side with no API cost, no latency from a remote vector DB, and no rate-limit risk. It is also the offline/fallback path when the embedding endpoint is unavailable.
- **The content store (`search-content.json`) is already the retrieval payload.** Whether you retrieve via BM25 or vectors, `createAnswerContext` is what assembles the grounded prompt for the LLM answer — you don't need to rebuild that logic.
- **Hybrid retrieval is the production pattern anyway.** The standard approach is RRF (Reciprocal Rank Fusion) or a simple score blend: run both BM25 and ANN, merge the ranked lists, deduplicate. The leadtype index is already the BM25 half of that pipeline.

**Summary:** leadtype gives you a production-grade, zero-infrastructure, edge-safe keyword search engine with synonym expansion, typo tolerance, and LLM-answer integration out of the box. Add a vector index only when you have measured evidence of a vocabulary-gap problem that the built-in synonym table cannot solve — and when you do, keep the BM25 index as the precision anchor and offline fallback.
