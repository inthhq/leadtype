# What `leadtype` Provides for Docs Search

## 1. Default Search Implementation: BM25 with Semantic Enhancements

By default, `leadtype` generates a **static, edge-safe search index** that uses **BM25 (Best Matching 25)** — a battle-tested ranking algorithm — enhanced with several intelligent features that make it surprisingly powerful without embeddings:

### Core Algorithm: BM25
- **Probabilistic relevance framework** that weighs term frequency and inverse document frequency.
- **Configurable parameters** (k1=1.2, b=0.75) tuned for typical documentation queries.
- **No external index required** — the entire search runs client-side or in a lightweight edge worker.

### Semantic Enhancements (No Embeddings)
1. **Stemming & Morphological Analysis**
   - Reduces words to their root form (e.g., "installing" → "install")
   - Catches inflected queries like "creates," "creation," "creative" → "creat"

2. **Synonym Expansion**
   - Default synonym pairs (e.g., `ai ↔ llm ↔ agent`, `install ↔ setup ↔ configure`)
   - Custom synonyms can be added via configuration

3. **Fuzzy Matching**
   - **Typo tolerance** with edit distance (Levenshtein distance ≤2 for longer words)
   - **Prefix matching** for partial word queries
   - Limits expansions (max 24 prefix, max 16 typo matches) to keep search fast

4. **Phrase & Proximity Matching**
   - **Phrase boost** (1.4×) when consecutive tokens appear together in order
   - **Proximity boost** (0.8×) when tokens appear in a narrow window (8 tokens)

5. **Content-Aware Weighting**
   - **Title** matches weighted 4× higher than body text
   - **Heading** matches weighted 2× higher
   - **Code blocks** weighted 0.35× (to avoid false positives on variable/function names)

### Search Output
- **Static JSON artifacts** (`search-index.json` + optional `search-content.json`)
- **Framework-agnostic client** that works in React, Vue, Svelte, or vanilla JS
- **Response includes**: exact URL with hash, excerpt, heading breadcrumb, relevance score
- **Can generate answer context** for LLM retrieval with up to 6 sources and 12K chars

### Static Index Benefits
- ✅ **No database** — works from a CDN or static file server
- ✅ **Fast** — O(1) posting list lookup per query term
- ✅ **Edge-friendly** — runs in Vercel, Cloudflare Workers, Astro, TanStack Start, etc.
- ✅ **Cheap** — no infrastructure costs, no API calls per search
- ✅ **Cacheable** — index is versioned, can be aggressively cached

---

## 2. When Embeddings (Vector Search) Are Actually Warranted

Adding a vector index and embeddings model makes sense **only under specific conditions**:

### Warranted Conditions
1. **Semantic mismatches are common**
   - Query: "how do I configure authentication" vs. docs mention only "identity," "oauth," "sessions"
   - BM25 fails because terms don't overlap; embeddings capture meaning

2. **Dense, narrative-style docs** with minimal metadata
   - Long-form prose where the key concepts don't match typical keywords
   - Medical, legal, or domain-specific docs with jargon
   - Example: docs about "metabolic pathways" where query uses "energy processing"

3. **Multilingual docs** where users search in a different language than the docs are written
   - Embeddings can bridge the language gap; BM25 cannot

4. **Complex, nested queries** with implicit intent
   - Query: "how to make my app fast" vs. docs on "optimization," "caching," "CDN," "async"
   - Semantic understanding helps, not just lexical matching

### NOT Warranted
- API documentation with standard keywords (most common)
- Tutorials/guides where titles and headings match user intent (usually ✓)
- Docs with consistent terminology (internal standards, glossaries)
- Query volumes low enough to run dynamic searches (no scale pressure)

---

## 3. What to Keep Even With Embeddings

**Do not remove the BM25 index even if you add vector search.** Use a **hybrid approach**:

### Keep BM25 Because
1. **Exact matches dominate relevance**
   - "react hooks" query must rank the "React Hooks" doc section first
   - Vector distance doesn't guarantee exact lexical matches; BM25 does

2. **Low latency for known queries**
   - Typo tolerance, stemming, and prefix expansion answer 80% of queries instantly
   - No embedding model inference needed

3. **Cost efficiency**
   - BM25 is free to run (already static, already compiled)
   - Embeddings cost money (API calls, inference, storage, GPU)

4. **Handles edge cases**
   - Code snippet searches (exact syntax keywords)
   - Version-specific API changes (exact term matching)
   - Acronyms and abbreviations (configured synonyms)

5. **No dependency on external models**
   - BM25 works offline, in any edge environment
   - Embedding models may be blocked, deprecated, or rate-limited

### Hybrid Strategy
- **Primary**: BM25 (always run first, always free)
- **Secondary**: Vector search (only for low-scoring BM25 results or ambiguous queries)
- **Combine**: Rerank by hybrid score (e.g., 0.7 × BM25 + 0.3 × vector similarity)
- **Cache both**: Static BM25 index + precomputed embeddings for docs

---

## Summary

`leadtype` ships with a **production-ready, free, edge-safe BM25 search** that handles the vast majority of doc queries through smart stemming, synonyms, fuzzy matching, and phrase/proximity boosts. **Do not add embeddings until you hit a specific wall** (semantic mismatch, multilingual, narrative-heavy docs) — and even then, keep BM25 as the fast primary filter.
