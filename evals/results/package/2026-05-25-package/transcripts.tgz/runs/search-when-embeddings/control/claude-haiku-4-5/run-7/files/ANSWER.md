# What `leadtype` Gives You for Docs Search

## 1. Default Search Method: BM25 Static Index

By default, **`leadtype` generates a static, edge-safe BM25 search index** stored as JSON.

### What you get out of the box:

- **BM25 keyword search** — a probabilistic ranking algorithm that weighs term frequency, inverse document frequency (IDF), document length, and term position
- **Chunked indexing** — docs are split into ~1200-character chunks (configurable) with overlap, each chunk indexed separately
- **Multi-field ranking** — different weights for matches in title (4x), headings (2x), body text (1x), and code (0.35x)
- **Smart term expansion** — automatically searches for:
  - Exact token matches
  - Stemmed variants (e.g., `installing` → `install`)
  - Synonyms (built-in: `ai` ↔ `agent` ↔ `llm`, `config` ↔ `configure` ↔ `settings`, etc.)
  - Prefix matches (e.g., `search` finds `searching`)
  - Typo tolerance via edit distance (1–2 character variations)
- **Phrase and proximity matching** — bonuses for consecutive tokens and nearby matches
- **Two-file output** by default:
  - `search-index.json` — compact inverted index + metadata (terms, documents, chunks)
  - `search-content.json` — actual chunk text (loaded on demand)

### Key constraints:

- The index is **purely static** — no backend or embeddings required; runs entirely in-browser or on edge
- Search is **lexical/keyword-based** — it does not understand semantic similarity, only term overlap
- Client-side overhead is low; the library includes framework adapters for React, Vue, Svelte, TanStack AI, Vercel AI, Cloudflare Workers

---

## 2. When Embeddings Are Actually Warranted

Adding a hosted vector database (embeddings-based search) is warranted **only when**:

### ✓ Add embeddings if:

1. **User queries are consistently semantically distant from keywords**
   - Example: users search "how do I fix it when things break?" but docs say "error handling" and "troubleshooting"
   - BM25 would return nothing; semantic search would find relevant pages

2. **Docs emphasize concepts over terminology**
   - Example: API reference heavy on examples but light on keyword density
   - Semantic search shines when multiple ways to phrase the same idea

3. **You have empirical evidence of search misses**
   - Run BM25 against real user queries; if miss rate is >15–20%, embeddings help
   - Without data, you're speculating

4. **You need answer generation at scale**
   - `leadtype` includes `createAnswerContext()` — it extracts top chunks and builds LLM context automatically
   - Works with BM25 *and* with any vector backend you wire in (see `leadtype/search/vercel`, `leadtype/search/cloudflare` for AI SDK patterns)

### ✗ **Do NOT add embeddings if:**

- You haven't optimized BM25 yet (synonyms, query expansion, chunk boundaries)
- Your docs are well-structured with clear terminology — BM25 will win
- You want to avoid operational complexity (embeddings = models, inference, rate limits, latency)
- Search latency is not a blocker (BM25 is instant; embeddings add ~100–500ms)

---

## 3. What to Keep Even With Embeddings

**Never replace the static BM25 index.** Instead, use a **two-tier hybrid search** approach:

1. **Keep the BM25 static index as the default fallback**
   - Zero operational cost
   - Instant client-side results
   - Handles ~80% of queries perfectly

2. **Layer embeddings on top for ambiguous or semantic queries**
   - Use LLM routing to detect when BM25 alone might miss
   - Fall back to BM25 if embedding inference fails
   - Only compute embeddings for a subset of chapters/sections (not full docs)

3. **Keep `createAnswerContext()` from `leadtype/search` as your LLM bridge**
   - It builds system prompts + source citations automatically
   - Works with any search backend (BM25 or embeddings)
   - Prevents hallucinations by grounding answers in source chunks

4. **Preserve the two-file output split** (if not using `embedContent`):
   - `search-index.json` — load at app startup
   - `search-content.json` — load on demand when a result is clicked
   - Keeps initial bundle size small

---

## Summary

**Default:** Static BM25 keyword search in JSON. Fast, cheap, indexable, works for most docs.

**When to add embeddings:** Only if BM25 search misses are empirically high AND semantic distance is the issue.

**How to add embeddings:** Keep the BM25 layer; treat embeddings as a premium fallback for edge cases. Use `leadtype`'s `createAnswerContext()` and framework adapters to wire in any inference backend (Vercel AI SDK, Cloudflare Workers AI, etc.).

**Operational debt avoided:** No database schema migrations, no embedding recomputes on every doc change, no rate limits or inference timeouts in your critical path.
