# What leadtype already gives you for docs search

## 1. What leadtype's docs search uses by default

leadtype's docs search is **fully static and purely lexical — no database, no embeddings, no external service required.**

### The artifact pipeline

At build time, `generateDocsSearchFiles` (from `leadtype/search/node`) reads every converted Markdown file, chunks the content, and writes two JSON files into your output directory:

| File | Default name | Contains |
|---|---|---|
| Index | `search-index.json` | Inverted term→chunk posting list, document metadata, chunk metadata, BM25 statistics |
| Content store | `search-content.json` | Raw text of every chunk, referenced by index at query time |

Both files are plain static assets. They can be served from a CDN, bundled into a package tarball, or loaded from `node_modules` — no server process, no database, no network round-trip to a vector store.

### The ranking algorithm

The runtime (`searchDocs` in `leadtype/search`) is a hand-rolled **BM25 ranker** (k₁ = 1.2, b = 0.75) with several layers on top:

- **Weighted fields** — title hits are worth 4×, heading hits 2×, body 1×, code snippets 0.35×.
- **Stemming** — Porter-style suffix reduction (`-ing`, `-ed`, `-ies`, `-es`, `-s`) so "configuring" matches "configure".
- **Built-in synonym expansion** — 17 pre-wired synonym groups (e.g. `install ↔ setup ↔ configure`, `auth ↔ authentication ↔ login`, `ts ↔ typescript`, `ai ↔ agent ↔ llm`) plus user-supplied synonyms at query time; synonyms are weighted at 0.72× exact.
- **Prefix matching** — any index term that starts with the query token matches at 0.55× (up to 24 expansions per token).
- **Typo tolerance** — Levenshtein edit-distance ≤ 1 (tokens < 7 chars) or ≤ 2 (≥ 7 chars) for terms beginning with the same letter; weighted 0.45× (up to 16 expansions per token).
- **Phrase/proximity boost** — exact phrase in chunk text gets a 1.4× multiplier; ordered proximity within an 8-token window gets 0.8×.
- **Stopword filtering** — a compact set of common English words (`a`, `the`, `is`, `in`, `of`, `to`, `use`, `what`, `when`, `where`, …) are dropped from both the index and queries.
- **Unicode normalisation** — NFKD decomposition + diacritic stripping so accented characters are handled correctly.

### Chunking

Documents are split into overlapping text chunks (default: 1 200 chars max, 160-char overlap, sentence-boundary aware). Each chunk is indexed separately, so results link to the specific heading anchor where the match occurred, not just the page.

### Query-time client

`createSearchClient` / `useLeadtypeSearch` (React) / `useLeadtypeSearch` (Next.js) fetch the two JSON artifacts once, cache them in memory, and run all BM25 scoring entirely in the browser or edge worker — **zero server round-trips at query time**.

### RAG / answer mode (optional, still no vector DB)

`createAnswerContext` uses BM25 to retrieve the top-ranked chunks and builds a grounded system prompt + cited context block. The framework adapters (`leadtype/search/vercel`, `/tanstack`, `/cloudflare`) stream the LLM answer back to the client. The retrieval step is still BM25 — the LLM is only involved in synthesising a prose answer, not in ranking.

---

## 2. When embeddings are actually warranted — and what to keep even then

### When the lexical index genuinely falls short

Add vector embeddings only when **all three** of the following are true for your docs set:

1. **Semantic-gap queries are common and measurable.** Users regularly ask questions whose vocabulary does not appear in the relevant page — for example, "how do I log in?" where the docs say "authenticate" and neither the built-in `auth ↔ authentication ↔ login` synonym nor prefix/typo matching bridges the gap. You should be able to point to real query logs that BM25 consistently fails on *after* tuning synonyms first.

2. **The corpus is large and heterogeneous enough that synonym tuning doesn't scale.** `searchDocs` accepts a `synonyms` option (a plain `Record<string, string[]>`). For most docs sites, adding a handful of project-specific synonym pairs (`{ widget: ["component", "element"] }`) closes the remaining vocabulary gaps without any infrastructure. If you find yourself needing hundreds of synonyms across dozens of domains, that signals the vocabulary space is too large for manual curation — that is the moment embeddings start paying for themselves.

3. **You have the latency and cost budget for it.** Embeddings require an embedding model call at index time, a vector database (or approximate-nearest-neighbour index) at query time, and ongoing hosting costs. For a standard docs site this is pure overhead.

### What to keep even if you do add embeddings

**Keep the BM25 index and run it in parallel (hybrid retrieval).** The reasons are concrete:

- **Exact-term precision.** Vector models can hallucinate similarity between unrelated tokens. A user searching for a specific CLI flag (`--base-url`) or error code (`ERR_DOCS_NOT_FOUND`) should get an exact hit, not a semantically nearest neighbour. BM25 guarantees this; embeddings do not.
- **Code and API surface coverage.** leadtype weights code text at 0.35× specifically because code snippets are in the index. Vector embeddings often perform poorly on short code tokens and symbolic strings.
- **Zero-latency fallback.** The BM25 index is already loaded in the browser/edge worker from the JSON artifacts. If the vector database is unavailable or slow, BM25 continues working with no user-visible degradation.
- **No cold-start cost.** The static JSON artifacts require no warm-up, no connection pool, and no per-query network call. Adding embeddings on top of BM25 (reciprocal-rank fusion is the standard approach) keeps this fast path intact while adding recall for semantic queries.

### Summary table

| Condition | Recommendation |
|---|---|
| Docs site with < ~500 pages | leadtype BM25 out of the box; tune `synonyms` if needed |
| Vocabulary gap confirmed in query logs, synonym tuning doesn't scale | Add embeddings + vector retrieval *alongside* BM25 (hybrid RRF) |
| Adding embeddings | Keep `search-index.json` + BM25 as the fast, exact, always-on layer |
| "RAG requires a vector DB" as the sole justification | Do not add a vector DB — leadtype's `createAnswerContext` already does retrieval-augmented generation using BM25, and it ships today |
