# leadtype navigation notes

1. A curated `nav` in `docs.config.ts` is the preferred source of truth for navigation. When `nav` is present, leadtype resolves the sidebar/docs navigation tree and agent-facing maps/indexes from the explicit `nav` nodes and their `pages` entries or include globs. A page's legacy `group` frontmatter does **not** decide where that page appears in the sidebar in this mode.

   The `group` field is still useful as fallback taxonomy/navigation metadata: if there is no curated `nav`, leadtype uses configured `groups` plus each page's `group` frontmatter to build navigation sections. Even with `nav`, the `group` values remain page metadata and can be validated against the configured `groups` tree when `groups` is still supplied.

2. During `leadtype generate`, leadtype resolves navigation before writing artifacts and checks for unknown legacy group slugs. If a page declares a `group` slug that is not present in the configured `groups`, generation fails with an error like:

   ```text
   /docs/some-page declares unknown group "missing-slug"
   ```

   The CLI reports that as `leadtype generate: ...` and exits non-zero, so the build does not continue to produce the generated outputs. Note that the unknown-group check is against the `groups` configuration; `nav` slugs are not the same thing as legacy frontmatter group slugs. In a nav-only config with no `groups` tree, there is no group-slug taxonomy to validate against.