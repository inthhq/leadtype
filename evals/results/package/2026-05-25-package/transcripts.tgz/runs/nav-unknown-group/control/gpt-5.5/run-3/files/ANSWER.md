# Leadtype navigation and legacy `group`

1. **`nav` is the source of truth when it is configured.** The curated `nav` tree in `docs.config.ts` drives the generated navigation/sidebar manifest and the agent-facing maps such as `docs/llms.txt`, `AGENTS.md`, and the agent-readability navigation. Page frontmatter `group` does not place a page into the sidebar/agent map when `nav` is present; pages are included by the `nav` node `pages` entries or `include` globs.

   The legacy `group` field is still useful as taxonomy/page metadata, for consumers that want to filter or label pages, and as the fallback navigation mechanism when no curated `nav` is supplied. Keeping `groups` in config also lets Leadtype validate old `group:` values during migration. Note that `nav` slugs are navigation section slugs; they are not the same thing as frontmatter `group` slugs.

2. **An unknown configured group is a build error in `leadtype generate`.** During generation Leadtype resolves navigation before writing artifacts, collects pages whose `group:` value is not present in the configured `groups` taxonomy, and fails on the first one with an error like:

   ```text
   /docs/some-page declares unknown group "some-slug"
   ```

   The command exits non-zero, so the build does not complete. In library-level navigation APIs this condition is represented on the returned navigation as `unknown`; the CLI generation path promotes it to a fatal error. If you use only `nav` and have no `groups` taxonomy at all, there is no legacy group list to validate against, so `group:` values are just page metadata and do not affect `nav` placement.