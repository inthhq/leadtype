# leadtype navigation notes

## `nav` vs. legacy `group` frontmatter

When `docs.config.ts` defines a curated `nav`, that `nav` is the source of truth for navigation. It drives the docs sidebar/navigation manifest and the agent-facing maps such as `docs/llms.txt`, `AGENTS.md`, and the agent readability navigation. Pages are placed by the explicit `nav` page entries / include globs, not by their frontmatter `group` value.

The frontmatter `group` field is the older taxonomy mechanism. It is still useful as fallback navigation when no curated `nav` is configured, and as metadata/taxonomy that leadtype can preserve and validate against configured `groups`. In other words: use `nav` for the curated order and structure; keep `group` only if you still want group metadata or a fallback grouping scheme.

## Unknown `group` slugs at build time

During `leadtype generate`, leadtype resolves the navigation and checks for pages whose `group` slug is not present in the configured `groups` taxonomy. If it finds one, the build fails before generating the final artifacts with an error like:

```text
/docs/some-page declares unknown group "missing-slug"
```

With curated `nav`, this validation applies when `groups` are also configured as the known taxonomy. If a config uses only `nav` and has no `groups` list, the `group` field is not what places pages in the sidebar, so there is no configured group taxonomy to validate against.