# Navigation Architecture in Leadtype

## 1. The Relationship Between `nav` and `group` Frontmatter

### Which One Drives the Sidebar and Agent Map?

**The curated `nav` drives both the sidebar and agent map when present.** The `nav` configuration in `docs.config.ts` is the "preferred" navigation tree, as documented in the `DocsConfig` type definition:

```typescript
/**
 * Curated navigation for the single-collection shape. When present, this
 * drives docs UI and agent-facing indexes; `groups` remains fallback
 * taxonomy/navigation metadata.
 */
nav?: DocsNavNode[];
```

This is also reflected in several generation functions that explicitly take `nav` as a parameter and handle it as the primary source:
- `LlmsTxtConfig.nav` – "Curated navigation tree. Preferred over `groups` when present."
- `LLMFullContextConfig.nav` – "Curated navigation tree. Preferred over `groups` when present."
- `AgentReadabilityConfig.nav` – "Curated navigation tree. Preferred over `groups` when present."

### What Is `group` Still Good For?

The legacy `group` frontmatter field (which can be a string or array of strings) continues to serve as **fallback taxonomy and metadata**, useful when:
1. **Groups aren't explicitly configured** – If neither `nav` nor explicit `groups` are defined, leadtype infers groups from all `group:` declarations found in page frontmatter
2. **Semantic metadata** – Pages still declare their logical groups via frontmatter, which is preserved and exported (e.g., in the `groups` array on each page in navigation artifacts)
3. **Page organization** – In the runtime `DocsNavigation` structure returned by `resolveDocsNavigation()`, pages are grouped into `DocsNavigationGroup` entries whose membership is determined by matching the page's declared groups against the config

## 2. What Happens at Build Time with Unknown Groups

When a page's frontmatter declares a `group` slug that the config doesn't know about, **the build process fails with an error during generation**.

### The Error Flow

In the `leadtype generate` CLI code (around line 1354 in `cli.js`), this happens in a validation step:

```javascript
const navigation = await resolveDocsNavigation({
  srcDir: sourceMirror.srcDir,
  groups,
  nav: effectiveNav,
  mounts,
  i18n: metadata.i18n,
  locale
});

const firstUnknownGroup = navigation.unknown[0];
if (firstUnknownGroup) {
  throw new Error(
    `${firstUnknownGroup.urlPath} declares unknown group "${firstUnknownGroup.slug}"`
  );
}
```

The `resolveDocsNavigation()` function returns a `DocsNavigation` object that includes an `unknown` array:

```typescript
type DocsNavigation = {
  groups: DocsNavigationGroup[];
  ungrouped: DocsNavigationPage[];
  /** Pages that named a group slug not present in the config. */
  unknown: {
    urlPath: string;
    slug: string;
  }[];
  locale?: string;
};
```

### The Result

- **If a page declares an unknown group**, it is collected in the `unknown` array
- **During generation**, if any unknown groups exist, the entire `leadtype generate` command fails with a clear error message indicating which page and which group slug caused the problem
- This is **not a warning** – it's a hard error that prevents build completion, ensuring the configuration and page frontmatter are always in sync

This strict validation ensures that docs configuration is explicit and intentional, preventing ambiguity in how pages are organized.
