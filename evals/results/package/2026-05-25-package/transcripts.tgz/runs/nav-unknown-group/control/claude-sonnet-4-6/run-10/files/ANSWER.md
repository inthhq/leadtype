# Navigation: `nav` vs `group` frontmatter

## 1. Which one drives the sidebar and agent map — and what is the other still good for?

### The curated `nav` in `docs.config.ts` is the primary driver

When a `nav` array is present (and non-empty) in `docs.config.ts`, leadtype uses it
as the single authoritative source for **both** the sidebar navigation tree **and**
every agent-facing artifact:

| Artifact | Driven by `nav` |
|---|---|
| `DocsNavigation` object (returned by `resolveDocsNavigation`, consumed by the sidebar) | ✅ |
| `docs/llms.txt` curated map | ✅ |
| `llms-full.txt` page ordering | ✅ |
| `AGENTS.md` section structure | ✅ |
| `agent-readability.json` / `sitemap.md` navigation property | ✅ |

The `nav` tree is a hierarchy of `DocsNavNode` objects. Each node carries an
optional `pages` list whose entries are either exact file-relative paths (e.g.
`"quickstart"`) or glob-style `{ include, exclude, sort }` objects. Pages are
resolved by matching those path entries against the filesystem; the result is an
ordered, curated structure that is completely independent of any frontmatter
field.

The relevant guard that appears in every pipeline function (`generateLlmsTxt`,
`generateLLMFullContextFiles`, `generateAgentsMd`, `generateAgentReadabilityArtifacts`,
`resolveDocsNavigation`) is always the same:

```js
// from dist/_shared/llm-DbiIv5JE.js
const hasNav = Boolean(config.nav && config.nav.length > 0);
const resolved = hasNav
  ? resolveNavGroups(config.nav ?? [])   // ← nav wins
  : resolveGroups(config.groups ?? []);  // ← groups fallback
```

When `hasNav` is true the older `buildGroupMembership` / `buildNavigationGroup`
path (which reads each page's `groups` array) is **skipped entirely** for nav
and agent-map construction.

### The legacy `group` frontmatter field becomes secondary metadata

A page's `group:` field (a string or array of group slugs, e.g.
`group: reference`) is parsed during every file scan and stored in the
`SourceDoc.groups` array. When `nav` is present it is **not** used to position
the page in the sidebar or any agent artifact; the `nav` tree's explicit page
list governs position instead.

What `group` is still useful for when `nav` is present:

1. **Backwards-compatibility / mixed-mode.** If you ever remove `nav` from the
   config, leadtype falls back to the `group`-based `buildGroupMembership`
   path automatically. The frontmatter is already there; nothing needs to be
   rewritten.

2. **`unknown` group detection even in nav mode.** When `nav` is the primary
   driver, leadtype still calls `findUnknownGroups` to cross-check each page's
   declared `group` slugs against the config's `groups` tree. The results are
   surfaced in the `navigation.unknown` array on the returned `DocsNavigation`
   object, giving consumers a diagnostic list of mismatches even though those
   slugs have no effect on layout.

3. **Custom frontmatter consumers.** Because `group` is a first-class field in
   the default frontmatter schema (`v.optional(v.union([v.string(),
   v.array(v.string())]))` in `defaultFrontmatterSchema`), it is available on
   every loaded page's `frontmatter` object for any runtime code that wants to
   group or filter pages by category outside of the nav tree (e.g. tag clouds,
   breadcrumb helpers, or custom search filters).

4. **Search index.** The `groups` array is passed through to the `SourceDoc`
   that feeds `createDocsSearchIndex`, so downstream search consumers can
   filter results by group slug regardless of how the sidebar is structured.

---

## 2. What happens at build time when a page declares a `group` slug the config doesn't know about?

The outcome differs depending on which navigation mode is active.

### Mode A — only `groups` is configured (no `nav`)

The build pipeline calls `buildGroupMembership(pages, resolved)`. For every
slug in a page's `groups` array it looks up `slugKey` (lowercased) in a `Map`
built from the **flattened** config groups. If the slug is not found:

```js
// dist/_shared/llm-DbiIv5JE.js — buildGroupMembership
if (!known.has(slugKey)) {
  unknown.push({ page, slug });   // recorded but not thrown
  continue;
}
```

The page is pushed onto an `unknown` list instead of any known group bucket. If
**none** of its declared slugs matched a known group, the page is also pushed
onto the `ungrouped` list so it still appears in the sidebar under the implicit
**"Other"** section. The mismatch is **not** a hard error; it is a silent
data-level annotation surfaced via `navigation.unknown`.

### Mode B — `nav` is configured (primary driver)

`buildGroupMembership` is not called for nav construction at all. Instead,
leadtype calls `findUnknownGroups(docs, config.groups)` which internally runs
the group-based membership check purely for diagnostics:

```js
// dist/_shared/llm-DbiIv5JE.js — findUnknownGroups
function findUnknownGroups(docs, groups) {
  if (!(groups && groups.length > 0)) return [];
  const resolved = resolveGroups(groups);
  const membership = buildGroupMembership(docs, resolved);
  return membership.unknown.map(({ page, slug }) => ({
    urlPath: page.urlPath,
    slug,
  }));
}
```

The result is attached to the returned `DocsNavigation` object as
`navigation.unknown`. The page itself is **not removed** from the sidebar (its
position is determined solely by the `nav` tree) and **no exception is thrown**.

### At lint time (`leadtype lint` / `lintDocs`)

The linter validates frontmatter fields against `defaultFrontmatterSchema`. That
schema marks `group` as `v.optional(v.union([v.string(), v.array(v.string())]))` —
any string value is structurally valid. The linter does **not** cross-check slug
values against the config's `groups` tree; it only enforces type correctness.
A page with `group: nonexistent-slug` passes lint without error or warning.

### Summary

| Situation | Result |
|---|---|
| Unknown `group` slug, `groups`-only mode | Page lands in `navigation.unknown` + falls through to `ungrouped` ("Other"); **no error thrown** |
| Unknown `group` slug, `nav` mode | Recorded in `navigation.unknown` for diagnostics; nav position unaffected; **no error thrown** |
| Unknown `group` slug at lint time | **No violation** — the schema only checks type, not slug membership |

In all cases the build **does not fail**. Unknown slugs are soft diagnostic
data, not hard errors. If you want to enforce that every declared `group` slug
resolves to a real config entry you need to consume `navigation.unknown` from
`resolveDocsNavigation` in your own build script and throw (or log) from there.
