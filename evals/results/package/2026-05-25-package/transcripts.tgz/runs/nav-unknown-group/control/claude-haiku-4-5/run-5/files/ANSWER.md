# Navigation in leadtype: Curated `nav` vs Legacy `group` Frontmatter

## Question 1: Relationship Between `nav` Config and `group` Frontmatter

### What drives the sidebar and agent map?
The **curated `nav`** in `docs.config.ts` (or `leadtype.config.ts`) drives both the sidebar and agent-facing indexes when present. According to the leadtype type system, `nav?: DocsNavNode[]` is documented as:

> "Curated navigation for the single-collection shape. When present, this drives docs UI and agent-facing indexes; `groups` remains fallback taxonomy/navigation metadata."

This is consistently reflected across all build-time functions:
- `generateLlmsTxt()` — prefers `nav` over `groups` for structuring `/docs/llms.txt`
- `generateAgentsMd()` — prefers `nav` for structuring the offline `AGENTS.md` file
- `generateAgentReadabilityArtifacts()` — prefers `nav` for sitemap and agent readability manifests
- `resolveDocsNavigation()` — prefers `nav` for generating the navigation manifest consumed by the docs shell

### What is the `group` frontmatter field still good for?
The legacy **`group` frontmatter field** on pages serves as **fallback taxonomy and metadata**. Even when `nav` is present:
- Pages still declare which groups they belong to via frontmatter (`group: <slug>` or `group: [a, b]`)
- These group slugs are preserved in the `groups: string[]` array on every `SourceDoc` (pages returned by the build pipeline)
- When `nav` is absent, the `groups` config acts as the primary taxonomy for organizing the sidebar and agent indexes
- The `groups` field provides structure for tools that need hierarchical organization independent of the curated nav tree

**In summary:** `nav` is the author-facing curated structure for UI and agents; `groups` is the fallback organizational metadata that keeps pages tagged with their topical categories regardless of navigation curation.

---

## Question 2: Build-Time Behavior When a Page Declares an Unknown Group Slug

When a page's frontmatter declares a `group` slug that is **not present in the config** `groups` tree, the behavior at build time is:

1. **The page is processed without error** — leadtype does not throw or fail the build.

2. **The unknown group is tracked separately** — The `DocsNavigation` object (returned by `resolveDocsNavigation()` and written to disk) contains an `unknown` field:

   ```typescript
   unknown: {
     urlPath: string;
     slug: string;
   }[]
   ```

   This is an array of all pages and their group slugs that reference config group slugs that don't exist.

3. **The page appears in the `ungrouped` section** — Since the referenced group doesn't exist in the config, the page cannot be placed into the group hierarchy. It is collected in the `ungrouped: DocsNavigationPage[]` array instead.

4. **Visibility in agent artifacts** — The page's unknown group slug is documented in the manifest so downstream consumers (docs shells, agent tools) can detect and log mismatches or handle them gracefully. The page itself remains searchable and discoverable; it is simply not hierarchically organized under the non-existent group.

**In summary:** Unknown group declarations are silently tolerated, the page is moved to the ungrouped section, and the mismatch is recorded in the navigation manifest for debugging and transparency.
