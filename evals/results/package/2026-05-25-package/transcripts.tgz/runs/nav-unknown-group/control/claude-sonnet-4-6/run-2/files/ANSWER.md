# Navigation: `nav` vs `group` frontmatter — authoritative answers

---

## 1. Which one drives the sidebar and agent map, and what is the other good for?

### The curated `nav` in `docs.config.ts` is the primary driver

When a `nav` array is present and non-empty in `docs.config.ts` (or in a
collection's config), **every output that touches navigation uses `nav`
exclusively**:

| Output | How `nav` drives it |
|--------|---------------------|
| **Sidebar / `DocsNavigation`** (`resolveDocsNavigation`) | Calls `resolveNavGroups(nav)` + `buildNavigationFromNav()`. The navigation object's `groups` are the sections in `nav`, in the order written. |
| **`docs/llms.txt`** (`generateLlmsTxt`) | Calls `renderDocsNavigationSummary()`, which walks the nav tree — same structure, same order. |
| **`llms-full.txt`** (`generateLLMFullContextFiles`) | Pages are re-ordered by walking `flattenNavigationPagePaths(navigation)` before concatenation. |
| **`AGENTS.md`** (`generateAgentsMd`) | Calls `buildNavigationFromNav()` and renders sections in nav order with `renderAgentsNavigationGroup()`. |
| **`agent-readability.json`** (`generateAgentReadabilityArtifacts`) | Calls `buildNavigationFromMarkdownDocs(…, "nav")` — the manifest's `navigation` field is nav-driven. |

The mechanism is: every `nav` node's `pages` array lists explicit page paths
(strings) or `include` glob patterns. The build resolves each entry to a doc by
matching its `relativePath` against `docsByRelativePath`. The doc's own
`group` frontmatter field plays **no role** in this matching or ordering.

### `group` frontmatter is the legacy / fallback taxonomy

The page-level `group` field (a string or array of strings, parsed by
`normalizeGroupValue()`) is only consulted when **no `nav` is configured**
(i.e., when `!(nav && nav.length > 0)` is true). In that case the pipeline
falls back to `resolveGroups(config.groups)` + `buildGroupMembership()`, which
assigns each page to a group bucket purely by matching `page.groups` slugs
against the flat/nested `groups` tree declared in the config.

When `nav` *is* present, `group` still has two narrower uses:

1. **Cross-validation**: `resolveDocsNavigation` always calls
   `findUnknownGroups(docs, config.groups)` even when routing through `nav`.
   This produces the `navigation.unknown` array (pages whose `group` slug isn't
   in the `groups` tree), surfacing potential taxonomy drift — see Question 2.

2. **Preserved metadata on every page**: `group` values are parsed into
   `page.groups: string[]` and stored on every `DocsNavigationPage`,
   `AgentReadabilityPage`, and `SourceDoc`. Consumers can read them for
   filtering, faceting, or custom rendering even when `nav` controls order.

**Summary in one sentence**: `nav` in `docs.config.ts` owns sidebar rendering
and all agent/LLM output structure; `group` frontmatter is legacy taxonomy
metadata that powers the group-based fallback and surfaces as cross-validation
signal when `nav` is present.

---

## 2. What happens at build time if a page declares a `group` slug the config doesn't know about?

### The page is silently demoted — no hard error, no warning from the core pipeline

Here is the exact flow in `buildGroupMembership()` (the function used in the
legacy `groups`-only path):

```
for (const page of orderedPages) {
  for (const slug of page.groups) {
    if (!known.has(slug.toLowerCase())) {
      unknown.push({ page, slug });   // recorded, but not thrown
      continue;                       // slug is skipped
    }
    // ... assign to the correct bucket
  }
  if (!matchedAny) {
    ungrouped.push(page);             // page lands in the "Other" section
  }
}
```

Step by step:

1. **No exception is thrown.** The unrecognised slug is collected into the
   `unknown` array and the loop continues.

2. **The page falls into `ungrouped`** (and subsequently into the `## Other`
   section of `llms.txt` / `AGENTS.md`) if *every* slug on the page is
   unknown. If even one slug is valid, the page is grouped normally under that
   slug, and only the invalid slugs are silently discarded.

3. **The `unknown` list is returned** on the `DocsNavigation` object
   (`navigation.unknown: { urlPath, slug }[]`). It is available at runtime to
   any caller of `resolveDocsNavigation()` or embedded in
   `agent-readability.json`. No logging happens inside the core library.

4. **When `nav` is configured**, `findUnknownGroups()` still runs the same
   `buildGroupMembership()` check against `config.groups` and passes the result
   as the `unknown` array to `buildNavigationFromNav()`. The unknown slugs are
   again surfaced in `navigation.unknown` with no hard error.

5. **`leadtype lint`** is the only place this becomes a proper diagnostic.
   `lintDocs()` validates frontmatter against `defaultFrontmatterSchema`, which
   accepts `group` as `string | string[]` without checking slugs against the
   config. Slug-level cross-referencing is not part of the default lint rules —
   the violation is only visible via the `navigation.unknown` array at runtime,
   not as a `LintViolation`.

### Practical consequence

An unknown `group` slug produces **silent misfiling** in the group-based path
(page appears under "Other" instead of its intended section) and a populated
`navigation.unknown` array that most pipelines never inspect. There is no
build-breaking error from the core library. To catch this, teams should either:

- Inspect `navigation.unknown` in a custom build step or transformer, or
- Write a `beforeAgentsMd` / `beforeLlmsTxt` transformer that throws when
  `navigation.unknown` is non-empty.
