# Navigation in Leadtype: `nav` vs `group` Frontmatter

## Question 1: Relationship between curated `nav` and `group` frontmatter

### Which drives the sidebar and agent map?

**The curated `nav` in `docs.config.ts` is the primary driver** for the sidebar UI and agent-facing maps (agent readability artifacts, `llms.txt`, `AGENTS.md`, etc.).

When you define a `nav` tree in your config, it takes precedence:

```typescript
// docs.config.ts
export default defineDocsConfig({
  product: { name: "My Product", summary: "..." },
  nav: [  // ← This drives the sidebar and agent map
    {
      title: "Getting Started",
      slug: "getting-started",
      pages: ["quickstart", "installation"],
    },
    {
      title: "API Reference",
      slug: "api-ref",
      pages: ["functions/*", "types/*"],
    },
  ],
})
```

The `nav` tree is explicit, curated, and controls the exact structure that users see in the sidebar and agents see in discovery artifacts.

### What is the `group` frontmatter field still good for?

The `group` frontmatter field (`group: <slug>` or `group: [a, b]`) is a **fallback taxonomy** and **labeling mechanism**:

1. **Grouping metadata** — When a page declares `group: "api-ref"`, it labels the page as belonging to that group. This is useful for:
   - Organizing pages for agent reads even if they're not explicitly listed in `nav`
   - Building dynamic navigation when the `nav` tree is not fully curated
   - Providing semantic metadata to search indexing and agent readability

2. **Ungrouped pages** — Pages without a `group` field appear under an `"ungrouped"` section in the agent navigation manifest (`DocsNavigation`). The `group` field prevents this.

3. **Multi-group classification** — A single page can belong to multiple groups via `group: [admin, settings]`, which may be used by downstream tools (e.g., filtering documentation by feature area).

4. **Backward compatibility** — The `groups` config option (a flat list of group definitions without a tree) is the legacy approach. The `nav` tree supersedes it, but `group` frontmatter still works with the legacy `groups` setup.

**In practice**: If you're building a new project, **use `nav` for navigation and rely on `group` only for metadata**. If you have an older project with just `groups` and no `nav`, pages still organize via their `group` field.

---

## Question 2: What happens at build time if a page declares an unknown `group`?

### Build behavior: Unknown group slugs are tracked, not rejected

When a page's frontmatter declares a `group` slug that **doesn't exist in the config**, leadtype does **not error or fail the build**. Instead:

1. **The page is collected into the `unknown` array** in the `DocsNavigation` manifest:

   ```typescript
   type DocsNavigation = {
     groups: DocsNavigationGroup[];
     ungrouped: DocsNavigationPage[];
     unknown: {
       urlPath: string;
       slug: string;
     }[];  // ← Unknown group references appear here
     locale?: string;
   };
   ```

2. **The build succeeds**, but the navigation manifest includes a list of pages that referenced undefined groups. This allows:
   - Build tools to warn or report orphaned pages without failing
   - Runtime code to detect misconfigurations
   - Gradual migrations (e.g., renaming a group slug and catching pages that still use the old name)

3. **Linting** — The `lintDocs()` function from `leadtype/lint` does **not** reject unknown groups either. Unknown group slugs are allowed by the schema and pass validation.

### Key insight

This design prioritizes **resilience over strictness**: a page won't break navigation if its `group` doesn't exist. The manifests generated at build time (`resolveDocsNavigation()`) explicitly surface unknown groups so downstream tools can handle them gracefully—perhaps by:
- Logging a warning
- Creating a catch-all "Uncategorized" section
- Running a validation check in CI that ensures all referenced groups are defined
- Migrating pages to a new group slug over time

This matches the philosophy of the broader leadtype system: the build pipeline is permissive, and **validation is delegated to linting and custom tooling**.
