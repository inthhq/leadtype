# Navigation in Leadtype: `nav` vs. Legacy `group` Frontmatter

## 1. Relationship Between `nav` Config and `group` Frontmatter

### Which One Drives the Sidebar and Agent Map?

The **curated `nav` in `docs.config.ts` is the primary driver** for the sidebar and agent-readable navigation. When present, `nav` takes precedence over the `groups` tree.

According to the leadtype source types (`llm/index.d.ts`), the configuration shows:

```typescript
type DocsConfig = {
  // ...
  /** Top-level navigation for the single-collection shape. Pages declare which 
   * group they belong to via MDX frontmatter (`group: <slug>` or `group: [a, b]`). */
  groups?: DocsGroup[];
  
  /** Curated navigation for the single-collection shape. When present, this
   * drives docs UI and agent-facing indexes; `groups` remains fallback
   * taxonomy/navigation metadata. */
  nav?: DocsNavNode[];
}
```

Every generation function that builds the sidebar or agent artifacts shows the same pattern: **`nav` is preferred, and `groups` is used as a fallback**. For example:

- `generateLlmsTxt()`: accepts both `groups` and `nav`, but prefers `nav`
- `generateAgentReadabilityArtifacts()`: same preference pattern
- `generateAgentsMd()`: same preference pattern

### What Is the `group` Frontmatter Still Good For?

The legacy `group` frontmatter field (a single string or array of strings) serves two remaining purposes:

1. **Taxonomy/Metadata**: When `nav` is not present, the `groups` tree provides the fallback navigation structure. Pages declare their group membership via `group: <slug>` or `group: [a, b, c]` in frontmatter, and these are resolved against the `groups` tree.

2. **Ungrouped/Unknown Tracking**: The `DocsNavigation` manifest (returned by `resolveDocsNavigation()`) includes:
   - `ungrouped`: pages with no `group` field
   - `unknown`: pages declaring a `group` slug that the config doesn't know about

This allows downstream systems to detect misconfigurations or intentionally track pages outside the curated structure.

---

## 2. Build-Time Behavior for Unknown `group` Slugs

When a page declares a `group` slug that the config doesn't know about, **the build does not fail**. Instead:

1. **The page is added to the `unknown` array** in the `DocsNavigation` manifest (see `readability.d.ts`):
   ```typescript
   type DocsNavigation = {
     groups: DocsNavigationGroup[];
     ungrouped: DocsNavigationPage[];
     /** Pages that named a group slug not present in the config. */
     unknown: {
       urlPath: string;
       slug: string;
     }[];
   };
   ```

2. **The page is still generated and indexed** — it won't be excluded or cause a hard error.

3. **Linting can flag it as a warning or error** depending on configuration. The `leadtype lint` command validates frontmatter and can treat unknown groups as violations (controlled by the lint configuration in `docs.config.ts`).

4. **The page is effectively "orphaned"** from the sidebar navigation structure when using the `nav` curated navigation, since the unknown group slug has no match in the config tree.

### Summary

- **Build continues successfully**: No hard error is thrown during `leadtype generate`.
- **Manifest tracks the mismatch**: The `unknown` array in `DocsNavigation` records the orphaned pages.
- **Lint reports it**: The `leadtype lint` command can flag unknown groups as violations (error or warning).
- **Page is still accessible**: The markdown is generated and included in search and `AGENTS.md` output, just not in the curated nav structure.

This design allows gradual migration from `groups` to `nav` without breaking existing pages, and makes it easy to spot configuration drift during development.
