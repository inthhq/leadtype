# Navigation in leadtype: Config vs Frontmatter

## Question 1: The Relationship Between `nav` in Config and Page `group` Frontmatter

### Which one drives the sidebar and agent map?

**The `nav` (curated navigation) in `docs.config.ts` drives both the sidebar and agent map.** This is the primary control point.

**The legacy `group` frontmatter field is still good for:**
- **Fallback taxonomy** — when no curated `nav` is present, `group` values organize pages into navigational sections
- **Validation during build** — leadtype uses `group` slugs to detect when a page references an unknown group
- **Search and filtering** — the groups are still exposed in the resolved navigation metadata (`DocsNavigation.groups`)
- **Agent readability** — pages carry their group assignments in the generated manifests for agent consumption

### How they coexist

From the type definitions in leadtype (`dist/llm/index.d.ts`):

```typescript
type DocsConfig = {
  groups?: DocsGroup[];        // Legacy taxonomy (fallback)
  nav?: DocsNavNode[];         // Curated navigation (preferred)
  // ...
};
```

And from the resolved navigation type (`dist/llm/readability.d.ts`):

```typescript
type DocsNavigation = {
  groups: DocsNavigationGroup[];  // Compiled group hierarchy
  ungrouped: DocsNavigationPage[]; // Pages with no group
  unknown: {                        // Pages declaring unknown group slugs
    urlPath: string;
    slug: string;
  }[];
};
```

**Precedence in code generation:**
- **If `nav` is present**, it drives the sidebar structure in `llms.txt` and agent-readable indexes. The `groups` config is still validated for consistency but is not primary.
- **If only `groups` is present**, the flat/nested group structure becomes the navigation tree.
- **If neither is present**, pages are either `ungrouped` or placed in their declared groups.

The key insight from the source code: `nav` is **curated** (author-controlled paths and ordering), while `groups` is **taxonomic** (a fallback classification scheme). Both are available at runtime for different purposes.

---

## Question 2: What Happens at Build Time When a Page Declares an Unknown Group Slug

At build time, **leadtype throws an error and fails the build.**

### The implementation

From `dist/cli.js` (lines 1351–1354):

```javascript
const firstUnknownGroup = navigation.unknown[0];
if (firstUnknownGroup) {
  throw new Error(
    `${firstUnknownGroup.urlPath} declares unknown group "${firstUnknownGroup.slug}"`
  );
}
```

This check runs during `leadtype generate` after navigation is resolved. The error message includes:
- The page's URL path (e.g., `/docs/getting-started`)
- The unknown group slug that the page declared

### Why this happens

Pages declare group membership via frontmatter:

```mdx
---
group: my-group
---
```

The group slug must match a slug in the configured `groups` array (or be reachable via `nav` if curated navigation is present). If the page references a group that doesn't exist in config, leadtype treats this as a **configuration error**, not a warning.

### Resolution

To fix the build failure:
1. **Add the group to `docs.config.ts`:**
   ```typescript
   export default defineDocsConfig({
     groups: [
       { slug: 'my-group', title: 'My Group' },
       // ...
     ],
     // ...
   });
   ```

2. **Or update the page's frontmatter** to use a group slug that exists in the config.

3. **Or remove the `group` field** if the page should be ungrouped (it will appear under `DocsNavigation.ungrouped`).

This strict validation ensures the navigation hierarchy is always consistent and prevents orphaned pages at build time.
