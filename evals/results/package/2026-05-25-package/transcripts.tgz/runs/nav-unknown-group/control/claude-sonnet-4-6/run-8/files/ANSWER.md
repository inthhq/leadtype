# Navigation: `nav` vs. `group` frontmatter

## 1. Which one drives the sidebar and agent map — and what is the other still good for?

### The curated `nav` in `docs.config.ts` is the authoritative driver

When a `nav` array is present and non-empty in `docs.config.ts` (or in a
collection inside `collections`), **every navigation artifact is built from
that tree**:

| Artifact | Driven by `nav` |
|---|---|
| `DocsNavigation` returned by `resolveDocsNavigation()` | ✅ `buildNavigationFromNav()` |
| Sidebar/agent map written to `agent-readability.json` | ✅ via `generateAgentReadabilityArtifacts()` |
| `/docs/llms.txt` curated docs map | ✅ `renderDocsNavigationSummary()` |
| `AGENTS.md` offline bundle | ✅ `buildNavigationFromNav()` |
| `llms-full.txt` page order | ✅ nav order via `orderMarkdownDocsByNavigation()` |

The `nav` tree is resolved by `resolveNavGroups()`, which walks the
`DocsNavNode[]` hierarchy. Each node's `pages` array lists either explicit
relative paths or `{ include: "glob/**" }` wildcard entries. Pages are placed
in the sidebar **exactly** in the order the curated `nav` declares them.

**Code evidence** (from `dist/_shared/llm-DbiIv5JE.js`):

```js
// resolveDocsNavigation — the primary public API
if (config.nav && config.nav.length > 0) {
  const resolvedNav = resolveNavGroups(config.nav);
  return buildNavigationFromNav(
    docs, resolvedNav, tocByUrlPath, …, findUnknownGroups(docs, config.groups)
  );
}
// --- falls through to groups path only when nav is absent ---
const resolved = resolveGroups(config.groups ?? []);
```

Same `if (hasNav)` branch governs `generateLlmsTxt`, `generateAgentsMd`, and
`generateAgentReadabilityArtifacts`.

### The legacy `group` frontmatter field is a taxonomy/validation hint

`group:` (a string or string array in a page's YAML front matter) is **read and
stored on every page** as `SourceDoc.groups: string[]`. It is used for two
things once `nav` is present:

1. **Orphan detection / "unknown groups" reporting.**  
   `findUnknownGroups()` runs a full `buildGroupMembership()` pass against the
   `groups` config tree to find any page whose `group:` slug has no matching
   entry in the config. The result is surfaced in
   `DocsNavigation.unknown: { urlPath, slug }[]`, which lets tooling flag
   misconfigured pages without blocking the build.

2. **Preserved on page objects for consumers.**  
   `DocsNavigationPage.groups`, `AgentReadabilityPage.groups`, and
   `DocsPageMeta.groups` all carry the raw frontmatter values. Framework
   adapters, search transformers, or custom tooling can still read them (e.g.
   to tag search results, filter by topic, or drive a secondary filter UI).

When `nav` is **absent**, the roles swap: `group` frontmatter is the *only*
thing that drives navigation (via `buildGroupMembership()` + `resolveGroups()`),
and there is no curated tree at all.

**Summary table:**

| Config state | Sidebar / agent map | `group` frontmatter role |
|---|---|---|
| `nav` present & non-empty | Driven entirely by `nav` | Orphan detection + per-page metadata |
| `nav` absent | Driven by `group` frontmatter + `groups` config | Primary navigation signal |

---

## 2. What happens at build time when a page declares an unknown `group` slug?

A page whose `group:` value does not match any slug in the `groups` config tree
**does not cause a hard error** — the build continues. Instead, several softer
things happen:

### a) The page is recorded in `DocsNavigation.unknown`

`buildGroupMembership()` (called both in the groups-only path and via
`findUnknownGroups()` in the `nav` path) tracks every unresolvable slug:

```js
// inside buildGroupMembership()
for (const slug of page.groups) {
  const slugKey = slug.toLowerCase();
  if (!known.has(slugKey)) {
    unknown.push({ page, slug });   // ← recorded, not thrown
    continue;
  }
  …
}
// page also falls into `ungrouped` if none of its slugs matched
if (!matchedAny) {
  ungrouped.push(page);
}
```

The `unknown` array is part of the `DocsNavigation` type returned by
`resolveDocsNavigation()` and embedded in `agent-readability.json`.

### b) The page is silently demoted to "ungrouped / Other"

Because none of the page's slugs matched, `matchedAny` remains `false` and
the page is pushed into `membership.ungrouped`. In the rendered outputs it
appears under the **"Other"** catch-all section (both in `llms.txt` and
`AGENTS.md`) rather than in any named group.

### c) `nav`-include mismatches **do** throw

If the unknown slug appears not in `group` frontmatter but inside a **`nav`
page entry** (e.g. a literal path string that resolves to no file), that *does*
throw a hard `Error`:

```js
// resolveNavEntryPages — literal path entries
const doc = docsByRelativePath.get(ref);
if (!doc) {
  throw new Error(
    `Nav page "${entry}" under "…" did not match a documentation page.`
  );
}
```

Similarly, a `{ include: "…", required: true }` entry with zero matches also
throws. A non-`required` include with zero matches instead emits a
`logger.warn(…)` to stderr and returns an empty list.

### d) `leadtype lint` reports it separately

`lintDocs()` validates frontmatter schema via Valibot. The `group` field is
typed as `v.optional(v.union([v.string(), v.array(v.string())]))` — any string
value is schema-valid. Slug cross-referencing against the `groups` config is
**not** a lint rule; unknown slugs surface only through the `DocsNavigation.unknown`
field at generation time, not as lint violations.

### Behaviour summary

| Scenario | Result |
|---|---|
| `group: unknown-slug` in frontmatter, `groups` config doesn't know it | Page added to `navigation.unknown[]`; demoted to "Other" in all outputs; **no error thrown** |
| Literal path in `nav.pages` that matches no file | **Hard `Error`** thrown at build time |
| `{ include: "glob", required: true }` matching nothing | **Hard `Error`** thrown at build time |
| `{ include: "glob" }` (no `required`) matching nothing | `logger.warn()` to stderr; empty result; build continues |
