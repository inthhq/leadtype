# Navigation in a leadtype project

Short answer: **`nav` wins.** When `docs.config.ts` defines a `nav` tree, it
drives every sidebar/agent artifact leadtype generates. The legacy `group:`
frontmatter field becomes per-page *taxonomy metadata* — still parsed, still
exposed, but no longer responsible for placing pages in the sidebar.

This is documented in the package's own types (`node_modules/leadtype/dist/llm/index.d.ts`):

> ```ts
> /**
>  * Curated navigation for the single-collection shape. When present, this
>  * drives docs UI and agent-facing indexes; `groups` remains fallback
>  * taxonomy/navigation metadata.
>  */
> nav?: DocsNavNode[];
> ```

The same "Curated navigation tree. Preferred over `groups` when present."
comment is repeated on `LlmsTxtConfig`, `LLMFullContextConfig`,
`AgentReadabilityConfig`, `AgentsMdConfig`, and `ResolveDocsNavigationConfig`.

---

## 1. What drives the sidebar / AGENTS.md / llms.txt?

Every generator in `leadtype/dist/_shared/llm-*.js` branches on the same flag:

```js
const hasNav = Boolean(config.nav && config.nav.length > 0);
const resolved = hasNav
  ? resolveNavGroups(config.nav ?? [])     // curated tree
  : resolveGroups(config.groups ?? []);    // legacy taxonomy
```

That flag governs:

| Output | File / function | Source of order & grouping when `nav` is set |
|---|---|---|
| Docs sidebar manifest | `resolveDocsNavigation()` → e.g. `src/generated/docs-nav.json` | `nav` tree |
| `/docs/llms.txt` (curated map) | `generateLlmsTxt()` | `nav` tree |
| `llms-full.txt` page order | `generateLLMFullContextFiles()` | `nav` tree (via `orderMarkdownDocsByNavigation`) |
| Agent Readability manifest + `sitemap.md` | `generateAgentReadabilityArtifacts()` | `nav` tree |
| Bundled `AGENTS.md` (agent map) | `generateAgentsMd()` | `nav` tree |

In `nav` mode, pages enter the sidebar by being **explicitly referenced** —
either as a path string (`"quickstart"`, `"/reference/cli"`) or as an
`include` glob (`{ include: "reference/**", sort: ["order", "title"] }`).
Frontmatter `group:` is **not consulted** for placement. Any page the `nav`
tree doesn't reference is collected into `navigation.ungrouped`.

### What `group:` is still good for

`group:` is read on every page and lands on the `SourceDoc.groups` /
`AgentReadabilityPage.groups` field (see `SourceDoc` in
`llm/index.d.ts` and `buildGroupMembership` in `_shared/llm-*.js`). So
even in `nav` mode it is still useful as:

- **Per-page taxonomy metadata** — surfaced on `manifest.pages[].groups`, in
  the markdown mirror frontmatter, and to any custom `DocsTransformer` you
  wire in.
- **Fallback navigation** — if you remove `nav` (or scaffold a new
  collection without one yet), `groups` + `group:` frontmatter immediately
  takes back over as the grouping mechanism. `resolveGroups(config.groups)`
  is still called, the membership tree is still built, and `llms.txt` /
  `AGENTS.md` will render from it.
- **Validation companion** — even with `nav` set, leadtype still calls
  `findUnknownGroups(docs, config.groups)` so the page-level `group:` slugs
  are checked against the configured `groups` taxonomy and the orphan list
  is propagated onto `navigation.unknown` in the manifest (see below).

Mental model: **`nav` answers "what goes in the sidebar, in what order";
`group:` answers "what bucket does this page belong to" for downstream
metadata.** When both exist, they are independent and `nav` is authoritative
for UI/agent surfaces.

---

## 2. What happens to an unknown `group:` slug at build time?

**Nothing fatal.** It is *not* a hard build error.

Walk through `buildGroupMembership` in `node_modules/leadtype/dist/_shared/llm-DbiIv5JE.js`:

```js
for (const slug of page.groups) {
  const slugKey = slug.toLowerCase();
  if (!known.has(slugKey)) {
    unknown.push({ page, slug });        // <- collected, not thrown
    continue;
  }
  // ... otherwise placed under the matching group
}
if (!matchedAny) {
  ungrouped.push(page);                  // page falls back to "Other"
}
```

So a page that declares `group: does-not-exist` will:

1. Be added to `navigation.unknown` as `{ urlPath, slug }` on the resolved
   navigation manifest (`DocsNavigation.unknown` in
   `llm/readability.d.ts`). Build tooling and dashboards can surface that
   list; leadtype itself only records it.
2. **In `groups`-only mode:** if the page declared no slugs that matched a
   configured group, it falls through to `navigation.ungrouped`, which
   `generateLlmsTxt` / `generateAgentsMd` render under a top-level
   "## Other" heading.
3. **In `nav` mode:** placement is decided entirely by the `nav` tree, so
   the unknown slug only affects metadata + the `unknown` report. The page
   is still placed wherever (or not) the `nav` tree references it.

### What *does* fail the build

For completeness, the navigation pipeline raises hard errors in these cases
(all from `_shared/llm-DbiIv5JE.js`):

- `assertValidGroupSlug` — a slug in `groups` or an inferred `nav` slug
  isn't URL-safe (alphanumerics + dashes).
- Duplicate sibling slugs under the same parent in `groups` or `nav`.
- A `nav` page string (e.g. `"quickstart"`) that doesn't resolve to any
  doc: `Nav page "quickstart" under "<group>" did not match a documentation page.`
- A `nav` include entry with `required: true` whose glob matches no pages.
  (Without `required`, it logs a `nav.include.empty` warning and continues.)
- Two source files normalizing to the same `urlPath`.

### Catching orphans early

If you want unknown `group:` slugs to *block* CI rather than just sit in
`navigation.unknown`, the standard pattern is:

```ts
// build/check-nav.ts
import { resolveDocsNavigation } from "leadtype/llm";
import config from "../docs.config";

const nav = await resolveDocsNavigation({
  srcDir: ".",
  baseUrl: "https://example.com",
  nav: config.nav,
  groups: config.groups,
});

if (nav.unknown.length > 0) {
  console.error("Pages reference unknown group slugs:");
  for (const { urlPath, slug } of nav.unknown) {
    console.error(`  ${urlPath} -> group: ${slug}`);
  }
  process.exit(1);
}
```

That promotes the manifest's `unknown` array into a build-time gate without
having to fight leadtype's permissive defaults.

---

## TL;DR

- **`nav` is authoritative** for the sidebar, `AGENTS.md`, `llms.txt`,
  `llms-full.txt` ordering, and the Agent Readability manifest. The
  generators all check `hasNav` and prefer `nav` over `groups`.
- **`group:` frontmatter is still parsed** and exposed as per-page
  taxonomy metadata, lint/transformer input, and the fallback grouping if
  you ever drop `nav`.
- **Unknown `group:` slugs don't fail the build.** They land in
  `navigation.unknown` and (in `groups`-only mode) the page itself falls
  through to "Other". Promote them to errors yourself via
  `resolveDocsNavigation(...).unknown` in CI if you want strictness.
