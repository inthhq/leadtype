# Navigation: `nav` vs `group` frontmatter — answers

---

## 1. Which one drives the sidebar and agent map, and what is the other still good for?

### `nav` is the authoritative driver

The curated `nav` array in `docs.config.ts` (a `DocsNavNode[]`) is the **primary
source of truth** for both the runtime sidebar and every agent-facing artifact.
When `nav` is present and non-empty, `resolveDocsNavigation` calls
`resolveNavGroups` + `buildNavigationFromNav` instead of the group-membership
path, and the result is what powers:

- **Sidebar** — `getNavigation()` (from `createDocsSource`) returns the nav-built
  `DocsNavigation` object; your UI renders that.
- **`llms.txt` / `docs/llms.txt`** — `generateLlmsTxt` branches on `hasNav` and
  calls `renderDocsNavigationSummary` (nav-aware) instead of `renderDocsSummary`
  (group-aware).
- **`llms-full.txt`** — `generateLLMFullContextFiles` reorders pages by nav when
  `nav` is present.
- **`AGENTS.md`** — `generateAgentsMd` walks `buildNavigationFromNav` when `nav`
  is set, building the offline agent index from the curated tree.
- **Agent-readability manifest / sitemap** — `generateAgentReadabilityArtifacts`
  passes `mode: "nav"` to `buildNavigationFromMarkdownDocs` when `nav` is
  present.

In short: **`nav` owns the order and structure of every output that a user or
agent reads.**

### `group` frontmatter is the fallback taxonomy + unknown-slug detector

The legacy `group: <slug>` (or `group: [a, b]`) field in page frontmatter is
used in two distinct ways once `nav` is present:

1. **Fallback when `nav` is absent** — if no `nav` is configured, leadtype falls
   back to `buildGroupMembership`, which matches each page's `group` slugs
   against the `groups` array in config and assigns pages to sidebar sections
   that way. So `group` is still the *only* driver for projects that haven't
   migrated to `nav` yet.

2. **Unknown-slug validation even when `nav` is active** — even in nav mode,
   `resolveDocsNavigation` calls `findUnknownGroups(docs, config.groups)` and
   attaches the result as `navigation.unknown`. This lets the build pipeline
   detect pages that declare a `group` slug that no longer appears in the
   `groups` array (see question 2 below). The `group` slugs are also preserved
   verbatim on every `DocsPageMeta` (the `groups: string[]` field) and in the
   agent-readability manifest pages list, so downstream tooling can still use
   them for custom filtering or taxonomy.

**Summary:**

| | `nav` (in config) | `group` (in frontmatter) |
|---|---|---|
| Drives sidebar order & structure | ✅ (when present) | ✅ (fallback only, when `nav` absent) |
| Drives agent map / `llms.txt` / `AGENTS.md` | ✅ (when present) | ✅ (fallback only) |
| Surfaced on page metadata (`groups` field) | — | ✅ always |
| Used for unknown-slug validation | — | ✅ always (cross-checked against `groups` config) |

---

## 2. What happens at build time if a page declares a `group` slug the config doesn't know about?

It is a **hard build error** — the `leadtype generate` command exits with code 1.

Here is the exact code path (from `cli.js` → `runGenerateCommand`):

```js
// cli.js — inside runGenerateCommand
const navigation = await resolveDocsNavigation({
  srcDir: sourceMirror.srcDir,
  groups,
  nav: effectiveNav,
  mounts,
  i18n: metadata.i18n,
  locale
});

const firstUnknownGroup = navigation.unknown[0];
if (firstUnknownGroup) {
  throw new Error(
    `${firstUnknownGroup.urlPath} declares unknown group "${firstUnknownGroup.slug}"`
  );
}
```

`navigation.unknown` is populated by `findUnknownGroups`, which calls
`buildGroupMembership` against the configured `groups` array. For every page
whose `group:` value (after normalisation to lowercase) does **not** match any
slug in the flattened `groups` tree, an entry `{ urlPath, slug }` is pushed onto
the `unknown` array.

The CLI then inspects `navigation.unknown[0]`: if any unknown slug was found, it
throws immediately — **before** any `convertAllMdx`, `generateLlmsTxt`, or
search-index work is done — and returns exit code `1`.

This check runs **even when `nav` is configured**: `findUnknownGroups` is always
called and passed to `buildNavigationFromNav` as the `unknown` parameter, so the
guard fires regardless of which navigation mode is active.

### What this means in practice

- Adding a new `group: my-new-section` to a page without also adding
  `{ slug: "my-new-section", title: "My New Section" }` to `groups` in
  `docs.config.ts` will break the build immediately.
- The error message names the offending page URL path and the unknown slug,
  making it straightforward to fix.
- The `lintDocs` command (`leadtype lint`) does **not** independently validate
  group slugs against the config (it only schema-validates the frontmatter
  shape), so this specific check is a generate-time-only guard.
