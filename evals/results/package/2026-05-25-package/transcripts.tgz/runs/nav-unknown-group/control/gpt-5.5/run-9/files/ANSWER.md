# Leadtype navigation and legacy `group` frontmatter

1. **`nav` is the source of truth when it is present.** The curated `nav` tree in `docs.config.ts` drives the docs navigation/sidebar and the agent-facing maps/indexes (for example `AGENTS.md`, `/docs/llms.txt`, and the agent-readability navigation). A page’s legacy `group` frontmatter does **not** place that page in the sidebar when `nav` is configured; pages are included where `nav.pages` or `nav` include globs put them. The `group` field is still useful as fallback taxonomy/navigation metadata: it is used when there is no curated `nav`, remains page metadata (`groups`), and can still be validated against configured `groups`.

2. **Unknown `group` slugs fail the build.** During `leadtype generate`, Leadtype resolves the navigation before writing artifacts and checks for pages whose frontmatter declares a `group` slug that is not known by the configured `groups` tree. If it finds one, generation throws an error like:

   ```text
   /docs/some-page declares unknown group "some-slug"
   ```

   So the page is not silently auto-added or ignored; the build exits non-zero until the slug is added to config or removed/fixed in frontmatter.
