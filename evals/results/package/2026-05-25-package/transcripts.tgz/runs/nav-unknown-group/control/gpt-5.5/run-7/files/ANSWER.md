# Leadtype navigation notes

1. The curated `nav` in `docs.config.ts` takes precedence. When `nav` is present, it is the source Leadtype uses to build the docs sidebar/navigation manifest and the agent-facing maps such as `/docs/llms.txt`, `AGENTS.md`, sitemap/readability navigation, and related ordering. A page's legacy `group` frontmatter no longer places that page in the sidebar when `nav` is being used. `group` is still useful as taxonomy/metadata: it is preserved on page metadata and agent readability page records, can be used by adapters or custom UI for filtering, and acts as the fallback navigation mechanism for projects that do not define `nav`.

2. During `leadtype generate`, Leadtype validates declared page groups against the configured `groups` taxonomy. If a page has `group: some-slug` and that slug is not present in the configured groups, generation fails before writing the final artifacts, with an error like:

   ```text
   /docs/path/to/page declares unknown group "some-slug"
   ```

   This validation is about the configured `groups` list, not the curated `nav` tree. A page's `group` does not need to match a `nav` node. If a project defines only `nav` and no `groups` taxonomy, there is no group list to validate against; if it keeps `groups` around for taxonomy/metadata, the frontmatter slugs must stay in sync with that list.
