# Navigation in Leadtype: `nav` vs `group` Frontmatter

## 1. The Relationship Between `nav` Config and `group` Frontmatter

### Which One Drives the Sidebar and Agent Map?

**The curated `nav` in `docs.config.ts` drives the sidebar and agent map** when present. According to the leadtype type definitions, `nav` is explicitly marked as "Preferred over `groups`" in multiple function signatures throughout the codebase:

```typescript
// From llm/index.d.ts
type DocsConfig = {
  groups?: DocsGroup[];
  /**
   * Curated navigation for the single-collection shape. When present, this
   * drives docs UI and agent-facing indexes; `groups` remains fallback
   * taxonomy/navigation metadata.
   */
  nav?: DocsNavNode[];
  // ...
}
```

The `nav` tree is the "author-facing curated navigation tree" that defines the actual structure users see when browsing docs or when agents read the documentation hierarchy.

### What is `group` Frontmatter Good For?

The `group` frontmatter field serves as a **fallback taxonomy and navigation metadata**. While `nav` drives the sidebar and agent map, `group` frontmatter:

1. **Categorizes pages for fallback grouping** — when `nav` is absent, pages are organized into navigation sections based on their declared `group` slug(s).

2. **Provides redundant metadata** — pages declare which group(s) they belong to via `group:` in frontmatter (supporting both single `group: "slug"` and multiple `group: ["slug1", "slug2"]`).

3. **Serves as a stability anchor** — allows pages to maintain their semantic categorization independently of the curated navigation hierarchy.

### Key Distinction

- **`nav` is hierarchical and curated**: It explicitly defines which pages appear where in the UI through `DocsNavNode[]` with `pages` and `children` properties.
- **`group` frontmatter is declarative and content-driven**: Pages announce their category membership, creating a "content-source-of-truth" that can exist independently of the navigation config.

In a build system, **`nav` constructs the canonical navigation tree**, while **`group` provides the page-level metadata that gets indexed and reported in the `DocsNavigation` result**.

---

## 2. What Happens at Build Time When a Page Declares an Unknown Group?

When a page declares a `group` slug that the config doesn't know about, **the unknown group is tracked in the `unknown` array** of the `DocsNavigation` result.

### The Formal Specification

From the `DocsNavigation` type definition in `llm/readability.d.ts`:

```typescript
type DocsNavigation = {
  groups: DocsNavigationGroup[];
  ungrouped: DocsNavigationPage[];
  /** Pages that named a group slug not present in the config. */
  unknown: {
    urlPath: string;
    slug: string;
  }[];
  locale?: string;
};
```

### What This Means

1. **No build failure** — leadtype does not throw an error or halt the build when encountering an unknown group slug.

2. **Pages are recorded separately** — pages that declare unknown groups are moved out of the normal `groups` tree and stored in the `unknown` array, which tracks:
   - The page's `urlPath` (its URL location in the docs site)
   - The `slug` of the unknown group they declared

3. **Available for reporting** — the `unknown` array is returned as part of the `DocsNavigation` object, making it accessible to:
   - Linting systems (the `leadtype lint` command) that could warn about misconfigurations
   - Build-time reporting tools that surface navigation inconsistencies
   - CI/CD integrations that want to flag orphaned pages

### Practical Implications

- **Graceful degradation**: Pages with unknown groups don't break the build; they're simply flagged as anomalies.
- **Lint-time detection**: Use `leadtype lint` to catch these mismatches and warn content authors.
- **Data-driven fixes**: The `unknown` array provides structured data so tooling can suggest the correct group slug or help add it to the config.

This design allows teams to:
- Maintain editorial flexibility (pages can be categorized before group definitions exist)
- Catch configuration drift (mismatch between group declarations and config definitions)
- Generate actionable reports without blocking the entire build pipeline
