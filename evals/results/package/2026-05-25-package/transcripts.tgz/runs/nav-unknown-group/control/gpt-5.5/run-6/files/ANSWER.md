# Leadtype navigation vs. `group` frontmatter

1. The curated `nav` in `docs.config.ts` is the source of truth for navigation when it is present. It drives the docs sidebar/navigation manifest and the agent-facing maps/indexes such as `AGENTS.md`, `/docs/llms.txt`, and the agent readability navigation. Pages are placed by the explicit `nav` tree (`pages`, `include`, `children`, `base`, sort options), not by their legacy `group` frontmatter.

   The page `group` field is still useful as metadata/taxonomy: it is preserved on page metadata, can be used by adapters/UI for filtering or tagging, validates legacy group membership when configured, and remains the fallback navigation mechanism for projects that do not define a curated `nav`.

2. During `leadtype generate`, Leadtype resolves the navigation and checks for pages whose `group` frontmatter references a configured group slug that does not exist. If it finds one, the build fails before emitting the docs artifacts, with an error like:

   ```text
   /docs/some-page declares unknown group "missing-slug"
   ```

   With curated `nav`, the unknown `group` does not control placement in the sidebar; validation only has a registry to check against if you still define `groups` in config. If no `groups` registry is defined, `group` frontmatter is effectively just ignored for navigation.