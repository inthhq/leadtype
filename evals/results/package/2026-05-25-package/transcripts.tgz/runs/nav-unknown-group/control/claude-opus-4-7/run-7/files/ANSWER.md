# Onboarding: `nav` vs. `group` in a leadtype project

Both answers below are grounded in the installed `leadtype` package — primarily the type definitions in `node_modules/leadtype/dist/llm/index.d.ts` and `dist/llm/readability.d.ts`, and the build pipeline in `node_modules/leadtype/dist/cli.js`.

## 1. What's the relationship between `nav` in `docs.config.ts` and a page's `group` frontmatter?

They describe the same docs tree from two different sides, and they are **not equal citizens**: `nav` is the curated, author-written tree in the config; `group` is a per-page taxonomy label declared in MDX frontmatter.

**`nav` is the source of truth for what users and agents see.** Whenever a `nav` tree is present, leadtype hands it (not `groups`) to every downstream generator:

- The TypeScript surface flags this explicitly. `LlmsTxtConfig`, `LLMFullContextConfig`, `AgentReadabilityConfig`, `AgentsMdConfig`, and `ResolveDocsNavigationConfig` each define `nav?: DocsNavNode[]` with the comment *"Curated navigation tree. Preferred over `groups` when present."*
- The top-level `DocsConfig.nav` doc-comment says the same thing in plainer English: *"When present, this drives docs UI and agent-facing indexes; `groups` remains fallback taxonomy/navigation metadata."*
- `cli.js` confirms this at runtime. `resolveGenerateMetadata` returns both `groups` and `nav`, and the generate command computes `effectiveNav = hasExplicitPathFilters ? undefined : nav` and then passes that same `effectiveNav` into `resolveDocsNavigation`, `generateAgentsMd`, `generateLlmsTxt`, `generateLLMFullContextFiles`, and `generateAgentReadabilityArtifacts`. That's the sidebar, `llms.txt`, `llms-full.txt`, `AGENTS.md`, and the agent-readability sitemap/manifest — all driven by `nav`.

**`group` frontmatter is still useful, but in a supporting role.** A page's `group: <slug>` (or `group: [a, b]`) does three things:

1. **Fallback navigation when no `nav` is configured.** If `docs.config.ts` only declares `groups` (or only `groups` per collection), leadtype falls back to building the tree by matching each page's `group` slug against the configured `DocsGroup.slug` entries. `SourceDoc.groups` in the type defs is described as *"Group slugs declared in frontmatter `group:`. Empty array = ungrouped."*
2. **Taxonomy/metadata that survives even when `nav` drives the UI.** `AgentReadabilityPage` and `DocsNavigationPage` both retain a `groups: string[]` field per page, so the page's declared groups are still emitted in the agent-readability manifest as a classification signal even when the curated `nav` is what builds the tree.
3. **Inference / bootstrapping.** When there is no config (or a collections config with no groups declared), `cli.js` calls `inferGroups(docsDir)` which walks every `.mdx`, reads the `group:` frontmatter, and synthesizes a `groups` list. That's how a leadtype-less repo can still produce sectioned output.

The short version for the team: **edit `nav` in `docs.config.ts` to change what users see; keep `group` accurate on each page so the agent manifest stays correctly classified and the fallback path keeps working.**

## 2. What happens at build time if a page declares a `group` slug the config doesn't know about?

**The `leadtype generate` build fails.** Unknown group slugs are a hard error, not a warning.

The mechanism (visible in `cli.js`):

1. After loading the config, generate calls `resolveDocsNavigation({ srcDir, groups, nav, mounts, i18n, locale })` for each locale.
2. The returned `DocsNavigation` object (typed in `dist/llm/readability.d.ts`) carries an `unknown: { urlPath: string; slug: string }[]` array — defined as *"Pages that named a group slug not present in the config."*
3. `cli.js` then does:

   ```js
   const firstUnknownGroup = navigation.unknown[0];
   if (firstUnknownGroup) {
     throw new Error(
       `${firstUnknownGroup.urlPath} declares unknown group "${firstUnknownGroup.slug}"`
     );
   }
   ```

That `throw` is caught by the outer `try/catch` in `runGenerateCommand` and reported via `reportFailure`, so the CLI exits with code `1` and the error message names the offending page path and slug, e.g.:

```
leadtype generate: /docs/guides/onboarding declares unknown group "intro"
```

A couple of useful nuances:

- The check runs **per locale**, so an unknown group in any localized copy of a page also fails the build.
- It runs **before** any markdown conversion or artifact generation, so a typo in `group:` short-circuits the whole pipeline rather than silently dropping pages from the sidebar.
- The fix is one of: add the missing slug to `groups` (or to the relevant collection's `groups`) in `docs.config.ts`, correct the typo in the page's frontmatter, or remove the `group:` field if the page is meant to be ungrouped (empty `groups` array is legal — those pages land in `DocsNavigation.ungrouped`).
