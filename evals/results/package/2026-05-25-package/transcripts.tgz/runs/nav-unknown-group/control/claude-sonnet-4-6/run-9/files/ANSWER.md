# Navigation in leadtype: `nav` vs `group` frontmatter

## 1. Which one drives the sidebar and agent map, and what is the other still good for?

### The curated `nav` tree drives everything

When a `nav` array is present in `docs.config.ts`, it is the **sole authority**
for the sidebar order and structure, the agent-readable map (`AGENTS.md`), and
all derived artifacts (`llms.txt`, `sitemap.md`, `agent-readability.json`).

The pipeline expresses this precedence explicitly and consistently throughout
the source. Every major build function checks the same condition first:

```js
// from dist/_shared/llm-DbiIv5JE.js (generateLlmsTxt, generateAgentsMd,
// resolveDocsNavigation, generateAgentReadabilityArtifacts, …)
const hasNav = Boolean(config.nav && config.nav.length > 0);
const resolved = hasNav
  ? resolveNavGroups(config.nav ?? [])   // ← curated tree wins
  : resolveGroups(config.groups ?? []);  // ← legacy fallback
```

When `nav` is present, navigation is built by `buildNavigationFromNav`, which
walks the explicitly listed pages (path strings and `include` globs) in the
order they appear in the config. Any page not referenced by a `nav` entry lands
in `ungrouped` — it still appears in the output but is not part of the curated
sections. The `DocsNavigation` type returned by `resolveDocsNavigation` carries
this same `groups` / `ungrouped` / `unknown` shape regardless of which mode is
used; `nav` just populates `groups` via author-defined ordering rather than
frontmatter matching.

The `DocsConfig` type documents this directly:

```ts
/**
 * Curated navigation for the single-collection shape. When present, this
 * drives docs UI and agent-facing indexes; `groups` remains fallback
 * taxonomy/navigation metadata.
 */
nav?: DocsNavNode[];
```

### The legacy `group` frontmatter field is still good for taxonomy and search metadata

When `nav` is in charge, a page's `group: <slug>` frontmatter is **not** used
to determine sidebar placement or to build `AGENTS.md` / `llms.txt` — those are
driven entirely by the `nav` tree. However, `group` is still read by the
pipeline and preserved in every page's metadata:

```ts
// SourceDoc / DocsNavigationPage both carry:
groups: string[];   // ← slug(s) from frontmatter `group:`
```

That array travels through to the `agent-readability.json` manifest
(`AgentReadabilityPage.groups`), the search index documents
(`DocsSearchDocument`), and the `DocsPageMeta` shape returned by
`createDocsSource`. This means `group` tags remain useful for:

- **Custom UI filtering / faceting** — a sidebar or search UI can still read
  `page.groups` to render category badges, filter results by topic, or group
  search hits, without those groups having to control the visual ordering.
- **Transformer hooks** — `afterFrontmatter` and `beforeSearchIndex`
  transformers receive `data.group` and `doc.groups`, making it easy to enrich
  or re-route pages based on declared taxonomy.
- **`findUnknownGroups` cross-validation** — when both `nav` and `groups` are
  configured, `resolveDocsNavigation` calls `findUnknownGroups`, which runs the
  `groups`-based membership check in parallel and surfaces any `group` slugs the
  frontmatter declares that are absent from the `groups` tree. Those mismatches
  appear in `navigation.unknown`.

In short: **`nav` owns structure and ordering; `group` owns taxonomy and
metadata tagging.**

---

## 2. What happens at build time if a page declares a `group` slug the config doesn't know about?

The behavior differs depending on whether the site uses the `nav` or `groups`
path.

### When `groups` is the active navigation mode (no `nav`)

Unrecognised slugs are detected inside `buildGroupMembership`, which is called
during every build step that resolves navigation:

```js
// dist/_shared/llm-DbiIv5JE.js – buildGroupMembership
for (const slug of page.groups) {
  const slugKey = slug.toLowerCase();
  if (!known.has(slugKey)) {
    unknown.push({ page, slug });   // ← recorded, not thrown
    continue;
  }
  // … add to the matched group
  matchedAny = true;
}
if (!matchedAny) {
  ungrouped.push(page);             // ← page falls back to ungrouped
}
```

The function does **not** throw. Instead it:

1. Records every `{ page, slug }` pair in the `unknown` array.
2. If a page named *only* unknown slugs (none matched), it moves the page to
   `ungrouped` — the page still appears in the output, just not under any named
   section.
3. Returns the full `{ byGroupSlug, ungrouped, unknown }` object to the caller.

That `unknown` array is then surfaced in the final `DocsNavigation` object:

```ts
// DocsNavigation (readability.d.ts)
unknown: { urlPath: string; slug: string }[];
```

It is written into `agent-readability.json` and is available to any runtime
that calls `resolveDocsNavigation`. The build completes successfully — there is
**no hard error** from an unrecognised `group` slug alone.

### When `nav` is the active navigation mode

The `nav` path never calls `buildGroupMembership` for sidebar construction, so
unknown `group` slugs are completely invisible to the nav build itself.
However, `resolveDocsNavigation` still runs `findUnknownGroups` as a
**side-channel validator** when both `nav` and `groups` are configured:

```js
// resolveDocsNavigation (dist/_shared/llm-DbiIv5JE.js)
if (config.nav && config.nav.length > 0) {
  const resolvedNav = resolveNavGroups(config.nav);
  return buildNavigationFromNav(
    docs,
    resolvedNav,
    tocByUrlPath,
    config.locale ?? …,
    findUnknownGroups(docs, config.groups)  // ← still validated
  );
}
```

`findUnknownGroups` rebuilds the `groups`-based membership and returns the
`unknown` entries. Those are forwarded into `navigation.unknown` in the returned
`DocsNavigation` — again non-fatal, but surfaced for tooling.

If `groups` is not set at all in the config, `findUnknownGroups` receives
`undefined`, returns an empty array immediately, and the unknown slugs are
simply ignored with no warning.

### Summary table

| Config shape | Unknown `group` slug effect |
|---|---|
| `groups` only | Page falls back to `ungrouped`; slug recorded in `navigation.unknown`. Build succeeds. |
| `nav` + `groups` | Sidebar unaffected (nav drives it); slug recorded in `navigation.unknown` via `findUnknownGroups`. Build succeeds. |
| `nav` only (no `groups`) | Completely silent — `findUnknownGroups` returns `[]`. Build succeeds. |

In all cases the build does **not** throw and the page is still included in the
output. The `navigation.unknown` array is the non-fatal signal you can inspect
(or act on in a transformer) to catch stale or misspelled `group` values.
