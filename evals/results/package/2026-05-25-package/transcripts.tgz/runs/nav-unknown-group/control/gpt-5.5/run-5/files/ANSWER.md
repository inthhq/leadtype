# Leadtype navigation: `nav` vs. frontmatter `group`

1. **`nav` is the source of truth when it is present.** The curated `nav` tree in `docs.config.ts` drives the generated sidebar/navigation manifest and the agent-facing maps/artifacts (`AGENTS.md`, `/docs/llms.txt`, agent readability navigation, sitemap-style maps). A page's legacy frontmatter `group` field does **not** place the page in the sidebar when `nav` is configured; `nav.pages` / `nav.children` decide where pages appear, and pages not referenced by `nav` are treated as ungrouped/`Other`.

   The legacy `group` field is still useful as fallback taxonomy/navigation metadata: if you do **not** provide `nav`, Leadtype can build navigation from configured `groups` plus each page's `group` slug(s). It is also preserved as page metadata and can be used for compatibility, filtering, or validation against the configured group taxonomy.

2. **An unknown `group` slug fails generation.** During `leadtype generate`, Leadtype resolves the docs navigation and checks `navigation.unknown`. If a page declares a frontmatter `group` slug that is not present in the configured `groups` tree, generation stops before writing the normal artifacts and reports an error like:

   ```text
   /docs/some-page declares unknown group "missing-slug"
   ```

   In CLI terms, the generate command exits with failure (`1`). With curated `nav`, this validation still applies when a `groups` taxonomy is configured alongside `nav`; if no `groups` taxonomy is configured, `group` frontmatter is just metadata and there is no configured group list to validate it against.
