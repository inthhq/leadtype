# Navigation in this leadtype project

Source of truth for the answers below: the installed `leadtype` package —
mainly `node_modules/leadtype/dist/_shared/llm-DbiIv5JE.js` (the
`resolveDocsNavigation`, `generateAgentsMd`, `generateLlmsTxt`, and
`generateAgentReadabilityArtifacts` implementations) and the build-time
validation in `node_modules/leadtype/dist/cli.js`. Type docs in
`node_modules/leadtype/dist/llm/index.d.ts` say so explicitly:

> Curated navigation for the single-collection shape. When present, this
> drives docs UI and agent-facing indexes; `groups` remains fallback
> taxonomy/navigation metadata.

## 1. Which one drives the sidebar and agent map?

**The curated `nav` in `docs.config.ts` drives both** when it is set. The
legacy `group:` frontmatter is no longer doing the placement work in that
case — leadtype switches renderers based purely on whether `nav` is
present.

You can see the switch in three different generators inside
`llm-DbiIv5JE.js`:

```js
// generateLlmsTxt, generateAgentsMd, generateAgentReadabilityArtifacts
const hasNav = Boolean(config.nav && config.nav.length > 0);
const resolved = hasNav
  ? resolveNavGroups(config.nav ?? [])     // curated tree
  : resolveGroups(config.groups ?? []);    // legacy taxonomy
```

And in `resolveDocsNavigation` (the function the docs UI calls to build
its sidebar manifest):

```js
if (config.nav && config.nav.length > 0) {
  const resolvedNav = resolveNavGroups(config.nav);
  return buildNavigationFromNav(
    docs, resolvedNav, tocByUrlPath, locale,
    findUnknownGroups(docs, config.groups),   // groups only used to validate
  );
}
// ...else fall back to groups + frontmatter membership
const resolved = resolveGroups(config.groups ?? []);
const membership = buildGroupMembership(docs, resolved);
```

So concretely, with `nav` in place:

- **Sidebar / docs UI** — `buildNavigationFromNav` walks the `nav` tree
  and pulls pages in by the explicit `pages: ["…"]` references (or
  `{ include: "…/**" }` globs) under each node. Frontmatter `group:` is
  not consulted for placement. Anything not referenced by `nav` ends up
  in `navigation.ungrouped`.
- **AGENTS.md** — `generateAgentsMd` uses the same nav tree to render
  `## <Group>` sections with relative `./docs/<slug>.md` links. Same
  story: links come from `nav.pages`, not from `group:`.
- **`/docs/llms.txt` and Agent Readability manifest** — also driven by
  `nav` through `renderDocsNavigationSummary` /
  `buildNavigationFromMarkdownDocs(..., 'nav', config.groups)`.

What `group:` frontmatter is still good for, given the type comments and
the `findUnknownGroups(docs, config.groups)` call above:

- **Taxonomy / validation metadata.** `groups` in the config + `group:`
  in frontmatter act as a typed vocabulary that leadtype validates
  against (see Q2). It catches typos and dangling-page mistakes even
  when the sidebar layout is fully controlled by `nav`.
- **Pure fallback.** If you ever delete `nav` from the config, the
  pipeline silently falls back to "render sections from `groups`, place
  each page by its `group:` frontmatter" — no other change needed. So
  `group:` is the safety net.
- **Per-page metadata for downstream consumers.** Each page object in
  the navigation manifest still carries `groups: [...]` (from
  frontmatter), so renderers can surface group badges/chips/filters
  independently of where the page lives in the curated tree.

Rule of thumb when editing docs in this project: to move a page in the
sidebar or AGENTS.md, edit `docs.config.ts`'s `nav`. Editing `group:` in
frontmatter will not move it.

## 2. What happens at build time if a page declares an unknown `group` slug?

**The build fails with a non-zero exit and an error message naming the
page and the bad slug** — as long as `groups` is also declared in the
config (which is the normal setup; the type/validator requires at least
one of `groups` or `nav`).

Mechanically, `runGenerateCommand` in
`node_modules/leadtype/dist/cli.js` does this for every locale before it
writes any output:

```js
const navigation = await resolveDocsNavigation({
  srcDir: sourceMirror.srcDir,
  groups,        // from docs.config.ts
  nav: effectiveNav,
  mounts, i18n, locale,
});
const firstUnknownGroup = navigation.unknown[0];
if (firstUnknownGroup) {
  throw new Error(
    `${firstUnknownGroup.urlPath} declares unknown group "${firstUnknownGroup.slug}"`,
  );
}
```

`navigation.unknown` is populated by `buildGroupMembership` /
`findUnknownGroups`: for each page it iterates the `group:` frontmatter
values, looks each one up in the (case-insensitively flattened) set of
configured group slugs, and pushes `{ page, slug }` into `unknown` for
any miss. Even when `nav` is the active renderer,
`resolveDocsNavigation` still calls
`findUnknownGroups(docs, config.groups)` so the validation runs.

So in practice, when you run `leadtype generate` (or `leadtype lint` —
same validator) you get a failure like:

```
leadtype generate: /docs/quickstart declares unknown group "quikstart"
```

…and no `public/`, `AGENTS.md`, search index, or sitemap is emitted for
that run. Fix it by either:

1. correcting the frontmatter `group:` slug to one declared in
   `docs.config.ts`'s `groups`, or
2. adding the slug to `groups` (and to `nav` if you want it in the
   sidebar).

Two edge cases worth knowing:

- **Multiple slugs per page.** Frontmatter accepts `group: [a, b]`. Each
  slug is checked independently; one unknown slug is enough to fail the
  build. If at least one matches a known group, the page still lands
  under that group in the legacy fallback renderer, but the build still
  errors on the unknown sibling.
- **No `groups` in the config at all (nav-only setup).**
  `findUnknownGroups` short-circuits to `[]` when `groups` is missing or
  empty, so unknown `group:` slugs are silently ignored. If you want
  typo protection in a nav-only project, keep a `groups` list as your
  taxonomy even though it isn't driving the sidebar.
