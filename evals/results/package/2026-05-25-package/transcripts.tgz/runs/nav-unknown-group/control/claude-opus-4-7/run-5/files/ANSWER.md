# Navigation in leadtype: `nav` vs page `group` frontmatter

Short version: the curated `nav` in `docs.config.ts` is the source of truth for
the sidebar and agent map whenever it's present. The legacy `group:` field on a
page is still parsed, but it now plays a supporting role — it's the fallback
taxonomy used when `nav` is absent, and it's also what the build cross-checks
against the config to catch typos.

## 1. Which one drives the sidebar and agent map?

The curated `nav` tree in `docs.config.ts` does. Every leadtype generator
(`generateLlmsTxt`, `generateLLMFullContextFiles`, `generateAgentReadabilityArtifacts`,
`generateAgentsMd`, and `resolveDocsNavigation`) accepts both `groups` and
`nav`, and the type declarations spell out the precedence consistently:

> `Curated navigation tree. Preferred over groups when present.`
> — `node_modules/leadtype/dist/llm/index.d.ts`

And on `DocsConfig.nav` itself:

> `When present, this drives docs UI and agent-facing indexes; groups remains
> fallback taxonomy/navigation metadata.`

So in a project that defines `nav`, the docs sidebar, the `/docs/llms.txt`
section ordering, the sitemap groupings, and the `AGENTS.md` table of contents
are all built from `nav`. Frontmatter `group:` values still populate the
`SourceDoc.groups` array on each page (useful for filters, badges, search
facets, or any custom rendering of your own), but they no longer determine the
order or shape of the navigation tree when `nav` exists.

What `group:` is still good for, even with `nav` present:

- **Taxonomy / metadata on each page.** `SourceDoc.groups` (a normalized
  `string[]`) stays available on every page record so your UI can show a "group"
  tag, filter search results, etc.
- **Fallback navigation** when a config omits `nav` and only defines `groups`
  (the older single-collection shape).
- **Build-time validation.** Pages are bucketed against the configured `groups`
  list to detect slugs that aren't declared anywhere — see question 2.

If you're using `collections`, the same precedence applies per collection
(`DocsCollection.nav` wins over `DocsCollection.groups`).

## 2. What happens at build time when a page declares an unknown `group` slug?

The build fails. During `leadtype generate`, the CLI calls
`resolveDocsNavigation(...)` for each locale and inspects the returned
`navigation.unknown` array — pages whose declared `group:` slug doesn't match
any group declared in the config:

```js
// node_modules/leadtype/dist/cli.js
const navigation = await resolveDocsNavigation({ srcDir, groups, nav: effectiveNav, ... });
const firstUnknownGroup = navigation.unknown[0];
if (firstUnknownGroup) {
  throw new Error(
    `${firstUnknownGroup.urlPath} declares unknown group "${firstUnknownGroup.slug}"`
  );
}
```

That throw is caught by the CLI's `reportFailure` path and `leadtype generate`
exits with code `1`, printing a message like:

```
leadtype generate: /docs/some/page declares unknown group "typoed-slug"
```

So even though `nav` is what actually drives the rendered sidebar/agent map,
the `group:` frontmatter field is still validated against the configured group
list (top-level `groups`, or merged across `collections`). A typo, a renamed
group, or a page that belongs to no declared group is a hard error, not a
warning.

A couple of useful nuances from the CLI source:

- If the config didn't declare any `groups` at all (or you're using
  `collections` without `groups`), leadtype calls `inferGroups()` to read every
  page's frontmatter and synthesize the group list. In that mode an "unknown"
  slug is essentially impossible — every declared slug becomes a known group.
- Pages with **no** `group:` at all aren't unknown; they show up in
  `navigation.ungrouped` and are allowed.
- `navigation.unknown` is also exposed on the runtime
  `DocsNavigation` type (`leadtype/llm` / `leadtype/llm/readability`), so if you
  build your own checker or sidebar you can surface the same diagnostic in
  development tooling.

### TL;DR

| Concern                              | Source                                          |
| ------------------------------------ | ----------------------------------------------- |
| Sidebar order & structure            | `nav` (falls back to `groups` if `nav` absent)  |
| Agent map / `llms.txt` sections      | `nav` (falls back to `groups` if `nav` absent)  |
| Per-page taxonomy tag / filter       | Page frontmatter `group:` → `SourceDoc.groups`  |
| Catching typoed/renamed group slugs  | Page `group:` validated against config `groups` |
| Unknown group at build time          | `leadtype generate` throws and exits non-zero   |
