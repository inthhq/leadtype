# Navigation in Leadtype: `nav` Config vs. `group` Frontmatter

## Question 1: Relationship between `nav` and `group` frontmatter

### The Core Relationship

**`nav` (curated navigation config) drives the sidebar and agent map. `group` frontmatter is a legacy fallback.**

From the `leadtype/llm` type definitions:

```typescript
// In DocsConfig:
/** 
 * Curated navigation for the single-collection shape. When present, this
 * drives docs UI and agent-facing indexes; `groups` remains fallback
 * taxonomy/navigation metadata.
 */
nav?: DocsNavNode[];
```

### What `nav` Does (Primary)

When you declare a curated `nav` tree in `docs.config.ts`:
- It **drives the sidebar UI** — the navigation structure your users see
- It **drives the agent map** — how `AGENTS.md`, `llms.txt`, and agent readability artifacts structure the documentation
- It provides explicit, ordered sections and hierarchical grouping
- Pages are explicitly listed in the tree via `pages` arrays (glob patterns or specific paths)
- This is the **preferred modern approach**

### What `group` Frontmatter Does (Secondary/Legacy)

Each page's `group` frontmatter field (a string or array of strings):
```yaml
---
group: getting-started
group: [getting-started, quickstart]  # Can belong to multiple groups
---
```

When **no `nav` is configured**:
- Pages are automatically organized by their declared groups
- `groups` (the taxonomy tree) provides the structure
- This is a **fallback, filesystem-driven approach** suitable for simple docs

When **`nav` is configured** (preferred):
- The `group` field is still parsed and available in page metadata (`page.groups`)
- But it **does not drive the sidebar or agent map**
- It remains useful for **metadata and filtering** — some frameworks may use it for tagging, analytics, or runtime filtering
- The field prevents errors; it's just not used for navigation

### Summary

| Aspect | `nav` (Curated) | `group` (Legacy Frontmatter) |
|--------|---|---|
| **Drives sidebar** | ✅ Yes (when present) | ❌ No (if `nav` exists) |
| **Drives agent map** | ✅ Yes (when present) | ❌ No (if `nav` exists) |
| **Controls page order** | ✅ Explicit via tree | ❌ Via `order:` frontmatter or alphabetically |
| **Hierarchical** | ✅ Full tree nesting | ❌ Flat taxonomy with `children` groups |
| **Use when** | Modern multi-level sites | Simple flat docs or fallback when no `nav` |
| **Still good for** | Everything | Metadata, filtering, secondary classification |

---

## Question 2: Build-time behavior for unknown `group` slugs

### The Behavior

**If a page declares a `group` slug that the config doesn't know about, leadtype does NOT error or fail at build time by default.** The unknown group is silently accepted.

### Why?

1. **The frontmatter schema is permissive**: The default `group` field accepts any string or array of strings — there is no built-in validation against a known list.

```typescript
// From defaultFrontmatterSchema:
readonly group: v.OptionalSchema<v.UnionSchema<[
  v.StringSchema<undefined>, 
  v.ArraySchema<v.StringSchema<undefined>, undefined>
], undefined>, undefined>;
```

2. **Decoupling frontmatter from config**: Leadtype allows pages to declare groups independently of whether the config uses:
   - A `groups` taxonomy (which would validate membership)
   - A `nav` tree (which doesn't validate groups at all)
   - Neither (pages are just ungrouped or auto-organized)

3. **The unknown group is preserved in metadata**: The page's `groups` array will contain the unknown slug, making it available to:
   - Custom remark transformers/lint rules
   - Frameworks that want to validate or warn about unknown groups
   - Runtime filtering or metadata purposes

### How to Catch Unknown Groups (If Desired)

If you want to **enforce** that all declared groups must exist in your config, use the `lintDocs` function from `leadtype/lint`:

```typescript
import { lintDocs } from 'leadtype/lint';

const result = await lintDocs({ srcDir: './docs' });
```

This validates frontmatter structure but **does not validate group membership** by default. To add that validation, create a custom schema or transformer:

```typescript
// In docs.config.ts transformers
transformers: [
  {
    validatePage(page) {
      const allowedGroups = new Set(config.groups?.map(g => g.slug) ?? []);
      for (const group of page.frontmatter.groups ?? []) {
        if (!allowedGroups.has(group)) {
          throw new Error(`Unknown group "${group}" in ${page.relativePath}`);
        }
      }
    }
  }
]
```

### Summary

| Scenario | Build Behavior |
|----------|---|
| **Page has unknown `group`, config has `nav`** | ✅ Builds successfully; `group` is preserved in metadata but not used for navigation |
| **Page has unknown `group`, config has `groups` taxonomy** | ✅ Builds successfully; unknown groups don't break navigation (pages aren't rendered in any group section unless explicitly included) |
| **Page has unknown `group`, config has neither** | ✅ Builds successfully; page is ungrouped |
| **Want to enforce validation** | Use custom lint rules or transformers; default `lintDocs()` doesn't validate group membership |

The design prioritizes **flexibility and forward-compatibility** over strict validation, allowing docs to evolve without breaking the build if frontmatter gets ahead of config changes.
