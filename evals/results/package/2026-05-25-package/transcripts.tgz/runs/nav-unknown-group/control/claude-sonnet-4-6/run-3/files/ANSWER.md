# Navigation: `nav` vs `group` frontmatter

## 1. Which drives the sidebar and agent map, and what is the other good for?

### The curated `nav` in `docs.config.ts` is the authoritative driver

When a `nav` array is present (and non-empty) in `docs.config.ts`, it becomes
the **sole source of truth** for every generated navigation artifact:

- the sidebar tree consumed by `resolveDocsNavigation` / `createDocsSource`
- the structured groups inside `agent-readability.json`
- the section structure of `AGENTS.md`
- the ordered sections of `docs/llms.txt`
- the page order of `llms-full.txt`

This is enforced uniformly throughout the build pipeline. Every major function
that produces navigation checks the same flag before branching:

```js
// from _shared/llm-DbiIv5JE.js (resolveDocsNavigation, generateAgentsMd,
// generateLlmsTxt, generateAgentReadabilityArtifacts, …)
const hasNav = Boolean(config.nav && config.nav.length > 0);
const resolved = hasNav
  ? resolveNavGroups(config.nav ?? [])   // ← nav wins
  : resolveGroups(config.groups ?? []);  // ← groups fallback
```

When `nav` is used, pages are placed in the tree by **explicit path entries**
(literal relative paths or `include:` glob patterns) declared directly in the
`nav` nodes — not by scanning frontmatter. Any page not referenced by any
`nav` node ends up in `ungrouped`.

### The legacy `group` frontmatter field is still good for taxonomy and
search metadata

The `group` field (a string or string array, e.g. `group: reference` or
`group: [sdk, reference]`) is read from every page's frontmatter and is
preserved on the `SourceDoc` / `DocsPageMeta` object as the `groups: string[]`
array. Even while `nav` is driving navigation, `group` continues to serve
several purposes:

1. **Unknown-group detection / cross-validation.** When `nav` is the primary
   driver but a legacy `groups` array is *also* declared in the config,
   `findUnknownGroups` is called to compare each page's `group` slugs against
   the known `groups` tree. The results surface in the `navigation.unknown`
   list, which is available at runtime for tooling, dashboards, or lint
   pipelines.

2. **Runtime page metadata.** `groups` is included in the `DocsPageMeta` type
   returned by `listPages()` and `loadPage()`, so UI code and custom
   transformers can read it for badge rendering, filtering, or analytics without
   touching the nav tree.

3. **Search index documents.** Each `DocsSearchDocument` carries the resolved
   `groups` value, so search results can surface or filter by group even when
   the sidebar is `nav`-driven.

4. **Gradual migration path.** Sites migrating from the legacy `groups`-only
   model to a curated `nav` can keep `group:` in frontmatter during the
   transition. The old behavior (sidebar driven by `group` slug matching) is
   preserved automatically whenever `nav` is absent or empty.

---

## 2. What happens at build time when a page declares a `group` slug the config doesn't know about?

The answer depends on **which navigation mode is active**:

### Mode A — `groups`-only (no `nav` in config)

The pipeline calls `buildGroupMembership(pages, resolvedGroups)`. This function
iterates over every page's `groups` array and looks each slug up in the
flattened, case-insensitive map of known groups:

```js
// from _shared/llm-DbiIv5JE.js — buildGroupMembership
for (const slug of page.groups) {
  const slugKey = slug.toLowerCase();
  if (!known.has(slugKey)) {
    unknown.push({ page, slug });   // ← recorded
    continue;                       // ← NOT added to any group
  }
  // ... add to byGroupSlug
}
if (!matchedAny) {
  ungrouped.push(page);             // ← falls back to "Other"
}
```

Concretely:
- The unrecognized slug is **silently recorded** — no exception is thrown.
- The page is treated as if it were ungrouped and appears in the `ungrouped`
  bucket (rendered as the "Other" section in `llms.txt` and `AGENTS.md`).
- The unrecognised entries are surfaced in `navigation.unknown` as
  `{ urlPath, slug }` objects so build scripts or lint passes can detect and
  report them.

### Mode B — `nav` is present (curated tree)

Navigation membership is determined entirely by whether a page is referenced
by a `nav` node's `pages` list. The page's frontmatter `group` field has **no
effect** on placement. If the page isn't referenced in any `nav` node, it goes
to `ungrouped` regardless of what `group:` says.

However, if a `groups` array is *also* declared in the config alongside `nav`,
the pipeline calls `findUnknownGroups` to run the same `buildGroupMembership`
check against that `groups` tree and attaches the results to
`navigation.unknown`. So unknown slugs in frontmatter are still **detectable**
at build time — they just don't crash the build.

### Summary table

| Scenario | Page placement | Unknown slug surfaced in `navigation.unknown`? | Build error? |
|---|---|---|---|
| `groups`-only mode, slug matches | Correct group | No | No |
| `groups`-only mode, slug unknown | Falls to `ungrouped` ("Other") | **Yes** | No |
| `nav` mode, page referenced in `nav` | Correct nav position | N/A | No |
| `nav` mode, page not in `nav` | Falls to `ungrouped` | **Yes** (if `groups` also declared) | No |

In all cases the build **completes without throwing**. The unrecognised slug is
captured in `navigation.unknown` for downstream tooling (lint reporters, CI
checks, custom transformers) to act on, but the pipeline itself treats it as a
soft, non-fatal condition.
