# Navigation and legacy groups in leadtype

1. In a `docs.config.ts` that defines curated `nav`, `nav` is the authoritative navigation tree. It drives the generated sidebar/navigation manifest and the agent-facing docs maps such as `docs/llms.txt`, `AGENTS.md`, and the agent-readability sitemap/navigation. A page's frontmatter `group` field is legacy/fallback taxonomy metadata: it is still read and preserved on page metadata, useful for migration/backward compatibility, validation, custom filtering/grouping, and as the fallback navigation mechanism when no curated `nav` is present.

2. During `leadtype generate`, leadtype resolves the docs navigation before writing artifacts. If a page declares a `group` slug that is not present in the configured `groups` catalog, generation fails with an error like:

   ```text
   /docs/some-page declares unknown group "some-slug"
   ```

   In other words, unknown legacy group slugs are treated as build-time configuration/content errors rather than silently creating a new sidebar section. In curated-`nav` projects, this validation depends on keeping a `groups` catalog for the legacy `group` field; `nav` still decides where pages appear.
