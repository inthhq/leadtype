# Navigation in leadtype: `nav` vs. `group`

## 1. What drives the sidebar / agent map?

Two things in leadtype describe navigation, and they are **not** equals:

- **`nav` in `docs.config.ts`** — an *author-curated tree* of `DocsNavNode`s
  (`title`, `slug`, `description`, `base`, `pages`, `children`). It is the
  hand-written sidebar.
- **`group:` in MDX frontmatter** — a per-page slug (or array of slugs) that
  tags a page with one or more **groups** (`DocsGroup` entries declared under
  `groups` in `docs.config.ts`).

### `nav` is the primary driver when present

Every place that builds a sidebar or agent-facing map accepts both, and the
type declarations are explicit that **`nav` wins**. From
`node_modules/leadtype/dist/llm/index.d.ts`:

```ts
type LlmsTxtConfig = {
  …
  /** Group tree from `docs.config.ts`. Used for `/docs/llms.txt` sections. */
  groups?: DocsGroup[];
  /** Curated navigation tree. Preferred over `groups` when present. */
  nav?: DocsNavNode[];
};

type AgentsMdConfig = {
  …
  /** Group tree from `docs.config.ts`. Drives section structure. */
  groups?: DocsGroup[];
  /** Curated navigation tree. Preferred over `groups` when present. */
  nav?: DocsNavNode[];
};
```

The same "preferred over `groups` when present" comment is repeated on
`LLMFullContextConfig`, `AgentReadabilityConfig`, and
`ResolveDocsNavigationConfig`. The top-level `DocsConfig` says it most
directly:

> Curated navigation for the single-collection shape. When present, this
> drives docs UI and agent-facing indexes; `groups` remains fallback
> taxonomy/navigation metadata.

So:

| Artifact                                  | Driven by                                      |
|-------------------------------------------|------------------------------------------------|
| Docs UI sidebar                           | `nav` (falls back to `groups`)                 |
| `AGENTS.md` (bundle mode)                 | `nav` (falls back to `groups`)                 |
| `/docs/llms.txt` curated map              | `nav` (falls back to `groups`)                 |
| `/llms-full.txt` ordering                 | `nav` (falls back to `groups`)                 |
| Agent-readability sitemap & manifest      | `nav` (falls back to `groups`)                 |
| `resolveDocsNavigation()` output          | `nav` (falls back to `groups`)                 |

### What is `group:` still good for?

Even when `nav` is the source of truth for the sidebar and agent maps, the
page's frontmatter `group:` slug is far from dead. It is the **taxonomy /
categorization signal** for each page:

- It's normalized into `SourceDoc.groups: string[]` (see `index.d.ts`), which
  is surfaced on every page record the pipeline emits — `MarkdownDoc`,
  `DocsNavigationPage`, and the agent-readability `AgentReadabilityPage`
  (`readability.d.ts`).
- It feeds the `groups`/`ungrouped`/`unknown` buckets returned by
  `resolveDocsNavigation()` and is what the build uses to validate that every
  page belongs to a known group (see #2 below).
- It is the fallback that the same artifacts fall back to when `nav` is
  omitted (single-source shape: `groups` then becomes the navigation tree).
- It carries through the build (CLI, lint, search ingestion) so consumers and
  search can filter / facet by group even though the sidebar layout is
  controlled by `nav`.

Short version: **`nav` controls *layout and order*; `group:` controls
*taxonomy and validation*.** A page's `group:` slug still has to resolve to a
real group declared in the config — but where that page appears in the
sidebar is decided by `nav`.

## 2. What happens at build if `group:` references an unknown slug?

The build **fails hard** for that page.

`leadtype generate` calls `resolveDocsNavigation(...)`, which returns a
`DocsNavigation` object that includes:

```ts
type DocsNavigation = {
  groups: DocsNavigationGroup[];
  ungrouped: DocsNavigationPage[];
  /** Pages that named a group slug not present in the config. */
  unknown: { urlPath: string; slug: string }[];
  locale?: string;
};
```

In `node_modules/leadtype/dist/cli.js`, immediately after resolving navigation
for each locale, the CLI does:

```js
const navigation = await resolveDocsNavigation({ … });
const firstUnknownGroup = navigation.unknown[0];
if (firstUnknownGroup) {
  throw new Error(
    `${firstUnknownGroup.urlPath} declares unknown group "${firstUnknownGroup.slug}"`
  );
}
```

That thrown error is caught by `runGenerateCommand`'s top-level handler,
which calls `reportFailure(message)` and returns exit code **1** — i.e.:

- In `text` mode you'll see something like
  `leadtype generate: /docs/some-page declares unknown group "foo"` on stderr.
- In `--json` mode it's emitted as a `generate.fail` log event with
  `error: "<page> declares unknown group \"foo\""`.
- No artifacts (`AGENTS.md`, `llms.txt`, `llms-full.txt`, search index,
  agent-readability manifest, sitemaps) are written.

A few useful nuances:

- The check runs **per-locale** when i18n is configured, so an unknown slug
  in any locale's copy fails the whole build.
- It only reports the **first** unknown reference; fix it, re-run, repeat to
  find the rest.
- If you didn't have a config file at all, the CLI calls `inferGroups()` —
  it derives the group list from the union of `group:` slugs in your MDX, so
  in that mode "unknown group" is effectively impossible (every observed slug
  is registered). The "unknown group" failure is the safety net specifically
  for the case where you *do* curate a `groups` list in `docs.config.ts` and a
  page drifts away from it.
- The check is on `groups`, not `nav`: pages that exist on disk but aren't
  listed in `nav` don't fail this check — they simply don't appear in the
  curated sidebar (they fall into `ungrouped` for fallback consumers). The
  hard failure is specifically about a `group:` slug that the config's
  `groups` (or merged collection `groups`) doesn't know about.
