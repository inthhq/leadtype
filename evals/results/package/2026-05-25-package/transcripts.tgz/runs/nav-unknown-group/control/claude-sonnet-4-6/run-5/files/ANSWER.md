# Navigation: `nav` vs `group` frontmatter

## 1. Which one drives the sidebar and agent map, and what is the other still good for?

### The curated `nav` in `docs.config.ts` — the authoritative driver

When a `nav` array is present and non-empty in `docs.config.ts` (or in a
collection config), **`nav` is the single source of truth for every
navigation-consuming output**: the sidebar tree returned by
`resolveDocsNavigation()`, the `llms.txt` docs section, `llms-full.txt` page
ordering, `AGENTS.md`, and the `agent-readability.json` manifest.

The pipeline detects this with a simple flag:

```js
// from _shared/llm-DbiIv5JE.js
const hasNav = Boolean(config.nav && config.nav.length > 0);
const resolved = hasNav
  ? resolveNavGroups(config.nav ?? [])   // nav path — explicit, curated
  : resolveGroups(config.groups ?? []);  // groups path — frontmatter-driven
```

When `hasNav` is `true` the pipeline calls `buildNavigationFromNav()`, which
walks the explicit `nav` tree and resolves each `pages` entry (a path string or
an `include` glob) against the filesystem. The resulting navigation object is
**structure-first**: the config author decides the order, depth, and grouping
of every section. Pages not referenced anywhere in the tree end up in
`navigation.ungrouped`.

### The legacy `group` frontmatter field — taxonomy and fallback

A page's `group: <slug>` (or `group: [a, b]`) frontmatter field is parsed by
`readSourceDocs()` into a `groups: string[]` array on every `SourceDoc`. When
`nav` is **not** configured, the pipeline calls `buildGroupMembership()` to
scatter pages into the groups declared in the `groups` array in the config —
the fallback, frontmatter-driven mode.

When `nav` **is** configured, `group` values are no longer used to build the
sidebar or agent map. They are still:

1. **Preserved on `SourceDoc` / `DocsPageMeta`** — the `groups` array is
   carried through to every resolved page view and into the
   `agent-readability.json` `pages` list, so downstream consumers (custom
   renderers, search transformers, analytics) can still read a page's semantic
   category.
2. **Validated for unknown-group warnings** — when `nav` is active but
   `groups` is also supplied in the config, `findUnknownGroups()` compares
   each page's `group` slugs against the `groups` tree and surfaces any
   mismatches in `navigation.unknown` (see below).
3. **Available as an authoring convention** — teams often use `group` as a
   lightweight tag even when `nav` controls rendering, e.g. to drive custom
   UI badges or content filters.

**In short:** `nav` drives the sidebar and agent map; `group` is taxonomy
metadata that survives as a per-page property and feeds the legacy fallback
path and the unknown-group diagnostic.

---

## 2. What happens at build time if a page declares a `group` slug the config doesn't know about?

The behaviour differs depending on which mode is active, but in neither case
does leadtype throw a hard error or refuse to build.

### When `nav` is active (primary mode)

`resolveDocsNavigation()` (and `generateAgentReadabilityArtifacts()`) call
`findUnknownGroups()` alongside nav resolution:

```js
// _shared/llm-DbiIv5JE.js — resolveDocsNavigation
return buildNavigationFromNav(
  docs,
  resolvedNav,
  tocByUrlPath,
  config.locale ?? ...,
  findUnknownGroups(docs, config.groups)  // ← unknown slugs reported here
);
```

`findUnknownGroups()` runs `buildGroupMembership()` against the `groups` tree
(if one is provided) and collects every `{ urlPath, slug }` pair where the
frontmatter slug does not match any known group. These pairs are returned as
`navigation.unknown` — a plain array on the `DocsNavigation` object. The build
continues normally; the unknown slugs are surfaced as **data for callers to
inspect or log**, not as exceptions.

If no `groups` array is provided alongside `nav`, `findUnknownGroups` receives
`undefined` and returns `[]` immediately — the unknown array stays empty and
no diagnostic is produced at all.

### When only `groups` is active (legacy/fallback mode)

`buildGroupMembership()` is called directly. For every page whose `group`
frontmatter slug does not match any slug in the flattened `groups` tree, the
page is pushed onto the `unknown` list **and also onto `ungrouped`**:

```js
// _shared/llm-DbiIv5JE.js — buildGroupMembership
for (const slug of page.groups) {
  const slugKey = slug.toLowerCase();
  if (!known.has(slugKey)) {
    unknown.push({ page, slug });  // recorded as unknown
    continue;
  }
  // ... placed in the matching group
  matchedAny = true;
}
if (!matchedAny) {
  ungrouped.push(page);  // also falls into "Other" / ungrouped section
}
```

The page is rendered in the **"Other"** section of `llms.txt` /
`AGENTS.md` / the sidebar rather than being dropped. The `navigation.unknown`
array is populated with `{ urlPath, slug }` entries for every offending pair.
Again, no exception is thrown.

### `leadtype lint` — the only place an unknown `group` slug becomes a hard signal

The `lintDocs()` function in `leadtype/lint` validates frontmatter with a
valibot schema. The default schema accepts `group` as `string | string[]`
without checking slugs against the config — so a syntactically valid slug
value passes schema validation. However, if a project passes a **custom
stricter schema** (e.g. a `v.picklist(knownSlugs)`) via
`lintDocs({ schemas: { frontmatter: ... } })`, unknown slugs will be emitted
as `schema` errors. Out of the box, only a syntactically malformed slug (one
that fails the `SLUG_PATTERN` regex `/^[a-z0-9]+(?:-[a-z0-9]+)*$/i`) will
cause `assertValidGroupSlug` to **throw synchronously** during config
resolution — but that check applies to the slugs declared *in the config*, not
to the frontmatter values on pages.

### Summary table

| Situation | What happens to the page | What appears in the output |
|---|---|---|
| `nav` active, page's `group` slug unknown, `groups` also configured | Page placed normally by `nav`; slug recorded | `navigation.unknown[{ urlPath, slug }]`; page rendered per `nav` |
| `nav` active, no `groups` configured | `findUnknownGroups` returns `[]` | Nothing; no diagnostic |
| `groups`-only mode, page's `group` slug unknown | Page moved to `ungrouped` | `navigation.unknown[{ urlPath, slug }]`; page appears under "Other" |
| Either mode, slug malformed (not URL-safe) | **Throws** `Error: Invalid group slug "…"` | Build aborts immediately |
| `leadtype lint` with default schema | `group` value is structurally validated only | No slug-vs-config check unless a custom schema is provided |
