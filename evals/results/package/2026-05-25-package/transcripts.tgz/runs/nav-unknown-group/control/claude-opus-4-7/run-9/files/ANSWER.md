# Navigation in a leadtype project

This answer is based on the installed `leadtype` package
(`node_modules/leadtype/dist/llm/index.d.ts` and the shared implementation in
`node_modules/leadtype/dist/_shared/llm-DbiIv5JE.js`).

## 1. `nav` vs. legacy `group` frontmatter — who drives what?

**The curated `nav` tree in `docs.config.ts` is the source of truth whenever it
is present.** Everywhere the leadtype pipeline picks a navigation strategy, it
runs the same check:

```ts
const hasNav = Boolean(config.nav && config.nav.length > 0);
const resolved = hasNav
    ? resolveNavGroups(config.nav ?? [])      // curated tree wins
    : resolveGroups(config.groups ?? []);     // fall back to frontmatter taxonomy
```

This is used by:

- `resolveDocsNavigation` — the manifest the docs UI sidebar imports.
- `generateAgentsMd` — the bundled `AGENTS.md` agent map.
- `generateLlmsTxt` — `/docs/llms.txt`.
- `generateLLMFullContextFiles` — page ordering inside `llms-full.txt`.
- `generateAgentReadabilityArtifacts` — `sitemap.md`, the manifest, etc.

The `DocsConfig` JSDoc says it explicitly:

> Curated navigation for the single-collection shape. When present, this
> drives docs UI and agent-facing indexes; `groups` remains fallback
> taxonomy/navigation metadata.

So:

- **Sidebar (UI) and agent map (`AGENTS.md`, `llms.txt`, sitemap):** driven by
  the curated `nav` in `docs.config.ts`. Authors do not have to touch
  frontmatter to add a page to the sidebar — they list it (or include-glob it)
  under a `DocsNavNode`. The `base` field cascades down the tree, page entries
  are extensionless relative paths, and `include` globs with `exclude` / `sort`
  / `required` are resolved against the actual docs files.

- **`group:` frontmatter:** still parsed, normalized, and surfaced. In the
  manifest produced by `resolveDocsNavigation`, every `DocsNavigationPage`
  carries a `groups: string[]` field with the page's declared group slugs.
  Likewise `AgentReadabilityPage.groups` and `SourceDoc.groups` in the public
  API expose them. So `group` is still useful as:
  - **Taxonomy / metadata** that ships with each page (filtering, faceting,
    badges, related-page widgets, search facets).
  - **The legacy fallback navigation source** — if `nav` is absent or empty,
    leadtype reverts to `groups` + frontmatter `group:` to build the sidebar
    via `buildGroupMembership` (matching each page's declared slug against the
    flattened `DocsGroup` tree).
  - **Validation signal in the curated path** — even when `nav` is driving
    everything, leadtype still calls `findUnknownGroups(docs, config.groups)`
    and stores the results on the manifest as `navigation.unknown` (see §2).

TL;DR: in a `nav`-driven project, `group` is no longer wiring; it is page
metadata plus a sanity check.

## 2. What happens if a page declares a `group` slug the config doesn't know?

**Nothing fatal at build time — it is reported, not thrown.**

The relevant code paths:

- `buildGroupMembership` (used in the legacy `groups`-driven mode, and called
  through `findUnknownGroups` in the `nav`-driven mode) walks every page's
  declared `group:` slugs. For each slug that doesn't match any
  `DocsGroup.slug` in the (flattened) config tree, it pushes
  `{ page, slug }` onto an `unknown` array. The page also falls through to
  `ungrouped` if **none** of its declared slugs match.

- That `unknown` list is surfaced on the navigation manifest:

  ```ts
  type DocsNavigation = {
      groups: DocsNavigationGroup[];
      ungrouped: DocsNavigationPage[];
      /** Pages that named a group slug not present in the config. */
      unknown: { urlPath: string; slug: string }[];
      locale?: string;
  };
  ```

  This is what `resolveDocsNavigation` returns, what
  `generateAgentReadabilityArtifacts` writes into the agent-readability
  manifest, and what consumers can render or assert against.

- In the `nav`-driven path, `buildNavigationFromMarkdownDocs` /
  `buildNavigationFromNav` still calls `findUnknownGroups(docs, config.groups)`
  and threads its result into `navigation.unknown` — so even when the curated
  tree is in charge, mismatched legacy `group:` slugs are surfaced (they just
  don't affect the sidebar).

- The build does **not** call `throw` for unknown group slugs. The errors that
  *do* throw from the navigation layer are:
  - `Invalid group slug "<slug>" under "<scope>"` — slug fails the URL-safe
    regex.
  - `Duplicate group slug "<slug>" under "<scope>"` / `Duplicate nav slug ...`
    — sibling collision in the config tree.
  - `Group slug "<slug>" appears in multiple collections; group slugs must be
    globally unique across the project.` (multi-collection mode).
  - `Nav page "<entry>" ... did not match a documentation page.` — a curated
    `nav` references a file that doesn't exist.
  - `Nav include "<glob>" ... matched no documentation pages.` — only thrown
    when the include entry is `required: true`; otherwise it logs a warning
    (`nav.include.empty`).

So in practice: a typo'd `group: foobar` in frontmatter will not break the
build. The page will still ship (placed under `ungrouped` in legacy mode, or
wherever `nav` puts it in curated mode), and it will appear in the
`navigation.unknown` array of the generated manifest — useful to log,
display in CI, or fail your own build on if you want stricter behavior.
