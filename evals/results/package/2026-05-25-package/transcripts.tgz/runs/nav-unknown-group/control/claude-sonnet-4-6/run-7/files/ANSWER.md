# Navigation in leadtype: `nav` vs `group` frontmatter

All findings below are traced directly to the leadtype source code installed at
`node_modules/leadtype` (v0.1.2).

---

## 1. Relationship between `nav` and `group`, and which one drives what

### The short answer

| Concern | Driven by |
|---|---|
| **Sidebar order & structure** (what the UI renders) | **`nav`** when present; `groups` otherwise |
| **Agent map** (`AGENTS.md`, `llms.txt`, `agent-readability.json`, `sitemap.md`) | **`nav`** when present; `groups` otherwise |
| **Taxonomy / membership metadata** only | `group` frontmatter (always collected, but only *used* to drive things when `nav` is absent) |

### The long answer

`docs.config.ts` can contain two orthogonal navigation structures:

```ts
// docs.config.ts
export default defineDocsConfig({
  groups: [...],  // ← legacy flat/hierarchical taxonomy
  nav: [...],     // ← curated UI + agent tree
})
```

#### `nav` — the authoritative tree (sidebar + agent map)

`nav` is a fully curated `DocsNavNode[]` tree. Every pipeline function that
produces navigation output checks for `nav` first:

```js
// from _shared/llm-DbiIv5JE.js  (resolveDocsNavigation, generateLlmsTxt,
//                                 generateAgentsMd, generateAgentReadabilityArtifacts)
const hasNav = Boolean(config.nav && config.nav.length > 0);
const resolved = hasNav
  ? resolveNavGroups(config.nav ?? [])   // curated path
  : resolveGroups(config.groups ?? []);  // legacy path
```

When `nav` is present:

- **`resolveDocsNavigation`** calls `buildNavigationFromNav`, which walks each
  `DocsNavNode`'s explicit `pages` / `include` entries to assemble the ordered
  list of pages under each section. The result is the `DocsNavigation` object
  that your sidebar and every agent-facing file is built from.
- **`generateLlmsTxt`** renders `renderDocsNavigationSummary` (nav-aware
  renderer) instead of `renderDocsSummary` (group-membership renderer).
- **`generateAgentsMd`** and **`generateAgentReadabilityArtifacts`** likewise
  branch on `hasNav` and call the nav-based builders.

`nav` nodes use a `base` path that cascades to descendants, and page entries
can be exact relative paths (`"quickstart"`) or glob-include objects
(`{ include: "reference/**" }`). The ordering of pages in the sidebar is
exactly the ordering in `nav` — not derived from frontmatter at all.

#### `group` frontmatter — legacy taxonomy metadata

`group` (a string or array of strings in each page's YAML front matter) is how
pages *self-report* which group they belong to. The pipeline always reads and
normalises it:

```js
// readSourceDocs / readMarkdownDocs in llm-DbiIv5JE.js
const groups = normalizeGroupValue(parsed.data.group);
// → stored on every SourceDoc / MarkdownDoc as `.groups: string[]`
```

But this data is only *acted upon* to build navigation when `nav` is **absent**.
Without `nav`, `buildGroupMembership` iterates all pages and slots each one
into the group whose `slug` matches the page's `group` frontmatter value. That
membership map then drives the sidebar sections, `llms.txt` sections, and the
agent map.

When `nav` **is** present, `group` frontmatter:

- Is still parsed and stored on every `DocsNavigationPage` / `AgentReadabilityPage`
  as `.groups: string[]`, so UI components and consumers can read it.
- Is forwarded into `findUnknownGroups` (see question 2 below) as a *validation
  input* when `config.groups` is also provided alongside `nav`.
- Plays **no role** in deciding which section a page appears in or in what
  order — that is entirely controlled by the curated `nav` tree.

#### Summary

`nav` drives the sidebar and all agent-readable indexes. `group` frontmatter is
useful legacy metadata — it keeps pages machine-tagged for consumers that read
`.groups` from the navigation manifest (e.g. a custom filter UI, or a
transformer hook), and it doubles as the fallback navigation mechanism when
`nav` is omitted.

---

## 2. What happens at build time when a page declares an unknown `group` slug

### When `nav` is absent (pure `groups`-based navigation)

The function `buildGroupMembership` is called. It flattens the configured
`groups` tree into a `Map<slugKey, ResolvedGroup>` and then iterates every page:

```js
// llm-DbiIv5JE.js — buildGroupMembership
for (const slug of page.groups) {
  const slugKey = slug.toLowerCase();
  if (!known.has(slugKey)) {
    unknown.push({ page, slug });   // ← recorded, NOT thrown
    continue;
  }
  // ... add to byGroupSlug
}
if (!matchedAny) {
  ungrouped.push(page);            // ← page falls into ungrouped
}
```

**The page is not dropped and no exception is thrown.** Instead:

1. The `(page, slug)` pair is pushed onto the `unknown` array.
2. Because no known group matched, the page is also added to `ungrouped`.
3. The returned `DocsNavigation` object carries:
   ```ts
   {
     groups: [...],         // sections with the known groups
     ungrouped: [...],      // pages with no matching group (incl. unknown-group pages)
     unknown: [             // the problematic slugs, surfaced for inspection
       { urlPath: "/docs/some-page", slug: "nonexistent-group" },
       ...
     ]
   }
   ```
4. The page appears under **"Other"** / ungrouped in the sidebar and in
   `llms.txt` / `AGENTS.md` — it is not silently lost.

The `unknown` array is part of the public `DocsNavigation` type, so your docs
shell can detect and surface those mismatches at runtime or in a build script.

### When `nav` is present

`buildNavigationFromNav` is used, and page `group` frontmatter does **not** drive
placement at all (the curated tree owns that). However, `resolveDocsNavigation`
still calls `findUnknownGroups` as a supplementary check when `config.groups` is
also provided:

```js
// resolveDocsNavigation in llm-DbiIv5JE.js
return buildNavigationFromNav(
  docs,
  resolvedNav,
  tocByUrlPath,
  config.locale,
  findUnknownGroups(docs, config.groups)  // ← validation only, result stored in .unknown
);
```

`findUnknownGroups` runs `buildGroupMembership` against the `groups` tree and
returns the same `{ urlPath, slug }` records. They are stored in `navigation.unknown`
for inspection but cause **no error and no build failure**.

### What `leadtype lint` checks (and does NOT check)

`lintDocs` (`runner-LBfgMZ36.js`) validates every page's frontmatter against
`defaultFrontmatterSchema`. That schema accepts `group` as
`optional(union([string(), array(string())]))` — any string is structurally
valid. The linter does **not** cross-reference `group` values against the
configured `groups` slugs; that cross-check is only done inside the navigation
builder at generation time, and even then it only records the mismatches in
`navigation.unknown` rather than exiting with a non-zero code.

### Practical consequence

An unknown `group` slug is a **silent demotion, not a fatal error**:

- The page ends up in the "Other / ungrouped" bucket in every output.
- The `navigation.unknown` array records the bad slug so a build script or
  transformer can detect and report it.
- If you want hard failures, consume `navigation.unknown` in a post-build step
  and exit non-zero when it is non-empty.
