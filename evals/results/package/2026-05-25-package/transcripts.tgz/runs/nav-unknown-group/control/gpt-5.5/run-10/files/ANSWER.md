# Navigation in leadtype

1. The curated `nav` in `docs.config.ts` is preferred. When `nav` is present, it drives the rendered/navigation manifest used by the docs sidebar and the agent-facing maps/indexes (`llms.txt`, `AGENTS.md`, agent readability sitemap/manifest). A page's legacy `group` frontmatter does **not** place the page in the sidebar when curated `nav` is in use.

   The `group` field is still useful as fallback taxonomy/navigation metadata: if you do not define `nav`, leadtype can build navigation from configured `groups` plus each page's `group` frontmatter. It is also preserved on page metadata for consumers that want to filter or tag pages by group, and configured `groups` can still be used to validate legacy group declarations.

2. During `leadtype generate`, leadtype resolves navigation before writing artifacts and checks for unknown group declarations. If a page declares a `group` slug that is not present in the configured `groups` tree, the build fails with an error like:

   ```text
   /docs/some-page declares unknown group "missing-slug"
   ```

   With curated `nav`, page placement still comes from `nav`; unknown-group checking only has something to compare against when you also configure `groups` as the legacy/fallback taxonomy.