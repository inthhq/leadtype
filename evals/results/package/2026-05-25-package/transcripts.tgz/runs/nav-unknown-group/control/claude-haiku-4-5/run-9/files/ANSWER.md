# Navigation in Leadtype: `nav` Config vs Frontmatter `group`

## Question 1: Relationship Between `nav` Config and Frontmatter `group`

### Which one drives the sidebar and agent map?

**The curated `nav` in `docs.config.ts` drives both the sidebar and agent map.**

When a curated `nav` is present in your docs config, it takes precedence over the legacy `groups` system. The `nav` is an author-facing curated navigation tree that explicitly defines the structure and content of docs UI and agent-readable indexes. This is the primary navigation source and fully controls what appears in:
- The sidebar (or docs navigation UI)
- Agent-facing artifacts like `/llms.txt`, `/docs/llms.txt`, and `AGENTS.md`
- The navigation manifest returned by `resolveDocsNavigation()`

### What is the legacy `group` frontmatter field still good for?

**The legacy `group` frontmatter field is a fallback taxonomy and metadata tag.**

When `nav` is absent, pages use their `group:` frontmatter to self-identify which group they belong to. This creates a flat taxonomy structure. The `group` field (which can be a string or array of strings) has two remaining uses:

1. **Ungrouped fallback**: When no curated `nav` is configured, `group:` drives the navigation structure by default.
2. **Metadata tagging**: Even when `nav` is present, the `group:` field is still parsed and preserved in the `DocsNavigation` output as `groups: string[]` on each page. This allows consumers to:
   - Tag pages with logical categories for custom rendering
   - Query "what groups does this page belong to?" independently of the curated navigation
   - Maintain backward compatibility with legacy systems that expect group metadata

**In summary**: `nav` is the modern, curated approach (explicit structure); `group` is the legacy, declarative approach (pages self-identify their categories).

---

## Question 2: What Happens at Build Time for Unknown Group Slugs?

### If a page declares a `group` slug that the config doesn't know about:

**The page is added to the `unknown` array in `DocsNavigation`.**

When `resolveDocsNavigation()` processes the docs tree and encounters a page with a `group:` frontmatter that references a slug not present in the configured `groups` or `nav` tree, the page does **not cause an error**. Instead:

1. The page is silently added to the `DocsNavigation.unknown` array as an entry with:
   - `urlPath`: the page's canonical route (e.g., `/docs/quickstart`)
   - `slug`: the unknown group slug that was declared

2. The page is **also added to the `ungrouped` array** in the navigation output, making it visible to the docs UI and agents.

3. **No build failure occurs** — this is a graceful degradation, not a hard error.

### Example from the type definitions:

```typescript
type DocsNavigation = {
  groups: DocsNavigationGroup[];
  ungrouped: DocsNavigationPage[];
  /** Pages that named a group slug not present in the config. */
  unknown: {
    urlPath: string;
    slug: string;
  }[];
  locale?: string;
};
```

This design allows:
- **Incremental migration**: You can introduce a curated `nav` without immediately updating all page frontmatter.
- **Debugging**: The `unknown` array acts as a lint warning list so you can identify pages with stale or typo'd group slugs.
- **Graceful fallback**: Pages remain discoverable (under `ungrouped`) even if their declared group doesn't exist in the config.

If you want stricter validation, use the `leadtype lint` command (see `leadtype/lint` entry point) to catch unknown group slugs at development time.
