# Navigation in leadtype: `nav` vs. page `group` frontmatter

Short version: when `docs.config.ts` exports a non-empty `nav`, **`nav` is the
single source of truth** for the sidebar, `AGENTS.md`, `docs/llms.txt`, and the
agent-readability manifest. The page-level `group:` frontmatter is *not* what
the docs UI reads when `nav` is present — it stays useful only as
taxonomy/metadata (per-page labels, search facets, your own consumers) and as
the fallback grouping when neither `nav` nor a curated `groups` tree is in
charge.

The evidence below is from the installed package
(`node_modules/leadtype@<version>`); the line references are to the bundled
dist so you can verify them as you onboard.

## 1. Which one drives the sidebar and the agent map?

### `nav` wins whenever it's present

The type definition in `node_modules/leadtype/dist/llm/index.d.ts` is explicit:

```ts
/**
 * Curated navigation for the single-collection shape. When present, this
 * drives docs UI and agent-facing indexes; `groups` remains fallback
 * taxonomy/navigation metadata.
 */
nav?: DocsNavNode[];
```

The same "Curated navigation tree. Preferred over `groups` when present."
comment is repeated on every config that takes a nav tree —
`LlmsTxtConfig`, `LLMFullContextConfig`, `AgentReadabilityConfig`,
`AgentsMdConfig`, and `ResolveDocsNavigationConfig`.

The runtime confirms it. In `dist/_shared/llm-*.js` every generator does the
same branch:

```js
const hasNav = Boolean(config.nav && config.nav.length > 0);
const resolved = hasNav
  ? resolveNavGroups(config.nav ?? [])
  : resolveGroups(config.groups ?? []);
```

That lives inside:

- `generateLlmsTxt`  → writes `/llms.txt` and `/docs/llms.txt`.
- `generateAgentsMd` → writes `AGENTS.md` (the agent map).
- `generateAgentReadabilityArtifacts` → writes the
  `agent-readability.json` manifest, `sitemap.xml/md`, `robots.txt`.
- `resolveDocsNavigation` → the structured tree consumed by your docs UI
  (typically dumped to e.g. `src/generated/docs-nav.json`).

When `hasNav` is true, the resolver calls `buildNavigationFromNav(...)`,
which assembles each group's `pages` strictly from the `pages:` entries in
`nav` (literal extensionless paths, or `{ include, exclude, sort, required }`
glob entries). It does **not** look at the `group:` frontmatter to decide
sidebar membership — it walks `nav` only.

### The page's `group:` frontmatter

`group:` is parsed off every MDX file in `readSourceDocs` / `readMarkdownDocs`:

```js
const groups = normalizeGroupValue(parsed.data.group); // string | string[]
```

It accepts a string or an array (`group: foo` or `group: [foo, bar]`) and is
attached to every `SourceDoc` / `MarkdownDoc` (`SourceDoc.groups`). What it's
used for downstream depends on whether `nav` is in play:

| Output                              | When `nav` is set         | When only `groups` is set                               |
| ----------------------------------- | ------------------------- | ------------------------------------------------------- |
| Sidebar (`resolveDocsNavigation`)   | from `nav` tree           | `buildGroupMembership(pages, resolveGroups(groups))`    |
| `AGENTS.md`                         | from `nav` tree           | from `group:` frontmatter joined to the `groups` tree   |
| `docs/llms.txt`                     | from `nav` tree           | from `group:` frontmatter joined to the `groups` tree   |
| `agent-readability.json` navigation | from `nav` tree           | from `group:` frontmatter joined to the `groups` tree   |
| `SourceDoc.groups` field            | still populated           | still populated                                         |
| Validation that the slug is known   | still runs (see §2)       | runs                                                    |

So `group:` is "still good for":

1. **Taxonomy / metadata** — it survives on every page object (`groups: string[]`),
   so transformers, search filters, your own components, or external tools can
   key on it even when the visible sidebar comes from `nav`.
2. **Fallback navigation** — if you delete `nav` (or scope it down) you fall
   straight back to the `groups` + `group:` model with no other changes.
3. **Validation** — even with `nav` present, leadtype still cross-checks every
   `group:` slug against the `groups` tree and refuses to generate when a slug
   isn't declared (next section).

A useful mental rule: `nav` is **structure** (what appears where, in what
order). `group:` is a **label** on the page. With `nav`, structure stops
deriving from labels.

## 2. What happens if a page declares an unknown `group:` slug?

**Build fails.** The check fires inside `runGenerateCommand` in
`node_modules/leadtype/dist/cli.js` *before* any MDX is converted:

```js
const navigation = await resolveDocsNavigation({
  srcDir: sourceMirror.srcDir,
  groups, nav: effectiveNav, mounts, i18n, locale
});
const firstUnknownGroup = navigation.unknown[0];
if (firstUnknownGroup) {
  throw new Error(
    `${firstUnknownGroup.urlPath} declares unknown group "${firstUnknownGroup.slug}"`
  );
}
```

`navigation.unknown` is produced by `findUnknownGroups(docs, config.groups)`
in `dist/_shared/llm-*.js`. It calls `buildGroupMembership(...)` which
walks every page's `groups: string[]`, lowercases each slug, and pushes any
slug not present in the resolved `groups` tree into the `unknown` bucket:

```js
for (const slug of page.groups) {
  const slugKey = slug.toLowerCase();
  if (!known.has(slugKey)) {
    unknown.push({ page, slug });
    continue;
  }
  ...
}
```

Concrete consequences:

- The CLI exits with a non-zero status and the message
  `"<urlPath> declares unknown group \"<slug>\""` (only the first offender
  is reported per run; fix it and rerun to find the next).
- No `docs/*.md`, `llms.txt`, `llms-full.txt`, `AGENTS.md`,
  `search-index.json`, or readability artifacts are written for that run.
- With `--format json`, the same message comes back as
  `{"event":"generate.fail","fields":{"error": "...declares unknown group..."}}`.
- The i18n loop runs `resolveDocsNavigation` per locale, so an unknown slug in
  *any* locale's pages also fails the build.

Two important nuances:

1. **The check uses `groups`, not `nav`.** Even when `nav` is the thing that
   drives the sidebar, `groups` is still the registry of legal slugs. If your
   config only has `nav` and no `groups`, then there is no registry — every
   `group:` slug is effectively "unknown" but `findUnknownGroups` short-circuits
   and returns `[]` when `groups` is empty, so the check passes (the `group:`
   value is then purely metadata).
2. **Inferred groups.** If no `docs.config.ts` is loaded, or you pass
   `--include`/`--exclude` filters with an empty `groups`, the CLI calls
   `inferGroups(docsDir)` and synthesizes a `groups` list from the union of
   every page's `group:` frontmatter — in that mode every declared slug is
   trivially known by construction. The "unknown group" error only bites you
   when you have a real `groups` tree in config and a page references a slug
   that isn't in it.

### Practical onboarding checklist

- Treat `docs.config.ts`'s `nav` as the canonical sidebar and `AGENTS.md`
  outline. Add a page there to make it show up.
- Keep page `group:` frontmatter consistent with the `groups` tree (when you
  declare one) — it's still validated, and it's what you'll fall back to if
  `nav` is removed.
- If you see `<url> declares unknown group "<slug>"` at build time, either
  add the slug to the `groups` tree in `docs.config.ts` or fix the typo in
  the page's frontmatter; the build won't proceed until you do.
