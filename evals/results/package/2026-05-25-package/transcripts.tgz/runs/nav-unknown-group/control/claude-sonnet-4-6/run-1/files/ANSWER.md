# Navigation: `nav` vs. `group` frontmatter

Answers sourced by reading the installed `leadtype` package at
`node_modules/leadtype` — specifically:
- `dist/_shared/llm-DbiIv5JE.js` (all navigation-resolution logic)
- `dist/llm/index.d.ts` (public types)
- `dist/lint/index.d.ts` + `dist/_shared/runner-LBfgMZ36.js` (lint pipeline)
- `dist/index.d.ts` (`createDocsSource` config types)

---

## 1. Which one drives the sidebar and agent map, and what is the other still good for?

### The curated `nav` is the authority — it drives everything

When a `nav` array is present and non-empty in `docs.config.ts` (or in a
per-collection config), **`nav` is always preferred**. Every output that
produces navigation — the sidebar data structure, `llms.txt`, `llms-full.txt`,
`AGENTS.md`, the agent-readability manifest, and `resolveDocsNavigation` — checks
`nav` first:

```ts
// From resolveDocsNavigation (llm-DbiIv5JE.js, ~line 570)
if (config.nav && config.nav.length > 0) {
  const resolvedNav = resolveNavGroups(config.nav);
  return buildNavigationFromNav(
    docs,
    resolvedNav,
    tocByUrlPath,
    config.locale ?? …,
    findUnknownGroups(docs, config.groups)   // ← groups only consulted here
  );
}
// Falls through to the groups path only when nav is absent
const resolved = resolveGroups(config.groups ?? []);
```

The same pattern repeats in `generateLlmsTxt`, `generateLLMFullContextFiles`,
`generateAgentReadabilityArtifacts`, `generateAgentsMd`, and
`createDocsSource`. In every case the check is:

```ts
const hasNav = Boolean(config.nav && config.nav.length > 0);
const resolved = hasNav ? resolveNavGroups(config.nav ?? [])
                        : resolveGroups(config.groups ?? []);
```

`buildNavigationFromNav` populates the sidebar by walking the `nav` tree's
explicit `pages` entries and `include` globs; pages are looked up **by
relative file path**, not by their `group` frontmatter field.

### `group` frontmatter is legacy fallback taxonomy

The `group` field (declared in a page's YAML frontmatter as `group: <slug>` or
`group: [a, b]`) was the *original* mechanism. It tells the build pipeline
"this page belongs to the group whose `slug` matches". When `nav` is **absent**,
the build calls `buildGroupMembership`, which scans every page's `groups` array
and matches slugs against the flat list of known `DocsGroup` entries. The
resulting sidebar and agent outputs are then driven by that group membership.

Once you add `nav`, `group` frontmatter:

| What still works | What `nav` takes over |
|---|---|
| Provides the `groups: string[]` array on every `DocsPageMeta` / `SourceDoc` object — still readable at runtime by your own UI code | Sidebar order and structure |
| Surfaced in the agent-readability manifest's `pages[n].groups` field so consumers can filter by topic | `llms.txt` section headings and page order |
| Used by `findUnknownGroups` (see Q2) to populate `navigation.unknown` for diagnostics | `AGENTS.md` section structure |
| Linted by `lintDocs` (the `group` field is in `defaultFrontmatterSchema`) | `resolveDocsNavigation` tree |

In short: **`nav` owns the tree; `group` becomes a passive metadata tag** that
is preserved on page objects and still linted, but no longer controls where
pages appear.

---

## 2. What happens at build time if a page declares a `group` slug the config doesn't know about?

The answer differs depending on whether the project is using `nav` mode or
`groups` mode.

### When using `nav` (the preferred path)

Unrecognised `group` slugs do **not** cause an error or even a warning during
the main build. The `group` frontmatter on each page is read and stored in the
`groups: string[]` field of `SourceDoc` / `DocsPageMeta`, but nav construction
(`buildNavigationFromNav`) never cross-checks that array against any known-slug
list — it builds the tree purely from the `nav` config.

The *only* place where unknown slugs are surfaced is inside
`findUnknownGroups`, which is called as a best-effort diagnostic helper:

```ts
// llm-DbiIv5JE.js
function findUnknownGroups(docs, groups) {
  if (!(groups && groups.length > 0)) {
    return [];
  }
  const resolved = resolveGroups(groups);
  const membership = buildGroupMembership(docs, resolved);
  return membership.unknown.map(({ page, slug }) => ({
    urlPath: page.urlPath,
    slug
  }));
}
```

This is called only when both `nav` **and** `groups` are present in the config
(i.e. you kept a legacy `groups` array alongside the new `nav`). The result is
stored as `navigation.unknown` — a plain array of `{ urlPath, slug }` records
attached to the returned `DocsNavigation` object. It is **not thrown as an
error**; it is available for downstream consumers (a custom build script, a CI
check) to inspect. If you omit `groups` from the config entirely while using
`nav`, `findUnknownGroups` returns `[]` and the unknown list is always empty.

### When using `groups` only (legacy path)

Unknown slugs are handled by `buildGroupMembership`:

```ts
// llm-DbiIv5JE.js
for (const slug of page.groups) {
  const slugKey = slug.toLowerCase();
  if (!known.has(slugKey)) {
    unknown.push({ page, slug });   // ← collected, not thrown
    continue;
  }
  // ... add to the matched group
  matchedAny = true;
}
if (!matchedAny) {
  ungrouped.push(page);   // ← page silently moves to "Other"
}
```

Again: **no exception is thrown**. Pages whose every `group` slug is unknown
are silently demoted to the `ungrouped` bucket, which renders as the "Other"
section in `llms.txt` and `AGENTS.md`. The `{ page, slug }` pairs land in
`navigation.unknown` for inspection, but the build completes successfully.

### What the linter does (`leadtype lint` / `lintDocs`)

The lint pipeline validates frontmatter shape (using `defaultFrontmatterSchema`)
but that schema defines `group` as:

```ts
group: v.optional(v.union([v.string(), v.array(v.string())]))
```

It only checks *type* (string or array of strings). It does **not** cross-check
the slug value against the `groups` tree — unknown slugs pass lint without
error or warning. There is no `invalid-link`-style rule for group slugs; the
lint rules (`schema`, `unknown-field`, `missing-field`, `parse-error`,
`invalid-link`, `unresolved-placeholder`, `cross-framework-link`) don't include
a group-slug-exists check.

### Summary table

| Scenario | What happens to the page | Error thrown? | Appears in `navigation.unknown`? |
|---|---|---|---|
| `nav` mode, page has unknown `group` slug, no legacy `groups` in config | Page appears wherever `nav` places it (or in `ungrouped` if not listed) | No | No |
| `nav` mode, page has unknown `group` slug, legacy `groups` also in config | Same nav placement; slug recorded as unknown | No | Yes |
| `groups`-only mode, page has unknown `group` slug | Page moves to `ungrouped` ("Other" section) | No | Yes |
| `leadtype lint` run on either mode | Passes; lint does not validate slug values | No | N/A |
