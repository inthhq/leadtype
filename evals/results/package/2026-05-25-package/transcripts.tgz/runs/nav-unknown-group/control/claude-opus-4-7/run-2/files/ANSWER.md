# Onboarding: navigation in a leadtype project

> Source references below come from the installed `leadtype` package
> (`node_modules/leadtype/dist/`) — specifically `llm/index.d.ts` and the
> generation pipeline in `_shared/llm-*.js` and `cli.js`.

## 1. `nav` vs. page `group` frontmatter

Both fields exist, but they aren't peers — they're two different *modes* of
describing the docs taxonomy, and only one of them is active at a time per
collection.

### What `docs.config.ts` declares

`DocsConfig` (and `DocsCollection`) accepts two related fields:

```ts
type DocsConfig = {
  // …
  /** Fallback taxonomy. Matched against frontmatter `group:` on each page. */
  groups?: DocsGroup[];

  /**
   * Curated navigation tree. When present, this drives docs UI and
   * agent-facing indexes; `groups` remains fallback taxonomy/navigation
   * metadata.
   */
  nav?: DocsNavNode[];
};
```

A `DocsGroup` is just `{ slug, title, description?, children? }` — a flat (or
shallow-nested) taxonomy. A `DocsNavNode` is an *authored* tree:
`{ title, slug?, base?, pages?, children? }`, where `pages` is a list of
extensionless paths or `{ include, exclude, sort, required }` glob entries.

### Which one drives the sidebar and the agent map?

**`nav` wins whenever it's present.** This is enforced uniformly across every
artifact the pipeline emits:

- `resolveDocsNavigation(...)` — the function the runtime docs shell calls to
  get a sidebar manifest — checks `if (config.nav && config.nav.length > 0)`
  first; only if that's empty/absent does it fall back to building navigation
  from `groups` + each page's frontmatter `group:` via
  `buildGroupMembership(...)`.
- `generateLlmsTxt(...)` (the `/docs/llms.txt` agent map) does the same:
  `const hasNav = Boolean(config.nav && config.nav.length > 0); const resolved =
  hasNav ? resolveNavGroups(config.nav) : resolveGroups(config.groups ?? []);`.
- `generateAgentsMd(...)` (the bundled `AGENTS.md` for `node_modules/<pkg>`)
  branches identically — when `nav` is set it iterates the curated tree;
  otherwise it walks `groups` and matches by frontmatter slug.
- `generateAgentReadabilityArtifacts(...)` (sitemap.md/xml, robots.txt, and the
  `agent-readability.json` manifest) calls
  `buildNavigationFromMarkdownDocs(..., hasNav ? "nav" : "groups", config.groups)`.

So one rule covers everything: **curated `nav` ⇒ that exact tree is the sidebar
and the agent map. No `nav` ⇒ the pipeline derives the tree by matching each
page's frontmatter `group:` against `groups[].slug`.**

### What `group` frontmatter is still good for

Even in a `nav`-driven project, frontmatter `group:` is *not* dead — it just
stops being the primary navigation key. It's still useful for:

1. **Fallback / un-curated pages.** With `nav`, every page not referenced by a
   `pages:` entry lands in `navigation.ungrouped` (visible in the
   `agent-readability.json` manifest and the `## Other` section of
   `/docs/llms.txt` and `AGENTS.md`). Frontmatter `group:` doesn't promote a
   page into the curated tree, but together with `groups` it still gives those
   leftover pages a taxonomy label downstream readers can group by.
2. **The `groups` validation pass.** When both `nav` and `groups` are
   configured, the pipeline still runs `findUnknownGroups(docs,
   config.groups)` and surfaces the result on
   `navigation.unknown`. That's how you keep your authored taxonomy honest
   even while `nav` drives the UI.
3. **Per-page metadata for downstream tooling.** `DocsPageMeta.groups` (from
   `createDocsSource()` / `resolveDocsNavigation`) and the
   `AgentReadabilityPage.groups` field both surface every frontmatter group
   slug verbatim, so external tools (search facets, custom sidebars,
   analytics) can still slice pages by `group:` independently of the curated
   tree.
4. **Inference when there is no config.** If `leadtype generate` runs without
   a config (or with a config that declares neither `groups` nor `nav`), the
   CLI calls `inferGroups(docsDir)` and synthesizes a `groups` list from every
   distinct frontmatter `group:` value it finds. That's the only path where
   `group:` alone shapes the output.

**TL;DR:** Curated `nav` in `docs.config.ts` is the source of truth for the
sidebar and agent-facing maps. Page `group:` frontmatter is taxonomy metadata
— used as the fallback nav when `nav` is absent, used for cross-validation
when `nav` is present, and exposed on every page record for downstream
consumers.

## 2. What happens at build time if a page declares an unknown `group` slug?

**`leadtype generate` fails with a non-zero exit code.** It's a hard error,
not a warning.

The relevant code in `cli.js` (around line 1351) runs once per locale during
`runGenerateCommand`:

```js
const navigation = await resolveDocsNavigation({
  srcDir: sourceMirror.srcDir,
  groups,
  nav: effectiveNav,
  mounts,
  i18n: metadata.i18n,
  locale,
});
const firstUnknownGroup = navigation.unknown[0];
if (firstUnknownGroup) {
  throw new Error(
    `${firstUnknownGroup.urlPath} declares unknown group "${firstUnknownGroup.slug}"`
  );
}
```

The error is thrown from inside the `try` block, caught by `runGenerateCommand`,
funneled through `reportFailure(message)`, and the CLI returns exit code `1`
(with `--format json` it emits a `generate.fail` log event carrying the same
message). No artifacts — `llms.txt`, `llms-full.txt`, `AGENTS.md`,
`search-index.json`, `agent-readability.json`, the converted `docs/*.md`
mirrors — are written when this check trips, because it runs before any of
the `generate*` calls.

### How "unknown" is decided

`navigation.unknown` is populated by `buildGroupMembership(pages, resolved)`
in `_shared/llm-*.js`:

```js
const known = new Map(all.map((g) => [g.slugKey, g])); // g.slugKey = slug.toLowerCase()
// …
for (const slug of page.groups) {
  const slugKey = slug.toLowerCase();
  if (!known.has(slugKey)) {
    unknown.push({ page, slug });
    continue;
  }
  // …
}
```

Three things follow from that:

- Matching is **case-insensitive** (`slug.toLowerCase()`), but otherwise the
  string has to match a configured `groups[].slug` (including nested
  `children[].slug`) exactly.
- Frontmatter `group:` may be a string or an array of strings
  (`normalizeGroupValue`); each entry is checked independently, so a page that
  lists `[reference, mystery]` with only `reference` configured will still
  trigger the unknown-group error on `mystery`.
- If `nav` is set but `groups` is **not**, the validation simply doesn't run
  — `findUnknownGroups` early-returns `[]` when `groups` is empty or
  undefined. So the build-time guard only fires when you've actually declared
  a taxonomy in config for the page's `group:` to be checked against.

### Practical guidance

- If you add a new frontmatter `group:` slug, add it to `groups` in
  `docs.config.ts` in the same change.
- If you want a page to appear in `## Other` / `ungrouped` and skip the
  taxonomy check, just leave `group:` out of its frontmatter.
- If you only need a curated sidebar and don't want to maintain a parallel
  taxonomy, you can omit `groups` entirely — `nav` alone is a valid config,
  and the unknown-group validation will be a no-op.
- To diagnose a failing build, the error message tells you the offending
  `urlPath` and slug verbatim; grep the docs tree for that `group:` value or
  add it to `docs.config.ts`.
