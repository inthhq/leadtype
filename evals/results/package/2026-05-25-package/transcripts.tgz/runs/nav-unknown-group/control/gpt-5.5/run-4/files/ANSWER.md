# Leadtype navigation notes

1. **`nav` is the source of truth when it is present.** In `docs.config.ts`, a curated `nav` tree is preferred over `groups` and drives the generated navigation manifest used by the docs sidebar/runtime (`resolveDocsNavigation` / `createDocsSource().getNavigation()`) and by agent-facing maps such as `/docs/llms.txt`, package `AGENTS.md`, and agent-readability sitemap/manifest navigation.

   A page's frontmatter `group` is legacy taxonomy metadata. It is still parsed and exposed on page metadata, and it remains useful for filtering/tagging, compatibility with older integrations, and as the fallback navigation mechanism when no curated `nav` is configured. In fallback `groups` mode, pages are placed into configured `groups` by matching `frontmatter.group` slugs; with `nav`, pages are placed by the `nav.pages` entries/includes instead, not by `group`.

2. **Unknown legacy group slugs are caught during generation when there is a `groups` taxonomy to validate against.** `leadtype generate` resolves the navigation before writing artifacts and checks `navigation.unknown`; if a page declares a `group` slug that is not present in the configured `groups`, the build fails with an error like:

   ```text
   leadtype generate: /docs/some-page declares unknown group "some-slug"
   ```

   In pure curated-`nav` setups that do not define `groups` at all, `group` frontmatter does not drive placement and there is no group taxonomy to validate against. If you keep `groups` alongside `nav`, those legacy group values can still be validated against that taxonomy while `nav` continues to drive the sidebar and agent map.
