# Navigation: `nav` vs. `group` frontmatter

> Source of truth for the answers below: `node_modules/leadtype/dist/llm/index.d.ts`,
> `node_modules/leadtype/dist/llm/readability.d.ts`, and the resolver in
> `node_modules/leadtype/dist/_shared/llm-DbiIv5JE.js` (functions
> `resolveDocsNavigation`, `buildNavigationFromNav`,
> `buildGroupMembership`, `findUnknownGroups`).

## 1. Which one drives the sidebar and agent map?

**`nav` in `docs.config.ts` wins whenever it is present.** `groups` is a
fallback taxonomy used only when `nav` is absent.

Inside leadtype, every generator (`resolveDocsNavigation`, `generateAgentsMd`,
`generateLlmsTxt`, `generateAgentReadabilityArtifacts`,
`generateLLMFullContextFiles`) computes the same flag and branches on it:

```ts
const hasNav = Boolean(config.nav && config.nav.length > 0);
const resolved = hasNav
  ? resolveNavGroups(config.nav ?? [])   // curated tree
  : resolveGroups(config.groups ?? []);  // group taxonomy
```

The two modes assemble pages very differently:

| Mode             | How pages land in a sidebar/agent section                                                                                                |
| ---------------- | ---------------------------------------------------------------------------------------------------------------------------------------- |
| `nav` (curated)  | `buildNavigationFromNav` walks each nav node's `pages: [...]` / `include:` globs and **looks up MDX files by relative path**. Frontmatter `group:` is **not consulted** for placement. |
| `groups` (legacy) | `buildGroupMembership` reads each page's frontmatter `group:` (string or string[]) and assigns the page to the matching group slug.       |

So with `nav` set:

- The docs UI sidebar is the curated tree, in author order.
- `AGENTS.md` sections come from the same tree (`renderAgentsNavigationGroup`).
- `/docs/llms.txt` is rendered via `renderDocsNavigationSummary`.
- The agent-readability manifest's `navigation.groups[]` is the nav tree.
- Any MDX page that the nav tree didn't reference falls into
  `navigation.ungrouped[]`.

### So what is `group:` frontmatter still good for?

When `nav` drives placement, `group:` is no longer the routing signal — but the
docs config types explicitly keep `groups` around as **"fallback
taxonomy/navigation metadata"** (see the doc comment on `DocsConfig.nav` in
`llm/index.d.ts`). Concretely, `group:` is still useful for:

- **Taxonomy / faceting**: every page carries its declared slugs through the
  pipeline. `SourceDoc.groups`, `MarkdownDoc.groups`, `AgentReadabilityPage.groups`,
  and `DocsNavigationPage.groups` all preserve the normalized list, so you can
  filter, badge, or facet by them in your UI or search.
- **Drift detection between authoring and curation**: if you keep a
  `docs.config.ts#groups` list alongside `nav`, leadtype runs
  `findUnknownGroups(docs, config.groups)` and surfaces any page whose
  frontmatter `group:` doesn't match a known slug in `navigation.unknown[]`
  (see #2 below). That's how you catch a typo like `group: quickstrt` even
  though `nav` placement no longer needs the field.
- **Fallback rendering** if a project (or a single locale build) ever ships
  without a `nav` — the same MDX still produces a coherent sidebar/AGENTS.md
  via group membership.

In short: **`nav` is the routing/UX source of truth, `group:` is metadata +
validation**.

## 2. What happens at build time if a page declares an unknown `group:` slug?

**It does not fail the build.** Leadtype treats it as a soft diagnostic and
keeps generating.

What actually happens, traced through `buildGroupMembership` and
`findUnknownGroups` in `_shared/llm-DbiIv5JE.js`:

1. The slug is normalized (trimmed, lowercased for comparison) and looked up in
   the flattened set of group slugs from `config.groups`.
2. If the slug isn't found, the page is pushed into an `unknown` list as
   `{ urlPath, slug }`. The page is **not** dropped — it just doesn't get
   attached to that nonexistent group.
3. If the page declared *only* unknown slugs (no matched group at all), it
   falls through to `ungrouped` and shows up in the "## Other" section in the
   `groups`-driven outputs.
4. The `unknown` array is surfaced on the resolved navigation:
   ```ts
   type DocsNavigation = {
     groups: DocsNavigationGroup[];
     ungrouped: DocsNavigationPage[];
     /** Pages that named a group slug not present in the config. */
     unknown: { urlPath: string; slug: string }[];
     locale?: string;
   };
   ```
   It is returned by `resolveDocsNavigation()` and embedded in
   `agent-readability.json` under `navigation.unknown`, so build tooling, CI,
   or a docs lint step can read it and decide whether to warn or fail.

### When *will* leadtype actually throw?

Only for problems in the **config itself**, not in page frontmatter:

- `assertValidGroupSlug` throws on non-URL-safe slugs
  (`Invalid group slug "..." under "...".`).
- `resolveGroups` / `resolveNavGroups` throw on duplicate sibling slugs
  (`Duplicate group slug "..." under "...".`).
- In `nav` mode, a string entry in `pages:` that doesn't resolve to an MDX
  file throws:
  `Nav page "<entry>" under "<path>" did not match a documentation page.`
- An `include:` glob that matches nothing logs a warning, and only throws if
  the entry has `required: true`
  (`Nav include "..." under "..." matched no documentation pages.`).

So the practical rule of thumb: a typo in a page's `group:` frontmatter is a
**warning-grade signal exposed on `navigation.unknown`**, while a typo or
ambiguity in `docs.config.ts` itself fails the build.
