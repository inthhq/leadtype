# Navigation in Leadtype: `nav` vs. `group` Frontmatter

## Question 1: Relationship Between `nav` Config and Legacy `group` Frontmatter

### Which One Drives the Sidebar and Agent Map?

**The curated `nav` in `docs.config.ts` drives the sidebar and agent map.**

When `nav` is present in your docs config, it takes precedence and controls:
- The sidebar structure and page ordering
- The agent-facing navigation indexes (llms.txt, AGENTS.md, sitemap.md, and robot.txt)
- The navigational hierarchy exposed through `resolveDocsNavigation()`

The `nav` field is explicitly documented as **"Preferred over `groups`"** across all agent-generation APIs:
- `generateLlmsTxt()` uses `nav` when present
- `generateAgentsMd()` uses `nav` when present  
- `generateAgentReadabilityArtifacts()` uses `nav` when present
- `createDocsSource()` uses `nav` when present

### What Is the `group` Frontmatter Still Good For?

The legacy `group` frontmatter field serves as **fallback taxonomic metadata**. It remains useful for:

1. **Taxonomy/labeling**: Marking which logical section a page belongs to, independent of UI presentation
2. **Fallback navigation**: When `nav` is not configured, the `groups` array from config and page `group:` frontmatter together form the navigation structure
3. **Agent readability context**: Pages track all group slugs they declare in their `groups` property (normalized from frontmatter), which appear in the `DocsNavigation.groups` output and search results
4. **Custom filtering/categorization**: Your own code or transformers can inspect the `groups` property on loaded pages to implement custom section-based logic

### Key Distinction

- **`nav` (curated)**: Author-driven, explicit, ordered tree—controls what agents see and how docs are presented
- **`group` (legacy)**: Content-driven metadata—pages declare membership; useful as taxonomy and for fallback scenarios

When both are present, `nav` wins for all agent-facing outputs, but `group` metadata persists in the page metadata and is included in search/navigation artifacts.

---

## Question 2: What Happens at Build Time If a Page Declares an Unknown `group` Slug?

### Build Behavior

**Unknown group slugs are captured but do not cause a build failure.** 

At build time, leadtype handles unknown groups as follows:

1. **Parsed and recorded**: The page's frontmatter `group:` field is parsed and normalized into the page's `groups` property
2. **Collected in the unknown list**: Any group slug the page declares that is **not** present in the config's `groups` or `nav` tree is collected into the navigation manifest under `DocsNavigation.unknown`
3. **No error thrown**: Build continues without failure or warning

### Where Unknown Groups Appear

The `DocsNavigation` type includes an `unknown` field:

```typescript
type DocsNavigation = {
  groups: DocsNavigationGroup[];
  ungrouped: DocsNavigationPage[];
  /** Pages that named a group slug not present in the config. */
  unknown: {
    urlPath: string;
    slug: string;
  }[];
  // ...
}
```

This list records:
- `urlPath`: The canonical docs URL of the page that declared the unknown group
- `slug`: The unknown group slug from its frontmatter

### Practical Implications

1. **Soft validation**: Unknown groups are not validated away—they become visible in the navigation manifest so tooling can detect and report misconfigurations
2. **Orphaned pages**: A page with only unknown groups won't appear under any configured group in the sidebar/agent map, but its metadata still exists in page lists
3. **Debugging**: Check the `unknown` array in generated `docs-nav.json` or similar artifacts to find pages with misconfigured group slugs
4. **No strict mode by default**: Leadtype doesn't throw by default, but you can add a transformer with `beforeLlmsTxt` hook to validate and reject unknown groups if desired

This design allows graceful degradation: the docs build completes even with configuration drift, but the problem is surfaced in the navigation artifact for detection and repair.
