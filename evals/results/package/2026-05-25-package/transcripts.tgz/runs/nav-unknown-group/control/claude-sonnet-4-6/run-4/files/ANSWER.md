# Navigation: `nav` vs. `group` frontmatter

## 1. Which one drives the sidebar and agent map, and what is the other still good for?

### `nav` in `docs.config.ts` — the authoritative driver

The curated `nav` array in `docs.config.ts` (a `DocsNavNode[]` tree) is **the primary driver** of every navigation-dependent output:

| Output | How `nav` drives it |
|---|---|
| **Sidebar / `DocsNavigation`** | `resolveDocsNavigation()` detects `nav` first (`if (config.nav && config.nav.length > 0)`), calls `resolveNavGroups(config.nav)` and `buildNavigationFromNav(…)` to construct the `{ groups, ungrouped }` tree. |
| **`AGENTS.md`** | `generateAgentsMd()` calls `buildNavigationFromNav(…)` when `nav` is present, producing the exact same ordered group structure for offline agent reading. |
| **`llms.txt` / `docs/llms.txt`** | `generateLlmsTxt()` uses `renderDocsNavigationSummary(…)` (nav path) instead of `renderDocsSummary(…)` (groups path). |
| **`llms-full.txt`** | `generateLLMFullContextFiles()` resolves the nav tree and calls `orderMarkdownDocsByNavigation(…)` so pages appear in nav order inside the flattened file. |
| **`agent-readability.json`** | `generateAgentReadabilityArtifacts()` passes `mode: "nav"` to `buildNavigationFromMarkdownDocs(…)`, which delegates to `buildNavigationFromNav(…)`. |

The `nav` tree is **explicit and curated**: each `DocsNavNode` lists its pages via `pages` (exact paths or glob-style `include` entries), with an optional `base` path that cascades to children. Pages are ordered exactly as listed; unmentioned pages fall into `ungrouped`.

### `group` frontmatter — legacy taxonomy metadata

The per-page `group` field (`group: <slug>` or `group: [a, b]`) is a **legacy mechanism** that pre-dates the curated nav. When `nav` is **not configured**, it is the sole driver: `buildGroupMembership()` matches each page's `groups[]` array against the flat/nested `DocsGroup` tree from `groups` in config, and that membership drives the same sidebar/agent outputs described above.

Once `nav` is present, `group` is **bypassed for all navigation rendering** — the code simply never calls `buildGroupMembership()` in the nav path. However, `group` is still **read and stored on every page** (`groups: normalizeGroupValue(parsed.data.group)`) and exposed in several useful ways:

* It is surfaced in the `SourceDoc.groups` and `DocsPageMeta.groups` fields, so your own UI or custom transformers can read it.
* It is preserved in the `AgentReadabilityPage.groups` array inside `agent-readability.json`, giving consumers a secondary taxonomy signal.
* It populates the `navigation.unknown[]` list in the `DocsNavigation` return value (see below) — when `nav` is active, `findUnknownGroups()` still runs against the `groups` config to surface mismatches.
* The `leadtype lint` / `lintDocs()` validator accepts `group` as a known, valid frontmatter field (it is in `defaultFrontmatterSchema`), so it will not generate lint warnings for it.

In short: **`nav` drives everything structural; `group` survives as per-page taxonomy metadata and a secondary consistency signal.**

---

## 2. What happens at build time if a page declares a `group` slug the config doesn't know about?

The outcome depends on which mode is active:

### When only `groups` (no `nav`) is configured

`buildGroupMembership()` is called. For every page, it looks up each of the page's declared group slugs in a `Map` keyed by lowercased slug. If a slug is **not found**:

```js
// from buildGroupMembership() in llm-DbiIv5JE.js
if (!known.has(slugKey)) {
  unknown.push({ page, slug });
  continue;           // ← does NOT add the page to any group
}
```

The page is pushed onto the `unknown[]` array **and** — if every one of its slugs was unknown (i.e. `matchedAny` stays `false`) — it is also pushed onto `ungrouped[]`. The build **does not throw**; it completes normally. The unrecognised pages simply land in the `## Other` section of `llms.txt`, `AGENTS.md`, and the sidebar.

The `unknown[]` list is returned in the `DocsNavigation` object so build scripts, CI checks, or custom transformers can inspect and act on it.

### When `nav` is configured

`buildGroupMembership()` is **not called for nav resolution**. Instead, `findUnknownGroups()` is invoked as a supplementary check:

```js
// resolveDocsNavigation() — nav branch
findUnknownGroups(docs, config.groups)   // uses the groups config for validation only
```

`findUnknownGroups()` runs `buildGroupMembership()` against the `groups` tree (if provided) purely to collect mismatches and returns `{ urlPath, slug }[]`. Those entries are attached to the returned `DocsNavigation.unknown[]` array — they do **not** affect page placement in the nav, and they do **not** cause a build failure.

### Slug format errors always throw

One hard error exists regardless of mode: if the slug itself is not URL-safe (i.e. fails `/^[a-z0-9]+(?:-[a-z0-9]+)*$/i`), `assertValidGroupSlug()` **throws synchronously** during `resolveGroups()` / `resolveNavGroups()`. This check applies to slugs declared in the *config*, not in frontmatter — a page can declare any string in `group:` without a format error from this guard.

### Summary table

| Scenario | Throws? | Page placement | Surfaced where |
|---|---|---|---|
| Unknown slug, `groups`-only mode | No | `ungrouped` ("Other") | `navigation.unknown[]`, "Other" in all outputs |
| Unknown slug, `nav` mode | No | Placed by `nav` entry (or `ungrouped` if not listed) | `navigation.unknown[]` only |
| Invalid slug format in **config** | **Yes** | — | Synchronous `Error` at build start |
