# Navigation in this leadtype project

Short version: **the curated `nav` in `docs.config.ts` is the source of truth** whenever it exists. The legacy `group:` frontmatter is a fallback taxonomy that only drives layout when `nav` is absent — but it is still validated against the config and will fail the build if it names a slug nobody knows about.

This is taken from the installed `leadtype` package (`node_modules/leadtype/dist/llm/index.d.ts`, `dist/_shared/llm-DbiIv5JE.js`, `dist/cli.js`) so it matches the version we actually run.

---

## 1. `nav` vs. `group:` — which one drives what?

### `nav` (curated tree in `docs.config.ts`) — the primary driver

`DocsConfig` exposes two top-level navigation fields:

```ts
type DocsConfig = {
  // …
  /** Top-level taxonomy. */
  groups?: DocsGroup[];

  /**
   * Curated navigation. When present, this drives docs UI and
   * agent-facing indexes; `groups` remains fallback taxonomy/navigation
   * metadata.
   */
  nav?: DocsNavNode[];
};
```

That comment is not aspirational — it's enforced in every generator:

- `generateLlmsTxt`, `generateLLMFullContextFiles`, `generateAgentReadabilityArtifacts`, `generateAgentsMd`, and `resolveDocsNavigation` all check `config.nav` first:
  ```js
  const hasNav = Boolean(config.nav && config.nav.length > 0);
  const resolved = hasNav
    ? resolveNavGroups(config.nav ?? [])
    : resolveGroups(config.groups ?? []);
  ```
- When `hasNav` is true the navigation tree is built by `buildNavigationFromNav(...)`, which walks the curated `nav` tree, resolves each `pages:` / `include:` entry against the on-disk MDX, and **ignores `group:` for placement**. Pages land in the tree because the config's `pages`/`include` entries point at them, not because their frontmatter says `group: foo`.
- The same tree feeds:
  - `/docs/llms.txt` (curated docs map for agents),
  - `AGENTS.md` (bundle-mode agent map),
  - `agent-readability.json` + `sitemap.md` (Vercel Agent Readability artifacts),
  - the docs sidebar via `resolveDocsNavigation(...)` (what the runtime imports as `src/generated/docs-nav.json` or similar).

So: **`nav` drives the sidebar order, the section headings, the `AGENTS.md` map, and the agent-readability manifest.**

### `group:` frontmatter — still useful, but secondary

The frontmatter `group:` field (string or string array) is normalized by `normalizeGroupValue` and stored on every page as `groups: string[]`. Even when `nav` is in charge, this metadata is *not* thrown away:

1. **Fallback layout when `nav` is absent.** Without a `nav`, generators fall back to `buildGroupMembership(docs, resolveGroups(config.groups))`, which buckets pages into groups by matching frontmatter `group:` slugs against `config.groups[].slug`. This is the original behavior and still works if you only declare `groups`.
2. **Taxonomy on every page record.** Each `AgentReadabilityPage` and `DocsNavigationPage` includes a `groups: string[]` array carrying whatever the frontmatter declared. That ships into `agent-readability.json` and into the navigation page views, so downstream tools (search filters, breadcrumb hints, "related by tag" UIs, JSON-LD enrichment) can use it as a per-page tag set even though placement comes from `nav`.
3. **Config validation.** Even in `nav`-driven mode, leadtype still calls `findUnknownGroups(docs, config.groups)` and stashes the result on `navigation.unknown`. The curated tree is what users see; `groups` is what the build uses to police the frontmatter (see §2).

Mental model:

| Concern | Driven by |
| --- | --- |
| Sidebar / section tree | `nav` (falls back to `groups` if `nav` is missing) |
| `/docs/llms.txt`, `AGENTS.md`, agent-readability sitemap | `nav` (falls back to `groups`) |
| Per-page `groups: []` tags in the manifest | `group:` frontmatter |
| "Is this `group:` slug spelled right?" check | `config.groups` (the declared taxonomy) |

Practically: pick a page's location by editing `nav` in `docs.config.ts`. Keep `group:` frontmatter accurate because it's the taxonomy that gets validated and exported, not because it places the page.

---

## 2. What happens if a page's `group:` slug isn't in the config?

The build fails. Specifically, `leadtype generate` calls `resolveDocsNavigation(...)` for each locale and then does:

```js
// node_modules/leadtype/dist/cli.js
const navigation = await resolveDocsNavigation({ srcDir, groups, nav: effectiveNav, mounts, i18n, locale });
const firstUnknownGroup = navigation.unknown[0];
if (firstUnknownGroup) {
  throw new Error(
    `${firstUnknownGroup.urlPath} declares unknown group "${firstUnknownGroup.slug}"`
  );
}
```

That throw is caught by the CLI's `reportFailure`, which logs the message (human or JSON depending on `--format`) and returns exit code **1**. No MDX is converted, no `llms.txt`, no `AGENTS.md`, no search index — generation stops at the validation step.

How `unknown` is computed (`findUnknownGroups` in `dist/_shared/llm-DbiIv5JE.js`):

1. Resolve `config.groups` into a tree (still done even when `nav` is present).
2. Flatten it into a set of known slug keys (lowercased).
3. For each page, walk its normalized `groups: string[]`. Any slug not in the set is pushed into `unknown` as `{ urlPath, slug }`.

So the check runs **against `config.groups`, not against `config.nav`**. Two consequences worth knowing:

- If you only declare `nav` and omit `groups` entirely, `findUnknownGroups` short-circuits (`if (!(groups && groups.length > 0)) return [];`) and `group:` frontmatter is effectively un-validated — it becomes free-form tag metadata. The build won't fail on unknown slugs because there's no declared taxonomy to compare against.
- If you declare both `nav` and `groups`, the curated `nav` lays out the sidebar **and** `groups` keeps policing the frontmatter taxonomy. This is the recommended setup: `nav` for humans/agents, `groups` for "are people inventing slugs we don't recognize?"

Two more edge cases that look similar but are different errors:

- `group:` slug exists in `config.groups` but the page is never referenced from `nav`: not an error. The page just shows up under `navigation.ungrouped` (and, in `AGENTS.md` / `llms.txt`, under a generated `## Other` section).
- `nav` references a page path that doesn't exist on disk: that throws from `resolveNavEntryPages` with `Nav page "<entry>" under "<group>" did not match a documentation page.` — separate from the unknown-group check.

### TL;DR

- Edit `nav` in `docs.config.ts` to move a page in the sidebar / agent map.
- Keep `group:` frontmatter correct and listed in `config.groups`; it's per-page taxonomy and the only thing that gates the build with the "unknown group" error.
- A `group:` slug the config doesn't know about → `leadtype generate` exits 1 with `"<urlPath> declares unknown group \"<slug>\""` before any artifacts are written.
