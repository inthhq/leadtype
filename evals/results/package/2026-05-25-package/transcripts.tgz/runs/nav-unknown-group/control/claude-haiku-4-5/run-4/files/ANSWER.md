# Navigation in leadtype: `nav` vs `group`

## 1. Relationship between curated `nav` and legacy `group` frontmatter

### Which drives sidebar and agent map?

The **curated `nav` drives the sidebar and agent map** when present. Looking at the TypeScript definitions in `leadtype/llm/index.d.ts`, the `DocsConfig` type shows:

```typescript
/**
 * Curated navigation for the single-collection shape. When present, this
 * drives docs UI and agent-facing indexes; `groups` remains fallback
 * taxonomy/navigation metadata.
 */
nav?: DocsNavNode[];

/**
 * Top-level navigation for the single-collection shape. Mutually exclusive
 * with `collections`. Pages declare which group they belong to via MDX
 * frontmatter (`group: <slug>` or `group: [a, b]`).
 */
groups?: DocsGroup[];
```

**Key insight**: When `nav` is defined in `docs.config.ts`, it takes precedence over `groups`. The docs UI and agent-facing artifacts (llms.txt, AGENTS.md, agent readability manifests) are built from the curated `nav` tree structure.

### What is the `group` frontmatter still good for?

The `group` frontmatter field from pages serves a different purpose:

1. **Metadata and organizational taxonomy**: Even when `nav` is present, pages still declare their `group` via frontmatter. This is stored in the page's metadata as `groups: string[]` (which can be a single group or multiple groups).

2. **Fallback grouping**: When `nav` is omitted, the `group` frontmatter drives the navigation structure instead. This is the legacy behavior for simpler docs sites that don't need curated navigation.

3. **Page context in templates**: The page's `groups` field is available in the frontmatter and can be used by page templates, breadcrumbs, or sidebar logic to provide context about organizational hierarchy—independent of how the sidebar is structured.

In summary:
- **`nav` in config** = curated, author-defined navigation hierarchy (drives UI and agent map)
- **`group` in frontmatter** = page-level metadata about organizational membership (used when `nav` is absent, and always available as page context)

---

## 2. Build-time behavior for unknown group slugs

When a page declares a `group` slug that the config doesn't know about, the page is **tracked in a special `unknown` array** in the navigation structure.

Looking at the `DocsNavigation` type in `leadtype/llm/readability.d.ts`:

```typescript
type DocsNavigation = {
    groups: DocsNavigationGroup[];
    ungrouped: DocsNavigationPage[];
    /** Pages that named a group slug not present in the config. */
    unknown: {
        urlPath: string;
        slug: string;
    }[];
    locale?: string;
};
```

**What happens**:
- The page is **not silently dropped** or merged into an existing group
- Instead, it appears in the `unknown` array with its `urlPath` and the unknown `slug` it declared
- This surfaces the problem at build time so the developer can see which pages reference undefined groups
- The build does not fail—it succeeds but reports the mismatch in the navigation manifest

This is a validation mechanism: the page is discoverable via its URL path, but the misconfigured group reference is flagged for author awareness. Tools consuming the `DocsNavigation` structure can then decide whether to warn, error, or handle these pages specially (e.g., rendering them in a separate "uncategorized" section or omitting them from structured navigation).
