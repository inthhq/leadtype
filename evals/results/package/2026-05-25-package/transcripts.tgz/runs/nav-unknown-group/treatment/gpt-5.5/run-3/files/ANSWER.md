# Leadtype navigation: `nav` vs. `group`

1. **`docs.config.ts` `nav` is the curated source of truth** when it is present. It drives the resolved navigation tree used by the docs sidebar/top-level sections and the agent-facing maps/artifacts such as `llms.txt`, `AGENTS.md`, sitemap markdown, and Agent Readability navigation. A page's frontmatter `group` is **legacy taxonomy metadata**: it is still useful for projects that have not adopted `nav` and need fallback group-based navigation, and it can still serve as broad taxonomy/search/filter metadata.

2. If a page declares a legacy `group` slug that is not declared in the loaded config's known groups, Leadtype treats that as a content/config mismatch. At build/generation time the navigation resolver reports it as unknown, and the CLI build fails with an error like:

   ```txt
   /docs/some-page declares unknown group "some-slug"
   ```

   In other words, unknown groups are caught during the build rather than being left as a runtime/sidebar problem.
