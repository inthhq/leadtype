# Navigation: `nav` vs. `group` in Leadtype

## 1. Which one drives the sidebar and agent map — and what is the other still good for?

### `nav` in `docs.config.ts` is the authoritative driver

The curated `nav` array declared in `docs.config.ts` (or in a per-collection
`defineCollection({ nav: … })`) is the **single source of truth** for every
navigation-related artifact leadtype produces. Specifically, the resolved `nav`
tree drives all of the following surfaces simultaneously:

| Surface | Driven by `nav` |
|---|---|
| Sidebar structure (top-level tabs and nested sections) | ✅ |
| `llms.txt` section headings and page listing | ✅ |
| `AGENTS.md` grouping (bundle mode) | ✅ |
| `agent-readability.json` and Agent Readability metadata | ✅ |
| `sitemap.md` / `sitemap.xml` | ✅ |
| Navigation manifest (`docs-nav.json`) from `resolveDocsNavigation()` | ✅ |

Because all those surfaces are resolved from the same `nav` tree, the human
sidebar and the agent-readable map are always structurally identical — there is
no drift between what a reader sees in a browser and what a coding agent reads
from `AGENTS.md` or `llms.txt`.

A `nav` node can be a flat section (`{ title, pages: […] }`), a nested group
(`{ title, children: […] }`), or a wildcard include
(`{ include: "guides/*", sort: ["order", "path"] }`). The `base` field cascades
a path prefix down to child nodes so you don't repeat folder names. Explicit
page strings in `pages` give you pinned, ordered entries; `include` entries
give you inventory-style expansion for component lists, hook lists, and
generated reference pages.

### `group` frontmatter is legacy taxonomy and compatibility metadata

The per-page `group` frontmatter field (a slug string or array of slugs)
predates config-owned `nav`. After a project adopts `nav`, the official
guidance is:

> Treat `group` as taxonomy and compatibility metadata. Put intentional
> navigation in `nav`.

What `group` is still useful for after adopting `nav`:

- **Legacy navigation fallback.** When `nav` is absent, `leadtype generate`
  falls back to the group resolver, which infers a navigation tree from the
  `group:` values it finds in frontmatter. This fallback is sufficient for
  small or early-stage docs sets.
- **Search facets.** The group slug is carried into the search index as
  metadata, so search UIs can filter or facet results by broad taxonomy.
- **Broad taxonomy / cross-cutting tags.** A page can declare multiple groups
  (`group: [a, b]`), allowing the same page to be associated with more than one
  topic area in ways that config nav (which places each page in one explicit
  location) does not express.
- **Compatibility.** During an incremental migration, keeping `group` in
  frontmatter while `nav` is being built out lets the legacy path continue
  functioning until `nav` fully replaces it.

**In summary:** `nav` drives the sidebar and every agent-facing map. `group`
survives as a lightweight taxonomy tag and a fallback for projects that have
not yet written a `nav`.

---

## 2. What happens at build time if a page declares a `group` slug the config doesn't know about?

**The build fails immediately with an error.**

This is explicitly by design. From the *How it works* reference:

> Step 3 — **Resolve groups** from frontmatter, validate every page's `group:`
> matches a known slug. If step 3 finds an unknown group, the run fails.

And from the *Frontmatter* reference:

> If a page declares a group slug that isn't in `docs.config.ts`, the build
> fails with `unknown group "<slug>"`. Same source of truth, no drift.

The exact sequence during `leadtype generate`:

1. Parse frontmatter for every `.mdx` file.
2. Convert each file through the remark stack and write `.md` output.
3. **Resolve groups** — every `group:` slug on every page is checked against
   the list of groups declared in `docs.config.ts`. A slug that has no matching
   entry in the config triggers an `unknown group "<slug>"` error and aborts
   the run.
4. (Only reached if step 3 passes) Generate `llms.txt`, search index, Agent
   Readability files, etc.

The same slug validation is also available before generation via
`leadtype lint`, which is the recommended CI step to run *before* generate so
you get precise file/line context on content errors rather than an abrupt build
abort. The lint rule that surfaces this in the library API is the `schema` /
frontmatter rule family (unknown or invalid field values).

**Why the hard failure rather than a warning?** Because unknown groups would
silently produce a broken navigation tree — pages would be orphaned from the
sidebar and from the agent map. Leadtype treats navigation consistency as a
correctness invariant, not a cosmetic concern, so it fails loudly at build time
rather than letting broken nav reach production. This also enforces a single
source of truth: the config is the registry of valid group slugs; frontmatter
values are validated against it.

### Practical implication for new pages

Whenever you add a new `group:` value to a page's frontmatter, you must first
declare that slug in `docs.config.ts` (`groups` array or equivalent collection
config). The reverse is also true for cleanup: removing a group from the config
while pages still reference its slug will break the build until those pages are
updated or removed. This tight coupling is the mechanism that prevents nav
drift.
