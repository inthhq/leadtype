# Navigation in leadtype: `nav` vs `group`

Source: `node_modules/leadtype/docs/authoring/frontmatter.md` and `node_modules/leadtype/docs/changelog/nav-migration-prompts.md` (version-matched docs that shipped with the installed package).

## 1. Which one drives the sidebar and agent map?

**The curated `nav` in `docs.config.ts` is the source of truth.** When `nav` is present, the same resolved tree drives every navigation surface leadtype produces:

- top-level docs areas / top tabs (e.g. Docs, Frontend, Integrations, Changelog),
- the human sidebar,
- `llms.txt` sections,
- `AGENTS.md` grouping,
- sitemap markdown,
- the Agent Readability metadata / navigation manifest.

This is by design — the changelog calls out the goal explicitly: *"Confirm `llms.txt`, `AGENTS.md`, Agent Readability navigation, the top nav, and the human sidebar use the same structure."*

**`group` in page frontmatter is legacy taxonomy metadata.** The frontmatter doc literally describes it as "optional legacy taxonomy metadata. Use config-owned `nav` for curated page placement." It is still useful for several things:

- **Fallback navigation.** If a project has *no* `nav` in `docs.config.ts`, leadtype falls back to the legacy group resolver — it reads each page's `group:` value, intersects it with the `groups` declared in config, and synthesizes a nav tree, `llms.txt` sections, `AGENTS.md` sections, and search metadata from that. The frontmatter doc notes this is "enough for small docs sets" but you should adopt `nav` once you need stable top-level areas, sidebar order, descriptions, nested sections, or wildcard includes.
- **Taxonomy / compatibility metadata.** Pages can declare multiple slugs (`group: [a, b]`), which is handy for cross-cutting categorization independent of where the page is *placed* in the sidebar.
- **Search facets and broad taxonomy.** The "What this gives you" section spells this out: `group` "remains available for legacy navigation fallback, search facets, and broad taxonomy."
- **Continued lint validation.** The migration prompt recommends keeping `groups` defined in config during migration so existing `group` frontmatter keeps validating, even though `nav` is now what actually drives placement.

Companion legacy fields:

- `order` — only relevant as a fallback sort key for pages pulled in by an `{ include: "...", sort: ["order", "path"] }` entry inside `nav`. The migration guidance is to "keep `order` only where wildcard includes need fallback sorting."

### Mental model

```
docs.config.ts  ── nav present? ──► nav tree ──► sidebar + top nav
                                            └─► llms.txt
                                            └─► AGENTS.md
                                            └─► sitemap.md
                                            └─► agent-readability nav

                ── nav absent ───► legacy group resolver
                                   (config `groups` ∩ page `group:` values)
                                            └─► same outputs, but inferred
```

In a `nav`-driven project, you can essentially ignore `group` for placement purposes; treat it the way you'd treat tags.

## 2. What happens if a page declares a `group` slug that the config doesn't know about?

**The build fails with `unknown group "<slug>"`.**

From the frontmatter doc, verbatim:

> If a page declares a group slug that isn't in `docs.config.ts`, the build fails with `unknown group "<slug>"`. Same source of truth, no drift.

So `group` is permissive in the sense that it's optional and legacy, but it's *not* a free-form field — any slug you write into a page's frontmatter must be declared in the project's `docs.config.ts` (either at the top level of `groups` or nested under a parent group's `children`). This is enforced at generate time and surfaced via `leadtype lint`'s `schema` rule in CI, so drift between page frontmatter and config gets caught before publish rather than silently producing a broken sidebar or `llms.txt` section.

Practical implication for onboarding: if you add a new page and pick a `group:` value, either (a) pick an existing slug already in `docs.config.ts`, or (b) add the slug to `groups` in the config in the same change. If the project has fully migrated to `nav`, you can usually just omit `group` altogether.
