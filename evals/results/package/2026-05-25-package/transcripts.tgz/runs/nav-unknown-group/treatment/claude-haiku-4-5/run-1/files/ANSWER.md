# Navigation in Leadtype: `nav` vs `group`

## 1. Relationship Between Config `nav` and Page `group` Frontmatter

### Which one drives the sidebar and agent map?

**The `nav` configuration in `docs.config.ts` is the primary driver.**

When a `nav` array is present in `docs.config.ts`, it drives:
- **Sidebar structure** — the navigation displayed in the rendered docs site
- **Agent map** — the navigation structure in `llms.txt`, `AGENTS.md`, and Agent Readability metadata
- **Sitemap markdown** — the navigation reflected in generated artifacts
- **Documentation hierarchy** — how sections and nested groups are organized for both human and machine consumers

### What is the `group` frontmatter field still good for?

The `group` field is **legacy taxonomy metadata**:
- **Backward compatibility** — pages that declare `group` can still validate if those groups are defined in `docs.config.ts`
- **Search facets** — `group` metadata can be used for search filtering and faceting
- **Fallback navigation** — in projects that have not adopted `nav`, the CLI can fall back to the legacy group resolver and infer a navigation structure from the `group:` values it finds in pages
- **Cross-cutting taxonomy** — pages can declare one or more group slugs (`group: slug` or `group: [a, b]`), allowing pages to belong to multiple taxonomy categories for organizational purposes

### The Modern Pattern

Best practice is to:
1. **Put curated navigation in `nav`** — use explicit page strings for important entry points, `include` patterns for inventory-like sections, and nested structure for complex hierarchies
2. **Keep `group` optional** — use it only for legacy fallback, search metadata, or when pages need to be tagged with multiple taxonomy categories
3. **Never let them drift** — the `docs.config.ts` is the source of truth; `group` in frontmatter should align with it for validation

---

## 2. Build-Time Behavior When a Page Declares an Unknown `group`

### What happens?

**The build fails with an error: `unknown group "<slug>"`**

If a page declares a `group` slug that isn't defined in `docs.config.ts`, the build process will exit with a validation error.

### Why this design?

This "same source of truth, no drift" approach ensures:
- **Consistent validation** — typos in group slugs are caught at build time, not silently ignored
- **Navigation integrity** — pages can't reference navigation groups that don't exist in the config
- **Failing fast** — CI catches these issues before they reach production

### When is this enforced?

The validation happens during:
- `leadtype generate` — the static artifact CLI
- `leadtype lint` — the dedicated linting tool (should be run in CI before publish)
- Framework adapter builds — when using the source primitive via `createDocsSource()`

### Fallback behavior (if no `nav` is configured)

If a project has not yet adopted `nav` config, the CLI can fall back to the legacy group resolver and infer groups from the `group:` values it finds in pages themselves. However, this fallback is intended only for small docs sets and should not be relied upon for production documentation—use config `nav` when you need stable top-level docs areas, sidebar order, descriptions, nested sections, or wildcard includes.

---

## Summary Table

| Aspect | `nav` in `docs.config.ts` | `group` in frontmatter |
|--------|--------------------------|----------------------|
| **Purpose** | Curated site navigation structure | Legacy taxonomy metadata |
| **Drives sidebar?** | ✅ Yes, primary | ❌ No (legacy fallback only) |
| **Drives agent map?** | ✅ Yes, primary | ❌ No (legacy fallback only) |
| **Used for search facets?** | ✓ Can be | ✓ Can be |
| **Allows wildcards & nesting?** | ✅ Yes | ❌ No |
| **Source of truth?** | ✅ Yes | ❌ Subservient |
| **Unknown slugs fail build?** | N/A | ✅ Yes, validation error |

