# Navigation in Leadtype: `nav` vs `group`

## 1. Which one drives the sidebar and agent map, and what is the other still good for?

**`nav` in `docs.config.ts` is the authority for all curated navigation.**

When a `nav` array is present in `docs.config.ts`, it is the single source of truth for:

- The **sidebar** structure (top-level tabs, section headings, page order).
- The **agent map** — `llms.txt` sections, `AGENTS.md` grouping, Agent Readability navigation, and the sitemap markdown.

From the frontmatter docs:

> `nav` drives top-level docs areas, sidebar structure, `llms.txt`, `AGENTS.md`, sitemap markdown, and Agent Readability navigation.

`nav` supports explicit page lists, `base` path cascading, wildcard `{ include }` entries, nested child sections, and `sort` options — giving intentional, stable control over the full information architecture of the site.

**`group` (the per-page frontmatter field) is legacy taxonomy metadata.**

Once `nav` is in place, `group` is no longer what builds the sidebar or drives the agent map. Its remaining uses are:

1. **Legacy navigation fallback.** If *no* `nav` is defined in the config, the build falls back to the old "group resolver," which infers navigation structure purely from `group:` values found in frontmatter and their corresponding `groups` declarations in the config. This is sufficient for small docs sets but does not support stable top-level areas, sidebar ordering, descriptions, nested sections, or wildcard includes.
2. **Search facets.** `group` values are still indexed and can be used as facets in the static search index.
3. **Broad taxonomy / compatibility metadata.** A page can be tagged with one or more group slugs (`group: [a, b]`) to indicate membership in multiple cross-cutting categories without affecting the curated nav structure.

In summary: **`nav` drives everything visible to humans and agents; `group` survives as a compatibility and taxonomy annotation.**

---

## 2. What happens at build time if a page declares a `group` slug the config doesn't know about?

**The build fails immediately with a hard error.**

From the "How it works" pipeline description (step 3 of `leadtype generate`):

> **Resolve groups** from frontmatter, validate every page's `group:` matches a known slug.
> If step 3 finds an unknown group, the run fails. That is by design — broken navigation is a content bug, not a render-time problem.

The frontmatter docs state the same constraint explicitly:

> If a page declares a group slug that isn't in `docs.config.ts`, the build fails with `unknown group "<slug>"`. Same source of truth, no drift.

This is intentional. Because `group` slugs feed the fallback nav tree, `llms.txt` sections, search metadata, and `AGENTS.md` grouping, an unrecognised slug would silently corrupt those outputs. Failing loudly at build time (before any artifact is written) prevents navigation drift between what the config declares and what pages actually claim.

The `validate-in-ci` guide reinforces this by recommending `leadtype lint` be run *before* `leadtype generate`, because `lint` will surface unknown groups with precise file/line context, which is easier to debug than the noisier generate-time failure.
