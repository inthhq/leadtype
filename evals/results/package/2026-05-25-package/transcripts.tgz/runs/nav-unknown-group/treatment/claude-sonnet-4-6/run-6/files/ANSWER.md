# Navigation in Leadtype: `nav` vs `group`

## 1. Which one drives the sidebar and agent map — and what is the other still good for?

**`nav` in `docs.config.ts` is the authoritative driver** of every curated navigation surface.  
**`group` in page frontmatter is the legacy fallback**, now demoted to taxonomy and compatibility metadata.

### How `nav` works

The `nav` array in `docs.config.ts` is the single source of truth for:

- **The sidebar** — root `nav` nodes become top-level tabs (Docs, Frontend, Integrations, Changelog, etc.); the active node's children become the sidebar tree.
- **The agent map** — the same resolved tree is what drives `llms.txt`, `llms-full.txt`, `AGENTS.md`, the sitemap markdown, and the `agent-readability.json` manifest.
- **Search metadata** — section headings in the search index are derived from `nav` sections.

In short, every surface that a human reader and every surface that an AI agent uses both come from `nav`. They share the same tree, so the two surfaces can never drift from each other.

```ts
// docs/docs.config.ts
export default defineDocsConfig({
  product: { name: "My Library", summary: "..." },
  nav: [
    {
      title: "Get Started",
      pages: ["", "quickstart"],
    },
    {
      title: "Reference",
      base: "reference",
      pages: ["cli", { include: "*", sort: ["order", "path"] }],
    },
  ],
});
```

### What `group` is still good for

`group` remains a valid, schema-recognised frontmatter field and is still useful for:

- **Legacy navigation fallback** — if a project has *no* `nav` in config at all, the CLI falls back to the legacy group resolver and infers navigation from `group:` values it finds across pages. This is enough for small docs sets but lacks stable ordering, descriptions, nested sections, or wildcard includes.
- **Search facets** — `group` values can still feed search metadata and broad taxonomy grouping.
- **Broad taxonomy / compatibility metadata** — a page can declare `group: [authoring, reference]` to express that it belongs to multiple conceptual categories without that affecting the curated nav structure.

The key rule: **use `nav` when you need intentional navigation; use `group` only as taxonomy and compatibility metadata.**

---

## 2. What happens at build time if a page declares a `group` slug the config doesn't know about?

**The build fails with an error.**

Specifically, when the legacy group resolver is active (i.e., `nav` is absent and `groups` are declared in `docs.config.ts`), every `group:` slug on a page is validated against the group slugs registered in config. If a page declares a slug that isn't in `docs.config.ts`, leadtype throws:

> `unknown group "<slug>"`

This is intentional. The config is the single source of truth for what groups exist; pages are not allowed to invent new group slugs unilaterally. The constraint ensures there is no drift between the config's declared groups and the groups pages actually reference.

The same principle enforces correctness before any generated artifacts are written — the sidebar, `llms.txt`, `AGENTS.md`, and the search index would all be inconsistent if a page could silently reference an undeclared group. Failing loudly at build time surfaces the problem where it is easiest to fix.

### Practical notes

- Run `leadtype lint` *before* `leadtype generate` in CI — lint validates frontmatter (including group slugs) with file and line context, which is easier to debug than a downstream app build using stale artifacts.
- If you are migrating to `nav`, keep `groups` defined in config for as long as any page frontmatter still carries `group:` values, so the validator continues to have something to check against.
- Once a project fully adopts `nav`, `group` values on pages are treated purely as taxonomy metadata and are no longer cross-checked against a config registry.
