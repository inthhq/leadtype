# Navigation in leadtype: `nav` vs. `group`

## 1. Relationship between `nav` (in `docs.config.ts`) and the legacy `group` frontmatter field

In current leadtype, the curated `nav` array in `docs.config.ts` is the single source of truth for navigation. From the authoring/frontmatter docs:

> `nav` drives top-level docs areas, sidebar structure, `llms.txt`, `AGENTS.md`, sitemap markdown, and Agent Readability navigation.

So `nav` is what drives:

- The site's top-level tabs (e.g. Docs, Frontend, Integrations, Changelog) — root nav nodes.
- The sidebar for the active top-level area — that node's child sections and pages.
- The agent-facing artifacts: `llms.txt`, `AGENTS.md`, sitemap markdown, and the Agent Readability metadata.
- Generated `docs-nav.json` if your app consumes one.

It is the *same resolved tree* feeding both the human sidebar and the agent map, which is the whole point of moving navigation into config — no drift between what readers see and what agents see.

The per-page `group:` frontmatter field is now **legacy taxonomy / compatibility metadata**. It is still valid and the schema still accepts it (including the multi-value form `group: [a, b]` for pages that belong to more than one taxonomy bucket), but it is explicitly *not* the recommended place to express curated navigation anymore. Per the changelog's "Nav migration prompts" page:

> `group` is still valid, but it is no longer the best place to express a polished navigation. Treat it as taxonomy and compatibility metadata. Put intentional navigation in `nav`.

What `group` is still good for:

- **Legacy navigation fallback.** If a project has no `nav` in its config, the CLI falls back to the legacy group resolver and infers the navigation tree from the `group:` values it finds on pages, intersected with whatever groups are declared in `docs.config.ts`. This is "good enough for small docs sets" but lacks stable top-level areas, descriptions, nested sections, and wildcard includes.
- **Search facets and broad taxonomy.** Even when `nav` owns navigation, `group` continues to flow into search metadata and acts as a tag-like classifier (and since a page can list multiple groups, it can participate in multiple taxonomy buckets independent of where it sits in the curated tree).
- **Compatibility** during migration so existing pages keep validating while you incrementally move structure into `nav`.

Similarly, the `order` frontmatter field is no longer needed for hand-pinned ordering — `nav` lists pages explicitly — but it remains useful as a fallback sort key for pages pulled in by a wildcard `{ include: "...", sort: ["order", "path"] }` entry.

## 2. What happens at build time when a page declares a `group` slug the config doesn't know about

The build fails. The frontmatter docs state this explicitly:

> If a page declares a group slug that isn't in `docs.config.ts`, the build fails with `unknown group "<slug>"`. Same source of truth, no drift.

So if you add `group: experiments` to a page but `docs.config.ts` only declares groups like `authoring`, `docs-site`, and `reference`, `leadtype generate` (and `leadtype lint` in CI, per the lint rules) will error out with an `unknown group "experiments"` failure rather than silently inventing a new bucket. The fix is either to:

- Add that slug to `groups` in `docs.config.ts` (if you really want a new taxonomy bucket), or
- Change the page's `group` to one of the already-declared slugs, or
- Remove the `group` field entirely if the page's placement is now expressed in `nav` and you don't need the taxonomy label.

This strict validation is what makes "same source of truth, no drift" work — the config enumerates the legal vocabulary and pages can't quietly diverge from it.
