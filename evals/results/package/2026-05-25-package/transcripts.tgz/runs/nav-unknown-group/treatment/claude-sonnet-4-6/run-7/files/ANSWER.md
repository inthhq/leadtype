# Navigation: `nav` vs `group` frontmatter

## 1. Relationship between `nav` (in `docs.config.ts`) and `group` (page frontmatter)

### `nav` drives everything authoritative

The curated `nav` array in `docs.config.ts` is the **single source of truth** for
all navigation surfaces. Once `nav` is present, it owns:

- The **sidebar** structure (top-level tabs, nested sections, page order)
- The **agent map** (`AGENTS.md` grouping, `llms.txt` sections, Agent Readability
  metadata, sitemap markdown)
- Generated navigation output (`resolveDocsNavigation`, `getNavigation()`)
- Search index metadata

`nav` supports fine-grained control: explicit page ordering, `base` inheritance
for path prefixes, `{ include: "folder/*" }` wildcard entries with optional
`sort`, nested children, and stable top-level "tab" nodes like Docs / Reference /
Changelog. The resolved tree is identical across every human and agent output
surface — there is no separate "sidebar config" vs "agent config."

### `group` is now legacy taxonomy / compatibility metadata

The `group` frontmatter field (e.g. `group: authoring` or
`group: [authoring, reference]`) is the **older**, pre-`nav` mechanism. In
projects that have fully adopted `nav`, `group` is demoted to a secondary role
and is still useful for:

1. **Legacy group resolver fallback.** If `nav` is absent, the CLI falls back to
   reading every page's `group` value and cross-referencing it with the `groups`
   list declared in `docs.config.ts` to build a navigation tree. This is enough
   for small or simple docs sets.
2. **Search facets.** `group` values appear as taxonomy metadata in the search
   index and can power faceted filtering in a search UI.
3. **Broad taxonomy / compatibility labelling.** Pages can carry multiple group
   slugs (`group: [a, b]`) to express cross-cutting membership that is
   independent of their precise position in the sidebar.

The key asymmetry: **`nav` drives the sidebar and the agent map; `group` is what
those nav-less pages used to use, and what is still available as taxonomy
metadata and a compatibility fallback.**

In the docs' own words (from `docs/authoring/frontmatter.md`):

> `nav` drives top-level docs areas, sidebar structure, `llms.txt`, `AGENTS.md`,
> sitemap markdown, and Agent Readability navigation.
>
> `group` remains available for legacy navigation fallback, search facets, and
> broad taxonomy.

---

## 2. What happens at build time if a page declares an unknown `group` slug

**The build fails with a hard error.**

If a page's frontmatter declares a `group` slug that is not registered in
`docs.config.ts`, `leadtype generate` exits non-zero with:

```
unknown group "<slug>"
```

This is by design — the "same source of truth, no drift" guarantee. Every slug
that any page references must exist in the config's `groups` list, so the two
never silently diverge.

From `docs/authoring/frontmatter.md`:

> If a page declares a group slug that isn't in `docs.config.ts`, the build
> fails with `unknown group "<slug>"`.  Same source of truth, no drift.

From `docs/build/validate-in-ci.md`:

> Generate fails noisily on unknown groups or broken includes.

### Catching it before `generate` runs

Because `leadtype generate` fails *noisily but late*, the recommended practice
is to run `leadtype lint` first in CI. Lint surfaces the same unknown-group
violation (along with schema, link, and placeholder issues) with precise
file/line context, making it easier to debug than a mid-generate failure:

```bash
# In CI — fail fast on content errors, then generate
npx leadtype lint docs --error-unknown
npx leadtype generate --src . --out public --json
```

The `--error-unknown` flag also upgrades any unrecognised frontmatter *field*
(not just group slugs) from a warning to a hard error, which is recommended for
strict CI setups.
