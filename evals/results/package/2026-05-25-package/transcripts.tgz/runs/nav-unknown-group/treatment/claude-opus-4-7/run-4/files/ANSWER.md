# Leadtype navigation: `nav` vs `group`

## 1. Relationship between curated `nav` and legacy `group` frontmatter

**`nav` in `docs.config.ts` is the source of truth for curated navigation.** It is what drives every reader- and agent-facing structural surface:

- the top-level docs areas / tabs and the human sidebar,
- `llms.txt` sections,
- `AGENTS.md` grouping,
- sitemap markdown,
- the Agent Readability navigation manifest.

The same resolved `nav` tree feeds all of those, so the human site and the agent map can't drift.

**The frontmatter `group` field is no longer the preferred way to express navigation.** Leadtype's authoring docs explicitly say:

> `group` — optional legacy taxonomy metadata. Use config-owned `nav` for curated page placement.

And from the changelog:

> `group` is still valid, but it is no longer the best place to express a polished navigation. Treat it as taxonomy and compatibility metadata.

That said, `group` is still good for several real jobs:

- **Fallback navigation.** If a project has *no* `nav` in `docs.config.ts`, the CLI falls back to the legacy group resolver: it reads each page's `group:` value, intersects with the `groups` array declared in the config (or, if there isn't one, infers groups from the union of values it sees), and builds a nav tree from that. That's fine for small docs sets; `nav` is what you reach for once you need stable top tabs, sidebar order, descriptions, nested sections, or wildcard includes.
- **Taxonomy / compatibility metadata.** A page can declare one or more group slugs (`group: foo` or `group: [foo, bar]`), which lets a page belong to multiple taxonomy buckets without duplicating files.
- **Search facets and broad classification** — `group` shows up in search metadata even when `nav` is what's rendering the sidebar.
- **Per-page `order`** still has a job too: it's the fallback sort key for pages pulled into a `nav` section via a wildcard `{ include: "*", sort: ["order", "path"] }`.

The short version: **`nav` drives the sidebar and the agent map; `group` is now taxonomy + a legacy fallback + a search facet.**

## 2. What happens at build time when a page has an unknown `group`?

**The build fails — by design.** From `docs/authoring/frontmatter.md`:

> If a page declares a group slug that isn't in `docs.config.ts`, the build fails with `unknown group "<slug>"`. Same source of truth, no drift.

`docs/how-it-works.md` says the same thing about the resolve step:

> If step 3 finds an unknown group, the run fails. That is by design — broken navigation is a content bug, not a render-time problem.

This is reflected at the CLI level too: `leadtype generate` exits with code `1` on an unknown group (alongside other runtime errors like a missing docs dir or config load failure), and the bundle/llm APIs emit `error: <urlPath> declares unknown group "<slug>".` on stderr.

A couple of edge cases worth knowing:

- **No config at all:** if there is no `docs.config.ts`, the CLI infers the group set from the union of `group:` values it actually finds in pages, so by construction nothing is "unknown" — but you also lose curated ordering, titles, and descriptions.
- **Config has `nav` but no `groups` array, and pages still set `group`:** `group` is then taxonomy/search metadata only and isn't validated against a curated list. The migration prompt explicitly recommends keeping a `groups` declaration in the config "when existing `group` frontmatter should continue to validate." If you want the strict "unknown group fails the build" guarantee, keep `groups` declared.
