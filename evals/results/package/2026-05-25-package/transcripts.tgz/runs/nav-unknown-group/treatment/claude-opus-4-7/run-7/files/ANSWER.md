# Navigation in a leadtype project: `nav` vs `group`

> Sources: `node_modules/leadtype/docs/authoring/frontmatter.md`,
> `node_modules/leadtype/docs/changelog/nav-migration-prompts.md`.

## 1. Relationship between config `nav` and frontmatter `group`

**Config-owned `nav` is the source of truth for curated navigation.** It
drives every reader- and agent-facing surface that depends on structure:

- The site's top-level docs areas (e.g. Docs / Reference / Changelog tabs).
- The sidebar inside the active root node.
- `llms.txt` section headings.
- `AGENTS.md` grouping (the "agent map").
- Sitemap markdown and Agent Readability navigation metadata.

From `docs/authoring/frontmatter.md`:

> `nav` drives top-level docs areas, sidebar structure, `llms.txt`,
> `AGENTS.md`, sitemap markdown, and Agent Readability navigation.

**Frontmatter `group` is now legacy taxonomy / compatibility metadata.**
It is still valid and still does useful work, but it is no longer where you
express intentional navigation. The migration note is explicit:

> `group` is still valid, but it is no longer the best place to express a
> polished navigation. Treat it as taxonomy and compatibility metadata. Put
> intentional navigation in `nav`.

What `group` is still good for:

- **Fallback navigation.** If a project has no `nav` in `docs.config.ts`,
  the CLI falls back to the legacy group resolver and infers a tree from the
  `group:` values it finds. That is enough for small docs sets.
- **Taxonomy and search facets.** A page can declare multiple group slugs
  (`group: [a, b]`) so it shows up under more than one taxonomy bucket. The
  frontmatter doc lists "search facets, and broad taxonomy" as the surviving
  role for `group`.
- **Compatibility** with existing pipelines and sidebars that still read
  `group` directly.

A related field worth knowing about: `order` is no longer needed for curated
ordering once you use `nav` with explicit page strings. Keep `order` only as
a fallback sort key for pages pulled in by wildcard `{ include: "*" }`
entries.

**Rule of thumb when onboarding**

- Want to change where a page appears in the sidebar / agent map?
  Edit `nav` in `docs.config.ts`.
- Want to tag a page for search/taxonomy or keep an older consumer working?
  Set `group` in the page's frontmatter.

## 2. What happens at build time if a page's `group` slug is unknown to the config?

**The build fails.** Groups are validated against the `groups` declared in
`docs.config.ts`. From `docs/authoring/frontmatter.md`:

> If a page declares a group slug that isn't in `docs.config.ts`, the build
> fails with `unknown group "<slug>"`. Same source of truth, no drift.

So `group` is permissive in role (legacy/taxonomy) but strict in
validation: any slug a page uses must be declared once in the config's
`groups` list, or `leadtype generate` / `leadtype lint` will reject it.
This is intentional — it prevents silent drift between frontmatter and the
configured taxonomy.

To fix an `unknown group "<slug>"` error you have two options:

1. Add the slug to `groups` in `docs.config.ts` (with a `title`, and
   optional nested `children` for deeper trees — only leaf groups hold
   pages).
2. Remove or rename the `group:` value on the page so it matches an
   existing slug (or drop it entirely if `nav` already places the page).
