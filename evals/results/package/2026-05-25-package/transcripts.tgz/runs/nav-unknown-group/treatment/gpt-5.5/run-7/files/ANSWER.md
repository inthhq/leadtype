# Navigation and legacy groups in Leadtype

1. **`nav` is the curated source of truth.** The `nav` array in `docs.config.ts` is what should drive intentional docs structure: top-level docs areas/tabs, sidebar sections, `llms.txt`, `AGENTS.md`, sitemap markdown, and Agent Readability/agent-map navigation. A page's frontmatter `group` field is legacy metadata; it no longer decides where a page belongs in a curated sidebar when `nav` is present. It is still useful for older/fallback group-based navigation, broad taxonomy, compatibility with existing docs, and search/filter facets.

2. **Unknown legacy groups fail the build when groups are configured.** If a page declares `group: some-slug` and the loaded config's legacy `groups` list does not contain that slug, Leadtype treats it as broken navigation metadata. `leadtype generate` fails before publishing artifacts with an error like:

   ```text
   /docs/example declares unknown group "some-slug"
   ```

   In other words, `nav` controls curated placement, but any legacy `group` values you keep must still match the configured legacy `groups` if you want them validated; otherwise remove or update the stale group metadata.
