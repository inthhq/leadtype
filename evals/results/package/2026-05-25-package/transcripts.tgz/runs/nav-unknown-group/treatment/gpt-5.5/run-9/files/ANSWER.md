# Leadtype navigation notes

1. **`docs.config.ts` `nav` is the curated navigation source of truth.** When `nav` is present, it drives the resolved navigation tree used by the human sidebar/top-level docs areas, `llms.txt`, `AGENTS.md`, sitemap markdown, and Agent Readability/agent-map metadata. A page's legacy `group` frontmatter does **not** decide its placement in that curated sidebar/agent map. `group` is still useful as compatibility/taxonomy metadata: it powers the legacy fallback navigation for projects that have not adopted `nav`, and it can still be used for broad taxonomy/search or filter facets.

2. **An unknown `group` slug fails the build when Leadtype has configured groups to validate against.** During generation/navigation resolution, Leadtype checks page `group` values against the known `groups` from config; if a page names a slug that is not known, generation fails fast with an error like:

   ```text
   /docs/some-page declares unknown group "some-slug"
   ```

   This is intentional: broken navigation/taxonomy is treated as a content/config bug rather than something to discover at render time. If there is no config/group set to validate against, Leadtype can infer legacy groups from frontmatter as a fallback, but once the config owns the taxonomy, unknown slugs are errors.
