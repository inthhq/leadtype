# Navigation in Leadtype: `nav` vs. `group`

## 1. Relationship between config `nav` and page `group` frontmatter — which drives what?

**The config `nav` is the primary source of truth and drives the sidebar and agent map.**

- **`nav` drives:** Curated top-level docs areas, sidebar structure, `llms.txt` section headings, `AGENTS.md` grouping, sitemap markdown, and Agent Readability navigation metadata. It's the intentional structure that powers human navigation (sidebars, tabs) and agent-facing document organization.

- **`group` is still valid but is now secondary.** It serves as:
  - **Taxonomy/compatibility metadata** for broad classification across docs
  - **Fallback for search facets** and legacy navigation systems
  - **Fallback sorting** when pages are pulled in via `include` directives in nav config

In projects that have adopted `nav`, frontmatter `group` is optional and treated as metadata rather than the authoritative navigation signal. In legacy projects without `nav`, the CLI falls back to inferring groups from the `group:` values it finds in pages and generates navigation from those — but this fallback is only recommended for small docs sets.

```mermaid
flowchart LR
  nav["config nav<br/>drives sidebar, llms.txt,<br/>AGENTS.md, agent maps"]
  group["page group<br/>taxonomy metadata,<br/>search facets,<br/>legacy fallback"]
  sidebar["sidebar structure"]
  agent["agent navigation"]
  nav --> sidebar
  nav --> agent
  group -.-> sidebar
  group -.-> agent
```

The same resolved tree powers all human and agent surfaces — when you curate navigation in `docs.config.ts`, every surface (sidebar, `llms.txt`, `AGENTS.md`, Agent Readability) stays aligned.

## 2. What happens at build time if a page declares a `group` slug that the config doesn't know about?

**The build fails with an error: `unknown group "<slug>"`.**

Leadtype enforces the same source of truth for both config and frontmatter. If a page's frontmatter declares `group: "unknown-slug"` but `docs.config.ts` doesn't declare that group (either in `nav` entries or in the legacy `groups` array), the `leadtype lint` command will raise a `schema` error before generation even begins:

```
unknown group "unknown-slug"
```

This strict validation happens during the lint phase (run before `leadtype generate` in the build pipeline) and prevents drift between authored pages and declared navigation structure. There is no silent fallback or implicit group creation — you must either:

1. Add the group to `docs.config.ts` (modern `nav` approach), or
2. Declare it in a legacy `groups` array in config if you're not yet using `nav`

This same-source-of-truth contract ensures that navigation, `llms.txt`, `AGENTS.md`, and agent-readable metadata all reflect the same structure.
