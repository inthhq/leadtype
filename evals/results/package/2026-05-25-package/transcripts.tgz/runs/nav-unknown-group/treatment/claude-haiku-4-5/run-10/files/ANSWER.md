# Navigation in Leadtype: Config vs. Frontmatter Groups

## 1. The Relationship Between `nav` Config and `group` Frontmatter

### What Drives Sidebar and Agent Map

**The curated `nav` in `docs.config.ts` is the primary driver** for:
- Sidebar structure and ordering
- The navigation tree in `llms.txt` section headings
- The organization in `AGENTS.md`
- Agent Readability navigation metadata
- Sitemap markdown structure
- Overall agent-facing document maps

### What the Legacy `group` Field is Good For

The `group` frontmatter field is a **legacy taxonomy and compatibility mechanism**. It remains useful for:

1. **Fallback Navigation** — If you don't have a curated `nav` in `docs.config.ts`, Leadtype will infer and resolve the navigation tree from `group` values found across all pages. This fallback is sufficient for small docs sets but lacks the polish of config-owned navigation.

2. **Search Metadata** — Pages can still use `group` (as a string or array: `group: authoring` or `group: [a, b]`) to populate search facets and provide cross-framework or multi-group taxonomy information.

3. **Backwards Compatibility** — Existing pages declaring `group` will continue to validate and resolve correctly, allowing gradual migration.

### The Mental Model

```
docs.config.ts nav
        ↓
   [drives] →  Sidebar structure
                llms.txt sections
                AGENTS.md grouping
                Agent Readability nav

Page frontmatter group
        ↓
   [provides] → Fallback taxonomy (if no nav)
                Search facets
                Multi-membership hints
```

**Best practice:** Use explicit `nav` in `docs.config.ts` for intentional structure, and keep `group` as optional taxonomy metadata only.

---

## 2. What Happens at Build Time with Unknown Group Slugs

### Build Failure with Error Message

If a page declares a `group` slug that **doesn't exist in `docs.config.ts`**, the build **fails with an error**:

```
unknown group "<slug>"
```

### Why This Happens

From the frontmatter documentation:

> If a page declares a group slug that isn't in `docs.config.ts`, the build fails with `unknown group "<slug>"`. Same source of truth, no drift.

This is an intentional schema validation check enforced by `leadtype lint`. It prevents:
- Typos in group slugs
- Orphaned pages with invalid group references
- Silent misconfigurations that could cause pages to disappear from navigation unexpectedly

### How to Fix

1. **Add the group to config** — If the group is intentional, declare it in `docs.config.ts`:
   ```ts
   groups: [
     { slug: "my-group", title: "My Group" },
   ]
   ```

2. **Remove or correct the group reference** — If the page shouldn't declare that group, remove or fix it:
   ```mdx
   ---
   title: "My Page"
   group: "existing-group"  # must match a known slug
   ---
   ```

3. **Migrate to config `nav`** — For new docs sites or migrations, prefer defining navigation structure in `nav` rather than relying on `group` at all.

This tight coupling between frontmatter and config prevents drift and ensures both human-facing and agent-facing outputs stay consistent.
