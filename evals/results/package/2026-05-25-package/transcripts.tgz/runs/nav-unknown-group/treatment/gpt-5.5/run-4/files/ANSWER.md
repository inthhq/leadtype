# Leadtype navigation answer

1. In current Leadtype projects, the curated `nav` in `docs.config.ts` is the source of truth for intentional navigation. When `nav` is present, it drives the resolved navigation tree used by the human sidebar/top-level docs areas and by agent-facing maps such as `llms.txt`, `AGENTS.md`, sitemap markdown, and Agent Readability metadata.

   The page frontmatter `group` field is legacy taxonomy metadata. It is still valid and useful for projects that have not migrated to `nav` (the legacy group resolver can build fallback navigation from configured `groups` plus page `group` values), and it can still serve as broad taxonomy/search-filter metadata. It is not where you should express curated sidebar structure once `nav` exists.

2. If a page declares a `group` slug that the configured legacy `groups` list does not know about, generation fails during navigation validation. The CLI reports an error in the form:

   ```text
   /docs/<page> declares unknown group "<slug>"
   ```

   This is deliberate: Leadtype treats a group/config mismatch as broken navigation metadata, not as something to silently ignore at render time. If you keep `group` frontmatter around for taxonomy/compatibility, keep the matching `groups` declarations in config so those slugs remain validated; otherwise prefer placing pages with `nav`.
