# Navigation: `nav` vs. `group` in Leadtype

Sources consulted (all from `node_modules/leadtype/docs/`):
- `authoring/frontmatter.md`
- `how-it-works.md`
- `changelog/nav-migration-prompts.md`
- `reference/lint.md`
- `sources/collections.md`
- `sources/configure-sources.md`

---

## 1. Which one drives the sidebar and agent map, and what is the other still good for?

**`nav` in `docs.config.ts` is the authoritative driver.** It owns the entire curated
navigation tree — the sidebar structure, top-level docs areas (tabs), sidebar
section ordering, `llms.txt` sections, `AGENTS.md` groupings, the sitemap
markdown, and the Agent Readability metadata. In short, every surface a human
browser and every surface an AI agent uses to discover and traverse the docs is
derived from the single resolved `nav` tree. The `frontmatter.md` doc states
this explicitly:

> "`nav` drives top-level docs areas, sidebar structure, `llms.txt`, `AGENTS.md`,
> sitemap markdown, and Agent Readability navigation."

The `nav` node shape supports `base` (path prefix that cascades to children),
explicit `pages` arrays, nested `children` nodes for multi-level sections, and
`{ include: "glob/*", sort: [...] }` entries for wildcard placement — giving you
full, intentional control over presentation order and information architecture.

**`group` (the page-level frontmatter field) is legacy taxonomy metadata.** It is
still valid and still read by the pipeline, but it is no longer the *owner* of
navigation structure. Its remaining useful roles are:

| Role | Detail |
|---|---|
| **Legacy fallback navigation** | When a project has *no* `nav` in config, the CLI falls back to a group resolver that builds a nav tree from the `group:` values it discovers across all pages. This fallback is enough for small, unstyled doc sets. |
| **Search facets** | The resolved group slug travels with each page into the search index, where it can be used as a filter facet at query time. |
| **Broad taxonomy / compatibility metadata** | `group` may be an array (`group: [a, b]`), so a page can belong to more than one taxonomy bucket. This is useful for cross-linking or for marking shared pages that should appear under multiple product areas without duplicating MDX files. |
| **Validation anchor (with `groups:` in config)** | When legacy groups *are* still declared in `docs.config.ts` under `groups:`, they serve as the allowed-slug registry that the build validates page-level `group:` values against (see question 2). |

The migration changelog (`changelog/nav-migration-prompts.md`) puts it plainly:

> "`group` is still valid, but it is no longer the best place to express a
> polished navigation. Treat it as taxonomy and compatibility metadata. Put
> intentional navigation in `nav`."

### How they interact at runtime

```
docs.config.ts  ──nav──►  resolved nav tree ──►  sidebar
                                               ──►  llms.txt sections
                                               ──►  AGENTS.md sections
                                               ──►  Agent Readability / sitemap

page frontmatter ──group──►  (legacy fallback when nav absent)
                          ──►  search facet metadata
                          ──►  taxonomy / cross-group membership
```

When `nav` is present, the group resolver is bypassed for all navigation
rendering; `group` values ride along as metadata only.

---

## 2. What happens at build time if a page declares a `group` slug the config doesn't know about?

**The build fails with a hard error.**

Specifically, `leadtype generate` runs group resolution as step 3 in its fixed
pipeline sequence (after frontmatter parsing and MDX conversion). During that
step every page's `group:` value is checked against the set of slugs declared in
`docs.config.ts`. If a slug is not found, the run aborts immediately with:

> `unknown group "<slug>"`

This is intentional, not a warning. The `how-it-works.md` doc states:

> "If step 3 finds an unknown group, the run fails. That is by design — broken
> navigation is a content bug, not a render-time problem."

And `authoring/frontmatter.md` reinforces the same rule:

> "If a page declares a group slug that isn't in `docs.config.ts`, the build
> fails with `unknown group "<slug>"`. Same source of truth, no drift."

The design goal is to prevent silent drift between what pages claim they belong
to and what the config actually defines. Because both `llms.txt`, `AGENTS.md`,
and the sidebar all derive from the same resolved tree, an unknown group would
produce inconsistent or missing navigation on every surface at once — so the
pipeline treats it as a hard content bug rather than a recoverable warning.

### Practical implication

If you add a new group slug to a page's `group:` frontmatter, you **must** also
add a matching entry to the `groups:` array in `docs.config.ts` (or add the page
to the `nav` tree) before running `leadtype generate` — or the build will fail.
`leadtype lint` will catch the same violation *before* generate if you run it
first in CI, which is the recommended order:

```bash
npx leadtype lint docs --error-unknown   # catches unknown groups early, with file context
npx leadtype generate --src . --out public --json
```
