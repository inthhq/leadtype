# Navigation in Leadtype: Config `nav` vs. Page `group` Frontmatter

## 1. Which one drives the sidebar and agent map?

**The curated `nav` in `docs.config.ts` is the primary source of truth** for sidebar and agent map structure.

### What drives what

From the frontmatter documentation in leadtype:

> For curated docs sites, put the navigation structure in `docs.config.ts` with `nav`. Root nodes can become top-level tabs like Docs, Frontend, Integrations, or Changelog. The active root node's pages and children usually become the sidebar. **The same resolved tree drives generated navigation, `llms.txt`, `AGENTS.md`, sitemap markdown, and Agent Readability metadata.**

**Config `nav` controls:**
- Sidebar structure and ordering
- Top-level tabs in the docs site
- `llms.txt` section organization
- `AGENTS.md` grouping for bundled agent docs
- Agent map structure used by agents to discover and route to content
- Sitemap organization
- Agent Readability navigation metadata

### What `group` is still good for

The `group` frontmatter field is a **legacy taxonomy metadata** field that remains useful for:
- **Search facets**: Pages can be filtered/tagged by group in search results
- **Fallback navigation**: In projects that haven't adopted `nav` yet, the CLI falls back to inferring groups from `group:` field values and builds a basic navigation tree from them
- **Broad taxonomy**: Acts as a secondary classification for content organization purposes

From the documentation:

> `group` remains available for legacy navigation fallback, search facets, and broad taxonomy.

## 2. What happens at build time if a page declares a `group` slug that the config doesn't know about?

**The build fails with an error.**

When `docs.config.ts` defines a `nav` configuration, it becomes the source of truth for known groups. If a page declares a `group` slug that isn't in the resolved navigation config, the build immediately exits with status code 1.

### The error behavior

From the frontmatter documentation:

> If a page declares a group slug that isn't in `docs.config.ts`, **the build fails with `unknown group "<slug>"`**. Same source of truth, no drift.

From the how-it-works documentation:

> If step 3 finds an unknown group, the run fails. **That is by design — broken navigation is a content bug, not a render-time problem.**

### Why this design

This strict validation ensures:
- **No silent drift**: The sidebar, `llms.txt`, `AGENTS.md`, and agent maps all use the same navigation structure
- **Early failure**: Build-time errors surface immediately in CI rather than leaving broken links or missing pages in production
- **Content integrity**: Navigation is treated as a schema that must be enforced, not a suggestion

From the CLI documentation:

> Exit codes: `0` success, `1` runtime error (docs dir missing, config load error, **unknown group**, conversion error, sync failure), `2` CLI usage error.

### The fallback mode

There is a legacy fallback: if no `nav` is configured in `docs.config.ts`, the CLI can infer groups from the union of `group:` values it finds across pages. However, this fallback is only for projects that haven't yet adopted `nav`. Once you define `nav` in your config, every page's `group` declaration must match a known group in that config.

