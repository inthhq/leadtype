# Navigation in Leadtype: `nav` vs `group`

## 1. Relationship Between `nav` Config and `group` Frontmatter

### Which One Drives What

**`nav` in `docs.config.ts` drives the sidebar and agent map.** It is the primary navigation source for curated docs sites.

**`group` in frontmatter is legacy taxonomy metadata** that remains useful for fallback and compatibility, but does not drive the primary navigation experience.

### The Distinction

When a Leadtype project adopts the modern `nav` approach:

- **`nav` is curated structure** defined in `docs.config.ts`. It determines:
  - Top-level docs areas (e.g., Docs, Guides, Reference, Changelog)
  - Sidebar order and hierarchy
  - Navigation rendering for humans
  - The agent map in `llms.txt` and `AGENTS.md`
  - Sitemap markdown
  - Agent Readability metadata

- **`group` remains useful for**:
  - Legacy fallback navigation in projects that haven't adopted `nav` yet
  - Search facets and broad taxonomy classification
  - Supporting pages that belong to multiple categories
  - Validation: confirming pages declare only known group slugs

### How They Work Together

The relationship is documented with this flow:

```
docs.config.ts → nav drives the primary tree
               → also declares group slugs for validation
page frontmatter → group field must match a known slug from config
                → pages use group for compatibility and taxonomy
```

When `nav` exists in your config, it takes precedence. The `group` field becomes optional secondary metadata. When `nav` does not exist, the system falls back to group-based resolution: each unique `group:` slug found in pages must be declared in `docs.config.ts` groups, and that forms the navigation tree instead.

### What This Gives You

Once frontmatter and config are consistent:
- **Human experience**: `nav` drives the sidebar structure readers navigate
- **Agent experience**: `nav` drives the sections in `llms.txt` and `AGENTS.md` that agents use for discovery
- **Validation**: declared `group` slugs must match known groups in config (whether from `nav` or `groups`), preventing drift
- **Flexibility**: pages can still declare `group` for fallback sorting and search metadata without affecting primary sidebar navigation

## 2. Build-Time Behavior with Unknown Group Slugs

### What Happens

If a page declares a `group` slug that the config doesn't know about, **the build fails with an error**.

Specifically:
- `leadtype generate` runs in this order: parse frontmatter → convert to markdown → **resolve groups** → generate site artifacts
- At step 3 (resolve groups), if any page's `group:` value doesn't match a slug in the config, the command exits with exit code `1` (runtime error)
- The error message is: `<urlPath> declares unknown group "<slug>"`

### Why This Design

This is intentional. From the documentation:

> "If a page declares a group slug that isn't in `docs.config.ts`, the build fails with `unknown group "<slug>"`. Same source of truth, no drift."

And further:

> "If step 3 finds an unknown group, the run fails. That is by design — broken navigation is a content bug, not a render-time problem."

### The Principle

Leadtype treats navigation configuration as a **content contract**. Every group slug a page claims must be explicitly declared in the config. This prevents:
- Typos in group names going unnoticed
- Pages drifting into unintended categories
- Silent failures where pages end up in the wrong section

This is why you should:
1. Run `leadtype lint` in CI before generation to catch schema and link issues with file/line context
2. Run `leadtype generate` to catch structural issues (unknown groups, broken includes) with noisy failures
3. Treat `unknown group` as a content bug to fix, not a render-time problem to work around

### Exit Code Reference

- `0`: success
- `1`: runtime error (includes unknown group, missing docs dir, config load error, conversion error, sync failure)
- `2`: CLI usage error
