# Navigation: `nav` vs `group` in Leadtype

Sources consulted: `node_modules/leadtype/AGENTS.md`, `docs/authoring/frontmatter.md`,
`docs/reference/llm.md`, `docs/reference/lint.md`, `docs/changelog/nav-migration-prompts.md`,
`docs/sources/configure-sources.md`, and `docs/build/validate-in-ci.md` (all inside the
installed `leadtype` package).

---

## 1. Which one drives the sidebar and agent map, and what is the other still good for?

### `nav` in `docs.config.ts` — the authoritative driver

Config-owned `nav` is the primary, intentional source of truth for **all** navigation
surfaces. When `nav` is present, the same resolved tree drives every consumer:

| Consumer | What `nav` produces |
|---|---|
| Sidebar / top nav tabs | Root `nav` nodes → top-level tabs; active node's children → sidebar sections |
| `llms.txt` | Section headings and page links (one section per `nav` node) |
| `AGENTS.md` (npm bundle) | Group headings and relative `./docs/*.md` links |
| `sitemap.md` | Heading structure and page links |
| `agent-readability.json` | Structured navigation manifest consumed by runtime helpers |
| `resolveDocsNavigation()` | The plain-object nav manifest you import into your UI shell |

`nav` supports the full, polished IA: root nodes for tabs, nested children for sidebar
sections, explicit page ordering, `base` path cascading, and wildcard `{ include }` entries
with sort control. This is what you reach for when you need stable top-level areas, nested
sections, or any intentional ordering. The leadtype docs put it plainly:

> "The active root node's pages and children usually become the sidebar. The same resolved
> tree drives generated navigation, `llms.txt`, `AGENTS.md`, sitemap markdown, and Agent
> Readability metadata."
> — `docs/authoring/frontmatter.md`

> "Config `nav` drives `llms.txt` sections, navigation, sitemap markdown, Agent Readability
> navigation, and `AGENTS.md` when present."
> — `docs/reference/llm.md`

### `group` frontmatter — legacy fallback + taxonomy

The per-page `group: <slug>` (or `group: [a, b]`) field is described as **optional legacy
taxonomy metadata**. Its roles are:

1. **Legacy navigation fallback.** If `docs.config.ts` has *no* `nav` array, `leadtype
   generate` falls back to the old group resolver: it reads `group` values out of every
   page's frontmatter and uses the `groups` list in config to infer section order. This is
   enough for small docs sets but lacks the expressiveness of `nav`.

2. **Search facets and taxonomy metadata.** Even in a project that fully uses `nav`, `group`
   values still propagate into the search index and `DocsPageMeta.groups`. This lets you
   filter or facet search results by taxonomy without that taxonomy controlling the IA.

3. **Cross-collection tagging.** A page can belong to multiple groups (`group: [a, b]`) for
   broad classification, while `nav` determines exactly where it appears in the sidebar.

The migration guide summarises the intent clearly:

> "Treat it [group] as taxonomy and compatibility metadata. Put intentional navigation in
> `nav`."
> — `docs/changelog/nav-migration-prompts.md`

### Bottom line

| Field | Drives sidebar / agent map? | Still useful for |
|---|---|---|
| `nav` in `docs.config.ts` | **Yes — primary driver** | Everything navigation-related |
| `group` frontmatter | No (when `nav` exists) | Legacy fallback, search facets, taxonomy tagging |

---

## 2. What happens at build time if a page declares a `group` slug the config doesn't know about?

**The build fails with an `unknown group "<slug>"` error.**

The `group` field and the config `groups` list form a single source of truth. Every slug a
page declares must be present in `docs.config.ts` — there is no silent fallback or
best-guess behaviour. The frontmatter docs state it directly:

> "If a page declares a group slug that isn't in `docs.config.ts`, the build fails with
> `unknown group "<slug>"`. Same source of truth, no drift."
> — `docs/authoring/frontmatter.md`

The `resolveDocsNavigation()` API surface mirrors this: the returned object includes an
`unknown` array, and the canonical usage pattern shown in `docs/reference/llm.md` is to
check that array and call `process.exit(1)` if it is non-empty:

```ts
const navigation = await resolveDocsNavigation({ srcDir: ".", baseUrl: "...", nav: docsConfig.nav });

if (navigation.unknown.length > 0) {
  for (const { urlPath, slug } of navigation.unknown) {
    process.stderr.write(`error: ${urlPath} declares unknown group "${slug}".\n`);
  }
  process.exit(1);
}
```

`leadtype lint` will also surface the problem *before* generation (as a `schema`-level
violation), and the `validate-in-ci.md` guide explicitly recommends running lint first
precisely because `leadtype generate` "fails noisily on unknown groups" — lint gives you the
specific file and line context needed to debug it quickly.

### Practical consequences

* **CI will break.** Both `leadtype lint --error-unknown` and `leadtype generate` exit
  non-zero, so a PR that introduces an unknown group will fail before any artifacts are
  written.
* **No partial output.** The failure is hard — no `llms.txt`, no markdown mirrors, no
  search index is written for that run.
* **Fix path.** Either (a) add the missing slug to the `groups` array in `docs.config.ts`,
  or (b) change the page's `group` value to match an existing slug. If you are mid-migration
  to `nav`, the `nav-migration-prompts.md` guide notes you should keep the `groups` list in
  config intact as long as any page still carries a matching `group` frontmatter value.
