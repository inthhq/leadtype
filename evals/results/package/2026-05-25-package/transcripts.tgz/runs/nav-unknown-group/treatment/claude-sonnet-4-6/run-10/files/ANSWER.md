# Navigation: `nav` vs `group` in Leadtype

## 1. Relationship between `nav` (in `docs.config.ts`) and the legacy `group` frontmatter field

### `nav` is the authoritative driver

The curated `nav` array in `docs.config.ts` is the **single source of truth** for
all navigation surfaces. Once `nav` is present, it drives:

- The **sidebar** (human-facing, rendered in the browser)
- The **agent map** — `llms.txt`, `llms-full.txt`, `AGENTS.md`, sitemap
  markdown, and the `agent-readability.json` manifest
- Top-level tab structure and nested section headings
- The resolved tree returned by `getNavigation()` through the source primitive

`nav` is deliberately config-owned (not scattered across individual page
files) so that the intended information architecture versions in one place and
is never accidentally altered by a single-page frontmatter edit.

### `group` is legacy taxonomy / compatibility metadata

The frontmatter `group` field pre-dates `nav`. In projects that have **not yet
adopted `nav`**, `leadtype generate` falls back to the legacy group resolver:
it reads the `groups` list from `docs.config.ts` and matches each page's
`group:` value against it to produce a fallback navigation tree, section
headings in `llms.txt`, and `AGENTS.md` groupings.

Once `nav` exists in the config, `group` is demoted. It is **still valid and
still read**, but it no longer drives the sidebar or the agent map. Instead it
is useful for:

| Remaining use of `group` | Why it still matters |
|---|---|
| **Taxonomy / search facets** | Pages can be tagged with broad category slugs that power search facets and filtering independently of sidebar structure. |
| **Compatibility metadata** | A page shared across multiple top-level nav areas can carry `group: [a, b]` to communicate its logical ownership to tooling and humans without changing its resolved nav position. |
| **Legacy fallback nav** (no `nav` present) | Small docs sets that have not migrated yet still get a working sidebar and `llms.txt` sections purely from `group` values. |
| **`include`-based sort hint** | `order` (a closely related field) and `group` remain valid fallback sorting signals when pages are pulled in by wildcard `include` entries. |

The one-sentence summary from the docs is precise: *"Use config-owned `nav`
for curated page placement. Treat `group` as taxonomy and compatibility
metadata."*

---

## 2. What happens at build time when a page declares an unknown `group` slug

If a page's frontmatter contains a `group` value (e.g. `group: widgets`) and
that slug is **not** declared in the `groups` list of `docs.config.ts`, the
build fails with:

```
unknown group "widgets"
```

This is an intentional hard error, not a warning. The design principle is
**same source of truth, no drift**: every slug that a page claims to belong to
must be explicitly registered in the config. If the config is the canonical
list of valid groups and a page references one that is absent, the mismatch is
caught immediately at build time rather than silently producing a broken or
incomplete navigation tree or agent map.

Practical implications:

- Adding a new group to a page always requires a matching entry in
  `docs.config.ts` first (or simultaneously).
- Renaming or removing a group in the config will fail the build for every
  page that still references the old slug — which is the correct behavior
  because it surfaces all the stale references at once.
- The same guard applies whether the project is using legacy `group`-based nav
  or has already migrated to `nav`; the `groups` registration list is still
  consulted for slug validation when `group` frontmatter is present.
