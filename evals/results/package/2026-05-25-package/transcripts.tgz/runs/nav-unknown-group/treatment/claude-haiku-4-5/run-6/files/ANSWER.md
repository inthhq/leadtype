# Navigation in Leadtype: Config `nav` vs. Legacy `group`

## 1. Relationship Between Config `nav` and Legacy `group`

### Which drives the sidebar and agent map?

**The curated `nav` in `docs.config.ts` drives the sidebar and agent map.**

The `nav` configuration is the source of truth for:
- Top-level docs areas (e.g., Docs, Frontend, Integrations, Changelog tabs)
- Sidebar structure and ordering
- Section headings in `llms.txt`
- Navigation structure in `AGENTS.md`
- Sitemap markdown organization
- Agent Readability metadata

### What is the legacy `group` field still good for?

The `group` frontmatter field remains available for:
- **Legacy navigation fallback** — In older projects that have not adopted `nav`, pages can still declare groups that the config resolves into a fallback navigation tree
- **Search facets and filtering** — Metadata for categorizing pages in search results
- **Broad taxonomy** — A way to tag pages across multiple taxonomy dimensions even when config-driven nav is the primary structure
- **Backward compatibility** — Existing docs sets can keep their `group` values while migrating to config-owned `nav`

### Mental model

When `docs.config.ts` defines a curated `nav`, the group field becomes optional taxonomy metadata. The resolved `nav` tree drives all navigation surfaces (sidebar, llms.txt sections, AGENTS.md structure). When no `nav` exists, the pipeline falls back to inferring groups from the union of `group:` values found across pages—this fallback is sufficient for small docs sets but lacks stable ordering and nested sections.

---

## 2. Build-Time Behavior: Undeclared Group Slugs

### What happens if a page declares a `group` slug that the config doesn't know about?

**The build fails with an error: `unknown group "<slug>"`.**

From the frontmatter documentation:

> If a page declares a group slug that isn't in `docs.config.ts`, the build fails with `unknown group "<slug>"`. Same source of truth, no drift.

This applies specifically to **fallback mode** — when the project relies on legacy groups because it does not have a curated `nav` defined. The config acts as a validation gate to prevent typos and ensure consistency.

### Key implications

1. **In fallback mode (no `nav` in config):** All group slugs must be pre-declared in the config's `groups` array or the build stops.

2. **When using config `nav`:** The `group` field is optional taxonomy metadata and is not subject to the same strict validation — the navigation tree is driven entirely by `nav`, not by scanning frontmatter groups.

3. **Validation timing:** This check occurs during `leadtype generate` and can be caught earlier with `leadtype lint`.

This design ensures **one source of truth**: if you're in fallback mode, the config declares every navigation dimension, and every page's group reference must match something in that config. This prevents silent orphaning of pages or accidental taxonomy drift.
