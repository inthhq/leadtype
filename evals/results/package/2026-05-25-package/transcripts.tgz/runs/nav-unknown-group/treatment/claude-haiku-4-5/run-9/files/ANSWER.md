# Navigation in Leadtype: `nav` vs. Legacy `group` Frontmatter

## 1. The Relationship Between `nav` Config and `group` Frontmatter

### Which Drives the Sidebar and Agent Map?

**The `nav` field in `docs.config.ts` drives the sidebar and agent map.** It is the primary, curated navigation structure that determines:

- Top-level tabs and navigation areas
- Sidebar ordering and nesting
- `llms.txt` section headings and structure
- `AGENTS.md` grouping (for bundled package docs)
- Sitemap markdown organization
- Agent Readability metadata navigation

### What is `group` Still Good For?

The legacy `group` frontmatter field serves two purposes:

1. **Backward Compatibility & Fallback**: In projects that have not yet adopted the `nav` config API, the `group` field provides a fallback navigation mechanism. Each page declares one or more group slugs (`group: "slug"` or `group: ["slug1", "slug2"]`), and these groups are declared once in `docs.config.ts`. The intersection of page groups and config groups produces the fallback navigation tree, section headings, and `AGENTS.md` grouping.

2. **Taxonomy & Metadata**: Even when `nav` is the primary navigation driver, `group` remains useful as taxonomy metadata. It can be used for:
   - Search faceting and filtering
   - Broad documentation taxonomy (pages can belong to multiple categories)
   - Non-rendering metadata that your application may reference

### The Mental Model

When `nav` is present in your config, it **owns** the navigation structure. The `group` field becomes optional taxonomy metadata. When `nav` is absent, the system falls back to resolving groups from page frontmatter and config declarations.

```mermaid
flowchart LR
    config["docs.config.ts<br/>nav (curated structure)"]
    group["page frontmatter<br/>group (taxonomy)"]
    nav["Navigation Tree<br/>(sidebar, llms.txt, AGENTS.md)"]
    
    config -->|drives| nav
    group -->|optional metadata| nav
```

---

## 2. Build-Time Behavior for Unknown Groups

### What Happens When a Page Declares an Unknown Group?

**The build fails with an error: `unknown group "<slug>"`.**

This is by design—it enforces a single source of truth. Specifically:

1. **Config Validation**: When `docs.config.ts` is loaded, it defines all valid group slugs. If a page's frontmatter declares `group: "unknown-slug"` and `"unknown-slug"` is not in the configured groups, the build exits with an error.

2. **Same Source of Truth, No Drift**: This validation rule prevents accidental typos or orphaned group references. Pages cannot belong to groups that don't exist in the config.

3. **Error Behavior**: The `resolveDocsNavigation` function checks for unknown groups and reports them:

   ```ts
   const navigation = await resolveDocsNavigation({
     srcDir: ".",
     baseUrl: "https://leadtype.dev",
     nav: docsConfig.nav,
   });
   
   if (navigation.unknown.length > 0) {
     for (const { urlPath, slug } of navigation.unknown) {
       process.stderr.write(`error: ${urlPath} declares unknown group "${slug}".\n`);
     }
     process.exit(1);
   }
   ```

4. **When This Applies**: This strictness applies when the config has a `groups` declaration. If you do not have `nav` in the config, the CLI falls back to inferring groups from the `group:` values it finds in page frontmatter—in that case, discovering new groups is allowed. But once you declare groups in config, unknown group slugs become a build failure.

### Practical Implications

- **Add the Group First**: Before adding `group: "new-feature"` to a page, ensure `{ slug: "new-feature", title: "..." }` is declared in `docs.config.ts`.
- **Prevents Orphans**: This constraint is a feature—it keeps your navigation config in sync with your actual content and prevents accidentally publishing pages in the wrong category.
- **Migration Checkpoint**: When migrating from frontmatter-only groups to config-owned `nav`, you may need to reconcile which groups are still in use and which can be removed.
