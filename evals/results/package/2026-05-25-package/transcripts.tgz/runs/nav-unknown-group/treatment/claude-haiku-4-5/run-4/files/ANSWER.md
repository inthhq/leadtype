# Navigation in Leadtype: `nav` vs. `group`

## 1. Relationship between `nav` and `group`: Which drives what?

### The Hierarchy

**`nav` (config-owned) is the primary driver.** It is the intended, curated navigation structure that determines:
- **Sidebar structure** — the active root node's pages and children become the rendered sidebar
- **Agent map** — drives `llms.txt`, `AGENTS.md`, sitemap markdown, and Agent Readability metadata
- **Top-level docs areas** — root nav nodes can become top-level tabs (Docs, Frontend, Integrations, Changelog, etc.)

**`group` (frontmatter) is now legacy taxonomy metadata.** It remains valid and is still used for:
- **Backward compatibility** — in projects that have not adopted `nav`, groups are still resolved and validated
- **Search and filtering** — pages can be tagged with `group` slugs for faceted search and taxonomy
- **Fallback validation** — when a `group` slug is declared, it must be known to the config (if config groups exist)

### The Mental Model

Think of it like this:

```mermaid
docs.config.ts (nav)        Page Frontmatter (group)
     ↓                             ↓
  [curated navigation        [taxonomy metadata /
   structure, ordering,       backward compatibility,
   nesting, descriptions]     search facets]
     ↓                             ↓
     └──────────────┬──────────────┘
                    ↓
    Navigation Tree (drives sidebar, llms.txt, AGENTS.md)
```

### When to Use Which

- **Use `nav` for intentional curation** — when order matters, when you have nested sections, when you want wildcard includes (`include: "*"`), or when you're building a polished navigation UX
- **Use `group` only when** — you need backward compatibility with legacy projects, or for search/taxonomy faceting outside the navigation structure

From the leadtype documentation:

> `group` is still valid, but it is no longer the best place to express a polished navigation. Treat it as taxonomy and compatibility metadata. Put intentional navigation in `nav`.

## 2. What happens at build time if a page declares an unknown `group` slug?

### The Error Behavior

**The build fails with exit code 1** and an error message:

```
error: <urlPath> declares unknown group "<slug>".
```

This is a **strict, same-source-of-truth validation**. The config is the authority.

### Why It Fails

The logic works like this:

1. If the config file (`docs.config.ts`) exists and declares `groups` (legacy shape) or `nav` (modern shape), leadtype treats those as the authoritative group registry
2. At generation time, every page's `group` field (if present) is validated against that registry
3. If a page declares a `group: "something"` and `"something"` is not in the config, generation exits with error code 1
4. This prevents silent drift between what pages claim their taxonomy is and what the config knows about

### In Code

From the CLI documentation:

> If a page declares a group slug that isn't in `docs.config.ts`, the build fails with `unknown group "<slug>"`. Same source of truth, no drift.

From the LLM API documentation (`resolveDocsNavigation`), you can check for unknowns:

```ts
const navigation = await resolveDocsNavigation({
  srcDir: ".",
  baseUrl: "https://leadtype.dev",
  nav: docsConfig.nav,
});

if (navigation.unknown.length > 0) {
  for (const { urlPath, slug } of navigation.unknown) {
    process.stderr.write(`error: ${urlPath} declares unknown group "${slug}".\n`);
  }
  process.exit(1);
}
```

### The Rationale

This is intentional design: leadtype enforces a **same source of truth** between pages and config. You cannot accidentally:
- Have a page in an undeclared group
- Drift config groups away from what pages use
- Leave orphaned group references in your docs

This strictness catches errors at build/CI time, not at runtime or in production.

---

## Summary Table

| Aspect | `nav` (config) | `group` (frontmatter) |
|--------|---|---|
| **Primary use** | Curated page structure and sidebar order | Legacy taxonomy, search faceting |
| **Drives** | Sidebar, llms.txt, AGENTS.md, sitemap, Agent Readability | Search metadata, validation (must be known) |
| **Scope** | Root nodes → top-level tabs; nested children → sidebar sections | Page-level metadata; can be one or more slugs |
| **Required?** | No, but recommended | No |
| **If undeclared** | Pages don't appear in nav | Validation error at build time |
| **Unknown value error?** | N/A (nav is explicit) | ✅ **Build fails with exit code 1** |
| **Use wildcard includes?** | Yes: `{ include: "*", sort: ["order", "path"] }` | No |
| **Stability** | Preferred for new projects | Keep for compatibility only |

## Further Reading

- **Migration guide**: See `node_modules/leadtype/docs/changelog/nav-migration-prompts.md` for copy-paste prompts to migrate from legacy groups to config-owned nav
- **Frontmatter spec**: See `node_modules/leadtype/docs/authoring/frontmatter.md` for the full frontmatter schema
- **LLM output**: See `node_modules/leadtype/docs/reference/llm.md` for how nav drives artifact generation
- **Lint rules**: See `node_modules/leadtype/docs/reference/lint.md` for how validation works
