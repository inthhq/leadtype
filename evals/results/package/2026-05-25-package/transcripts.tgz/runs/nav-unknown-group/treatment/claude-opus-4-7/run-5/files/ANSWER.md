# Leadtype navigation: `nav` vs legacy `group`

Both questions below are answered from the bundled leadtype docs
(`node_modules/leadtype/docs/authoring/frontmatter.md` and
`node_modules/leadtype/docs/changelog/nav-migration-prompts.md`).

## 1. Which one drives the sidebar and agent map?

**The curated `nav` array in `docs.config.ts` is the source of truth for
navigation.** It drives every reader-facing and agent-facing surface from a
single resolved tree:

- top-level docs areas / tabs (Docs, Reference, Changelog, …)
- the sidebar within the active root node
- `llms.txt` section structure
- `AGENTS.md` grouping
- sitemap markdown
- Agent Readability navigation metadata

From the frontmatter docs:

> `nav` drives top-level docs areas, sidebar structure, `llms.txt`,
> `AGENTS.md`, sitemap markdown, and Agent Readability navigation.

A page's `group:` frontmatter field is **legacy taxonomy / compatibility
metadata**. It is still useful for:

- **Fallback navigation** when a project hasn't adopted `nav`. The CLI infers
  a nav tree from `group:` values plus the `groups` declared in
  `docs.config.ts`. That's enough for small docs sets, but lacks stable top
  tabs, sidebar order, descriptions, nested sections, and wildcard includes.
- **Search facets and broad taxonomy** — pages can declare multiple groups
  (`group: [a, b]`) so a page can be cross-listed in search/taxonomy without
  affecting curated nav.
- **Validation / lint compatibility** — keeping `groups` declared in config
  lets existing `group:` frontmatter continue to validate during migration.

In short: `nav` = curated navigation + agent map; `group` = taxonomy, search
facets, and a fallback nav resolver when `nav` is absent.

## 2. What if a page declares an unknown `group` slug?

**The build fails.** The group resolver requires every `group` slug used in
frontmatter to be declared in `docs.config.ts`. From
`authoring/frontmatter.md`:

> If a page declares a group slug that isn't in `docs.config.ts`, the build
> fails with `unknown group "<slug>"`. Same source of truth, no drift.

So the two ways to fix the error are:

1. Add the slug (and its title, plus any nested children) to the `groups`
   declaration in `docs.config.ts`, **or**
2. Remove/rename the `group:` value on the page to match an existing slug —
   typically what you want during a `nav` migration where `group` is being
   demoted to pure taxonomy.

Note that only **leaf** groups (no children) directly contain pages; non-leaf
groups in the config are heading-only, so assigning `group:` to a parent slug
is also invalid.
