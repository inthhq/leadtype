# Leadtype navigation: `nav` vs `group`

Sources: `node_modules/leadtype/docs/authoring/frontmatter.md` and `node_modules/leadtype/docs/changelog/nav-migration-prompts.md`.

## 1. Which one drives the sidebar and agent map?

**The curated `nav` array in `docs.config.ts` is the source of truth** for site and agent navigation in any project that has adopted it. Quoting the frontmatter docs:

> `nav` drives top-level docs areas, sidebar structure, `llms.txt`, `AGENTS.md`, sitemap markdown, and Agent Readability navigation.

In other words, the same resolved `nav` tree powers:

- Top-level tabs (root nodes like Docs, Frontend, Integrations, Changelog).
- The human sidebar (the active root node's pages and children).
- `llms.txt` sections.
- The bundled `AGENTS.md` document map.
- Sitemap markdown and Agent Readability metadata.

So if you're trying to figure out *why a page appears where it does in the sidebar or in `AGENTS.md`*, look at `docs.config.ts` `nav`, not at the page's frontmatter.

**`group` is legacy taxonomy/compatibility metadata.** The migration changelog is explicit:

> `group` is still valid, but it is no longer the best place to express a polished navigation. Treat it as taxonomy and compatibility metadata. Put intentional navigation in `nav`.

What `group` is still good for:

- **Legacy navigation fallback.** If a project does not define `nav`, the CLI falls back to the legacy group resolver and infers the nav tree, `llms.txt` sections, and `AGENTS.md` groupings from the `group:` values it finds. That's fine for small docs sets.
- **Search facets / broad taxonomy.** A page can carry multiple group slugs (`group: [a, b]`) and be shared across taxonomy groups even when curated placement is handled by `nav`.
- **Compatibility** with existing tooling and validation while a project is mid-migration.

Sibling field `order` follows the same pattern: it's no longer a primary sorting mechanism, but it remains useful as a *fallback sort key* for pages that `nav` pulls in via wildcard `{ include: "..." }` entries (`sort: ["order", "path"]`).

## 2. What happens at build time if a page declares an unknown `group`?

**The build fails.** From `docs/authoring/frontmatter.md`:

> If a page declares a group slug that isn't in `docs.config.ts`, the build fails with `unknown group "<slug>"`. Same source of truth, no drift.

So even though `group` is legacy, it is still validated against the `groups` declared in `docs.config.ts`. There is no silent ignoring and no implicit group creation — every slug a page uses must be declared in config (either as a top-level group or as a nested child under `children`). This is what keeps the legacy taxonomy honest while teams migrate to config-owned `nav`.

Practical takeaway while onboarding:

- To change where a page shows up in the sidebar / `AGENTS.md` / `llms.txt`, edit `nav` in `docs.config.ts`.
- Keep `group` on pages only as taxonomy; make sure every slug you use is declared in `docs.config.ts` `groups` or you'll get an `unknown group "<slug>"` build error.
- Use `order` only as a tiebreaker for wildcard `include` entries in `nav`.
