# Navigation in a Leadtype docs project

Sourced from the installed `leadtype` package — primarily
`node_modules/leadtype/docs/authoring/frontmatter.md` and
`node_modules/leadtype/docs/changelog/nav-migration-prompts.md`.

## 1. `nav` (in `docs.config.ts`) vs. legacy `group` frontmatter

**The curated `nav` array in `docs.config.ts` is the source of truth.** It is
what drives every navigation-shaped surface that Leadtype generates from one
resolved tree:

- top-level docs areas / tabs (Docs, Frontend, Integrations, Changelog, …)
- the human sidebar (the active root node's pages and children)
- `llms.txt`
- `AGENTS.md` (the agent map bundled into the npm tarball)
- sitemap markdown
- Agent Readability navigation metadata

Quoting the frontmatter doc directly: *"`nav` drives top-level docs areas,
sidebar structure, `llms.txt`, `AGENTS.md`, sitemap markdown, and Agent
Readability navigation."* In other words, once you've adopted `nav`, the
human site and the agent-facing artifacts cannot drift — they're rendered
from the same resolved tree.

**The legacy `group` frontmatter field is now taxonomy / compatibility
metadata.** It is still valid, but it is no longer the recommended place to
express a polished navigation. It remains useful for:

- **Legacy navigation fallback.** If a project has no `nav` in
  `docs.config.ts`, the CLI falls back to the legacy group resolver, infers
  groups from each page's `group:` values, and builds a fallback nav tree,
  `llms.txt` section headings, search metadata, and AGENTS.md grouping from
  that. Fine for small docs sets; insufficient when you need stable top
  tabs, sidebar order, descriptions, nested sections, or wildcard includes.
- **Search facets and broad taxonomy.** Because a page can declare multiple
  group slugs (`group: [a, b]`), the same page can be tagged into more than
  one bucket for search/taxonomy purposes even when `nav` controls placement.
- **Compatibility during migration** from older Leadtype docs sites that
  predate config-owned `nav`.

Companion fallback knobs:

- `order` in frontmatter is still consulted as a fallback sort for pages
  pulled in by `{ include: ... }` entries in `nav`.

Practical rule of thumb from the migration prompts: put *intentional*
navigation in `nav`; treat `group` as taxonomy/compatibility metadata only.

## 2. What happens if a page declares an unknown `group` slug?

**The build fails.** From the frontmatter doc:

> If a page declares a group slug that isn't in `docs.config.ts`, the build
> fails with `unknown group "<slug>"`. Same source of truth, no drift.

So `group` is not free-form — every slug a page uses must be declared once
in `docs.config.ts` (either in a top-level `groups` list, or as nested
children of a group entry). The lint/build refuses to silently drop a page
into a phantom bucket; you either add the slug to the config or fix the
frontmatter. Only **leaf** groups (no children) directly contain pages;
non-leaf groups act as headings only.

This is intentional: it keeps the page-declared taxonomy and the
config-declared taxonomy in lockstep, which is what makes the generated
`llms.txt` / `AGENTS.md` / sidebar all agree.
