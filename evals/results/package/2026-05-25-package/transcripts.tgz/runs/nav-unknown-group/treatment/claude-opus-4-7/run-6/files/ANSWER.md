# Leadtype navigation: `nav` vs. legacy `group`

## 1. Relationship between curated `nav` and a page's `group` frontmatter

**`nav` in `docs.config.ts` is the source of truth for curated navigation.** It drives:

- Top-level docs areas (e.g. tabs like Docs, Frontend, Integrations, Changelog)
- The sidebar structure under the active root node
- `llms.txt` sections
- `AGENTS.md` grouping (the agent map)
- Sitemap markdown
- Agent Readability metadata

In other words, the sidebar **and** the agent-facing document map are both rendered from the same resolved `nav` tree, so human and agent surfaces stay aligned automatically.

The page's `group` frontmatter field is **legacy taxonomy/compatibility metadata**. It is still valid, but it is no longer the right place to express polished navigation. It is still useful for:

- **Legacy navigation fallback.** If a project has no `nav` in `docs.config.ts`, the CLI falls back to the legacy group resolver and builds the nav tree, `llms.txt` sections, and `AGENTS.md` sections from the `group:` values it finds. This is enough for small doc sets.
- **Broad taxonomy / cross-cutting membership.** A page can declare multiple groups (`group: [a, b]`), so `group` is handy when a page belongs to more than one taxonomy bucket.
- **Search facets** and other categorization that isn't strictly hierarchical navigation.

Optional `order` frontmatter is similarly demoted: keep it only as a tiebreaker for pages pulled in by wildcard `{ include: "*", sort: ["order", "path"] }` entries.

### Quick guide

| Concern | Driven by |
|---|---|
| Sidebar structure | `nav` (or legacy `group` if `nav` is absent) |
| Top tabs / docs areas | `nav` |
| `AGENTS.md` agent map | `nav` (or legacy `group` if `nav` is absent) |
| `llms.txt` sections | `nav` (or legacy `group` if `nav` is absent) |
| Taxonomy / multi-membership / search facets | `group` |
| Fallback sort inside `{ include }` | `order` |

## 2. What happens if a page declares an unknown `group` slug?

**The build fails.** When a project still uses `group`-based navigation, every group slug must be declared once in `docs.config.ts`. If a page's frontmatter sets `group: <slug>` for a slug that isn't declared there, `leadtype generate` errors out with:

```
unknown group "<slug>"
```

This is deliberate: the config and frontmatter share a single source of truth for group identity, so typos and stale slugs can't silently drift between the sidebar and the agent map — they're caught at build time instead. (Note also that only **leaf** groups directly contain pages; non-leaf groups in a nested config are heading-only.)

You can also catch many related issues earlier with `leadtype lint`, which enforces the frontmatter schema (`schema`, `unknown-field`, `parse-error`, `invalid-link`, etc.) in CI before a build runs.
