# Leadtype navigation notes

## 1. `nav` vs. legacy `group`

`docs.config.ts` `nav` is the curated navigation source of truth for modern Leadtype projects. It is the structure you should use for product-level information architecture: top-level docs areas, sidebar sections, ordering, nested sections, and wildcard includes. The resolved `nav` tree is what drives the human sidebar/navigation manifest and the agent-facing maps such as `llms.txt`, `AGENTS.md`, sitemap markdown, and Agent Readability navigation.

A page's frontmatter `group` field is legacy taxonomy metadata. It can still be useful for:

- fallback navigation in projects that have not adopted `nav`,
- search/filter facets,
- broad taxonomy or compatibility with existing content,
- validating old group assignments when you keep `groups` declared in config.

So: put intentional sidebar/agent-map placement in `nav`; keep `group` only as taxonomy/fallback/compatibility metadata.

## 2. Unknown `group` slugs at build time

When Leadtype is validating legacy groups and a page declares a `group` slug that is not declared in the loaded config, generation fails instead of silently inventing a section. The error is reported as an unknown group, e.g.:

```txt
/docs/some-page declares unknown group "missing-slug"
```

The CLI treats that as a runtime build error and exits non-zero. This is intentional: a stale or misspelled group is considered a content/config drift bug, not something to defer to render time.

If a project has no configured legacy group list to validate against, Leadtype can infer fallback groups from frontmatter; but once groups are configured, the config is the allowed set.