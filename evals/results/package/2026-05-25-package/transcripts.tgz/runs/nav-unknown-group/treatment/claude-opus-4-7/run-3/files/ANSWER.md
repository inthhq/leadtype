# Navigation in leadtype: `nav` vs. `group`

## 1. Relationship between curated `nav` and legacy `group`

In current leadtype, the **curated `nav` array in `docs.config.ts` is the single source of truth for both the human sidebar and the agent map**. The page-level `group` frontmatter field is *legacy taxonomy/compatibility metadata* — it no longer drives the polished navigation when a `nav` is present.

### What `nav` drives

The resolved `nav` tree from `docs.config.ts` produces, in one pass:

- Top-level docs areas (e.g. tabs like Docs, Frontend, Integrations, Changelog).
- The human sidebar (order, nesting, section titles, descriptions).
- `llms.txt` section structure.
- `AGENTS.md` grouping (the "agent map").
- Sitemap markdown.
- Agent Readability navigation metadata.
- Generated `docs-nav.json` consumed by the app.

Quoting `node_modules/leadtype/docs/authoring/frontmatter.md`:

> `nav` drives top-level docs areas, sidebar structure, `llms.txt`, `AGENTS.md`, sitemap markdown, and Agent Readability navigation.

So when you wire up the sidebar component or the agent index, you should be reading what leadtype generated from `nav` — not iterating page `group` values yourself.

### What `group` is still good for

`group` has not been removed; it has been demoted. It remains useful for:

- **Taxonomy / compatibility metadata.** A page can declare `group: authoring` or `group: [a, b]` so it belongs to one or more taxonomy buckets without affecting curated placement. This is handy when the same page conceptually lives in multiple "topics."
- **Search facets.** Group slugs surface as faceting/filter metadata in search indexes.
- **Fallback navigation.** If a project has *no* `nav` in `docs.config.ts`, the CLI falls back to the legacy group resolver: it reads each page's `group:` and builds the nav, `llms.txt` sections, and AGENTS.md grouping from the intersection of page groups and the `groups` declared in config. That fallback is fine for small docs sets, but you give up sidebar order, descriptions, nested sections, and wildcard includes.
- **Lint validation.** `groups` in config plus `group` in frontmatter lets `leadtype lint` catch typos and stray slugs even on sites that have fully migrated to `nav`.

Quoting `docs/how-it-works.md`:

> `group` … A slug declaring which legacy taxonomy group a page belongs to. Config nav now drives curated sidebar and agent-map structure; group remains useful for fallback navigation and search facets.

And the summary at the end of the frontmatter reference:

> - `nav` drives top-level docs areas, sidebar structure, `llms.txt`, `AGENTS.md`, sitemap markdown, and Agent Readability navigation.
> - `group` remains available for legacy navigation fallback, search facets, and broad taxonomy.
> - `order` remains available as fallback sorting for pages pulled in by `include`.

### Rule of thumb for this codebase

- Want a page to appear in a specific spot in the sidebar or agent map? **Edit `nav` in `docs.config.ts`.** Don't tweak `group`.
- Want a page to be searchable/filterable under a topic, or to keep working in a legacy build path? Keep its `group` frontmatter.
- Don't try to encode sidebar order with `group`. Use `nav` with explicit page strings for pinned entries and `{ include: "*", sort: ["order", "path"] }` for the rest of a folder.

## 2. What happens at build if a page declares an unknown `group` slug?

**The build fails fast** with an `unknown group "<slug>"` error.

From `docs/authoring/frontmatter.md`:

> If a page declares a group slug that isn't in `docs.config.ts`, the build fails with `unknown group "<slug>"`. Same source of truth, no drift.

This is intentional: `groups` in `docs.config.ts` and `group:` in page frontmatter are validated against each other so the taxonomy can't silently drift. It applies whether you are running:

- `leadtype generate` (the CLI), or
- a custom build script that imports `docs.config.ts` and calls the lower-level APIs — those pipelines explicitly "fail fast on unknown legacy groups or invalid nav refs so a bad config can't ship" (`docs/package-docs/bundle.md`).

### How to fix it when it happens

You generally have three options:

1. **Fix the typo.** Most "unknown group" failures are misspellings of an existing slug. Match the page's `group:` to a slug declared under `groups` in `docs.config.ts`.
2. **Declare the new group in `docs.config.ts`.** If the slug is legitimately new, add it (with `slug`, `title`, and optional nested `children`) to the `groups` array in config. Only leaf groups can directly contain pages; non-leaf groups are headings only.
3. **Remove the `group` field** if the page no longer needs that taxonomy and its placement is already handled by `nav`. Because `group` is optional, dropping it is a valid migration step.

### Related failure modes to know about

- If you use `nav` and reference an MDX file that doesn't exist (via an explicit page string), generation also fails — `nav` entries are validated against the file tree.
- `leadtype lint` will surface `schema` and `unknown-field` issues in frontmatter before you get to `generate`, so running it in CI catches most of these earlier.
- If you have *no* config at all, the CLI falls back to `package.json` for product metadata and infers groups from the union of `group:` values it sees. In that mode there is no "unknown group" check because the set of valid groups is whatever the pages declare — but you also lose curated sidebar order.

### TL;DR

- `nav` in `docs.config.ts` is the curated source of truth for sidebar + agent map.
- `group` frontmatter is taxonomy/search/fallback metadata, validated against `groups` in the same config.
- An unknown `group` slug is a hard build error (`unknown group "<slug>"`), by design.
