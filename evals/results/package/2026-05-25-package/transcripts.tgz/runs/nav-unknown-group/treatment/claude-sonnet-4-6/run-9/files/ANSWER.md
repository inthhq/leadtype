# Navigation: `nav` vs `group` frontmatter in Leadtype

## Question 1 — Which one drives the sidebar and agent map, and what is the other still good for?

### `nav` in `docs.config.ts` is the authoritative driver

The curated `nav` array in `docs.config.ts` is the **single source of truth** for all navigation and agent-facing structure in a modern Leadtype project. Everything that a reader or an agent sees is derived from it:

| Surface | Driven by `nav` |
|---|---|
| Top-level tabs (Docs, Reference, Changelog, …) | ✅ |
| Sidebar sections and page order | ✅ |
| `llms.txt` section headings | ✅ |
| `AGENTS.md` grouping and links | ✅ |
| Agent Readability metadata (`agent-readability.json`) | ✅ |
| `sitemap.md` navigation structure | ✅ |
| `resolveDocsNavigation()` / `getNavigation()` output | ✅ |

`nav` supports rich composition: nested `children` for deep trees, a `base` prefix that cascades to child nodes, explicit page strings for pinned pages, and `{ include: "folder/*" }` wildcard entries for inventory-like sections. The resolved tree is what every downstream artifact — human sidebar, `llms.txt`, `AGENTS.md` — uses.

> From the frontmatter reference:
> *"`nav` drives top-level docs areas, sidebar structure, `llms.txt`, `AGENTS.md`, sitemap markdown, and Agent Readability navigation."*

---

### `group` frontmatter is legacy taxonomy metadata

The `group` field (e.g. `group: authoring` or `group: [authoring, reference]`) predates the `nav` API. It is still **valid and useful**, but it is no longer the right tool for expressing intentional navigation. What it remains good for:

1. **Legacy fallback navigation** — When a project has *no* `nav` in `docs.config.ts` at all, the CLI falls back to the group resolver: it reads every page's `group:` value, cross-references the `groups:` list in config, and infers a nav tree from that intersection. This fallback is enough for small or early-stage docs sets.

2. **Search facets** — `group` values are indexed as taxonomy metadata so search queries can be scoped or filtered by group.

3. **Broad taxonomy / compatibility metadata** — A page may declare multiple groups (`group: [authoring, reference]`) to signal it belongs to more than one conceptual bucket, which `nav` placement alone cannot express.

> From the frontmatter reference:
> *"`group` remains available for legacy navigation fallback, search facets, and broad taxonomy."*

> From the How it works vocabulary:
> *"A slug declaring which legacy taxonomy group a page belongs to. Config nav now drives curated sidebar and agent-map structure; group remains useful for fallback navigation and search facets."*

---

### Summary

| | `nav` in `docs.config.ts` | `group` frontmatter |
|---|---|---|
| **Drives sidebar** | ✅ Yes — authoritative | ❌ No (only in legacy fallback) |
| **Drives agent map** (`llms.txt`, `AGENTS.md`) | ✅ Yes — authoritative | ❌ No (only in legacy fallback) |
| **Legacy nav fallback** (no `nav` present) | N/A | ✅ Yes |
| **Search facets** | — | ✅ Yes |
| **Taxonomy / cross-group membership** | — | ✅ Yes |
| **Nested sidebar sections, tab areas, include wildcards** | ✅ Yes | ❌ No |

---

## Question 2 — What happens at build time if a page declares a `group` slug that the config doesn't know about?

**The build fails immediately with an `unknown group "<slug>"` error.**

This is an intentional hard failure, not a warning. When `leadtype generate` runs, step 3 of the fixed pipeline is:

> *"Resolve groups from frontmatter, validate every page's `group:` matches a known slug."*

If any page's `group` value is not present in the `groups:` list declared in `docs.config.ts`, the run stops at that step with an error. The rationale, stated explicitly in the docs, is:

> *"If a page declares a group slug that isn't in `docs.config.ts`, the build fails with `unknown group "<slug>"`. Same source of truth, no drift."*

> *"If step 3 finds an unknown group, the run fails. That is by design — broken navigation is a content bug, not a render-time problem."*

### Why this matters in practice

- **No silent drift.** A page that references a deleted or misspelled group slug will not quietly disappear from navigation or produce a broken nav tree — the pipeline stops loudly before writing any output.
- **Catch it earlier with `leadtype lint`.** The lint command runs the same group-resolution checks before generation, so you can surface unknown-group errors in CI on a PR (with file and line context) rather than waiting for the full generate step to fail. The recommended CI order is: `leadtype lint` first, then `leadtype generate`.
- **The same contract applies in nav-mode projects.** Even after migrating to `nav`, any `group:` values still declared in frontmatter must match a slug in the config's `groups:` list, or the build fails.
