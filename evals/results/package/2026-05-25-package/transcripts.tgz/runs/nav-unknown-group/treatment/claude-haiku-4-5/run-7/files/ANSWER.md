# Navigation and Config Questions

## 1. Relationship between `nav` in `docs.config.ts` and legacy `group` frontmatter field

**Which drives the sidebar and agent map:**
The curated `nav` in `docs.config.ts` is the primary driver for both the sidebar and agent map. This is the preferred approach for modern Leadtype projects.

**What the other is still good for:**
The legacy `group` frontmatter field remains valuable for:
- **Taxonomy metadata** — Pages can declare multiple groups for classification purposes
- **Fallback navigation** — In projects that haven't adopted `nav`, the group resolver infers navigation structure from the `group` values found in pages
- **Search facets** — Groups can be used to organize search results
- **Broad taxonomy classification** — Pages can belong to multiple logical categories independent of the curated navigation

**Key insight:** The relationship is hierarchical. When `nav` is defined in config, it takes precedence and drives the navigation tree, `llms.txt` sections, `AGENTS.md` grouping, and Agent Readability metadata. The `group` field becomes supplementary taxonomy metadata. If no `nav` is defined, the CLI falls back to the legacy group resolver, which infers groups from the `group` values it finds in page frontmatter.

## 2. What happens at build time if a page declares a `group` slug that the config doesn't know about

**The build fails with an error.** 

According to the lint rules documentation, if a page declares a group slug that isn't defined in `docs.config.ts`, the build fails with the error message: `unknown group "<slug>"`.

This enforces a single source of truth — the groups declared in the config are the canonical set. Any page declaring a group must reference one of those known groups. This validation happens during the linting phase (via `leadtype lint`), which runs before generation, catching the issue early in the build pipeline rather than allowing invalid references to silently pass through.
