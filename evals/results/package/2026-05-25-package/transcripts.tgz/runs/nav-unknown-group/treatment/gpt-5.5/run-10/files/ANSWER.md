# Leadtype navigation and legacy groups

1. In modern Leadtype projects, `docs.config.ts` `nav` is the curated source of truth. It drives the top-level docs areas, sidebar structure, `llms.txt` sections, `AGENTS.md`, sitemap markdown, and Agent Readability / agent-map navigation. A page's frontmatter `group` field is legacy metadata; it is still useful for projects that have not adopted `nav` (fallback group-based navigation), and for taxonomy/search/filter facets or broad compatibility metadata.

2. If legacy `group` values are being validated against configured `groups` and a page declares a slug the config does not know, the build fails fast with an error like:

   ```text
   <page-url> declares unknown group "<slug>"
   ```

   That is intentional: Leadtype treats drift between page metadata and the config as a content/navigation bug rather than letting broken grouping ship. If you have moved to `nav` but want old `group` frontmatter to keep being checked, keep the corresponding `groups` entries in the config; `nav` still controls curated placement.
