# Navigation in a leadtype project

Sourced from `node_modules/leadtype/docs/authoring/frontmatter.md`.

## 1. `nav` in `docs.config.ts` vs. a page's `group` frontmatter

**Curated `nav` in `docs.config.ts` is the source of truth that drives the sidebar and the agent map.** When a project defines `nav`, the same resolved tree is what produces:

- top-level docs areas / tabs (e.g. Docs, Frontend, Integrations, Changelog),
- the sidebar structure under the active root,
- `llms.txt`,
- `AGENTS.md`,
- sitemap markdown,
- Agent Readability navigation metadata.

The leadtype docs are explicit about this: *"`nav` drives top-level docs areas, sidebar structure, `llms.txt`, `AGENTS.md`, sitemap markdown, and Agent Readability navigation."*

**`group` is legacy taxonomy metadata on a page**, declared in frontmatter as `group: <slug>` or `group: [a, b]` (a page may belong to multiple groups). It is still useful for:

- **Legacy navigation fallback** — if a project has not adopted `nav`, the CLI falls back to the legacy group resolver. It infers a nav tree from the `group:` values it finds on pages, intersected with the group declarations in `docs.config.ts`. That produces the fallback nav tree, the section headings in `llms.txt`, and `AGENTS.md` grouping. This is "enough for small docs sets," but `nav` is recommended when you need stable top-level areas, sidebar order, descriptions, nested sections, or wildcard includes.
- **Search facets and broad taxonomy** — even in `nav`-driven projects, `group` remains available as a tag-like classification (a page can be in several groups), surfaced to search metadata.

In short: `nav` drives placement and ordering of pages in human and agent surfaces; `group` is a cross-cutting label retained for fallback navigation and faceting.

## 2. Build-time behavior for an unknown `group` slug

If a page declares a `group` slug that is not declared in `docs.config.ts`, **the build fails** with the error:

```
unknown group "<slug>"
```

The intent, per the leadtype docs, is "Same source of truth, no drift" — every group used by a page must be declared once in `docs.config.ts`, so typos or stray slugs are caught at build time rather than silently producing a broken or invisible nav entry.
