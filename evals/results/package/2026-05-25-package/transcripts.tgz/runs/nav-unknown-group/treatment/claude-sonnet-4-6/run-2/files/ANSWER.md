# Navigation: `nav` vs `group` — Answers

## 1. Which one drives the sidebar and agent map, and what is the other still good for?

### `nav` in `docs.config.ts` is the primary driver

The curated `nav` array in `docs.config.ts` is the **authoritative source** for all navigation and agent-facing output. Specifically, `nav` drives:

- **Sidebar structure** — root nodes become top-level tabs (e.g. Docs, Frontend, Integrations, Changelog); the active root node's pages and children become the sidebar.
- **Agent map / `llms.txt`** — section headings, page links, and routing hints in the docs-scoped and root `llms.txt` files.
- **`AGENTS.md`** — the offline, package-bundled navigation index consumed by coding agents reading from `node_modules/`.
- **Sitemap markdown** — `sitemap.md` headings and links.
- **Agent Readability metadata** — the `agent-readability.json` manifest and its navigation tree.
- **`resolveDocsNavigation()`** — the build-time API that returns the nav tree; the returned tree is what every artifact generator and sidebar UI consumes.

The `nav` structure supports explicit page slugs, `base` prefixes that cascade to children, wildcard `{ include: "folder/*" }` entries with `sort` control, and arbitrarily deep nesting. This makes it the right home for intentional, curated IA.

### `group` frontmatter is the legacy fallback — still useful for taxonomy

`group` (a string or array of strings on a page's YAML frontmatter) was the _original_ way to express navigation before `nav` existed. With config-owned `nav` in place, `group` is demoted to **optional taxonomy/compatibility metadata**. It is still useful for:

- **Legacy navigation fallback** — if there is no `nav` in `docs.config.ts`, the CLI falls back to the group resolver, inferring navigation from all the `group:` values it finds. This fallback is enough for small, simple docs sets.
- **Search facets** — `group` values still appear in search metadata and can be used as filter facets.
- **Broad taxonomy** — pages that belong to multiple conceptual categories can declare `group: [a, b]`; this does not conflict with `nav` placement.
- **Validation anchor** — when `groups` are declared in config, the group resolver validates that every page's `group` slug is known (see Question 2 below).

In summary: **`nav` owns the sidebar and agent map; `group` is a secondary taxonomy tag and a compatibility shim for projects that haven't migrated yet.**

---

## 2. What happens at build time if a page declares a `group` slug the config doesn't know about?

**The build fails with an `unknown group "<slug>"` error.**

From the frontmatter docs:

> If a page declares a group slug that isn't in `docs.config.ts`, the build fails with `unknown group "<slug>"`. Same source of truth, no drift.

This is an intentional hard failure — not a warning — to prevent configuration drift between what the config declares as valid groups and what pages actually claim membership in.

The same behaviour surfaces through the `resolveDocsNavigation()` API, which populates `navigation.unknown` with every `{ urlPath, slug }` pair that couldn't be resolved. The standard pattern shown in the LLM reference docs is to check that array and exit the process non-zero:

```ts
const navigation = await resolveDocsNavigation({ srcDir: ".", baseUrl, nav: docsConfig.nav });

if (navigation.unknown.length > 0) {
  for (const { urlPath, slug } of navigation.unknown) {
    process.stderr.write(`error: ${urlPath} declares unknown group "${slug}".\n`);
  }
  process.exit(1);
}
```

### How to avoid it

- **Declare the group slug** in `docs.config.ts` (either under `groups` for the legacy resolver, or ensure the `nav` tree covers it).
- **Remove or correct the `group` field** on the offending page.
- **Run `leadtype lint` before `leadtype generate`** in CI — lint surfaces schema and navigation problems with precise file/line context, making this class of error easy to diagnose before the heavier generate step runs.
