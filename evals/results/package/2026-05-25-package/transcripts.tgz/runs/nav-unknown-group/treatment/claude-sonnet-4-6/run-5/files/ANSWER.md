# Navigation: `nav` vs `group` in Leadtype

## 1. What is the relationship between `nav` and `group`, and which one drives the sidebar and agent map?

### `nav` (in `docs.config.ts`) is the authoritative driver

The curated `nav` array in `docs.config.ts` is the **single source of truth** for every navigation surface that Leadtype produces. Specifically, `nav` drives:

- The **sidebar** structure (top-level docs areas, nested sections, page order within sections).
- The **agent map** — `llms.txt` sections, `AGENTS.md` grouping, `sitemap.md`, and `agent-readability.json` navigation metadata.

The entire resolved tree flows from `nav` through one consistent pipeline:

```
docs.config.ts  →  nav resolver  →  sidebar
                                 →  llms.txt sections
                                 →  AGENTS.md sections
                                 →  sitemap / agent-readability.json
```

`nav` supports explicit page strings, `base` prefixes that cascade to child nodes, `{ include: "glob/*" }` wildcard entries, nested section nodes, and per-node `sort` control. It gives you stable, intentional information architecture that is impossible to express reliably with flat frontmatter alone.

### `group` (frontmatter) is legacy taxonomy / fallback metadata

The `group: <slug>` (or `group: [a, b]`) field in a page's frontmatter is a **legacy mechanism**. It remains valid and useful, but it is **no longer the driver** for curated navigation. It is still good for:

- **Fallback navigation** in projects that have not yet adopted `nav`. When no `nav` is defined, `leadtype generate` falls back to the group resolver and infers a nav tree from the `group:` values it finds in frontmatter. This is sufficient for small docs sets.
- **Search facets** — `group` values are exposed in search metadata so pages can be filtered by taxonomy in a search UI.
- **Broad taxonomy / compatibility metadata** — labelling a page with a logical category it belongs to, independent of where it sits in the curated sidebar.
- **Legacy tools or custom code** that reads raw frontmatter directly.

The official guidance is: once you have `nav` in `docs.config.ts`, treat `group` as taxonomy and compatibility metadata, not as a navigation primitive. The sidebar and agent map are owned entirely by `nav`.

### Summary table

| Surface | Driven by |
|---|---|
| Sidebar structure | `nav` in `docs.config.ts` |
| `llms.txt` sections | `nav` |
| `AGENTS.md` sections | `nav` |
| `sitemap.md` / `agent-readability.json` nav | `nav` |
| Fallback nav (no `nav` present) | `group` frontmatter |
| Search facets | `group` frontmatter |
| Broad taxonomy labelling | `group` frontmatter |

---

## 2. What happens at build time if a page declares a `group` slug that the config doesn't know about?

The build **fails immediately with a hard error**.

When `leadtype generate` runs, step 3 of its fixed pipeline is "resolve groups from frontmatter and validate every page's `group:` against the known slugs declared in `docs.config.ts`." If any page declares a `group` slug that is not registered in the config, the run exits with:

```
unknown group "<slug>"
```

This is a deliberate design decision: broken navigation is treated as a **content bug, not a render-time problem**. The same requirement applies in the fallback (no `nav`) path — every `group` value a page declares must have a corresponding entry in the config's `groups` list. The strict one-source-of-truth policy means config and frontmatter can never silently drift apart.

Practically, this means:
- If you add a new `group:` slug to a page, you **must** also add it to `docs.config.ts` before running the build.
- `leadtype lint` surfaces the same violation as a lint error before generation, so you can catch it in CI during a PR — before the harder generate-time failure.
- The error is intentionally loud and specific, naming the unknown slug, so it is easy to diagnose and fix.
