# Navigation System in Leadtype Projects

## 1. The Relationship Between `nav` in `docs.config.ts` and Legacy `group` Frontmatter

### Which One Drives Sidebar and Agent Map?

**The curated `nav` in `docs.config.ts` is the primary driver.** It controls:
- Sidebar structure and page ordering
- `llms.txt` navigation sections
- `AGENTS.md` organization
- Sitemap markdown
- Agent Readability metadata

### What is `group` Frontmatter Still Good For?

The legacy `group` field remains valuable for:

1. **Fallback navigation** — When a project has not yet adopted config-owned `nav`, the `group` resolver infers the navigation tree from `group:` values found across all pages
2. **Multi-group taxonomy** — Pages can declare `group: <slug>` or `group: [a, b]` to be shared across multiple taxonomy groups simultaneously
3. **Search metadata** — The `group` values help organize search facets and taxonomic metadata
4. **Legacy projects** — For small docs sets that haven't migrated to `nav`, it's "enough," though using config `nav` is recommended for stable top-level docs areas, sidebar order, descriptions, nested sections, or wildcard includes

### The Mental Model

```
docs.config.ts nav (curated)
        ↓
[feeds sidebar, llms.txt, AGENTS.md, sitemap, agent metadata]

page frontmatter group: slug (legacy taxonomy)
        ↓
[fallback tree if no nav exists, search facets, legacy grouping]
```

When `nav` is present, it is the source of truth. The `group` field becomes supplementary — useful for ad-hoc taxonomy but not required when `nav` is comprehensive.

---

## 2. Build-Time Behavior: Unknown Group Slugs in Pages

### What Happens?

**If a page declares a `group` slug that the config doesn't know about, the build fails with an error: `unknown group "<slug>"`.**

This is intentional design:
- Same source of truth (the config), no drift between frontmatter and config
- Prevents silent failures where a page's group is silently ignored
- Forces explicit declaration of all groups in `docs.config.ts`

### Example

**docs.config.ts declares only these groups:**
```ts
{
  groups: ["authoring", "docs-site", "reference"]
}
```

**A page tries to use:**
```mdx
---
title: "My Page"
group: "unknown-category"
---
```

**Result:** Build fails with `unknown group "unknown-category"`. The page author must either:
1. Add `unknown-category` to `docs.config.ts` `groups` list, or
2. Change the page's `group:` to a declared group like `"authoring"`

This strict validation catches configuration drift early, especially important when pages are shared across multiple groups or when a docs set transitions between projects.
