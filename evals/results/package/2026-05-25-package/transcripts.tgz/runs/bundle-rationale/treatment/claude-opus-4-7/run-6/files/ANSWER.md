# Bundling docs inside an npm package

## Why `AGENTS.md`, not `llms.txt`

[`llms.txt`](https://llmstxt.org) is a **website** convention: a file served at `/llms.txt` whose body is a list of absolute URLs that an agent fetches over HTTP. Drop it inside an npm tarball and it's the wrong shape — every link points at a hosted URL the consuming environment may not be able to reach, and no major coding agent looks for `node_modules/<pkg>/llms.txt` in the first place. [`AGENTS.md`](https://agents.md) is the matching **filesystem** convention, and it's what Claude Code, OpenAI Codex, Cursor, GitHub Copilot, Aider, Devin, and friends already scan for when they work against files on disk. An `AGENTS.md` at the root of the installed package gets relative links to sibling `docs/*.md` files, needs no network, and is automatically version-matched to whatever release the consumer installed — exactly the contract you want from package-bundled docs.

## What `leadtype generate --bundle` deliberately skips

`--bundle` mode emits only `AGENTS.md` plus per-topic `docs/**/*.md`. It intentionally omits the three artifacts that only make sense when docs are served over HTTP: **`llms.txt`**, **`llms-full.txt`**, and **the search index** (alongside the other site-mode outputs like `sitemap.xml`, `sitemap.md`, `robots.txt`, and `agent-readability.json`). Those files exist to advertise URLs to crawlers, drive content negotiation, or power an in-browser search runtime — none of which apply inside `node_modules/<your-package>/`, where the consumer is a coding agent reading files directly off disk. Keeping them out of the tarball avoids shipping dead absolute URLs and unnecessary bytes; generate them in website mode instead, where they belong.
