# Why AGENTS.md, Not llms.txt, Inside an npm Tarball

`llms.txt` is a **website convention** defined at [llmstxt.org](https://llmstxt.org): a file served at `/llms.txt` containing absolute URLs that an HTTP agent fetches over the network. That shape is wrong inside an npm tarball on two counts: the absolute URLs point at a hosted site the agent may not be able to reach (especially in offline or air-gapped environments), and no major coding agent — Claude Code, Codex, Cursor, Copilot, Aider, Devin, etc. — looks for `node_modules/<pkg>/llms.txt`. `AGENTS.md`, by contrast, is the **filesystem convention** ([agents.md](https://agents.md)) that those same tools *do* understand when working with files on disk. Placed at `node_modules/<your-package>/AGENTS.md`, it uses relative links like `./docs/quickstart.md` that resolve correctly both during local dev and after install, with no network required and content that is always version-matched to what was actually installed.

## Artifacts Skipped by `leadtype generate --bundle`

According to the `leadtype` docs (`docs/package-docs/bundle.md`), passing `--bundle` deliberately skips three website artifacts:

| Artifact | Why it doesn't belong in a package |
|---|---|
| `llms.txt` | A website discovery file intended to be fetched over HTTP at a root URL; meaningless and unreachable from inside `node_modules`. |
| `llms-full.txt` | A full-content HTTP fallback for the same website convention; same reasoning as `llms.txt`. |
| Search index | A static index built for a hosted docs site's runtime query layer; there is no search server or browser to serve it from inside a tarball. |

These three artifacts are all designed for an HTTP-accessible docs site — they assume a server, a domain, and a live network connection. A package tarball has none of those things, so `--bundle` omits them and emits only `AGENTS.md` plus the per-topic `.md` files that a coding agent can read directly off disk.
