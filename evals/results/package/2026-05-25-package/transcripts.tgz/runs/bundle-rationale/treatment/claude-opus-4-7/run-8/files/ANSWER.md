# Bundling docs inside an npm package

## Why `AGENTS.md`, not `llms.txt`

`llms.txt` is a **website convention**: a file served at `/llms.txt` containing absolute URLs that an agent fetches over HTTP. Inside an npm tarball that shape breaks down — every link points at a hosted URL the agent may not be able to reach, and no major coding agent looks for `node_modules/<pkg>/llms.txt`. `AGENTS.md` ([agents.md](https://agents.md)) is the **filesystem convention** that the ecosystem (Claude Code, OpenAI Codex, Cursor, GitHub Copilot, Aider, Devin, …) actually reads from disk. Shipping `AGENTS.md` at the package root with relative links like `./docs/quickstart.md` means the file is meaningful both in local dev and at `node_modules/<your-package>/AGENTS.md` after install: no network required, and the docs are guaranteed to match the installed version. leadtype emits both — `llms.txt` in website mode for HTTP-discoverable agents, and `AGENTS.md` in `--bundle` mode for offline, filesystem-discoverable agents.

## What `leadtype generate --bundle` deliberately skips

In `--bundle` mode leadtype intentionally omits the website-only artifacts: **`llms.txt`**, the root **`llms-full.txt`** fallback, and the **static search index**. Those exist to be served from an origin — `llms.txt`/`llms-full.txt` rely on absolute URLs an HTTP agent can dereference, and the search index is meant to be queried by a runtime in the browser or server. None of that makes sense inside `node_modules/<pkg>/`, where there is no host, no base URL, and no runtime to query an index. A bundled package only needs `AGENTS.md` plus per-topic `docs/**/*.md` so an agent can walk the relative links straight from the installed dependency.
