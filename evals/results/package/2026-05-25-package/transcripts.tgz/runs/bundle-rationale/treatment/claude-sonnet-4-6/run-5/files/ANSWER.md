# Why AGENTS.md beats llms.txt inside an npm tarball

`llms.txt` is a **website convention**: a file served at a well-known URL (`/llms.txt`) whose links are absolute HTTP URLs pointing at hosted markdown mirrors. Inside an npm tarball those absolute URLs are useless — the agent may have no network access, and no major coding tool (Claude Code, Cursor, GitHub Copilot, Codex, Aider, Devin, etc.) looks for `node_modules/<pkg>/llms.txt`. `AGENTS.md`, by contrast, is the **filesystem convention** those tools actually follow. It lives at a package root, uses relative paths like `./docs/quickstart.md`, and works the moment the tarball is unpacked — no HTTP request needed, and every link resolves to a file that is version-matched to the exact release that was installed. leadtype's `--bundle` mode therefore emits `AGENTS.md` (via `generateAgentsMd`) instead of `llms.txt`, expressly because relative filesystem links are the right shape for offline, in-`node_modules` reading.

## Artifacts skipped by `leadtype generate --bundle`

`--bundle` deliberately skips three website-only artifacts:

- **`llms.txt` / `llms-full.txt`** — hosted routing indexes with absolute URLs; meaningless without a running web server and a known base URL.
- **`search-index.json` / `search-content.json`** — a static search index sized and structured for a browser or server-side search runtime, not for a coding agent reading files from disk.
- **`sitemap.xml`, `sitemap.md`, `robots.txt`, and `agent-readability.json`** — HTTP-discovery and crawl-policy artifacts that assume a canonical public URL and are consumed by crawlers and CDN-layer tooling, not by tools operating on a local filesystem.

None of these belong in a published package because they either require a live URL to be meaningful, assume a network-reachable host, or are simply never read by the coding-agent tools that open `AGENTS.md` when working with an installed dependency.
