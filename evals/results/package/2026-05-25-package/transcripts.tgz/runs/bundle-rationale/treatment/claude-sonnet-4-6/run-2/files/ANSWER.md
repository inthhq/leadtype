# Why AGENTS.md — not llms.txt — belongs in an npm tarball

`llms.txt` is a **website convention**: a file served at the root of a domain (`/llms.txt`) whose links are absolute URLs pointing at hosted pages. Inside an npm tarball those URLs are useless — the agent may have no network access, the links can't be resolved as relative filesystem paths, and no major coding agent (Claude Code, Cursor, Codex, Copilot, Aider, Devin, etc.) looks for `node_modules/<pkg>/llms.txt` in the first place. `AGENTS.md` is the **filesystem convention** designed for exactly this situation: it lives at the package root, every link inside it is a relative path like `./docs/quickstart.md`, and coding agents that work with files on disk know to read it from `node_modules/<your-package>/AGENTS.md`. The content is therefore version-matched to the installed release, works fully offline, and uses the same relative-path contract whether the file is read from `node_modules/` after `npm install` or from `packages/<name>/` during local development. leadtype itself ships both — `llms.txt` in website mode for HTTP-discoverable agents, and `AGENTS.md` via `--bundle` mode for offline filesystem-discoverable agents — because they solve different problems with different shapes.

## Artifacts skipped by `leadtype generate --bundle`

The `--bundle` flag deliberately omits three categories of website artifacts:

- **`llms.txt` and `llms-full.txt`** — routing-index files built around absolute URLs and HTTP discoverability; meaningless without a running web server and the wrong shape for a tarball.
- **The search index** (`search-index.json`, `search-content.json`) — a runtime query artifact designed to be served over HTTP and queried by a browser or agent making network requests; it has no role inside `node_modules/`.
- **Agent-readability / sitemap / robots files** (`sitemap.xml`, `sitemap.md`, `robots.txt`, `agent-readability.json`) — these exist to make a *hosted site* crawlable and content-negotiation-aware; they embed absolute canonical URLs and are consumed by HTTP crawlers and CDN middleware, not by a local coding agent reading installed packages.

All of these artifacts assume a live origin with an addressable base URL. A package tarball has neither, so including them would only mislead agents with links they cannot follow.
