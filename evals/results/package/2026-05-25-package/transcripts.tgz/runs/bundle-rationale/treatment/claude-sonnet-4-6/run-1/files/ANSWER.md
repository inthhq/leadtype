# Why AGENTS.md — not llms.txt — belongs in an npm tarball

`llms.txt` is a **website convention**: it lives at the root of a hosted domain and its links are absolute URLs that an HTTP-capable agent fetches over the network. Inside an npm tarball those absolute URLs may be unreachable (air-gapped environments, offline IDEs, agents without web access), and no major coding agent — Claude Code, OpenAI Codex, Cursor, GitHub Copilot, Aider, Devin, etc. — looks for `node_modules/<pkg>/llms.txt` anyway. `AGENTS.md` is the **filesystem convention** designed for exactly this situation: tools that work with files on disk discover it at `node_modules/<your-package>/AGENTS.md`, all its links are **relative paths** (e.g. `./docs/quickstart.md`) that resolve correctly both during local development and after install, no network request is required, and the content is always version-matched to the installed package. leadtype deliberately emits both shapes from the same MDX source — `llms.txt` in site mode for HTTP-discoverable agents, `AGENTS.md` in `--bundle` mode for filesystem-discoverable agents — because the right shape depends on where the file is consumed.

## Artifacts skipped by `leadtype generate --bundle`

When the `--bundle` flag is set, leadtype skips three website-only artifacts:

- **`llms.txt`** (and the docs-scoped `docs/llms.txt`) — a URL-routing index whose links are root-relative or absolute HTTP paths; meaningless without a running web server.
- **`llms-full.txt`** — a single giant file concatenating all docs for HTTP clients that cannot follow page-level links; unnecessary when an agent can simply open the per-topic `.md` files already present in the tarball.
- **The search index** — a static JSON artifact built for in-browser or server-side full-text search queries; there is no search runtime inside `node_modules`, and the file would only bloat the tarball.

All three artifacts exist to serve the *hosted website* audience. They assume HTTP transport, a live origin, and runtime infrastructure that simply does not exist inside an installed package.
