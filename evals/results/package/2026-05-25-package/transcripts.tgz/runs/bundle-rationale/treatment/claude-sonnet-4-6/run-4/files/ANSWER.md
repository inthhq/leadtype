# Why AGENTS.md — not llms.txt — belongs inside an npm tarball

`llms.txt` is a **website convention**: a file served at `/llms.txt` whose contents are absolute HTTP URLs that an agent resolves over the network. Inside an npm tarball that model breaks entirely — the links point at a hosted site the agent may not be able to reach, and no major coding agent (Claude Code, Cursor, Codex, Copilot, Aider, Devin, etc.) looks for `node_modules/<pkg>/llms.txt` on the filesystem. `AGENTS.md` is the **filesystem convention** that coding agents and IDEs actually understand. It lives at the package root, its internal links are relative paths (e.g. `./docs/quickstart.md`), it requires zero network access, and it automatically tracks the installed version of the library. That is exactly the shape that belongs inside a tarball: discoverable on disk, self-contained, and version-matched.

## Artifacts that `leadtype generate --bundle` deliberately skips

The `--bundle` flag omits three website-only outputs and the reason is the same in each case — they are meaningful only when served over HTTP, not when read from the filesystem:

| Skipped artifact | Why it doesn't belong in a package |
|---|---|
| `llms.txt` | An HTTP-discovery index of absolute URLs; useless without a running web server. |
| `llms-full.txt` | A single-file fallback concatenating all docs for HTTP agents; redundant when the individual `.md` files are already present on disk. |
| `search-index.json` / search artifacts | A pre-built query index for a hosted search endpoint; has no runtime to serve it from inside `node_modules`. |

These artifacts are generated in **website mode** (`leadtype generate` without `--bundle`) and written to `public/` for CDN or framework hosting. In bundle mode, `leadtype` replaces all of them with `AGENTS.md` plus the per-topic `.md` files — the only two things a coding agent reading files from disk actually needs.
