# Why AGENTS.md, Not llms.txt, Inside an npm Tarball

`llms.txt` is a **website convention**: it lives at the root URL of a hosted site and contains absolute HTTP links that an agent fetches over the network. Inside an npm tarball, that shape breaks in two ways. First, every link points at a remote URL that an offline or air-gapped agent cannot reach — the whole value proposition of shipping docs with the package is eliminated. Second, no major coding agent (Claude Code, OpenAI Codex, Cursor, Copilot, Aider, Devin, etc.) looks for `node_modules/<pkg>/llms.txt`; none of them treat that path as meaningful. `AGENTS.md`, by contrast, is the **filesystem convention** those tools understand. When leadtype writes `AGENTS.md` via `leadtype generate --bundle`, every link is a relative path such as `./docs/quickstart.md`, so the file is meaningful both during local development and after install at `node_modules/<your-package>/AGENTS.md`. The content also matches the installed version exactly — no drift, no network round-trip.

## Artifacts skipped by `--bundle`

`leadtype generate --bundle` deliberately skips three website artifacts:

- **`llms.txt`** and **`llms-full.txt`** — these are hosted-site routing indexes built around absolute URLs and HTTP discovery. They are meaningless on a filesystem with no origin.
- **The search index** (`search-index.json` / `search-content.json`) — a static search index is designed to be queried by a running web server or CDN; it has no use inside a dependency folder that a coding agent reads as plain files.

None of these artifacts belong in a package because they are built for HTTP agents navigating a live website, not for coding agents reading installed files on disk.
