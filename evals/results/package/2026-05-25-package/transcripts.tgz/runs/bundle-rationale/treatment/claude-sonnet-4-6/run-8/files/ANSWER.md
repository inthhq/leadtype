# Why AGENTS.md, not llms.txt, belongs in an npm tarball

`llms.txt` is a **website convention**: a file served at a root HTTP URL (`/llms.txt`) whose links are absolute URLs that an agent fetches over the network. Inside an npm tarball those absolute URLs may be unreachable (air-gapped environments, offline IDEs, agents without web access), and no major coding agent — Claude Code, Cursor, GitHub Copilot, Aider, Codex, Devin — looks for `node_modules/<pkg>/llms.txt` in the first place. `AGENTS.md` is the **filesystem convention** that these tools *do* understand: when a coding agent works with files on disk it reads `AGENTS.md` and follows its links. Because `leadtype generate --bundle` writes every link in `AGENTS.md` as a relative path (e.g. `./docs/quickstart.md`), the file is meaningful both at `packages/my-package/AGENTS.md` during local development and at `node_modules/my-package/AGENTS.md` after install — no network required, and the content is always version-matched to the installed package.

## Artifacts that `--bundle` deliberately skips

`leadtype generate --bundle` omits three website-only artifacts:

| Artifact | Why it doesn't belong in a package |
|---|---|
| `llms.txt` / `llms-full.txt` | Website routing indexes whose links are absolute URLs pointing at a hosted site; meaningless and potentially broken when read from the filesystem. |
| Search index | A runtime query artifact for a hosted docs site; an installed package has no search server, and the index file adds size with no benefit to a coding agent reading files directly. |

These outputs are produced by the default `leadtype generate` (site mode) and pair with a running web server; they are deliberately excluded from `--bundle` mode because they are website artifacts that don't make sense offline.
