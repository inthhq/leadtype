# Why AGENTS.md, not llms.txt, belongs in an npm tarball

`llms.txt` is a *website* convention — it is fetched over HTTP by agents and tools that discover documentation from a hosted URL. Inside an npm tarball there is no HTTP server, no URL, and no standard mechanism for a coding agent to know it should look for a file named `llms.txt`. `AGENTS.md`, by contrast, is the established convention for agent-readable documentation shipped *on disk*: coding agents (Codex, Claude Code, Cursor, etc.) are explicitly designed to look for `AGENTS.md` in the current project and in installed packages under `node_modules/<pkg>/AGENTS.md`. Placing docs there means they are version-matched to the exact release the consumer installed, always available offline, and discovered automatically without any extra configuration. `llms.txt` dropped into a tarball would simply be an inert, invisible file that no tooling would ever find.

## Artifacts that `leadtype generate --bundle` deliberately skips

The CLI source (`GENERATE_USAGE` string and the `runGenerateCommand` branch) is explicit: `--bundle` writes **only** `AGENTS.md` and `docs/*.md`, and skips every website-only artifact:

- **`llms.txt` / `llms-full.txt`** — index files that point agents at a *hosted* docs site via absolute URLs; meaningless without a `--base-url` and an HTTP server to serve them.
- **`search-index.json` / `search-content.json`** — a BM25 index built for the edge-safe runtime search API; it is queried over HTTP at runtime and has no role in an offline package.
- **`sitemap.xml` / `sitemap.md`** — crawl-discovery artifacts for web crawlers and hosted-site navigation; they encode absolute URLs and belong to the deployed site, not to a library tarball.
- **`robots.txt`** — a web-server directive file that controls crawler access to a hosted domain; it has no meaning inside `node_modules`.
- **`agent-readability.json`** — a manifest that ties together the above hosted artifacts (llms.txt paths, sitemap paths, robots.txt path) for HTTP-based agent discovery; again only useful when served from a URL.

None of these files contain any information that a coding agent reading an installed package needs — they either require a live URL to be useful or duplicate what `AGENTS.md` + `docs/*.md` already provide in a portable, path-relative form.
