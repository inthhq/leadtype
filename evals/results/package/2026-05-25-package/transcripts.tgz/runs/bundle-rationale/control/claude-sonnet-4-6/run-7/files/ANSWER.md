# Why AGENTS.md, not llms.txt, belongs in an npm tarball

`llms.txt` is a *website* convention: it lives at a well-known HTTP URL (e.g. `https://example.com/llms.txt`) so that online agents and crawlers can discover it by making a network request. It is also designed to contain *links* back to a hosted site, which are meaningless once the file is sitting inside `node_modules`. `AGENTS.md`, by contrast, is a *filesystem* convention: coding agents such as Codex and Cursor look for it on disk in the repository or installed package they are currently reading. Placing `AGENTS.md` at the package root means it lands at `node_modules/<your-pkg>/AGENTS.md` after `npm install`, giving any agent an unambiguous, version-matched, **offline** entry point into the docs without any network dependency. The leadtype README reinforces this directly: "The bundled output lives at `node_modules/<your-pkg>/AGENTS.md` after install so consumers can point coding agents at version-matched offline docs."

`leadtype generate --bundle` deliberately produces *only* `AGENTS.md` and the per-page `docs/*.md` mirrors. It skips every artifact that is meaningful only when docs are served from a website:

- **`llms.txt` and `llms-full.txt`** — HTTP-discovery indexes that embed public URLs; useless (and broken) inside a tarball.
- **`search-index.json` and `search-content.json`** — BM25 search indexes consumed by the runtime search API on a live server, not by an agent reading files from disk.
- **`sitemap.xml` and `sitemap.md`** — Search-engine and human navigation maps tied to absolute public URLs.
- **`robots.txt`** — An HTTP-server crawl-policy file that has no meaning inside a package directory.
- **`agent-readability.json`** — A structured manifest of the above web-served artifacts; equally irrelevant without a live origin.

The CLI help string captures this precisely: `--bundle` "skips llms.txt, llms-full.txt, and search artifacts — those are website-only."
