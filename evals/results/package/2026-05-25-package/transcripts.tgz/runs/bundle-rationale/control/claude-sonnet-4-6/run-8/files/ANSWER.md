# Why AGENTS.md, and What --bundle Skips

## AGENTS.md is the right file for docs inside an npm tarball

`AGENTS.md` (not `llms.txt`) is the conventional entry-point for coding agents that read a project from disk. When a developer runs `npm install`, the package lands at `node_modules/<pkg>/`. Coding agents such as Codex, Cursor, and similar tools look for `AGENTS.md` at a package or project root as a well-known, filesystem-first signal — no HTTP request required, no base URL needed, and the content is always version-matched to the exact release that was installed. `llms.txt`, by contrast, is a *website* convention: it lives at a hosted URL (e.g. `https://example.com/llms.txt`) and is fetched over HTTP by agents that can reach the internet. Dropping an `llms.txt` into the tarball gives it the wrong name, the wrong semantics, and no canonical URL to point at — agents scanning `node_modules/` won't know what to do with it. The `leadtype generate --bundle` command reflects this distinction explicitly: it writes `AGENTS.md` (plus per-page `docs/*.md` mirrors) and nothing else.

## What --bundle deliberately skips

According to the CLI help text and source code, `leadtype generate --bundle` skips every artifact that only makes sense when served from a hosted docs website:

- **`llms.txt`** – a URL-based index for HTTP agents; meaningless without a `base-url` and a live server.
- **`llms-full.txt`** – the root full-context fallback file, likewise served at a known public URL.
- **`docs/search-index.json`** (and `docs/search-content.json`) – a BM25 static search index built for an edge/CDN runtime query endpoint; there is no query server inside an npm package.
- **`docs/sitemap.xml`** and **`docs/sitemap.md`** – crawlability artifacts for search engines and web agents that discover pages via HTTP.
- **`docs/robots.txt`** – HTTP-server–level crawl instructions with no meaning on the local filesystem.
- **`docs/agent-readability.json`** – the agent-readability manifest that maps live URL paths to their markdown mirrors.

All of these artifacts assume a public `base-url`, an HTTP server, and consumers that reach the package over the network. None of those assumptions hold for a library shipped in a tarball, so `--bundle` skips them entirely and emits only the offline-readable `AGENTS.md` + `docs/*.md` subset.
