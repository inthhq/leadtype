# Shipping docs inside an npm tarball

## 1. Why `AGENTS.md`, not `llms.txt`

`llms.txt` is a *website* convention: it's a single, root-served index (e.g. `https://example.dev/llms.txt`) that HTTP-fetching agents discover by URL. That shape assumes a hosted origin, absolute links, and a crawler-style consumer. Inside an npm tarball there is no origin — the files land at `node_modules/<pkg>/`, and the consumer is a coding agent reading the filesystem. `AGENTS.md` is the right artifact for that environment: it's a version-matched, on-disk entry point that a project's own root `AGENTS.md` can point at (e.g. "read `node_modules/leadtype/AGENTS.md` first"), giving the agent offline, version-locked docs that exactly match the installed code. This is precisely the split `leadtype` codifies — `generate` emits website artifacts, `generate --bundle` emits `AGENTS.md` + `docs/*.md` for the tarball.

## 2. What `leadtype generate --bundle` deliberately skips

`--bundle` omits the website-only outputs: **`llms.txt`**, the root **`llms-full.txt`** fallback, and the static **`search-index.json`**. None of them belong in a package tarball: `llms.txt` and `llms-full.txt` are root-served discovery/aggregate files meant to be fetched over HTTP from a docs origin, and `search-index.json` powers an edge-served BM25 search runtime — it has no consumer when the docs are sitting in `node_modules/`, and it would just bloat install size. Those artifacts are emitted in default `leadtype generate` mode and served from the hosted docs site; the tarball ships only `AGENTS.md` and the flattened `docs/*.md` pages an agent will actually read from disk.
