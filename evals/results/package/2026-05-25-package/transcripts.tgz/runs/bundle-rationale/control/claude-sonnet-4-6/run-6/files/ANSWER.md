# Why AGENTS.md, and what --bundle skips

## AGENTS.md is the right shape for docs inside an npm tarball

`llms.txt` is an HTTP convention: it lives at a well-known URL on a hosted docs
site and is fetched over the network by agents that speak `Accept: text/markdown`
or that scrape `/llms.txt`. It has no defined meaning on a local filesystem.
`AGENTS.md`, by contrast, is a filesystem-first convention: coding agents such as
Codex, Claude, and Cursor look for it by name when they walk a project's
`node_modules/` tree. Because `leadtype` lists `AGENTS.md` (and `docs/*.md`) in
its `package.json` `"files"` array — not `llms.txt` — those files are included in
every published tarball and land at `node_modules/<pkg>/AGENTS.md` after
`npm install`. The result is version-matched, offline-readable documentation: the
agent reads the same docs revision that the installed code implements, without any
network round-trip or URL resolution. Dropping an `llms.txt` into the tarball
instead would be ignored by every agent that expects the HTTP convention, while
breaking every agent that expects a filesystem entry point named `AGENTS.md`.

## What `leadtype generate --bundle` deliberately skips

Running `leadtype generate --bundle` emits only `AGENTS.md` and the per-page
`docs/*.md` mirror files. It deliberately skips the four classes of artifact that
belong to a hosted website, not a package tarball:

- **`llms.txt` and `llms-full.txt`** — link indexes that embed absolute `base-url`
  values and are designed to be fetched by HTTP agents; they are meaningless and
  broken without a live origin URL.
- **`search-index.json` (and `search-content.json`)** — a BM25 static search index
  generated for the edge-safe runtime; consumers of an installed package query the
  package's own API, not a bundled search index.
- **`sitemap.xml` and `sitemap.md`** — crawlability artifacts for search engines and
  site-aware agents; they reference absolute URLs and have no value inside
  `node_modules`.
- **`robots.txt` and `agent-readability.json`** — HTTP-layer signals for web crawlers
  and the agent-readability manifest, again dependent on a hosted origin.

All of these are produced only in default (site) mode, as the CLI itself states:
`--bundle` runs in package mode and writes `AGENTS.md` + `docs/*.md`,
*skipping llms.txt, llms-full.txt, and search artifacts — those are website-only*.
