# Why `AGENTS.md`, not `llms.txt`, belongs inside an npm tarball

`AGENTS.md` is the right shape for docs shipped inside a package because it is the convention that coding agents — Codex, Copilot, Cursor, and similar tools — look for when they read a project or dependency from disk. When a consumer runs `npm install`, the file lands at `node_modules/<your-pkg>/AGENTS.md`; an agent inspecting the installed package finds it at a well-known, predictable path and immediately has version-matched documentation with no network request needed. `llms.txt`, by contrast, is a *web* convention: it lives at a URL root (`https://example.com/llms.txt`) and is designed to be fetched over HTTP by agents browsing a hosted site. Dropping an `llms.txt` into a tarball breaks that contract — there is no URL, no HTTP agent to serve it, and no standard that tells a coding agent to look for it inside `node_modules`. The `leadtype` package itself demonstrates this split: its `"files"` field in `package.json` lists `AGENTS.md` and `docs/*.md` for the tarball, and its README explicitly tells consumers to point their root `AGENTS.md` at `node_modules/leadtype/AGENTS.md` for offline, version-matched docs.

## What `leadtype generate --bundle` deliberately skips

Running `leadtype generate --bundle` produces only `AGENTS.md` and `docs/*.md` — the flat, agent-readable markdown files. It deliberately omits the three website-oriented artifacts that the default (non-`--bundle`) mode emits:

- **`llms.txt`** — an index file meant to be served at a site's root URL and discovered over HTTP; meaningless without a web server.
- **Root `llms-full.txt`** — a single large concatenated context file designed as an HTTP fallback for agents that cannot walk individual URLs; again only useful when hosted.
- **`search-index.json`** — a static BM25 search index built for an edge-deployed search endpoint; it has no runtime consumer inside a plain npm package and would only inflate the tarball size for no benefit.

All three artifacts assume a live URL, a web server, or both. Shipping them in a tarball would add dead weight without giving package consumers or their coding agents anything they can actually use.
