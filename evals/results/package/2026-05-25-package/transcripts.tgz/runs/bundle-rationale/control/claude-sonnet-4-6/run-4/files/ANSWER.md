# Why `AGENTS.md`, not `llms.txt`, for docs inside an npm tarball

`AGENTS.md` is the right choice because its filename is the convention that coding agents (and tools like Codex, Cursor, and similar) look for when they open a project from disk — specifically inside `node_modules/<pkg>/AGENTS.md` after `npm install`. A file at that path gives every consumer version-matched, offline-available docs that agents can read without any network request. `llms.txt`, by contrast, is a *website* convention: it lives at the root of a hosted docs site and is fetched over HTTP (often with an `Accept: text/markdown` header). It assumes a live base URL and is designed for HTTP-based agent discovery, not for local filesystem traversal. Shipping `llms.txt` in a tarball would put a file in a location that tooling does not scan for, with links that point at an external site rather than the installed package contents, giving agents nothing useful at install time.

## What `leadtype generate --bundle` deliberately skips

When run with `--bundle`, `leadtype generate` writes only `AGENTS.md` and `docs/*.md` to the package directory. It skips all of the following website-only artifacts:

- **`llms.txt`** and **`llms-full.txt`** — HTTP-served index files for agent discovery via a hosted URL; meaningless without a `--base-url` and a running server.
- **`search-index.json`** (and `search-content.json`) — a BM25 static search index built for the edge-safe runtime query API; it is queried through a fetch/HTTP route, not by reading a file from `node_modules`.
- **`sitemap.xml`** and **`sitemap.md`** — crawl maps for search engines and HTTP agents; only relevant to a publicly reachable domain.
- **`robots.txt`** — a web-server directive file that has no meaning inside a package tarball.
- **`agent-readability.json`** — a manifest that links the above website artifacts together for agent-readability middleware.

None of these make sense in a package because they either require absolute base URLs, depend on a running HTTP server, or are consumed only by web crawlers — not by a coding agent reading from the local filesystem after `npm install`.
