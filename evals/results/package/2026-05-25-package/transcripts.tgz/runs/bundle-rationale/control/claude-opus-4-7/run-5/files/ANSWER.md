# Shipping docs inside an npm tarball

## Why `AGENTS.md`, not `llms.txt`

`llms.txt` is a *website* convention: it lives at a known URL (`/llms.txt`) so that HTTP clients and crawlers can discover a curated set of links into a hosted docs site. Those links are absolute URLs that only resolve when the docs are served. Inside an installed npm package there is no host, no base URL, and no fetcher — the consumer is a coding agent reading files off disk at `node_modules/<pkg>/`. `AGENTS.md` is the right shape for that environment: it's a single, conventional entry-point filename that agents already look for, it sits at the package root next to `README.md`, and it points at sibling markdown files using relative paths (`docs/*.md`) that work offline and stay version-matched to the installed package. This is exactly what leadtype's README recommends — after `npm install leadtype`, you point your project's own `AGENTS.md` at `node_modules/leadtype/AGENTS.md`, which then links into the bundled `docs/*.md`.

## What `leadtype generate --bundle` deliberately skips

Per the CLI's own help text, bundle mode writes only `AGENTS.md` and `docs/*.md`, and explicitly skips the website-only artifacts that default (site) mode produces:

- **`llms.txt`** (root and `docs/llms.txt`) — a URL-based summary index meant to be served from a base URL; meaningless inside a tarball.
- **`llms-full.txt`** — the full-context fallback file served at a site root for HTTP agents that want one big blob; redundant when the agent can just read the `docs/*.md` files directly off disk.
- **Search artifacts** (`docs/search-index.json`, `search-content.json`) — a static BM25 index designed to be fetched by a browser/edge runtime; it bloats the tarball and has no consumer in a Node `node_modules` context.
- **Agent-readability/sitemap artifacts** (`docs/sitemap.xml`, `docs/sitemap.md`, `docs/robots.txt`, `agent-readability.json`, `i18n-manifest.json`) — all crawler- and host-oriented files keyed to absolute URLs; they belong on the deployed site, not in an installed package.

The common thread: every skipped artifact assumes a base URL and an HTTP fetcher. Bundle mode keeps only the two things a local agent actually needs — a root entry point (`AGENTS.md`) and the markdown it links to.
