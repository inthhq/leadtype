# Bundling docs in an npm tarball

## Why `AGENTS.md`, not `llms.txt`

`llms.txt` is a *website* convention: it lives at a site's root and points crawlers/HTTP agents at the canonical, hosted URLs that make up a documentation set. Inside an installed package there is no site, no base URL, and no HTTP — there is only `node_modules/<pkg>/`. A coding agent working in a checkout doesn't fetch URLs; it opens files on disk. `AGENTS.md` is the file-system-native equivalent: a version-matched entry point at the package root that an agent (or a project's own root `AGENTS.md`) can chain into, with relative links into `node_modules/<pkg>/docs/*.md`. That's exactly the shape leadtype's own README recommends — after `npm install leadtype`, projects point their root `AGENTS.md` at `node_modules/leadtype/AGENTS.md`, which in turn references the flattened per-page markdown that shipped in the tarball. Shipping `llms.txt` instead would advertise URLs the consumer can't resolve and duplicate a file whose job is already done by the hosted site.

## What `leadtype generate --bundle` deliberately skips

Per leadtype's README, the `--bundle` mode emits only `AGENTS.md` and `docs/*.md`. The website-only artifacts that the default (non-bundle) `generate` mode produces are intentionally omitted:

- **`llms.txt`** — a hosted-site index of absolute URLs; meaningless from inside `node_modules` and aimed at HTTP agents requesting `/llms.txt` or `Accept: text/markdown` from the live site.
- **Root `llms-full.txt`** — the single-file fallback dump of the whole corpus for HTTP agents that can't follow links; it's pure duplication of the per-page `docs/*.md` files already in the tarball, so it would just bloat install size.
- **`search-index.json`** (the static BM25 search index, e.g. `public/docs/search-index.json`) — built to be served from an edge/runtime search endpoint on the docs site. Consumers of the package don't run that endpoint, and shipping the index would add weight that no installer will ever query.

In short: the bundle mode keeps what an on-disk agent can actually use (`AGENTS.md` + markdown pages) and drops the three artifacts whose only purpose is to be served over HTTP from a docs website.
