# Why `AGENTS.md`, and what `--bundle` skips

## 1. `AGENTS.md` is the right shape for docs inside an npm tarball

`AGENTS.md` is the conventional entry point that coding agents look for when
reading an installed package from disk. `leadtype generate --bundle` writes it
to the package root so that, after `npm install`, every agent can find
version-matched docs at `node_modules/<your-pkg>/AGENTS.md` without needing a
network request. The file is listed in `"files"` in `package.json` (alongside
`docs/*.md`) so it ships inside the tarball automatically. `llms.txt`, by
contrast, is a *website* convention — it lives at a hosted URL (e.g.
`https://example.com/llms.txt`) and is fetched over HTTP by tools that accept
`text/markdown` or crawl `/llms.txt`. Dropping it inside a tarball gains
nothing: there is no URL to crawl, no server to serve it, and agents reading
the local filesystem already have a well-known filename (`AGENTS.md`) to look
for. Using `llms.txt` in a package would be the wrong abstraction for the wrong
transport.

## 2. Artifacts that `--bundle` deliberately skips

When `leadtype generate --bundle` runs it omits every artifact that only makes
sense when docs are served from a website:

- **`llms.txt`** and **`llms-full.txt`** — HTTP-discovery index files intended
  to be fetched by remote agents; meaningless without a base URL and a server.
- **`search-index.json`** and **`search-content.json`** — the static BM25
  search index is consumed at runtime by the hosted search API; it has no role
  inside a tarball where there is no query endpoint.
- **`sitemap.xml`** and **`sitemap.md`** — crawler/SEO artifacts that reference
  absolute public URLs, which do not exist in an offline package context.
- **`robots.txt`** — an HTTP server directive; irrelevant on the local
  filesystem.
- **`agent-readability.json`** — the readability manifest references the same
  hosted URL tree as the sitemap and is generated as part of the website
  pipeline only.

The CLI's own help text (in `GENERATE_USAGE`) summarises this directly: bundle
mode *"skips llms.txt, llms-full.txt, and search artifacts — those are
website-only"*. All of these files either depend on a public base URL, require
an HTTP server to be useful, or duplicate information that the offline
`docs/*.md` files already provide in a simpler form.
