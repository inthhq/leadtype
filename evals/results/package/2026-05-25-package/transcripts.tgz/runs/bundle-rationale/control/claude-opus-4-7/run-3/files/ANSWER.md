# Why `AGENTS.md` (not `llms.txt`) belongs in an npm tarball

`llms.txt` is a *website* convention: a stable URL at the site root that points HTTP-fetching agents at a curated, link-based map of the docs hosted elsewhere. Inside an installed npm package those links don't make sense — the consumer already has the bytes on disk at `node_modules/<pkg>/`, version-matched to whatever they installed. The right shape there is `AGENTS.md` at the package root: a plain entry-point file that a coding agent can read directly and that points at sibling `docs/*.md` files on the local filesystem. That's exactly the split `leadtype` itself ships (see its README's "Bundled agent docs" section) and that its CLI documents — quoting `leadtype generate --help`: *"With `--bundle`, runs in package mode and writes: AGENTS.md, docs/\*.md (skips llms.txt, llms-full.txt, and search artifacts — those are website-only)."* So tell your teammate to drop `AGENTS.md` (plus the flattened `docs/*.md` it references) into the tarball, and keep `llms.txt` for the hosted docs site.

# Website artifacts `leadtype generate --bundle` deliberately skips

In bundle mode `leadtype` intentionally **does not** emit:

- **`llms.txt`** — a root-of-site index of absolute URLs; meaningless inside `node_modules`, where the consumer wants on-disk paths, not links back to a website.
- **`llms-full.txt`** — the concatenated full-corpus fallback aimed at HTTP agents that can't crawl; it duplicates the per-page `docs/*.md` already in the tarball and just bloats install size.
- **Search artifacts** (`docs/search-index.json`, search content files, `agent-readability.json`) — a BM25 index built for an edge/browser runtime serving a hosted site; consumers of an installed package grep the filesystem instead, so shipping the index is dead weight.
- **Sitemap/robots** (`docs/sitemap.xml`, `docs/sitemap.md`, `docs/robots.txt`) — crawler and SEO hints addressed to a public origin; an npm tarball has no origin, no crawlers, and no SEO surface.

All of these are emitted only in default (site) mode, where they're served from your docs host. Keeping them out of the package keeps the install small and avoids shipping URLs and indexes that would immediately go stale relative to the consumer's actual filesystem layout.
