# Why AGENTS.md, not llms.txt, belongs inside an npm tarball

`llms.txt` is a *web convention* — it lives at a well-known URL on a hosted site and is fetched over HTTP by agents that understand the protocol. Inside an npm tarball there is no HTTP server, no URL, and no discovery mechanism for `llms.txt`; it would just be an invisible file that neither npm tooling nor coding agents have any reason to look for. `AGENTS.md`, by contrast, is the established filesystem convention that coding agents (and tools like Codex, Cursor, and similar) recognise when they are working *on disk* inside a project. Because `npm install` places the package at a predictable path (`node_modules/<pkg>/`), a root-level `AGENTS.md` in the tarball lands at `node_modules/<pkg>/AGENTS.md` — exactly where an agent reading the installed package will look. leadtype's own `package.json` confirms this: its `"files"` array explicitly includes `"AGENTS.md"` and `"docs"` (the per-page markdown mirrors), and its README instructs consumers to point their project's root `AGENTS.md` at `node_modules/leadtype/AGENTS.md` for version-matched, offline-readable docs. `llms.txt` is absent from `"files"` entirely.

## What `leadtype generate --bundle` deliberately skips

Running `leadtype generate --bundle` produces only `AGENTS.md` and `docs/*.md`. It intentionally omits the three website-only artifacts that the default (non-bundle) mode emits:

- **`llms.txt`** — an index file designed to be served from a public URL; meaningless without an HTTP host.
- **`llms-full.txt`** (root full-context fallback) — a concatenated dump intended as a single large HTTP response for agents that cannot follow links; not useful or appropriate inside a package.
- **`search-index.json`** — a static BM25 search index built for an edge-safe runtime query layer on a hosted docs site; there is no search server inside an npm package, so shipping the index would only add dead weight to the tarball.

These artifacts belong to the *website* layer of the pipeline (hosted, URL-addressable, served to browsers and HTTP agents). The bundle mode strips them out because an npm package only needs the parts a coding agent can read directly from the filesystem after `npm install`.
