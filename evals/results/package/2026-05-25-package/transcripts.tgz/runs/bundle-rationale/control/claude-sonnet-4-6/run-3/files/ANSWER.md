# Why `AGENTS.md`, not `llms.txt`, is the right shape for npm-shipped docs

`llms.txt` is a **website convention**: it lives at a well-known HTTP URL (e.g. `https://example.com/llms.txt`) and is fetched by agents over the network. Inside an npm tarball there is no HTTP server, no URL to advertise, and no guarantee the file will be discovered. `AGENTS.md`, by contrast, is the **filesystem convention** that coding agents (and the tools that drive them) look for when reading an installed package from disk. After `npm install` the file lands at `node_modules/<your-pkg>/AGENTS.md` — a predictable, version-matched path that a project's root `AGENTS.md` can point at directly. `leadtype generate --bundle` reflects this split exactly: it emits `AGENTS.md` + `docs/*.md` for the tarball and reserves `llms.txt` / `llms-full.txt` for the hosted-site mode.

## Artifacts that `leadtype generate --bundle` deliberately skips

Running with `--bundle` omits every artifact that only makes sense when served over HTTP from a docs website:

| Skipped artifact | Why it doesn't belong in a package |
|---|---|
| `llms.txt` / `docs/llms.txt` | A URL-index file meant to be fetched at a known HTTP address; meaningless on disk inside `node_modules`. |
| `llms-full.txt` | A single-file full-context dump for HTTP agents; redundant when `docs/*.md` are already present locally. |
| `docs/search-index.json` + `docs/search-content.json` | A BM25 search index built for the edge-safe runtime query API; consumers of an installed package use the markdown files directly, not a hosted search endpoint. |
| `docs/sitemap.xml` + `docs/sitemap.md` | Crawler / SEO artifacts that reference absolute public URLs; they have no meaning without a deployed site. |
| `docs/robots.txt` | An HTTP crawl-control directive; irrelevant in a package tarball. |
| `docs/agent-readability.json` | An agent-readability manifest that cross-links to hosted URL paths; the local `AGENTS.md` + `docs/*.md` serve the same purpose for offline consumers. |

The CLI's own help text summarises the rule plainly: `--bundle` *"skips llms.txt, llms-full.txt, and search artifacts — those are website-only"*.
