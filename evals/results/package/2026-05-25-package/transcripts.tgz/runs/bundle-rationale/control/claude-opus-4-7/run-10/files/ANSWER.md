# Bundling docs for coding agents: prefer `AGENTS.md`

## Why `AGENTS.md`, not `llms.txt`, inside the tarball

`llms.txt` is a **website convention** — a root-served index whose value comes
from absolute URLs that point HTTP-aware agents at hosted markdown mirrors and
a `llms-full.txt` fallback. Once that file is buried inside
`node_modules/<pkg>/`, the absolute URLs no longer match where the file lives,
the agent can't fetch the siblings it advertises, and nothing about the layout
tells a coding agent "start here." `AGENTS.md`, by contrast, is the convention
coding agents already look for at a project (or package) root, and it works
purely with **relative on-disk paths** — exactly the shape that survives being
copied into a tarball and unpacked under `node_modules`. That's why
`leadtype generate --bundle` writes `AGENTS.md` plus `docs/*.md` at the package
root: consumers can point their own root `AGENTS.md` at
`node_modules/<pkg>/AGENTS.md` and get version-matched, offline docs that the
agent can actually open.

## What `--bundle` deliberately skips, and why

Per `leadtype generate --bundle`'s own help text, bundle mode emits only
`AGENTS.md` and `docs/*.md`, and explicitly **skips the website-only
artifacts**: `llms.txt`, the root `llms-full.txt` fallback, and the search
artifacts (`docs/search-index.json` / `search-content.json`, plus the
`agent-readability.json` manifest, `sitemap.xml`, `sitemap.md`, and
`robots.txt` that the site mode also produces). Those files only make sense
when served from a real origin: `llms.txt` and `llms-full.txt` rely on a
`--base-url` to resolve links, the search index is built to be fetched by an
edge runtime over HTTP, and sitemaps/robots are addressed to web crawlers.
Shipping them inside an npm tarball would bloat the package with files no
consumer can meaningfully use from disk, and would advertise URLs that don't
resolve from `node_modules/`. Keeping the bundle to `AGENTS.md` + `docs/*.md`
is the artifact set that actually pays its weight on `npm install`.
