# Why AGENTS.md, not llms.txt, belongs in an npm tarball

`llms.txt` is a *website convention*: it lives at a URL root (e.g. `https://example.com/llms.txt`) and is fetched over HTTP by agents that discover it via well-known paths. It has no meaning on a local filesystem inside `node_modules`. `AGENTS.md`, by contrast, is the established convention for *on-disk* agent documentation — coding tools (Codex, Cursor, Claude Code, etc.) already know to look for `AGENTS.md` at the root of a directory tree. When a consumer runs `npm install`, the file lands at `node_modules/<your-pkg>/AGENTS.md` and is immediately readable offline, version-matched to the exact release, with no network request required. The leadtype README makes this explicit: "point your project's root `AGENTS.md` at the bundled docs: `node_modules/leadtype/AGENTS.md`." Shipping `llms.txt` instead would break every tool that expects the HTTP convention while helping none of the tools that read the filesystem.

## What `leadtype generate --bundle` deliberately skips

According to the CLI help text baked into `dist/cli.js` and the behaviour in `runGenerateCommand`, `--bundle` mode writes only `AGENTS.md` and `docs/*.md` (flattened markdown mirrors). It deliberately omits every artifact that only makes sense when served from a hosted docs site:

| Skipped artifact | Why it doesn't belong in a package |
|---|---|
| `llms.txt` / `llms-full.txt` | Designed to be fetched from a URL root; meaningless as a file path inside `node_modules`. |
| `docs/search-index.json` / `search-content.json` | A BM25 index built for the search runtime — it requires a running HTTP endpoint and has no use to an agent reading from disk. |
| `docs/sitemap.xml` / `sitemap.md` | Sitemap formats are consumed by web crawlers via HTTP; they reference absolute URLs that don't exist for a local package copy. |
| `docs/robots.txt` | A web-server directive file; it has no effect and no consumer inside a tarball. |
| `agent-readability.json` (the readability manifest) | A hosting-side manifest that records URL paths for HTTP-based agent discovery tools; irrelevant without a live server. |

All of these artifacts assume a public base URL and are produced in default (site) mode only. Bundle mode keeps the output to the minimum a coding agent actually needs offline: a structured entry-point (`AGENTS.md`) and the flat markdown topic files it references.
