# Bundling docs inside the `leadtype` tarball

## Why `AGENTS.md`, not `llms.txt`

`llms.txt` is a *website* convention: it lives at a known URL on a hosted docs site and is fetched by HTTP agents that hit the origin (often via `Accept: text/markdown` or a direct `/llms.txt` request). Inside an npm tarball there is no origin, no base URL, and no fetch — a coding agent is reading files off disk at `node_modules/<pkg>/`. The idiomatic entry point for that case is `AGENTS.md` at the package root, which a project's own root `AGENTS.md` can point at (e.g. "read `node_modules/leadtype/AGENTS.md` first"). That gives consumers a **version-matched, offline** entry point that travels with the installed code, which is exactly the shape `leadtype generate --bundle` produces: `AGENTS.md` plus `docs/*.md` flattened markdown.

## What `--bundle` deliberately skips, and why

Per the `leadtype` README, the website-style outputs are emitted only in the default `leadtype generate` mode and are intentionally *omitted* from `--bundle`: **`llms.txt`**, the root **`llms-full.txt`** fallback, and **`search-index.json`**. They don't belong in a package because they're hosted-site artifacts — `llms.txt` and `llms-full.txt` assume a single canonical URL space that agents crawl over HTTP, and `search-index.json` is a static BM25 index meant to be served to a browser/edge runtime as part of the docs site. Shipping them inside a tarball would bloat installs with data that has no consumer on disk (no URL to resolve against, no runtime loading the index), while `AGENTS.md` + `docs/*.md` give local agents everything they actually need.
