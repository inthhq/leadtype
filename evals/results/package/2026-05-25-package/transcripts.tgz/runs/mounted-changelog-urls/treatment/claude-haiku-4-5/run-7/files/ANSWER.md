# Serving Changelog at `/changelog/...` with Leadtype

## The Command

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

The key is `changelog=/changelog`, which tells leadtype:
- Read MDX source from the `changelog/` folder
- Serve canonical URLs at `/changelog/...` (not `/docs/changelog/...`)
- Keep the page searchable by maintaining an internal copy for the search index

## What Happens to `changelog/v1.mdx`

For a file like `changelog/v1.mdx`, the pipeline emits:

| Artifact | Path | Purpose |
| --- | --- | --- |
| **Internal generated copy** | `public/docs/changelog/v1.md` | Built automatically for search indexing and agent helpers (never served to humans directly). |
| **Public mirror** | `public/changelog/v1.md` | Static markdown mirror served at the canonical public URL. |
| **Canonical URL** | `/changelog/v1` | The URL agents see in `llms.txt`, search metadata (`search-index.json`), `sitemap.xml` entries, and `agent-readability.json`. |

The internal copy ensures search queries can find and rank content from the changelog. The public mirror and canonical URLs ensure humans and agents both navigate to `/changelog/v1` — not `/docs/changelog/v1`.

## How It Works

When you specify `--docs-dir changelog=/changelog`:

1. **Mount point**: Leadtype merges the changelog folder into the generated docs tree, keeping an internal reference copy at `public/docs/changelog/` for search.
2. **URL prefix**: The `=/changelog` suffix tells leadtype to emit canonical links pointing to `/changelog` instead of `/docs/changelog`.
3. **Public output**: A static markdown mirror is written to `public/changelog/` so the canonical URL resolves correctly for both HTML rendering and content negotiation.
4. **Search scope**: The page is fully indexed under its canonical `/changelog/v1` URL, so agents can discover and cite it properly.

All three artifacts (internal copy, public mirror, and canonical URL) work together to make the changelog searchable while serving it at its own top-level URL.
