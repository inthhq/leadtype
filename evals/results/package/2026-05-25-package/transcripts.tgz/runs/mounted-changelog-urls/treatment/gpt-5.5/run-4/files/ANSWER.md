# Answer

Use a mounted second docs directory for the changelog:

```bash
leadtype generate --src . --docs-dir docs --docs-dir changelog=/changelog --out public
```

For a source file such as `changelog/v1.mdx`, that command:

- keeps the searchable/generated internal markdown copy at `public/docs/changelog/v1.md`;
- also writes a public static mirror at `public/changelog/v1.md`, so the site can serve it from `/changelog/v1.md` instead of `/docs/changelog/v1.md`;
- records the mounted canonical URL as `/changelog/v1.md` in agent-facing artifacts such as `llms.txt`, search metadata, sitemap entries, and `agent-readability.json`.

Because the internal copy remains under `public/docs/changelog/`, leadtype's search index still includes the changelog content while using the `/changelog/...` public URL prefix for result/canonical links.
