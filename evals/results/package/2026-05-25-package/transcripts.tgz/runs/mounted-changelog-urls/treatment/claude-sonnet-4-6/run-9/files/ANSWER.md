# Serving `changelog/` under `/changelog/...`

## 1. The single `leadtype generate` invocation

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

### Why each flag is needed

| Flag | Purpose |
|---|---|
| `--src .` | Project root — where `leadtype.config.ts` / `docs.config.ts` are resolved from. |
| `--docs-dir docs` | First (primary) source folder; mounted at the generated docs root (`/docs/…`). |
| `--docs-dir changelog=/changelog` | Second source folder. The `<dir>=<url-prefix>` syntax mounts `changelog/` with its **own public URL prefix `/changelog`** instead of the default `/docs/changelog`. Without the `=/changelog` suffix the pages would land at `/docs/changelog/…`. |
| `--out public` | Output root where all generated artifacts are written. |
| `--base-url https://example.com` | Absolute base used in canonical links, `llms.txt`, sitemap entries, and `agent-readability.json`. Required for correct canonical URLs. |

The `--docs-dir changelog=/changelog` flag is the key piece: the `<dir>=<url-prefix>` form tells leadtype to keep the internal copy under `public/docs/changelog/` (so search and runtime helpers can find it) **and** also publish a static markdown mirror at `public/changelog/` with canonical links that point to `/changelog/…`, not `/docs/changelog/…`.

---

## 2. What the pipeline emits for `changelog/v1.mdx`

### Internal generated copy

```
public/docs/changelog/v1.md
```

This is the MDX-to-markdown conversion result. It lives under `public/docs/` regardless of the public URL prefix, because the search index generator (`generateDocsSearchFiles`) and runtime helpers always read from `<outDir>/docs/`. This is what makes the changelog **searchable** — it is indexed alongside all other docs content and contributes records to `public/docs/search-index.json` and `public/docs/search-content.json`.

### Public mirror

```
public/changelog/v1.md
```

Because the `=/changelog` URL prefix was supplied, leadtype also writes a **static markdown mirror** at the path that matches the public URL. HTTP agents and human browsers requesting `https://example.com/changelog/v1.md` (or `Accept: text/markdown` on `/changelog/v1`) receive this file.

### Canonical URL that agents see

```
https://example.com/changelog/v1
```

(Or `/changelog/v1.md` for the raw markdown form.)

This canonical URL appears in every agent-facing artifact:

- **`public/llms.txt`** — the top-level discovery file lists the page as `https://example.com/changelog/v1.md`.
- **`public/docs/search-index.json`** — search result records carry `url: "/changelog/v1"` (not `/docs/changelog/v1`), so a matched result deep-links correctly.
- **`public/docs/sitemap.xml` / `sitemap.md`** — the sitemap `<loc>` and markdown link both reference `https://example.com/changelog/v1`.
- **`public/docs/agent-readability.json`** — the manifest entry for the page uses the canonical `/changelog/v1` path for markdown responses, JSON-LD, and attribution metadata.
- **Markdown frontmatter** — the generated `.md` files include `canonical_url: https://example.com/changelog/v1` and `last_updated` so copied content retains its source attribution.

### Summary table

| Artifact | Path on disk | Canonical URL |
|---|---|---|
| Internal generated copy (search input) | `public/docs/changelog/v1.md` | — (internal only) |
| Public markdown mirror | `public/changelog/v1.md` | `https://example.com/changelog/v1` |
| Search index entry | inside `public/docs/search-index.json` | `/changelog/v1` |
| `llms.txt` entry | `public/llms.txt` | `https://example.com/changelog/v1.md` |
| Sitemap entry | `public/docs/sitemap.xml` | `https://example.com/changelog/v1` |
| Agent readability manifest | `public/docs/agent-readability.json` | `https://example.com/changelog/v1` |
