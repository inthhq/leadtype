# Answer

Use a URL-prefix mount for the sibling changelog source:

```bash
leadtype generate --src . --docs-dir docs --docs-dir changelog=/changelog --out public
```

For `changelog/v1.mdx`, leadtype treats `docs` as the main docs root and mounts the extra `changelog` source under the merged docs path `changelog`, but with the public URL prefix `/changelog`:

- Internal generated copy: `public/docs/changelog/v1.md` — this stays in the docs-scoped generated tree, so search/runtime helpers can index and read it with the rest of the docs.
- Public markdown mirror: `public/changelog/v1.md` — this is the URL-prefix mirror outside `/docs`, so the hosted markdown page is served at `/changelog/v1.md` rather than `/docs/changelog/v1.md`.
- Canonical agent-facing URL: `/changelog/v1.md` — this is what leadtype emits in agent-facing artifacts such as `llms.txt`, search metadata, sitemap entries, and `agent-readability.json`.
