# Mounting `changelog/` at `/changelog` instead of `/docs/changelog`

## 1. The command

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public
```

The first `--docs-dir docs` mounts the main docs folder at the docs root (URL prefix `/docs`, which is the default). The second uses the `<dir>=<url-prefix>` form documented for `--docs-dir` to remount `changelog/` at the public URL prefix `/changelog`. Both folders feed into the same generated docs tree, so the changelog pages are merged into the same search index, `llms.txt` listing, sitemap, and Agent Readability manifest as the rest of the docs — they're just published under a different URL prefix.

## 2. What gets emitted for `changelog/v1.mdx`

With the command above, a source file at `changelog/v1.mdx` produces three distinct things:

- **Internal generated copy** — `public/docs/changelog/v1.md`
  This is the canonical on-disk artifact that powers `createDocsSource()`, the search content/index, link resolution, and any runtime helpers. It keeps the `/docs/...` shape so all the docs-scoped artifacts (`public/docs/search-index.json`, `public/docs/sitemap.xml`, `public/docs/agent-readability.json`, etc.) stay coherent.
- **Public markdown mirror** — `public/changelog/v1.md`
  A static markdown mirror written at the public prefix so agents that fetch `https://<host>/changelog/v1.md` directly (or follow links from `llms.txt`) get the page without any rewrite layer in front.
- **Canonical URL agents see** — `/changelog/v1.md` (resolved against `--base-url` if provided, e.g. `https://leadtype.dev/changelog/v1.md`)
  This is the URL that shows up in `llms.txt`, `llms-full.txt`, the search metadata, sitemap entries, and `agent-readability.json`. Nothing in those artifacts points at `/docs/changelog/...` — agents only ever see the `/changelog/...` form, even though the internal generated copy lives under `public/docs/changelog/`.

Net effect: the changelog is part of one unified, searchable docs corpus internally, but every agent- and human-facing URL is published cleanly under `/changelog/...`.
