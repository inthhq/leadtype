# Answer

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://YOUR_SITE_ORIGIN
```

Replace `https://YOUR_SITE_ORIGIN` with the deployed site origin.

For `changelog/v1.mdx`, the mounted `--docs-dir` does this:

- **Internal generated copy:** Leadtype still stages/converts it under the generated docs tree as `public/docs/changelog/v1.md`. Search and runtime/agent helpers read from this internal `public/docs/**` tree, so the changelog remains searchable.
- **Public markdown mirror:** Because `changelog` is mounted at `/changelog`, Leadtype also mirrors the generated markdown to `public/changelog/v1.md`.
- **Canonical URL agents see:** Agent metadata, sitemap/search metadata, and canonical page URLs use the mount, so the page is identified as `https://YOUR_SITE_ORIGIN/changelog/v1` (path: `/changelog/v1`), not `/docs/changelog/v1`. Markdown links for the mirror resolve to `/changelog/v1.md`.
