# Serving Changelog Under `/changelog/...` While Maintaining Searchability

## 1. The Single `leadtype generate` Invocation

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

**Key detail:** The syntax `changelog=/changelog` mounts the `changelog/` folder at the public URL prefix `/changelog` instead of the default `/docs/changelog`.

---

## 2. What It Emits for `changelog/v1.mdx`

### Internal Generated Copy
- **File:** `public/docs/changelog/v1.md`
- **Purpose:** Indexing for search, runtime resolution, and agent helpers
- **Location:** Inside the internal docs tree for operational consistency

### Public Mirror
- **File:** `public/changelog/v1.md`
- **Purpose:** Static canonical markdown mirror that humans and agents fetch directly
- **URL:** Served at `/changelog/v1.md` on the website

### Canonical URLs (in Agent Artifacts)
**Agents see these URLs in:**
- `llms.txt` and `llms-full.txt`: `/changelog/v1.md` (markdown link)
- `search-index.json` and `search-content.json`: Metadata points to `/changelog/v1`
- `sitemap.xml`: Entry for `/changelog/v1.md`
- `agent-readability.json`: Manifest includes `/changelog/v1` as the canonical path

**Result:** The changelog remains searchable via the internal indexed copy at `public/docs/changelog/v1.md`, but all agent-visible references and static mirrors point to `/changelog/v1.md` — the folder is "mounted out" of `/docs` to its own top-level route without losing search functionality.
