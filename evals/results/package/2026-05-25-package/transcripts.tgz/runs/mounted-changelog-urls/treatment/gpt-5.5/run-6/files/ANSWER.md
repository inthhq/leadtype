# Answer

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

Replace `https://example.com` with the site’s real origin.

For a source file such as `changelog/v1.mdx`, the `changelog=/changelog` mount means:

- Leadtype still creates the internal merged-docs copy at `public/docs/changelog/v1.md`. Search generation reads the merged `public/docs/**` corpus, so the changelog page remains searchable.
- Because the public URL prefix is `/changelog`, Leadtype also writes the public markdown mirror at `public/changelog/v1.md`.
- Agent-facing URLs use the `/changelog` mount, not `/docs/changelog`: the canonical page URL is `https://example.com/changelog/v1`, and the markdown URL advertised for agents is `https://example.com/changelog/v1.md`.
