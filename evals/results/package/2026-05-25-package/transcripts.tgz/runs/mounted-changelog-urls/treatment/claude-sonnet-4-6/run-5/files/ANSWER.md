# Serving `changelog/` under `/changelog/` with `leadtype generate`

## 1. The single `leadtype generate` invocation

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

The key piece is the `<dir>=<url-prefix>` syntax on the second `--docs-dir` flag:

- `changelog` tells leadtype to read MDX from the `./changelog/` folder on disk.
- `=/changelog` mounts that folder at the public URL prefix `/changelog` instead of the default `/docs/changelog`.

Without the `=/changelog` suffix, the folder would be nested under the docs root as `/docs/changelog/...`. With it, the folder gets its own public URL tree while still being included in search.

---

## 2. What leadtype emits for `changelog/v1.mdx`

### Internal generated copy (for search and runtime helpers)

```
public/docs/changelog/v1.md
```

Leadtype always writes a copy of every converted file under `public/docs/` — the stable docs root. This copy is what the search-index pipeline (`public/docs/search-index.json` and `public/docs/search-content.json`) reads, so the file is fully indexed and searchable even though it lives at a different public URL.

### Public mirror (the static markdown file served at the public path)

```
public/changelog/v1.md
```

Because the `=/changelog` URL prefix was specified, leadtype also writes a static mirror at the matching path under the output root. A CDN or static host can serve this file directly at `https://example.com/changelog/v1.md`.

### Canonical URL that agents see

```
/changelog/v1
```

All agent-facing artifacts — `llms.txt`, `llms-full.txt`, `sitemap.xml`, `sitemap.md`, `agent-readability.json`, and every `url` field in the search index — use the canonical URL derived from the `=/changelog` prefix. Agents (and search crawlers) therefore discover and attribute this page as living at `/changelog/v1`, **not** at `/docs/changelog/v1`.

---

## Summary of the three artifacts side-by-side

| Artifact | Path / value |
|---|---|
| Internal generated copy | `public/docs/changelog/v1.md` |
| Public markdown mirror | `public/changelog/v1.md` |
| Canonical URL (llms.txt, search, sitemap, agent-readability) | `https://example.com/changelog/v1` |
