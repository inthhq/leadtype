# Serving `changelog/` under `/changelog/...`

## 1. The command

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public
```

The first `--docs-dir docs` mounts the main docs folder at the generated docs
root. The second uses the `<dir>=<url-prefix>` form documented for
`leadtype generate` — it tells the pipeline that the sibling `changelog/`
folder is its own source whose public URL prefix is `/changelog`, not
`/docs/changelog`.

## 2. What gets emitted for `changelog/v1.mdx`

For a single source file `changelog/v1.mdx`, the pipeline produces three
distinct things:

- **Internal generated copy** — `public/docs/changelog/v1.md`.
  This is the markdown the docs source/search index and runtime helpers read
  from. Every page, no matter what URL prefix it gets, lives under
  `<out>/docs/...` internally so a single source/search pipeline can see it.
  This is what keeps the changelog searchable.

- **Public mirror** — `public/changelog/v1.md`.
  Because `changelog` was mounted with `=/changelog`, leadtype additionally
  writes a static markdown mirror at the requested public prefix. That file is
  what a browser or agent actually fetches at `https://your.site/changelog/v1.md`.

- **Canonical URL agents see** — `/changelog/v1.md` (not `/docs/changelog/v1.md`).
  The mount prefix is propagated into every URL-anchored artifact:
  `llms.txt`, search metadata, `sitemap.xml`, and `agent-readability.json` all
  reference the page as `/changelog/v1.md` (or `/changelog/v1` for the HTML
  route), so coding agents and crawlers follow the `/changelog/...` URL rather
  than the internal `/docs/changelog/...` path.

Net effect: one source folder, searchable through the same index as the rest of
the docs, but served and linked under `/changelog/...` everywhere it's
agent-visible.
