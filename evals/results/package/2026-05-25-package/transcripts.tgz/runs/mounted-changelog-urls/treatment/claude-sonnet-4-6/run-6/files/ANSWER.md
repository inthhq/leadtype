# Serving `changelog/` Under `/changelog/` with `leadtype generate`

## 1. The single `leadtype generate` invocation

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

### How each flag contributes

| Flag | Purpose |
|---|---|
| `--src .` | Project root; leadtype looks for `docs.config.ts` here. |
| `--docs-dir docs` | Primary docs source, mounted at the generated docs root (`/docs`). |
| `--docs-dir changelog=/changelog` | The `<dir>=<url-prefix>` form mounts the sibling `changelog/` folder at the public URL prefix `/changelog` instead of the default `/docs/changelog`. |
| `--out public` | Everything is written under `public/`. |
| `--base-url https://example.com` | Absolute base used for canonical URLs in `llms.txt`, search metadata, sitemap, and `agent-readability.json`. |

The `--docs-dir changelog=/changelog` argument is the key: the `=` separator tells leadtype to use `/changelog` as the public URL prefix for that source while keeping the internal generated copy inside `public/docs/` where the pipeline's search and agent helpers expect it.

---

## 2. What leadtype emits for `changelog/v1.mdx`

### Internal generated copy

```
public/docs/changelog/v1.md
```

This is the MDX-to-markdown conversion that the search pipeline, `llms-full.txt` aggregation, and runtime helpers read. It lives under `public/docs/` regardless of the public URL prefix, so it is picked up by `search-index.json`, `search-content.json`, and other docs-scoped artifacts automatically — this is what keeps it **searchable**.

### Public (mirror) copy

```
public/changelog/v1.md
```

Because the `=/changelog` prefix was declared, leadtype also writes a static markdown mirror at the public path. HTTP agents, CDN routes, and markdown-negotiating servers serve this file directly when a client requests `/changelog/v1.md` or sends `Accept: text/markdown` to `/changelog/v1`.

### Canonical URL that agents see

```
https://example.com/changelog/v1
```

This `/changelog/v1` path (not `/docs/changelog/v1`) is what leadtype writes into every agent-facing artifact:

- **`public/llms.txt`** — the routing index that coding agents and HTTP tools read first; the entry for this page links to `https://example.com/changelog/v1.md`.
- **`public/llms-full.txt`** — the full-context fallback; the page's section header uses the `/changelog/v1` canonical path.
- **`public/docs/search-index.json` / `search-content.json`** — result entries carry `url: "/changelog/v1"` so search results resolve to the correct public route.
- **`public/docs/sitemap.xml` / `sitemap.md`** — the sitemap entry for this page uses `https://example.com/changelog/v1`.
- **`public/docs/agent-readability.json`** — the manifest entry for markdown-response middleware points to `/changelog/v1`.

### Summary diagram

```
changelog/v1.mdx  (source)
      │
      ├─► public/docs/changelog/v1.md   ← internal copy (search index, llms-full.txt, agent helpers)
      │
      ├─► public/changelog/v1.md        ← public mirror (served at /changelog/v1.md)
      │
      └─► canonical URL: https://example.com/changelog/v1
          (in llms.txt · search metadata · sitemap · agent-readability.json)
```

The page is therefore served at `/changelog/v1` on the generated site, never at `/docs/changelog/v1`, while remaining fully indexed by the search pipeline.
