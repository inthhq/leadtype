# Serving `changelog/` under `/changelog/...`

## 1. The command

Use the `<dir>=<url-prefix>` form of `--docs-dir` so the second source folder gets its own public URL prefix instead of being nested under `/docs/`:

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public
```

- `--docs-dir docs` mounts the main docs folder at the generated docs root (`/docs/...`).
- `--docs-dir changelog=/changelog` mounts the sibling `changelog/` folder at the public URL prefix `/changelog`, while still keeping it in the unified docs tree for search.

(If the repo uses a `leadtype.config.{ts,js,mjs,cjs}` with `collections`, the equivalent is a second `defineCollection({ dir: "changelog", prefix: "/changelog" })` — `--docs-dir` is rejected when collections are configured.)

## 2. What gets emitted for `changelog/v1.mdx`

For that one source file, `leadtype generate` produces three distinct things:

| Role | Path / value |
|---|---|
| Internal generated copy (powers search index, runtime helpers, `createDocsSource`) | `public/docs/changelog/v1.md` |
| Public static markdown mirror (what agents actually fetch) | `public/changelog/v1.md` |
| Canonical URL written into `llms.txt`, `search-index.json` / `search-content.json` metadata, `sitemap.xml`, and `agent-readability.json` | `/changelog/v1.md` |

So the page stays fully searchable — it lives inside the merged docs tree at `public/docs/changelog/v1.md` for the search index and source primitive — but every agent-facing artifact advertises it under the clean `/changelog/...` prefix, and a real file is written at `public/changelog/v1.md` so that canonical URL resolves when served as static assets.
