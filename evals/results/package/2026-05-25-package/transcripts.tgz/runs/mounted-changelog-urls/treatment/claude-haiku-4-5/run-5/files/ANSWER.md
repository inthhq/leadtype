# Changelog URL Prefix Configuration

## The Single `leadtype generate` Invocation

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

This command:
- Reads `docs/` as the primary docs folder
- Reads `changelog/` as a secondary source folder mounted at the `/changelog` URL prefix (not under `/docs`)
- Writes all generated artifacts (including search) to `public/`
- Uses `https://example.com` as the base for canonical links in metadata, sitemap, robots, and agent manifests

## Output Artifacts for `changelog/v1.mdx`

When you run the command above on a file like `changelog/v1.mdx`, leadtype emits:

### 1. **Internal Generated Copy** (for search and runtime helpers)
```
public/docs/changelog/v1.md
```
- Flattened markdown version of the MDX
- Used internally by the search index and agent runtime helpers
- Not directly exposed; it's in the generated docs tree for tooling access

### 2. **Public Mirror** (the canonical web-facing copy)
```
public/changelog/v1.md
```
- Static markdown mirror served from the site root
- This is what HTTP clients and agents actually fetch
- Markdown content negotiation (`Accept: text/markdown`) serves this file
- URL-based artifact searches fetch from here

### 3. **Canonical URL in Agent Metadata**
```
/changelog/v1.md
```
- This is what appears in:
  - `llms.txt` and `llms-full.txt` (discovery and fallback files)
  - Search index metadata (`search-index.json`)
  - `sitemap.xml` and `sitemap.md`
  - `robots.txt` entries
  - `agent-readability.json` (agent request manifests)
- When agents read search results or navigate from `llms.txt`, they fetch from `/changelog/v1.md`
- The full canonical URL is `https://example.com/changelog/v1.md`

## How This Works

The `--docs-dir changelog=/changelog` flag does two things:

1. **Merge** the changelog folder into the generated docs tree (so search sees all content)
2. **Remount** it at a different public URL prefix (`/changelog` instead of `/docs/changelog`)

The leading internal copy (`public/docs/changelog/v1.md`) ensures search indexing and runtime link resolution work correctly. The public mirror (`public/changelog/v1.md`) is what gets served to users and agents. Agents read the canonical URL from metadata files and request the content from there, making the setup fully agent-discoverable and searchable.
