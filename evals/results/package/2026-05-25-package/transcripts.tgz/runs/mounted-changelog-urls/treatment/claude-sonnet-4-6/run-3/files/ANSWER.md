# Serving `changelog/` Under `/changelog/` with `leadtype generate`

## 1. The invocation

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://your-site.com
```

The key is the `<dir>=<url-prefix>` syntax on the second `--docs-dir` flag:
`changelog=/changelog` tells leadtype to read source files from the repo's
`changelog/` folder and assign them the public URL prefix `/changelog` instead
of the default `/docs/changelog`.

---

## 2. What leadtype emits for `changelog/v1.mdx`

### Internal generated copy (for search & runtime helpers)
```
public/docs/changelog/v1.md
```
This copy always lands under the `public/docs/` tree regardless of the public
URL prefix. The search index (`public/docs/search-index.json` /
`search-content.json`) and the agent-readability manifest
(`public/docs/agent-readability.json`) both index this file, so the page is
**fully searchable**.

### Public (mirror) copy
```
public/changelog/v1.md
```
Because the `=/changelog` URL prefix was declared, leadtype also writes a
static markdown mirror directly at `public/changelog/v1.md`. This is the file
that a CDN or static server exposes to browsers and HTTP clients at the public
path.

### Canonical URL seen by agents
```
/changelog/v1
/changelog/v1.md   ← direct markdown mirror link
```
Every URL-bearing artifact uses the `/changelog` prefix:

| Artifact | Entry emitted |
|---|---|
| `public/llms.txt` | `- [v1](/changelog/v1.md)` |
| `public/docs/sitemap.xml` | `<loc>https://your-site.com/changelog/v1</loc>` |
| `public/docs/agent-readability.json` | canonical URL → `/changelog/v1` |
| Search metadata | canonical URL → `/changelog/v1` |

Agents that discover the site via `llms.txt` or the sitemap therefore follow
`/changelog/v1` — never `/docs/changelog/v1` — while the internal copy at
`public/docs/changelog/v1.md` keeps the page participating in full-text search
and all runtime helper APIs.
