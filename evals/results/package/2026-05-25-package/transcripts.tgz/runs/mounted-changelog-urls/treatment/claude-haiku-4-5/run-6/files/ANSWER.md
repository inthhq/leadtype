# Mounting Changelog at `/changelog/...` Instead of `/docs/changelog/...`

## The Command

Use the `--docs-dir` flag with a URL prefix override:

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

## What It Emits for `changelog/v1.mdx`

For a file at `changelog/v1.mdx`, this invocation produces three artifacts:

| Artifact | Path | Purpose |
|----------|------|---------|
| **Internal generated copy** | `public/docs/changelog/v1.md` | Searchable content, used by the search index and runtime helpers like `createDocsSource()`. Agents searching the static index will find results pointing here. |
| **Public mirror** | `public/changelog/v1.md` | Static markdown file served at the public URL prefix. This is what humans and agents fetch when accessing the changelog directly. |
| **Canonical URL** | `/changelog/v1` | The URL agents see in `llms.txt`, `agent-readability.json`, search metadata, sitemap entries, and other agent-discoverable artifacts. Agents prioritize this URL when pointing at content. |

## How It Works

- The first `--docs-dir docs` mounts at the generated docs root (`/docs`).
- The `--docs-dir changelog=/changelog` syntax mounts the second source at a **custom URL prefix** (`/changelog`) instead of the default nested path (`/docs/changelog`).
- Leadtype keeps an internal merged copy at `public/docs/changelog/v1.md` for search indexing and unified content operations.
- Simultaneously, it writes a public mirror at `public/changelog/v1.md` where agents and humans expect it.
- All canonical links point to `/changelog/v1`, not `/docs/changelog/v1`.

This ensures changelog pages are searchable (by indexing the internal copy) while remaining accessible at their own public URL root.
