# Serving the sibling `changelog/` folder at `/changelog/...`

## 1. The single command

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public
```

The key piece is the `<dir>=<url-prefix>` form on the second `--docs-dir`. It
mounts the sibling `changelog/` folder as an additional source, but tells the
pipeline that its public canonical URLs live under `/changelog`, not under
`/docs/changelog`. The `docs/` folder is still the first source, so it remains
mounted at the generated docs root (`/docs`).

## 2. What gets emitted for `changelog/v1.mdx`

Per the [CLI reference](node_modules/leadtype/docs/reference/cli.md) ("Multiple
source folders"), giving a docs-dir an explicit URL prefix produces three
distinct things:

- **Internal generated copy** — `public/docs/changelog/v1.md`
  This is what the in-app docs source primitive, the search index, and runtime
  helpers read from. Keeping it inside `public/docs/...` is what makes the
  changelog page searchable alongside the rest of the docs (it sits in the same
  generated docs tree that `search-index.json` / `search-content.json` and the
  agent-readability manifest are built from).

- **Public mirror (static markdown)** — `public/changelog/v1.md`
  A second copy is written at the URL-prefix location so the file is reachable
  at the public path you actually want to expose. This is the file your web
  server hands out when an agent (or `curl`) requests `/changelog/v1.md`.

- **Canonical URL agents see** — `/changelog/v1.md`
  The canonical link that shows up in `llms.txt`, `llms-full.txt`, search
  metadata, the docs sitemap, and `agent-readability.json` is the
  url-prefixed one (`/changelog/v1.md`), **not** `/docs/changelog/v1.md`. So
  every agent-facing artifact advertises the changelog under `/changelog/...`
  exactly as required, while the internal generated tree under
  `public/docs/...` continues to back search.
