# Serving Changelog at `/changelog/...` with Full Searchability

## The Command

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

## What Gets Emitted

For a file like `changelog/v1.mdx`:

| Artifact | Location | Purpose |
|----------|----------|---------|
| **Internal generated copy** | `public/docs/changelog/v1.md` | Used by the search index and runtime agents reading from disk |
| **Public markdown mirror** | `public/changelog/v1.md` | Static markdown served directly at `/changelog/v1.md` when requested with `Accept: text/markdown` |
| **Canonical URL in metadata** | `/changelog/v1` | Appears in `llms.txt`, search metadata, sitemap entries, agent-readability.json, and other metadata — agents and humans see this as the canonical location |

## How It Works

The `<dir>=<url-prefix>` syntax on `--docs-dir changelog=/changelog`:

1. **Keeps internal search copy under `/docs`** — `public/docs/changelog/v1.md` ensures the search index finds and indexes the content with all other docs.

2. **Publishes the markdown mirror at the custom prefix** — `public/changelog/v1.md` is written as a static file at the public URL prefix you specified.

3. **Emits canonical metadata with the public prefix** — When agents and tools read `llms.txt`, `search-index.json`, `agent-readability.json`, or sitemap entries, they see `/changelog/v1` as the canonical URL, not `/docs/changelog/v1`.

The key insight: the content is **unified** in the search index (so "Find all docs about breaking changes" works across both docs and changelog), but **routed differently** in public URLs so users and agents see changelog at `/changelog/...` instead of `/docs/changelog/...`.
