# Serving `changelog/` under `/changelog/...`

## 1. The command

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

The key piece is the `<dir>=<url-prefix>` form on the second `--docs-dir`. It
mounts the sibling `changelog/` folder at its own public URL prefix instead of
nesting it under the main docs root.

(Replace `--base-url` with whatever your site uses. You can swap in collections
via `leadtype.config.ts` later if changelog needs its own filters, schema, or
nav — but for "just put it at `/changelog`", the repeated `--docs-dir` flag is
the documented happy path.)

## 2. What gets emitted for `changelog/v1.mdx`

Three things land on disk / in metadata for that one source file:

| Artifact | Path | Purpose |
| --- | --- | --- |
| Internal generated copy | `public/docs/changelog/v1.md` | Kept under the docs tree so the static **search index**, runtime search helpers, and other docs-scoped tooling still see it. |
| Public markdown mirror | `public/changelog/v1.md` | Static markdown served at the canonical URL — what `Accept: text/markdown` requests and agents hitting `/changelog/v1.md` actually fetch. |
| Canonical URL | `/changelog/v1` (markdown form `/changelog/v1.md`) | What gets written into `llms.txt`, `sitemap.xml`, `search-content.json`'s page metadata, and `agent-readability.json`. |

So agents and crawlers only ever see `/changelog/...` URLs, but the page is
still indexed by the same search pipeline that covers `/docs/...`. Nothing
appears under `/docs/changelog/...` in any public artifact — that path is just
an internal staging location for the search index.
