# Mounting Changelog at `/changelog` with Searchability

## 1. Single `leadtype generate` invocation

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

The `changelog=/changelog` syntax tells leadtype to:
- Read the `changelog/` folder as a docs source
- Mount it at the public URL prefix `/changelog` (not under `/docs/changelog`)
- Keep it searchable via the same search index
- Include it in sitemap, robots, and all agent-readability artifacts

## 2. What gets emitted for `changelog/v1.mdx`

### Internal generated copy (for search & runtime):
```
public/docs/changelog/v1.md
```
This file is preserved for search indexing and agent helpers. It's not served directly to users.

### Public mirror (served to humans):
```
public/changelog/v1.md
```
This is the human-facing static markdown mirror at the canonical URL path.

### Canonical URL agents see:
```
/changelog/v1.md
```
Leadtype emits this URL in:
- `llms.txt` (product index)
- Search metadata (`search-index.json`, `search-content.json`)
- `sitemap.xml` entries
- `agent-readability.json` manifest
- Best starting points and JSON-LD links

**Result:** The changelog is fully searchable and discoverable by agents, but the public site serves `/changelog/v1.md` instead of `/docs/changelog/v1.md`.
