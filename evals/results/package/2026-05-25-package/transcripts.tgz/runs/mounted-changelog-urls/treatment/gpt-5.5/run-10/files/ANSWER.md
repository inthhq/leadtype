# Answer

```bash
leadtype generate --src . --docs-dir docs --docs-dir changelog=/changelog --out public
```

The important part is the mounted docs dir form `changelog=/changelog`: it merges the sibling `changelog/` folder into the generated docs tree, but gives it its own public URL prefix.

For a source file such as:

```text
changelog/v1.mdx
```

Leadtype emits:

- **Internal generated copy:** `public/docs/changelog/v1.md`
  - This stays inside the generated docs tree so Leadtype's search/runtime artifacts can index it.
- **Public mirror:** `public/changelog/v1.md`
  - This is the static file your site can serve at the changelog URL prefix.
- **Canonical agent-facing URL:** `/changelog/v1.md`
  - This is what appears in agent-facing artifacts such as `llms.txt`, search metadata, sitemap entries, and `agent-readability.json` — not `/docs/changelog/v1.md`.
