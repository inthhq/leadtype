# Serving `changelog/` at `/changelog/...`

The `leadtype generate` CLI supports per-source URL prefixes via the `<dir>=<url-prefix>` form on `--docs-dir`. That lets `changelog/` keep its own public path while remaining part of the same generated docs tree (so it stays searchable).

## 1. The command

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public
```

- `--docs-dir docs` mounts the main docs folder at the generated docs root (default URL prefix `/docs`).
- `--docs-dir changelog=/changelog` mounts the sibling `changelog/` folder but reassigns its **public** URL prefix to `/changelog` instead of `/docs/changelog`.
- `--out public` is the on-disk output root.

## 2. What it emits for `changelog/v1.mdx`

For an input file `changelog/v1.mdx`, the pipeline produces three distinct things:

| Role | Path / URL | Purpose |
|---|---|---|
| Internal generated copy | `public/docs/changelog/v1.md` | Lives under the unified docs tree so the search index, `createDocsSource` runtime helpers, and includes keep working. |
| Public markdown mirror | `public/changelog/v1.md` | Static mirror written at the requested prefix so the file is fetchable directly under `/changelog/...`. |
| Canonical URL | `/changelog/v1.md` | What agents see — emitted in `llms.txt`, search metadata, `sitemap.xml`, and `agent-readability.json`. |

So the changelog page is **searchable** (it's in the same generated docs tree and search index as the rest of the docs) but **addressed** at `/changelog/v1.md` rather than `/docs/changelog/v1.md` — exactly what the requirement asked for.
