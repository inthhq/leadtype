# Mounted changelog URLs

Use an explicit URL mount for the sibling `changelog/` source:

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://your-site.example
```

Replace `https://your-site.example` with the site origin you want in absolute artifacts. The key part is `--docs-dir changelog=/changelog`: `docs` stays the primary docs source, while `changelog` is included in the same generated corpus but mounted at `/changelog` instead of `/docs/changelog`.

For `changelog/v1.mdx`, site mode emits:

- Internal generated copy for the docs corpus/search/runtime helpers: `public/docs/changelog/v1.md`.
- Public static markdown mirror for the mounted URL: `public/changelog/v1.md`, served as `/changelog/v1.md`.
- Canonical mounted URLs in agent-facing metadata: the page URL is `/changelog/v1`, and the markdown URL agents are linked to is `/changelog/v1.md` (or `https://your-site.example/changelog/v1` / `https://your-site.example/changelog/v1.md` where absolute URLs are emitted).

Because the internal copy remains under `public/docs/changelog/v1.md`, it is still read by the generated search index; because the mount is `/changelog`, generated links and metadata do not point agents at `/docs/changelog/v1.md`.
