# Serving Changelog Under `/changelog/` with leadtype

## 1. Single `leadtype generate` Invocation

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://your-domain.com
```

This configuration:
- Merges the primary `docs/` folder at the root of the generated docs tree
- Mounts `changelog/` with a custom URL prefix (`/changelog`)
- Outputs artifacts to `public/`
- Sets the base URL for canonical links (required for sitemap, robots, and search metadata)

## 2. What Gets Emitted for `changelog/v1.mdx`

For a file `changelog/v1.mdx`, the pipeline produces:

| Artifact | Path | Visibility | Purpose |
|----------|------|------------|---------|
| **Internal generated copy** | `public/docs/changelog/v1.md` | Internal | Used by search indexing, search-index.json content, and runtime helpers. Kept alongside other docs for unified search infrastructure. |
| **Public mirror** | `public/changelog/v1.md` | Public website | Static markdown file served directly to browsers at `https://your-domain.com/changelog/v1.md` or as a content source for your docs site router. |
| **Canonical URL in agents** | `/changelog/v1.md` | Agent-visible | Agents see this URL in `llms.txt`, `search-index.json` metadata, `sitemap.xml`, and `agent-readability.json`. The canonical URL prefix is `/changelog`, not `/docs/changelog`. |

### Summary

- **Search remains unified**: The internal copy at `public/docs/changelog/v1.md` is indexed and appears in search results with the canonical URL `/changelog/v1.md`.
- **URL prefix decoupling**: The internal path (`docs/changelog/`) and the public canonical URL (`/changelog`) are independent. Agents and external references use only the canonical URL.
- **Static mirrors**: Both `public/docs/changelog/v1.md` and `public/changelog/v1.md` exist on disk, allowing flexible serving strategies (e.g., proxy rewrites, static routing, or direct file serving).
