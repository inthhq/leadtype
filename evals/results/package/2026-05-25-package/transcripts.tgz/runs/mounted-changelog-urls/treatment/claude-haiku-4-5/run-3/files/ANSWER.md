# Serving Changelog Under `/changelog/...` with Searchability

## The Single `leadtype generate` Invocation

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://your-domain.com
```

### Explanation

- `--docs-dir docs` — mounts the main docs folder at the generated docs root
- `--docs-dir changelog=/changelog` — mounts the `changelog/` folder with a custom URL prefix of `/changelog`
  - The `=<url-prefix>` syntax tells leadtype to serve this source under a different public URL path
  - Without the URL prefix, it would default to `/docs/changelog/...`

---

## Output Emission Details

For a file like `changelog/v1.mdx`:

### Internal Generated Copy
**Path:** `public/docs/changelog/v1.md`
- This is the master copy used internally for search indexing and runtime helpers
- Always lives under `/docs/` regardless of the public URL prefix
- Enables the search index to find the content

### Public Mirror / Static Route
**Path:** `public/changelog/v1.md`
- The static markdown mirror served directly at the canonical URL
- Accessible via `GET /changelog/v1.md` with `Accept: text/markdown` negotiation
- This is what browsers and agents fetch when requesting markdown

### Canonical URL Agents See
**URL:** `/changelog/v1.md`
- Emitted in `llms.txt`, search metadata, `search-index.json`, `sitemap.xml`, `agent-readability.json`
- This is the URL agents use in source citations and references
- Agents read the canonical URL and fetch from `public/changelog/v1.md`

---

## How It Works

1. **Mounting:** The `changelog=/changelog` syntax tells leadtype to merge `changelog/` into the generated docs tree **internally** (at `docs/changelog/...` for search), but emit **public URLs** as `/changelog/...`.

2. **Search:** The content is indexed at the internal path but searchable; search metadata points to the canonical public URL `/changelog/v1.md`.

3. **Agents:** When reading `llms.txt` or `search-index.json`, agents see `/changelog/v1.md` as the canonical URL, not `/docs/changelog/v1.md`.

4. **Static Delivery:** The mirror at `public/changelog/v1.md` is a pure static file that HTTP agents and humans fetch directly — no routing required.

This design separates the **internal structure** (for indexing and runtime) from the **public URLs** (what agents cite), keeping everything searchable while serving changelog under its own path.
