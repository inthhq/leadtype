# Answer

```bash
leadtype generate --src . --docs-dir docs --docs-dir changelog=/changelog --out public
```

For `changelog/v1.mdx`, that invocation treats `docs/` as the normal docs root and mounts the sibling `changelog/` source with its own public URL prefix:

- **Internal generated copy:** `public/docs/changelog/v1.md`
  - This stays in the generated docs tree so leadtype's runtime helpers and search generation can include it.
- **Public markdown mirror:** `public/changelog/v1.md`
  - This is the file your site can serve at `/changelog/v1.md`, instead of under `/docs/changelog/v1.md`.
- **Canonical URL agents see:** `/changelog/v1.md`
  - That URL is what leadtype writes into agent-facing artifacts such as `llms.txt`, search metadata, sitemap entries, and `agent-readability.json`.

If you also pass `--base-url https://example.com`, the same canonical path is emitted as an absolute URL, e.g. `https://example.com/changelog/v1.md`.
