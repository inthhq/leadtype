# Serving `changelog/` under `/changelog/...`

## 1. The command

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public
```

The key piece is the `<dir>=<url-prefix>` form on the second `--docs-dir`. It
mounts the sibling `changelog/` folder as an extra docs source but pins its
public URL prefix to `/changelog` instead of the default `/docs/changelog`.

## 2. What gets emitted for `changelog/v1.mdx`

leadtype writes the file in two places and advertises one canonical URL:

- **Internal generated copy:** `public/docs/changelog/v1.md`
  This stays inside the unified `/docs` tree so the runtime helpers — the
  search index (`public/docs/search-index.json` /
  `search-content.json`), `createDocsSource()`, includes, link
  resolution — keep seeing every page under one root. That's why the page
  remains searchable.
- **Public mirror (static):** `public/changelog/v1.md`
  A second markdown file is written directly under `public/changelog/` so
  HTTP agents requesting `/changelog/v1.md` (or hitting the page with
  `Accept: text/markdown`) get a 1:1 mirror without having to know about
  the internal `/docs` mount.
- **Canonical URL agents see:** `/changelog/v1` (markdown form
  `/changelog/v1.md`)
  That's the URL written into `llms.txt`, the search metadata,
  `sitemap.xml`, and `agent-readability.json`. Nothing leaks the
  `/docs/changelog/...` path to consumers.

So humans and agents see `/changelog/v1`, the static mirror lives at
`public/changelog/v1.md`, and search/runtime tooling still reads from the
unified `public/docs/changelog/v1.md` copy.
