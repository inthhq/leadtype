# Serving Changelog Under `/changelog/...`

## The invocation

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public
```

## What it emits for `changelog/v1.mdx`

For a file like `changelog/v1.mdx`, the generate command produces:

### Internal generated copy
- **Location**: `public/docs/changelog/v1.md`
- **Purpose**: Used for search indexing and runtime helpers; stays in the docs tree for consistent internal structure.

### Public mirror
- **Location**: `public/changelog/v1.md`
- **Purpose**: The static markdown file served directly at the public URL.

### Canonical URL (in agents.txt, search metadata, sitemap, and agent-readability.json)
- **URL**: `/changelog/v1.md`
- **Seen by**: LLMs reading `llms.txt`, search index entries, sitemap entries, and `agent-readability.json` manifest.

This approach achieves both goals:
1. **Correct URL path** — agents see `/changelog/v1.md`, not `/docs/changelog/v1.md`
2. **Searchability** — the page is indexed via the internal copy at `public/docs/changelog/v1.md` and fully included in search results with the correct canonical URL
