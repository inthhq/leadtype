# Serving `changelog/` at `/changelog/...`

## 1. The `leadtype generate` invocation

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

The key piece is `changelog=/changelog` — the `<dir>=<url-prefix>` syntax. This tells leadtype to read the local `changelog/` folder as a second source and assign it the public URL prefix `/changelog` instead of the default `/docs/changelog`.

The `docs` entry (the first `--docs-dir`) is mounted at the generated docs root as usual. The `changelog=/changelog` entry is mounted at its own independent public prefix, keeping the two trees entirely separate on the public URL surface. Search is built from both trees together, so changelog pages are fully searchable alongside the main docs.

---

## 2. What leadtype emits for `changelog/v1.mdx`

### Internal generated copy
```
public/docs/changelog/v1.md
```
Leadtype always writes the converted markdown under `public/docs/` regardless of the public URL prefix. This copy is consumed internally by the search pipeline (`public/docs/search-index.json`, `public/docs/search-content.json`) and by runtime helpers that read the `public/docs/` tree.

### Public mirror
```
public/changelog/v1.md
```
Because the mount was declared with `=/changelog`, leadtype also writes a static markdown mirror at the path that matches the public URL prefix. This is the file a CDN, static host, or `Accept: text/markdown` content-negotiation handler serves directly to HTTP agents requesting the changelog page.

### Canonical URL (what agents see)
```
/changelog/v1
```
All canonical references — `llms.txt` links, sitemap entries, `agent-readability.json` metadata, and search-result `url` fields — point to `/changelog/v1` (and `/changelog/v1.md` for the markdown form). Agents discovering the site through `llms.txt` or the sitemap therefore land at `/changelog/...` URLs, never at `/docs/changelog/...`.
