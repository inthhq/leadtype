# Serving `changelog/` Under `/changelog/...`

## 1. The `leadtype generate` Invocation

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

### Why each flag matters

| Flag | Purpose |
|---|---|
| `--src .` | Project root (where `docs/` and `changelog/` both live). |
| `--docs-dir docs` | Primary source folder; its pages are mounted at the generated docs root (`/docs/…`). |
| `--docs-dir changelog=/changelog` | The `<dir>=<url-prefix>` syntax mounts the sibling `changelog/` folder at the **public URL prefix** `/changelog` instead of the default `/docs/changelog`. |
| `--out public` | Output root for all generated artifacts. |
| `--base-url https://example.com` | Required for canonical URLs, `llms.txt` links, sitemap entries, and search metadata to resolve correctly. |

> **Key point:** the `<dir>=<url-prefix>` form (here `changelog=/changelog`) is the single switch that separates the public URL prefix (`/changelog/…`) from the default nesting that would otherwise place the pages under `/docs/changelog/…`.

---

## 2. What Leadtype Emits for `changelog/v1.mdx`

### Internal generated copy

```
public/docs/changelog/v1.md
```

This copy is created regardless of the custom URL prefix. It lives under the shared `public/docs/` tree so the **search pipeline** (`search-index.json`, `search-content.json`) and **runtime agent helpers** (`agent-readability.json`) can reach it through a single consistent directory scan. The file is fully converted MDX → Markdown, with `canonical_url` and `last_updated` frontmatter injected.

### Public markdown mirror

```
public/changelog/v1.md
```

Because the `=/changelog` prefix was supplied, Leadtype also writes a **static markdown mirror** at the public path. This is the file actually served to browsers and HTTP agents at `/changelog/v1.md` (or via `Accept: text/markdown` negotiation on `/changelog/v1`).

### Canonical URL agents see

```
https://example.com/changelog/v1
```

Every place Leadtype records the authoritative location of this page uses the custom prefix:

- **`llms.txt`** — lists the page as `https://example.com/changelog/v1.md`
- **`sitemap.xml` / `sitemap.md`** — entry resolves to `https://example.com/changelog/v1`
- **`agent-readability.json`** — `url` field is `/changelog/v1`
- **Markdown frontmatter** (`canonical_url`) inside both copies — `https://example.com/changelog/v1`
- **Search metadata** (`search-index.json` / `search-content.json`) — URL recorded as `/changelog/v1`

So agents discovering the site via `llms.txt` or the sitemap are directed straight to `/changelog/v1`, never to `/docs/changelog/v1`, while the internal copy at `public/docs/changelog/v1.md` ensures the file is indexed and searchable alongside every other docs page.

---

### Summary diagram

```
changelog/v1.mdx  (source)
       │
       ├─► public/docs/changelog/v1.md   ← internal copy (search + agent helpers)
       │
       └─► public/changelog/v1.md        ← public mirror served at /changelog/v1
                                            canonical URL: https://example.com/changelog/v1
```
