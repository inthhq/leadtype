# Answer

Use a mounted `--docs-dir` for the changelog folder:

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

Replace `https://example.com` with the site origin you deploy from.

For a source file such as `changelog/v1.mdx`, this emits:

- Internal generated copy for Leadtype helpers/search: `public/docs/changelog/v1.md`
- Public markdown mirror served at the mounted route: `public/changelog/v1.md` (`/changelog/v1.md`)
- Canonical page URL exposed to agents/metadata: `https://example.com/changelog/v1`, not `https://example.com/docs/changelog/v1`

The page remains searchable because Leadtype still includes the internal `public/docs/changelog/v1.md` copy in the generated search artifacts under `public/docs/search-index.json` and `public/docs/search-content.json`, while search metadata, `llms.txt`, sitemap entries, and `agent-readability.json` point at the mounted `/changelog/...` URLs.
