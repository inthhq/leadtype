# Serving `changelog/` under `/changelog/...`

## 1. The command

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public
```

The `<dir>=<url-prefix>` form on the second `--docs-dir` re-mounts the sibling
`changelog/` folder at the public URL prefix `/changelog` instead of the default
`/docs/changelog`. The main `docs/` folder stays mounted at the docs root.

## 2. What gets emitted for `changelog/v1.mdx`

For that single source file, leadtype produces three things:

| Role | Path / URL | Purpose |
|---|---|---|
| **Internal generated copy** | `public/docs/changelog/v1.md` | Lives under the docs tree so it's picked up by the search index (`public/docs/search-index.json` / `search-content.json`), the docs sitemap, and runtime helpers — i.e. it stays searchable. |
| **Public static mirror** | `public/changelog/v1.md` | A markdown mirror written at the requested URL prefix so the site can serve it directly at `/changelog/v1.md` without going through `/docs/...`. |
| **Canonical URL agents see** | `/changelog/v1.md` | Used everywhere a canonical link is emitted: `llms.txt`, search metadata, sitemap entries, and `agent-readability.json`. Agents and crawlers never see the `/docs/changelog/...` path. |

Net effect: the page is reachable (and canonicalized) at `/changelog/v1.md`,
while still participating in the docs search index because its internal copy
lives at `public/docs/changelog/v1.md`.
