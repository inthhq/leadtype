# Serving changelog pages under `/changelog/…`

## 1. The single `leadtype generate` invocation

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

The key is the `<dir>=<url-prefix>` syntax on the second `--docs-dir` flag:
`changelog=/changelog` tells leadtype to read source files from `./changelog/`,
mount them with the public URL prefix `/changelog`, and still keep an internal
generated copy under `public/docs/changelog/` so the search index and runtime
helpers can reach them.

---

## 2. What leadtype emits for `changelog/v1.mdx`

### Internal generated copy

```
public/docs/changelog/v1.md
```

This is the MDX-converted markdown file that the search pipeline
(`search-index.json`, `search-content.json`) and runtime helper APIs read.
It is produced regardless of the public URL prefix and is what makes the page
**searchable**.

### Public markdown mirror

```
public/changelog/v1.md
```

Because the `=/changelog` URL prefix was declared, leadtype also writes a
static markdown mirror at the public path. This is the file a CDN or static
host serves when an HTTP client (browser or agent) requests
`https://example.com/changelog/v1.md` (or sends `Accept: text/markdown`).

### Canonical URL seen by agents

```
/changelog/v1
```

All URL-bearing artifacts — `llms.txt`, `llms-full.txt`, `sitemap.xml`,
`sitemap.md`, `agent-readability.json`, and search result metadata — use the
URL prefix supplied after `=`. So agents reading `llms.txt` or the sitemap, and
any tool querying the search index, will see the page linked and attributed as:

```
https://example.com/changelog/v1
```

not as `/docs/changelog/v1`.

---

### Summary of the three outputs at a glance

| Artifact | Path on disk | Public URL |
|---|---|---|
| Internal generated copy (search / runtime) | `public/docs/changelog/v1.md` | *(internal only)* |
| Static markdown mirror (agent / CDN) | `public/changelog/v1.md` | `https://example.com/changelog/v1.md` |
| Canonical URL in `llms.txt`, sitemap, search metadata | — | `https://example.com/changelog/v1` |
