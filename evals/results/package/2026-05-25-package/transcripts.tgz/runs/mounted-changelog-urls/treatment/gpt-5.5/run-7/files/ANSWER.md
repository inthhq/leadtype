# Changelog mount for leadtype

Use a mounted second docs directory:

```bash
npx leadtype generate --src . --docs-dir docs --docs-dir changelog=/changelog --out public --base-url https://example.com
```

Replace `https://example.com` with the site's real production origin.

For `changelog/v1.mdx`, leadtype treats `changelog` as an additional source folder mounted at `/changelog`:

- **Internal generated copy:** `public/docs/changelog/v1.md`. This stays under the generated docs tree, so the normal site-mode artifacts, including `public/docs/search-index.json` and `public/docs/search-content.json`, can index it.
- **Public markdown mirror:** `public/changelog/v1.md`, served as `/changelog/v1.md` instead of `/docs/changelog/v1.md`.
- **Canonical URLs agents see:** mounted changelog URLs are emitted in the agent-facing artifacts. With the `--base-url` above, the page URL is `https://example.com/changelog/v1`, and the markdown URL linked from `llms.txt` / exposed as the markdown mirror is `https://example.com/changelog/v1.md` — not anything under `/docs/changelog/...`.
