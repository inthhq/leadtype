# Serving `changelog/` at `/changelog/...`

## 1. The `leadtype generate` invocation

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

The key piece is the `<dir>=<url-prefix>` syntax on the second `--docs-dir`:
`changelog=/changelog` tells leadtype to mount the sibling `changelog/` folder
at the public URL prefix `/changelog` instead of the default `/docs/changelog`.

---

## 2. What the pipeline emits for `changelog/v1.mdx`

### Internal generated copy
```
public/docs/changelog/v1.md
```
Leadtype always writes every source file into the docs sub-tree under `public/docs/`
regardless of the public URL prefix. This copy is what the search index
(`public/docs/search-index.json` / `search-content.json`) and runtime helpers
(e.g. `createDocsSource`, `agent-readability.json`) read from.

### Public mirror
```
public/changelog/v1.md
```
Because the mount carries an explicit URL prefix (`/changelog`), leadtype also
writes a static markdown mirror at the matching path under `public/`. This is the
file a CDN, static host, or `Accept: text/markdown` request will serve.

### Canonical URL that agents see
```
/changelog/v1
```
(or `/changelog/v1.md` where a full-path link is needed)

Every URL-anchored artifact — `llms.txt`, `llms-full.txt`, `sitemap.xml`,
`sitemap.md`, `robots.txt`, and `agent-readability.json` — uses `/changelog/v1`
as the canonical path. Agents reading `llms.txt` or the sitemap therefore
discover and link to `/changelog/v1`, not `/docs/changelog/v1`.

---

### Summary of the three outputs at a glance

| Artifact | Path / URL |
|---|---|
| Internal generated copy (search & helpers) | `public/docs/changelog/v1.md` |
| Static public mirror (served to browsers & agents) | `public/changelog/v1.md` |
| Canonical URL in `llms.txt`, sitemap, `agent-readability.json` | `/changelog/v1` |
