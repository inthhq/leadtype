# Serving `changelog/` under `/changelog/` with leadtype

## 1. The `leadtype generate` invocation

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

The key ingredient is the `<dir>=<url-prefix>` syntax on the second `--docs-dir` flag:
`changelog=/changelog`. This tells leadtype to read source files from `./changelog/`, keep
an internal generated copy (for search and runtime helpers) nested under the standard docs
output tree, **and** simultaneously write a public mirror at the top-level `/changelog/…`
URL prefix — not under `/docs/changelog/…`.

## 2. What leadtype emits for `changelog/v1.mdx`

### Internal generated copy
```
public/docs/changelog/v1.md
```
This is the converted markdown file written inside the docs output tree. It is consumed by
the search index builder, `llms-full.txt`, and runtime helpers such as
`agent-readability.json`. It is reachable internally but is **not** the canonical address.

### Public mirror
```
public/changelog/v1.md
```
A static markdown mirror written directly under `public/` at the mounted URL prefix.
This is what a CDN, static host, or `Accept: text/markdown` HTTP client fetches at the
clean public URL.

### Canonical URL that agents see
```
/changelog/v1
```
(or `https://example.com/changelog/v1` when `--base-url` is supplied)

This canonical path is what leadtype writes into every agent-facing artifact:

| Artifact | Entry for `changelog/v1.mdx` |
|---|---|
| `public/llms.txt` | Link pointing to `/changelog/v1.md` |
| `public/llms-full.txt` | Full-context entry under the `/changelog` prefix |
| `public/docs/search-index.json` | Page URL recorded as `/changelog/v1` |
| `public/docs/search-content.json` | Content keyed to `/changelog/v1` |
| `public/docs/sitemap.xml` | `<loc>https://example.com/changelog/v1</loc>` |
| `public/docs/agent-readability.json` | Manifest entry with canonical `/changelog/v1` |

Because the search files are built from the internal copy
(`public/docs/changelog/v1.md`) but reference the canonical `/changelog/v1` URL, the page
is **fully searchable** while still being served at the clean `/changelog/…` route.

### Why not `/docs/changelog/v1`?
Without the `=/changelog` mount annotation, repeating `--docs-dir changelog` alone would
nest the output under the first source's URL tree and produce canonical URLs at
`/docs/changelog/v1`. The `=<url-prefix>` segment overrides that default, giving the
changelog its own first-class URL namespace.
