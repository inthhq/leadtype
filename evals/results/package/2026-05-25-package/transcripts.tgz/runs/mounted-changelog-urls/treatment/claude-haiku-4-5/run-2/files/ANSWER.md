# Changelog URL Mounting in Leadtype

## The Solution: Single `leadtype generate` Invocation

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

Replace `https://example.com` with your actual site base URL.

## What It Emits

For a file like `changelog/v1.mdx`, this configuration produces:

### 1. **Internal Generated Copy** (for search, runtime helpers)
   - Path: `public/docs/changelog/v1.md`
   - Purpose: Used internally by the docs pipeline for search indexing and agent content resolution
   - Searchable: **Yes** — this copy is indexed in `search-index.json`

### 2. **Public Static Mirror** (for direct serving)
   - Path: `public/changelog/v1.md`
   - Purpose: Served directly to browsers and agents at the canonical public URL
   - Searchable: Yes, linked from search results

### 3. **Canonical URL** (what agents and metadata see)
   - URL: `/changelog/v1`
   - Referenced in: `llms.txt`, `search-index.json`, `sitemap.xml`, `agent-readability.json`, and JSON-LD
   - Agent-discoverable: **Yes** — agents see the canonical `/changelog/v1` path

## How the Syntax Works

The `--docs-dir changelog=/changelog` syntax is `<local-folder>=<url-prefix>`:

- `changelog` = the local folder (relative to `--src`)
- `/changelog` = the public URL prefix where it should be mounted (not under `/docs/`)

Without the URL prefix, `changelog/v1.mdx` would be merged under `/docs/changelog/v1`, which is not desired here.

## Summary

- **Config:** Repeat `--docs-dir` with one folder per source, using `folder=urlprefix` syntax to customize the URL mount
- **Search:** Enabled automatically; content is both in the internal copy and discoverable via the search index
- **Agents:** See canonical URLs like `/changelog/v1` in all metadata artifacts and can fetch the corresponding `public/changelog/v1.md` mirror

