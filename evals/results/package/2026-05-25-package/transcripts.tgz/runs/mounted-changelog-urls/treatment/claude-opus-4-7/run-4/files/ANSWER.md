# Serving `changelog/` at `/changelog/...`

## 1. The `leadtype generate` invocation

Use a second `--docs-dir` with the `<dir>=<url-prefix>` form so the changelog source is mounted at its own public URL prefix instead of nesting under `/docs`:

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

- `--docs-dir docs` mounts the primary docs folder at the generated docs root (`/docs`).
- `--docs-dir changelog=/changelog` adds the sibling `changelog/` folder as a second source and overrides its public URL prefix to `/changelog` (rather than the default `/docs/changelog`).
- `--base-url` is what stamps the canonical URLs into `llms.txt`, `sitemap.xml`, `search-content.json`, and `agent-readability.json`.

## 2. What gets emitted for `changelog/v1.mdx`

For that one input file, three distinct things exist after generation:

| Role | Path / URL | Purpose |
|---|---|---|
| **Internal generated copy** | `public/docs/changelog/v1.md` | Kept inside the docs tree so the search index, `llms-full.txt`, and runtime docs helpers can still find and serve the page. This is why the changelog stays searchable. |
| **Public static mirror** | `public/changelog/v1.md` | A static markdown file written at the mount's public prefix, so a request to `/changelog/v1.md` on the deployed site resolves to a real file under `public/`. |
| **Canonical URL agents see** | `/changelog/v1.md` (i.e. `https://example.com/changelog/v1.md` after `--base-url` is applied) | This is the URL written into `llms.txt`, sitemap entries, search metadata, and `agent-readability.json`. Agents and crawlers will never see a `/docs/changelog/...` link for these pages. |

In other words, the page lives in two places on disk on purpose: the `public/docs/changelog/v1.md` copy keeps the changelog part of the searchable docs corpus, while `public/changelog/v1.md` plus the canonical `/changelog/v1.md` URL is what the outside world (browsers, crawlers, LLM agents) is pointed at.
