# Serving `changelog/` under `/changelog/` with `leadtype generate`

## 1. The single `leadtype generate` invocation

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

### What each flag does

| Flag | Purpose |
|---|---|
| `--src .` | Project root (where `docs/` and `changelog/` live side by side). |
| `--docs-dir docs` | Primary docs source. Becomes the generated-docs root (`public/docs/`). |
| `--docs-dir changelog=/changelog` | Secondary source. The `<dir>=<url-prefix>` syntax mounts `changelog/` at the public URL prefix `/changelog` instead of the default `/docs/changelog`. |
| `--out public` | Output root for all generated artifacts. |
| `--base-url https://example.com` | Absolute origin used for canonical URLs in `llms.txt`, sitemap entries, search metadata, and `agent-readability.json`. |

The `<dir>=<url-prefix>` form is the key detail: without `=/changelog`, the second `--docs-dir` would nest everything under `/docs/changelog/…` instead of `/changelog/…`.

---

## 2. What gets emitted for `changelog/v1.mdx`

### a) Internal generated copy (for search and runtime helpers)

```
public/docs/changelog/v1.md
```

Leadtype always writes every source file into the unified `public/docs/` tree first. This copy is what powers the **search index** (`public/docs/search-index.json` and `public/docs/search-content.json`) and what the runtime helpers (`createAgentMarkdownResponse`, `resolveDocsNavigation`, etc.) read from disk. The file is present here regardless of the public URL prefix.

### b) Public markdown mirror (static file served to visitors and agents)

```
public/changelog/v1.md
```

Because the mount was declared with `=/changelog`, leadtype also writes a static mirror at `public/changelog/v1.md`. This file is what gets served when a browser or agent fetches `https://example.com/changelog/v1.md` directly — or when a framework serves the path verbatim from the `public/` directory.

### c) Canonical URL that agents see

```
/changelog/v1
```
or, as a fully-qualified URL:
```
https://example.com/changelog/v1
```

Every agent-facing artifact that references this page uses the `/changelog/…` prefix, **not** `/docs/changelog/…`:

- **`public/llms.txt`** — links to `/changelog/v1.md`.
- **`public/llms-full.txt`** — inline content attributed to `/changelog/v1.md`.
- **`public/docs/search-index.json` / `search-content.json`** — search result URLs resolve to `/changelog/v1`.
- **`public/docs/sitemap.xml` / `sitemap.md`** — `<loc>` and markdown links point to `https://example.com/changelog/v1`.
- **`public/docs/agent-readability.json`** — the manifest entry for this page carries `urlPath: "/changelog/v1"` and `markdownUrl: "/changelog/v1.md"`.
- **`Link: <canonical>` response header** — `createAgentMarkdownResponse` enriches the markdown with `canonical_url: https://example.com/changelog/v1` in the frontmatter and sets the `Link` header to match.

### Summary table

| Artifact | Path / URL |
|---|---|
| Internal generated copy (search + helpers) | `public/docs/changelog/v1.md` |
| Public static mirror | `public/changelog/v1.md` |
| Canonical URL (agents, sitemap, llms.txt) | `https://example.com/changelog/v1` |
| Markdown mirror URL (llms.txt, agent headers) | `https://example.com/changelog/v1.md` |

The internal copy and the public mirror contain identical content; the distinction is purely about where on disk (and therefore under which URL) each file is served. Search remains fully functional because it indexes from the internal `public/docs/` tree, while every canonical reference an agent or crawler follows points to the public `/changelog/…` route.
