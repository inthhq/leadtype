# Answer

```bash
leadtype generate --src . --docs-dir docs --docs-dir changelog=/changelog --out public --base-url https://example.com
```

Replace `https://example.com` with the site's real origin.

For a source file such as `changelog/v1.mdx`, the mounted `--docs-dir changelog=/changelog` entry means:

- Leadtype still creates the internal generated markdown copy under the normal docs artifact tree:
  `public/docs/changelog/v1.md`.
- It also writes the public mounted markdown mirror at:
  `public/changelog/v1.md`.
- Search is still generated from the internal `public/docs/**` tree, so the page remains in `public/docs/search-index.json` / `public/docs/search-content.json`, but its indexed/canonical route is the mounted route, not `/docs/changelog/v1`.
- Agent-facing canonical page metadata uses:
  `https://example.com/changelog/v1` (`urlPath: "/changelog/v1"`).
  The markdown alternate/mirror URL agents can fetch is:
  `https://example.com/changelog/v1.md` (`markdownUrlPath: "/changelog/v1.md"`).
