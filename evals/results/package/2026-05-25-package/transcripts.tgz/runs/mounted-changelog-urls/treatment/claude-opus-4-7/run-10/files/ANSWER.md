# Mounting `changelog/` at `/changelog`

## 1. The command

Mount the changelog folder at its own public URL prefix with `--docs-dir <dir>=<url-prefix>`:

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

The first `--docs-dir` keeps `docs/` as the generated docs root (still served under `/docs`). The second `--docs-dir changelog=/changelog` mounts the sibling `changelog/` folder at the public URL prefix `/changelog`, so its pages are **not** nested under `/docs/changelog/...`.

## 2. What gets emitted for `changelog/v1.mdx`

Per `node_modules/leadtype/docs/reference/llm.md` and `docs/sources/configure-sources.md`, the mounted form creates a leadtype "mount" equivalent to:

```ts
{ pathPrefix: "changelog", urlPrefix: "/changelog" }
```

For `changelog/v1.mdx` you get three things:

| Layer | Path / URL | Purpose |
| --- | --- | --- |
| Internal generated copy | `public/docs/changelog/v1.md` | Stays inside the generated `docs/` tree so search indexing, `llms-full.txt`, and the docs-scoped `agent-readability.json`/sitemap all still find it. This is the file `resolveMarkdownMirrorTarget` and `createAgentMarkdownResponse` resolve against. |
| Public markdown mirror | `public/changelog/v1.md` | Static mirror written at the mounted prefix so requests for `/changelog/v1.md` (and `Accept: text/markdown` requests to `/changelog/v1`) can be served directly from the output root, not from `/docs/...`. |
| Canonical URL agents see | `https://example.com/changelog/v1` | The URL used in `llms.txt`, root `llms-full.txt`, `docs/sitemap.xml`, `docs/sitemap.md`, `docs/agent-readability.json`, navigation entries, JSON-LD `canonical`, and the search index metadata. No `/docs/` segment appears anywhere agents look. |

In short: leadtype keeps one internal copy under `public/docs/changelog/` so the existing search and discovery pipeline keeps working unchanged, and it additionally writes a public mirror under `public/changelog/` and rewrites every agent-facing URL to `/changelog/v1` so the page is canonically served at its own top-level prefix.
