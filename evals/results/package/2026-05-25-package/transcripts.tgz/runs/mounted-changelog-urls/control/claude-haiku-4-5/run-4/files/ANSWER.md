# Serving Changelog at `/changelog/...` with `leadtype generate`

## 1. The Command

To serve changelog pages at `/changelog/...` instead of `/docs/changelog/...` while keeping them searchable, use:

```bash
npx leadtype generate --src . --out public --base-url https://your-domain.com --docs-dir docs --docs-dir changelog=/changelog
```

### Breakdown:
- `--docs-dir docs` — Include the main docs at `/docs/...` (default location)
- `--docs-dir changelog=/changelog` — Mount the `changelog/` folder at `/changelog/...` on the generated site (not under `/docs/`)
- `--base-url https://your-domain.com` — Ensures agent-readable URLs are absolute (optional; omit for relative paths)
- All markdown is made searchable in `search-index.json`

## 2. What Gets Emitted for `changelog/v1.mdx`

### Internal Generated Copy (staging)
```
public/docs/changelog/v1.md
```
This is where `leadtype` initially converts and processes the MDX file. It's used for:
- Building the search index (`search-index.json`)
- Generating agent-readable outputs (`llms.txt`, `AGENTS.md`)
- Computing navigation and readability artifacts

### Public Mirror (served URL structure)
```
public/changelog/v1.md
```
After the internal conversion, leadtype **mirrors** this file to match the intended URL structure. Your web server/router serves from this path.

### Canonical URL Agents See
```
https://your-domain.com/changelog/v1
```

This is the absolute URL that appears in all agent-readable outputs:
- `/llms.txt` — product index, "Best Starting Points"
- `/docs/llms.txt` — curated docs sections
- `/docs/search-index.json` — search results (agent answers include this URL)
- `/docs/agent-readability.json` — discovery artifact for web crawlers
- `/docs/robots.txt` — references in `Sitemap` meta
- `/docs/sitemap.xml` — canonical URLs for all pages (including `/changelog/v1`)

The key point: **All agent-facing files correctly reference `/changelog/v1`, not `/docs/changelog/v1`.** So when an LLM agent searches the index or fetches a page, it gets the right public URL—changelog is fully integrated into search and LLM context without appearing nested under docs.

---

### How the Mount Works

The `--docs-dir changelog=/changelog` syntax:
- **`changelog`** = source directory (relative to `--src`)  
- **`/changelog`** = URL prefix where it's served to the web

Internally, leadtype:
1. Reads `changelog/*.mdx` files
2. Stages converted markdown to `docs/changelog/*.md` (for processing)
3. Mirrors staged files to `changelog/*.md` in output (for web serving)
4. Records the canonical URL as `/changelog/...` in search, sitemaps, and agent outputs

This keeps changelog pages **completely out of the `/docs/` namespace** on the live site while preserving full search and LLM integration.
