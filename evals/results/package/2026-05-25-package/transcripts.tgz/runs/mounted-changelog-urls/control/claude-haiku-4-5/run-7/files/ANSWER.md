# Mounting Changelog to /changelog/...

## The Single Invocation

```bash
npx leadtype generate --src . --out public --base-url https://yoursite.com --docs-dir docs --docs-dir changelog=/changelog
```

## What Gets Emitted

For a file like `changelog/v1.mdx`:

### 1. **Internal Generated Copy**
```
public/docs/changelog/v1.md
```
This is where `leadtype` initially converts and writes the flattened markdown. It's organized under `docs/changelog/` because internally, the changelog mount point is staged there during processing.

### 2. **Public Mirror**
```
public/changelog/v1.md
```
After conversion, `leadtype` creates a public-facing mirror by copying from `public/docs/changelog/v1.md` to `public/changelog/v1.md`. This mirror lives at the mounted URL prefix and is what humans and agents fetch via HTTP.

### 3. **Canonical URL for Agents**
```
/changelog/v1
```
In `llms.txt`, search indices, and agent-readable artifacts (like `AGENTS.md` or `agent-readability.json`), the page is referenced as `/changelog/v1` — the mounted URL prefix you specified with `changelog=/changelog`. Agents see this as the canonical, public-facing location.

---

## How the `--docs-dir` Mount Syntax Works

- **`--docs-dir docs`** — Default behavior. Maps `docs/` folder to `/docs/...` URLs.
- **`--docs-dir changelog=/changelog`** — Maps `changelog/` folder to `/changelog/...` URLs and includes it in search.

The `=` syntax lets you mount a docs folder *outside* the default `/docs/` hierarchy. Everything under that mount is still searchable (included in the search index) and agent-readable.

## Example Site Output

```
public/
├── docs/                       # Default docs folder
│   ├── index.md
│   ├── changelog/              # Internal staging copy
│   │   └── v1.md
│   ├── llms.txt
│   └── search-index.json
├── changelog/                  # Public mirror at mounted URL
│   └── v1.md
├── llms.txt
├── llms-full.txt
└── search-index.json           # Includes changelog pages
```

Agents will read `/changelog/v1.md` and see it indexed under `/changelog/v1`, not `/docs/changelog/v1`.
