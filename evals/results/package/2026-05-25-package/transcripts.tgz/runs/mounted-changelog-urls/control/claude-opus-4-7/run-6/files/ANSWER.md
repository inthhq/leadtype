# Mounting `changelog/` at `/changelog/...`

## 1. The command

```bash
npx leadtype generate \
  --src . \
  --out public \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --base-url https://example.com
```

The key flag is the second `--docs-dir`. Per `leadtype generate --help`:

> `--docs-dir <dir>` — Docs source folder relative to `--src` (default: `docs`). Repeat to merge multiple folders. Use `<dir>=<url-prefix>` to mount a source outside `/docs`, e.g. `changelog=/changelog`.

So `--docs-dir changelog=/changelog` tells leadtype:

- Take MDX from the local `changelog/` folder.
- Mount its public URL prefix at `/changelog` instead of the default `/docs/changelog`.

We still pass `--docs-dir docs` so the normal docs site keeps building alongside it. (If we passed only `--docs-dir changelog=/changelog`, the first/only source is treated as the primary docs root and would land directly under `out/docs/*.md` — not what we want.)

## 2. What gets emitted for `changelog/v1.mdx`

Internally leadtype always stages every source under one `docs/` tree (that's how the converter, navigation resolver, llms.txt generator, and search indexer all see it). For multi-source mounts, the staged subpath is the source folder's basename — here, `changelog`. Then, because the changelog mount's `urlPrefix` (`/changelog`) doesn't match the default expected prefix (`/docs/changelog`), leadtype mirrors the generated markdown out to the public URL location and rewrites the canonical URL used in `llms.txt`, the sitemap, and the search index.

For a source file `changelog/v1.mdx`, with `--out public --base-url https://example.com`, you get:

| Artifact | Path | Purpose |
| --- | --- | --- |
| **Internal generated copy** | `public/docs/changelog/v1.md` | The flattened markdown the converter writes into the staging mount under `/docs`. It's how the pipeline keeps a single, uniform `docs/` tree internally. |
| **Public mirror** | `public/changelog/v1.md` | Copied out by `copyMountedMarkdownMirrors` because the mount's `urlPrefix` (`/changelog`) differs from `/docs/changelog`. This is what `Accept: text/markdown` fetches will hit. |
| **Canonical URL** | `https://example.com/changelog/v1` | The URL recorded in `llms.txt`, `docs/sitemap.xml`, `docs/sitemap.md`, and the `search-index.json` / `search-content.json` records — so agents and search results link to `/changelog/...`, never `/docs/changelog/...`. |

The page is still picked up by `generateDocsSearchFiles` (same call as for `/docs/...` content — it just uses the `mounts` array to rewrite the URL), so it remains fully searchable through whichever framework adapter (`leadtype/next`, `leadtype/search`, etc.) you wire up.

> Note: the staged `public/docs/changelog/v1.md` copy stays on disk too. If you'd rather not serve it under `/docs/changelog/...`, add a rewrite/redirect in your web framework — leadtype mirrors the canonical copy at `/changelog/v1.md` but doesn't delete the staging copy, since the search/sitemap pipelines read from the unified `docs/` staging tree.
