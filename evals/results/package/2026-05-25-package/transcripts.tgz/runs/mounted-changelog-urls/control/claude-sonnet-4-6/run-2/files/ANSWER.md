# Serving `changelog/` under `/changelog/` with `leadtype generate`

## 1. The single `leadtype generate` invocation

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

### How the flags work

| Flag | Purpose |
|---|---|
| `--src .` | Project root (where `docs/` and `changelog/` both live). |
| `--docs-dir docs` | First (primary) source: the standard `docs/` folder. Its pages are mounted at the default URL prefix `/docs`. |
| `--docs-dir changelog=/changelog` | Second source: the `changelog/` folder. The `<dir>=<url-prefix>` syntax tells leadtype to mount it at `/changelog` instead of the default `/docs/changelog`. |
| `--out public` | All generated artifacts land under `public/`. |
| `--base-url https://example.com` | Absolute URLs in `llms.txt`, `llms-full.txt`, search index, and sitemap will be rooted here. |

The `<dir>=<url-prefix>` syntax is defined in `parseDocsSourceInput` inside the CLI.
A bare `<dir>` value gives the default prefix (`/docs` for the first source, `/docs/<dirname>` for subsequent ones);
appending `=<url-prefix>` overrides that to any site-rooted path — in this case `/changelog`.

Because two source folders are passed, leadtype internally stages them into a
single temporary `docs/` tree, merging them before conversion. The second
source gets a **mount path** derived from the URL prefix (`changelog` ←
`/changelog`), which is the internal sub-directory key used throughout the
pipeline.

---

## 2. What leadtype emits for `changelog/v1.mdx`

### Step 1 — MDX conversion (internal generated copy)

`changelog/v1.mdx` is staged into the internal temp tree as
`docs/changelog/v1.mdx`, then converted by `convertAllMdx` and written to:

```
public/docs/changelog/v1.md
```

This is the **internal generated copy** — the canonical flat-markdown file
that all downstream steps (search index, `llms-full.txt`, sitemap, etc.) read
from. It is the single source of truth for the page's content inside the
output tree.

### Step 2 — Public mirror (copied to the mounted URL path)

After conversion, `copyMountedMarkdownMirrors` detects that the mount
`{ pathPrefix: "changelog", urlPrefix: "/changelog" }` does **not** map to the
default expected prefix `/docs/changelog`. It therefore copies every `*.md`
file from `public/docs/changelog/` into:

```
public/changelog/v1.md
```

This is the **public mirror** — the file your web server (Next.js, Astro, etc.)
serves when an HTTP client requests `/changelog/v1.md` or sends
`Accept: text/markdown`. Agents that follow `llms.txt` links reach the page
here.

### Step 3 — Canonical URL (what agents see)

The mount configuration `{ pathPrefix: "changelog", urlPrefix: "/changelog" }`
is passed through `toDocsUrlPath` / `toMountedMarkdownUrlPath` whenever the
pipeline needs an addressable URL. For `changelog/v1.md` the result is:

```
/changelog/v1          ← HTML page URL path
/changelog/v1.md       ← markdown mirror URL path (agent-readable)
https://example.com/changelog/v1.md   ← absolute URL recorded in the search
                                         index, llms.txt, llms-full.txt, and
                                         agent-readability.json
```

Agents (and search) therefore see the page at **`https://example.com/changelog/v1`**
(HTML) / **`https://example.com/changelog/v1.md`** (markdown), never under
`/docs/changelog/…`.

### Summary table

| Artifact | Path on disk | Public URL |
|---|---|---|
| Internal generated copy | `public/docs/changelog/v1.md` | *(not publicly routed by default)* |
| Public mirror | `public/changelog/v1.md` | `/changelog/v1.md` |
| HTML page (your renderer) | *(your framework reads the copy)* | `/changelog/v1` |
| Search index entry | recorded in `public/docs/search-index.json` | resolves to `https://example.com/changelog/v1` |
| `llms.txt` / `llms-full.txt` link | `public/llms.txt`, `public/llms-full.txt` | `https://example.com/changelog/v1.md` |

The page is fully **searchable** because `generateDocsSearchFiles` reads from
`public/docs/` (including `public/docs/changelog/v1.md`) using the mount map,
so `changelog/v1` is indexed with URL `/changelog/v1` — not `/docs/changelog/v1`.
