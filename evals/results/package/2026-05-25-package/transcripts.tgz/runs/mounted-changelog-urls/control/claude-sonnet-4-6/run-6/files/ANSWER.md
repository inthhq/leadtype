# Serving `changelog/` under `/changelog/` with `leadtype generate`

## 1. The single `leadtype generate` invocation

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

### How it works

`--docs-dir` accepts the form `<dir>=<url-prefix>`.  The CLI's
`parseDocsSourceInput` function splits on the first `=` and records the
directory (`changelog`) together with the explicit URL prefix (`/changelog`).
`resolveDocsSources` then builds two source entries:

| `--docs-dir` value | source directory | URL prefix |
|--------------------|-----------------|------------|
| `docs` (first, default) | `./docs` | `/docs` |
| `changelog=/changelog` | `./changelog` | `/changelog` |

Because `/changelog` differs from the default `/docs/<mountPath>` that would
have been inferred automatically, `copyMountedMarkdownMirrors` runs after
conversion and copies the generated markdown mirrors from their internal staging
location into `public/changelog/`.

Search (`generateDocsSearchFiles`) and LLM artifacts
(`generateLlmsTxt` / `generateLLMFullContextFiles`) all receive the full
`mounts` array, so every changelog page is indexed and included in
`llms.txt` / `llms-full.txt` with its `/changelog/…` URL — not a
`/docs/…` URL.

---

## 2. What is emitted for `changelog/v1.mdx`

### Step 1 — MDX conversion (internal staging copy)

`convertAllMdx` processes the merged staging tree.  Because `changelog` is the
second source and its mount path is `"changelog"` (derived from the folder
name), the file is staged at:

```
<tmp>/docs/changelog/v1.mdx
```

After conversion the generated markdown mirror lands at the **internal** path:

```
public/docs/changelog/v1.md
```

This is the canonical **internal** location that the search index, `llms.txt`,
and `llms-full.txt` read from.

### Step 2 — Public mirror (copyMountedMarkdownMirrors)

Because the mount's `urlPrefix` (`/changelog`) differs from the default
`/docs/changelog` that would have been emitted for a second source, the CLI
runs `copyMountedMarkdownMirrors`.  It reads every `*.md` file from the
internal directory (`public/docs/changelog/`) and copies them to the directory
that matches the public URL prefix:

```
public/changelog/v1.md     ← the publicly served markdown mirror
```

### Step 3 — Canonical URL seen by agents

`toDocsUrlPath` resolves the file's relative path (`changelog/v1`) against the
mounts table.  The `changelog` path prefix matches the mount
`{ pathPrefix: "changelog", urlPrefix: "/changelog" }`, so the canonical URL
path is:

```
/changelog/v1
```

With `--base-url https://example.com` the **absolute canonical URL** that
appears in `llms.txt`, `llms-full.txt`, `search-index.json`, and the
`agent-readability.json` manifest is:

```
https://example.com/changelog/v1
```

The corresponding markdown mirror URL (what an HTTP agent following
`Accept: text/markdown` or the `llms.txt` link list would fetch) is:

```
https://example.com/changelog/v1.md
```

served from `public/changelog/v1.md`.

### Summary table

| Artifact | Path on disk | Public URL |
|---|---|---|
| Internal generated copy | `public/docs/changelog/v1.md` | (not directly exposed) |
| Public markdown mirror | `public/changelog/v1.md` | `https://example.com/changelog/v1.md` |
| Canonical page URL (agents & search) | — | `https://example.com/changelog/v1` |
