# Answer

Use a mounted second docs source for the sibling changelog folder:

```bash
npx leadtype generate --src . --docs-dir docs --docs-dir changelog=/changelog --out public --base-url https://YOUR_SITE_ORIGIN
```

For a source file such as `changelog/v1.mdx`, that invocation treats `changelog` as an additional mounted source whose URL prefix is `/changelog`:

- Internal generated markdown copy: `public/docs/changelog/v1.md`
  - Leadtype still converts all mounted sources into the internal generated `docs/` tree so search and agent artifacts can read one combined markdown corpus.
- Public mounted markdown mirror: `public/changelog/v1.md`
  - Because the source was mounted as `changelog=/changelog`, Leadtype mirrors the generated markdown out to the public `/changelog` prefix instead of exposing it canonically as `/docs/changelog`.
- Canonical URL agents see: `https://YOUR_SITE_ORIGIN/changelog/v1`
  - In agent readability/search metadata this page is identified by `urlPath: "/changelog/v1"` and its markdown alternate is `markdownUrlPath: "/changelog/v1.md"`.
  - It is not canonicalized as `/docs/changelog/v1`.
