# Serving `changelog/` under `/changelog/` with `leadtype generate`

## 1. The single invocation

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

The second `--docs-dir` flag uses the `<dir>=<url-prefix>` mount syntax:
`changelog` is the source folder (relative to `--src`) and `/changelog` is
the public URL prefix where those pages should live on the generated site.

## 2. What happens to `changelog/v1.mdx`

### Step 1 — internal staging copy

Before conversion, all source trees are merged into a temporary staging
directory.  Because `changelog` is a *non-primary* source (the first source
is `docs`), leadtype derives a mount path from the folder name:

```
<tmpdir>/leadtype-generate-XXXX/
└── docs/
    └── changelog/        ← mount path = "changelog"
        └── v1.mdx        ← copied verbatim from changelog/v1.mdx
```

MDX-to-markdown conversion then runs over the whole staging `docs/` tree and
writes flattened `.md` files into the real output directory:

```
public/
└── docs/
    └── changelog/
        └── v1.md         ← converted markdown (the internal copy)
```

This `public/docs/changelog/v1.md` file is the **internal generated copy**.
It always exists under `public/docs/<mountPath>/` regardless of the public
URL prefix.

### Step 2 — public mirror

After conversion, `copyMountedMarkdownMirrors` checks every mount.  It
compares the mount's declared `urlPrefix` (`/changelog`) against the path
that would be expected if the source lived under `/docs`
(`/docs/changelog`).  Because they differ, it **copies** every `.md` file
from the internal location to a parallel tree that matches the public URL:

```
public/
└── changelog/
    └── v1.md             ← the public mirror (identical content)
```

This is the file HTTP agents and tools fetch when they request
`/changelog/v1.md` or send `Accept: text/markdown` to `/changelog/v1`.

### Step 3 — canonical URL

`toDocsUrlPath` resolves the relative staging path `changelog/v1` through the
mount table:

1. The `changelog` path prefix is stripped from the relative path, leaving
   `v1`.
2. The mount's `urlPrefix` (`/changelog`) is prepended.

Result:

```
/changelog/v1
```

This is the canonical URL that appears in `llms.txt`, `llms-full.txt`,
`search-index.json`, and every internal cross-reference.  Agents see the page
at `https://example.com/changelog/v1` — **not** under `/docs/`.

### Search

`generateDocsSearchFiles` receives the full `mounts` array, so the BM25
search index records the page under its `/changelog/v1` canonical URL.
Searches for changelog content resolve to the correct public path.

### Summary table

| Artifact | Path in `public/` | Purpose |
|---|---|---|
| Internal generated copy | `docs/changelog/v1.md` | Produced by MDX→MD conversion; source-of-truth for all downstream steps |
| Public mirror | `changelog/v1.md` | Served at the public URL; fetched by HTTP agents using `Accept: text/markdown` |
| Canonical URL (agents) | `/changelog/v1` (absolute: `https://example.com/changelog/v1`) | The URL recorded in `llms.txt`, `search-index.json`, and all cross-links |
