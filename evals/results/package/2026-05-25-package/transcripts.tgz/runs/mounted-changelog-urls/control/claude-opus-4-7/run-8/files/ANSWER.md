# Mounting `changelog/` at `/changelog/...`

## 1. The command

Use a second `--docs-dir` whose value carries an explicit URL prefix
(`<dir>=<url-prefix>`). The first `--docs-dir` stays as `docs` so the
main docs continue to live at `/docs/...`:

```bash
npx leadtype generate \
  --src . \
  --out public \
  --base-url https://example.com \
  --docs-dir docs \
  --docs-dir changelog=/changelog
```

Notes on why it has to look like this:

- `leadtype generate`'s help for `--docs-dir` says:
  *"Repeat to merge multiple folders. Use `<dir>=<url-prefix>` to mount a
  source outside `/docs`, e.g. `changelog=/changelog`."* That's exactly
  this case.
- The **first** `--docs-dir` is always the "primary" source and is
  staged at the root of the internal docs tree. Keep `docs` first so
  `docs/foo.mdx` keeps its canonical `/docs/foo` URL. Additional sources
  are mounted by their basename, so `changelog/` becomes the mount
  `changelog`.
- Adding `=/changelog` overrides the default URL prefix (which would
  otherwise have been `/docs/changelog`) and pushes the public copy and
  canonical URL up to the site root.
- No `leadtype.config.*` / `docs.config.*` is required — the same effect
  can also be expressed by declaring a `collections` map with
  `prefix: "/changelog"`, but for a single sibling folder the CLI flag
  is the minimum-friction option, and that's what the prompt asks for.

## 2. What gets emitted for `changelog/v1.mdx`

For an input file `changelog/v1.mdx`, the run produces three things you
care about:

| Role | Path / URL |
| --- | --- |
| Internal generated copy (staging mirror under `/docs`) | `public/docs/changelog/v1.md` |
| Public mirror at the requested mount | `public/changelog/v1.md` |
| Canonical URL agents see (in `llms.txt`, search index, sitemap, agent‑readability manifest) | `https://example.com/changelog/v1` |

How that falls out of the pipeline:

1. **Conversion.** `convertAllMdx` always writes flattened markdown
   under `<outDir>/docs`, keyed by each source's `mountPath` (the
   basename of the source dir). So `changelog/v1.mdx` is first written
   to `public/docs/changelog/v1.md`. This is the staged copy the search
   indexer and `llms-full.txt` consume.
2. **Public mirror.** After conversion, `copyMountedMarkdownMirrors`
   sees the mount's `urlPrefix` (`/changelog`) differs from the
   "expected" docs-relative prefix (`/docs/changelog`) and copies every
   `.md` from `public/docs/changelog/` to `public/changelog/`. That's
   the directory your web server should expose at `/changelog/...` to
   serve the `Accept: text/markdown` / `.md` mirror.
3. **Canonical URLs.** All URL generation goes through
   `toDocsUrlPath(relativePath, mounts)`, which resolves the file
   against the matching mount and prefixes with that mount's
   `urlPrefix`. With `urlPrefix = "/changelog"` and `baseUrl =
   https://example.com`, `v1.mdx` resolves to
   `https://example.com/changelog/v1` — that's the URL written into
   `llms.txt`, `llms-full.txt`, `search-index.json`,
   `search-content.json`, `sitemap.xml`, `sitemap.md`, and
   `agent-readability.json`. The page is therefore searchable like any
   other doc, just with a `/changelog/...` canonical URL instead of
   `/docs/changelog/...`.

A regular `docs/quickstart.mdx` in the same run is unaffected — it
lands at `public/docs/quickstart.md` with canonical URL
`https://example.com/docs/quickstart`.
