# Answer

Use site mode (do not pass `--bundle`) and mount the sibling `changelog/` source with an explicit URL prefix:

```bash
leadtype generate --src . --docs-dir docs --docs-dir changelog=/changelog --out public --base-url https://YOUR-SITE.example
```

Replace `https://YOUR-SITE.example` with the real site origin.

For a source file `changelog/v1.mdx`, leadtype stages that second docs source under its mount name and converts it as if it lived at `docs/changelog/v1.mdx` internally. The emitted files/URLs are:

- Internal generated markdown copy: `public/docs/changelog/v1.md`
- Public mounted markdown mirror: `public/changelog/v1.md` (served as `/changelog/v1.md`)
- Canonical page URL agents see: `/changelog/v1` (or `https://YOUR-SITE.example/changelog/v1` with the `--base-url` above)

The page is still included in the site search artifacts generated under `public/docs/search-index.json` / `public/docs/search-content.json`, with its search document URL set to `/changelog/v1` rather than `/docs/changelog/v1`.
