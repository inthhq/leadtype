# Serving `changelog/` at `/changelog/` with `leadtype generate`

## 1. The single invocation

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

### Why each piece matters

| Flag | Purpose |
|---|---|
| `--docs-dir docs` | First source — the regular docs folder, mounted at the default `/docs` prefix (no `=` override needed). |
| `--docs-dir changelog=/changelog` | Second source — the `changelog/` folder beside `docs/`, explicitly mounted at the `/changelog` URL prefix instead of the default `/docs/changelog`. The `<dir>=<url-prefix>` syntax is the built-in way to override where a source folder appears in the public URL tree. |
| `--out public` | Output root; all generated artefacts land here. |
| `--base-url https://example.com` | Fills absolute URLs in `llms.txt`, `llms-full.txt`, the search index, and the agent-readability manifest. |

The `--docs-dir` flag is repeatable; the first occurrence is the **primary** source (mount path `""`, default URL prefix `/docs`). Every subsequent occurrence is a **secondary** source whose mount path is derived from the folder name and whose URL prefix is either inferred as `/docs/<name>` or overridden with the `=<url-prefix>` form. Using `changelog=/changelog` forces the URL prefix to `/changelog`, keeping it out of the `/docs/…` hierarchy entirely.

---

## 2. What the pipeline emits for `changelog/v1.mdx`

### Step-by-step

#### 2a. Source staging

Because two `--docs-dir` values are supplied, the CLI copies both sources into a shared temporary staging tree before conversion. The staging layout becomes:

```
<tmpdir>/docs/
  <docs source files>     ← from docs/
  changelog/
    v1.mdx                ← from changelog/v1.mdx, path-prefixed with "changelog"
```

The mount table recorded for this run is:

```
pathPrefix: ""          → urlPrefix: /docs
pathPrefix: changelog   → urlPrefix: /changelog
```

#### 2b. MDX → Markdown conversion (`convertAllMdx`)

The CLI runs `convertAllMdx` over the staging `docs/` tree and writes flattened Markdown to the **internal** output directory:

```
public/docs/changelog/v1.md      ← canonical internal copy
```

This file lives under `public/docs/` because that is where `convertAllMdx` always writes (it does not know about URL prefixes at this stage).

#### 2c. Public mirror (`copyMountedMarkdownMirrors`)

After conversion, the CLI iterates the mount table and copies the Markdown files for every mount whose URL prefix does **not** match the expected default (`/docs/<pathPrefix>`). For the `changelog` mount, the expected default would be `/docs/changelog`, but the configured prefix is `/changelog` — so a mismatch is detected and the files are copied out:

```
public/changelog/v1.md            ← public mirror, served at /changelog/v1.md
```

The internal copy at `public/docs/changelog/v1.md` is the source of truth used internally by the search and LLM artefact generators; the copy under `public/changelog/` is what a browser or HTTP client fetching `https://example.com/changelog/v1.md` receives.

#### 2d. URL resolution (`toDocsUrlPath`)

`toDocsUrlPath` resolves a relative path through the mount table by longest-prefix match. For `changelog/v1.mdx`:

1. The relative path `changelog/v1.mdx` starts with the mount's `pathPrefix` (`changelog`).
2. The mount's `urlPrefix` is `/changelog`.
3. The mounted-relative path is `v1` (after stripping the prefix segment and extension).
4. The final URL path is **`/changelog/v1`**.

#### 2e. Search index

`generateDocsSearchFiles` reads the converted Markdown from `public/docs/` and resolves every document's `urlPath` through the same mount table. The search record for `changelog/v1.md` is indexed with:

```json
{
  "urlPath": "/changelog/v1",
  "absoluteUrl": "https://example.com/changelog/v1",
  "relativePath": "changelog/v1"
}
```

The page is therefore fully searchable via `public/docs/search-index.json` and `public/docs/search-content.json`, despite its public URL being outside `/docs/`.

#### 2f. Canonical URL seen by agents

The agent-readability manifest (`public/docs/agent-readability.json`), `llms.txt`, and `llms-full.txt` all call `toMountedMarkdownUrlPath` for the Markdown mirror path and `toDocsUrlPath` for the HTML URL. For `changelog/v1`:

| Field | Value |
|---|---|
| `urlPath` (HTML page) | `/changelog/v1` |
| `markdownUrlPath` (`.md` mirror) | `/changelog/v1.md` |
| `absoluteUrl` | `https://example.com/changelog/v1` |
| `markdownAbsoluteUrl` | `https://example.com/changelog/v1.md` |

Any agent that reads `llms.txt` or the `agent-readability.json` manifest sees `/changelog/v1` — never `/docs/changelog/v1`.

---

## Summary of artefacts for `changelog/v1.mdx`

| Artefact | Location on disk | Public URL |
|---|---|---|
| Internal generated copy (Markdown) | `public/docs/changelog/v1.md` | _(not directly served; used by search/LLM generators)_ |
| Public Markdown mirror | `public/changelog/v1.md` | `https://example.com/changelog/v1.md` |
| Canonical URL (HTML page) | _(rendered by your framework at build time)_ | `https://example.com/changelog/v1` |
| Search index entry | `public/docs/search-index.json` | `urlPath: /changelog/v1` |
| Agent-readability entry | `public/docs/agent-readability.json` | `urlPath: /changelog/v1`, `markdownUrlPath: /changelog/v1.md` |
