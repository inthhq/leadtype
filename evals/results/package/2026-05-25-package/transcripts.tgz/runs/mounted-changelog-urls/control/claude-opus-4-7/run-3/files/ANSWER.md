# Serving `changelog/` at `/changelog/...`

## 1. The command

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

What does the work is the `<dir>=<url-prefix>` form of `--docs-dir`, documented in
`leadtype generate --help`:

> `--docs-dir <dir>` Docs source folder relative to `--src` (default: `docs`).
> Repeat to merge multiple folders. Use `<dir>=<url-prefix>` to mount a source
> outside `/docs`, e.g. `changelog=/changelog`.

The first `--docs-dir` (no `=`) is the root source, mounted at `/docs`. The
second one (`changelog=/changelog`) tells leadtype: "stage these files under
the `changelog/` mount, but publish them at the URL prefix `/changelog`
instead of the default `/docs/changelog`."

(If you prefer config over flags, the equivalent is a `leadtype.config.ts`
with two `collections` — one with `dir: "docs"`, one with
`dir: "changelog", prefix: "/changelog"` — and then just
`npx leadtype generate --base-url …`.)

## 2. What gets emitted for `changelog/v1.mdx`

Given input `./changelog/v1.mdx`, after the command above runs:

### Internal generated copy (always under `public/docs/...`)

```
public/docs/changelog/v1.md
```

This is the canonical flattened-markdown file that leadtype produces by
running the MDX converter. Every mounted source is staged under the
`docs/` tree internally — `mountPath` for the second source is `changelog`,
so the file lands at `docs/changelog/v1.md`. The search indexer, link
checker, `llms.txt`, sitemap and agent-readability manifest all read from
this staging tree, so the page is fully indexed and searchable.

### Public mirror (under the mounted URL prefix)

```
public/changelog/v1.md
```

Because the configured URL prefix (`/changelog`) differs from the default
that the mount path would have produced (`/docs/changelog`), leadtype's
`copyMountedMarkdownMirrors` step copies every `*.md` from
`public/docs/changelog/**` to `public/changelog/**`. That is what a host
serves to humans and to HTTP agents requesting `text/markdown`.

### Canonical URL agents see

```
https://example.com/changelog/v1
```

All URL-producing artifacts — `public/llms.txt`, `public/llms-full.txt`,
`public/docs/search-index.json`, `public/docs/sitemap.xml`,
`public/docs/sitemap.md`, `public/docs/agent-readability.json` — emit
`/changelog/v1` (and the `.md` variant `/changelog/v1.md`) for this page,
**not** `/docs/changelog/v1`. That happens because the mount
`{ pathPrefix: "changelog", urlPrefix: "/changelog" }` is threaded through
`toDocsUrlPath` everywhere a public URL is built.

### Summary table

| Concern                     | Path                                  |
| --------------------------- | ------------------------------------- |
| MDX source                  | `./changelog/v1.mdx`                  |
| Internal flattened markdown | `public/docs/changelog/v1.md`         |
| Public markdown mirror      | `public/changelog/v1.md`              |
| Canonical page URL          | `https://example.com/changelog/v1`    |
| Canonical markdown URL      | `https://example.com/changelog/v1.md` |
| Appears in `llms.txt`?      | Yes, as `/changelog/v1.md`            |
| Appears in search index?    | Yes, scoped to the `/changelog` mount |
