# Serving Changelog at `/changelog/...` with `leadtype generate`

## The Solution

Run this single `leadtype generate` invocation:

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

The key is the `--docs-dir changelog=/changelog` syntax, which tells leadtype:
- **Source**: Read MDX from the `./changelog/` directory
- **URL mount**: Mount those files at `/changelog/...` on the generated site (not under `/docs/`)

You can repeat `--docs-dir` multiple times to add more sources. The first one (default `docs`) goes to `/docs/`; additional ones use explicit mounts.

---

## What It Emits for `changelog/v1.mdx`

For a source file at `changelog/v1.mdx`, leadtype generates three artifacts:

### 1. **Internal Copy** (staging/conversion cache)
```
public/docs/changelog/v1.md
```
This is the flattened Markdown output written during the conversion phase. It's stored under `docs/` internally during the build pipeline as a staging location.

### 2. **Public Mirror** (canonical location for humans and agents)
```
public/changelog/v1.md
```
After conversion, leadtype copies the generated Markdown from the staging location (`public/docs/changelog/v1.md`) to the final canonical public location using the mount specification (`/changelog` → `public/changelog/`). This is what gets served to:
- Web crawlers and browsers via `GET /changelog/v1.md` (with `Accept: text/markdown`)
- Agent readability checks and `/llms.txt` references
- Search index ingestion

### 3. **Canonical URL** (what agents see in manifests)
```
https://example.com/changelog/v1
```
When agents read `llms.txt`, `/docs/llms.txt`, search-index.json, or the agent-readability manifest, they see the canonical URL path as:
- **URL path**: `/changelog/v1` (no extension; frontmatter slugs derive from filename)
- **Absolute URL**: `https://example.com/changelog/v1` (from `--base-url` + path)
- **Markdown mirror**: `https://example.com/changelog/v1.md` (auto-appended `.md` for agent content negotiation)

The `urlPath` in the generated navigation and search index reflects the mounted path, so agents know to find the canonical Markdown at `/changelog/v1.md`, not `/docs/changelog/v1.md`.

---

## Why This Works

The `--docs-dir <dir>=<url-prefix>` syntax is a **path-to-URL mount**. It:

1. Treats `<dir>` as a source root for MDX discovery (like a second `docs/` folder)
2. Applies `<url-prefix>` to the generated URL paths, bypassing the default `/docs/` prefix
3. Still generates the internal markdown copy under `public/docs/<dir>/` for the build pipeline
4. **Automatically copies** the finished markdown to the mounted location after conversion (via `copyMountedMarkdownMirrors`)
5. Updates all agent-facing indexes (llms.txt, search, readability manifest) to reference the mounted URL

The pages remain fully searchable because the search index includes the correct canonical URL paths and content from the changelog files, even though they're mounted outside `/docs/`.
