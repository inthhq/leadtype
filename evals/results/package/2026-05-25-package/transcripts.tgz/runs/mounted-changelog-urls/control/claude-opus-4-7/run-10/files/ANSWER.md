# Mounting `changelog/` under `/changelog` (not `/docs/changelog`)

## 1. The command

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

The relevant flag is **`--docs-dir <dir>=<url-prefix>`**. It is documented in
`leadtype generate --help` as:

> `--docs-dir <dir>` Docs source folder relative to `--src` (default: docs).
> Repeat to merge multiple folders.
> Use `<dir>=<url-prefix>` to mount a source outside `/docs`,
> e.g. `changelog=/changelog`.

A few rules the CLI enforces (from `dist/cli.js`):

- The flag is **repeatable**. The first `--docs-dir` is always mounted at the
  root of the staging tree, so put `docs` first and `changelog=/changelog`
  second.
- The URL prefix may not be `/` (you can't take over the site root).
- Two sources may not resolve to the same mount path or same URL prefix.
- Sources may not produce the same staged file name. (`docs/index.mdx` and
  `changelog/index.mdx` are fine — they live under different mount paths;
  `docs/v1.mdx` and `changelog/v1.mdx` are also fine for the same reason.)

Swap `--base-url` for your real production URL. If you're publishing the docs
inside an npm tarball instead of to a website, add `--bundle` (the same mount
rules apply, but only `AGENTS.md` + `docs/*.md` are emitted).

## 2. What gets emitted for `changelog/v1.mdx`

Under the hood leadtype always converts MDX through a canonical
`/<out>/docs/...` staging tree and then, when a source has a non-default
`urlPrefix`, copies the resulting markdown to a second location matching that
URL prefix. So for `changelog/v1.mdx` you get **two** on-disk artifacts plus
**one** canonical URL:

| Role | Path / URL |
| --- | --- |
| Internal generated copy (staging tree used by search, llms.txt, sitemap, etc.) | `public/docs/changelog/v1.md` |
| Public mirror (served at the user-visible URL) | `public/changelog/v1.md` |
| Canonical URL agents and crawlers see | `https://example.com/changelog/v1` |

The plumbing, for the curious:

- `resolveDocsSources` assigns the second source `mountPath: "changelog"` and
  `urlPrefix: "/changelog"`.
- `convertAllMdx` writes the flattened markdown into the staging path
  `public/docs/changelog/v1.md`.
- `copyMountedMarkdownMirrors` notices that the mount's `urlPrefix`
  (`/changelog`) differs from the expected default
  (`/docs/changelog`) and copies the markdown tree to
  `public/changelog/v1.md` — that's the public mirror.
- `toDocsUrlPath` (in `leadtype/dist/_shared/docs-url-*.js`) resolves the
  source's relative path against the mount table and emits
  `/changelog/v1` as the page URL. That URL is what flows into:
  - `public/llms.txt` and `public/llms-full.txt`
  - `public/docs/search-index.json` and `public/docs/search-content.json`
  - `public/docs/sitemap.xml`, `public/docs/sitemap.md`, `public/docs/robots.txt`
  - `public/docs/agent-readability.json`

That last point is what answers the "still searchable" requirement: search,
llms, and sitemap artifacts are built from the canonical mount table, so
every changelog page is indexed exactly once and points at
`https://example.com/changelog/v1` — never at `/docs/changelog/v1`.
