# Serving `changelog/` under `/changelog/` with `leadtype generate`

## 1. The single invocation

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

### Why this works

`--docs-dir` accepts the form `<dir>=<url-prefix>`.  
Passing it **twice** tells leadtype to merge two source trees into one staged
docs directory before the rest of the pipeline runs:

| flag value | source folder | mounted at staging path | public URL prefix |
|---|---|---|---|
| `docs` (first, implicit default) | `./docs/` | _(root staging docs dir)_ | `/docs` |
| `changelog=/changelog` | `./changelog/` | `changelog/` inside staging | `/changelog` |

The `changelog=/changelog` entry satisfies the constraint that the URL prefix
must **not** be the site root (`/`) and must **not** default to `/docs/…` — it
is an explicit, non-`/docs` prefix, so the mount table becomes:

```
pathPrefix: "changelog"   →  urlPrefix: "/changelog"
pathPrefix: ""            →  urlPrefix: "/docs"
```

The search pipeline operates over every staged file regardless of its mount,
so changelog pages appear in `public/docs/search-index.json` with their
correct `/changelog/…` canonical URLs.

---

## 2. What leadtype emits for `changelog/v1.mdx`

### Step-by-step through the pipeline

#### a) Source mirror / staging

Because two `--docs-dir` sources are present, leadtype creates a temporary
staging directory.  `changelog/v1.mdx` is copied into it at the sub-path that
corresponds to the `changelog` mount:

```
<tmpdir>/leadtype-generate-XXXX/docs/changelog/v1.mdx
```

#### b) Internal generated copy — `convertAllMdx`

`convertAllMdx` walks `<staging>/docs/` and writes one `.md` file per `.mdx`
file, preserving the relative path, under `public/docs/`:

```
public/docs/changelog/v1.md
```

This is the **internal generated copy** — the canonical markdown artefact that
every other pipeline step reads (`llms.txt` entries, search indexing,
`llms-full.txt`, sitemap, agent-readability manifest).

#### c) Public mirror — `copyMountedMarkdownMirrors`

After conversion, leadtype walks the mount table.  For the `changelog` mount it
finds:

```
pathPrefix : "changelog"
urlPrefix  : "/changelog"          ← explicit, non-default
expected   : "/docs/changelog"     ← what the default would have been
```

Because the configured `urlPrefix` (`/changelog`) differs from what the default
rule would produce (`/docs/changelog`), leadtype copies every `.md` file from
the internal path into the public output path that mirrors the URL prefix:

```
public/docs/changelog/v1.md   →   public/changelog/v1.md
```

`public/changelog/v1.md` is the **public mirror** — the file your web server
or CDN serves when an HTTP client (browser or agent) does:

```
GET /changelog/v1.md
Accept: text/markdown
```

#### d) Canonical URL agents see

`toDocsUrlPath` resolves `changelog/v1` against the mount table:

1. The relative staging path `changelog/v1` matches `pathPrefix: "changelog"`.
2. The mounted-relative path becomes `v1`.
3. The result is `urlPrefix + "/" + mountedRelativePath` = **`/changelog/v1`**.

With `--base-url https://example.com` the fully-qualified canonical URL is:

```
https://example.com/changelog/v1
```

That URL appears in:

- `public/llms.txt` and `public/docs/llms.txt` (entry line for the page)
- `public/llms-full.txt` (full-context bundle header)
- `public/docs/search-index.json` (each search record's `url` field)
- `public/docs/sitemap.xml` / `public/docs/sitemap.md`
- The `agent-readability.json` manifest

### Summary table

| Artefact | Path on disk | URL |
|---|---|---|
| Internal generated copy | `public/docs/changelog/v1.md` | _(internal only, used by the pipeline)_ |
| Public markdown mirror | `public/changelog/v1.md` | `https://example.com/changelog/v1.md` |
| Canonical HTML/agent URL | _(rendered by your UI from the source)_ | `https://example.com/changelog/v1` |
