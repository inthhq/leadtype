# Serving `changelog/` at `/changelog/...`

## 1. The `leadtype generate` invocation

```bash
npx leadtype generate \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

The `--docs-dir` flag can be repeated and accepts the form `<dir>=<url-prefix>`.
Passing it twice mounts two source trees into the same pipeline:

| `--docs-dir` value  | Source folder | URL prefix  |
|---------------------|---------------|-------------|
| `docs`              | `./docs/`     | `/docs`     |
| `changelog=/changelog` | `./changelog/` | `/changelog` |

Because a non-`/docs` URL prefix is declared explicitly for the second source,
leadtype knows the public path for every file in `changelog/` should begin with
`/changelog` instead of the default `/docs/changelog`.

---

## 2. What happens to `changelog/v1.mdx`

### Step 1 — Staging / internal generated copy

During generation leadtype stages all sources into a temporary unified tree
under a single `docs/` directory (in a `mkdtemp` working directory).  
The `changelog` folder has an inferred mount path of `changelog`
(derived from `path.basename("changelog")`), so the file is staged at:

```
<tmpdir>/leadtype-generate-XXXXXX/docs/changelog/v1.mdx
```

The MDX is then converted to Markdown by `convertAllMdx`, writing the
**internal** generated copy to:

```
public/docs/changelog/v1.md
```

This is the single source of truth that all downstream generators (search
index, `llms-full.txt`, agent-readability manifest, etc.) read from.

### Step 2 — Public mirror

After conversion, `copyMountedMarkdownMirrors` is called with the mount table:

```
pathPrefix: "changelog"   →   urlPrefix: "/changelog"
```

Because the URL prefix (`/changelog`) differs from the default nested path
(`/docs/changelog`), the function copies every `.md` file from
`public/docs/changelog/` to the mirror directory that matches the declared URL
prefix:

```
public/changelog/v1.md
```

This mirror is what your web server serves when a browser or HTTP client
requests `/changelog/v1.md` (`Accept: text/markdown` or a direct `.md` URL).

### Step 3 — Canonical URL that agents see

The `toDocsUrlPath` function resolves the page's URL by matching the file's
mount-relative path against the mount table.  
For `changelog/v1.mdx`:

- mount `pathPrefix = "changelog"` matches
- `mountedRelativePath` → `"v1"` (after stripping the prefix and extension)
- `urlPrefix = "/changelog"`
- Result: **`/changelog/v1`**

With `--base-url https://example.com` the absolute URL becomes:

```
https://example.com/changelog/v1
```

That canonical URL is what appears in:
- `public/llms.txt` and `public/docs/llms.txt` link lists
- `public/llms-full.txt` (`URL: https://example.com/changelog/v1`)
- `public/docs/agent-readability.json` (`urlPath`, `absoluteUrl`)
- `public/docs/sitemap.xml` and `public/docs/sitemap.md`
- The BM25 search index (`public/docs/search-index.json`)

The file is fully indexed and searchable because `generateDocsSearchFiles`
reads from `public/docs/` (the internal copy) using the same mount table, so
every changelog page surfaces in search results with its `/changelog/…` URL
rather than `/docs/changelog/…`.

### Summary table for `changelog/v1.mdx`

| Artifact | Path |
|---|---|
| Internal generated copy | `public/docs/changelog/v1.md` |
| Public markdown mirror | `public/changelog/v1.md` |
| Canonical URL (agents & browsers) | `https://example.com/changelog/v1` |
