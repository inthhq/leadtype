# Serving Changelog Under `/changelog/...`

## The Command

Use this single `leadtype generate` invocation:

```bash
npx leadtype generate \
  --src . \
  --out public \
  --base-url https://example.com \
  --docs-dir docs \
  --docs-dir changelog=/changelog
```

The key syntax is `--docs-dir changelog=/changelog`:
- `changelog` = the source folder (relative to `--src`)
- `/changelog` = the URL prefix where pages are served on the site (outside `/docs`)

## What Gets Emitted

For a file at `changelog/v1.mdx`:

### 1. Internal Generated Copy
**Location:** `public/docs/changelog/v1.md`

This is the intermediate build artifact. The changelog source is **staged** under the `docs/` staging directory to unify MDX conversion. Because `changelog` is mounted at the root level (not inside `docs`), leadtype internally prefixes it with its mount path.

### 2. Public Mirror
**Location:** `public/changelog/v1.md`

After conversion, leadtype's `copyMountedMarkdownMirrors()` function detects that the URL prefix (`/changelog`) differs from the default nested docs path (`/docs/changelog`), so it **copies the file tree** from the staging area to the custom mount point.

This is the public-facing markdown file that agents and web servers fetch.

### 3. Canonical URL Agents See
**URL:** `https://example.com/changelog/v1.md`

In `llms.txt` and search indices, pages are registered at this canonical URL—*not* under `/docs/changelog/...`. This ensures agents and tools read from the correct path, and search queries return results with the correct public URL.

---

## How It Works

1. **Parsing:** `--docs-dir changelog=/changelog` is parsed by `parseDocsSourceInput()` into:
   - `docsDir: "changelog"`
   - `urlPrefix: "/changelog"` (normalized via `normalizeUrlPrefix()`)

2. **Staging:** Files from `changelog/` are copied to a temporary docs directory with mount path `"changelog"`, creating `docs/changelog/v1.mdx`.

3. **Conversion:** MDX files are converted to markdown under `public/docs/changelog/v1.md`.

4. **Mirroring:** Because the URL prefix `/changelog` ≠ the default path `/docs/changelog`, the function `copyMountedMarkdownMirrors()` mirrors the converted markdown from `public/docs/changelog/` to `public/changelog/`.

5. **Search & LLMs Indexing:** The canonical URL for all indexing operations is `/changelog/v1.md` (derived from the `urlPrefix`), so agents and search see the correct public path.

---

## Key Behavior

- **Still searchable:** Changelog pages are included in the static search index (`search-index.json`) with URLs under `/changelog/...`
- **Minimal duplication:** The internal copy (`public/docs/changelog/`) is only created during conversion; the public mirror is the canonical served copy.
- **Composable:** You can mount multiple folders with different prefixes:
  ```bash
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --docs-dir faq=/faq
  ```
  Each gets its own URL prefix, staging mount path, and public mirror.
