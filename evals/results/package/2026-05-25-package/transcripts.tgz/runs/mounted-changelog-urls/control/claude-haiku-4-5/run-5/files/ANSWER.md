# Mounting changelog outside `/docs/`

## The single `leadtype generate` invocation

```bash
npx leadtype generate \
  --src . \
  --out public \
  --base-url https://example.com \
  --docs-dir docs \
  --docs-dir "changelog=/changelog"
```

This tells leadtype to:
1. Include the default `docs/` folder (mapped to `/docs`)
2. Include the `changelog/` folder as a second source, mounted at URL prefix `/changelog` (not `/docs/changelog`)

## What it emits for a file like `changelog/v1.mdx`

For a source file at `changelog/v1.mdx`, leadtype generates:

| Artifact | Path |
|----------|------|
| **Internal generated copy** | `public/docs/changelog/v1.md` |
| **Public mirror** | `public/changelog/v1.md` |
| **Canonical URL agents see** | `/changelog/v1` (or `https://example.com/changelog/v1` when agent reads from `llms.txt`) |

### How the mirror works

After converting all MDX to markdown and placing it under `public/docs/`, leadtype's `copyMountedMarkdownMirrors()` function copies the generated markdown files from the staging location (`public/docs/changelog/v1.md`) to the mounted URL prefix location (`public/changelog/v1.md`). This ensures:

- The file is **searchable** (agents can find it via `llms.txt`, `/llms-full.txt`, and `search-index.json`)
- The file is **served at the custom URL** (e.g., `/changelog/v1`) for both humans and agent tools making HTTP requests
- **Backlinks work correctly** because the canonical URL (`/changelog/v1`) is consistent across all artifacts

The mount configuration creates a `DocsPathMount` entry: `{ pathPrefix: "changelog", urlPrefix: "/changelog" }`, which is passed through every generation phase (llms.txt, search index, agent readability manifests, etc.) so all references stay aligned.
