# Serving Changelog at `/changelog/...` with Searchability

## The Single `leadtype generate` Invocation

To serve the changelog under `/changelog/...` instead of `/docs/changelog/...` while keeping it searchable, run:

```bash
npx leadtype generate --src . --out public --base-url https://example.com --docs-dir docs --docs-dir changelog=/changelog
```

Or equivalently in a build script:

```bash
leadtype generate --docs-dir docs --docs-dir changelog=/changelog
```

## What Gets Emitted

For a file like `changelog/v1.mdx`, the pipeline emits three artifacts:

### 1. **Internal Generated Copy** (canonical source)
- **Path**: `public/docs/changelog/v1.md`
- **Role**: The authoritative markdown version in the `/docs/` staging area; used as the source for all agent-readable bundles and search indexing.

### 2. **Public Mirror** (user-facing mount)
- **Path**: `public/changelog/v1.md`
- **Role**: A copy of the generated markdown mirrored to the custom URL prefix. This is what the website serves at `/changelog/v1.md`.

### 3. **Canonical URL for Agents** (search index, llms.txt)
- **URL**: `https://example.com/changelog/v1`
- **Role**: The canonical URL that agents see in:
  - The search index (`public/docs/search-index.json`)
  - The `llms.txt` file (`public/llms.txt` and `public/docs/llms.txt`)
  - The `llms-full.txt` fallback
  - The agent readability manifest

## How Searchability Works

Both **internal** and **public** versions are searchable:

1. **Search Index**: Uses canonical URL (`/changelog/...`), so agents and search clients query at the custom URL.
2. **Markdown Mirror**: Both `/docs/changelog/v1.md` and `/changelog/v1.md` exist and are indexed; clients can fetch either.
3. **No Content Duplication**: The conversion (MDX → markdown) happens once; mirrors are copies only.
4. **Unified Context**: `llms.txt` and `llms-full.txt` list changelog pages under `/changelog/`, making the custom mount path the primary reference for agents.

## Configuration Details

The `<dir>=<url-prefix>` syntax:
- **Left side** (`changelog`): Source folder relative to `--src`
- **Right side** (`/changelog`): URL prefix for the public mirror and agent-facing links
- Must not be the root (`/`) and must differ from other mounted prefixes
- Repeatable: add multiple `--docs-dir` flags to merge separate source folders with different URL mounts

The first `--docs-dir` (or default `docs`) is assumed to use the standard `/docs/` mount unless explicitly overridden.
