# Serving changelog under `/changelog/...` with leadtype

## The Command

```bash
npx leadtype generate --src . --out public --base-url https://your-domain.com --docs-dir docs --docs-dir changelog=/changelog
```

This single invocation achieves your goal:
- The first `--docs-dir docs` handles regular documentation
- The second `--docs-dir changelog=/changelog` mounts the `changelog/` folder outside `/docs` so it's served under `/changelog/...`
- The changelog pages are searchable because they're all processed through the same `leadtype generate` pipeline

## What Gets Emitted for `changelog/v1.mdx`

### 1. **Internal Generated Copy** (staging)
```
public/docs/changelog/v1.md
```
This is the MDX-to-markdown conversion created in the standard docs staging directory during the conversion phase. It's an internal working copy used for building search indices and mirrors.

### 2. **Public Mirror** (canonical output)
```
public/changelog/v1.md
```
After conversion, leadtype mirrors the staged markdown file from `public/docs/changelog/v1.md` to the mount point at `public/changelog/v1.md`. This is where agents and HTTP clients fetch the page.

### 3. **Canonical URL Agents See**
```
https://your-domain.com/changelog/v1
```
In `llms.txt`, search indices, and other agent-readable artifacts, the canonical URL is `/changelog/v1` (not `/docs/changelog/v1`). This ensures agents discover and reference the changelog pages at the correct public path.

## Key Points

- **Why it works**: The `--docs-dir <dir>=<url-prefix>` syntax tells leadtype to mount a source folder at a custom URL prefix instead of under `/docs`
- **Searchability**: Both the docs and changelog are converted and indexed in the same pipeline, so changelog pages appear in `search-index.json` with correct URLs under `/changelog`
- **Merge semantics**: Using `--docs-dir` twice merges both folders into a single virtual docs tree during processing
- **Path prefixing**: Frontmatter, navigation, and internal link generation all respect the custom mount path, so cross-references work correctly
