# Serving `changelog/` under `/changelog/...`

## 1. The command

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

Key bits:

- `--docs-dir` is repeatable; the **first** entry is the primary source and
  becomes the unprefixed `/docs` root.
- The `<dir>=<url-prefix>` form on the second `--docs-dir` mounts the
  `changelog/` folder at a custom public URL prefix (`/changelog`) instead of
  the default fallback (`/docs/changelog`).
- Search, `llms.txt`, `llms-full.txt`, sitemap, and the agent‑readability
  manifest are all generated with this mount taken into account, so changelog
  pages remain searchable and discoverable by agents.

(If you'd rather declare this in `leadtype.config.ts`, the equivalent is two
`collections` — one with `dir: "docs"`, one with `dir: "changelog"` and
`prefix: "/changelog"` — and you drop the `--docs-dir` flags.)

## 2. What gets emitted for `changelog/v1.mdx`

leadtype always **stages** every source under a single canonical
`docs/<mountPath>/...` tree inside the output directory, then **mirrors** any
source whose URL prefix isn't the default `/docs/<mountPath>` to its custom
public location. Concretely, given `changelog/v1.mdx`:

| Artifact | Path |
| --- | --- |
| Internal generated copy (canonical staging) | `public/docs/changelog/v1.md` |
| Public mirror (what `/changelog/v1` is served from) | `public/changelog/v1.md` |
| Canonical URL agents see (in `llms.txt`, search index, sitemap, agent‑readability manifest) | `https://example.com/changelog/v1` |

Both copies are byte-identical Markdown produced from the same MDX conversion;
the mirror is a copy, not a separate render. The internal `public/docs/changelog/`
copy is what lets the standard docs route handler resolve the page if anything
still asks for it by its staging slug — but every emitted link, sitemap entry,
and search hit uses the mounted `/changelog/...` URL.
