# Mounting Changelog Under `/changelog/...` with Leadtype

## The Single `leadtype generate` Invocation

```bash
npx leadtype generate \
  --src . \
  --out public \
  --docs-dir docs \
  --docs-dir "changelog=/changelog" \
  --base-url https://example.com \
  --name "My Product" \
  --summary "Product documentation"
```

The key is the second `--docs-dir` with the `<dir>=<url-prefix>` syntax:
- `changelog` is the source directory (relative to `--src`)
- `/changelog` is the **canonical public URL prefix** where these files are served

## What Gets Emitted for `changelog/v1.mdx`

Leadtype processes this in three layers:

### 1. **Internal Generated Copy** → `public/docs/changelog/v1.md`
- The source file `changelog/v1.mdx` is converted to markdown
- Stored under `docs/changelog/` in the staging directory alongside all other converted docs
- This is the working copy used for search indexing and agent-facing manifests

### 2. **Public Mirror** → `public/changelog/v1.md`
- Leadtype's `copyMountedMarkdownMirrors` function detects that this file's mount has a **custom `urlPrefix`** (`/changelog` instead of the default `/docs/changelog`)
- Creates a public mirror by copying the converted markdown from `docs/changelog/` to `changelog/`
- This is what **HTTP agents fetch** when requesting `/changelog/v1.md` with `Accept: text/markdown`

### 3. **Canonical URL** → `/changelog/v1`
- Both agent-facing indexes (`/llms.txt`, `/docs/llms.txt`, `/docs/search-index.json`, `/agent-readability.json`)
- Internal search and navigation structures
- All reference this page with the canonical URL `/changelog/v1` (without file extension)
- Agents reading search results, navigation trees, or `llms.txt` see the correct mount point

## Key Mechanics

The `--docs-dir <dir>=<url-prefix>` syntax works via:

1. **Path prefix inference**: `resolveDocsSources()` extracts the mount path from the directory name (`changelog`) when not provided explicitly
2. **URL prefix override**: When you specify `changelog=/changelog`, the explicit `/changelog` overrides the default `/docs/changelog`
3. **Two-layer output**:
   - Staging: All converted markdown lives under `docs/` regardless of source directory
   - Mirroring: Files with non-default mounts get copied to their target URL prefix in the output directory
4. **Search/nav awareness**: Both the search index and navigation builders receive the `mounts` array containing `{ pathPrefix: "changelog", urlPrefix: "/changelog" }`, so they always emit the correct canonical URLs

## Example Layout

```
public/
  docs/
    llms.txt                          # References /changelog/v1
    search-index.json                 # Indexed with /changelog/v1
    agent-readability.json            # Lists canonical /changelog/v1
    docs/                             # Auto-generated subdir
      llms.txt                        # Curated docs index
    changelog/v1.md                   # Internal copy (working file)
  changelog/
    v1.md                             # Public mirror (served at /changelog/v1.md)
  llms.txt                            # Root index
```

**Result**: Agents and HTTP clients see `/changelog/v1` as the canonical URL, fetch markdown from `/changelog/v1.md`, and find it listed in all agent-facing indexes—all while keeping the internal file organization clean.
