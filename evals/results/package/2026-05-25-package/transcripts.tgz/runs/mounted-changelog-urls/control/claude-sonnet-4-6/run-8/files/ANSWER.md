# Serving `changelog/` under `/changelog/` with `leadtype generate`

## 1. The single invocation

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

The key mechanism is the **`<dir>=<url-prefix>` form** of `--docs-dir`. Passing
`changelog=/changelog` tells leadtype to:

- read source MDX from `./changelog/` (relative to `--src`), and
- mount those pages at the URL prefix `/changelog` instead of the default
  `/docs/changelog`.

Both `--docs-dir` flags are processed together. The first source (`docs`) uses
the implicit default prefix `/docs`. The second source (`changelog=/changelog`)
uses the explicit prefix `/changelog`. Every source participates in the same
`convertAllMdx` pass and the same search-index build, so changelog pages are
fully searchable alongside docs pages.

> **Constraint enforced by the CLI parser** (`parseDocsSourceInput` /
> `normalizeUrlPrefix`): the URL prefix must not be the bare site root (`/`),
> and both the directory and the prefix parts must be non-empty strings. `/changelog`
> satisfies both requirements.

---

## 2. What the pipeline emits for `changelog/v1.mdx`

### Step 1 — source mirror staging

Because two `--docs-dir` entries are present, `createSourceMirror` copies both
source trees into a shared temporary `docs/` directory before processing:

| Source file | Staged path in temp dir |
|---|---|
| `docs/**` | `<tmp>/docs/<relative-path>` |
| `changelog/v1.mdx` | `<tmp>/docs/changelog/v1.mdx` |

The `changelog` source is mounted with `mountPath = "changelog"` (derived from
the folder name, which is the part of the input before `=`).

### Step 2 — MDX → Markdown conversion (`convertAllMdx`)

`convertAllMdx` reads every `**/*.mdx` under the staged `docs/` directory and
writes `.md` files to `public/docs/`, preserving the relative path:

| Staged source | Internal generated copy |
|---|---|
| `<tmp>/docs/changelog/v1.mdx` | `public/docs/changelog/v1.md` |

This is the **canonical internal copy** — it lives under `public/docs/` because
that is where `convertAllMdx` always writes (it is called with
`outDir = path.join(outDir, "docs")`).

### Step 3 — public mirror copy (`copyMountedMarkdownMirrors`)

After conversion, `copyMountedMarkdownMirrors` compares each mount's
`urlPrefix` against the default URL that mount would have received
(`/docs/changelog` for `mountPath = "changelog"`). Because the configured
`urlPrefix` is `/changelog` — different from the default `/docs/changelog` — a
mirror copy is made:

| Internal generated copy | Public mirror copy |
|---|---|
| `public/docs/changelog/v1.md` | `public/changelog/v1.md` |

The function computes `outputDirForUrlPrefix(outDir, "/changelog")` →
`public/changelog`, then copies every `*.md` found under
`public/docs/changelog/` into that tree.

### Step 4 — canonical URL seen by agents

The `toDocsUrlPath` function resolves relative paths against the mount table.
For a file whose staged relative path is `changelog/v1.mdx` and whose mount
maps `pathPrefix = "changelog"` → `urlPrefix = "/changelog"`:

1. The mount is matched (`normalizedPath.startsWith("changelog/")`).
2. The mounted-relative portion is `v1` (after stripping the `changelog/` prefix).
3. The final URL path is `urlPrefix + "/" + mountedRelativePath` =
   **`/changelog/v1`**.

With `--base-url https://example.com` that becomes the absolute URL
**`https://example.com/changelog/v1`**.

This URL appears in every agent-facing artifact:

| Artifact | Entry for `changelog/v1.mdx` |
|---|---|
| `public/llms.txt` | product summary (links all pages) |
| `public/docs/llms.txt` | curated navigation map → `/changelog/v1.md` mirror URL |
| `public/llms-full.txt` | full-context block with `URL: https://example.com/changelog/v1` |
| `public/docs/search-index.json` | BM25 chunk with `urlPath: "/changelog/v1"` |
| `public/docs/agent-readability.json` | page entry with `urlPath`, `markdownUrlPath: "/changelog/v1.md"` |
| `public/docs/sitemap.xml` / `sitemap.md` | `https://example.com/changelog/v1` |

### Summary table

| What | Path / URL |
|---|---|
| Source file | `changelog/v1.mdx` |
| Staged (temp) | `<tmp>/docs/changelog/v1.mdx` |
| Internal generated copy | `public/docs/changelog/v1.md` |
| Public mirror copy | `public/changelog/v1.md` |
| Canonical URL (agents) | `https://example.com/changelog/v1` |
