# Serving Changelog Under `/changelog/` with Searchability

## The CLI Invocation

To serve changelog pages under `/changelog/...` instead of `/docs/changelog/...` while keeping them searchable, run:

```bash
npx leadtype generate --src . --docs-dir docs --docs-dir changelog=/changelog --out public --base-url https://your-site.com
```

### Breakdown

- `--docs-dir docs` — include the main `docs/` folder (mounted at `/docs` by default)
- `--docs-dir changelog=/changelog` — mount the `changelog/` folder at the **site root URL prefix `/changelog`** (not nested under `/docs`)
- `--base-url https://your-site.com` — set the base URL for absolute links and search index

The `<dir>=<url-prefix>` syntax is the key: it decouples the source directory from its URL prefix.

---

## What Gets Emitted

For a source file like `changelog/v1.mdx`:

### 1. **Internal Generated Copy** (staging)
- **Location:** `public/docs/changelog/v1.md`
- **Purpose:** Intermediate build artifact where MDX is converted to markdown. All markdown mirrors are initially generated here.

### 2. **Public Mirror** (canonical location)
- **Location:** `public/changelog/v1.md`
- **Purpose:** The publicly served markdown file that HTTP agents and documentation sites fetch. This is created by copying from the internal generated copy.

### 3. **Canonical URL (Agents See)**
- **URL Path:** `/changelog/v1`
- **Full URL:** `https://your-site.com/changelog/v1`
- **In `llms.txt`:** Listed under the `/changelog` mount with this canonical URL
- **In Search Index:** Indexed with this URL as the source-of-truth

### Search Integration

- The page is **included in** `public/search-index.json` under the canonical URL `/changelog/v1`
- The search index is built from the markdown generated in `public/docs/`, but URLs in the index point to their mounted locations
- When agents or search clients query, they receive results pointing to `/changelog/v1`, not `/docs/changelog/v1`
- The page also appears in `public/llms.txt` and sectioned appropriately based on mount metadata

---

## How It Works Internally

1. **Merging sources:** Both `docs/` and `changelog/` are temporarily copied into a unified staging directory (both under the `docs/` subdirectory internally)
2. **URL resolution:** Each source is tagged with its mount path and URL prefix:
   - `docs/` → mount path: `""` → URL prefix: `/docs`
   - `changelog/` → mount path: `changelog` → URL prefix: `/changelog`
3. **Markdown conversion:** All `.mdx` files are converted to `.md` in the staging tree, preserving the folder structure
4. **Public mirror copy:** After conversion, markdown files are copied from `public/docs/changelog/` to `public/changelog/` to match the public-facing URL structure
5. **Search & navigation:** URLs in the search index and navigation are rewritten to match the mounted prefixes

---

## Key Points

- **Searchability:** ✅ Fully searchable via the unified search index
- **Navigation:** ✅ Agents see the canonical `/changelog/v1` URL in `llms.txt` and search results
- **Agents/LLMs:** ✅ When reading docs from `Accept: text/markdown`, they fetch from `/changelog/v1.md`
- **No duplicate indexing:** The page is indexed once, under its canonical URL only
- **Flexibility:** You can mount multiple source folders to different URL prefixes: `--docs-dir docs --docs-dir changelog=/changelog --docs-dir api-ref=/api`
