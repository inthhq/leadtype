# Serving `changelog/` under `/changelog/` with `leadtype generate`

## 1. The single `leadtype generate` invocation

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

The key is the second `--docs-dir` flag, which uses the `<dir>=<url-prefix>` mount
syntax:

```
--docs-dir changelog=/changelog
```

This tells leadtype to read source files from the `changelog/` folder beside
`docs/` and to serve their converted output at the `/changelog/…` URL prefix
**instead of** the default `/docs/changelog/…`.

---

## 2. What leadtype emits for `changelog/v1.mdx`

### Step 1 — source mount resolution

The CLI calls `resolveDocsSources` with two entries:

| input      | `mountPath` | resolved `urlPrefix` |
|------------|-------------|----------------------|
| `docs`     | `""`        | `/docs`              |
| `changelog`| `changelog` | `/changelog`         |

Because the `changelog=/changelog` entry supplies an explicit URL prefix that
does **not** start with `/docs/`, `copyMountedMarkdownMirrors` knows it needs
to mirror the converted files out of the internal `public/docs/changelog/`
staging area into a separate `public/changelog/` tree.

### Step 2 — internal generated copy (staging)

`convertAllMdx` is called with

```
srcDir  = <tmp>/docs          (merged staging copy of both source folders)
outDir  = public/docs
```

`deriveOutputPath` preserves the sub-path relative to `srcDir`, so
`changelog/v1.mdx` is written as:

```
public/docs/changelog/v1.md   ← internal / staging copy
```

This file is **not** intended to be served directly. It exists so that every
subsequent pipeline step (search index, `llms.txt`, `llms-full.txt`,
`agent-readability.json`) can read markdown files from the flat `public/docs/`
tree using a single glob, regardless of their public URL.

### Step 3 — public mirror

After conversion, `copyMountedMarkdownMirrors` detects that the `changelog`
mount's `urlPrefix` (`/changelog`) differs from the default expected prefix for
its `pathPrefix` (`/docs/changelog`). It copies every `*.md` file from the
staging directory to the URL-aligned output path:

```
public/changelog/v1.md        ← public mirror, served at /changelog/v1.md
```

This is the file your web server (Next.js, Astro, Nginx, Cloudflare Pages, …)
must serve when a browser or HTTP agent requests `/changelog/v1.md` or uses an
`Accept: text/markdown` header on `/changelog/v1`.

### Step 4 — canonical URL that agents see

The `urlPath` recorded in the search index (`public/docs/search-index.json`),
`agent-readability.json`, `llms.txt`, and every `markdownUrlPath` reference is
derived by `toDocsUrlPath` using the mount table:

```
urlPath          = /changelog/v1
markdownUrlPath  = /changelog/v1.md
absoluteUrl      = https://example.com/changelog/v1
```

Agents reading `public/llms.txt`, `public/docs/agent-readability.json`, or the
search index will therefore discover `changelog/v1.mdx` under
`https://example.com/changelog/v1` — never under `/docs/changelog/v1`.

### Summary table

| Artifact | Path on disk | Public URL / canonical |
|---|---|---|
| Internal converted copy (pipeline input) | `public/docs/changelog/v1.md` | not served directly |
| Public markdown mirror (agent-readable) | `public/changelog/v1.md` | `/changelog/v1.md` |
| Canonical HTML URL | — | `/changelog/v1` |
| Search index entry (`urlPath`) | inside `public/docs/search-index.json` | `/changelog/v1` |
| `markdownUrlPath` in `agent-readability.json` | — | `/changelog/v1.md` |
| `absoluteUrl` (with `--base-url`) | — | `https://example.com/changelog/v1` |
