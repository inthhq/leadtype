# Answer

```bash
leadtype generate --src . --docs-dir docs --docs-dir changelog=/changelog --out public --base-url https://your-site.example
```

Replace `https://your-site.example` with the site's real origin.

For `changelog/v1.mdx`, the second `--docs-dir` mounts the source folder at the generated staging path `changelog/` but assigns it the public URL prefix `/changelog`:

- Internal generated copy: `public/docs/changelog/v1.md`
- Public mirror: `public/changelog/v1.md`, served as `/changelog/v1.md` instead of `/docs/changelog/v1.md`
- Canonical page URL in agent-facing outputs/search metadata: `https://your-site.example/changelog/v1` (or `/changelog/v1` as the path)

The page is still included in the normal site-mode search artifacts (`public/docs/search-index.json` and `public/docs/search-content.json`), with its mounted `/changelog/...` URL.