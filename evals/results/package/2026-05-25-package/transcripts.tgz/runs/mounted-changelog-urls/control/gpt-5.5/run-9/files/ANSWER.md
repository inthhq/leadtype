# Answer

```bash
leadtype generate --src . --out public --base-url https://your-site.example --docs-dir docs --docs-dir changelog=/changelog
```

Keep `docs` first: the first source is the normal `/docs` mount. The second `--docs-dir` value uses the `<dir>=<url-prefix>` form, so the sibling `changelog/` source is mounted at `/changelog` instead of the default `/docs/changelog`.

For a source file such as `changelog/v1.mdx`, site-mode generation does this:

- **Internal generated copy:** it stages the extra source under the generated docs tree and converts it to `public/docs/changelog/v1.md`.
- **Public mirror:** because the mount prefix is `/changelog`, leadtype mirrors that markdown to `public/changelog/v1.md`, which is the path your site should serve for markdown-aware agents.
- **Canonical URL agents see:** mounted URL resolution maps the staged relative path `changelog/v1.md` to `/changelog/v1` (absolute: `https://your-site.example/changelog/v1` with the `--base-url` above). Agent/readability artifacts and the search documents use that mounted URL, not `/docs/changelog/v1`; markdown links point at `/changelog/v1.md`.

The default site-mode command also emits the search artifacts (for example under `public/docs/search-index.json` / `search-content.json`), and those include the changelog page with the `/changelog/...` URL.
