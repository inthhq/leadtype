# Serving `changelog/` under `/changelog/` with `leadtype generate`

## 1. The single invocation

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

### Why this works

`--docs-dir` accepts the syntax `<dir>=<url-prefix>`. Repeating the flag
mounts multiple source folders into one pipeline:

| `--docs-dir` value    | Source folder | URL prefix    |
|-----------------------|---------------|---------------|
| `docs`                | `./docs`      | `/docs`       |
| `changelog=/changelog`| `./changelog` | `/changelog`  |

leadtype copies both source trees into a shared temporary staging directory,
flattens all MDX files to Markdown, and then — because `changelog`'s URL
prefix (`/changelog`) differs from the default docs prefix (`/docs/changelog`)
— **mirrors** the generated Markdown files from `public/docs/changelog/` to
`public/changelog/`. The search index is built from the merged set of pages,
so changelog content is fully searchable alongside the regular docs.

---

## 2. What gets emitted for `changelog/v1.mdx`

### Step 1 — Internal generated copy (under `public/docs/`)

During MDX-to-Markdown conversion, leadtype processes the changelog source
tree just like it does the main `docs/` tree, writing output relative to a
`changelog` path-prefix mount inside its staging area.  The converted
Markdown lands at:

```
public/docs/changelog/v1.md
```

This is the **internal** artifact.  The search indexer (`search-index.json`)
and the LLM full-context file (`llms-full.txt`) read from `public/docs/` and
therefore pick up `public/docs/changelog/v1.md` automatically — changelog
pages are included in both.

### Step 2 — Public mirror (under `public/changelog/`)

After conversion, `copyMountedMarkdownMirrors` detects that the `changelog`
mount has a custom URL prefix (`/changelog`) that diverges from the default
expected prefix (`/docs/changelog`).  It therefore copies every `*.md` file
from the internal location to the public-facing location:

```
public/changelog/v1.md     ← public mirror, served at /changelog/v1.md
```

Your web framework serves `public/changelog/v1.md` directly from
`/changelog/v1.md` (HTTP with `Accept: text/markdown`) and renders the page
at `/changelog/v1` (HTML).

### Step 3 — Canonical URL seen by agents

The `toDocsUrlPath` function maps the relative path `changelog/v1.mdx`
through the mount table.  Because the `changelog` path-prefix mount resolves
to the `/changelog` URL prefix, the canonical URL path becomes:

```
/changelog/v1
```

With `--base-url https://example.com` that expands to the absolute URL:

```
https://example.com/changelog/v1
```

This is the URL recorded in every agent-facing artifact:

| Artifact | Entry for `changelog/v1.mdx` |
|---|---|
| `public/llms.txt` | `https://example.com/changelog/v1` |
| `public/llms-full.txt` | full content block under `URL: https://example.com/changelog/v1` |
| `public/docs/search-index.json` | `urlPath: "/changelog/v1"`, `absoluteUrl: "https://example.com/changelog/v1"` |
| `public/docs/agent-readability.json` | `urlPath: "/changelog/v1"`, `markdownUrlPath: "/changelog/v1.md"` |

The page is therefore served at `/changelog/v1` (not `/docs/changelog/v1`),
its Markdown mirror is at `/changelog/v1.md`, and every agent that consults
`llms.txt`, `llms-full.txt`, the search index, or the agent-readability
manifest will see the `/changelog/v1` canonical URL — never the internal
`/docs/changelog/v1` path.
