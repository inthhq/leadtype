# Answer

Use site mode and mount the sibling `changelog/` source with an explicit URL prefix:

```bash
leadtype generate --src . --out public --base-url https://YOUR_SITE --docs-dir docs --docs-dir changelog=/changelog
```

Replace `https://YOUR_SITE` with the site's real origin. The important part is the repeated `--docs-dir`: the normal docs stay mounted at `/docs`, while `changelog/` is mounted at `/changelog` instead of the default secondary-source URL `/docs/changelog`.

For a source file such as:

```text
changelog/v1.mdx
```

leadtype treats it as a mounted secondary source:

- Internal generated markdown copy: `public/docs/changelog/v1.md`
  - The file is staged under the generated docs tree so the normal conversion, `llms-full.txt`, readability artifacts, and search generation can all process it.
- Public markdown mirror: `public/changelog/v1.md`
  - Because the mount URL prefix is `/changelog`, leadtype mirrors the generated markdown out from `public/docs/changelog/...` to `public/changelog/...`.
- Canonical page URL used by agents/search: `https://YOUR_SITE/changelog/v1`
  - The markdown URL advertised for direct agent-readable markdown is `https://YOUR_SITE/changelog/v1.md`.
  - It is not canonicalized as `https://YOUR_SITE/docs/changelog/v1`.

The search index is still emitted in the normal site output under `public/docs/search-index.json` (plus `public/docs/search-content.json`), and the changelog page is included there with its mounted URL path `/changelog/v1`.
