# Serving `changelog/` at `/changelog/…` with `leadtype generate`

## 1. The single `leadtype generate` invocation

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

### Why this works — the `<dir>=<url-prefix>` syntax

`--docs-dir` accepts the form `<dir>=<url-prefix>`.  
The CLI's `parseDocsSourceInput` function splits the value on the first `=`:

- **`docs`** → source directory `docs/`, default URL prefix `/docs` (first source, so `mountPath = ""`).
- **`changelog=/changelog`** → source directory `changelog/`, URL prefix `/changelog` (second source, so `mountPath = "changelog"`).

The two sources are merged into a temporary staging tree:

```
<tmp>/docs/          ← pages from docs/
<tmp>/docs/changelog/ ← pages from changelog/
```

`convertAllMdx` runs against that staging tree and writes `.md` files to
`public/docs/` and `public/docs/changelog/` respectively.

After conversion, `copyMountedMarkdownMirrors` inspects the mounts. For the
second mount (`pathPrefix = "changelog"`, `urlPrefix = "/changelog"`) it sees
that `/changelog` differs from the default `/docs/changelog` it would infer,
so it copies every `.md` file from `public/docs/changelog/` to
`public/changelog/`.

Search indexing, `llms.txt`, `llms-full.txt`, and the agent-readability
artifacts are all generated with the same `mounts` array, so the
changelog pages are included in the search index and agent discovery files
alongside the regular docs pages.

---

## 2. What is emitted for `changelog/v1.mdx`

### Step 1 — conversion (internal generated copy)

`changelog/v1.mdx` is staged at:

```
<tmp>/docs/changelog/v1.mdx
```

`convertAllMdx` flattens it to Markdown and writes:

```
public/docs/changelog/v1.md          ← internal generated copy
```

This file holds the fully-resolved Markdown (MDX components stripped,
frontmatter normalised, includes expanded). It is the source of truth consumed
by search indexing and `llms-full.txt`.

### Step 2 — public mirror (what the web server serves)

`copyMountedMarkdownMirrors` copies the file to the mounted URL prefix path:

```
public/changelog/v1.md               ← public mirror
```

This is the file a docs framework (Next.js, Astro, etc.) or an HTTP client
using `Accept: text/markdown` fetches when it requests `/changelog/v1.md`.

### Step 3 — canonical URL seen by agents

The canonical URL path is derived by `toDocsUrlPath`:

1. The relative staging path is `changelog/v1`.
2. The mount `{ pathPrefix: "changelog", urlPrefix: "/changelog" }` is matched.
3. The mounted-relative path is `v1`.
4. The result is `/changelog/v1`.

With `--base-url https://example.com` the absolute canonical URL becomes:

```
https://example.com/changelog/v1
```

This is the URL written into `llms.txt`, `llms-full.txt`, `sitemap.md`,
`sitemap.xml`, and the search index — what coding agents and crawlers resolve
when they follow the discovery chain starting at `/llms.txt`.

### Summary table

| Artefact | Location on disk | URL |
|---|---|---|
| Internal generated copy | `public/docs/changelog/v1.md` | *(not directly served)* |
| Public Markdown mirror | `public/changelog/v1.md` | `/changelog/v1.md` |
| Canonical URL (agents) | — | `https://example.com/changelog/v1` |
