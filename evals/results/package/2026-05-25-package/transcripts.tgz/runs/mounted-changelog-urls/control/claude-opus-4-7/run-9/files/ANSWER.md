# Mounting `changelog/` at `/changelog`

## 1. The command

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

The relevant flag is `--docs-dir`, which the CLI help describes as:

> Docs source folder relative to `--src` (default: `docs`). Repeat to merge multiple folders.
> Use `<dir>=<url-prefix>` to mount a source outside `/docs`, e.g. `changelog=/changelog`.

A few details worth pinning down:

- The **first** `--docs-dir` becomes the unprefixed source. Its content lands directly under `public/docs/...` with canonical URLs like `/docs/quickstart`. We pass `--docs-dir docs` explicitly only because once you pass `--docs-dir` at all, the implicit `docs` default is gone — you have to name it.
- The **second** `--docs-dir changelog=/changelog` says: read MDX from `./changelog/`, but expose it under the URL prefix `/changelog`, not the default `/docs/changelog`.
- Replace `--base-url` with whatever your real site origin is; it's what gets baked into `llms.txt`, `llms-full.txt`, the sitemap, and the search index.

## 2. What gets emitted for `changelog/v1.mdx`

Internally, leadtype always stages every source under a single `docs/` tree before conversion. Non-default sources get mounted at a subfolder matching the source's basename (`changelog`). Then, because we asked for a non-default URL prefix, a **mirror** is copied to that prefix at the output root.

For `changelog/v1.mdx` you therefore end up with:

| Role | Path on disk | Notes |
| --- | --- | --- |
| Internal generated copy (staging output) | `public/docs/changelog/v1.md` | Always written. This is the canonical on-disk artifact and the path the search index / `llms.txt` machinery reads from. |
| Public mirror (what the site serves) | `public/changelog/v1.md` | Copied from the internal location by leadtype's `copyMountedMarkdownMirrors` step, because the requested URL prefix (`/changelog`) differs from the default expected prefix (`/docs/changelog`). |
| Canonical URL agents see | `https://example.com/changelog/v1` | Used in `llms.txt`, `llms-full.txt`, `sitemap.xml`, `agent-readability.json`, and the search index entry. The `.md` companion URL is `https://example.com/changelog/v1.md`. |

What this gives you in practice:

- Humans hitting `https://example.com/changelog/v1` (HTML) and HTTP agents hitting `https://example.com/changelog/v1.md` both resolve under `/changelog/...`, never `/docs/changelog/...`.
- `public/docs/changelog/v1.md` still exists, but it's an implementation detail of the build — your web server can ignore or hide that subtree. The mirror at `public/changelog/v1.md` is the one your routing should expose.
- Search picks up changelog pages exactly like docs pages, indexing them under their canonical `/changelog/...` URLs, so `--docs-dir changelog=/changelog` keeps them fully searchable.
- The MDX in `changelog/` participates in the same pipeline (frontmatter validation, remark plugins, group inference) as `docs/`, so no separate config is required to get a `v1.mdx` page into the search index.
