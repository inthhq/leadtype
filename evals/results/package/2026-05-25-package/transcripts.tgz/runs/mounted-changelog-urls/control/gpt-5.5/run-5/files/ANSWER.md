# Answer

Use `--docs-dir` twice: keep the normal docs tree mounted at `/docs`, and mount the sibling changelog tree at `/changelog`.

```sh
leadtype generate --src . --out public --base-url https://YOUR-SITE.example --docs-dir docs --docs-dir changelog=/changelog
```

For `changelog/v1.mdx`, leadtype stages the second source under the docs output namespace, then mirrors it to the requested public mount:

- Internal generated markdown copy: `public/docs/changelog/v1.md`
- Public markdown mirror: `public/changelog/v1.md`
- Canonical page URL used in generated agent/search metadata: `/changelog/v1` (or `https://YOUR-SITE.example/changelog/v1` where absolute URLs are emitted)

Because the changelog source is part of the same generate run, its markdown is included in the generated search files (`public/docs/search-index.json` and `public/docs/search-content.json`) with that `/changelog/v1` URL, rather than `/docs/changelog/v1`.
