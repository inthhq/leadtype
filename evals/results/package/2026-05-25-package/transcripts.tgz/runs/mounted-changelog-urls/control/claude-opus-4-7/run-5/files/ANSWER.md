# Mounting `changelog/` at `/changelog/...`

`leadtype generate` accepts repeated `--docs-dir` flags, and each one can be
written as `<dir>=<url-prefix>` to mount that source at an arbitrary URL prefix
instead of the default `/docs/<dir>`.

## 1. The command

```bash
npx leadtype generate \
  --src . \
  --out public \
  --base-url https://example.com \
  --docs-dir docs \
  --docs-dir changelog=/changelog
```

Notes on the flags:

- The **first** `--docs-dir` is the primary source. It mounts at the
  conventional `/docs` prefix and its files land at the root of the docs
  staging area (no extra path segment).
- Every **subsequent** `--docs-dir` is mounted under a sub-path. Without
  `=<url-prefix>` it would default to `/docs/changelog`. The `=/changelog`
  override moves the public URL prefix to the site root (`/changelog`) while
  the source folder name (`changelog`) is still used as the *internal* mount
  segment so the two sources can't collide.
- `--base-url` is what lets `llms.txt`, `llms-full.txt`, `sitemap.xml`, and
  `search-index.json` emit absolute canonical URLs.

If you'd rather encode this in `leadtype.config.{ts,js}`, the equivalent is a
`collections` entry whose `prefix` is `/changelog` — but you cannot mix
`collections` with CLI `--docs-dir`, so pick one.

## 2. What it emits for `changelog/v1.mdx`

Given the input `./changelog/v1.mdx`, leadtype produces three things:

| Role | Path / URL | Who reads it |
| --- | --- | --- |
| **Internal generated copy** (staging mirror under `/docs`) | `public/docs/changelog/v1.md` | The pipeline itself — `llms.txt`, `llms-full.txt`, `search-index.json`, and `agent-readability.json` are all assembled by walking `public/docs/**`. This file is the source of truth on disk. |
| **Public mirror at the mounted prefix** | `public/changelog/v1.md` | HTTP agents fetching with `Accept: text/markdown`. `copyMountedMarkdownMirrors` notices that the configured `urlPrefix` (`/changelog`) differs from the default (`/docs/changelog`) and copies every `*.md` from `public/docs/changelog/` into `public/changelog/` so the URL `https://example.com/changelog/v1.md` resolves to the same content. |
| **Canonical URL agents see** | `https://example.com/changelog/v1` | This is the URL written into `llms.txt`, `llms-full.txt`, `sitemap.xml`/`sitemap.md`, `search-index.json`, `search-content.json`, and `agent-readability.json`. The mount table passed to `toDocsUrlPath` rewrites any path under the `changelog` source from `/docs/changelog/v1` to `/changelog/v1`, so nothing in the agent-facing artifacts ever references `/docs/changelog`. |

Net result: humans land on `https://example.com/changelog/v1` (your UI
renders the page), HTTP/agent clients hit `https://example.com/changelog/v1.md`
for the flattened markdown, the static search index lists the page under
`/changelog/v1` so it stays fully searchable, and the `/docs/changelog/...`
copy exists only as an internal staging artifact you can ignore (or strip
from your deploy) — it is never advertised in any generated index.
