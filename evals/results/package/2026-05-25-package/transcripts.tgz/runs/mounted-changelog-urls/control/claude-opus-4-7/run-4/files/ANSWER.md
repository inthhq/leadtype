# Mounting `changelog/` at `/changelog` with `leadtype generate`

## 1. The command

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

What's going on:

- `--docs-dir docs` keeps your regular docs at the default `/docs` URL
  prefix.
- `--docs-dir changelog=/changelog` is the key bit. The
  `<dir>=<url-prefix>` form of `--docs-dir` (see `leadtype generate --help`)
  mounts a second source folder. The folder name (`changelog`) becomes its
  internal staging path; the `=/changelog` half overrides what would
  otherwise have been `/docs/changelog` so the public URL lives directly
  under `/changelog/...`.
- The first `--docs-dir` always owns `/docs` and can't be remapped — only
  *additional* sources accept a custom URL prefix. That's why the two
  flags must be given in that order.

You can drop `--base-url` if you don't need absolute URLs in the
generated `llms.txt` / `llms-full.txt` / sitemap, but the routing
behavior is identical either way.

## 2. What gets emitted for `changelog/v1.mdx`

For a single source file:

```
changelog/v1.mdx
```

`leadtype generate` produces three things:

### a. Internal generated copy (under `/docs`)

```
public/docs/changelog/v1.md
```

This is `convertAllMdx`'s canonical output. Every mounted source is
first written into the unified `public/docs/<mountPath>/...` tree so
that link resolution, navigation, frontmatter validation, and search
indexing all see one consistent layout. Don't rely on this path from
the outside — treat it as an implementation detail.

### b. Public mirror (at the requested prefix)

```
public/changelog/v1.md
```

Because the mount's `urlPrefix` (`/changelog`) doesn't match the
default it would otherwise have had (`/docs/changelog`), leadtype's
`copyMountedMarkdownMirrors` step copies the markdown subtree from
`public/docs/changelog/` to `public/changelog/`. This is what your
HTTP layer serves to agents requesting `Accept: text/markdown` at
`/changelog/v1`.

### c. Canonical URL agents see

```
https://example.com/changelog/v1
```

Everywhere a URL for this page is emitted — `public/llms.txt`,
`public/llms-full.txt`, `public/docs/search-index.json`,
`public/docs/sitemap.xml`, `public/docs/sitemap.md`, and
`public/docs/agent-readability.json` — leadtype uses the mount's URL
prefix, not the internal `/docs/changelog/...` path. The page stays in
the same BM25 search index as the rest of your docs (it's searchable
exactly like a `/docs/*` page), but every agent-facing link points at
`/changelog/v1`.

### Quick summary table

| Concern                       | Path                                          |
| ----------------------------- | --------------------------------------------- |
| Source                        | `changelog/v1.mdx`                            |
| Internal staged markdown      | `public/docs/changelog/v1.md`                 |
| Public markdown mirror        | `public/changelog/v1.md`                      |
| Canonical URL (llms / search) | `https://example.com/changelog/v1`            |
| Listed in `llms.txt`?         | Yes — under its frontmatter group             |
| In `search-index.json`?       | Yes — alongside `/docs/*` pages               |
