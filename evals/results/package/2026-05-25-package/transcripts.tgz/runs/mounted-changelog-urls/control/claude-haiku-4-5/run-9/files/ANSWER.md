# Serving Changelog Under `/changelog/...` with Full Searchability

## 1. The Command

```bash
npx leadtype generate \
  --src . \
  --out public \
  --base-url https://your-site.com \
  --docs-dir docs \
  --docs-dir 'changelog=/changelog'
```

This single invocation:
- Processes the main `docs/` folder normally (served under `/docs/...`)
- Mounts the `changelog/` folder with a custom URL prefix at `/changelog/...` instead of the default `/docs/changelog/...`
- Includes all files in the static search index (both docs and changelog are searchable)

## 2. Output Structure for `changelog/v1.mdx`

### **Internal Generated Copy** (staging)
```
public/docs/changelog/v1.md
```
This is where leadtype first converts the MDX to markdown, storing it in an internal staging directory under `/docs/changelog/` during the build process.

### **Public Mirror** (canonical output)
```
public/changelog/v1.md
```
This is the actual file served at the public URL and what agents read. The `--docs-dir 'changelog=/changelog'` flag tells leadtype to copy the markdown mirror from the staging location to this path.

### **Canonical URL for Agents**
```
https://your-site.com/changelog/v1.md
```
When agents fetch content (via `Accept: text/markdown` or similar), they get this URL. It's included in:
- `llms.txt` entries with path `/changelog/v1`
- `search-index.json` (searchable as a changelog page)
- `llms-full.txt` (if included in the default context)

## How It Works

The `<dir>=<url-prefix>` syntax in `--docs-dir`:
- **Left side (`changelog`)**: The source folder path relative to `--src`
- **Right side (`/changelog`)**: The URL prefix where files are publicly served

Without the URL prefix override, leadtype would default to mounting secondary doc sources under `/docs/<folder-name>`, resulting in `/docs/changelog/...`. The explicit `=/changelog` directive breaks out of the `/docs` hierarchy and serves at the root level instead.

Both the internal staging (`public/docs/changelog/`) and the public mirror (`public/changelog/`) are generated; the mirror is what you actually serve to clients and agents.
