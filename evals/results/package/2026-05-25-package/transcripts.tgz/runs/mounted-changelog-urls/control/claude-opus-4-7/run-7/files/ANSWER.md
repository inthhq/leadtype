# Mounting `changelog/` at `/changelog/...`

## 1. The command

```bash
npx leadtype generate \
  --src . \
  --out public \
  --base-url https://example.com \
  --docs-dir docs \
  --docs-dir changelog=/changelog
```

Key points:

- The `<dir>=<url-prefix>` form on `--docs-dir` is exactly what mounts a
  source folder outside `/docs`. The CLI help text calls this out:
  *"Use `<dir>=<url-prefix>` to mount a source outside /docs, e.g.
  changelog=/changelog."*
- `--docs-dir` must be repeated when you have more than one source. The
  **first** `--docs-dir` is treated as the canonical docs root (its
  `mountPath` is `""`), so list `docs` first and `changelog=/changelog`
  second. If you only pass `--docs-dir changelog=/changelog`, leadtype
  will mount it at the docs root and you'll lose `/docs/...`.
- Swap `--base-url` for your real site, or drop it if you don't need
  absolute URLs in `llms.txt` / sitemaps.

## 2. What gets emitted for `changelog/v1.mdx`

Internally leadtype always stages converted markdown under
`<out>/docs/<mountPath>/...` and *then*, when a source has a custom URL
prefix, it copies that subtree to the prefix as a public mirror.

For `changelog/v1.mdx` with the command above you get:

| Artifact | Path | Notes |
| --- | --- | --- |
| Internal generated copy (staging) | `public/docs/changelog/v1.md` | Always written here first — this is leadtype's canonical on-disk location for the flattened MDX. It's how `convertAllMdx` keeps a single staging tree. |
| Public mirror | `public/changelog/v1.md` | Copied by `copyMountedMarkdownMirrors` because the source's `urlPrefix` (`/changelog`) differs from the staging prefix (`/docs/changelog`). This is what your web server actually exposes at the public URL. |
| Canonical URL agents see | `https://example.com/changelog/v1` | The `mounts` array passed to `generateLlmsTxt`, `generateLLMFullContextFiles`, `generateDocsSearchFiles`, and `generateAgentReadabilityArtifacts` uses the mount's `urlPrefix`, so every link in `llms.txt`, `llms-full.txt`, `search-index.json`, `search-content.json`, `sitemap.xml`, `sitemap.md`, and `agent-readability.json` points at `/changelog/v1`, **not** `/docs/changelog/v1`. |

Because the search index is built from the mounted (`/changelog/...`)
URLs, the changelog pages remain fully searchable — they just show up
under the changelog prefix instead of the docs prefix.

Regular `docs/*.mdx` files continue to land at `public/docs/*.md` and
`https://example.com/docs/...` unchanged.
