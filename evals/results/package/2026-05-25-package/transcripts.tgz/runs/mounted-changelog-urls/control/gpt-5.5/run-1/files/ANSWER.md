# Serving `changelog/` at `/changelog`

Use site mode and mount the sibling changelog folder with an explicit URL prefix:

```bash
npx leadtype generate --src . --out public --docs-dir docs --docs-dir changelog=/changelog
```

This keeps the normal `docs/` source at `/docs/...`, but stages the sibling `changelog/` source under the internal docs tree while assigning it the public URL prefix `/changelog`.

For `changelog/v1.mdx`, the command emits:

- **Internal generated copy:** `public/docs/changelog/v1.md`
  - leadtype converts all MDX into the generated `docs/` output tree first; the second source is staged under the `changelog/` mount path there.
- **Public mirror:** `public/changelog/v1.md`
  - because the mount's URL prefix is `/changelog` rather than the default `/docs/changelog`, leadtype mirrors the generated markdown to the public URL location.
- **Canonical agent-facing page URL:** `/changelog/v1`
  - generated agent/readability/search metadata resolves the page through the mount, so agents see `/changelog/v1` as the page URL, with the markdown mirror at `/changelog/v1.md`.

The site-mode command also generates `public/docs/search-index.json` and `public/docs/search-content.json`; the changelog page is included there with its mounted URL (`/changelog/v1`), so it remains searchable.
