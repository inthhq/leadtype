# Answer

Use site mode and mount the sibling `changelog/` source explicitly:

```sh
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://your-site.example
```

Replace `https://your-site.example` with the site's real origin.

For `changelog/v1.mdx`, leadtype stages the second docs source under the generated docs tree, converts it, and then mirrors it to the mounted public prefix:

- Internal generated markdown copy: `public/docs/changelog/v1.md`
- Public mounted markdown mirror: `public/changelog/v1.md` (served as `/changelog/v1.md`)
- Canonical page URL in agent/search metadata: `/changelog/v1` (absolute form: `https://your-site.example/changelog/v1`)

The page remains searchable because the default site-mode search generation reads the internal `public/docs/...` markdown tree with the mount table applied, so the search document for that file is indexed with `urlPath` `/changelog/v1`, not `/docs/changelog/v1`.
