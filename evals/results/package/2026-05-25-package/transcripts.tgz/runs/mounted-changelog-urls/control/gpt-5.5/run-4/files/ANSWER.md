# Answer

Use two docs sources, mounting the sibling `changelog/` source at `/changelog`:

```bash
leadtype generate --src . --docs-dir docs --docs-dir changelog=/changelog --out public --base-url "$SITE_URL"
```

Replace `$SITE_URL` with the site's origin, for example `https://example.com`.

For `changelog/v1.mdx`, leadtype treats `docs/` as the normal `/docs` source and mounts `changelog/` as a second source:

- Internal generated copy: `public/docs/changelog/v1.md`
  - This is the staged/generated markdown under leadtype's internal `docs` output tree, so it is included when leadtype builds `public/docs/search-index.json` and `public/docs/search-content.json`.
- Public mirror: `public/changelog/v1.md`
  - Because the second source was declared as `changelog=/changelog`, leadtype mirrors the mounted markdown out from the internal `/docs/changelog` location to the public `/changelog` location.
- Canonical URL agents see: `$SITE_URL/changelog/v1`
  - Agent/readability metadata, sitemap/full-context URLs, and search records use `/changelog/v1`, not `/docs/changelog/v1`.
  - The markdown URL for the generated page is `$SITE_URL/changelog/v1.md`.
