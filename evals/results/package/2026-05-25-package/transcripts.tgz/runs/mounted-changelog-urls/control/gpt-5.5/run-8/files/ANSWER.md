# Answer

Use site mode with both source folders, explicitly mounting the sibling `changelog/` source at `/changelog`:

```bash
leadtype generate --src . --out public --base-url https://YOUR-SITE.example --docs-dir docs --docs-dir changelog=/changelog
```

Replace `https://YOUR-SITE.example` with the site origin you want in absolute agent/search URLs. If your build environment already provides the site URL, the important part is the repeated `--docs-dir`, especially `changelog=/changelog`.

For `changelog/v1.mdx`, leadtype treats `docs/` as the default `/docs` source and mounts `changelog/` as a second source whose staged path prefix is `changelog` but whose URL prefix is `/changelog`. The result is:

- **Internal generated copy:** `public/docs/changelog/v1.md`
  - This is the normalized/generated markdown copy under leadtype's internal `docs/` output tree.
- **Public mirror:** `public/changelog/v1.md`
  - Because the mount URL prefix is `/changelog`, leadtype mirrors the generated markdown out of `public/docs/changelog/` to the public `/changelog/` path.
- **Canonical URL agents/search see:** `https://YOUR-SITE.example/changelog/v1` (URL path `/changelog/v1`)
  - It is not canonicalized as `/docs/changelog/v1`.
  - The markdown fetch URL advertised for the mirror is `/changelog/v1.md`.
  - The page remains searchable because the search index is built from the internal generated markdown tree and applies the mount mapping, so the indexed document URL is `/changelog/v1`.
