# Serving `changelog/` at `/changelog/...`

## 1. The invocation

```bash
npx leadtype generate \
  --src . \
  --out public \
  --base-url https://example.com \
  --docs-dir docs \
  --docs-dir changelog=/changelog
```

Key points:

- `--docs-dir` is repeatable. The first one (`docs`) is the primary mount and stays at the default `/docs` URL prefix. The second one (`changelog`) is an extra source folder beside `docs/`.
- The `<dir>=<url-prefix>` syntax (called out explicitly in `leadtype generate --help`: *"Use `<dir>=<url-prefix>` to mount a source outside `/docs`, e.g. `changelog=/changelog`"*) overrides the default URL prefix that a secondary source would otherwise get (which would be `/docs/changelog`).
- `--base-url` is required for the public canonical URLs in `llms.txt`, `llms-full.txt`, `search-index.json`, and `sitemap.xml` to be absolute.

There is no flag you need to add to keep the changelog "searchable" — extra `--docs-dir` mounts participate in the search index and llms artifacts automatically, because internally they are still staged inside `public/docs/...` before being mirrored to their public URL prefix.

## 2. What `changelog/v1.mdx` produces

For an input file `./changelog/v1.mdx`, leadtype emits **two** markdown files plus index entries:

| Artifact | Path on disk | Purpose |
| --- | --- | --- |
| Internal staged copy | `public/docs/changelog/v1.md` | The "source of truth" markdown that `llms.txt`, `llms-full.txt`, `search-index.json`, and `search-content.json` reference internally. Also what bash/`grep`-style adapters read. |
| Public mirror | `public/changelog/v1.md` | The user-facing markdown served at the public URL prefix. Created by `copyMountedMarkdownMirrors`, which copies every `**/*.md` from `public/docs/<mountPath>/` to `public/<urlPrefix>/` because the URL prefix (`/changelog`) does not match the default expected prefix (`/docs/changelog`). |
| Canonical URL (in `llms.txt`, sitemap, search index) | `https://example.com/changelog/v1` | What humans, HTTP agents (`Accept: text/markdown`), and search hits point at. Note: no `/docs/` segment. |

So agents that hit `https://example.com/changelog/v1.md` (or `/changelog/v1` with `Accept: text/markdown`) get the mirrored markdown; the site's own bundle generator and search runtime continue to read the canonical copy at `public/docs/changelog/v1.md`; and search results surface the entry under its canonical `/changelog/v1` URL, never under `/docs/changelog/v1`.
