# Serving Changelog Outside `/docs` with leadtype

## The Command

```bash
leadtype generate --src . --docs-dir docs --docs-dir changelog=/changelog --out public
```

This single invocation mounts the `changelog/` folder at a custom URL prefix (`/changelog`) instead of the default `/docs/changelog/...`.

## What Gets Emitted

For a file like `changelog/v1.mdx`:

### 1. Internal Generated Copy
- **Path**: `public/docs/changelog/v1.md`
- This is the intermediate conversion staging area where all MDX → markdown conversion happens.
- leadtype initially converts all mounted sources into a unified staging structure under `public/docs/`.

### 2. Public Mirror (Canonical Location)
- **Path**: `public/changelog/v1.md`
- After conversion, the `copyMountedMarkdownMirrors()` function detects the custom mount and **mirrors** markdown files from the staging area to the public URL location.
- This is where the site actually serves the content from.

### 3. Canonical URL (For Agents & Search)
- **URL**: `/changelog/v1`
- When navigation, search indexes, `llms.txt`, `AGENTS.md`, and `agent-readability.json` are built, they all reference this canonical URL — not `/docs/changelog/v1`.
- This happens because the `--docs-dir changelog=/changelog` flag sets the mount's `urlPrefix` to `/changelog`.

## How It Works

1. **Mount configuration**: `changelog=/changelog` tells leadtype:
   - Source directory: `changelog` (relative to `--src`)
   - URL prefix: `/changelog`
   - Staging path: `docs/changelog` (auto-computed from the basename of the source directory)

2. **URL logic**: 
   - Default docs mounts to `/docs` and stages to `docs/`
   - Additional mounts with explicit prefixes that don't start with `/docs/` trigger the mirroring logic
   - The mismatch between expected (`/docs/changelog`) and actual (`/changelog`) destination triggers the mirror copy

3. **Search and navigation remain searchable** because:
   - `resolveDocsNavigation()` uses mounts to build navigation with the correct `urlPrefix`
   - Search index generation respects the mount's canonical URL
   - Agents see the correct paths in `llms.txt` and `AGENTS.md`

## Key Points

- **Repeat `--docs-dir`** to merge multiple sources (first one defaults to `/docs`, others can be mounted anywhere)
- **Custom prefix requires `=`**: Use `dir=prefix` format; prefix must not be the site root (`/`)
- **Mirroring is automatic**: If the canonical URL differs from the default staging location, markdown files are copied after conversion
- **Single truth**: The URL prefix drives navigation, search, and readability artifact generation — mirroring just ensures the files are in the right place for the web server
