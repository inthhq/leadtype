# Answer

## 1. Single `leadtype generate` invocation

```bash
npx leadtype generate \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --base-url https://your-domain.com
```

* `--docs-dir docs` is the default docs source (served under `/docs`).
* `--docs-dir changelog=/changelog` mounts the sibling `changelog/` folder at the URL prefix `/changelog` instead of nesting it under `/docs/changelog`.
* `--base-url` is required so generated indexes and agent manifests contain absolute canonical URLs.
* `--out public` is the default output directory and can be omitted.

## 2. What gets emitted for `changelog/v1.mdx`

| Artifact | Path / URL |
|----------|------------|
| **Internal generated copy** | `public/docs/changelog/v1.md` |
| **Public mirror** | `public/changelog/v1.md` |
| **Canonical URL agents see** | `https://your-domain.com/changelog/v1` (page URL) and `https://your-domain.com/changelog/v1.md` (markdown mirror) |

### Details

1. **Internal generated copy** – The pipeline stages all sources into a single temporary `docs/` tree, converts MDX to flat markdown, and writes the result to `public/docs/changelog/v1.md`. This is the copy used to build the search index, sitemaps, `llms.txt`, and `agent-readability.json`.

2. **Public mirror** – Because the mount’s `urlPrefix` is `/changelog` (not the default `/docs/changelog`), `leadtype` automatically mirrors the markdown files from `public/docs/changelog/` into `public/changelog/`. This makes the page servable at `/changelog/v1.md` (and `/changelog/v1` by your framework) without requiring the URL to contain `/docs`.

3. **Canonical URL** – `toDocsUrlPath` resolves the mount mapping and strips the internal `docs/` prefix, so every agent-facing artifact references the page at `/changelog/v1`. The search index, `llms.txt`, and `agent-readability.json` all point to this canonical path, keeping the changelog fully searchable while it lives outside the `/docs/` URL namespace.
