# Serving Changelog at `/changelog/...` with Mounts

## 1. The Command

```bash
npx leadtype generate --src . --out public --base-url https://example.com --docs-dir docs --docs-dir changelog=/changelog
```

This invocation:
- Reads source MDX from `docs/` and `changelog/` folders
- Mounts `changelog/` at the URL prefix `/changelog` (not `/docs/changelog`)
- Generates all artifacts (including search index) with the changelog pages reachable at `/changelog/...`
- Keeps changelog pages searchable alongside the main docs

## 2. Artifact Emission for `changelog/v1.mdx`

For a source file at `changelog/v1.mdx`:

| Artifact | Location | Purpose |
|----------|----------|---------|
| **Internal generated copy** | `public/docs/changelog/v1.md` | Intermediate markdown used by the build; agents searching internally also see this |
| **Public mirror** | `public/changelog/v1.md` | Canonical public markdown file at the mounted URL prefix |
| **Canonical URL** | `https://example.com/changelog/v1` | The URL agents and humans see when reading/browsing the page |

When an agent or user navigates to the page, HTTP content negotiation serves:
- `Accept: text/html` → HTML rendering from your framework
- `Accept: text/markdown` → Markdown from `public/changelog/v1.md`
- (Search index includes the page under `/changelog/v1`)

### How Mounts Work Internally

The `--docs-dir changelog=/changelog` flag creates a mount:
- **`pathPrefix`** = `"changelog"` (relative path in the staging directory)
- **`urlPrefix`** = `"/changelog"` (public URL prefix)

1. **During conversion**: MDX in `changelog/` gets converted to markdown at `public/docs/changelog/` (internal staging)
2. **Mirroring step**: Markdown files are then copied from `public/docs/changelog/` to `public/changelog/` to match the URL prefix
3. **Search index**: Built from the staged markdown, canonicalized to `/changelog/...` URLs
4. **Navigation + `llms.txt`**: All links point to `/changelog/v1`, not `/docs/changelog/v1`

This setup ensures:
- ✅ Changelog lives at `/changelog/...` on the site
- ✅ Searchable (included in `search-index.json` with correct canonical URLs)
- ✅ Markdown mirrors are public and agent-readable at the right path
- ✅ Works alongside the main `/docs` tree

---

### Multiple Mounts Example

```bash
npx leadtype generate --src . --out public --base-url https://example.com \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --docs-dir guides=/guides
```

This produces:
- `public/docs/*.md` and URLs at `/docs/...`
- `public/changelog/*.md` and URLs at `/changelog/...`
- `public/guides/*.md` and URLs at `/guides/...`

All appear in the same search index with correct canonical URLs.
