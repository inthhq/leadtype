# Serving `changelog/` under `/changelog/...`

## 1. The command

```bash
leadtype generate --docs-dir docs --docs-dir changelog=/changelog --base-url https://yoursite.dev
```

- The **first** `--docs-dir` is the primary source. It mounts at the bare root
  (mount path `""`), so `docs` keeps its normal `/docs` URL prefix.
- The **second** `--docs-dir` uses the `<dir>=<url-prefix>` form
  (`changelog=/changelog`). This mounts the sibling `changelog/` folder with the
  URL prefix `/changelog` instead of the default `/docs/changelog`.
- Because both folders are normal docs sources, the changelog pages are
  converted, indexed, and added to `llms.txt`/search just like the `docs` pages —
  so they stay fully searchable.

(`--base-url` is shown for completeness so generated links are absolute; it isn't
required for the mounting behavior. Add `--name`/`--summary` if you don't have a
`package.json` to derive them from.)

> Note: you must list `docs` explicitly as the first `--docs-dir`. If you only
> passed `--docs-dir changelog=/changelog`, that single source would become the
> primary mount and your `docs/` folder would not be picked up.

## 2. What gets emitted for `changelog/v1.mdx`

With the mount `{ pathPrefix: "changelog", urlPrefix: "/changelog" }`, leadtype
produces three things for that file:

| Artifact | Location | Notes |
| --- | --- | --- |
| **Internal generated copy** | `public/docs/changelog/v1.md` | Conversion always writes flattened markdown under the staging `docs/` tree at `<out>/docs/<mountPath>/...`. This is the canonical on-disk copy the pipeline reads from. |
| **Public mirror** | `public/changelog/v1.md` | Because the URL prefix (`/changelog`) differs from the default it would otherwise get (`/docs/changelog`), `copyMountedMarkdownMirrors` copies the markdown to a second location that matches the public prefix. This is what gets served at `/changelog/v1.md`. |
| **Canonical URL agents see** | `/changelog/v1` | `toDocsUrlPath` resolves the file through its mount, swapping the `changelog/` path prefix for the `/changelog` URL prefix. So `llms.txt`, the search index, the sitemap, and the agent-readability manifest all reference `/changelog/v1` (markdown link `/changelog/v1.md`) — **never** `/docs/changelog/...`. |

So a single `leadtype generate` call gives you:

- `public/docs/changelog/v1.md` — internal copy (pipeline source of truth),
- `public/changelog/v1.md` — public mirror served under `/changelog`,
- canonical URL `/changelog/v1` everywhere agents look, while the page remains in
  the BM25 search index alongside the rest of the docs.
