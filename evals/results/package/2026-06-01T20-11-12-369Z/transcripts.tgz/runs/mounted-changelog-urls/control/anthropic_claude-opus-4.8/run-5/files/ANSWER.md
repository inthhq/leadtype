# Serving `changelog/` under `/changelog/...`

## 1. The command

```bash
npx leadtype generate --docs-dir docs --docs-dir changelog=/changelog --base-url https://example.com
```

(`--base-url` is optional — drop it for a relative-URL build. Set it to your real
site origin. The two `--docs-dir` flags are the part that matters.)

### Why this shape

- `leadtype generate` accepts `--docs-dir` more than once to **merge multiple
  source folders**. Each value may use the form `<dir>=<url-prefix>` to mount a
  source somewhere other than the default `/docs` tree.
- The **first** `--docs-dir` is the primary source and is always mounted at the
  site root of the docs tree (`mountPath = ""`, URL prefix `/docs`). So
  `--docs-dir docs` keeps `docs/**` at `/docs/...` exactly as before.
- The **second** source, `changelog=/changelog`, mounts the sibling `changelog/`
  folder and overrides its URL prefix to `/changelog`. Without the `=/changelog`
  override it would default to `/docs/changelog` (i.e. `/docs/<basename>`), which
  is exactly what we want to avoid.

A few guardrails the CLI enforces:

- The override prefix must not be the site root (`=/` is rejected).
- If the repo had a `leadtype.config.*` that defines `collections`, you could
  **not** pass `--docs-dir` — collections fully describe their own sources (and
  you'd instead set `prefix: "/changelog"` on the changelog collection). This
  repo has no such config, so the `--docs-dir` form is the right tool. (The
  collection equivalent produces identical output.)

## 2. What it emits for `changelog/v1.mdx`

During the run leadtype first **stages** every source into a single internal
`docs/` tree, joining each non-primary source under its folder basename — so
`changelog/v1.mdx` is staged as `docs/changelog/v1.mdx`. Then:

### Internal generated copy (the canonical flattened artifact)

```
public/docs/changelog/v1.md
```

`convertAllMdx` always writes the flattened markdown into `<out>/docs/...`,
keyed by the staged path. This is the real generated file; the llms.txt,
`llms-full.txt`, search index, sitemap, and agent-readability manifest are all
built by reading this `docs/` tree.

### Public mirror (what `/changelog/...` is actually served from)

```
public/changelog/v1.md
```

Because the mount's URL prefix (`/changelog`) differs from the default it would
otherwise get (`/docs/changelog`), the generator runs a mirror step that copies
every `*.md` under `public/docs/changelog/` to the output directory that matches
the URL prefix — `public/changelog/`. That mirror is what a request to
`/changelog/v1.md` resolves to.

### Canonical URL agents see

```
/changelog/v1
```

(absolute: `https://example.com/changelog/v1` when `--base-url` is set; its
markdown form is `/changelog/v1.md`.)

The mount table is threaded into the URL resolver, so when leadtype maps the
staged path `changelog/v1.md` to a URL it strips the `changelog/` path prefix,
applies the `/changelog` URL prefix, and drops the extension — yielding
`/changelog/v1`. This is the URL recorded in `llms.txt`, `llms-full.txt`, the
search index, and the agent-readability manifest, so the page stays fully
**searchable** and discoverable while living at `/changelog/...` instead of
`/docs/changelog/...`.

### Summary table

| Artifact | Path / value |
| --- | --- |
| Internal generated copy | `public/docs/changelog/v1.md` |
| Public mirror (served) | `public/changelog/v1.md` |
| Canonical URL | `/changelog/v1` (`.md` mirror: `/changelog/v1.md`) |
