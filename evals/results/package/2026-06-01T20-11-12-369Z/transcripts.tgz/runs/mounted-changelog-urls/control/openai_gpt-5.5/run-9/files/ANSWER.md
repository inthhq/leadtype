# Mounted changelog output

Use site mode with both source roots, mounting the sibling `changelog/` source at `/changelog`:

```bash
leadtype generate --src . --out public --docs-dir docs --docs-dir changelog=/changelog --base-url https://your-site.example
```

Replace `https://your-site.example` with the real site origin. Keeping this in normal site mode (no `--bundle`) also emits the search files, so the mounted changelog pages are included in `public/docs/search-index.json` and `public/docs/search-content.json`.

For a source file such as `changelog/v1.mdx`, leadtype stages that second source under the internal mount path `changelog/` and converts it to:

- Internal generated markdown copy: `public/docs/changelog/v1.md`
- Public mounted mirror: `public/changelog/v1.md`
- Canonical page URL in agent/search metadata: `/changelog/v1` (or `https://your-site.example/changelog/v1` with the `--base-url` above)

Agent-readable artifacts that point at the markdown file use the mounted markdown URL `/changelog/v1.md`, not `/docs/changelog/v1.md`.
