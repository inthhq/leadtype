# Serving Changelog Under `/changelog/...` with Searchability

## 1. The Single `leadtype generate` Invocation

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

Or more concisely:

```bash
npx leadtype generate --src . --docs-dir docs --docs-dir changelog=/changelog --out public --base-url https://example.com
```

**Key syntax:** `--docs-dir changelog=/changelog` mounts the `changelog/` folder at the URL prefix `/changelog` instead of the default `/docs/changelog`.

---

## 2. What Gets Emitted for `changelog/v1.mdx`

### Internal Generated Copy
**Location:** `public/docs/changelog/v1.md`

This is the canonical conversion from MDX to markdown. All other outputs derive from this file.

### Public Mirror (Canonical URL)
**Location:** `public/changelog/v1.md`

The public-facing copy served to agents and browsers. This is the **canonical URL** that agents see and link to.

### Agent-Visible URL
Agents accessing content see the canonical URL: **`/changelog/v1.md`** (or `/changelog/v1` for HTML).

When agents request the markdown version via `Accept: text/markdown` or navigate to `/changelog/...`, they get the public mirror at `public/changelog/v1.md`.

---

## How It Works

1. **Source:** `changelog/v1.mdx` is converted to markdown during the generate step.

2. **Internal Staging:** The markdown lands at `public/docs/changelog/v1.md` (under the default docs prefix `/docs`).

3. **Public Mirror:** Because `--docs-dir changelog=/changelog` specifies a custom URL prefix, leadtype automatically copies the markdown from the internal path to the public mount point at `public/changelog/v1.md`.

4. **Search Indexing:** The page is indexed into `public/docs/search-index.json` and `public/changelog/search-index.json` (if separate), with the canonical URL recorded as `/changelog/v1`.

5. **Navigation & Discovery:** The page appears in navigation trees and `llms.txt` with the `/changelog` prefix, making it discoverable and properly linked.

---

## Summary

- **Invocation:** `--docs-dir changelog=/changelog` (repeat the `--docs-dir` flag)
- **Internal generated copy:** `public/docs/changelog/v1.md`
- **Public mirror (canonical):** `public/changelog/v1.md`
- **Canonical URL agents see:** `/changelog/v1`
- **Search:** Fully indexed under the canonical `/changelog/...` path
