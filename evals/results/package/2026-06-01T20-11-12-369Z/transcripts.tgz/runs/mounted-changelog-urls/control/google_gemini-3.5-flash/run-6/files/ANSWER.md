# Configuring Mounted Changelog URLs in Leadtype

To serve a custom changelog directory `changelog/` located next to `docs/` at the URL path `/changelog/...` (while keeping pages searchable and indexable), use the following configuration:

## 1. Single `leadtype generate` Invocation

```bash
npx leadtype generate \
  --src . \
  --out public \
  --base-url https://example.com \
  --docs-dir docs \
  --docs-dir changelog=/changelog
```

### Explanation of flags:
- `--src .`: Specifies the project root.
- `--out public`: Specifies the public site build target directory.
- `--base-url https://example.com`: Sets the canonical base URL for resolving absolute links, metadata, sitemaps, and headers.
- `--docs-dir docs`: Mounts the default `docs/` folder to the default `/docs` prefix.
- `--docs-dir changelog=/changelog`: Mounts the `changelog/` directory outside `/docs` using custom `<folder>=<url-prefix>` syntax, mapping it directly to `/changelog`.

---

## 2. Emitted Artifacts for `changelog/v1.mdx`

Given a file like `changelog/v1.mdx` under the root of the changelog folder:

### A. Internal Generated Copy
* **File path:** `public/docs/changelog/v1.md`
* **Details:** Leadtype copies files from all mounted sources into a unified staging area where `convertAllMdx` compiles them. Because the custom mounting directory uses the path prefix `changelog` (for `/changelog`), the page is compiled directly into `public/docs/changelog/v1.md`.

### B. Public Mirror
* **File path:** `public/changelog/v1.md`
* **Details:** During the build, Leadtype identifies that the URL prefix `/changelog` is not the expected default `/docs/changelog`. It automatically creates a public mirror by copying compiled `.md` pages to their corresponding custom path under the output root, making them directly readable under `/changelog/v1.md`.

### C. Canonical URL Agents See
* **Canonical Site URL (HTML Route):** `https://example.com/changelog/v1`
* **Canonical Markdown URL (Agent Route):** `https://example.com/changelog/v1.md`
* **Details:** 
  * The canonical URL representing the main page is resolved to `https://example.com/changelog/v1`.
  * This canonical HTML URL is embedded directly into the compiled Markdown file's frontmatter as:
    ```yaml
    canonical_url: "https://example.com/changelog/v1"
    ```
  * When HTTP agents make requests requesting Markdown or with an AI user agent, Leadtype serves a `Link` response header referencing the canonical HTML route:
    ```http
    Link: <https://example.com/changelog/v1>; rel="canonical"
    ```
