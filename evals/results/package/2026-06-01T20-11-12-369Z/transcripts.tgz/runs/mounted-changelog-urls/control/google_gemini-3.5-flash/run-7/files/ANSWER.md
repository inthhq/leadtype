# Answer

## 1. Single `leadtype generate` Invocation

To mount the `changelog/` folder outside `/docs/...` and serve it directly under `/changelog/...` while keeping it searchable and indexed properly, you use the repeated `--docs-dir` option with `<dir>=<url-prefix>` mounting syntax:

```bash
npx leadtype generate --docs-dir docs --docs-dir changelog=/changelog
```

*(If you are deploying to a hosted site, you should also include `--base-url` and optionally `--out` for your output directory):*

```bash
npx leadtype generate --base-url https://leadtype.dev --out public --docs-dir docs --docs-dir changelog=/changelog
```

---

## 2. Emitted Artifacts for `changelog/v1.mdx`

When `leadtype generate` processes a file located at `changelog/v1.mdx` with the above configuration:

### A. The Internal Generated Copy
* **Path:** `public/docs/changelog/v1.md` (assuming the output folder is `public`)
* **How it is built:** During compilation, `leadtype` stages all MDX sources into a temporary workspace. Files from the `changelog/` directory are staged under `docs/changelog/` to prevent collisions. These are then converted from MDX to flat, clean Markdown (`.md`) and written under the `<outDir>/docs/` folder.

### B. The Public Mirror
* **Path:** `public/changelog/v1.md`
* **How it is built:** After compiling MDX into `.md` inside `public/docs`, `leadtype` identifies that the mounted URL prefix for `changelog` is `/changelog` (which differs from the standard `/docs/changelog` prefix). The pipeline calls `copyMountedMarkdownMirrors` to copy the generated `.md` files out of `public/docs/changelog/` and into the top-level `public/changelog/` directory.

### C. The Canonical URL Agents See
* **Sitemaps/Main Page Canonical URL:** `https://leadtype.dev/changelog/v1`
* **Markdown Mirror Canonical URL:** `https://leadtype.dev/changelog/v1.md`
* **How it is determined:** `leadtype` resolves paths using `toDocsUrlPath` and the defined mounts. Because the file originates from the `changelog` folder (mounted with the `/changelog` prefix), the pipeline generates sitemaps, static search indexes, and `llms.txt` references pointing directly to the `/changelog/v1` and `/changelog/v1.md` paths.
