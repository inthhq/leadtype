# Answer

```bash
leadtype generate --src . --docs-dir docs --docs-dir changelog=/changelog --out public --base-url https://example.com
```

Replace `https://example.com` with the site's real origin. The important part is the repeated `--docs-dir`: the normal docs source stays mounted at `/docs`, while `changelog=/changelog` mounts the sibling `changelog/` source at `/changelog` instead of the default secondary-source mount `/docs/changelog`.

For `changelog/v1.mdx`, leadtype stages it as the mounted relative path `changelog/v1.mdx` and emits:

- **Internal generated copy:** `public/docs/changelog/v1.md`
  - This is the converted markdown inside leadtype's generated `docs` artifact tree.
  - Search and LLM artifacts are built from this generated tree.
- **Public markdown mirror:** `public/changelog/v1.md`
  - Because the source was mounted with the URL prefix `/changelog`, leadtype mirrors the generated markdown to the public URL-prefix directory.
  - This is the markdown file agents can fetch at `/changelog/v1.md`.
- **Canonical page URL agents see:** `https://example.com/changelog/v1` (or `/changelog/v1` as the URL path)
  - The page is indexed/searchable with `urlPath: "/changelog/v1"`, not `"/docs/changelog/v1"`.
  - Agent-readability/full-context artifacts use that canonical page URL, while also pointing at the mounted markdown URL `/changelog/v1.md`.
