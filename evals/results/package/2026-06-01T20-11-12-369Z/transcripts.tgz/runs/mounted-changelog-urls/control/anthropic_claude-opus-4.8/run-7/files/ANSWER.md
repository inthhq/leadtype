# Serving `changelog/` under `/changelog/...`

## 1. The single `leadtype generate` invocation

```bash
npx leadtype generate \
  --src . \
  --out public \
  --base-url https://example.com \
  --docs-dir docs \
  --docs-dir changelog=/changelog
```

### Why this works

`leadtype generate` accepts `--docs-dir` more than once to merge several source
folders into one site. The key piece is the `<dir>=<url-prefix>` form documented
in the CLI help:

> `--docs-dir <dir>` … Use `<dir>=<url-prefix>` to mount a source outside
> `/docs`, e.g. `changelog=/changelog`.

- The **first** `--docs-dir docs` is the primary source. It mounts at the site
  root for docs (mount path `""`, URL prefix `/docs`) — your normal
  `/docs/...` pages.
- The **second** `--docs-dir changelog=/changelog` adds the sibling
  `changelog/` folder and explicitly mounts it at the URL prefix `/changelog`.

Without the `=/changelog` override, an extra source folder defaults to
`/docs/<foldername>` (i.e. `/docs/changelog`). Supplying `=/changelog` pulls it
out from under `/docs` and serves it at the top level instead, exactly as
required. (The prefix may not be `/` — the root is reserved — but `/changelog`
is fine.)

Because the changelog is processed by the *same* generate run, it flows through
the same MDX→markdown flattening, the same `llms.txt` / `llms-full.txt`
aggregation, and the same static search-index build — so the pages stay fully
**searchable** and agent-readable, just at a different URL.

> Note: `--base-url` only affects the absolute URLs written into the generated
> link/search artifacts; it isn't what relocates the changelog. The relocation
> is entirely the `changelog=/changelog` mount. Use whatever base URL your site
> is served from (or omit it if you rely on the environment-derived default).

## 2. What it emits for `changelog/v1.mdx`

Given the source file `changelog/v1.mdx` and `--out public`, the run produces
three distinct things:

| Artifact | Path / value | Notes |
| --- | --- | --- |
| **Internal generated copy** | `public/docs/changelog/v1.md` | Every converted page is first written under `public/docs/<mountPath>/...`. The changelog source mounts with staging path `changelog`, so its flattened markdown lands at `public/docs/changelog/v1.md`. This is the canonical on-disk conversion output the pipeline works from. |
| **Public mirror** | `public/changelog/v1.md` | Because the changelog's URL prefix (`/changelog`) differs from its default docs location (`/docs/changelog`), `leadtype` mirrors the markdown to the directory that matches the public URL prefix — `public/changelog/`. This is the file actually served when an HTTP agent requests the page as markdown at `/changelog/v1.md`. |
| **Canonical URL agents see** | `/changelog/v1` (absolute: `https://example.com/changelog/v1`) | URL paths are derived from the mount's URL prefix, not its staging folder. So the page's canonical doc URL — the one used in `llms.txt`, `llms-full.txt`, the search index, sitemap, and agent-readability manifest — is `/changelog/v1`, with the markdown mirror at `/changelog/v1.md`. Nothing references `/docs/changelog/...`. |

### Mental model

1. **Convert** → write the flattened copy to `public/docs/changelog/v1.md`
   (internal staging under `/docs`).
2. **Mirror** → since the mount's URL prefix `/changelog` ≠ the default
   `/docs/changelog`, copy the markdown out to `public/changelog/v1.md` so the
   public path on disk matches the public URL.
3. **Index/link** → all generated link, search, and sitemap artifacts record the
   page under the mount's URL prefix, i.e. `/changelog/v1`
   (`https://example.com/changelog/v1`), keeping it searchable while never
   exposing a `/docs/changelog/...` URL.
