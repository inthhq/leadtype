# Serving `changelog/` under `/changelog/...`

## 1. Invocation

Run `leadtype generate` with both source folders, using `<dir>=<url-prefix>` to mount the changelog outside the default `/docs` tree:

```bash
npx leadtype generate \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

- `--docs-dir docs` keeps the main docs at `/docs/...`.
- `--docs-dir changelog=/changelog` overrides the default `/docs/changelog` prefix so changelog pages are served from `/changelog/...`.
- The search index, `llms.txt`, and agent-readability metadata all receive the mount map and resolve URLs accordingly, so the changelog remains searchable.

## 2. Emissions for `changelog/v1.mdx`

| Artifact | Path / URL |
|----------|------------|
| **Internal generated copy** | `public/docs/changelog/v1.md` — all converted markdown is first written under the default `docs/` output tree, preserving the merged source structure (`changelog/` as a sub-directory). |
| **Public mirror** | `public/changelog/v1.md` — because the mount’s `urlPrefix` (`/changelog`) differs from the default staging path (`/docs/changelog`), `copyMountedMarkdownMirrors` copies the `.md` files into the custom prefix directory. |
| **Canonical URL agents see** | `https://example.com/changelog/v1.md` — `llms.txt`, the search index, and agent-readability manifests use `toMountedMarkdownUrlPath`, which strips the internal `changelog/` path prefix and replaces it with `/changelog`, yielding `/changelog/v1.md`. Agents requesting the markdown mirror get this URL. |
