# Mounting the Changelog under `/changelog/...`

## 1. The single `leadtype generate` invocation

To mount the standard `docs/` folder normally and mount the `changelog/` folder right beside it under `/changelog/...` instead of `/docs/changelog/...`, run:

```bash
npx leadtype generate --docs-dir docs --docs-dir changelog=/changelog --base-url https://example.com
```

*(You can replace `https://example.com` with your production base URL and adjust `--out <dir>` if your output folder is not the default `public`).*

---

## 2. Generated Outputs and URLs for `changelog/v1.mdx`

When `leadtype generate` runs with the invocation above, it processes `changelog/v1.mdx` as follows:

### Internal Generated Copy
* **Path:** `public/docs/changelog/v1.md` *(assuming `--out` is the default `public`)*
* **Description:** The pipeline first stages and flattens `changelog/v1.mdx` into standard agent-readable markdown (`.md`) inside the standard output directory under `docs/changelog/v1.md`.

### Public Mirror
* **Path:** `public/changelog/v1.md`
* **Description:** Because the URL prefix (`/changelog`) does not match the default expected prefix (`/docs/changelog`), `leadtype` copies the generated markdown file from the intermediate directory to the target public directory. This makes the raw, agent-readable markdown directly accessible at `/changelog/v1.md`.

### Canonical URL agents see
* **HTML/Canonical URL:** `https://example.com/changelog/v1`
* **Markdown Mirror URL:** `https://example.com/changelog/v1.md`
* **Description:** In the generated search index (`search-index.json`), sitemap files (`sitemap.xml`, `sitemap.md`), and `llms.txt` index files, the document is associated with its canonical HTML route path `/changelog/v1` (absolute canonical URL `https://example.com/changelog/v1`) and its markdown counterpart `https://example.com/changelog/v1.md`. This ensures search tools and AI agents can locate and read the page directly under `/changelog/...` rather than `/docs/changelog/...`.
