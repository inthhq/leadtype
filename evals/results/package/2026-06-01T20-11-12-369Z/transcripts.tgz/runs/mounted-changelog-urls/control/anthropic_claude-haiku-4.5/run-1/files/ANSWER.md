# Serving `changelog/` Under `/changelog/...` Instead of `/docs/changelog/...`

## 1. The Single `leadtype generate` Invocation

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://your-site.com
```

**Key mechanism:** The `--docs-dir changelog=/changelog` flag tells leadtype:
- **Source location:** Look for MDX files in the `changelog/` folder (relative to `--src`)
- **URL mount prefix:** Serve those files under `/changelog/` on the generated site (not under `/docs/changelog/`)

---

## 2. What Gets Emitted for `changelog/v1.mdx`

When you have a file at `changelog/v1.mdx`, here's what leadtype generates:

### **Internal Generated Copy** (staging location)
```
public/docs/changelog/v1.md
```
This is the flattened markdown that **agents read via `Accept: text/markdown` requests** or when they access internal paths. It lives in the staging area because leadtype always flattens MDX to markdown in `docs/` first.

### **Public Mirror** (canonical served path)
```
public/changelog/v1.md
```
This is a **mirror/copy** created by `copyMountedMarkdownMirrors()` in the generate pipeline. It reflects the custom mount point you declared with `changelog=/changelog`. This is what gets served to both humans and agents when accessing the canonical URL.

### **Canonical URL (What Agents See)**
```
https://your-site.com/changelog/v1
```
- When agents make a request like `GET /changelog/v1.md` with `Accept: text/markdown`, they receive the public mirror.
- The frontmatter metadata (title, description, group, etc.) points agents to this `/changelog/...` path.
- `llms.txt` and `AGENTS.md` reference this canonical URL (not `/docs/changelog/...`).

---

## 3. How It's Searchable

The changelog is **fully searchable** because:

1. **Search index generation** respects the mounts configuration via the `mounts` parameter passed to `generateDocsSearchFiles()`.
2. The search index (`public/docs/search-index.json` or locale-specific variants) includes all pages from all mounts, with their canonical URLs.
3. When agents query the search index, results point back to the canonical `/changelog/...` paths.

You can optionally add a `--base-url` so links in the search index resolve as absolute URLs for API consumers.

---

## Example Full Setup

```bash
# Assume this structure:
# .
# ├── docs/          (normal docs)
# ├── changelog/     (changelog entries)
# └── public/        (generated output)

npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://myproject.dev
```

**Generated output structure:**
```
public/
├── docs/
│   ├── llms.txt                    # Product index (references /changelog/... for changelog pages)
│   ├── index.md                    # Flattened docs
│   ├── guides/
│   │   └── getting-started.md
│   ├── changelog/                  # Staging copy (internal)
│   │   └── v1.md
│   └── search-index.json           # Search index (includes /changelog/... URLs)
├── changelog/                      # Public mirror (canonical serve location)
│   └── v1.md
├── llms.txt                        # Root product index
└── llms-full.txt                   # Full context dump
```

**Key behaviors:**
- `https://myproject.dev/docs/index.md` → flattened docs home
- `https://myproject.dev/docs/guides/getting-started.md` → flattened guide page
- `https://myproject.dev/changelog/v1.md` → **changelog file (served from public mirror, not /docs/)**
- Agent readability manifests list `/changelog/v1` as the canonical path
- Search results point agents to `/changelog/...` paths
