# Answer

```bash
leadtype generate --src . --out public --base-url https://example.com --docs-dir docs --docs-dir changelog=/changelog
```

Use your real site origin in place of `https://example.com`.

For a source file such as `changelog/v1.mdx`, this treats `docs/` as the normal `/docs` source and mounts `changelog/` at `/changelog`:

- Internal generated copy: `public/docs/changelog/v1.md`
  - leadtype still stages/converts the second source under the internal `docs/changelog/` tree so shared artifacts such as `public/docs/search-index.json` and `public/docs/search-content.json` can include it.
- Public markdown mirror: `public/changelog/v1.md`
  - because the requested URL prefix `/changelog` differs from the default internal `/docs/changelog` mount, leadtype copies the generated markdown mirror out to the public URL prefix.
- Canonical agent-facing page URL: `https://example.com/changelog/v1` (or `/changelog/v1` as a path)
  - agent/readability and search metadata use `/changelog/v1`, not `/docs/changelog/v1`; the markdown URL for the mirrored page is `/changelog/v1.md`.
