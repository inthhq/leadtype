# Answer

```bash
leadtype generate --src . --docs-dir docs --docs-dir changelog=/changelog --out public --base-url https://YOUR-SITE.example
```

Replace the `--base-url` value with the production origin for the site.

For `changelog/v1.mdx`, the second `--docs-dir` is staged internally under the `changelog` mount, but its URL prefix is `/changelog`:

- Internal generated markdown copy: `public/docs/changelog/v1.md`
- Public markdown mirror: `public/changelog/v1.md` (served as `/changelog/v1.md`)
- Canonical page URL in generated agent/search metadata: `/changelog/v1` (or `https://YOUR-SITE.example/changelog/v1` where absolute URLs are emitted)

The search artifacts are still generated in the normal site output (`public/docs/search-index.json` and `public/docs/search-content.json`) and index that page with the mounted `/changelog/v1` URL, not `/docs/changelog/v1`.
