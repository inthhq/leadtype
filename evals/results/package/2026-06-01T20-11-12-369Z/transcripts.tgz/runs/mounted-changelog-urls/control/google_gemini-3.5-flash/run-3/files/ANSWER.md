# Mounted Changelog URLs in Leadtype

Below is the configuration and description of how `leadtype` achieves serving changelog pages directly under `/changelog/...` (outside the standard `/docs/...` path) while keeping them fully searchable and integrated.

---

## 1. The `leadtype generate` Invocation

To include both the standard `docs/` directory and the `changelog/` directory (mapped to the `/changelog` URL route prefix), run the following single invocation:

```bash
npx leadtype generate --docs-dir docs --docs-dir changelog=/changelog --base-url https://example.com
```

### Explanation of Flags:
- `--docs-dir docs`: Tells `leadtype` to mount the main `docs/` directory at the default `/docs` route prefix.
- `--docs-dir changelog=/changelog`: Tells `leadtype` to mount the `changelog/` directory at the `/changelog` route prefix instead of the default `/docs/changelog` nested prefix.
- `--base-url https://example.com`: Sets the canonical site URL base used for absolute URLs across the generated site (e.g. in the search index, sitemaps, and `llms.txt`).

---

## 2. Emitted Artifacts and Lifecycle for `changelog/v1.mdx`

When `changelog/v1.mdx` is processed, `leadtype` performs a multi-step staging, compilation, and mirroring process that produces three distinct representations:

### A. The Internal Generated Copy
* **File Path:** `public/docs/changelog/v1.md` (or `[out-dir]/docs/changelog/v1.md`)
* **How it is produced:** 
  1. `leadtype` stages all markdown files in a temporary staging root. The `changelog/` source is staged under a folder named after its mount prefix: `tempDocsDir/changelog/v1.mdx`.
  2. The MDX compilation engine converts the staged files to clean, flattened Markdown.
  3. The compilation output is written directly to the internal documentation output path: `[out-dir]/docs/changelog/v1.md`.
* **Purpose:** This file acts as the internal source of truth. It is used to build the static search index (e.g. `public/docs/search-index.json`), generate the unified sitemaps, and produce the edge-safe runtime assets.

### B. The Public Mirror
* **File Path:** `public/changelog/v1.md` (or `[out-dir]/changelog/v1.md`)
* **How it is produced:** 
  1. During the generation process, `leadtype` detects that the `/changelog` URL prefix does not match the default expected URL prefix for its mounted folder (`/docs/changelog`).
  2. After MDX-to-Markdown conversion completes, the `copyMountedMarkdownMirrors` step copies the generated `.md` files from the internal subdirectory (`[out-dir]/docs/changelog/v1.md`) into their public URL-aligned path (`[out-dir]/changelog/v1.md`).
* **Purpose:** This is the publicly accessible markdown file served on the live site at `/changelog/v1.md`, ready to be requested by users and HTTP agents (via standard routing or headers like `Accept: text/markdown`).

### C. The Canonical URL Seen by Agents
* **URL:** `https://example.com/changelog/v1`
* **How it is determined:**
  1. `leadtype` resolves the route path for `changelog/v1.mdx` using its custom mount configuration to map the file to the custom route prefix `/changelog/v1`.
  2. It prepends the configured `--base-url` (`https://example.com`) to formulate the absolute URL.
* **Where agents see this:**
  - **Frontmatter Injection:** In both the internal copy and the public mirror, `leadtype` injects a YAML frontmatter property:
    ```yaml
    canonical_url: https://example.com/changelog/v1
    ```
  - **Search Indices and Sitemaps:** The edge-safe search index (`search-index.json`), `sitemap.xml`, and `sitemap.md` all map the file to the canonical route `/changelog/v1` and absolute URL `https://example.com/changelog/v1`.
  - **`llms.txt` and `llms-full.txt`:** The product summary context files reference `/changelog/v1` as the active path, ensuring search crawlers and LLM agents retrieve context with the correct URL.
