# Mounting Changelog Pages in Leadtype

To serve a `changelog/` folder under `/changelog/...` (outside the default `/docs/changelog/...`) while keeping it fully searchable, we configure `leadtype` to mount the directory using custom URL prefix mapping on the CLI.

---

### 1. The `leadtype generate` Invocation

The single invocation that achieves this is:

```bash
npx leadtype generate \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --base-url https://example.com \
  --out public
```

#### How it works:
* `--docs-dir docs`: Resolves the primary documentation directory and mounts it to the default `/docs` prefix.
* `--docs-dir changelog=/changelog`: Mounts the companion `changelog` directory to the `/changelog` URL prefix instead of the default `/docs/changelog` prefix.
* `--base-url https://example.com`: The canonical base URL of your hosted site.
* `--out public`: Specifies the destination directory for build artifacts.

---

### 2. Artifacts Emitted for `changelog/v1.mdx`

For a file like `changelog/v1.mdx`, the following artifacts and URLs are created:

#### A. Internal Generated Copy
* **Path:** `public/docs/changelog/v1.md`
* **Details:** This is the internally converted, flattened Markdown output created in the standard staging area (`public/docs/`) during build processing.

#### B. Public Mirror
* **Path:** `public/changelog/v1.md`
* **Details:** Since `/changelog` is mounted outside `/docs`, `leadtype` identifies that the target URL prefix does not match the default `/docs` layout. It copies the generated `.md` file to this public path matching the `/changelog/...` prefix. This public mirror is what HTTP agents fetch when requesting markdown versions or accessing `/changelog/...` routes.

#### C. Canonical URL Agents See
* **URL:** `https://example.com/changelog/v1.md`
* **Details:** The agent-facing endpoints (such as `llms.txt`, full-context outputs, and the static edge-safe search index `search-index.json`) will refer to this canonical URL for indexation and crawl-ability.
