# Serving `changelog/` under `/changelog/...`

## 1. The single command

Run `leadtype generate` with **two** `--docs-dir` sources: the normal `docs`
folder as the primary source, and the sibling `changelog` folder mounted at its
own URL prefix using the `<dir>=<url-prefix>` form:

```bash
npx leadtype generate \
  --src . \
  --out public \
  --base-url https://example.com \
  --docs-dir docs \
  --docs-dir changelog=/changelog
```

Notes:

- The **first** `--docs-dir` (`docs`) is the primary source and keeps the
  default `/docs` URL prefix.
- The **second** `--docs-dir changelog=/changelog` mounts the sibling
  `changelog/` folder. The `=/changelog` part overrides the prefix that would
  otherwise be `/docs/changelog`, hoisting the pages to the site root under
  `/changelog`.
- Swap `--base-url` for your real site origin. The `--out public` is the default
  and can be omitted.

Why not a config file? You can do the same thing in `leadtype.config.ts` with a
`collections` entry (`changelog: { dir: "../changelog", prefix: "/changelog" }`),
but the question asks for a single `generate` invocation, and `--docs-dir
changelog=/changelog` expresses the exact same mount inline. (You can't combine
`--docs-dir` with a config that defines `collections` — the CLI rejects that.)

## 2. What it emits for `changelog/v1.mdx`

leadtype always converts every source into one internal `docs/` tree, then
*mirrors* any non-`/docs` mount to its public location. The URL the source is
mounted at (`/changelog`) is what flows into `llms.txt`, the search index, and
the agent-readability/sitemap metadata — so the changelog stays fully
searchable while living at the root.

For an input file `changelog/v1.mdx`:

| Artifact | Path / value |
| --- | --- |
| **Internal generated copy** (the canonical conversion output) | `public/docs/changelog/v1.md` |
| **Public mirror** (served to humans/agents at the chosen prefix) | `public/changelog/v1.md` |
| **Canonical URL agents see** | `https://example.com/changelog/v1` (markdown at `https://example.com/changelog/v1.md`) |

### How that happens, step by step

1. **Staging / conversion.** Both sources are merged into a single docs tree.
   The primary `docs` source mounts at path-prefix `""`; the `changelog` source
   gets path-prefix `changelog` (from its folder basename). MDX is flattened and
   written under `public/docs/...`, so `changelog/v1.mdx` becomes the internal
   copy `public/docs/changelog/v1.md`.

2. **Public mirror.** Because the mount's URL prefix (`/changelog`) differs from
   the prefix it would have under `docs` (`/docs/changelog`), leadtype copies the
   generated markdown out of `public/docs/changelog/` into `public/changelog/`.
   That mirror is the file served at the public `/changelog/...` URLs.

3. **Canonical URL + search.** URL resolution maps the file through its mount,
   producing `/changelog/v1` (and the markdown sibling `/changelog/v1.md`). That
   same `/changelog` prefix is fed to `llms.txt`, `llms-full.txt`, the static
   `search-index.json`, the sitemap, and the agent-readability manifest — so the
   changelog pages are indexed and discoverable, just under `/changelog/...`
   instead of `/docs/changelog/...`.
