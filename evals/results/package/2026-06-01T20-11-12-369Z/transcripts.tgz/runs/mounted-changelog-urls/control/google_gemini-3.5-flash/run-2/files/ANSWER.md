# Configured Leadtype Routing for `/changelog`

To serve pages from a sibling `changelog/` directory under `/changelog/...` rather than `/docs/changelog/...` on the generated site, while keeping them searchable, we leverage `leadtype`'s multi-source mount capability.

---

### 1. The `leadtype generate` Invocation

Run the following command to generate the pipeline outputs:

```bash
npx leadtype generate --src . --out public --base-url https://example.com --docs-dir docs --docs-dir changelog=/changelog
```

*(Note: If using `pnpm` or `yarn`, replace `npx` with your package runner of choice. You can customize the `--base-url` as appropriate for your production domain).*

---

### 2. Output and Routing Pipeline Behavior for `changelog/v1.mdx`

When `changelog/v1.mdx` is processed by the command above, `leadtype` performs the following steps and emits these artifacts:

#### **A. Internal Generated Copy**
* **File Path:** `public/docs/changelog/v1.md`
* **How it is created:** 
  During staging, `leadtype` merges the configured sources into a temporary workspace.
  * The first source (`docs`) has no custom mount-path prefix and stages into the root of the temporary staging directory.
  * The second source (`changelog`) is detected as a custom source outside of `docs`. Since it is specified at index `1` with `--docs-dir changelog=/changelog`, it is assigned a staging mount path of `changelog`. Its files are staged under `<temp_root>/docs/changelog/v1.mdx`.
  
  Next, the MDX compiler (`convertAllMdx`) runs over the unified staging folder, flattening MDX components to clean Markdown and compiling the outputs directly into `public/docs/...`. Hence, the compiled internal target is emitted at `public/docs/changelog/v1.md`.

#### **B. Public Mirror**
* **File Path:** `public/changelog/v1.md`
* **How it is created:** 
  After MDX conversion, `leadtype` runs `copyMountedMarkdownMirrors(outDir, mounts)`. It loops over the mounted directories and compares their target URL prefix with the expected nested default (`/docs/changelog`). 
  
  Because the configured URL prefix `/changelog` is different from the default `/docs/changelog`, `leadtype` identifies that these files must be exposed at the root-level path. It mirrors/copies all converted `.md` files from `public/docs/changelog/` to the final public route at `public/changelog/`.

#### **C. Canonical URL Agents See**
* **Canonical URL (HTML/Rendered Page):** `https://example.com/changelog/v1`
* **Canonical Markdown URL (for LLMs / Agents):** `https://example.com/changelog/v1.md`
* **How it is resolved:** 
  When building search indexes, the `llms.txt` file, and agent-readability manifests, `leadtype` resolves relative file paths using the `resolveDocsPathMount` function:
  1. The relative path `changelog/v1.mdx` matches the `changelog` mount.
  2. The custom `urlPrefix` of `/changelog` is used to construct the routing path instead of the fallback `/docs` prefix.
  3. Index segments and extensions are stripped (converting `changelog/v1.mdx` to route segment `/changelog/v1`).
  4. Finally, the relative path is appended to the configured `--base-url` (e.g. `https://example.com`), producing the canonical absolute URLs above.
