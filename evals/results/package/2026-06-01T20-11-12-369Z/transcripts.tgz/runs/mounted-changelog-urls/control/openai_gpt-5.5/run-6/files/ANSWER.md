# Answer

```bash
leadtype generate --src . --out public --docs-dir docs --docs-dir changelog=/changelog --base-url https://your-site.example
```

The important part is the repeated `--docs-dir`. The first source (`docs`) remains mounted at `/docs`; the second source uses `changelog=/changelog`, which stages the `changelog/` source in the generated docs set but gives it a public URL prefix outside `/docs`.

For `changelog/v1.mdx`, site generation emits:

- Internal generated markdown copy: `public/docs/changelog/v1.md`
  - This is the staged copy used by leadtype's generated indexes/search pipeline.
- Public markdown mirror: `public/changelog/v1.md`
  - This is copied from the staged output because the mount's URL prefix is `/changelog` instead of the default `/docs/changelog`.
- Canonical agent-visible route: `/changelog/v1`
  - With the `--base-url` shown above, absolute agent metadata uses `https://your-site.example/changelog/v1`.
  - Agent markdown links point at the mounted mirror, e.g. `/changelog/v1.md`, not `/docs/changelog/v1.md`.

The page is still searchable because leadtype builds the search index from the internal `public/docs/...` markdown output, while applying the mount so the search document URL is `/changelog/v1`.
