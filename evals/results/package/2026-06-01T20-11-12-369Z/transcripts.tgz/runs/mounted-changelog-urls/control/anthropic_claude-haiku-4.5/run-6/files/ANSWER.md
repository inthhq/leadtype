# Mounting Changelog Under `/changelog/...`

## The Single `leadtype generate` Invocation

```bash
npx leadtype generate --src . --out public --base-url https://example.com \
  --docs-dir docs \
  --docs-dir changelog=/changelog
```

This tells `leadtype` to:
- Use `docs/` as the first source (mounted at `/docs` by default)
- Use `changelog/` as a second source, mounted at the URL prefix `/changelog` (not `/docs/changelog`)
- Generate all agent-facing artifacts (llms.txt, search index, robots.txt, sitemap) with awareness of both mounts

## Output Structure for `changelog/v1.mdx`

For a file at `changelog/v1.mdx`, the command produces:

### 1. **Internal Generated Copy** (staging directory during build)
```
public/docs/changelog/v1.md
```
This is the flattened markdown intermediate file in the internal staging path. Leadtype converts all `.mdx` to `.md` and places mounted sources under `docs/<mount-path>/`.

### 2. **Public Mirror** (served from the root of the canonical URL)
```
public/changelog/v1.md
```
After conversion, `leadtype` copies the markdown file from the internal staging location to match the canonical URL prefix, so agents and `Accept: text/markdown` requests fetch it here.

### 3. **Canonical URL Agents See**
```
https://example.com/changelog/v1
```
(or `https://example.com/changelog/v1.md` when requesting markdown explicitly)

This URL is:
- Embedded in the search index (`docs/search-index.json`)
- Listed in `docs/llms.txt` or `/llms.txt` under the appropriate section
- Included in agent-readability artifacts (`docs/agent-readability.json`)
- Indexed by `robots.txt` and `sitemap.xml`
- **Searchable** because the search index includes all mounts and resolves full canonical URLs

The mount configuration ensures `changelog/v1.mdx` is treated as a **first-class docs path** with searchability and agent discovery, just not under the `/docs/` subtree.
