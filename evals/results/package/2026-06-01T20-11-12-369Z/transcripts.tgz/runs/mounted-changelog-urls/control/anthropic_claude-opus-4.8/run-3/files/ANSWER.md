# Serving `changelog/` under `/changelog/...`

## 1. The single `leadtype generate` invocation

```bash
leadtype generate --docs-dir docs --docs-dir changelog=/changelog --base-url https://example.com
```

- `--docs-dir docs` keeps the normal docs folder mounted at the site root for docs (`/docs/...`).
- `--docs-dir changelog=/changelog` mounts the sibling `changelog/` folder at the URL
  prefix `/changelog` instead of the default `/docs/changelog`.
  The `<dir>=<url-prefix>` form is exactly what the CLI provides for "mount a
  source outside `/docs`."
- `--base-url` is only needed for absolute links in the site-mode artifacts
  (`llms.txt`, sitemaps, search index); swap in your real production URL.

Because both sources are passed to `generate` in one run, everything — the
flattened markdown, `llms.txt`, `llms-full.txt`, the sitemaps, and the static
`search-index.json` — is built over the union of `docs/` **and** `changelog/`,
so the changelog stays fully searchable.

> Note on path resolution: the `=/changelog` URL prefix is honored, but the
> staging *mount path* is derived from the source folder's basename
> (`changelog`). That means the internal generated copy is always staged under
> `docs/changelog/...` first and then mirrored out to the public prefix. Keep
> the folder named `changelog` (don't rename it to collide with another mount).

## 2. What it emits for `changelog/v1.mdx`

Given the output root `public/` (the default `--out`), the file `changelog/v1.mdx`
produces three things:

### a. Internal generated copy (canonical on-disk markdown)

```
public/docs/changelog/v1.md
```

`convertAllMdx` always writes flattened markdown into `<out>/docs/`, placing
mounted sources under their mount path (`changelog`). This is the copy the
search index, `llms.txt`, and sitemap entries are generated from.

### b. Public mirror (served at the real prefix)

```
public/changelog/v1.md
```

Since the requested URL prefix (`/changelog`) differs from the default
(`/docs/changelog`), `copyMountedMarkdownMirrors` copies every `.md` file from
`public/docs/changelog/` to `public/changelog/`. This mirror is what backs the
public `/changelog/...` routes and the `Accept: text/markdown` responses.

### c. Canonical URL agents see

```
/changelog/v1
```

`toDocsUrlPath` resolves the `changelog` mount to URL prefix `/changelog` and
strips the extension, yielding `/changelog/v1` (the markdown variant agents
fetch is `/changelog/v1.md`). With `--base-url https://example.com` the absolute
canonical URL is:

```
https://example.com/changelog/v1
```

So agents and the search index reference the page under `/changelog/v1` — never
`/docs/changelog/v1` — while the page remains in the same crawl/search scope as
the rest of the docs.
