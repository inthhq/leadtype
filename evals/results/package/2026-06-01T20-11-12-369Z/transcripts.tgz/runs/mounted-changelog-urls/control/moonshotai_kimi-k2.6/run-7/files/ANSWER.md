# Mounting `changelog/` under `/changelog/…`

## 1. Single `leadtype generate` invocation

Pass both source folders with `--docs-dir`, using `<dir>=<url-prefix>` for the mount that should live outside `/docs`.

```bash
npx leadtype generate \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://your-domain.com
```

* `--docs-dir docs` is required because as soon as you pass any `--docs-dir` flag the default `docs` folder is no longer assumed automatically.
* `changelog=/changelog` tells leadtype to treat the `changelog/` directory as a separate collection mounted at URL prefix `/changelog`.
* The command is still a single `generate` run, so search indexing, `llms.txt`, sitemaps, and the agent-readability manifest all include the changelog pages automatically.

## 2. What gets emitted for `changelog/v1.mdx`

| Artifact | Path / URL | Why |
|----------|------------|-----|
| **Internal generated copy** | `public/docs/changelog/v1.md` | `convertAllMdx` flattens every MDX file into markdown and writes it under the merged `docs/` output tree. Because the changelog source is staged with mount path `changelog`, its files land inside `docs/changelog/`. |
| **Public mirror** | `public/changelog/v1.md` | After conversion, `copyMountedMarkdownMirrors` notices that the mount’s URL prefix (`/changelog`) differs from the default expected prefix (`/docs/changelog`). It copies the `.md` files from the internal `docs/changelog/` folder up to a root-level `changelog/` folder so they are served at `/changelog/v1.md`. |
| **Canonical URL agents see** | `https://your-domain.com/changelog/v1` | `toDocsUrlPath` resolves the mount, strips the `changelog/` path prefix and the file extension, and applies the custom URL prefix `/changelog`. This path appears in `llms.txt`, `search-index.json`, the sitemap, and `agent-readability.json` as the canonical page URL. (The markdown mirror URL—`/changelog/v1.md`—is also recorded, but the canonical page reference is `/changelog/v1`.) |
