# Serving `changelog/` under `/changelog/...`

## 1. The single command

```bash
leadtype generate --docs-dir docs --docs-dir changelog=/changelog --base-url https://example.com
```

Why this works:

- `leadtype generate` defaults to a single source folder, `docs`. The moment you
  want a second source folder beside it, you list **both** sources explicitly
  with repeated `--docs-dir` flags. The first `--docs-dir` is the *primary*
  source (mounted at the site root for docs, i.e. `/docs`); every later one is an
  additional mounted source.
- `--docs-dir` accepts a `<dir>=<url-prefix>` form. Passing
  `changelog=/changelog` mounts the `changelog/` folder at the **top-level**
  `/changelog` URL prefix instead of the default nested
  `/docs/changelog` it would otherwise get from its folder basename.
- Because the changelog is still passed through the normal `generate` pipeline,
  it is included in `llms.txt`, the `search-index.json`, the sitemap, and the
  agent-readability manifest — so it stays fully searchable.

(`--base-url` is included so the canonical/absolute URLs in `llms.txt`, the
search index, and the sitemap are correct. Swap in your real site URL. It is not
required for the routing behavior itself.)

If you'd rather keep this in config instead of flags, the equivalent is a
`leadtype.config.ts` with a `collections` map giving the changelog collection a
`prefix: "/changelog"` — but the task asked for the single `generate`
invocation, which is the command above.

## 2. What gets emitted for `changelog/v1.mdx`

With `changelog/v1.mdx` as input, the run produces three distinct things:

### a. The internal generated copy (staging layout, always under `docs/`)
```
public/docs/changelog/v1.md
```
Every source — primary or mounted — is flattened by the converter into the
canonical staging tree rooted at `<out>/docs/`. A mounted source keeps its mount
path (`changelog`, derived from the folder name) as a subfolder, so the
flattened markdown lands at `public/docs/changelog/v1.md`. This copy is what the
`llms.txt` / search / sitemap generators read, which is why the page stays
searchable.

### b. The public mirror (what the site actually serves)
```
public/changelog/v1.md
```
After conversion, leadtype mirrors any mounted source whose URL prefix differs
from its default (`/docs/<mountPath>`). Here the requested prefix `/changelog`
differs from the default `/docs/changelog`, so the markdown under
`public/docs/changelog/` is copied to `public/changelog/`. That places the
served file at `/changelog/v1.md` — **not** `/docs/changelog/v1.md`.

### c. The canonical URL agents see
```
/changelog/v1
```
(absolute: `https://example.com/changelog/v1`)

The page's canonical/HTML URL resolves through the mount to the `/changelog`
prefix plus the path with its `.mdx`/`index` suffix stripped, giving
`/changelog/v1`. Its markdown mirror that agents fetch (e.g. via
`Accept: text/markdown` or the entries in `llms.txt`) is the same path with a
`.md` suffix: `/changelog/v1.md`.

### Summary

| Artifact | Location / value |
| --- | --- |
| Internal generated copy | `public/docs/changelog/v1.md` |
| Public mirror (served) | `public/changelog/v1.md` |
| Canonical page URL | `/changelog/v1` (`https://example.com/changelog/v1`) |
| Markdown URL for agents | `/changelog/v1.md` |
