# Serving `changelog/` under `/changelog/...`

## 1. The command

```bash
leadtype generate --src . --out public --base-url https://example.com \
  --docs-dir docs \
  --docs-dir changelog=/changelog
```

The mechanism is the `--docs-dir <dir>=<url-prefix>` form documented in
`leadtype generate --help`:

> `--docs-dir <dir>` Docs source folder relative to `--src` (default: docs).
> Repeat to merge multiple folders. Use `<dir>=<url-prefix>` to mount a source
> outside `/docs`, e.g. `changelog=/changelog`.

Why both flags are needed:

- The **first** `--docs-dir` becomes the *primary* source with an empty mount
  path and the canonical `/docs` prefix, so you must list `docs` explicitly to
  keep your normal docs at `/docs/...`. (As soon as you pass any `--docs-dir`,
  the implicit default `docs` source is no longer added for you.)
- Every **subsequent** source is mounted under a folder named after its
  basename. The `=/changelog` suffix overrides the prefix that source would
  otherwise get (`/docs/changelog`) so the pages live at `/changelog/...`
  instead. Replace `--base-url` with your real production URL.

Set the URL prefix to anything that is not `/` — leadtype rejects mounting a
source at the site root.

## 2. What it emits for `changelog/v1.mdx`

Internally leadtype always converts every source into the staging docs tree
(`<out>/docs/...`), keyed by mount path, and then mirrors any source whose URL
prefix differs from the default `/docs/<mount>` location to its public path.

For `changelog/v1.mdx` with `--out public`:

| Artifact | Path / value |
| --- | --- |
| **Internal generated copy** (canonical conversion output, also what feeds search & `llms.txt`) | `public/docs/changelog/v1.md` |
| **Public mirror** (the copy actually served at the requested prefix) | `public/changelog/v1.md` |
| **Canonical URL agents see** (page URL; markdown mirror is this + `.md`) | `/changelog/v1` &nbsp;→&nbsp; `https://example.com/changelog/v1` (markdown at `/changelog/v1.md`) |

How that falls out of the pipeline:

- `resolveDocsSources` gives the `changelog` source `mountPath = "changelog"`
  and `urlPrefix = "/changelog"`.
- `convertAllMdx` writes the flattened markdown into the staging docs tree at
  `public/docs/changelog/v1.md` — this is the internal copy that the search
  index, `llms.txt`, `llms-full.txt`, and sitemap are all built from, so the
  changelog stays fully searchable.
- `copyMountedMarkdownMirrors` notices the mount's URL prefix (`/changelog`)
  is **not** the default `/docs/changelog`, so it copies the rendered markdown
  out to `public/changelog/v1.md`, the public mirror under the requested route.
- `toDocsUrlPath` resolves the canonical page URL using the mount: the
  `changelog/` prefix is stripped and the `/changelog` prefix applied, yielding
  `/changelog/v1` (and the agent-facing markdown URL `/changelog/v1.md`).

A root `changelog/index.mdx` would mirror to `public/changelog/index.md` with
canonical URL `/changelog` and markdown URL `/changelog/index.md`.
