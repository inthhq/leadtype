# Serving `changelog/` under `/changelog/...`

## 1. The single command

```bash
leadtype generate --src . --base-url https://example.com \
  --docs-dir docs \
  --docs-dir changelog=/changelog
```

The mechanism is `leadtype generate`'s repeatable `--docs-dir` flag, which
accepts the `<dir>=<url-prefix>` mount form (see `leadtype generate --help`:
"Use `<dir>=<url-prefix>` to mount a source outside /docs, e.g.
`changelog=/changelog`").

- The **first** `--docs-dir docs` is the primary source. It keeps the default
  `/docs` URL prefix and an empty mount path. (If `docs` is already your only
  other source you can keep it explicit as shown, or rely on the implicit
  default — but once you add a second `--docs-dir` you should list both so the
  intent is clear.)
- The **second** `--docs-dir changelog=/changelog` mounts the sibling
  `changelog/` folder and **remaps its URL prefix to `/changelog`** instead of
  the default `/docs/changelog`.

Notes:
- The URL prefix must not be the site root (`/`); `/changelog` is fine.
- Add `--base-url` so the generated `llms.txt`, sitemap, and agent-readability
  artifacts emit absolute canonical URLs.
- Because there are now multiple sources, leadtype stages them into a temporary
  merged tree before converting — both folders still flow through the same
  pipeline, so changelog pages remain **searchable** (they're included in
  `search-index.json` / `search-content.json` and `llms.txt`).
- This is the CLI path. The equivalent config-file shape is a `collections`
  entry with `dir: "changelog"` and `prefix: "/changelog"`; you can't mix
  `--docs-dir` with a config that defines `collections`.

## 2. What it emits for `changelog/v1.mdx`

leadtype converts every source into `out/docs/...` first, then mirrors mounted
sources to their public URL prefix. So a single input file produces three
distinct things:

### Internal generated copy (staging-prefixed, always under `/docs`)
```
public/docs/changelog/v1.md
```
This is the canonical flattened-markdown artifact leadtype writes during
conversion. The mount path (`changelog`) is preserved here, so the internal copy
lives at `docs/changelog/v1.md`. This copy is what feeds search and the
`llms`/sitemap generators.

### Public mirror (served at the remapped prefix)
```
public/changelog/v1.md
```
Because the mount's URL prefix (`/changelog`) differs from the default
(`/docs/changelog`), `copyMountedMarkdownMirrors` copies the markdown out of
`docs/changelog/` into a top-level `changelog/` directory. This is the file that
actually answers requests to `/changelog/v1.md` (the `Accept: text/markdown` /
agent-readable mirror). Your site UI renders the human HTML page at the same
public path, `/changelog/v1`.

### Canonical URL agents see
```
/changelog/v1
```
Resolved by `toDocsUrlPath` against the mount `{ pathPrefix: "changelog",
urlPrefix: "/changelog" }`: it strips the `changelog/` path prefix, drops the
`.mdx` extension, and prepends the mounted URL prefix. The matching markdown
mirror URL is `/changelog/v1.md`. With `--base-url https://example.com`, the
absolute canonical URL recorded in `llms.txt`, the sitemap, and the
agent-readability manifest is `https://example.com/changelog/v1` — **not**
`/docs/changelog/v1`.
