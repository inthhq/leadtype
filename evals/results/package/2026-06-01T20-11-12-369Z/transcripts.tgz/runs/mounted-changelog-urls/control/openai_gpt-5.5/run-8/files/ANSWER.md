# Answer

```sh
leadtype generate --src . --out public --docs-dir docs --docs-dir changelog=/changelog
```

The first `--docs-dir docs` keeps the normal docs mounted at `/docs`. The second repeated `--docs-dir` adds the sibling `changelog/` source and explicitly mounts it at `/changelog`.

For a source file such as `changelog/v1.mdx`, site generation stages/converts it under the generated docs tree, then mirrors it to the requested public mount:

- Internal generated copy used by leadtype artifacts/search: `public/docs/changelog/v1.md`
- Public markdown mirror to serve: `public/changelog/v1.md`
- Canonical page URL in agent/search metadata: `/changelog/v1`  
  Its markdown URL is `/changelog/v1.md`, not `/docs/changelog/v1.md`.

Because the search index is built from the internal generated docs tree with the mount table applied, the changelog page is included in `public/docs/search-index.json`/`search-content.json` while resolving to `/changelog/v1`.
