# Mounted changelog answer

## 1. Single `leadtype generate` invocation

```bash
npx leadtype generate \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

* `--docs-dir docs` keeps the default docs folder emitted under `/docs/…`.
* `--docs-dir changelog=/changelog` tells leadtype to treat the `changelog/` directory as a **mounted source** with its own URL prefix (`/changelog`).
* Because the URL prefix is not the default `/docs/changelog`, leadtype automatically mirrors the rendered markdown into `public/changelog/` so the pages are served at the custom path.
* The search index is still built from the internal `public/docs/` tree, so changelog pages remain searchable.

## 2. What gets emitted for `changelog/v1.mdx`

| Artifact | Location | Notes |
|---|---|---|
| **Internal generated copy** | `public/docs/changelog/v1.md` | This is the flattened markdown produced by `convertAllMdx`. It lives inside the main `docs/` output tree because the source mirror stages mounted folders under `docs/<mountPath>/` during generation. |
| **Public mirror** | `public/changelog/v1.md` | `copyMountedMarkdownMirrors` detects that the mount’s URL prefix (`/changelog`) differs from the default (`/docs/changelog`) and copies the `.md` file to the custom path. This is what an HTTP agent (or a human) fetches when requesting `/changelog/v1.md`. |
| **Canonical URL agents see** | `https://example.com/changelog/v1.md` (markdown mirror) and `https://example.com/changelog/v1` (page URL) | `llms.txt`, `agent-readability.json`, and the search index all resolve paths via `toDocsUrlPath` using the mount map, so agents see the changelog at the `/changelog/…` namespace—not under `/docs/changelog/…`. |
