# Serving `changelog/` under `/changelog/...`

## 1. Single `leadtype generate` invocation

```bash
npx leadtype generate \
  --src . \
  --out public \
  --base-url https://example.com \
  --docs-dir docs \
  --docs-dir changelog=/changelog
```

* `--docs-dir docs` keeps the main docs tree mounted at `/docs` (the default).
* `--docs-dir changelog=/changelog` mounts the sibling `changelog/` folder at the URL prefix `/changelog` instead of `/docs/changelog`.
* Both trees are merged into the same temporary source mirror, so the static search index covers changelog pages as well.

> Omitting `--docs-dir docs` would make `changelog` the primary source and mirror **everything** into `/changelog`, which is not what you want.

## 2. What gets emitted for `changelog/v1.mdx`

| Artifact | Path / URL |
|----------|------------|
| **Internal generated copy** (converted markdown) | `<out>/docs/changelog/v1.md` |
| **Public mirror** (edge-friendly markdown) | `<out>/changelog/v1.md` |
| **Canonical URL agents see** | `https://example.com/changelog/v1` |
| **Markdown mirror URL** | `https://example.com/changelog/v1.md` |

### How it works

1. **MDX → Markdown conversion**  
   `convertAllMdx` writes all flattened markdown into `<out>/docs/...` preserving the merged folder structure, so `changelog/v1.mdx` becomes `<out>/docs/changelog/v1.md`.

2. **Public mirror**  
   `copyMountedMarkdownMirrors` notices that the mount’s `urlPrefix` (`/changelog`) differs from the default `/docs/changelog`. It copies every `.md` file from `<out>/docs/changelog/` into `<out>/changelog/`, making the page servable at `/changelog/v1.md`.

3. **Canonical URL**  
   The agent-readability manifest (`agent-readability.json`) and the search index both resolve the page through the mount map. The `urlPath` is `/changelog/v1`, so:
   * `absoluteUrl` = `https://example.com/changelog/v1`
   * `markdownAbsoluteUrl` = `https://example.com/changelog/v1.md`

   Framework adapters (e.g. `createGenerateMetadata` in Next.js) emit `<link rel="canonical" href="https://example.com/changelog/v1">` and the `text/markdown` alternate at `…/v1.md`.
