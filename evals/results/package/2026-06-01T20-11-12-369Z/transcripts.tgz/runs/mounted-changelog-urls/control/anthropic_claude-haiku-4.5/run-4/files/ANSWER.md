# Mounting Changelog Pages Outside `/docs`

## Single `leadtype generate` Invocation

```bash
npx leadtype generate \
  --src . \
  --out public \
  --base-url https://yoursite.com \
  --docs-dir docs \
  --docs-dir changelog=/changelog
```

The key flag is `--docs-dir changelog=/changelog`, which:
- Reads MDX from the `changelog/` folder on disk
- Mounts it at the `/changelog` URL prefix (not `/docs/changelog`)
- Keeps all pages searchable (included in `search-index.json`, `llms.txt`, and agent-readability metadata)

---

## What It Emits

For a file like `changelog/v1.mdx`:

### Internal Generated Copy
**Location:** `public/docs/changelog/v1.md`

This is the flattened markdown (MDX → markdown after component conversion) stored in the standard docs staging directory. It's created during the initial conversion pass.

### Public Mirror
**Location:** `public/changelog/v1.md`

After the internal copy is generated, leadtype copies the markdown files from `public/docs/changelog/` to `public/changelog/` to match the mounted URL structure. This is the human-readable file served at the mounted path.

### Canonical URL (Agent-Visible)
**URL:** `https://yoursite.com/changelog/v1`

The `urlPath` recorded in frontmatter and used by agents, search indexes, and generated metadata. Resolved using the mounts configuration:
- Page lives at `docs/changelog/v1.md` (internal)
- Mount maps path prefix `changelog` → URL prefix `/changelog`
- Result: `urlPath = /changelog/v1`

This URL appears in:
- `public/docs/search-index.json` — used for the static search index
- `public/docs/agent-readability.json` — used by agents discovering pages
- `public/llms.txt` and `public/docs/llms.txt` — agent-facing navigation indexes
- `public/changelog/v1.md` frontmatter and TOC anchors — all links updated to `/changelog/*`

---

## How Mounts Work (Implementation Detail)

The `--docs-dir <dir>=<url-prefix>` syntax creates a `DocsPathMount` pair:
- **pathPrefix**: relative staging path in `public/docs/` (e.g., `changelog`)
- **urlPrefix**: canonical URL prefix (e.g., `/changelog`)

During generation:
1. All source folders are merged into a temporary staging directory (`public/docs/`)
2. Conversion happens once; URLs rewritten via `toDocsUrlPath(relativePath, mounts)`
3. After conversion, `copyMountedMarkdownMirrors()` copies each mount's `public/docs/<pathPrefix>/*` to `public/<urlPrefix>/*`
4. Search indexes, `llms.txt`, and agent-readability metadata use the canonical `urlPrefix` URLs

**Result:** One file on disk, served at two paths, but agents and search always see the canonical `/changelog/...` URL.
