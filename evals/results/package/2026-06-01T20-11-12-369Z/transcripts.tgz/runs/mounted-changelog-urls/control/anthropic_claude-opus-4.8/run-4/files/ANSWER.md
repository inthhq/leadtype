# Serving `changelog/` under `/changelog/...`

Our repo layout:

```
docs/            ← main docs (served under /docs)
changelog/       ← changelog MDX, sibling of docs/
  v1.mdx
```

We want `changelog/*.mdx` published at `/changelog/...` (a top-level URL space,
**not** `/docs/changelog/...`) while still being indexed by the static search.

## 1. The `leadtype generate` invocation

```bash
leadtype generate \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --base-url https://leadtype.dev \
  --out public
```

Why this works:

- `leadtype generate` accepts **multiple** `--docs-dir` flags. They are merged
  into one output. The **first** `--docs-dir` is the primary source and mounts
  at the site root of the docs space (its files land directly under `/docs`).
  Every **additional** source is mounted under a sub-path named after its
  folder's basename.
- The `<dir>=<url-prefix>` form is the override that mounts a source **outside
  `/docs`**. The CLI help spells this out:
  *"Use `<dir>=<url-prefix>` to mount a source outside `/docs`, e.g.
  `changelog=/changelog`."* So `--docs-dir changelog=/changelog` says: take the
  `changelog/` folder and give its pages the public URL prefix `/changelog`.
- Without the `=/changelog` override, a second source `changelog` would default
  to the URL prefix `/docs/changelog` — exactly what we want to avoid.

Because `--docs-dir` is used, there must be **no `collections` block** in a
`leadtype.config.*` — collections fully describe their own sources and the CLI
rejects `--docs-dir` alongside them. (The equivalent collections-mode override
is `prefix: "/changelog"` on the collection.)

## 2. What it emits for `changelog/v1.mdx`

A single source MDX file `changelog/v1.mdx` produces three distinct things:

### a. The internal generated copy (the staging mount)

`leadtype` always flattens MDX to markdown into a canonical, `docs/`-rooted
layout first. The mount path for the `changelog` source is `changelog`, so the
flattened markdown is written to:

```
public/docs/changelog/v1.md
```

This is the internal/working copy. It is what the search-index builder,
`llms.txt`, `llms-full.txt`, the sitemap, and the agent-readability manifest are
all generated from. It exists regardless of the public mount.

### b. The public mirror (what humans/fetchers hit under /changelog)

Because the source's URL prefix (`/changelog`) differs from its default docs
location (`/docs/changelog`), `leadtype` mirrors the flattened markdown to the
requested public location:

```
public/changelog/v1.md
```

So a request for the markdown lives at `/changelog/v1.md`, and your site UI
renders the HTML page at `/changelog/v1`. The page never appears under
`/docs/changelog/...` in the public URL space.

### c. The canonical URL agents see

Every artifact that records URLs (search index `search-index.json`,
`search-content.json`, `llms.txt`, `llms-full.txt`, sitemap, and the
`agent-readability.json` manifest) resolves the page through the mount table
(`pathPrefix: "changelog"` → `urlPrefix: "/changelog"`). So the canonical
URL recorded for `changelog/v1.mdx` is:

```
https://leadtype.dev/changelog/v1
```

with its markdown companion at `https://leadtype.dev/changelog/v1.md`.

This is why the page stays **fully searchable**: the search index is built from
the internal `public/docs/changelog/v1.md` copy, but each entry's canonical URL
is rewritten to `/changelog/v1` via the mount. Searchers and agents are pointed
at the public `/changelog/...` URL, never at `/docs/changelog/...`.

## Summary table for `changelog/v1.mdx`

| Artifact | Location / value |
| --- | --- |
| Internal generated copy | `public/docs/changelog/v1.md` |
| Public markdown mirror | `public/changelog/v1.md` |
| Public HTML page | `/changelog/v1` |
| Canonical URL (search, llms.txt, sitemap, agent manifest) | `https://leadtype.dev/changelog/v1` |
