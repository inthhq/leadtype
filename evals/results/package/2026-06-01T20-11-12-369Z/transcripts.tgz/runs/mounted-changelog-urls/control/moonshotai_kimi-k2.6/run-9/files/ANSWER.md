# Mounting `changelog/` at `/changelog/...`

## 1. Single `leadtype generate` invocation

Because passing any `--docs-dir` overrides the default, you must explicitly list **both** the regular docs folder and the changelog folder with its desired URL prefix.

```bash
npx leadtype generate \
  --src . \
  --out public \
  --base-url https://example.com \
  --docs-dir docs \
  --docs-dir changelog=/changelog
```

* `--docs-dir docs` keeps the main docs tree under `/docs/...`.
* `--docs-dir changelog=/changelog` mounts the sibling `changelog/` folder so its pages are addressed as `/changelog/...` instead of `/docs/changelog/...`.
* `--base-url` is required so absolute canonical URLs can be written into `llms.txt`, the search index, and agent-readability artifacts.

## 2. What gets emitted for `changelog/v1.mdx`

Assuming the command above, leadtype produces three relevant artifacts for a source file at `changelog/v1.mdx`:

| Artifact | Path / URL | Explanation |
|---|---|---|
| **Internal generated copy** | `public/docs/changelog/v1.md` | `convertAllMdx` flattens the MDX into markdown and writes it into the default docs output tree, preserving the mount path (`changelog`) as a subdirectory. |
| **Public mirror** | `public/changelog/v1.md` | Because the mount’s URL prefix (`/changelog`) differs from the default `/docs/changelog`, `copyMountedMarkdownMirrors` copies the `.md` files into a folder that matches the custom prefix, making them directly servable at `/changelog/...`. |
| **Canonical URL agents see** | `https://example.com/changelog/v1` | This is the page’s canonical `urlPath` (used in the search index, `agent-readability.json`, and `llms-full.txt`). The markdown mirror — the `.md` link that `llms.txt` points agents to — is `https://example.com/changelog/v1.md`. |

The changelog pages remain fully searchable because `generateDocsSearchFiles` indexes every markdown file under the internal `public/docs/` tree, and the search entries reference the canonical `/changelog/...` paths.
