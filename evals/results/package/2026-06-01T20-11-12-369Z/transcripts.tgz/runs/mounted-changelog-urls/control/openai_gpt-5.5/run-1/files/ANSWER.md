# Answer

```bash
leadtype generate --src . --out public --base-url https://example.com --docs-dir docs --docs-dir changelog=/changelog
```

Replace `https://example.com` with the production origin for the generated site. The important part is that `docs` is listed first and `changelog` is mounted with an explicit URL prefix: `changelog=/changelog`. Running in the default site mode keeps the changelog included in the generated search artifacts.

For a source file such as:

```text
changelog/v1.mdx
```

leadtype stages that second docs source under the internal mount path `changelog`, then converts it like any other MDX page:

- Internal generated markdown copy: `public/docs/changelog/v1.md`
- Public mounted markdown mirror: `public/changelog/v1.md`
- Canonical page URL recorded for agents/search: `https://example.com/changelog/v1` (URL path: `/changelog/v1`)

So the changelog page is indexed and exposed as `/changelog/v1`, not `/docs/changelog/v1`; the `public/docs/changelog/v1.md` copy is the internal generated copy that powers the pipeline, while `public/changelog/v1.md` is the public mirror matching the mounted URL prefix.
