# Mounted Changelog Setup with Leadtype

To serve your changelog pages under `/changelog/...` rather than `/docs/changelog/...` while keeping them fully searchable, you can use the multiple `--docs-dir` mounting feature in `leadtype`.

---

## 1. The `leadtype generate` Invocation

To achieve this in a single invocation, run:

```bash
npx leadtype generate --docs-dir docs --docs-dir changelog=/changelog --base-url https://example.com --out public
```

### Explaining the Flags:
* `--docs-dir docs`: Declares the first docs source. Since it's the first element, its mount prefix is empty, routing its contents to `/docs` (e.g., `docs/index.mdx` becomes `/docs`).
* `--docs-dir changelog=/changelog`: Declares the second docs source. The key-value format `<dir>=<url-prefix>` mounts the local directory `changelog/` outside `/docs` so its compiled output routes directly to `/changelog/...` instead of `/docs/changelog/...`.
* `--base-url https://example.com`: Sets the absolute URL base used to resolve canonical search entries, `llms.txt` references, and readable agent paths.
* `--out public`: Specifies the public asset output directory.

---

## 2. Emitted Artifacts for `changelog/v1.mdx`

For a file located at `changelog/v1.mdx`, `leadtype generate` will emit the following output:

### A. The Internal Generated Copy
* **File path:** `public/docs/changelog/v1.md`
* **How it is made:** `leadtype` temporarily mounts the custom directories into a merged staging folder (staging `changelog/v1.mdx` as `temp/docs/changelog/v1.mdx`). It then compiles MDX to flattened Markdown (`convertAllMdx`), outputting it into the standard `<out>/docs/` subdirectory structure.

### B. The Public Mirror
* **File path:** `public/changelog/v1.md`
* **How it is made:** `leadtype` compares the custom `urlPrefix` (`/changelog`) with the expected default prefix (`/docs/changelog`). Since they differ, the utility `copyMountedMarkdownMirrors` copies the compiled Markdown file from the internal folder (`public/docs/changelog/v1.md`) to the mounted destination under the public directory (`public/changelog/v1.md`).

### C. The Canonical URL Agents See
* **Canonical Page URL (HTML):** `https://example.com/changelog/v1`
* **Canonical Markdown Mirror URL (for Agents):** `https://example.com/changelog/v1.md`
* **Details:** Any agent-oriented files (e.g., `llms.txt`, `llms-full.txt`, sitemaps, search-index metadata, or requests specifying `Accept: text/markdown`) will reference the absolute URL `https://example.com/changelog/v1.md` for this page, allowing AI search and coding agents to fetch the clean Markdown representation directly.
