# Serving `changelog/` under `/changelog/...`

## 1. `leadtype generate` invocation

```bash
npx leadtype generate \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://your-site.com
```

* `--docs-dir docs` keeps the primary docs collection at the default `/docs` prefix.  
* `--docs-dir changelog=/changelog` mounts the sibling `changelog/` folder with the custom URL prefix `/changelog`.  
* Repeat `--docs-dir` as many times as needed; order matters (the first source gets the empty mount path and therefore defaults to `/docs`).

## 2. What is emitted for `changelog/v1.mdx`

| Artifact | Path / Value | Explanation |
|---|---|---|
| **Internal generated copy** | `public/docs/changelog/v1.md` | `leadtype` always converts MDX → markdown into the output’s `docs/` tree first. Because the `changelog` source is staged with a mount path of `changelog`, the file lands here internally. |
| **Public mirror** | `public/changelog/v1.md` | When a source’s custom `urlPrefix` (`/changelog`) differs from the default inferred path (`/docs/changelog`), `leadtype` mirrors the `.md` files into the custom prefix directory so they are actually servable at `/changelog/...`. |
| **Canonical URL agents see** | `https://your-site.com/changelog/v1` | Search index entries, `llms.txt`, `sitemap.xml`, and the agent-readability manifest all resolve the page using the mount’s `urlPrefix` (`/changelog`) plus the stripped file path (`v1`). |

In short: the file is **searchable** because the search indexer consumes the mount table and indexes the page under `/changelog/v1`, while humans and HTTP agents can fetch the markdown mirror at `/changelog/v1.md`.
