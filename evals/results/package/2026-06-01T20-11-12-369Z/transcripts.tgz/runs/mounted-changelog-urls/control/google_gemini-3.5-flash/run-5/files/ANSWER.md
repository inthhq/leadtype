# Answer: Mounting Changelog under `/changelog/...` using `leadtype`

## 1. Single `leadtype generate` Invocation

To include both the standard `docs/` folder (served at `/docs/...`) and the `changelog/` folder (served directly at `/changelog/...`), you repeat the `--docs-dir` flag and use the `<dir>=<url-prefix>` syntax for the changelog folder:

```bash
npx leadtype generate --src . --docs-dir docs --docs-dir changelog=/changelog --out public --base-url https://example.com
```

### Options Breakdown:
- `--src .` specifies that the current working directory is the project root containing the folders.
- `--docs-dir docs` mounts the standard `docs/` directory under its default `/docs` URL prefix. (Note: Once `--docs-dir` is explicitly defined, you must specify all folders you want processed, as the default `docs` behavior is replaced).
- `--docs-dir changelog=/changelog` mounts the local `changelog/` folder under the `/changelog` URL prefix rather than the default `/docs/changelog`.
- `--out public` sets the output directory to `public/` (often served by frameworks or static hosts).
- `--base-url https://example.com` sets the canonical base URL utilized to generate absolute URLs in search indexes, sitemaps, and LLM text files.

---

## 2. Emitted Artifacts for `changelog/v1.mdx`

Given a source file at `changelog/v1.mdx`, the `leadtype` generator converts, mirrors, and indexes it as follows:

### A. Internal Generated Copy
* **Staging Mirror:** To combine the distinct directories safely, `leadtype` merges all sources under a temporary staging directory (e.g., `<temp>/docs/`). The `changelog/` files are placed inside `<temp>/docs/changelog/` based on their mount name.
* **Compiled Markdown file:** The MDX-to-Markdown compiler translates `changelog/v1.mdx` into flat, clean Markdown and writes it to the designated `docs` subfolder inside the main output directory.
* **Resulting Path:** **`public/docs/changelog/v1.md`**

### B. Public Mirror
* **Path Copying:** Because `/changelog` deviates from the default `/docs/changelog` prefix, `leadtype` copies the compiled Markdown from the internal output directory to the public output location to preserve matching clean URL structures for direct HTTP fetches.
* **Resulting Path:** **`public/changelog/v1.md`**
* **Purpose:** This file is publicly servable at `/changelog/v1.md`, enabling automated AI agents, HTTP clients requesting markdown, or tools reading the sitemap to retrieve the version of the documentation stripped of React/MDX components.

### C. Canonical URL Seen by Agents
* **Relative URL Path:** **`/changelog/v1`**
* **Absolute Canonical URL:** **`https://example.com/changelog/v1`** (this is the path indexed in `search-index.json`, the sitemaps, and sitemap tables).
* **Agent-Readable Markdown URL:** **`/changelog/v1.md`** (or `https://example.com/changelog/v1.md` absolutely; this is the URL reference included in sitemaps, search results, and `llms.txt` indexing for agents to fetch markdown directly).
