# Serving Changelog Under `/changelog/...` with Searchability

## The Single `leadtype generate` Invocation

```bash
npx leadtype generate --src . --out public --base-url https://example.com \
  --docs-dir docs \
  --docs-dir changelog=/changelog
```

**What this does:**
- `--docs-dir docs` — processes the main docs folder (served under `/docs/...`)
- `--docs-dir changelog=/changelog` — **mounts** the changelog folder with URL prefix `/changelog` instead of `/docs/changelog`
- Both sources are included in search, navigation, and agent-readable artifacts

## What It Emits for `changelog/v1.mdx`

### 1. Internal Generated Copy (MDX → Markdown)
```
public/docs/changelog/v1.md
```
This is the staging location created during the conversion pass. It's an intermediate file used during build—not served directly.

### 2. Public Mirror at the Canonical URL
```
public/changelog/v1.md
```
This is the **public-facing** file that agents and humans access. The mount configuration automatically mirrors converted files from `/docs/changelog/` to `/changelog/` after all transformations complete.

### 3. Canonical URL Agents See
```
https://example.com/changelog/v1
```
- In agent-readable artifacts (`llms.txt`, `/docs/llms.txt`, `AGENTS.md`, `sitemap.md`)
- In the static search index (`search-index.json`)
- In source maps and navigation structures passed to rendering frameworks
- In `robots.txt` and `sitemap.xml`

The **double-generation** pattern is intentional: MDX files are converted once under the staged `/docs/changelog/` path for build-time consistency, then mirrored to `/changelog/` based on the mount configuration. This ensures:
- **Single conversion pass** (consistent output, no duplicated processing)
- **Searchability** (search index includes both sources under their canonical URLs)
- **Flexibility** (navigation, breadcrumbs, and agent artifacts correctly reflect `/changelog/...` paths)

## How Mounts Work

The syntax `<dir>=<url-prefix>` tells leadtype:
- **`<dir>`** — the source folder relative to `--src` (e.g., `changelog`)
- **`<url-prefix>`** — the public URL prefix (e.g., `/changelog`, `/blog`, `/releases`)

This is a **path-to-URL mapping**. It does not rename folders; it remounts them. The changelog stays alongside docs in your repo:
```
.
├── docs/           (mounted at /docs)
├── changelog/      (mounted at /changelog, not /docs/changelog)
└── ...
```

After `--docs-dir docs --docs-dir changelog=/changelog`:
- Search results for changelog pages link to `/changelog/v1`, not `/docs/changelog/v1`
- Agents reading `llms.txt` see changelog under `/changelog/...`
- Your docs site can render these pages in a separate UI section or style them differently

## Fallback Without a Config File

If you don't have a `docs.config.ts` or `leadtype.config.ts`, the CLI works entirely from command-line flags. The above invocation is **self-contained** — no config needed.

## With a `docs.config.ts`

If you want to encode mounts in your config, you can use the **multi-collection shape**:

```typescript
// docs.config.ts
import { defineDocsConfig, defineCollection } from 'leadtype';

export default defineDocsConfig({
  product: {
    name: 'My Project',
    summary: 'Docs and changelog.',
  },
  collections: {
    docs: defineCollection({
      dir: 'docs',
      prefix: '/docs',
    }),
    changelog: defineCollection({
      dir: 'changelog',
      prefix: '/changelog',
    }),
  },
});
```

Then run:
```bash
npx leadtype generate --src . --out public --base-url https://example.com
```

The config fully describes both sources and their mounts. The CLI reads it automatically.
