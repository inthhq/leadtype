# Answer

```bash
npx leadtype generate --src . --out public --docs-dir docs --docs-dir changelog=/changelog --base-url https://your-site.example
```

Replace `https://your-site.example` with the site origin you want in absolute agent/search metadata. The important part is the repeated `--docs-dir`: `docs` remains mounted at `/docs`, while `changelog=/changelog` mounts the sibling `changelog/` source at `/changelog`.

For `changelog/v1.mdx`, leadtype stages that second source under the `changelog` mount and emits:

- **Internal generated copy:** `public/docs/changelog/v1.md`
  - This is the markdown produced by the MDX conversion pipeline. Search indexing reads from the generated `public/docs/**` tree, so this copy is what keeps the changelog page searchable.
- **Public mirror:** `public/changelog/v1.md`
  - Because the source was explicitly mounted as `/changelog`, leadtype mirrors the generated markdown out of `public/docs/changelog/` to the public URL prefix directory.
- **Canonical URL agents/search metadata see:** `/changelog/v1`
  - With the `--base-url` above, absolute metadata points at `https://your-site.example/changelog/v1`.
  - The markdown URL advertised to agents is `/changelog/v1.md`, not `/docs/changelog/v1.md`.

The search artifacts are still the normal site-mode outputs under `public/docs/search-index.json` and `public/docs/search-content.json`, but the changelog entry inside them uses the canonical `/changelog/v1` URL.
