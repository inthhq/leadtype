# Changelog beside docs — `leadtype generate` setup

## 1. Single invocation

```bash
npx leadtype generate \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --base-url https://<your-site>
```

- `--docs-dir` can be repeated to merge multiple source folders.
- The `<dir>=<url-prefix>` syntax (e.g. `changelog=/changelog`) tells leadtype to mount that source outside the default `/docs` tree.
- `--out` defaults to `public`, and `--src` defaults to `.`, so they can be omitted if those defaults match your repo layout.

## 2. What is emitted for `changelog/v1.mdx`

| Artifact | Location / URL | How it is produced |
|----------|----------------|--------------------|
| **Internal generated copy** | `public/docs/changelog/v1.md` | `convertAllMdx` flattens the MDX and writes it into the default docs output tree, preserving the mount-path sub-directory. |
| **Public mirror** | `public/changelog/v1.md` | `copyMountedMarkdownMirrors` copies the flattened markdown from `public/docs/changelog/` into a directory that matches the custom URL prefix (`/changelog`). Agents that send `Accept: text/markdown` can fetch it at `/changelog/v1.md`. |
| **Canonical URL agents see** | `https://<your-site>/changelog/v1` | The search index, `llms.txt`, sitemap, and `agent-readability.json` all register the page under this path. leadtype resolves the mount mapping (`changelog=/changelog`) via `toDocsUrlPath`, so the canonical `urlPath` is `/changelog/v1` and the `.md` mirror is derived from it. |

Because the search indexer (`generateDocsSearchFiles`) reads the internal copy and uses the same mount table, the changelog pages are fully searchable under `/changelog/…` without being nested under `/docs/changelog/…`.
