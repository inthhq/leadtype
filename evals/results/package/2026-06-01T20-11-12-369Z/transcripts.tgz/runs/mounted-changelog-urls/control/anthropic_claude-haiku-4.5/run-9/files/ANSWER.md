# Mounting Changelog Pages Outside `/docs`

## The Command

```bash
npx leadtype generate --docs-dir docs --docs-dir changelog=/changelog --out public --base-url https://example.com
```

## What It Emits

For a file like `changelog/v1.mdx`:

### 1. **Internal Generated Copy**
```
public/docs/changelog/v1.md
```
This is the intermediate flattened markdown, stored under the staging mount directory.

### 2. **Public Mirror** 
```
public/changelog/v1.md
```
This is automatically mirrored from the staging copy to match the canonical URL structure (via `copyMountedMarkdownMirrors`).

### 3. **Canonical URL for Agents**
```
/changelog/v1
```
This is the URL agents see in `llms.txt`, search indexes, and navigation metadata. It reflects the `=/changelog` mount prefix, **not** nested under `/docs/changelog/...`.

---

## How It Works

The `--docs-dir` flag accepts two syntaxes:

- **`<dir>`** — Defaults to `/docs/<dirname>` for sources after the first. The first source (typically `docs/`) defaults to `/docs`.
- **`<dir>=<url-prefix>`** — Explicitly sets the mounted URL prefix, allowing any path including root-level ones (e.g., `/changelog` instead of `/docs/changelog`).

In our case:
- `--docs-dir docs` → source at `docs/`, mounted to `/docs` (default)
- `--docs-dir changelog=/changelog` → source at `changelog/`, mounted to `/changelog` (explicit override)

The `mounts` array passed to the pipeline is:
```json
[
  { pathPrefix: "", urlPrefix: "/docs" },
  { pathPrefix: "changelog", urlPrefix: "/changelog" }
]
```

The `copyMountedMarkdownMirrors` function then:
1. Finds the internal copy at `public/docs/changelog/v1.md`
2. Mirrors it to the canonical location `public/changelog/v1.md`
3. Ensures all agent-facing URLs, search entries, and navigation use `/changelog/...`

---

## Search & Navigation

All generated artifacts respect the mount:

- **`llms.txt`** lists changelog pages under `/changelog/...` 
- **`search-index.json`** indexes pages with canonical URL `/changelog/v1`
- **`agent-readability.json`** includes the correct `urlPath` for agents
- **Navigation** (if defined) uses the canonical `/changelog/...` path

This allows agents and search engines to find and reference changelog content at its intended top-level URL while the build system keeps internal staging organized.
