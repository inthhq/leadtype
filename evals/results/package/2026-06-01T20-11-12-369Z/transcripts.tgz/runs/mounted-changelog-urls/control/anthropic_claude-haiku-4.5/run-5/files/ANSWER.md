# Mounting Changelog Outside `/docs/`

## Single `leadtype generate` Invocation

```bash
npx leadtype generate --src . --out public --base-url https://example.com \
  --docs-dir docs \
  --docs-dir changelog=/changelog
```

Or as a single line without line breaks:

```bash
npx leadtype generate --src . --out public --base-url https://example.com --docs-dir docs --docs-dir changelog=/changelog
```

## What It Emits

For a source file `changelog/v1.mdx`:

| Artifact | Location | Purpose |
|----------|----------|---------|
| **Internal Generated Copy** | `public/docs/changelog/v1.md` | Flattened markdown (intermediate stage used internally) |
| **Public Mirror** | `public/changelog/v1.md` | Public URL-prefixed copy, served at the canonical URL path |
| **Canonical URL** | `/changelog/v1` | URL agents and humans see (no `.md` extension in URLs) |

### How It Works

The `--docs-dir` flag accepts the syntax `<dir>=<url-prefix>`:

- **First invocation** (`--docs-dir docs`): Default behavior, no mount prefix → files go to `/docs/`
- **Second invocation** (`--docs-dir changelog=/changelog`): Mount `changelog/` folder to URL prefix `/changelog` → files go to `/changelog/` instead of `/docs/changelog/`

After conversion:
1. Both sources' MDX files are converted to markdown inside `public/docs/` (internal staging)
2. The `changelog` files at `public/docs/changelog/*` are **mirrored** to `public/changelog/*` to match the canonical URL prefix
3. The search index, `llms.txt`, and navigation see the canonical URL `/changelog/v1`
4. Agents reading `llms.txt` or the search index will find the file at `/changelog/v1.md`

### Example Output Structure

```
public/
├── docs/
│   ├── index.md                    (from docs/index.mdx)
│   ├── changelog/
│   │   └── v1.md                   (from changelog/v1.mdx, internal staging)
│   ├── llms.txt                    (references both /docs/* and /changelog/*)
│   └── search-index.json           (searchable under both paths)
├── changelog/
│   └── v1.md                       (public mirror, canonical URL)
└── llms-full.txt
```

The `mounts` configuration passed internally is:
```javascript
[
  { pathPrefix: "", urlPrefix: "/docs" },           // docs folder
  { pathPrefix: "changelog", urlPrefix: "/changelog" }  // changelog folder
]
```

This ensures:
- Files in `docs/` resolve to canonical URLs like `/docs/quickstart`
- Files in `changelog/` resolve to canonical URLs like `/changelog/v1`
- All are searchable and agent-readable
- No duplication in the canonical URL or search index
