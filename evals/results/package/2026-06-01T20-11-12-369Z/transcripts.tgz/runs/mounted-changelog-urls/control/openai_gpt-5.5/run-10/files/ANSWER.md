# Answer

Use site mode with both source roots, explicitly mounting the sibling changelog folder at `/changelog`:

```bash
npx leadtype generate --src . --out public --docs-dir docs --docs-dir changelog=/changelog --base-url https://your-site.example
```

Replace `https://your-site.example` with the site origin you want in absolute agent/search metadata.

For `changelog/v1.mdx`, this produces:

- **Internal generated copy:** `public/docs/changelog/v1.md`
  - Leadtype still stages/normalizes all generated markdown under the internal `docs` output so the normal pipeline can build `llms-full.txt`, `public/docs/search-index.json`, `public/docs/search-content.json`, `agent-readability.json`, sitemap data, etc.
- **Public mounted markdown mirror:** `public/changelog/v1.md`
  - Because the second `--docs-dir` was declared as `changelog=/changelog`, leadtype mirrors the generated markdown out from the internal `/docs/changelog` location to the public `/changelog` URL space.
- **Canonical URL agents/search metadata see:** `https://your-site.example/changelog/v1`
  - The markdown URL path for the agent-readable mirror is `/changelog/v1.md`.
  - It is not canonicalized as `/docs/changelog/v1` or `/docs/changelog/v1.md`.
