# Serving `changelog/` under `/changelog/...`

## 1. The command

```bash
leadtype generate --docs-dir docs --docs-dir changelog=/changelog --base-url https://example.com
```

(Set `--base-url` to your real site URL. `--src`/`--out` keep their defaults of
`.` and `public`.)

### Why this works

`--docs-dir` accepts a `<dir>=<url-prefix>` form. The first `--docs-dir docs` is
the primary source and stays mounted at `/docs`. The second source,
`changelog=/changelog`, mounts the sibling `changelog/` folder at the URL
prefix `/changelog` instead of the default `/docs/changelog`.

Both sources are part of a single `generate` run, so every changelog page is
flattened, included in `llms.txt`/`llms-full.txt`, and indexed into
`docs/search-index.json` — i.e. it stays fully **searchable** even though it is
served outside `/docs`.

> Note: the URL prefix may not be the site root (`/`), and each mounted source
> must resolve to a distinct folder. `/changelog` satisfies both.

If you prefer config over flags, the equivalent is a `collections` entry in
`leadtype.config.ts` with `{ dir: "changelog", prefix: "/changelog" }`, then
just run `leadtype generate`.

## 2. What it emits for `changelog/v1.mdx`

For the source file `changelog/v1.mdx`, the run produces:

- **Internal generated copy** (the canonical staging location, always under
  `/docs`):
  `public/docs/changelog/v1.md`
  The converter stages every non-primary source under its mount path inside
  `docs/`, so the flattened markdown is first written here.

- **Public mirror** (served at the requested prefix):
  `public/changelog/v1.md`
  Because the mount's URL prefix (`/changelog`) differs from the default it
  would otherwise get (`/docs/changelog`), leadtype copies the generated
  markdown out to the mirror directory that matches the public URL.

- **Canonical URL agents see:**
  `/changelog/v1`
  (with `--base-url`, the absolute form is `https://example.com/changelog/v1`).
  Its markdown twin is fetchable at `/changelog/v1.md`. This is the path that
  appears in `llms.txt`, the search index, and the agent-readability metadata —
  not `/docs/changelog/v1`.
