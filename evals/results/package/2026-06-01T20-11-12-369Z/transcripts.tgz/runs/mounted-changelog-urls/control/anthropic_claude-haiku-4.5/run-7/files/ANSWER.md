# Mounting Changelog Outside `/docs/`

## The Command

```bash
npx leadtype generate \
  --src . \
  --out public \
  --docs-dir docs \
  --docs-dir 'changelog=/changelog'
```

## What It Emits

For a file like `changelog/v1.mdx`:

### 1. **Internal Generated Copy** (`public/docs/changelog/v1.md`)
   - This is the *staging* location where leadtype writes all converted markdown files
   - MDX is flattened to markdown here
   - This is the canonical source for all agent-visible content

### 2. **Public Mirror** (`public/changelog/v1.md`)
   - This is the *mounted copy* that sits at the custom URL prefix
   - Leadtype automatically mirrors markdown files from the staging location to this custom path
   - This is what browsers and agents see when they visit `/changelog/...`

### 3. **Canonical URL for Agents** 
   - **In `llms.txt` and `AGENTS.md`:** `/changelog/v1`
   - **In search indices:** Indexed under `/changelog/v1`
   - **In sitemaps:** Listed at `/changelog/v1`
   - **In agent-readability metadata:** Canonical path is `/changelog/v1`

## How It Works

The `--docs-dir changelog=/changelog` syntax uses the `<dir>=<url-prefix>` mount syntax:
- `changelog` = source directory name (relative to `--src`)
- `/changelog` = URL prefix where pages are served (and where agents access them)

Leadtype's pipeline:
1. Copies `changelog/*.mdx` to internal staging at `public/docs/changelog/`
2. Converts MDX → markdown in that staging location
3. Detects the custom URL prefix (`/changelog` ≠ default `/docs/changelog`)
4. Automatically mirrors the converted `.md` files to `public/changelog/`
5. Writes all metadata (llms.txt, search-index.json, agent-readability.json) with canonical URLs pointing to `/changelog/v1`

Result: Your changelog is searchable and agent-accessible at `/changelog/...`, not `/docs/changelog/...`
