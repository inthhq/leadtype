# Mounted changelog URLs with leadtype

## 1. Single `leadtype generate` invocation

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

The key piece is `--docs-dir changelog=/changelog`.  
- The first `--docs-dir docs` is mounted at the generated docs root (`/docs/…`).  
- The second source, `changelog=/changelog`, keeps its own public URL prefix instead of being nested under `/docs/changelog/…`.

`--base-url` is required if you want fully-qualified canonical URLs in `llms.txt`, the sitemap, search metadata, and `agent-readability.json`. Omitting it leaves those as root-relative paths.

## 2. What gets emitted for `changelog/v1.mdx`

| Artifact | Path / URL | Purpose |
|----------|------------|---------|
| **Internal generated copy** | `public/docs/changelog/v1.md` | Converted markdown that the search index, runtime helpers, and other pipeline stages read from. This is what makes the page searchable even though it lives outside `docs/`. |
| **Public markdown mirror** | `public/changelog/v1.md` | Static file served directly at `/changelog/v1.md`. Agents requesting `Accept: text/markdown` or hitting the `.md` URL receive this file. |
| **Canonical URL agents see** | `/changelog/v1.md` (or `https://example.com/changelog/v1.md` with `--base-url`) | The link written in `llms.txt`, search metadata, sitemap entries, and `agent-readability.json`. The HTML canonical is `/changelog/v1` (or fully qualified with `--base-url`), while the markdown mirror—the URL agents actually fetch—is `/changelog/v1.md`. The generated markdown also receives a `canonical_url` frontmatter alias pointing back to the HTML page. |
