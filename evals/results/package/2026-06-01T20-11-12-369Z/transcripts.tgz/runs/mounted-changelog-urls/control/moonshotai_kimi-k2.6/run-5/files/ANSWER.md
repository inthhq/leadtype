# Mounted changelog under `/changelog/...`

## 1. The single `leadtype generate` invocation

```bash
npx leadtype generate \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

**Why this works:**
- `--docs-dir docs` keeps the default docs folder in the pipeline.
- `--docs-dir changelog=/changelog` mounts the sibling `changelog/` folder at the URL prefix `/changelog` instead of the default `/docs/changelog`.
- `--base-url` is required so that generated index files (llms.txt, sitemap, search) contain absolute canonical URLs.

If you omit `--docs-dir docs` and only pass the mount, the default docs folder is **not** included (`--docs-dir` replaces the default once used).

## 2. Emitted artifacts for `changelog/v1.mdx`

| Artifact | Location / Value | How it is produced |
|----------|------------------|--------------------|
| **Internal generated copy** | `public/docs/changelog/v1.md` | The pipeline stages all sources under a temporary `docs/` root. `convertAllMdx` flattens the MDX into markdown and writes it to the output docs tree using the staged relative path (`changelog/v1.md`). |
| **Public mirror** | `public/changelog/v1.md` | `copyMountedMarkdownMirrors` sees that the mount’s URL prefix (`/changelog`) differs from the default (`/docs/changelog`), so it mirrors the `.md` files from `public/docs/changelog/` into `public/changelog/`. Agents requesting `Accept: text/markdown` at `/changelog/v1` receive this file. |
| **Canonical URL agents see** | `/changelog/v1` (absolute: `https://example.com/changelog/v1`) | `toDocsUrlPath` resolves the staged relative path against the mounts table. Because the path starts with the `changelog` mount, the prefix `/changelog` is used instead of `/docs/changelog`. This URL appears in `llms.txt`, the sitemap, and the search index, so the page is fully searchable. |
