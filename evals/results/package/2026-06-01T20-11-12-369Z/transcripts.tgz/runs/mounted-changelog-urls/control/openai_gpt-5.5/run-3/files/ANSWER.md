# Mounted changelog output

Use the normal docs source first, then add the sibling changelog source with an explicit URL prefix:

```bash
leadtype generate --src . --out public --base-url https://example.com --docs-dir docs --docs-dir changelog=/changelog
```

Replace `https://example.com` with the site origin. The important part is the repeated `--docs-dir`: `docs` remains mounted at `/docs`, and `changelog=/changelog` mounts the sibling `changelog/` folder at `/changelog` instead of the default nested `/docs/changelog` prefix.

For `changelog/v1.mdx`, this emits:

- Internal generated markdown copy: `public/docs/changelog/v1.md`. Leadtype stages the second source under the `changelog/` mount inside the generated docs tree, and the search/LLM generation reads this internal copy.
- Public mounted markdown mirror: `public/changelog/v1.md`. Because the mount URL prefix is `/changelog`, leadtype mirrors the generated markdown there for the public site.
- Canonical page URL/path in generated agent/search metadata: `/changelog/v1` — absolute URLs use the supplied base URL, e.g. `https://example.com/changelog/v1`. Agent-facing markdown links point at the mounted mirror, e.g. `/changelog/v1.md`, not `/docs/changelog/v1.md`.

The generated search files still live under `public/docs/` (for example `public/docs/search-index.json` and `public/docs/search-content.json`), but entries for changelog pages use the mounted `/changelog/...` URL paths, so those pages remain searchable with the desired public URLs.
