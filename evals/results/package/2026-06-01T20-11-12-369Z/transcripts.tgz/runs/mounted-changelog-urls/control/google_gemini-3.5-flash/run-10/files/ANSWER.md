# Achieving Custom Changelog Mounts with Leadtype

To host your changelog pages under `/changelog/...` (instead of `/docs/changelog/...`) while keeping them searchable and indexed by agents, you can configure leadtype's source mounts.

---

### 1. The `leadtype generate` Invocation

Run the following command to generate the documentation pipeline with both the default `docs/` folder and the custom `changelog/` folder mounted:

```bash
leadtype generate --docs-dir docs --docs-dir changelog=/changelog --out public --base-url https://example.com
```

#### Flag Explanations:
- `--docs-dir docs`: Explicitly includes the primary `docs/` directory. (If any `--docs-dir` flag is provided, leadtype only uses the specified paths and no longer falls back to the default `docs/` folder).
- `--docs-dir changelog=/changelog`: Mounts the `changelog/` folder beside `docs/` and maps its URL path prefix to `/changelog`.
- `--out public`: Defines the destination output directory (defaults to `public`).
- `--base-url https://example.com`: Sets the absolute base URL of your site, which is required for sitemaps, robots.txt, and canonical agent URLs.

---

### 2. Emitted Artifacts and Canonical URL for `changelog/v1.mdx`

When leadtype processes the file `changelog/v1.mdx`, it outputs the following components:

#### 1. Internal Generated Copy
* **File Path:** `public/docs/changelog/v1.md`
* **Details:** During the conversion phase, the leadtype pipeline flattens all MDX sources into standard Markdown, maintaining the structured folder path in the staging area under the output `public/docs/` directory.

#### 2. Public Mirror
* **File Path:** `public/changelog/v1.md`
* **Details:** To serve the flat Markdown mirror under the correct public URL route, leadtype executes `copyMountedMarkdownMirrors`. It detects that `/changelog` is a custom-mounted prefix that differs from the default `/docs/changelog` prefix, and copies the compiled Markdown file to `public/changelog/v1.md`.

#### 3. Canonical URL
* **URL:** `https://example.com/changelog/v1`
* **Details:** Because the mount configuration maps the `changelog` path prefix to `/changelog`, the canonical path resolves to `/changelog/v1` (with no `.md` extension or index segment). Combined with the `--base-url`, coding agents and sitemaps will see `https://example.com/changelog/v1` as the canonical URL.
