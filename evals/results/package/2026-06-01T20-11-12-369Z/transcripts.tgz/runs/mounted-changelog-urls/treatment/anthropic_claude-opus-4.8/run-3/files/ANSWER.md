# Serving `changelog/` under `/changelog/...`

## 1. The command

Mount the sibling `changelog/` folder with its own public URL prefix using the
`--docs-dir <dir>=<url-prefix>` form:

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public
```

- The first `--docs-dir docs` is mounted at the generated docs root (`/docs`).
- `--docs-dir changelog=/changelog` merges the sibling `changelog/` folder into the
  same generated docs tree (so it's still indexed/searchable), **but** gives it the
  public URL prefix `/changelog` instead of `/docs/changelog`.

Add `--base-url https://your-site.com` if you want absolute canonical URLs in
`sitemap.xml`, `robots.txt`, search metadata, and full-context fallbacks.

## 2. What it emits for `changelog/v1.mdx`

For a source file `changelog/v1.mdx`, the `<dir>=<url-prefix>` mount produces three
distinct things:

| Artifact | Path / Value | Purpose |
|--|--|--|
| **Internal generated copy** | `public/docs/changelog/v1.md` | Lives inside the generated docs tree so search, the search index, and runtime helpers (e.g. `createDocsSource`) still find and index it. This is what keeps the changelog searchable. |
| **Public mirror** | `public/changelog/v1.md` | A static markdown mirror written under the requested URL prefix, so the page is actually served at `/changelog/...` rather than `/docs/changelog/...`. |
| **Canonical URL** | `/changelog/v1.md` | The link emitted in `llms.txt`, search metadata, `sitemap.xml` entries, and `agent-readability.json` — so agents and crawlers see the page at `/changelog/v1.md`, not `/docs/changelog/v1.md`. |

### Contrast with the plain form

Without the `=/changelog` suffix (i.e. `--docs-dir changelog`), the folder is mounted
under its own name *inside* docs: `changelog/v1.mdx` would become
`public/docs/changelog/v1.md` and be served at `/docs/changelog/v1.md`. The
`=<url-prefix>` form is what relocates the public/canonical URL to `/changelog/...`
while keeping the internal indexed copy under `public/docs/...` for search.

> Note: `--include` / `--exclude` still match docs-root-relative paths after the merge,
> e.g. `--include "changelog/**"`.
