# Serving `changelog/` under `/changelog/...`

## 1. The command

The repo keeps `changelog/` as a local sibling of `docs/`, so this is the
**multiple-local-folders** shape: repeat `--docs-dir`, and give the changelog
its own URL prefix with the `<dir>=<url-prefix>` form.

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

- The **first** `--docs-dir` (`docs`) is mounted at the generated docs root (`/docs`).
- The second source uses `changelog=/changelog`, which mounts the `changelog/`
  folder at the public URL prefix `/changelog` instead of nesting it under
  `/docs/changelog`.
- `--base-url` is what makes the canonical artifacts (sitemap, search metadata,
  `llms.txt`, agent-readability manifest) emit correct links — keep it for a
  real site build.

> Note: do **not** use a `leadtype.config.ts` with a `collections` map *and*
> `--docs-dir` at the same time — collections fully describe their sources and
> `--docs-dir` is rejected in that mode. If you ever switch to collections, the
> equivalent is `defineCollection({ dir: "./changelog", prefix: "/changelog" })`.

## 2. What it emits for `changelog/v1.mdx`

A prefixed mount (`changelog=/changelog`) produces three distinct things, which
is exactly what keeps the pages public-at-`/changelog` **and** searchable:

| Artifact | Path / value | Purpose |
|----------|-------------|---------|
| **Internal generated copy** | `public/docs/changelog/v1.md` | Stays under the docs root so search indexing and runtime helpers (`createDocsSource`, search-index/content, agent tools) still see and index the page. |
| **Public static mirror** | `public/changelog/v1.md` | A static markdown mirror written at the prefixed location so the page is actually served under `/changelog/...`. |
| **Canonical URL agents see** | `/changelog/v1` (markdown form `/changelog/v1.md`) | The link that appears in `llms.txt`, search metadata, `sitemap.xml`, and `agent-readability.json`. Agents are pointed at `/changelog`, never `/docs/changelog`. |

### Contrast: without the prefix

If you had written plain `--docs-dir changelog` (no `=/changelog`), the folder
would have nested under the docs root: `changelog/v1.mdx` → `public/docs/changelog/v1.md`
served at `/docs/changelog/v1`. Adding `=/changelog` is what relocates the public
mirror and the canonical links to `/changelog/...` while preserving the internal
copy for search.

### Filtering still works

`--include` / `--exclude` match docs-root-relative paths *after* the merge, so
you'd still target the changelog with e.g. `--include "changelog/**"`.
