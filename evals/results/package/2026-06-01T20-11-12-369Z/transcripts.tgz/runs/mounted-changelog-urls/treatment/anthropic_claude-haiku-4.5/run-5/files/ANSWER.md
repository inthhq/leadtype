# Mounting Changelog at `/changelog` Instead of `/docs/changelog`

## 1. The Single `leadtype generate` Invocation

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

The key is `--docs-dir changelog=/changelog`, which uses the `<dir>=<url-prefix>` syntax to mount the `changelog/` folder under a custom public URL prefix.

## 2. What It Emits for `changelog/v1.mdx`

For a source file like `changelog/v1.mdx`, leadtype generates three artifacts:

### Internal Generated Copy
**Location:** `public/docs/changelog/v1.md`

This copy is **not** served publicly. It lives in the `docs/` subdirectory so that:
- The search index can find and index it (keeping search results unified across all content)
- Runtime helpers and navigation can resolve it alongside the main docs
- It's included in `llms-full.txt` (the fallback full-context file for agents)

### Static Public Mirror
**Location:** `public/changelog/v1.md`

This is the **public-facing markdown file** served at the canonical URL. It's a static markdown mirror of the converted `.mdx`, searchable and readable by agents via HTTP requests for `/changelog/v1.md`.

### Canonical URL Agents See
**Canonical URL:** `/changelog/v1.md`

The canonical link that appears in:
- `llms.txt` entry points and navigation references
- `search-index.json` document metadata
- `search-content.json` snippets
- `sitemap.xml` and `sitemap.md`
- `agent-readability.json` manifest

This means agents will discover and link to `/changelog/v1.md`, not `/docs/changelog/v1.md`.

## Summary

The `<dir>=<url-prefix>` mount syntax creates a **dual-location setup**:
- **Internal:** Unified in `public/docs/` for search and navigation
- **Public:** Mirrored to the custom URL prefix for agent-discoverable serving
- **Searchable:** Indexed and fully findable despite the separate URL location

This is the same pattern leadtype uses for other standalone content like blog posts, tutorials, or API references that should live outside the main `/docs` tree while remaining searchable.
