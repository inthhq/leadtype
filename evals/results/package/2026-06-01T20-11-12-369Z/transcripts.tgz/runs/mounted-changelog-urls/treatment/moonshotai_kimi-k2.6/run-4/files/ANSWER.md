# Serving `changelog/` under `/changelog/...`

## 1. Single `leadtype generate` invocation

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

**Why this works:**
- `--docs-dir docs` mounts the main docs folder at the generated docs root (`/docs/...`).
- `--docs-dir changelog=/changelog` uses the `<dir>=<url-prefix>` syntax. It tells Leadtype to keep the changelog content searchable and mirrored internally, but to expose its canonical public URLs under `/changelog/...` instead of `/docs/changelog/...`.
- `--out public` writes all artifacts into the `public/` folder (or whichever directory your framework serves statically).
- `--base-url` is required so that sitemaps, `llms.txt`, search metadata, and `agent-readability.json` can emit absolute canonical URLs.

## 2. What gets emitted for `changelog/v1.mdx`

| Artifact | Path / URL | Purpose |
|----------|-----------|---------|
| **Internal generated copy** | `public/docs/changelog/v1.md` | The flattened markdown used by the search index and runtime helpers (e.g. `createDocsSource`, search hooks, agent-readability manifest). This is what makes the page searchable even though it is not surfaced under `/docs/changelog/...` to users. |
| **Public mirror** | `public/changelog/v1.md` | The static markdown mirror served at `https://example.com/changelog/v1.md`. Agents or users requesting `Accept: text/markdown` receive this file. |
| **Canonical URL agents see** | `https://example.com/changelog/v1.md` (or the path `/changelog/v1.md` in relative contexts) | `llms.txt`, `sitemap.xml`, search metadata, and `agent-readability.json` all point to `/changelog/v1.md` as the canonical location. The internal `public/docs/changelog/v1.md` copy is never advertised as the public URL—it exists only for indexing and runtime resolution. |

So the page remains fully searchable because the internal copy is indexed, but humans and agents discover it at the public mirror path `/changelog/v1.md`.
