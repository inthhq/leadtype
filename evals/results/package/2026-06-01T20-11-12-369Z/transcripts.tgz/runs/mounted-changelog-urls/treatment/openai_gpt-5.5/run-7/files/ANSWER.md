# Answer

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

Replace `https://example.com` with the site's real origin.

For `changelog/v1.mdx`, that mount does three relevant things:

- **Internal generated copy:** Leadtype still folds the changelog into the docs corpus at `public/docs/changelog/v1.md`. Search and runtime helper artifacts use this internal copy, so the page remains searchable.
- **Public markdown mirror:** Leadtype also writes a served mirror at `public/changelog/v1.md`, matching the requested `/changelog/...` public route.
- **Canonical URL agents see:** Agent-facing artifacts use the mounted `/changelog` URL, not `/docs/changelog`: with the base URL above, the page canonical is `https://example.com/changelog/v1`, and markdown links/alternates point at `https://example.com/changelog/v1.md`.