# Serving `changelog/` under `/changelog/...`

## 1. `leadtype generate` invocation

Use the `<dir>=<url-prefix>` syntax on the repeated `--docs-dir` flag so the sibling `changelog/` folder keeps its own public route while remaining part of the searchable corpus.

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

* `--docs-dir docs` mounts the primary docs folder at the generated docs root (`/docs/…`).
* `--docs-dir changelog=/changelog` mounts the sibling `changelog/` folder with its own URL prefix (`/changelog/…`) instead of nesting it under `/docs/changelog/…`.
* `--base-url` is required so that canonical artifacts (`llms.txt`, sitemap, search metadata, `agent-readability.json`) can emit fully qualified URLs.

## 2. What is emitted for `changelog/v1.mdx`

| Artifact | Path / URL |
|---|---|
| **Internal generated copy** | `public/docs/changelog/v1.md` — kept inside the generated docs tree so search indexes, runtime helpers, and the source primitive can still find and index the page. |
| **Public mirror** | `public/changelog/v1.md` — a static markdown mirror served directly at the requested public prefix. |
| **Canonical URL agents see** | `https://example.com/changelog/v1.md` (and the extension-less variant `/changelog/v1`) — written into `llms.txt`, `search-index.json`, `sitemap.xml`, and `agent-readability.json` as the canonical location for the page. |

In short: the page is searchable because the internal copy lives under `public/docs/changelog/v1.md`, but agents and site visitors are directed to the canonical `/changelog/v1.md` route.
