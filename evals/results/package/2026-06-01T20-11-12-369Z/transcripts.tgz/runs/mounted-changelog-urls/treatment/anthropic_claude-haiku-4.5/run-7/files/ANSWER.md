# Serving Changelog at `/changelog/...` with Searchability

## The Single `leadtype generate` Invocation

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://yourdomain.com
```

This achieves the goal: changelog pages are served at `/changelog/...` (not `/docs/changelog/...`) while remaining fully searchable.

## What Gets Emitted for `changelog/v1.mdx`

For a file like `changelog/v1.mdx`, leadtype generates three layers:

### 1. Internal Generated Copy (Search/Runtime)
- **Path**: `public/docs/changelog/v1.md`
- **Purpose**: Kept here for the search index and agent runtime helpers to find and index the content
- **Visibility**: Not served directly to users or agents; internal only

### 2. Public Mirror (Static Markdown for Agents)
- **Path**: `public/changelog/v1.md`
- **Purpose**: Static markdown mirror that agents and tools can fetch directly
- **Visibility**: Served under the custom URL prefix

### 3. Canonical URLs (Agent-Visible)
- **In `llms.txt`**: References point to `/changelog/v1`
- **In `agent-readability.json`**: Metadata declares canonical URLs as `/changelog/v1`
- **In `sitemap.xml`**: Entries list `/changelog/v1` (not `/docs/changelog/v1`)
- **In search metadata**: All search result links point to `/changelog/v1`

### Summary Table

| What | Path | Who sees it |
|------|------|------------|
| **Internal copy** | `public/docs/changelog/v1.md` | Search indexer, runtime helpers |
| **Public mirror** | `public/changelog/v1.md` | HTTP agents, `Accept: text/markdown` requests |
| **Canonical link** | `/changelog/v1` | Agents reading `llms.txt`, `agent-readability.json`, sitemap, search results |

## How the `=/changelog` Syntax Works

The `--docs-dir changelog=/changelog` syntax splits the folder mount into two parts:

- **Left side** (`changelog`): the local folder to read from
- **Right side** (`/changelog`): the public URL prefix for canonical links and output files

If you omit the prefix, the folder name becomes the mount prefix by default (`/docs/changelog`). With an explicit prefix, you override that behavior.

## Result: Searchable Under a Custom URL

Agents can:
1. Discover changelog pages via `/changelog` entries in `llms.txt`
2. Fetch markdown directly from `/changelog/v1.md`
3. Query the search index and receive results pointing to `/changelog/v1`

The search index includes all content from the changelog because the internal copy at `public/docs/changelog/...` is still generated and indexed—it just isn't the canonical public URL.
