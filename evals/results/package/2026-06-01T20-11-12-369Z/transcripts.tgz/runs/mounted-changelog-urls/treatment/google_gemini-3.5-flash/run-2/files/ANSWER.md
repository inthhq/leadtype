# Configured Multi-Source Mounting for Sibling Changelog

Here is how to configure `leadtype` to serve changelog pages under `/changelog/...` (not under `/docs/changelog/...`) while keeping them fully searchable and integrated.

---

### 1. The `leadtype generate` Invocation

Run the following command from the project root:

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

*(Note: Replace `https://example.com` with your production base URL to generate correct absolute links in sitemaps and agent manifests.)*

---

### 2. Emitted Output for `changelog/v1.mdx`

When `changelog/v1.mdx` is processed with the above command, `leadtype` generates:

1. **The Internal Generated Copy:**
   * **Path:** `public/docs/changelog/v1.md`
   * **Purpose:** This file is used internally by search (such as building the search index files under `public/docs/search-index.json` and `public/docs/search-content.json`) and by framework runtime helpers.

2. **The Public Mirror:**
   * **Path:** `public/changelog/v1.md`
   * **Purpose:** A static markdown copy written directly to the public mirror directory mapping to the specified route prefix.

3. **The Canonical URL Agents See:**
   * **URL:** `/changelog/v1.md` (or absolute URL `https://example.com/changelog/v1.md` / `/changelog/v1` depending on base URL and system configuration).
   * **Emitted in:** Generated canonical references, including `llms.txt`, sitemaps, search index metadata, and `agent-readability.json`.
