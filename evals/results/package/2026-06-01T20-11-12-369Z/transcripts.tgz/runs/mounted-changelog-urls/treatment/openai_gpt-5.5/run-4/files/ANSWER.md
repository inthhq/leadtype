# Answer

```bash
leadtype generate --src . --docs-dir docs --docs-dir changelog=/changelog --out public
```

`changelog=/changelog` mounts the sibling `changelog/` source folder at its own public URL prefix instead of under `/docs/changelog`.

For `changelog/v1.mdx`, site generation emits:

- **Internal generated copy for leadtype/search/runtime helpers:** `public/docs/changelog/v1.md`
- **Public static markdown mirror:** `public/changelog/v1.md`
- **Canonical URL agents see:** `/changelog/v1.md`

That canonical `/changelog/v1.md` path is what appears in agent-facing metadata such as `llms.txt`, search metadata, sitemap entries, and `agent-readability.json`, while the internal `public/docs/changelog/v1.md` copy remains available for search indexing.