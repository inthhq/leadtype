# Serving `changelog/` under `/changelog/...`

## 1. The command

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public
```

- The first `--docs-dir docs` is mounted at the generated docs root (the usual `/docs/...`).
- The second source uses the `<dir>=<url-prefix>` form (`changelog=/changelog`), which mounts the sibling `changelog/` folder under its own public URL prefix `/changelog` instead of nesting it beneath `/docs`.
- Because it's merged into the same generated docs tree (just remapped), the changelog pages still land in the search index and remain searchable.

If you used a plain `--docs-dir changelog` (no `=/changelog`), it would instead be mounted under the folder name and served at `/docs/changelog/...` — which is exactly what we want to avoid.

## 2. What it emits for `changelog/v1.mdx`

For an input file `changelog/v1.mdx`, the run produces three things:

| Artifact | Path / value | Purpose |
|----------|--------------|---------|
| **Internal generated copy** | `public/docs/changelog/v1.md` | Lives inside the generated docs tree so the static search index and runtime/source helpers can find it. |
| **Public mirror** | `public/changelog/v1.md` | A static markdown mirror written at the prefixed location, so the page is actually served at `/changelog/...`. |
| **Canonical URL agents see** | `/changelog/v1.md` | The link emitted in `llms.txt`, search metadata, sitemap entries, and `agent-readability.json`. |

So the page is discoverable/searchable via the internal copy under `/docs/...`, but every canonical/public reference points agents and the site at `/changelog/v1.md` rather than `/docs/changelog/v1.md`.
