# Serving Changelog Under `/changelog/...`

## 1. The Single `leadtype generate` Invocation

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://your-domain.com
```

**Key points:**
- `--docs-dir docs` — mounts the primary docs folder at the generated docs root (default mount at `/docs`)
- `--docs-dir changelog=/changelog` — uses the `<dir>=<url-prefix>` syntax to serve changelog under `/changelog` instead of `/docs/changelog`
- `--base-url` — required for canonical URL generation in agents-facing artifacts

## 2. What It Emits for `changelog/v1.mdx`

For a file like `changelog/v1.mdx`, the pipeline generates three artifacts:

### Internal Generated Copy
**Path:** `public/docs/changelog/v1.md`

This is the converted markdown file used for:
- Search indexing (`search-index.json`, `search-content.json`)
- Runtime helpers and search queries
- Full-context fallback copies

### Public Mirror
**Path:** `public/changelog/v1.md`

A static markdown mirror written to match the public URL prefix. Agents can fetch this directly without going through `/docs/`. It's searchable because the search index still includes it.

### Canonical URL in Agent Artifacts
**URLs emitted in:**
- `llms.txt` — `/changelog/v1.md`
- `llms-full.txt` — `/changelog/v1.md`
- `search-index.json` (metadata) — `/changelog/v1.md`
- `search-content.json` (full URLs) — `/changelog/v1.md`
- `sitemap.xml` — `https://your-domain.com/changelog/v1.md`
- `agent-readability.json` — `/changelog/v1.md`

**Result:** Agents see and fetch from `/changelog/v1.md` while the content remains searchable and properly indexed alongside the docs.

---

**Reference:** [CLI documentation — Multiple source folders with custom URL prefixes](https://leadtype.dev/docs/reference/cli#multiple-source-folders)
