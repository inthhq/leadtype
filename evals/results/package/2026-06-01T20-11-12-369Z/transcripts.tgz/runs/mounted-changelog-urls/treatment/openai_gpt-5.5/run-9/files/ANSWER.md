# Answer

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

Replace `https://example.com` with the site origin you publish from. The important part is the second `--docs-dir`: `changelog=/changelog` tells Leadtype to read the sibling `changelog/` source folder but mount it at the public `/changelog` URL prefix instead of the default `/docs/changelog` prefix.

For `changelog/v1.mdx`, that site-mode generation emits:

- **Internal generated copy:** `public/docs/changelog/v1.md`. Leadtype keeps this docs-tree copy for search and runtime/agent helper artifacts.
- **Public mounted markdown mirror:** `public/changelog/v1.md`, so the static file can be served from the changelog route.
- **Canonical URL agents see:** `/changelog/v1` for the page, with the markdown URL `/changelog/v1.md` in generated agent-facing metadata such as `llms.txt`, search metadata, sitemap entries, and `public/docs/agent-readability.json` — not `/docs/changelog/v1` or `/docs/changelog/v1.md`.

Because this is normal site mode, not `--bundle`, Leadtype also emits the searchable artifacts under `public/docs/search-index.json` and `public/docs/search-content.json`, using the mounted `/changelog/...` canonical URLs.