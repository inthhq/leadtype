# Changelog URL Configuration for leadtype

## 1. The Single `leadtype generate` Invocation

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

This uses the `<dir>=<url-prefix>` syntax on the second `--docs-dir` flag to mount the `changelog/` folder at the `/changelog` URL prefix instead of under `/docs`.

## 2. Output Details for `changelog/v1.mdx`

For a file like `changelog/v1.mdx`, leadtype emits:

### Internal Generated Copy
- **Path:** `public/docs/changelog/v1.md`
- **Purpose:** Kept internally for search indexing and agent runtime helpers
- **Format:** Flattened markdown (MDX components converted to text)

### Public Mirror (Static Markdown)
- **Path:** `public/changelog/v1.md`
- **Purpose:** Served directly to users and agents at the canonical URL prefix
- **Format:** Same flattened markdown as the internal copy

### Canonical URL Agents See
- **URL:** `/changelog/v1` (or `https://example.com/changelog/v1` in absolute form)
- **Appears in:**
  - `llms.txt` and `llms-full.txt` links
  - Search index metadata (`search-index.json`)
  - Sitemap entries (`sitemap.xml`)
  - Agent readability manifest (`agent-readability.json`)

### Search Indexing
- **Searchable:** ✅ Yes
- **Search index metadata:** References the canonical `/changelog/v1` URL
- **Search results point agents to:** The public mirror at `/changelog/v1.md`

---

**Key insight:** Leadtype maintains the internal copy at `public/docs/changelog/v1.md` for tooling integration, writes a static mirror at `public/changelog/v1.md`, and directs agents to the canonical `/changelog/v1` prefix in all metadata artifacts (search, sitemap, LLM files). This keeps the changelog searchable while serving it outside the `/docs/` tree.
