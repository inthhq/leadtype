# Answer

## 1. Single `leadtype generate` invocation

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public
```

The key is the `--docs-dir changelog=/changelog` mount syntax. It tells Leadtype to keep the changelog content searchable internally while giving it its own public URL prefix (`/changelog`) instead of nesting it under `/docs/changelog`.

(If you also need sitemap / robots canonical URLs, add `--base-url https://example.com`.)

## 2. What it emits for `changelog/v1.mdx`

| Artifact | Location / Value | Purpose |
|----------|------------------|---------|
| **Internal generated copy** | `public/docs/changelog/v1.md` | Converted markdown kept inside the docs tree so the search index, runtime helpers, and `agent-readability.json` can still find and index the page. |
| **Public mirror** | `public/changelog/v1.md` | Static markdown mirror served at the public path `/changelog/v1.md`. |
| **Canonical URL agents see** | `/changelog/v1.md` | Emitted in `llms.txt`, search metadata, sitemap entries, and `agent-readability.json` so agents and search crawlers discover the page at its standalone prefix, not under `/docs/`. |
