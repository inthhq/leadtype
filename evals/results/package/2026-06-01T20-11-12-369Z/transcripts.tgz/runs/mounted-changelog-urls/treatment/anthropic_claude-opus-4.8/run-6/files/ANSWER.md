# Serving `changelog/` under `/changelog/...`

## 1. The command

Mount the sibling `changelog/` folder at its own public URL prefix using the
`<dir>=<url-prefix>` form of `--docs-dir`:

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

- `--docs-dir docs` mounts the main docs folder at the generated docs root (`/docs`).
- `--docs-dir changelog=/changelog` adds the sibling `changelog/` folder but
  re-roots its **public** URL prefix to `/changelog` instead of the default
  `/docs/changelog`.
- Add `--base-url` so the canonical links written into `llms.txt`, search
  metadata, the sitemap, and `agent-readability.json` are correct. (Replace the
  example host with yours.)

Because both folders are passed through the pipeline, the changelog pages are
still converted, indexed, and included in search — they just answer at a
different URL.

## 2. What `changelog/v1.mdx` emits

For an input file `changelog/v1.mdx`, the run produces three things:

| Role | Path / value | Purpose |
|--|--|--|
| **Internal generated copy** | `public/docs/changelog/v1.md` | Kept under the docs root so the search index, `createDocsSource`, and other runtime/agent helpers can find it. This copy is *not* the public-facing one. |
| **Public mirror** | `public/changelog/v1.md` | A static markdown mirror written at the re-rooted prefix, so the file is actually served from `/changelog/...`, not `/docs/changelog/...`. |
| **Canonical URL agents see** | `/changelog/v1` (e.g. `https://example.com/changelog/v1`) | The link emitted in `llms.txt`, search metadata, sitemap entries, and `agent-readability.json`. Agents are pointed at `/changelog/...`, never `/docs/changelog/...`. |

So the page lives internally under `public/docs/changelog/` to stay searchable,
is mirrored publicly under `public/changelog/`, and every canonical/agent-facing
reference resolves to `/changelog/v1`.
