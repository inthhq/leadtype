# Mounting `changelog/` at `/changelog/...`

## 1. Single `leadtype generate` invocation

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

The `=<url-prefix>` syntax on the second `--docs-dir` flag tells leadtype to keep the changelog content searchable and indexed internally, while emitting public artifacts (markdown mirrors, sitemap entries, `llms.txt` links, and search metadata) under `/changelog/…` rather than `/docs/changelog/…`.

## 2. What it emits for `changelog/v1.mdx`

| Artifact | Path / URL | Purpose |
|----------|------------|---------|
| **Internal generated copy** | `public/docs/changelog/v1.md` | Flattened markdown kept inside the generated docs tree so the static search index and runtime helpers can still index and query the page. |
| **Public mirror** | `public/changelog/v1.md` | The static markdown mirror actually served to browsers and agents that request the page. |
| **Canonical URL agents see** | `https://example.com/changelog/v1.md` | The canonical path emitted in `llms.txt`, search metadata, `agent-readability.json`, and sitemap entries. Agents and SEO crawlers are pointed here, not to `/docs/changelog/v1.md`. |

Because the internal copy at `public/docs/changelog/v1.md` is still part of the generated docs tree, the changelog remains fully searchable even though its public URL lives under `/changelog/`.
