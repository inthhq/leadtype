# Mounted changelog URLs

## 1. Invocation

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

Repeat `--docs-dir` for each source folder. The first folder (`docs`) is mounted at the generated docs root; the second uses `<dir>=<url-prefix>` so that its pages keep their own public route (`/changelog/…`) instead of being nested under `/docs/changelog/…`.

## 2. Emissions for `changelog/v1.mdx`

| Artifact | Path / URL | Purpose |
|---|---|---|
| **Internal generated copy** | `public/docs/changelog/v1.md` | Lives inside the generated docs tree so search indexing and runtime helpers (e.g. `leadtype/search`) can still find and index the page. |
| **Public mirror** | `public/changelog/v1.md` | A static markdown mirror served directly at `/changelog/v1.md`. |
| **Canonical URL agents see** | `/changelog/v1` (and `/changelog/v1.md`) | Emitted in `llms.txt`, search metadata, sitemap entries, and `agent-readability.json` as the canonical location for the page. |
