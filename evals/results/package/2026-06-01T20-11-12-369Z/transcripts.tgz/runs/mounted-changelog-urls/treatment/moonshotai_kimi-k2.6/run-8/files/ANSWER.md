# Answer

## 1. Single `leadtype generate` invocation

```bash
leadtype generate --src . --docs-dir docs --docs-dir changelog=/changelog --out public
```

Repeating `--docs-dir` merges both folders into the same generated corpus.  
Writing the second source as `changelog=/changelog` keeps the changelog inside the unified docs tree so it remains searchable, while also mirroring it publicly under `/changelog` and making every canonical URL point there instead of `/docs/changelog`.

## 2. What it emits for `changelog/v1.mdx`

| What | Location |
|------|----------|
| **Internal generated copy** (for search index & runtime helpers) | `public/docs/changelog/v1.md` |
| **Public mirror** (static file served at `/changelog/…`) | `public/changelog/v1.md` |
| **Canonical URL agents see** (in `llms.txt`, search metadata, sitemap entries, and `agent-readability.json`) | `/changelog/v1.md` |
