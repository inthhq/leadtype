# Serving Changelog at `/changelog/...` Instead of `/docs/changelog/...`

## The Command

Use the `<dir>=<url-prefix>` syntax in `--docs-dir` to mount the changelog folder at a custom public URL prefix:

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url <your-site-url>
```

The key is `--docs-dir changelog=/changelog`, which tells leadtype to:
1. Read source files from the `changelog/` folder
2. Serve them publicly under `/changelog/...` instead of `/docs/changelog/...`

## What It Emits for `changelog/v1.mdx`

For a file like `changelog/v1.mdx`, the `leadtype generate` invocation above produces:

### Internal Generated Copy (for search/runtime)
- **Path:** `public/docs/changelog/v1.md`
- **Purpose:** Agent-readable markdown kept at a stable internal path for search indexing, `llms.txt` includes, and runtime helpers to locate.

### Public Mirror (static site serving)
- **Path:** `public/changelog/v1.md`
- **Purpose:** Directly mirrors the internal copy. Web servers can serve this to visitors at `/changelog/v1.md` without nested `docs/` routing.

### Canonical URL (agents see this)
- **In `llms.txt`:** `/changelog/v1`
- **In search metadata:** `/changelog/v1`
- **In `sitemap.xml`:** `/changelog/v1`
- **In `agent-readability.json`:** `/changelog/v1`
- **Purpose:** Agents read these artifacts and understand that the canonical, user-facing location is `/changelog/v1`, not `/docs/changelog/v1`.

---

## Summary

The `--docs-dir changelog=/changelog` mount ensures:
- ✅ Changelog is searchable (internal copy at `public/docs/changelog/v1.md` is indexed)
- ✅ Public URL is `/changelog/v1`, not `/docs/changelog/v1`
- ✅ Agents see `/changelog/v1` in all canonical links
- ✅ Static mirrors at `public/changelog/v1.md` can be served directly by the site
