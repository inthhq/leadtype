# Mounting Changelog Directories with Custom URL Prefixes in Leadtype

To serve a sibling `changelog/` folder right beside `docs/` under a custom `/changelog/...` path while keeping it fully searchable, use the following details.

## 1. The `leadtype generate` Invocation

Run the following command from your project root:

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

### Breakdown of flags:
* `--src .`: Declares that the current directory is the source root (containing the `docs` and `changelog` directories).
* `--docs-dir docs`: Mounts your primary `docs/` folder as the generated docs root.
* `--docs-dir changelog=/changelog`: Mounts the sibling `changelog/` directory and specifies the `<dir>=<url-prefix>` syntax, mapping its public URL prefix to `/changelog`.
* `--out public`: Specifies the output directory (e.g. `public/`).
* `--base-url https://example.com` *(optional/recommended for site mode)*: Supplies the base URL to generate correct absolute canonical sitemaps and agent indices.

---

## 2. Generated Outputs for `changelog/v1.mdx`

When `leadtype generate` processes the source file `changelog/v1.mdx`, it produces the following three outputs:

### A. The Internal Generated Copy
* **Path:** `public/docs/changelog/v1.md`
* **Purpose:** Kept within the main generated documentation tree, allowing search utilities and runtime helpers (e.g. navigation resolving) to correctly index and reference the file content.

### B. The Public Mirror
* **Path:** `public/changelog/v1.md`
* **Purpose:** Written as a static Markdown mirror directly at the custom path, matching the requested public prefix so that web clients and tools can access it at `/changelog/v1.md`.

### C. The Canonical URL Seen by Agents
* **URLs:** `/changelog/v1` and `/changelog/v1.md`
* **Locations:** These canonical URLs are emitted and mapped in the following generated artifacts instead of pointing to `/docs/changelog/v1.md`:
  * `llms.txt` and `llms-full.txt` (the agent indices)
  * Search metadata (`search-index.json` and `search-content.json`)
  * Sitemap entries (`sitemap.xml` and `sitemap.md`)
  * Agent Readability metadata (`agent-readability.json`)
