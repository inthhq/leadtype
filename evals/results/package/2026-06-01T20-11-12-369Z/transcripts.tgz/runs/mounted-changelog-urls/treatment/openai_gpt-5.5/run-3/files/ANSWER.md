```bash
leadtype generate --src . --docs-dir docs --docs-dir changelog=/changelog --out public --base-url https://example.com
```

Use your real site origin for `--base-url`.

For `changelog/v1.mdx`, `docs` remains the primary docs source and `changelog=/changelog` mounts the sibling changelog source at its own public prefix while still staging it inside the generated docs tree for search/runtime helpers:

- Internal generated/search copy: `public/docs/changelog/v1.md`
- Public markdown mirror: `public/changelog/v1.md`
- Canonical page URL agents/metadata see: `/changelog/v1` (or `https://example.com/changelog/v1` in absolute-URL artifacts)

The markdown mirror URL agents can fetch is `/changelog/v1.md`, but its canonical URL points at the mounted changelog page, not `/docs/changelog/v1`.
