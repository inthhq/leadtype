# Serving Changelog Under `/changelog/...` with Leadtype

## The Single Invocation

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://yourdomain.com
```

## What It Emits for `changelog/v1.mdx`

### Internal Generated Copy
- **Path:** `public/docs/changelog/v1.md`
- **Purpose:** Used internally by search indexing and runtime helpers
- **Not served directly to users**

### Public Markdown Mirror
- **Path:** `public/changelog/v1.md`
- **Purpose:** Static markdown file served directly to HTTP clients requesting `Accept: text/markdown`
- **Public URL:** `https://yourdomain.com/changelog/v1.md`

### Canonical URL in Agent Artifacts
- **Appears in:** `llms.txt`, search metadata, `sitemap.xml`, `robots.txt`, and `agent-readability.json`
- **Value:** `/changelog/v1` (or `https://yourdomain.com/changelog/v1`)
- **What agents see:** All agent-readable manifests and metadata point to `/changelog/v1`, not `/docs/changelog/v1`

## How It Works

The `--docs-dir changelog=/changelog` syntax:
1. **First part before `=`** (`changelog`) — the local source folder to read from
2. **Second part after `=`** (`/changelog`) — the public URL prefix where this content should be served

The pipeline:
- Reads all `.mdx` files from the `changelog/` folder
- Converts them to markdown
- Keeps a copy at `public/docs/changelog/v1.md` for search and internal helpers
- Writes the canonical public copy at `public/changelog/v1.md`
- Registers canonical paths (`/changelog/...`) in all agent-readable outputs
- The changelog content remains searchable because the internal copy feeds the search index

This keeps changelog content separate from the main docs tree on your public site while maintaining full search integration.
