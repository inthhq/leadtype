# Leadtype Changelog Prefix and Serving Configuration

This document outlines how to configure `leadtype` to serve changelog pages under `/changelog/...` (instead of `/docs/changelog/...`) while keeping them searchable on the generated site.

---

## 1. The Single `leadtype generate` Invocation

To achieve this, use the `<dir>=<url-prefix>` mount syntax with the `--docs-dir` option:

```bash
npx leadtype generate --src . --docs-dir docs --docs-dir changelog=/changelog --out public
```

*Note: You can optionally append `--base-url <your-site-url>` (e.g., `--base-url https://example.com`) to resolve absolute canonical links.*

---

## 2. Emitted Artifacts and Canonical URL for `changelog/v1.mdx`

Given a source file at `changelog/v1.mdx`, the generator emits the following artifacts and URLs:

1. **Internal Generated Copy:**
   * **Path:** `public/docs/changelog/v1.md`
   * **Role:** Used internally for search indexers/helpers, page metadata extraction, and runtime helpers.

2. **Public Mirror (Static Markdown Mirror):**
   * **Path:** `public/changelog/v1.md`
   * **Role:** Statically served at `/changelog/v1.md` for users/agents requesting raw markdown files.

3. **Canonical URL Agents See:**
   * **URL:** `/changelog/v1` (and `/changelog/v1.md`)
   * **Role:** Injected into `llms.txt`, the search index metadata (`search-index.json`/`search-content.json`), sitemap entries, and the `agent-readability.json` manifest.
