# Serving Changelog at `/changelog` while Maintaining Search

## 1. The Single `leadtype generate` Invocation

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

The key syntax is `changelog=/changelog`: this tells leadtype to mount the `changelog/` folder at the `/changelog` public URL prefix instead of nesting it under `/docs`.

## 2. What Gets Emitted for `changelog/v1.mdx`

For a file like `changelog/v1.mdx`, leadtype emits:

### Internal Generated Copy
- **Path:** `public/docs/changelog/v1.md`
- **Purpose:** Serves search indexing, runtime helpers, and the internal corpus. Kept here for consistency with the docs pipeline.

### Public Mirror
- **Path:** `public/changelog/v1.md`
- **Purpose:** The canonical static markdown mirror at the public URL prefix. Agents and content negotiation systems access this file.

### Canonical URL for Agents
- **Emitted in `llms.txt`, `search-index.json`, `agent-readability.json`, and `sitemap.xml`:** `/changelog/v1` (or `/changelog/v1.md` in markdown contexts)
- **Purpose:** Agents see the canonical, human-friendly changelog URL—not `/docs/changelog/v1`. Search metadata, sitemap entries, and agent-readability manifests all point here.

### Summary for a File Like `changelog/v1.mdx`

| Artifact | Location | Purpose |
|----------|----------|---------|
| Internal generated markdown | `public/docs/changelog/v1.md` | Search index, conversion pipeline, runtime traversal |
| Public markdown mirror | `public/changelog/v1.md` | Static file served to agents via content negotiation or direct HTTP |
| Canonical URL recorded | `/changelog/v1` in `llms.txt` et al. | Agents and search metadata point to this URL, not `/docs/changelog/v1` |
| Searchable | Yes (indexed from internal copy) | Included in `public/docs/search-index.json` under the `/changelog/v1` canonical URL |

This approach gives you the best of both worlds: a cleanly organized public surface under `/changelog/...` where agents can find versioned release notes, while the internal generated corpus stays under `/docs/` for a unified search index and runtime helpers.
