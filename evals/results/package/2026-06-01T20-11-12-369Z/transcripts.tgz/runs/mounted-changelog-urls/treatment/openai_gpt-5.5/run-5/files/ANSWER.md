# Answer

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

Replace `https://example.com` with the site’s real origin. This is site mode (no `--bundle`), so Leadtype still emits the search files under `public/docs/`.

For a source file such as `changelog/v1.mdx`, the mounted `--docs-dir changelog=/changelog` does this:

- Internal generated copy: `public/docs/changelog/v1.md` — kept in the generated docs tree for search and runtime/agent helpers.
- Public markdown mirror: `public/changelog/v1.md` — served as `/changelog/v1.md` instead of `/docs/changelog/v1.md`.
- Canonical URL agents see: `/changelog/v1` for the page, with markdown/discovery links using `/changelog/v1.md` where a markdown mirror URL is needed. In other words, `llms.txt`, search metadata, sitemap entries, and `agent-readability.json` point at the mounted `/changelog/...` URLs, not `/docs/changelog/...`.
