# Serving `changelog/` under `/changelog/...`

## 1. Single `leadtype generate` invocation

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

* `--docs-dir docs` keeps the main docs tree at the generated root (`/docs/...`).  
* `--docs-dir changelog=/changelog` mounts the sibling `changelog/` folder at its own public URL prefix instead of nesting it under `/docs/changelog/...`.  
* `--out public` and `--base-url` are included so that sitemap entries, search metadata, and agent-readability manifests get correct absolute URLs.

## 2. What gets emitted for `changelog/v1.mdx`

| Artifact | Location / Value |
|----------|------------------|
| **Internal generated copy** | `public/docs/changelog/v1.md` — kept inside the docs tree so search indexes, runtime helpers, and the source primitive can still find and index it. |
| **Public markdown mirror** | `public/changelog/v1.md` — written to the public route that matches the mount prefix, served directly at `/changelog/v1.md`. |
| **Canonical URL agents see** | `/changelog/v1.md` (root-relative mirror path) in `llms.txt`, `llms-full.txt`, search metadata, sitemap data, and `agent-readability.json`.  The HTML page canonical is `/changelog/v1`.  When `--base-url` is provided, absolute helpers such as the XML sitemap resolve it to `https://example.com/changelog/v1.md`. |

Because the internal copy stays at `public/docs/changelog/v1.md`, the page remains fully searchable; because the mirror lives at `public/changelog/v1.md` and the mount metadata rewrote its canonical path, agents and site visitors both reach it under `/changelog/...` rather than `/docs/changelog/...`.
