# Answer

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

Replace `https://example.com` with the site origin you publish.

For `changelog/v1.mdx`, the `changelog=/changelog` mount means:

- **Internal generated copy:** Leadtype still stages the converted markdown inside the docs artifact tree at `public/docs/changelog/v1.md`. Search and the runtime/agent helper artifacts read from this internal `public/docs/**` tree, so the page remains searchable.
- **Public markdown mirror:** Leadtype also copies that mounted markdown to `public/changelog/v1.md`, so the static `.md` mirror is served outside `/docs`.
- **Canonical URLs agents see:** the mounted page URL is `/changelog/v1`, and agent-facing markdown links (for example in `llms.txt` / `agent-readability.json`) point at `/changelog/v1.md` rather than `/docs/changelog/v1.md`.
