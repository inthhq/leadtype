# Mounting Changelog URLs

To serve pages from a sibling `changelog/` folder under `/changelog/...` (instead of `/docs/changelog/...`) while keeping them searchable and generating public mirrors, follow the solution below.

---

### 1. The `leadtype generate` Invocation

You can achieve this with a single invocation of the `leadtype generate` command by passing multiple `--docs-dir` flags and using the `<dir>=<url-prefix>` mounting syntax:

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://your-site.com
```

#### Flag breakdown:
* `--src .`: Directs Leadtype to the current project directory containing both `docs/` and `changelog/`.
* `--docs-dir docs`: Mounts the primary docs source under `/docs` (default root prefix).
* `--docs-dir changelog=/changelog`: Mounts the sibling `changelog/` source folder with a custom public URL prefix (`/changelog`), overriding the default `/docs/changelog` prefix.
* `--out public`: Specifies the output directory where generated artifacts and static assets are written.
* `--base-url https://your-site.com`: Sets the canonical site URL to build absolute sitemap URLs and metadata.

---

### 2. Output for `changelog/v1.mdx`

When `changelog/v1.mdx` is processed by the command above, Leadtype emits:

1. **The Internal Generated Copy:** 
   * **Path:** `public/docs/changelog/v1.md`
   * **Purpose:** Serves as the internal representation of the page, allowing runtime helpers, search indexes (`search-index.json`), and content loaders to locate and parse the topic.

2. **The Public Mirror:**
   * **Path:** `public/changelog/v1.md`
   * **Purpose:** Serves as the public static markdown asset mapped exactly to the customized public route.

3. **The Canonical URL Agents See:**
   * **URL Path:** `/changelog/v1.md` (or extensionless `/changelog/v1`)
   * **Details:** This path/URL prefix is used in agent-discoverability indexes including `llms.txt`, `llms-full.txt`, sitemap metadata (`sitemap.xml` / `sitemap.md`), search metadata, and `agent-readability.json`.
