# Changelog mount

Run site-mode generation with the normal docs source plus the sibling changelog source mounted at its own URL prefix:

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

Replace `https://example.com` with the site's real origin. Search is still generated because this is the default site mode, not `--bundle`.

For `changelog/v1.mdx`, leadtype treats `changelog` as an additional source mounted under the generated docs tree for indexing/runtime data, but gives it a public `/changelog` URL prefix:

- Internal generated copy: `public/docs/changelog/v1.md`
- Public markdown mirror: `public/changelog/v1.md`
- Agent-facing canonical markdown URL: `/changelog/v1.md` (or `https://example.com/changelog/v1.md` anywhere the configured `--base-url` is used for absolute URLs)

The page's canonical route/path is therefore under `/changelog`, not `/docs/changelog`; search metadata and agent artifacts point at the mounted changelog URL rather than the internal staging path.
