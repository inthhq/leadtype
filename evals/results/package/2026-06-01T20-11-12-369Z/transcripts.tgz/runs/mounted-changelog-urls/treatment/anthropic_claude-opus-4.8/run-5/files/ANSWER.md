# Serving `changelog/` under `/changelog/...`

## 1. The command

Mount the sibling `changelog/` folder at its own URL prefix using the
`--docs-dir <dir>=<url-prefix>` form:

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

- `--docs-dir docs` mounts the main docs folder at the generated docs root (`/docs`).
- `--docs-dir changelog=/changelog` mounts the sibling `changelog/` folder at the
  public URL prefix `/changelog` instead of the default `/docs/changelog`.

(Swap in your real `--base-url`. The prefix form is the one piece that moves the
changelog out from under `/docs/` while keeping it part of the same generation
run, so it still lands in the search index and agent metadata.)

## 2. What it emits for `changelog/v1.mdx`

| Artifact | Path / value | Purpose |
|--|--|--|
| Internal generated copy | `public/docs/changelog/v1.md` | Kept under the docs root so the static **search index** (`public/docs/search-index.json` / `search-content.json`) and the runtime/agent helpers can find it. This is why the changelog stays **searchable**. |
| Public markdown mirror | `public/changelog/v1.md` | A static markdown mirror written at the `/changelog` prefix, so the page is actually served from `/changelog/...` rather than `/docs/changelog/...`. |
| Canonical URL | `/changelog/v1` (`/changelog/v1.md` for the markdown mirror) | The canonical link that agents see — emitted into `llms.txt`, search metadata, sitemap entries, and `agent-readability.json`. |

In short: with the `changelog=/changelog` mount, leadtype keeps a hidden copy
under `public/docs/changelog/` for search/runtime lookups, writes the served copy
at `public/changelog/`, and points every canonical/agent-facing link at
`/changelog/...`.
