# Serving `changelog/` under `/changelog/...`

## 1. The command

Use the `<dir>=<url-prefix>` form of `--docs-dir` so the changelog folder is mounted at its own public URL prefix instead of nested under `/docs`:

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

- `--docs-dir docs` mounts the primary docs folder at the generated docs root (`/docs`).
- `--docs-dir changelog=/changelog` mounts the sibling `changelog/` folder at the public prefix `/changelog` rather than `/docs/changelog`.
- `--base-url` is what makes the canonical links absolute in `sitemap.xml`, `robots.txt`, search metadata, and the agent-readability manifest (swap in your real production URL).

## 2. What it emits for `changelog/v1.mdx`

With the `=/changelog` prefix, leadtype produces three things for that one file:

1. **Internal generated copy** — `public/docs/changelog/v1.md`. This stays under the docs root so the search index and runtime/agent helpers can still find and index the page (i.e. it remains searchable).

2. **Public mirror** — `public/changelog/v1.md`. A static markdown mirror written at the URL-prefixed location, so the page is actually served from `/changelog/...`.

3. **Canonical URL** — `/changelog/v1.md` (absolute: `https://example.com/changelog/v1.md`). This is the link agents see: it's what gets emitted into `llms.txt`, the search metadata, the sitemap entries, and `agent-readability.json`. None of these point at `/docs/changelog/...`.

### Why not plain `--docs-dir changelog`?

Without the `=/changelog` suffix, additional source folders are mounted under their own folder name *inside* the docs root, so `changelog/v1.mdx` would become `public/docs/changelog/v1.md` with a canonical URL of `/docs/changelog/v1` — exactly the `/docs/changelog/...` path we want to avoid. The `=/changelog` prefix is what lifts it out to a top-level `/changelog` URL while keeping the indexed internal copy for search.
