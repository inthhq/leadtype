# Changelog mounting

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

Replace `https://example.com` with the site origin you want in absolute canonical metadata.

For `changelog/v1.mdx`, the `changelog=/changelog` mount means:

- Internal generated copy: `public/docs/changelog/v1.md`.
  - This stays inside the generated docs tree, so Leadtype's search and runtime helper artifacts under `public/docs/` can index/read it.
- Public markdown mirror: `public/changelog/v1.md`.
  - This is the static mirror served under `/changelog/v1.md`, not `/docs/changelog/v1.md`.
- Canonical agent-facing route: `/changelog/v1` (absolute: `https://example.com/changelog/v1` with the `--base-url` above).
  - Agent metadata/search/sitemap entries use the `/changelog/...` mount. Markdown-oriented links/alternates point at `/changelog/v1.md`; neither should canonicalize to `/docs/changelog/...`.
