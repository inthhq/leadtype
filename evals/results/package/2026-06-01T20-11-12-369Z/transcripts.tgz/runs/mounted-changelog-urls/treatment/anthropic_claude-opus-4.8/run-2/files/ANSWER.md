# Serving `changelog/` under `/changelog/...` (searchable)

## 1. The command

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public
```

The key is the `<dir>=<url-prefix>` form of `--docs-dir`. The first
`--docs-dir docs` mounts the main docs folder at the generated docs root
(`/docs`). The second, `changelog=/changelog`, merges the sibling
`changelog/` folder into the same generated docs tree (so it stays in the
search index and the runtime source helpers), but assigns it its own public
URL prefix `/changelog` instead of `/docs/changelog`.

> Note: if your project uses a `leadtype.config.{ts,js,…}` with `collections`,
> `--docs-dir` is rejected. The equivalent there is a collection with
> `dir: "changelog"` and `prefix: "/changelog"`.

## 2. What `changelog/v1.mdx` emits

For a file like `changelog/v1.mdx`, the run produces three things:

- **Internal generated copy:** `public/docs/changelog/v1.md`
  This lives under the generated docs root so it remains part of the search
  index (`search-index.json` / `search-content.json`) and is resolvable by the
  runtime source primitive — i.e. it stays fully searchable.

- **Public mirror:** `public/changelog/v1.md`
  A static markdown mirror written at the prefixed location, so the page is
  actually served from `/changelog/...` rather than `/docs/changelog/...`.

- **Canonical URL agents see:** `/changelog/v1.md`
  This prefixed URL is what's emitted in `llms.txt`, search metadata, sitemap
  entries, and `agent-readability.json` — so every agent-facing artifact points
  at the `/changelog/...` location, not the internal `/docs/changelog/...` copy.

In short: search and runtime keep using the internal `/docs/changelog/v1.md`
copy, while everything public/canonical points at `/changelog/v1.md`.
