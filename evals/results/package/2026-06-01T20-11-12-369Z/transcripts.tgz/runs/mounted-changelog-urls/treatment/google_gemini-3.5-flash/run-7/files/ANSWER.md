# Changelog Subdirectory Integration in Leadtype

Here is the exact `leadtype generate` invocation and the details of how files under the sibling `changelog/` folder are processed and emitted.

## 1. The Single `leadtype generate` Invocation

To mount the sibling `changelog/` folder alongside `docs/` and serve its pages under the `/changelog/...` prefix instead of `/docs/changelog/...` while keeping them fully searchable, use the `<dir>=<url-prefix>` syntax for the second `--docs-dir` flag:

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public
```

*(Note: You can optionally add `--base-url <url>` if you want to include your domain root for sitemap and full-context fallback URLs, e.g., `--base-url https://example.com`)*.

---

## 2. Emitted Artifacts for `changelog/v1.mdx`

When running the above generation command on a file like `changelog/v1.mdx`, Leadtype processes and emits the following:

### 1. Internal Generated Copy
* **File Path**: `public/docs/changelog/v1.md`
* **Purpose**: This copy is used internally by Leadtype for full-text search indexing, search metadata, and framework runtime helpers.

### 2. Public Mirror
* **File Path**: `public/changelog/v1.md`
* **Purpose**: This is the static markdown mirror generated under the requested prefix, which matches the public serving path.

### 3. Canonical URL
* **URL Path**: `/changelog/v1.md` (or `https://example.com/changelog/v1.md` if `--base-url` is specified)
* **Purpose**: This is the canonical link that LLM/AI agents see and follow. Leadtype emits this path in:
  * `llms.txt` and `llms-full.txt`
  * Search metadata (`search-index.json` / `search-content.json`)
  * Generated `sitemap.xml` and `sitemap.md`
  * `agent-readability.json`
