# Answer

Here is how you can configure `leadtype` to serve the `changelog/` folder under `/changelog/...` rather than under `/docs/changelog/...`.

## 1. Single `leadtype generate` Invocation

You can use the repeatable `--docs-dir` flag with the `<dir>=<url-prefix>` syntax to map the custom path:

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public
```

*(Note: `--src .` and `--out public` are the defaults and can be omitted, making `leadtype generate --docs-dir docs --docs-dir changelog=/changelog` also valid).*

## 2. Emitted Output for `changelog/v1.mdx`

When `changelog/v1.mdx` is processed with the command above, the generator emits the following:

* **Internal Generated Copy:**
  `public/docs/changelog/v1.md`  
  *This file is generated at the standard internal path, ensuring search indexes and runtime helpers can access it correctly.*

* **Public Mirror:**
  `public/changelog/v1.md`  
  *A static markdown mirror is written to this custom path, matching the custom URL prefix.*

* **Canonical URL Agents See:**
  `/changelog/v1.md`  
  *This is the canonical link emitted in `llms.txt`, search metadata, sitemap entries, and the `agent-readability.json` manifest.*
