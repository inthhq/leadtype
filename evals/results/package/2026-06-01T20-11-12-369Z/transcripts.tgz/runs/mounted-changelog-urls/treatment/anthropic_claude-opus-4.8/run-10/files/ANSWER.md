# Serving `changelog/` under `/changelog/...`

## 1. The command

Use a second `--docs-dir` with the `<dir>=<url-prefix>` syntax so the changelog
folder gets its own public URL prefix instead of inheriting `/docs/`:

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public
```

- `--docs-dir docs` is the primary source, mounted at the generated docs root.
- `--docs-dir changelog=/changelog` mounts the sibling `changelog/` folder under
  the public prefix `/changelog` (the part after the `=`).

Without the `=/changelog` suffix, an additional `--docs-dir changelog` would
mount the folder under its own name, i.e. at `public/docs/changelog/...` and
`/docs/changelog/...` — which is exactly what we want to avoid.

## 2. What it emits for `changelog/v1.mdx`

The `<dir>=<url-prefix>` form produces three things for each changelog page:

| Artifact | Location / value | Purpose |
| --- | --- | --- |
| **Internal generated copy** | `public/docs/changelog/v1.md` | Stays under the docs tree so it is picked up by the **search index** and runtime helpers (`createDocsSource`, markdown-mirror resolution, etc.). This is why the page remains searchable. |
| **Public mirror** | `public/changelog/v1.md` | A static markdown mirror written at the requested public prefix, so the file is served at the desired route. |
| **Canonical URL** | `/changelog/v1.md` | The URL agents see — emitted into `llms.txt`, search metadata, sitemap entries, and `agent-readability.json`. |

So `changelog/v1.mdx`:

- keeps its **internal** copy at `public/docs/changelog/v1.md` (search + runtime),
- also gets a **public mirror** at `public/changelog/v1.md`,
- and is referenced everywhere by the **canonical** path `/changelog/v1.md`
  (not `/docs/changelog/v1.md`).

This satisfies both requirements: the pages are served under `/changelog/...`
while still being fully indexed and searchable.
