# Answer

### 1. The Single `leadtype generate` Invocation

To mount the sibling `changelog/` folder beside `docs/` such that changelog pages are served under `/changelog/...` (while still being indexable and searchable), run:

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://docs.example.com
```

*(Note: Replace `https://docs.example.com` with your production base URL. If your project root is not `.`, adjust `--src` accordingly).*

---

### 2. Output for a File Like `changelog/v1.mdx`

When the generator processes `changelog/v1.mdx` under the `changelog=/changelog` mount:

1. **The Internal Generated Copy:**
   * **Path:** `public/docs/changelog/v1.md`
   * **Purpose:** This file is used internally by search indexing, runtime page loaders, and navigation resolution helpers.

2. **The Public Mirror:**
   * **Path:** `public/changelog/v1.md`
   * **Purpose:** This is the static markdown mirror generated and written directly into the public output folder under the requested prefix, enabling it to be served under `/changelog/...` directly from your CDN/web host.

3. **The Canonical URL Agents See:**
   * **URL:** `https://docs.example.com/changelog/v1` or `https://docs.example.com/changelog/v1.md`
   * **Purpose:** These canonical links are written directly into `llms.txt`, search metadata (`search-index.json`/`search-content.json`), sitemap entries (`sitemap.xml`/`sitemap.md`), and the `agent-readability.json` manifest.
