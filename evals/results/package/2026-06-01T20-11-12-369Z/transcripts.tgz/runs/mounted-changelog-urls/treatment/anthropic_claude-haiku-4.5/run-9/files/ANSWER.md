# Serving Changelog at `/changelog/...` Instead of `/docs/changelog/...`

## The Command

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

The key flag is `--docs-dir changelog=/changelog`, which mounts the changelog folder at its own public URL prefix (`/changelog`) instead of nesting it under the default docs root (`/docs/changelog`).

## What It Emits for `changelog/v1.mdx`

For a file like `changelog/v1.mdx`, the pipeline produces three outputs:

### 1. **Internal Generated Copy** (for search and runtime helpers)
   - **Path:** `public/docs/changelog/v1.md`
   - **Purpose:** Kept internally by Leadtype for search indexing, runtime markdown resolution, and agent helper lookups.

### 2. **Public Mirror** (static markdown file agents can fetch directly)
   - **Path:** `public/changelog/v1.md`
   - **Purpose:** A static markdown mirror served at the canonical public URL so agents and browsers can directly access the content.

### 3. **Canonical URL** (what agents and metadata see)
   - **URL:** `/changelog/v1`
   - **Used in:** `llms.txt`, search metadata, sitemap entries, `agent-readability.json`, and agent request context.
   - **Purpose:** The single source of truth for where this content lives. Agents use this URL to request the page, and it resolves to the public mirror.

---

## How It Works

When you use `--docs-dir changelog=/changelog`:

- Leadtype still maintains an internal copy at `public/docs/changelog/v1.md` for search and runtime systems.
- It writes a static markdown mirror at the canonical path `public/changelog/v1.md`.
- All metadata (llms.txt, sitemap, search index, agent-readability.json) points to `/changelog/v1` as the canonical URL.
- The page is **fully searchable** because Leadtype indexes the internal copy, but agents and users see the `/changelog/...` URL throughout.

---

## Why This Works

The `=<url-prefix>` syntax tells Leadtype to:
1. Keep content organized internally for efficient search and inclusion resolution.
2. Expose it publicly under a different URL path that matches your site structure.
3. Make agents aware of the canonical URL so they generate links and references correctly.
