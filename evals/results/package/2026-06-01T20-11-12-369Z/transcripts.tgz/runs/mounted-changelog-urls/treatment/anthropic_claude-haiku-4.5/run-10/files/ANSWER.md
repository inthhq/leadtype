# Serving Changelog Under `/changelog/` with leadtype

## 1. The Command

To serve changelog pages under `/changelog/...` while keeping them searchable, use:

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://yourdomain.com
```

This invocation:
- Merges `docs/` and `changelog/` into a single searchable tree
- Mounts `changelog/` with a custom public URL prefix `/changelog`
- Writes agent-discoverable artifacts with correct canonical URLs

---

## 2. What It Emits for `changelog/v1.mdx`

### Internal Generated Copy
- **Path:** `public/docs/changelog/v1.md`
- **Purpose:** Used for search indexing and runtime navigation helpers (like breadcrumbs, related pages)
- **Content:** Converted markdown with full internal context

### Public Mirror (Static Mirror)
- **Path:** `public/changelog/v1.md`
- **Purpose:** Static markdown file served at the canonical public URL
- **Content:** Same as internal copy, but discoverable at the canonical prefix

### Canonical URL for Agents
- **URL:** `/changelog/v1.md` (or `https://yourdomain.com/changelog/v1.md` in absolute form)
- **Locations where this appears:**
  - `llms.txt` (main agent index)
  - Search metadata (`search-index.json`, `search-content.json`)
  - Sitemap entries (`sitemap.xml`, `sitemap.md`)
  - `agent-readability.json` manifest
  - Full-context fallback URLs in LLM responses

---

## How It Works

The `<dir>=<url-prefix>` syntax on `--docs-dir` tells leadtype to:
1. **Mount internally** under its natural path (`changelog/`) for the searchable merged tree
2. **Publish publicly** under the custom prefix (`/changelog`) for agent access
3. **Emit canonical links** using the public prefix in all URL-bearing artifacts

Without the URL prefix (just `--docs-dir changelog`), entries would be served at `/docs/changelog/...` instead. The prefix flag overrides this, decoupling the internal organization from the public URL shape.

Search remains unified across all sources because the search index is built from the merged internal tree before URL remapping happens—all `changelog/` and `docs/` pages appear in the same searchable corpus.
