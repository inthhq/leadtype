# Serving `changelog/` under `/changelog/...`

## 1. Single `leadtype generate` invocation

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://your-site.example.com
```

The `=<url-prefix>` syntax on the second `--docs-dir` tells leadtype to mount the `changelog` folder at its own public URL prefix (`/changelog`) rather than nesting it under `/docs/changelog`.

## 2. What is emitted for `changelog/v1.mdx`

| Artifact | Path / URL |
|----------|-----------|
| **Internal generated copy** (used by search index & runtime helpers) | `public/docs/changelog/v1.md` |
| **Public markdown mirror** (served to agents/browsers) | `public/changelog/v1.md` |
| **Canonical URL agents see** | `/changelog/v1.md` (or the fully-qualified `https://your-site.example.com/changelog/v1.md` in `llms.txt`, sitemap entries, search metadata, and `agent-readability.json`) |

In short: the file is still indexed because the internal copy lives under `public/docs/`, but every public-facing canonical link points to `/changelog/v1.md` so it appears outside the `/docs` namespace on the generated site.
