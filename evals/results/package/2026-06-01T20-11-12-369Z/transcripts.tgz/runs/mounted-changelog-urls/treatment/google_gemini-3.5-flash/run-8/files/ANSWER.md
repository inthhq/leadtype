# Serving Changelog Pages Under `/changelog/...`

To achieve this structure using `leadtype`, we can use the multiple-source folder feature with a custom URL prefix mapping on the `--docs-dir` flag.

## 1. The Single `leadtype generate` Invocation

Run the following command in the project root:

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public
```

*(Note: You can append `--base-url <url>` to this invocation for absolute canonical URLs in sitemaps, robots.txt, and metadata files).*

---

## 2. Emitted Files and Canonical URL for `changelog/v1.mdx`

When the above pipeline processes a source file like `changelog/v1.mdx`, it produces the following artifacts and URLs:

### Internal Generated Copy
* **Path:** `public/docs/changelog/v1.md`
* **Purpose:** Serves as the internal, structured content copy used by search indexing, AI answer engines, and runtime documentation routing/helpers.

### Public Mirror
* **Path:** `public/changelog/v1.md`
* **Purpose:** Written as a static, direct markdown file mirroring the converted page contents at the specified prefix.

### Canonical URL
* **URL:** `/changelog/v1.md` (or prepended with the configured `--base-url`, e.g. `https://example.com/changelog/v1.md`)
* **Purpose:** This is the URL that agents and search engines encounter. It is written as the canonical reference in `llms.txt`, search index metadata, sitemap entries, and `agent-readability.json`.
