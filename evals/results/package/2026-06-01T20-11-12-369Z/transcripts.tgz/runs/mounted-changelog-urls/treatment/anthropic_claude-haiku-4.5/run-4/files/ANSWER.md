# Serving Changelog at `/changelog/...` While Keeping It Searchable

## The Single `leadtype generate` Invocation

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://your-site.com
```

## What This Emits for `changelog/v1.mdx`

When you run the above command with a file `changelog/v1.mdx`, leadtype produces:

### 1. **Internal Generated Copy** (for search and runtime helpers)
- **Path**: `public/docs/changelog/v1.md`
- **Purpose**: Indexed by the search engine and available to leadtype's runtime helpers for resolving includes and nav context.
- **Not public-facing**: This is internal machinery only.

### 2. **Public Markdown Mirror** (what humans and agents fetch)
- **Path**: `public/changelog/v1.md`
- **Purpose**: The canonical URL that appears in `llms.txt`, search metadata, sitemap entries, and agent-readability.json.
- **URL**: `/changelog/v1.md`
- **How agents see it**: Content negotiation via `Accept: text/markdown` returns this file; it's also linked in the discovery artifacts.

### 3. **Canonical URL in Agent Artifacts**
- **In `llms.txt`**: Links point to `/changelog/v1.md`
- **In `search-index.json`**: Metadata and canonical URL field reference `/changelog/v1.md`
- **In `sitemap.xml` and `sitemap.md`**: Entry is `/changelog/v1.md`
- **In `agent-readability.json`**: The `url` field for this page is `/changelog/v1.md`

## Why This Works

The flag syntax `--docs-dir changelog=/changelog` means:
- **`changelog`**: The source folder to read from
- **`=/changelog`**: Mount it at public URL prefix `/changelog` instead of the default `/docs/changelog`

Leadtype internally:
1. Merges all `--docs-dir` sources into a unified docs tree (keeping the first one at the root)
2. Writes the internal copy to `public/docs/` for indexing and runtime resolution
3. **Emits static mirrors at the declared public prefix** (`/changelog/` in this case)
4. Uses the public prefix (`/changelog/...`) as canonical in all agent-facing artifacts (llms.txt, search, sitemap, robots, agent-readability.json)

The result: your changelog is fully searchable (indexed from the internal copy) while appearing to agents and humans under its own URL path, not nested under `/docs`.

## Complete Example

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

**Generated structure:**
```
public/
  llms.txt                     ← lists /changelog/v1.md (not /docs/changelog/...)
  docs/
    llms.txt                   ← scoped version
    sitemap.xml                ← includes /changelog/v1.md
    search-index.json          ← indexed, canonical URL is /changelog/v1.md
    agent-readability.json     ← references /changelog/v1.md
    changelog/v1.md            ← internal copy (for search)
  changelog/
    v1.md                      ← public mirror at canonical URL
```

Agents and search see `/changelog/v1.md` as the canonical URL, while search indexing includes the content for full discoverability.
