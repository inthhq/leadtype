# Answer

## 1. The `leadtype generate` Invocation

To achieve the desired behavior where the `changelog/` pages are served under `/changelog/...` (not `/docs/changelog/...`), you can use the `<dir>=<url-prefix>` syntax with multiple `--docs-dir` flags. 

The single invocation is:

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public
```

---

## 2. Emitted Files and Canonical URLs

For a file like `changelog/v1.mdx`, running the invocation above results in the following outputs:

1. **Internal Generated Copy:** 
   * **Path:** `public/docs/changelog/v1.md`
   * **Purpose:** This file is used internally for search indexing, navigation, and other runtime helpers.

2. **Public Mirror:** 
   * **Path:** `public/changelog/v1.md`
   * **Purpose:** A static markdown mirror written under the `/changelog` URL path to be served directly to users and agents.

3. **Canonical URL Agents See:** 
   * **URL:** `/changelog/v1.md` (or absolute canonical URL if `--base-url` is provided, e.g., `https://example.com/changelog/v1.md`)
   * **Location of appearance:** This canonical path is emitted in the central registry files like `llms.txt`, search metadata (`search-index.json`/`search-content.json`), sitemap entries, and `agent-readability.json`.
