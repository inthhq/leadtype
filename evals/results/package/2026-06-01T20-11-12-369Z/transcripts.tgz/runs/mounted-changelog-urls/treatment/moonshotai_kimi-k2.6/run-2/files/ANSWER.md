# Answer

## 1. Single `leadtype generate` invocation

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

The key part is **`changelog=/changelog`**. This tells leadtype to mount the `changelog` folder at its own URL prefix (`/changelog`) instead of nesting it under `/docs/changelog`.

## 2. What it emits for `changelog/v1.mdx`

| Artifact | Path / URL |
|----------|------------|
| **Internal generated copy** | `public/docs/changelog/v1.md` — kept for the search index and runtime helpers. |
| **Public mirror** | `public/changelog/v1.md` — the static markdown file actually served to browsers/agents. |
| **Canonical URL agents see** | `https://example.com/changelog/v1` (page) and `https://example.com/changelog/v1.md` (markdown mirror). These URLs appear in `llms.txt`, search metadata, sitemap entries, and `agent-readability.json`. |
