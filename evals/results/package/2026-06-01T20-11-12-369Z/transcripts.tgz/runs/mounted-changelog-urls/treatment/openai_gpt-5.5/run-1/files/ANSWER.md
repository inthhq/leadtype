# Changelog mount

Use the mounted `--docs-dir` form for the sibling changelog folder:

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

Replace `https://example.com` with the site's real origin.

For `changelog/v1.mdx`, Leadtype still merges the page into the generated docs tree so it participates in search and runtime helpers, but it gives the mounted folder its own public URL prefix:

- Internal generated copy: `public/docs/changelog/v1.md`
- Public static markdown mirror: `public/changelog/v1.md`
- Canonical agent-facing markdown URL: `/changelog/v1.md` — or `https://example.com/changelog/v1.md` in absolute-URL artifacts when `--base-url https://example.com` is used.

So the changelog is searchable via the normal `public/docs/search-*.json` artifacts, while agents and public metadata do not point at `/docs/changelog/...`.