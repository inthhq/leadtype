# Serving `changelog/` under `/changelog/...`

## 1. The `leadtype generate` invocation

Mount the sibling `changelog/` folder as an additional docs source with its own
public URL prefix using the `<dir>=<url-prefix>` form on `--docs-dir`:

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public
```

- The first `--docs-dir docs` mounts at the generated docs root.
- `--docs-dir changelog=/changelog` merges the sibling `changelog/` folder into
  the same generated docs tree (so it stays in the search index) but assigns it
  a distinct public URL prefix of `/changelog` instead of `/docs/changelog`.

## 2. What it emits for `changelog/v1.mdx`

Using the `=/changelog` prefix, a single source file `changelog/v1.mdx` produces:

| Artifact | Path / value | Purpose |
|--|--|--|
| **Internal generated copy** | `public/docs/changelog/v1.md` | Lives under the docs root so search indexing and the runtime helpers (`createDocsSource`, search-index/content) can still find and serve it — this is why it stays searchable. |
| **Public mirror** | `public/changelog/v1.md` | A static markdown mirror written at the requested public prefix, so the page is actually served from `/changelog/...` rather than `/docs/changelog/...`. |
| **Canonical URL** | `/changelog/v1.md` | The link emitted in `llms.txt`, search metadata, `sitemap.xml` entries, and `agent-readability.json` — this is the canonical location agents are pointed to. |

So you get the best of both: the file is indexed/served from the internal
`public/docs/changelog/v1.md` copy (searchable), while every public-facing
reference — the mirror and the canonical link agents see — uses `/changelog/...`.

> Note: without the `=/changelog` suffix (plain `--docs-dir changelog`), the
> additional folder mounts under its own name *inside* docs, giving
> `public/docs/changelog/v1.md` and the canonical `/docs/changelog/v1.md` — the
> behavior we explicitly want to avoid.
