# Serving `changelog/` under `/changelog/...`

## 1. The `leadtype generate` invocation

Mount the sibling `changelog/` folder with its own public URL prefix using the
`--docs-dir <dir>=<url-prefix>` form:

```bash
leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public
```

- The first `--docs-dir docs` is mounted at the generated docs root (`/docs`).
- `--docs-dir changelog=/changelog` merges the sibling `changelog/` folder into
  the same generated docs tree (so it stays in the unified search index and
  runtime helpers), but assigns it the public URL prefix `/changelog` instead of
  the default `/docs/changelog`.

If you also serve canonical artifacts (sitemap, robots, search metadata),
add `--base-url https://your-site.example` so those links are absolute.

## 2. What it emits for `changelog/v1.mdx`

For a source file `changelog/v1.mdx`, the run produces three distinct things:

- **Internal generated copy:** `public/docs/changelog/v1.md`
  This is the copy used for the unified search index, `search-content.json`,
  and runtime/source helpers — which is why the changelog stays searchable
  alongside the rest of the docs.

- **Public mirror:** `public/changelog/v1.md`
  Because of the `=/changelog` prefix, leadtype also writes a static markdown
  mirror at the public path so the file is actually served under
  `/changelog/...` rather than `/docs/changelog/...`.

- **Canonical URL agents see:** `/changelog/v1.md`
  This prefixed path is what gets emitted as the canonical link in `llms.txt`,
  search metadata, sitemap entries, and `agent-readability.json`.

### Contrast with the plain (no-prefix) form

Without the `=/changelog` suffix (i.e. just `--docs-dir changelog`), the file
would be mounted under the docs folder name: it would emit only
`public/docs/changelog/v1.md` with the canonical URL `/docs/changelog/v1.md`,
and there would be no `/changelog/...` mirror. The `=<url-prefix>` form is what
relocates it to the top-level `/changelog/...` URL space while keeping it
searchable.
