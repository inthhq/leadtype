# Answer

## 1. Single `leadtype generate` invocation

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

Replace `https://example.com` with your real base URL.

- `docs` is mounted at the generated docs root (default `/docs`).
- `changelog=/changelog` mounts the sibling `changelog/` folder at its own public URL prefix `/changelog` instead of nesting it under `/docs/changelog`.

## 2. What is emitted for `changelog/v1.mdx`

| Artifact | What leadtype writes |
|---|---|
| **Internal generated copy** | `public/docs/changelog/v1.md` — kept inside the docs tree so search indexes and runtime helpers can still crawl and index the page. |
| **Public mirror** | `public/changelog/v1.md` — written directly under the mounted prefix and served at `/changelog/v1.md`. |
| **Canonical URL agents see** | `https://example.com/changelog/v1.md` — used in `llms.txt`, search metadata, sitemap entries, and `agent-readability.json`. Some artifacts may also reference the clean path `/changelog/v1`. |
