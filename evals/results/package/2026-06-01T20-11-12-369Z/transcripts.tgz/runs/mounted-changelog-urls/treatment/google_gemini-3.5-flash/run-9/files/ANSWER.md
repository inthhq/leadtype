# Mounting Sibling Docs and Custom URL Prefixes in Leadtype

Below is the configuration and generation command to mount a sibling `changelog/` folder under a custom `/changelog/...` path, along with a description of the output files.

---

### 1. The `leadtype generate` Invocation

To mount the `changelog/` folder beside `docs/` such that changelog pages are served under `/changelog/...` (while still keeping them searchable), use the following single `leadtype generate` invocation:

```bash
npx leadtype generate \
  --src . \
  --docs-dir docs \
  --docs-dir changelog=/changelog \
  --out public \
  --base-url https://example.com
```

#### How it works:
- `--src .`: Specifies the repo or root directory containing the docs and changelog folders.
- `--docs-dir docs`: The first source folder is mounted as the default docs root.
- `--docs-dir changelog=/changelog`: The second source folder is mounted under its own custom public URL prefix (`/changelog`), which keeps it out of `/docs/changelog/...`.
- `--out public`: Directs the pipeline to output the generated artifacts in the `public` directory.
- `--base-url https://example.com`: Optional/recommended flag providing the base URL for canonical artifacts like `sitemap.xml`, search metadata, sitemaps, etc.

---

### 2. Artifacts Emitted for `changelog/v1.mdx`

For a file located at `changelog/v1.mdx`, `leadtype` will emit the following:

1. **Internal Generated Copy:**
   - **Path:** `public/docs/changelog/v1.md`
   - **Purpose:** Used internally for search indices, metadata, and runtime helpers.

2. **Public Mirror:**
   - **Path:** `public/changelog/v1.md`
   - **Purpose:** Serves as a static markdown mirror at the custom public URL.

3. **Canonical URL Agents See:**
   - **Canonical Link:** `/changelog/v1.md` (or prefixed with the configured base URL, e.g., `https://example.com/changelog/v1.md`)
   - **Included in:** `llms.txt`, search metadata, sitemap entries, and `agent-readability.json`.
