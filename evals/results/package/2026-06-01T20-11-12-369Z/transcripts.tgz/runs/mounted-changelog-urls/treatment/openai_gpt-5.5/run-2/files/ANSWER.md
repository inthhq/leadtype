# Answer

```bash
leadtype generate --src . --docs-dir docs --docs-dir changelog=/changelog --out public --base-url https://example.com
```

Replace `https://example.com` with the real site origin.

For `changelog/v1.mdx`, Leadtype treats `changelog` as an extra mounted source:

- **Internal generated copy for search/runtime artifacts:** `public/docs/changelog/v1.md`
- **Public markdown mirror for the mounted URL prefix:** `public/changelog/v1.md`
- **Agent-facing mounted markdown URL:** `https://example.com/changelog/v1.md` (or `/changelog/v1.md` as a site-relative URL)

The important part is `--docs-dir changelog=/changelog`: the file still exists inside the generated `public/docs/...` tree so search and Leadtype helpers can index/read it, but the mounted public URL points at `/changelog/...` instead of `/docs/changelog/...`. Search/page metadata uses the mounted page route `/changelog/v1`, with the markdown mirror available at `/changelog/v1.md`.
