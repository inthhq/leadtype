# The `--enrich-git` Flag

The `--enrich-git` flag on `leadtype generate` automatically adds two frontmatter fields to pages by extracting information from git history: `lastModified` and `lastAuthor`. These fields are populated directly from the git log of the file, allowing pages to display when they were last changed and who made that change. When this flag is not passed, these fields are not added to the frontmatter; authors are instructed not to set them manually as they are filled in entirely by the flag's processing.
