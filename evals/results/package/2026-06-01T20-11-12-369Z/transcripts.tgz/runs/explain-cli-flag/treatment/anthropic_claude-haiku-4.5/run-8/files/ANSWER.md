# The `--enrich-git` Flag

The `--enrich-git` flag on `leadtype generate` automatically adds two frontmatter fields to pages by extracting metadata from the git history of the repository: `lastModified`, which contains the date of the most recent commit that changed the page, and `lastAuthor`, which contains the name of the author who made that most recent commit. These fields are derived from the repository's git log for each documentation file and can be used by the site to display information about when a page was last updated and who updated it.
