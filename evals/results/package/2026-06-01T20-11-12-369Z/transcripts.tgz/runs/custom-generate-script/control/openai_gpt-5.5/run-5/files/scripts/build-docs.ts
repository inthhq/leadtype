import path from "node:path";
import { fileURLToPath } from "node:url";
import { mkdir, rm } from "node:fs/promises";

import { convertAllMdx } from "leadtype/convert";
import { generateLLMFullContextFiles, generateLlmsTxt } from "leadtype/llm";
import { defaultRemarkPlugins, remarkInclude, remarkTypeTableToMarkdown } from "leadtype/remark";
import { generateDocsSearchFiles } from "leadtype/search/node";

import docsConfig, { nav, product } from "../docs.config.ts";

const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const docsDir = path.join(projectRoot, "docs");
const publicDir = path.join(projectRoot, "public");
const publicDocsDir = path.join(publicDir, "docs");

// Set one of these in CI/deploys for absolute URLs in llms.txt/search results.
const baseUrl =
  process.env.LEADTYPE_BASE_URL ??
  process.env.DOCS_BASE_URL ??
  process.env.NEXT_PUBLIC_SITE_URL;

function createConversionRemarkPlugins() {
  const typeTableBasePath = path.resolve(
    projectRoot,
    docsConfig.typeTableBasePath ?? ".",
  );

  return [
    remarkInclude,
    ...defaultRemarkPlugins.map((plugin) =>
      plugin === remarkTypeTableToMarkdown
        ? [
            remarkTypeTableToMarkdown,
            {
              basePath: typeTableBasePath,
              strict: docsConfig.typeTableStrict,
            },
          ]
        : plugin,
    ),
    ...(docsConfig.flatteners ?? []),
  ];
}

async function main() {
  // Remove only generated docs artifacts so other files in public/ are preserved.
  await Promise.all([
    rm(publicDocsDir, { recursive: true, force: true }),
    rm(path.join(publicDir, "llms.txt"), { force: true }),
    rm(path.join(publicDir, "llms-full.txt"), { force: true }),
  ]);
  await mkdir(publicDocsDir, { recursive: true });

  // 1. MDX -> agent-readable Markdown mirrors at public/docs/*.md.
  await convertAllMdx({
    srcDir: docsDir,
    outDir: publicDocsDir,
    remarkPlugins: createConversionRemarkPlugins(),
    failOnError: docsConfig.typeTableStrict,
    frontmatterSchema: docsConfig.frontmatterSchema,
    transformers: docsConfig.transformers,
  });

  // 2. Hosted-site routing indexes: public/llms.txt and public/docs/llms.txt.
  await generateLlmsTxt({
    srcDir: projectRoot,
    outDir: publicDir,
    baseUrl,
    product,
    nav,
    transformers: docsConfig.transformers,
  });

  // 3. Root fallback containing the full generated Markdown corpus.
  await generateLLMFullContextFiles({
    outDir: publicDir,
    baseUrl,
    product: { name: product.name },
    nav,
    transformers: docsConfig.transformers,
  });

  // 4. Static search artifacts under public/docs/.
  const search = await generateDocsSearchFiles({
    outDir: publicDir,
    baseUrl,
    transformers: docsConfig.transformers,
  });

  console.log(
    `Built hosted docs artifacts in ${path.relative(projectRoot, publicDir)} ` +
      `(${search.docs} docs, ${search.chunks} search chunks).`,
  );
}

await main();
