import { convertAllMdx } from "leadtype/convert";
import { generateLlmsTxt, generateLLMFullContextFiles } from "leadtype/llm";
import { generateDocsSearchFiles } from "leadtype/search/node";
import docsConfig from "../docs.config.ts";

const { product, nav } = docsConfig;
const baseUrl = process.env.BASE_URL;

async function buildDocs() {
  // 1. Flatten MDX → markdown mirrors under public/docs/
  await convertAllMdx({
    srcDir: "docs",
    outDir: "public/docs",
  });

  // 2. Routing index: public/llms.txt (+ public/docs/llms.txt)
  await generateLlmsTxt({
    srcDir: ".",
    outDir: "public",
    baseUrl,
    product,
    nav,
  });

  // 3. Root fallback: public/llms-full.txt
  await generateLLMFullContextFiles({
    outDir: "public",
    baseUrl,
    product: { name: product.name },
    nav,
  });

  // 4. Static search index (default writes to public/docs/search-index.json)
  await generateDocsSearchFiles({
    outDir: "public",
    baseUrl,
  });

  console.log("Docs built successfully.");
}

buildDocs().catch((err) => {
  console.error(err);
  process.exit(1);
});
