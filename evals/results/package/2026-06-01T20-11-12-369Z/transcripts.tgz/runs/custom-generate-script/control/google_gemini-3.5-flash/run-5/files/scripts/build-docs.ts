import { mkdir } from "node:fs/promises";
import { convertAllMdx } from "leadtype/convert";
import { generateLlmsTxt, generateLLMFullContextFiles } from "leadtype/llm";
import { generateDocsSearchFiles } from "leadtype/search/node";
import config from "../docs.config.ts";

async function main() {
  console.log("Creating output directory public/docs...");
  await mkdir("public/docs", { recursive: true });

  const { product, nav } = config;

  console.log("Converting MDX pages to markdown mirrors...");
  // 1. Converted markdown mirrors (public/docs/*.md)
  await convertAllMdx({
    srcDir: "docs",
    outDir: "public/docs",
  });

  console.log("Generating llms.txt...");
  // 2. Routing index public/llms.txt
  await generateLlmsTxt({
    srcDir: ".",
    outDir: "public",
    product,
    nav,
  });

  console.log("Generating llms-full.txt...");
  // 3. Root public/llms-full.txt fallback
  await generateLLMFullContextFiles({
    outDir: "public",
    product,
    nav,
  });

  console.log("Generating static search index...");
  // 4. Static search index
  await generateDocsSearchFiles({
    outDir: "public",
  });

  console.log("Docs pipeline completed successfully!");
}

main().catch((err) => {
  console.error("Build failed:", err);
  process.exit(1);
});
