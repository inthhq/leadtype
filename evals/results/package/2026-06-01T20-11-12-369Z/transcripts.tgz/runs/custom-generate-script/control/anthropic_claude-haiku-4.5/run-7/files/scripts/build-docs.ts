#!/usr/bin/env node

import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
import { convertAllMdx } from "leadtype/convert";
import {
  generateLlmsTxt,
  generateLLMFullContextFiles,
} from "leadtype/llm";
import { generateDocsSearchFiles } from "leadtype/search/node";

// Resolve the project root (where docs.config.ts lives)
const __dirname = dirname(fileURLToPath(import.meta.url));
const projectRoot = dirname(__dirname);

// Output directory for public artifacts
const publicDir = join(projectRoot, "public");

// Import the config to access product and nav
let docsConfig: any;
try {
  const configModule = await import(join(projectRoot, "docs.config.ts"));
  docsConfig = configModule.default;
} catch (error) {
  console.error("Failed to load docs.config.ts:", error);
  process.exit(1);
}

const { product, nav } = docsConfig;

console.log("📦 Building docs artifacts...\n");

try {
  // Step 1: Convert MDX files to markdown
  console.log("1️⃣  Converting MDX to markdown...");
  await convertAllMdx({
    srcDir: projectRoot,
    outDir: publicDir,
  });
  console.log("   ✅ Markdown mirrors written to public/docs/*.md\n");

  // Step 2: Generate llms.txt routing index
  console.log("2️⃣  Generating llms.txt routing index...");
  await generateLlmsTxt({
    srcDir: projectRoot,
    outDir: publicDir,
    product,
    nav,
  });
  console.log("   ✅ Routing index written to public/llms.txt\n");

  // Step 3: Generate llms-full.txt fallback
  console.log("3️⃣  Generating llms-full.txt fallback...");
  await generateLLMFullContextFiles({
    outDir: publicDir,
    product: { name: product.name },
    nav,
  });
  console.log("   ✅ Full context fallback written to public/llms-full.txt\n");

  // Step 4: Generate static search index
  console.log("4️⃣  Generating search index...");
  const searchResult = await generateDocsSearchFiles({
    outDir: publicDir,
  });
  console.log(
    `   ✅ Search index written to ${searchResult.outputPath}`
  );
  console.log(`      Documents: ${searchResult.docs}, Chunks: ${searchResult.chunks}, Terms: ${searchResult.terms}\n`);

  console.log("✨ All docs artifacts built successfully!");
} catch (error) {
  console.error("❌ Build failed:", error);
  process.exit(1);
}
