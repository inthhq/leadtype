import { fileURLToPath } from "node:url";
import path from "node:path";
import { convertAllMdx } from "leadtype/convert";
import {
  generateLlmsTxt,
  generateLLMFullContextFiles,
  generateAgentReadabilityArtifacts,
} from "leadtype/llm";
import { generateDocsSearchFiles } from "leadtype/search/node";
import docsConfig from "../docs.config.ts";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const projectRoot = path.resolve(__dirname, "..");
const srcDir = projectRoot;
const outDir = path.resolve(projectRoot, "public");
const docsDir = path.resolve(projectRoot, "docs");

async function buildDocs() {
  console.log("🔨 Building docs artifacts...\n");

  try {
    // 1. Convert MDX to markdown
    console.log("📝 Converting MDX to markdown...");
    await convertAllMdx({
      srcDir: docsDir,
      outDir: path.resolve(outDir, "docs"),
      failOnError: true,
    });
    console.log("✓ Markdown conversion complete\n");

    // 2. Generate /llms.txt (routing index with curated docs map)
    console.log("🗂️  Generating llms.txt (routing index)...");
    await generateLlmsTxt({
      srcDir: projectRoot,
      outDir,
      baseUrl: process.env.BASE_URL || "http://localhost:3000",
      product: docsConfig.product,
      nav: docsConfig.nav,
      groups: docsConfig.groups,
    });
    console.log("✓ llms.txt generated\n");

    // 3. Generate /llms-full.txt (full-context fallback)
    console.log("📄 Generating llms-full.txt (full context)...");
    await generateLLMFullContextFiles({
      outDir,
      baseUrl: process.env.BASE_URL || "http://localhost:3000",
      product: { name: docsConfig.product.name },
      nav: docsConfig.nav,
      groups: docsConfig.groups,
    });
    console.log("✓ llms-full.txt generated\n");

    // 4. Generate static search index
    console.log("🔍 Generating search index...");
    const searchResult = await generateDocsSearchFiles({
      outDir: path.resolve(outDir, "docs"),
      baseUrl: process.env.BASE_URL || "http://localhost:3000",
      outputFile: "search-index.json",
      embedContent: false,
    });
    console.log(
      `✓ Search index generated (${searchResult.docs} docs, ${searchResult.chunks} chunks)\n`
    );

    // 5. Generate agent readability artifacts (optional robots.txt, sitemap, etc.)
    console.log("🤖 Generating agent readability artifacts...");
    await generateAgentReadabilityArtifacts({
      outDir,
      baseUrl: process.env.BASE_URL || "http://localhost:3000",
      product: {
        name: docsConfig.product.name,
        summary: docsConfig.product.summary,
      },
      nav: docsConfig.nav,
      groups: docsConfig.groups,
    });
    console.log("✓ Agent readability artifacts generated\n");

    console.log("✨ All docs artifacts built successfully!");
    console.log(`\n📍 Output directory: ${outDir}`);
    console.log("  - public/docs/*.md (markdown mirrors)");
    console.log("  - public/llms.txt (routing index)");
    console.log("  - public/llms-full.txt (fallback context)");
    console.log("  - public/docs/search-index.json (search index)");
    console.log("  - public/docs/robots.txt");
    console.log("  - public/docs/sitemap.md");
    console.log("  - public/docs/sitemap.xml");
  } catch (error) {
    console.error("❌ Build failed:", error);
    process.exit(1);
  }
}

buildDocs();
