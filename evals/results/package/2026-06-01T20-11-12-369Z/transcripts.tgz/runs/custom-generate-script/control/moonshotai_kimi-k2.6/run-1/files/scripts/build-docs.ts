import { convertAllMdx } from "leadtype/convert";
import { generateLlmsTxt, generateLLMFullContextFiles } from "leadtype/llm";
import { generateDocsSearchFiles } from "leadtype/search/node";
import path from "node:path";
import docsConfig from "../docs.config.ts";

const { product, nav } = docsConfig;

const SRC_DIR = "docs";
const OUT_DIR = "public";
const BASE_URL = process.env.BASE_URL;

async function main() {
  // 1. Flatten MDX into markdown mirrors under public/docs/*.md
  await convertAllMdx({
    srcDir: SRC_DIR,
    outDir: path.join(OUT_DIR, "docs"),
  });

  // 2. Generate routing index: public/llms.txt (+ public/docs/llms.txt)
  await generateLlmsTxt({
    srcDir: ".",
    outDir: OUT_DIR,
    baseUrl: BASE_URL,
    product,
    nav,
  });

  // 3. Generate root fallback: public/llms-full.txt
  await generateLLMFullContextFiles({
    outDir: OUT_DIR,
    baseUrl: BASE_URL,
    product: { name: product.name },
    nav,
  });

  // 4. Build static search index under public/docs/search-index.json
  await generateDocsSearchFiles({
    outDir: OUT_DIR,
    baseUrl: BASE_URL,
  });

  console.log("Docs built successfully in", OUT_DIR);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
