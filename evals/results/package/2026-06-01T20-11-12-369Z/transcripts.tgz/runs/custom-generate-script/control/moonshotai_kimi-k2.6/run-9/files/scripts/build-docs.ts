import { mkdir } from "node:fs/promises";
import path from "node:path";
import { convertAllMdx } from "leadtype/convert";
import { generateLlmsTxt, generateLLMFullContextFiles } from "leadtype/llm";
import { generateDocsSearchFiles } from "leadtype/search/node";
import { defaultRemarkPlugins, remarkInclude } from "leadtype/remark";
import docsConfig from "../docs.config";

const { product, nav } = docsConfig;

const ROOT_DIR = path.resolve(import.meta.dirname, "..");
const DOCS_DIR = path.join(ROOT_DIR, "docs");
const OUT_DIR = path.join(ROOT_DIR, "public");
const DOCS_OUT_DIR = path.join(OUT_DIR, "docs");
const BASE_URL = process.env.BASE_URL;

async function main() {
  // Ensure output directories exist
  await mkdir(DOCS_OUT_DIR, { recursive: true });

  const remarkPlugins = [remarkInclude, ...defaultRemarkPlugins];

  // 1. Convert MDX source files to markdown mirrors under public/docs/*.md
  await convertAllMdx({
    srcDir: DOCS_DIR,
    outDir: DOCS_OUT_DIR,
    remarkPlugins,
  });

  // 2. Generate routing index: public/llms.txt and public/docs/llms.txt
  await generateLlmsTxt({
    srcDir: ROOT_DIR,
    outDir: OUT_DIR,
    product,
    nav,
    baseUrl: BASE_URL,
  });

  // 3. Generate root fallback: public/llms-full.txt
  await generateLLMFullContextFiles({
    outDir: OUT_DIR,
    product: { name: product.name },
    nav,
    baseUrl: BASE_URL,
  });

  // 4. Build static search index under public/docs/search-index.json
  await generateDocsSearchFiles({
    outDir: OUT_DIR,
    baseUrl: BASE_URL,
  });

  console.log("Docs built successfully in", OUT_DIR);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
