import { mkdir } from "node:fs/promises";
import { convertAllMdx } from "leadtype/convert";
import { generateLlmsTxt, generateLLMFullContextFiles } from "leadtype/llm";
import { generateDocsSearchFiles } from "leadtype/search/node";
import config from "../docs.config";

async function main() {
  console.log("Starting docs build pipeline...");

  // Ensure output directory exists
  await mkdir("public", { recursive: true });

  const { product, nav } = config;

  // 1. Converted markdown mirrors (written under public/docs/*.md)
  console.log("Converting MDX to markdown mirrors...");
  await convertAllMdx({
    srcDir: "docs",
    outDir: "public/docs",
  });

  // 2. The routing index (written under public/llms.txt)
  console.log("Generating routing index (llms.txt)...");
  await generateLlmsTxt({
    srcDir: ".",
    outDir: "public",
    product,
    nav,
  });

  // 3. The root full-context fallback (written under public/llms-full.txt)
  console.log("Generating full-context fallback (llms-full.txt)...");
  await generateLLMFullContextFiles({
    outDir: "public",
    product,
    nav,
  });

  // 4. The static search index (written under public/docs/search-index.json)
  console.log("Generating static search index...");
  await generateDocsSearchFiles({
    outDir: "public",
  });

  console.log("Docs build pipeline completed successfully!");
}

main().catch((err) => {
  console.error("Docs build pipeline failed:", err);
  process.exit(1);
});
