import path from "node:path";
import { rm } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { convertAllMdx } from "leadtype/convert";
import { generateLLMFullContextFiles, generateLlmsTxt } from "leadtype/llm";
import { defaultRemarkPlugins, remarkInclude, remarkTypeTableToMarkdown } from "leadtype/remark";
import { generateDocsSearchFiles } from "leadtype/search/node";
import { nav, product } from "../docs.config.ts";

const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const docsDir = path.join(projectRoot, "docs");
const outDir = path.join(projectRoot, "public");
const outDocsDir = path.join(outDir, "docs");

// Set DOCS_BASE_URL in the hosting environment to generate absolute URLs.
// Leaving it undefined keeps the build runnable for local previews.
const baseUrl = process.env.DOCS_BASE_URL;

const remarkPlugins = [
  remarkInclude,
  ...defaultRemarkPlugins.map((plugin) =>
    plugin === remarkTypeTableToMarkdown
      ? [remarkTypeTableToMarkdown, { basePath: projectRoot }]
      : plugin,
  ),
];

async function buildDocs() {
  // Remove only the artifacts this script owns so other public/ assets survive.
  await Promise.all([
    rm(outDocsDir, { force: true, recursive: true }),
    rm(path.join(outDir, "llms.txt"), { force: true }),
    rm(path.join(outDir, "llms-full.txt"), { force: true }),
  ]);

  // 1. Convert source MDX into public markdown mirrors.
  await convertAllMdx({
    srcDir: docsDir,
    outDir: outDocsDir,
    remarkPlugins,
    failOnError: true,
  });

  // 2. Generate the hosted-site routing indexes.
  await generateLlmsTxt({
    srcDir: projectRoot,
    outDir,
    baseUrl,
    product,
    nav,
  });

  // 3. Generate the root full-context fallback from public/docs/*.md.
  await generateLLMFullContextFiles({
    outDir,
    baseUrl,
    product: { name: product.name },
    nav,
  });

  // 4. Build the static search index from the generated markdown mirrors.
  await generateDocsSearchFiles({
    outDir,
    baseUrl,
  });
}

await buildDocs();
