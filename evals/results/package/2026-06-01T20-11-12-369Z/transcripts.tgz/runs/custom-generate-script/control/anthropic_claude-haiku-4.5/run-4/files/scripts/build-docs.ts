#!/usr/bin/env bun
/**
 * Build script for generating agent-facing docs artifacts using leadtype library APIs.
 * Produces:
 * - public/docs/*.md - converted markdown mirrors from docs/*.mdx
 * - public/llms.txt - routing index for docs navigation
 * - public/llms-full.txt - root fallback full-context file
 * - public/search-index.json - static search index
 */

import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
import { mkdir } from "node:fs/promises";

import { convertAllMdx } from "leadtype/convert";
import {
  generateLlmsTxt,
  generateLLMFullContextFiles,
  generateDocsSearchFiles,
} from "leadtype/llm";

// Import config
import docsConfig from "../docs.config.ts";

const __dirname = dirname(fileURLToPath(import.meta.url));
const projectRoot = resolve(__dirname, "..");
const docsDir = resolve(projectRoot, "docs");
const publicDir = resolve(projectRoot, "public");
const publicDocsDir = resolve(publicDir, "docs");

// Ensure output directories exist
await mkdir(publicDir, { recursive: true });
await mkdir(publicDocsDir, { recursive: true });

console.log("🔨 Building docs artifacts...\n");

// Step 1: Convert MDX to Markdown
console.log("📝 Converting MDX to Markdown...");
await convertAllMdx({
  srcDir: docsDir,
  outDir: publicDocsDir,
});
console.log(`✓ Markdown mirrors written to ${publicDocsDir}\n`);

// Step 2: Generate llms.txt (routing index)
console.log("🗂️  Generating llms.txt (routing index)...");
await generateLlmsTxt({
  srcDir: projectRoot,
  outDir: publicDir,
  baseUrl: process.env.BASE_URL || "http://localhost:3000",
  product: docsConfig.product,
  nav: docsConfig.nav,
});
console.log(`✓ Routing index written to ${resolve(publicDir, "docs/llms.txt")}\n`);

// Step 3: Generate llms-full.txt (root fallback)
console.log("⚙️  Generating llms-full.txt (full-context fallback)...");
await generateLLMFullContextFiles({
  outDir: publicDir,
  baseUrl: process.env.BASE_URL || "http://localhost:3000",
  product: { name: docsConfig.product.name },
  nav: docsConfig.nav,
});
console.log(`✓ Full-context file written to ${resolve(publicDir, "llms-full.txt")}\n`);

// Step 4: Generate search index
console.log("🔍 Generating search index...");
const searchResult = await generateDocsSearchFiles({
  outDir: publicDir,
  baseUrl: process.env.BASE_URL || "http://localhost:3000",
  outputFile: "search-index.json",
  embedContent: false,
});
console.log(
  `✓ Search index written to ${searchResult.outputPath} (${searchResult.docs} docs, ${searchResult.chunks} chunks)\n`
);

console.log("✨ Build complete!");
console.log(`\nGenerated artifacts:`);
console.log(`  • ${publicDocsDir}/*.md`);
console.log(`  • ${resolve(publicDir, "docs/llms.txt")}`);
console.log(`  • ${resolve(publicDir, "llms-full.txt")}`);
console.log(`  • ${resolve(publicDir, "search-index.json")}`);
