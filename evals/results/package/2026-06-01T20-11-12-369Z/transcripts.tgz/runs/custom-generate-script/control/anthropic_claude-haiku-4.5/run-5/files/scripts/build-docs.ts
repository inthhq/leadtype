#!/usr/bin/env node

import { fileURLToPath } from "url";
import { dirname, join, resolve } from "path";
import { createDocsSource } from "leadtype";
import { convertAllMdx } from "leadtype/convert";
import {
  generateLlmsTxt,
  generateLLMFullContextFiles,
  generateAgentReadabilityArtifacts,
} from "leadtype/llm";
import { generateDocsSearchFiles } from "leadtype/search/node";
import type { ProductInfo, DocsNavNode } from "leadtype";

// Get the script directory for relative imports
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const projectRoot = resolve(__dirname, "..");

// Import config from docs.config.ts
const configModule = await import(resolve(projectRoot, "docs.config.ts"));
const config = configModule.default;

const product: ProductInfo = config.product;
const nav: DocsNavNode[] | undefined = config.nav;

const docsDir = join(projectRoot, "docs");
const publicDir = join(projectRoot, "public");

console.log("🔨 Building docs artifacts for hosted docs site...\n");

try {
  // Step 1: Convert MDX files to Markdown
  console.log("📝 Converting MDX to Markdown...");
  await convertAllMdx({
    srcDir: docsDir,
    outDir: join(publicDir, "docs"),
    failOnError: true,
  });
  console.log("✅ Markdown mirrors created at public/docs/*.md\n");

  // Step 2: Create a docs source for building indexes
  console.log("🗂️  Creating docs source...");
  const docsSource = await createDocsSource({
    contentDir: docsDir,
    baseUrl: "https://docs.example.com",
    nav,
  });
  console.log(
    `✅ Docs source created (${(await docsSource.listPages()).length} pages)\n`
  );

  // Step 3: Generate routing index (llms.txt and docs/llms.txt)
  console.log("📋 Generating routing indexes...");
  await generateLlmsTxt({
    srcDir: projectRoot,
    outDir: publicDir,
    baseUrl: "https://docs.example.com",
    product,
    nav,
  });
  console.log("✅ Routing indexes generated:");
  console.log("   - public/llms.txt (product summary)");
  console.log("   - public/docs/llms.txt (curated docs map)\n");

  // Step 4: Generate root full-context fallback
  console.log("📚 Generating full-context fallback...");
  await generateLLMFullContextFiles({
    outDir: publicDir,
    baseUrl: "https://docs.example.com",
    product,
    nav,
  });
  console.log("✅ Full-context fallback created at public/llms-full.txt\n");

  // Step 5: Generate agent readability artifacts (robots.txt, sitemap, manifest)
  console.log("🤖 Generating agent readability artifacts...");
  await generateAgentReadabilityArtifacts({
    outDir: publicDir,
    baseUrl: "https://docs.example.com",
    product,
    nav,
  });
  console.log("✅ Agent artifacts generated:");
  console.log("   - public/docs/robots.txt (agent discovery)");
  console.log("   - public/docs/sitemap.md (agent-readable map)");
  console.log("   - public/docs/sitemap.xml (XML sitemap)");
  console.log("   - public/docs/readability.manifest.json (metadata)\n");

  // Step 6: Generate static search index
  console.log("🔍 Generating static search index...");
  const searchResult = await generateDocsSearchFiles({
    outDir: publicDir,
    baseUrl: "https://docs.example.com",
    outputFile: "search-index.json",
    embedContent: true,
  });
  console.log(
    `✅ Search index generated at public/search-index.json`
  );
  console.log(
    `   (${searchResult.docs} docs, ${searchResult.chunks} chunks, ${(searchResult.bytes / 1024).toFixed(1)} KB)\n`
  );

  // Summary
  console.log("=".repeat(70));
  console.log("✨ Hosted docs build complete! Generated artifacts:\n");
  console.log("AGENT-FACING ARTIFACTS:");
  console.log("  📋 public/llms.txt                     - Product summary (routing)");
  console.log("  📋 public/docs/llms.txt                - Curated docs index");
  console.log("  📚 public/llms-full.txt                - Full-context fallback");
  console.log("  🤖 public/docs/robots.txt              - Agent discovery meta");
  console.log("  🗺️  public/docs/sitemap.md              - Agent-readable sitemap");
  console.log("  🗺️  public/docs/sitemap.xml             - XML sitemap");
  console.log("  📄 public/docs/readability.manifest.json- Navigation metadata");
  console.log("\nCONTENT:");
  console.log("  📁 public/docs/*.md                    - Converted markdown mirrors");
  console.log("  🔍 public/search-index.json            - Static BM25 search index");
  console.log("=".repeat(70));
} catch (error) {
  console.error("\n❌ Build failed:", error);
  process.exit(1);
}
