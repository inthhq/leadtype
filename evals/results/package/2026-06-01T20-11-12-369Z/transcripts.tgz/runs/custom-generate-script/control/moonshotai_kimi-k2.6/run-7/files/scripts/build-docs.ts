import { convertAllMdx } from "leadtype/convert";
import { generateLlmsTxt, generateLLMFullContextFiles } from "leadtype/llm";
import { generateDocsSearchFiles } from "leadtype/search/node";
import docsConfig from "../docs.config.ts";

const { product, nav } = docsConfig;

async function build() {
  // 1. Convert MDX source files into flat markdown mirrors
  await convertAllMdx({ srcDir: "docs", outDir: "public/docs" });

  // 2. Generate routing index (llms.txt + docs/llms.txt)
  await generateLlmsTxt({ srcDir: ".", outDir: "public", product, nav });

  // 3. Generate the full-context fallback file
  await generateLLMFullContextFiles({ outDir: "public", product, nav });

  // 4. Build static search index from the generated markdown
  await generateDocsSearchFiles({ outDir: "public" });
}

build().catch((err) => {
  console.error(err);
  process.exit(1);
});
