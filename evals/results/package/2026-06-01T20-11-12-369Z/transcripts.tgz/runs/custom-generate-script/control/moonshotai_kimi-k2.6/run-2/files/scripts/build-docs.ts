import { mkdir } from "node:fs/promises";
import { resolve } from "node:path";
import { convertAllMdx } from "leadtype/convert";
import { generateLlmsTxt, generateLLMFullContextFiles } from "leadtype/llm";
import { generateDocsSearchFiles } from "leadtype/search/node";
import config from "../docs.config.ts";

const { product, nav } = config;

const OUT_DIR = "public";
const BASE_URL = process.env.BASE_URL;

async function main() {
  await mkdir(resolve(OUT_DIR, "docs"), { recursive: true });

  console.log("Converting MDX files to markdown mirrors...");
  await convertAllMdx({
    srcDir: "docs",
    outDir: resolve(OUT_DIR, "docs"),
  });

  console.log("Generating llms.txt...");
  await generateLlmsTxt({
    srcDir: ".",
    outDir: OUT_DIR,
    baseUrl: BASE_URL,
    product,
    nav,
  });

  console.log("Generating llms-full.txt...");
  await generateLLMFullContextFiles({
    outDir: OUT_DIR,
    baseUrl: BASE_URL,
    product: { name: product.name },
    nav,
  });

  console.log("Generating static search index...");
  await generateDocsSearchFiles({
    outDir: OUT_DIR,
    baseUrl: BASE_URL,
  });

  console.log("Docs build complete.");
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
