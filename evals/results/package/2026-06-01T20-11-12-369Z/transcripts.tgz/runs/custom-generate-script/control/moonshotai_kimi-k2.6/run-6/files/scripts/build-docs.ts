import path from "node:path";
import config from "../docs.config.ts";
import { convertAllMdx } from "leadtype/convert";
import { generateLlmsTxt, generateLLMFullContextFiles } from "leadtype/llm";
import { generateDocsSearchFiles } from "leadtype/search/node";

const { product, nav } = config;

const SRC_DIR = ".";
const DOCS_SRC_DIR = "docs";
const OUT_DIR = "public";

async function main() {
  // 1. Convert MDX source files into markdown mirrors under public/docs/
  await convertAllMdx({
    srcDir: DOCS_SRC_DIR,
    outDir: path.join(OUT_DIR, "docs"),
  });

  // 2. Generate llms.txt routing index (and docs/llms.txt)
  await generateLlmsTxt({
    srcDir: SRC_DIR,
    outDir: OUT_DIR,
    product,
    nav,
  });

  // 3. Generate root llms-full.txt fallback from the mirrored markdown
  await generateLLMFullContextFiles({
    outDir: OUT_DIR,
    product: { name: product.name },
    nav,
  });

  // 4. Build the static search index from the mirrored markdown
  await generateDocsSearchFiles({
    outDir: OUT_DIR,
  });

  console.log("Docs built successfully in", OUT_DIR);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
