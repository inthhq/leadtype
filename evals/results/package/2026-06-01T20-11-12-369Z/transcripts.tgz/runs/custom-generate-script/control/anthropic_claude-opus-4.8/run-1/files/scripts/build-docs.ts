/**
 * build-docs.ts — produce the agent-facing artifacts for a hosted docs site
 * using leadtype's library APIs (not the `leadtype` CLI).
 *
 * Pipeline (order matters):
 *   1. convertAllMdx                -> public/docs/*.md       (markdown mirrors)
 *   2. generateLlmsTxt              -> public/llms.txt        (routing index)
 *   3. generateLLMFullContextFiles  -> public/llms-full.txt   (root fallback)
 *   4. generateDocsSearchFiles      -> public/docs/search-index.json
 *
 * Steps 3 and 4 read the generated markdown under `public/docs/`, so they must
 * run after the conversion step (1).
 */

import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";

import { convertAllMdx } from "leadtype/convert";
import {
  generateLlmsTxt,
  generateLLMFullContextFiles,
} from "leadtype/llm";
import { generateDocsSearchFiles } from "leadtype/search/node";
import { defaultRemarkPlugins } from "leadtype/remark";

import { product, nav } from "../docs.config.ts";

// Resolve paths relative to the project root (this file lives in `scripts/`).
const scriptDir = dirname(fileURLToPath(import.meta.url));
const projectRoot = resolve(scriptDir, "..");

// `srcDir` is the directory that *contains* the `docs/` folder of `.mdx`
// sources; `outDir` is the hosted-site output root that will contain `docs/`.
const srcDir = projectRoot;
const outDir = resolve(projectRoot, "public");

// Public origin the hosted docs are served from. Absolute links in llms.txt,
// the full-context fallback, and the search index are built against this.
const baseUrl = process.env.DOCS_BASE_URL ?? "https://demo-library.dev";

async function main(): Promise<void> {
  // 1. Convert every `docs/*.mdx` into a flattened markdown mirror under
  //    `public/docs/*.md`, applying leadtype's default component flatteners.
  await convertAllMdx({
    srcDir,
    outDir,
    remarkPlugins: defaultRemarkPlugins,
    failOnError: true,
  });

  // 2. Write the routing index `public/llms.txt` (and `public/docs/llms.txt`)
  //    from the source frontmatter + curated nav.
  await generateLlmsTxt({
    srcDir,
    outDir,
    baseUrl,
    product,
    nav,
  });

  // 3. Write the root `public/llms-full.txt` fallback by reading the markdown
  //    mirrors emitted in step 1.
  await generateLLMFullContextFiles({
    outDir,
    baseUrl,
    product,
    nav,
  });

  // 4. Build the static search index (`public/docs/search-index.json`) from the
  //    generated markdown mirrors.
  const search = await generateDocsSearchFiles({
    outDir,
    baseUrl,
  });

  console.log(
    `Docs build complete: ${search.docs} docs, ${search.chunks} chunks, ` +
      `${search.terms} terms -> ${search.outputPath}`,
  );
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
