import path from "node:path";
import { fileURLToPath } from "node:url";

import { convertAllMdx } from "leadtype/convert";
import { generateLLMFullContextFiles, generateLlmsTxt } from "leadtype/llm";
import { defaultRemarkPlugins, remarkInclude, remarkTypeTableToMarkdown } from "leadtype/remark";
import { generateDocsSearchFiles } from "leadtype/search/node";

import { nav, product } from "../docs.config";

const rootDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const srcDir = rootDir;
const docsDir = path.join(srcDir, "docs");
const outDir = path.join(srcDir, "public");
const outDocsDir = path.join(outDir, "docs");

// Set DOCS_BASE_URL (for example, "https://example.com") in hosted builds
// to make links in llms.txt/search artifacts absolute. Leadtype also works
// without it for local builds.
const baseUrl = process.env.DOCS_BASE_URL || undefined;

const remarkPlugins = [
  remarkInclude,
  ...defaultRemarkPlugins.map((plugin) =>
    plugin === remarkTypeTableToMarkdown
      ? [remarkTypeTableToMarkdown, { basePath: srcDir }]
      : plugin,
  ),
];

await convertAllMdx({
  srcDir: docsDir,
  outDir: outDocsDir,
  remarkPlugins,
  failOnError: true,
});

await generateLlmsTxt({
  srcDir,
  outDir,
  baseUrl,
  product,
  nav,
});

await generateLLMFullContextFiles({
  outDir,
  baseUrl,
  product: { name: product.name },
  nav,
});

await generateDocsSearchFiles({
  outDir,
  baseUrl,
});

console.log(`Generated hosted docs artifacts in ${path.relative(rootDir, outDir) || outDir}`);
