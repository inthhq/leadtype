import { convertAllMdx } from "leadtype/convert";
import { generateLlmsTxt, generateLLMFullContextFiles } from "leadtype/llm";
import { generateDocsSearchFiles } from "leadtype/search/node";
import config from "../docs.config.ts";

async function main() {
  const { product, nav } = config;

  console.log("1. Converting MDX files under 'docs/' to Markdown mirrors in 'public/docs/'...");
  await convertAllMdx({
    srcDir: "docs",
    outDir: "public/docs",
  });

  console.log("2. Generating routing index 'public/llms.txt'...");
  await generateLlmsTxt({
    srcDir: ".",
    outDir: "public",
    product,
    nav,
  });

  console.log("3. Generating full-context file 'public/llms-full.txt'...");
  await generateLLMFullContextFiles({
    outDir: "public",
    product,
    nav,
  });

  console.log("4. Generating search index under 'public/docs/'...");
  await generateDocsSearchFiles({
    outDir: "public",
  });

  console.log("Docs pipeline build finished successfully!");
}

main().catch((err) => {
  console.error("Docs build failed:", err);
  process.exit(1);
});
