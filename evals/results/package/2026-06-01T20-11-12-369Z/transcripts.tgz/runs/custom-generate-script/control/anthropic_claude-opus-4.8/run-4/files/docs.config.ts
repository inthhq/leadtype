import { defineDocsConfig } from "leadtype";

export const product = {
  name: "Demo Library",
  summary: "A small library used to exercise the docs pipeline.",
};

export const nav = [{ title: "Get Started", pages: [""] }];

export default defineDocsConfig({ product, nav });
