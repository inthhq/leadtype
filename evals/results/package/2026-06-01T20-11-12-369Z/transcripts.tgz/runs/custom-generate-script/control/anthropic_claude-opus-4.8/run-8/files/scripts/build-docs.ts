/**
 * Build the agent-facing artifacts for a hosted docs site.
 *
 * Uses leadtype's library APIs (not the `leadtype` CLI) so we control the
 * exact step order and output paths. Everything is written under `public/`:
 *
 *   public/docs/*.md             — flattened markdown mirrors of the MDX
 *   public/llms.txt              — routing index (product summary + docs map)
 *   public/llms-full.txt         — root full-context fallback bundle
 *   public/docs/search-index.json — static search index
 *
 * Run order matters: conversion must run first (later steps read the
 * generated `.md` files from the output dir), then the routing index, then
 * the full-context fallback, then the search index.
 */
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";

import { convertAllMdx } from "leadtype/convert";
import {
  generateLLMFullContextFiles,
  generateLlmsTxt,
} from "leadtype/llm";
import { defaultRemarkPlugins } from "leadtype/remark";
import { generateDocsSearchFiles } from "leadtype/search/node";

import { nav, product } from "../docs.config.ts";

// Resolve paths relative to the project root (one level up from scripts/).
const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");

// `srcDir` is the repo root that *contains* the `docs/` source directory;
// `outDir` is the hosted site's static asset root that will contain `docs/`.
const srcDir = projectRoot;
const outDir = resolve(projectRoot, "public");

// Public origin the hosted docs are served from. Drives absolute links in
// llms.txt, the full-context fallback, and the search index.
const baseUrl = process.env.DOCS_BASE_URL ?? "https://leadtype.dev";

async function main() {
  // 1. Convert every `docs/**/*.mdx` source into a clean markdown mirror at
  //    `public/docs/**/*.md`. The MDX components are flattened by the default
  //    remark plugin stack so the output is agent-readable plain markdown.
  await convertAllMdx({
    srcDir,
    outDir,
    remarkPlugins: defaultRemarkPlugins,
    failOnError: true,
  });

  // 2. Generate the routing index: `public/llms.txt` (product summary) and
  //    `public/docs/llms.txt` (curated docs map). Reads frontmatter from the
  //    `.md`/`.mdx` files under `{srcDir}/docs/`.
  await generateLlmsTxt({
    srcDir,
    outDir,
    baseUrl,
    product,
    nav,
  });

  // 3. Generate the root `public/llms-full.txt` full-context fallback. This
  //    reads the converted `.md` files from `{outDir}/docs/`, so it must run
  //    after step 1.
  await generateLLMFullContextFiles({
    outDir,
    baseUrl,
    product,
    nav,
  });

  // 4. Build the static, edge-safe search index from the generated markdown
  //    mirrors under `{outDir}/docs/`. Writes `public/docs/search-index.json`.
  await generateDocsSearchFiles({
    outDir,
    baseUrl,
  });
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
