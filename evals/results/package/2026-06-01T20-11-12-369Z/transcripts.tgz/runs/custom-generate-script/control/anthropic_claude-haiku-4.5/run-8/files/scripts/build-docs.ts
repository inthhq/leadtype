#!/usr/bin/env node
/**
 * Build script for agent-facing docs artifacts using leadtype library APIs.
 * 
 * Generates:
 * - public/docs/*.md (converted markdown mirrors)
 * - public/llms.txt (routing index with curated navigation)
 * - public/llms-full.txt (fallback full-context file)
 * - public/docs/search-index.json (static search index)
 * - public/docs/{robots.txt, sitemap.md, sitemap.xml} (agent readability artifacts)
 */

import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
import { mkdir } from "node:fs/promises";
import {
  generateLlmsTxt,
  generateLLMFullContextFiles,
  generateAgentReadabilityArtifacts,
} from "leadtype/llm";
import { generateDocsSearchFiles } from "leadtype/search/node";
import { convertAllMdx } from "leadtype/convert";

// Import config from the project root
import docsConfig from "../docs.config.ts";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const projectRoot = resolve(__dirname, "..");

const srcDir = projectRoot;
const outDir = resolve(projectRoot, "public");
const docsDir = resolve(projectRoot, "docs");

async function main() {
  console.log("🚀 Building agent-facing docs artifacts...\n");

  // Ensure output directories exist
  await mkdir(outDir, { recursive: true });
  await mkdir(resolve(outDir, "docs"), { recursive: true });

  try {
    // Step 1: Convert MDX to Markdown
    console.log("📝 Converting MDX to markdown...");
    await convertAllMdx({
      srcDir: docsDir,
      outDir: resolve(outDir, "docs"),
      concurrency: 4,
      failOnError: true,
    });
    console.log("✅ Markdown conversion complete\n");

    // Step 2: Generate llms.txt (routing index with curated navigation)
    console.log("📋 Generating /llms.txt (routing index)...");
    await generateLlmsTxt({
      srcDir: srcDir,
      outDir: outDir,
      baseUrl: process.env.BASE_URL,
      product: docsConfig.product,
      groups: docsConfig.groups,
      nav: docsConfig.nav,
    });
    console.log("✅ /llms.txt generated\n");

    // Step 3: Generate llms-full.txt (full-context fallback)
    console.log("📚 Generating /llms-full.txt (full-context fallback)...");
    await generateLLMFullContextFiles({
      outDir: outDir,
      baseUrl: process.env.BASE_URL,
      product: { name: docsConfig.product.name },
      groups: docsConfig.groups,
      nav: docsConfig.nav,
    });
    console.log("✅ /llms-full.txt generated\n");

    // Step 4: Generate agent readability artifacts (robots.txt, sitemap.md, sitemap.xml)
    console.log("🤖 Generating agent readability artifacts...");
    const readabilityResult = await generateAgentReadabilityArtifacts({
      outDir: resolve(outDir, "docs"),
      baseUrl: process.env.BASE_URL,
      product: {
        name: docsConfig.product.name,
        summary: docsConfig.product.summary,
      },
      groups: docsConfig.groups,
      nav: docsConfig.nav,
    });
    console.log("✅ Agent readability artifacts generated\n");

    // Step 5: Generate static search index
    console.log("🔍 Generating search index...");
    const searchResult = await generateDocsSearchFiles({
      outDir: resolve(outDir, "docs"),
      baseUrl: process.env.BASE_URL,
      outputFile: "search-index.json",
      embedContent: false,
    });
    console.log("✅ Search index generated\n");

    console.log("🎉 All artifacts generated successfully!");
    console.log(`📂 Output directory: ${outDir}`);
    console.log(`\nGenerated files:`);
    console.log(`  - ${outDir}/docs/*.md (converted markdown mirrors)`);
    console.log(`  - ${outDir}/llms.txt (routing index)`);
    console.log(`  - ${outDir}/llms-full.txt (full-context fallback)`);
    console.log(`  - ${outDir}/docs/search-index.json (static search index)`);
    console.log(`  - ${outDir}/docs/robots.txt (agent readability)`);
    console.log(`  - ${outDir}/docs/sitemap.md (markdown sitemap)`);
    console.log(`  - ${outDir}/docs/sitemap.xml (XML sitemap)`);
    console.log(`\nSearch index stats:`);
    console.log(`  - Documents: ${searchResult.docs}`);
    console.log(`  - Chunks: ${searchResult.chunks}`);
    console.log(`  - Terms: ${searchResult.terms}`);
    console.log(`  - Index size: ${(searchResult.indexBytes / 1024).toFixed(2)} KB`);
  } catch (error) {
    console.error("❌ Build failed:", error);
    process.exit(1);
  }
}

main();
