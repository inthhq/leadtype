import { mkdir } from "node:fs/promises";
import path from "node:path";
import docsConfig from "../docs.config.ts";
import { convertAllMdx } from "leadtype/convert";
import { defaultRemarkPlugins } from "leadtype/remark";
import { generateLlmsTxt, generateLLMFullContextFiles } from "leadtype/llm";
import { generateDocsSearchFiles } from "leadtype/search/node";

const { product, nav } = docsConfig;

const SRC_DIR = ".";
const DOCS_SRC_DIR = "docs";
const OUT_DIR = "public";

async function main() {
  await mkdir(OUT_DIR, { recursive: true });

  // 1. Convert MDX sources into markdown mirrors under public/docs/
  await convertAllMdx({
    srcDir: DOCS_SRC_DIR,
    outDir: path.join(OUT_DIR, "docs"),
    remarkPlugins: defaultRemarkPlugins,
  });

  // 2. Generate routing index (public/llms.txt + public/docs/llms.txt)
  await generateLlmsTxt({
    srcDir: SRC_DIR,
    outDir: OUT_DIR,
    product,
    nav,
  });

  // 3. Generate root fallback full-context file (public/llms-full.txt)
  await generateLLMFullContextFiles({
    outDir: OUT_DIR,
    product: { name: product.name },
    nav,
  });

  // 4. Generate static search index (public/docs/search-index.json)
  await generateDocsSearchFiles({
    outDir: OUT_DIR,
  });

  console.log("Docs built successfully in", OUT_DIR);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
