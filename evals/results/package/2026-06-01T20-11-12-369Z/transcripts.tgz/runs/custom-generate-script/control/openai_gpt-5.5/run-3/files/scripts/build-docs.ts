import path from "node:path";
import { rm } from "node:fs/promises";

import { convertAllMdx } from "leadtype/convert";
import { generateLLMFullContextFiles, generateLlmsTxt } from "leadtype/llm";
import {
  defaultRemarkPlugins,
  remarkInclude,
  remarkTypeTableToMarkdown,
} from "leadtype/remark";
import { generateDocsSearchFiles } from "leadtype/search/node";

import { nav, product } from "../docs.config";

const projectRoot = process.cwd();
const docsDir = path.join(projectRoot, "docs");
const outDir = path.join(projectRoot, "public");
const outDocsDir = path.join(outDir, "docs");

// Optional, but useful for hosted docs links in llms.txt and the search index.
const baseUrl = process.env.DOCS_BASE_URL ?? process.env.SITE_URL;

const remarkPlugins = [
  remarkInclude,
  ...defaultRemarkPlugins.map((plugin) =>
    plugin === remarkTypeTableToMarkdown
      ? [remarkTypeTableToMarkdown, { basePath: projectRoot }]
      : plugin,
  ),
];

// Remove generated artifacts before rebuilding so deleted/renamed docs do not
// leave stale markdown mirrors or stale index files behind.
await Promise.all([
  rm(outDocsDir, { recursive: true, force: true }),
  rm(path.join(outDir, "llms.txt"), { force: true }),
  rm(path.join(outDir, "llms-full.txt"), { force: true }),
]);

// 1. Convert source MDX into markdown mirrors under public/docs/*.md.
await convertAllMdx({
  srcDir: docsDir,
  outDir: outDocsDir,
  remarkPlugins,
  failOnError: true,
});

// 2. Generate the hosted-site routing indexes.
await generateLlmsTxt({
  srcDir: projectRoot,
  outDir,
  baseUrl,
  product,
  nav,
});

// 3. Generate the root full-context fallback from public/docs/*.md.
await generateLLMFullContextFiles({
  outDir,
  baseUrl,
  product: { name: product.name },
  nav,
});

// 4. Generate the static search index from public/docs/*.md.
await generateDocsSearchFiles({
  outDir,
  baseUrl,
});

console.log(`Built leadtype docs artifacts in ${path.relative(projectRoot, outDir)}`);
