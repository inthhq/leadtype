import { convertAllMdx } from "leadtype/convert";
import { generateLlmsTxt, generateLLMFullContextFiles } from "leadtype/llm";
import { generateDocsSearchFiles } from "leadtype/search/node";
import docsConfig from "../docs.config.ts";

const { product, nav } = docsConfig;

async function main() {
  // 1. Convert MDX source files to markdown mirrors under public/docs
  await convertAllMdx({
    srcDir: "docs",
    outDir: "public/docs",
  });

  // 2. Generate routing index (public/llms.txt and public/docs/llms.txt)
  await generateLlmsTxt({
    srcDir: ".",
    outDir: "public",
    product,
    nav,
  });

  // 3. Generate root full-context fallback (public/llms-full.txt)
  await generateLLMFullContextFiles({
    outDir: "public",
    product: { name: product.name },
    nav,
  });

  // 4. Build static search index from the converted markdown
  await generateDocsSearchFiles({
    outDir: "public",
  });
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
