# Build Script Documentation

## Overview

The `scripts/build-docs.ts` script generates agent-facing artifacts for a hosted docs site using leadtype's library APIs. It is designed to be run during your build process.

## Usage

```bash
npm run build-docs
# or
bun run scripts/build-docs.ts
```

## What It Does

The script performs the following steps in order:

### 1. **Convert MDX to Markdown** (`public/docs/*.md`)
   - Uses `convertAllMdx()` from `leadtype/convert`
   - Converts all `.mdx` files in `docs/` to `.md` files in `public/docs/`
   - Preserves frontmatter and applies configured remark plugins

### 2. **Create Docs Source**
   - Uses `createDocsSource()` from `leadtype`
   - Sets up in-memory docs index for subsequent generation steps
   - Provides navigation and search capabilities

### 3. **Generate Routing Index** (`public/docs/llms.txt`)
   - Uses `generateLlmsTxt()` from `leadtype/llm`
   - Creates a curated navigation manifest for LLM routing
   - Includes product info and navigation structure from `docs.config.ts`

### 4. **Generate Full-Context Fallback** (`public/llms-full.txt`)
   - Uses `generateLLMFullContextFiles()` from `leadtype/llm`
   - Creates a comprehensive fallback file with all docs content
   - Used when agents can't access the routing index

### 5. **Generate Agent Readability Artifacts**
   - Uses `generateAgentReadabilityArtifacts()` from `leadtype/llm`
   - Generates:
     - `public/docs/robots.txt` - Agent discovery metadata
     - `public/docs/sitemap.md` - Markdown-formatted agent sitemap
     - `public/docs/sitemap.xml` - Standard XML sitemap

### 6. **Generate Search Index** (`public/search-index.json`)
   - Uses `generateDocsSearchFiles()` from `leadtype/search/node`
   - Creates static search index for agent and human searches
   - Embeds content for offline search capability

## Configuration

The script imports configuration from `docs.config.ts`:

- **`product`**: Product information (name, summary, optional blocks)
- **`nav`**: Curated navigation tree for agent routing

The base URL is currently hardcoded to `https://docs.example.com`. To use a different base URL, modify the script or pass it as an environment variable:

```typescript
const baseUrl = process.env.DOCS_BASE_URL || "https://docs.example.com";
```

## Output Structure

```
public/
├── docs/
│   ├── *.md                 # Converted markdown mirrors
│   ├── llms.txt             # Routing index
│   ├── robots.txt           # Agent discovery
│   ├── sitemap.md           # Agent sitemap (markdown)
│   └── sitemap.xml          # Standard XML sitemap
├── llms-full.txt            # Full-context fallback
└── search-index.json        # Search index
```

## API References

This script uses the following leadtype library APIs:

- **`leadtype`**: Core docs source API
  - `createDocsSource()` - In-memory docs index
  
- **`leadtype/convert`**: MDX to markdown conversion
  - `convertAllMdx()` - Batch convert all MDX files
  
- **`leadtype/llm`**: LLM/agent artifacts
  - `generateLlmsTxt()` - Routing index generation
  - `generateLLMFullContextFiles()` - Fallback full-context generation
  - `generateAgentReadabilityArtifacts()` - Sitemap & robots.txt generation
  
- **`leadtype/search/node`**: Search indexing
  - `generateDocsSearchFiles()` - Static search index generation

## Error Handling

The script will exit with code 1 if any step fails. Failed conversions are logged with details. Use `failOnError: true` to halt on first error rather than continuing.

## Performance Notes

- Directory scanning happens once during `createDocsSource()`
- All doc files are read and processed sequentially (configurable concurrency in `convertAllMdx()`)
- Search index generation processes all documents in a single pass
- Total time scales with doc count and file sizes
