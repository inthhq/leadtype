import { convertAllMdx } from "leadtype/convert";
import { generateLlmsTxt, generateLLMFullContextFiles } from "leadtype/llm";
import { generateDocsSearchFiles } from "leadtype/search/node";
import { defaultRemarkPlugins } from "leadtype/remark";
import docsConfig from "../docs.config.ts";

const { product, nav } = docsConfig;

const SRC_DIR = ".";
const OUT_DIR = "public";
const BASE_URL = process.env.BASE_URL ?? "";

async function main() {
  // 1. Convert MDX source files into flattened markdown mirrors.
  await convertAllMdx({
    srcDir: "docs",
    outDir: OUT_DIR,
    remarkPlugins: defaultRemarkPlugins,
  });

  // 2. Generate the routing index (public/llms.txt and public/docs/llms.txt).
  await generateLlmsTxt({
    srcDir: SRC_DIR,
    outDir: OUT_DIR,
    baseUrl: BASE_URL,
    product,
    nav,
  });

  // 3. Generate the root full-context fallback (public/llms-full.txt).
  await generateLLMFullContextFiles({
    outDir: OUT_DIR,
    baseUrl: BASE_URL,
    product: { name: product.name },
    nav,
  });

  // 4. Generate the static search index from the converted markdown.
  await generateDocsSearchFiles({
    outDir: OUT_DIR,
    baseUrl: BASE_URL,
  });
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
