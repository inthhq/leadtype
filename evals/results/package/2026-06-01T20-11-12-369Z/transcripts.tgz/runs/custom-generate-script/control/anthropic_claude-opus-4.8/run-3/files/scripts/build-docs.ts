/**
 * Build the agent-facing artifacts for the hosted docs site.
 *
 * Uses leadtype's library APIs (not the `leadtype` CLI) so we control plugin
 * order and output paths. Everything is written under `public/`:
 *
 *   public/docs/*.md            — flattened markdown mirrors of the MDX
 *   public/llms.txt             — routing index (product summary + docs map)
 *   public/llms-full.txt        — root full-context fallback
 *   public/docs/search-index.json — static search index
 *
 * The steps run in dependency order: the markdown mirrors are produced first
 * because `generateLLMFullContextFiles` and `generateDocsSearchFiles` read the
 * generated `.md` files from `public/docs/`.
 */

import { convertAllMdx } from "leadtype/convert";
import {
  generateLLMFullContextFiles,
  generateLlmsTxt,
} from "leadtype/llm";
import { defaultRemarkPlugins } from "leadtype/remark";
import { generateDocsSearchFiles } from "leadtype/search/node";

import { nav, product } from "../docs.config.ts";

// Repo root holding the `docs/` source tree.
const srcDir = ".";
// Output root for the hosted site.
const outDir = "public";
// Public origin the generated absolute links point at.
const baseUrl = "https://leadtype.dev";

async function buildDocs(): Promise<void> {
  // 1. Convert every `docs/**/*.mdx` into a flattened markdown mirror under
  //    `public/docs/`. The default remark stack strips authoring imports and
  //    flattens MDX components into clean markdown agents can read.
  await convertAllMdx({
    srcDir: `${srcDir}/docs`,
    outDir: `${outDir}/docs`,
    remarkPlugins: defaultRemarkPlugins,
    failOnError: true,
  });

  // 2. Generate the routing index `public/llms.txt` (product summary) plus the
  //    curated docs map. Reads frontmatter from the MDX source.
  await generateLlmsTxt({
    srcDir,
    outDir,
    baseUrl,
    product,
    nav,
  });

  // 3. Generate the root `public/llms-full.txt` fallback by concatenating the
  //    markdown mirrors produced in step 1 (read from `public/docs/`).
  await generateLLMFullContextFiles({
    outDir,
    baseUrl,
    product,
    nav,
  });

  // 4. Build the static, edge-safe search index from the generated markdown.
  await generateDocsSearchFiles({
    outDir,
    baseUrl,
  });
}

await buildDocs();
