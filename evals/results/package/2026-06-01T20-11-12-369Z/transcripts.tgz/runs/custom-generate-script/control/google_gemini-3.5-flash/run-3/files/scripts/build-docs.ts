import { mkdir } from "node:fs/promises";
import path from "node:path";
import { convertAllMdx } from "leadtype/convert";
import { defaultRemarkPlugins } from "leadtype/remark";
import { generateLlmsTxt, generateLLMFullContextFiles } from "leadtype/llm";
import { generateDocsSearchFiles } from "leadtype/search/node";
import docsConfig from "../docs.config.ts";

async function main() {
  const srcDir = "docs";
  const outDir = "public";
  const docsOutDir = path.join(outDir, "docs");

  console.log("Creating output directories...");
  await mkdir(docsOutDir, { recursive: true });

  const { product, nav } = docsConfig;

  console.log("Converting MDX docs to Markdown mirrors...");
  await convertAllMdx({
    srcDir,
    outDir: docsOutDir,
    remarkPlugins: defaultRemarkPlugins,
  });

  console.log("Generating routing index (llms.txt)...");
  await generateLlmsTxt({
    srcDir: ".",
    outDir,
    product,
    nav,
  });

  console.log("Generating root fallback full context (llms-full.txt)...");
  await generateLLMFullContextFiles({
    outDir,
    product: { name: product.name },
    nav,
  });

  console.log("Generating static search index...");
  await generateDocsSearchFiles({
    outDir,
  });

  console.log("Build completed successfully!");
}

main().catch((error) => {
  console.error("Build failed:", error);
  process.exit(1);
});
