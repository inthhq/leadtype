import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
import { convertAllMdx } from "leadtype/convert";
import {
  generateLlmsTxt,
  generateLLMFullContextFiles,
  generateAgentReadabilityArtifacts,
} from "leadtype/llm";
import { createDocsSource } from "leadtype";
import config from "../docs.config.ts";

const __dirname = dirname(fileURLToPath(import.meta.url));
const projectRoot = join(__dirname, "..");
const docsDir = join(projectRoot, "docs");
const publicDir = join(projectRoot, "public");
const docsOutDir = join(publicDir, "docs");

async function buildDocs() {
  console.log("🔨 Building docs artifacts...\n");

  // Step 1: Convert MDX files to markdown
  console.log("📝 Converting MDX to markdown...");
  await convertAllMdx({
    srcDir: docsDir,
    outDir: docsOutDir,
  });
  console.log(`✓ Markdown mirrors written to ${docsOutDir}\n`);

  // Step 2: Generate llms.txt routing index
  console.log("🗂️  Generating routing index...");
  await generateLlmsTxt({
    srcDir: projectRoot,
    outDir: publicDir,
    product: config.product,
    nav: config.nav,
  });
  console.log(`✓ Routing index written to ${join(publicDir, "llms.txt")}\n`);

  // Step 3: Generate llms-full.txt fallback
  console.log("📄 Generating full-context fallback...");
  await generateLLMFullContextFiles({
    outDir: publicDir,
    product: { name: config.product.name },
    nav: config.nav,
  });
  console.log(
    `✓ Full-context fallback written to ${join(publicDir, "llms-full.txt")}\n`
  );

  // Step 4: Generate static search index
  console.log("🔍 Generating search index...");
  const docsSource = await createDocsSource({
    contentDir: docsDir,
    nav: config.nav,
  });
  const searchBundle = await docsSource.buildSearchIndex();

  // Write search index as JSON to public directory
  const searchIndexPath = join(publicDir, "docs-search.json");
  await Bun.write(searchIndexPath, JSON.stringify(searchBundle, null, 2));
  console.log(`✓ Search index written to ${searchIndexPath}\n`);

  // Step 5: Generate agent readability artifacts
  console.log("🤖 Generating agent readability artifacts...");
  const readabilityResult = await generateAgentReadabilityArtifacts({
    outDir: publicDir,
    product: config.product,
    nav: config.nav,
  });
  console.log(`✓ Agent readability artifacts generated:`);
  console.log(
    `  - Manifest: ${join(publicDir, readabilityResult.files.manifest)}`
  );
  console.log(
    `  - Robots.txt: ${join(publicDir, readabilityResult.files.robotsTxt)}`
  );
  console.log(
    `  - Sitemap.md: ${join(publicDir, readabilityResult.files.sitemapMd)}`
  );
  console.log(
    `  - Sitemap.xml: ${join(publicDir, readabilityResult.files.sitemapXml)}\n`
  );

  console.log("✨ All docs artifacts built successfully!");
}

buildDocs().catch((error) => {
  console.error("❌ Build failed:", error);
  process.exit(1);
});
