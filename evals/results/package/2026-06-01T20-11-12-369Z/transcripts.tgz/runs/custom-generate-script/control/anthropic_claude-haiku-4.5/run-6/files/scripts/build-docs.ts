import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
import {
  convertAllMdx,
  generateLlmsTxt,
  generateLLMFullContextFiles,
  generateAgentReadabilityArtifacts,
} from "leadtype";
import { generateDocsSearchFiles } from "leadtype/search/node-index";
import config from "../docs.config.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const projectRoot = resolve(__dirname, "..");
const docsDir = resolve(projectRoot, "docs");
const publicDir = resolve(projectRoot, "public");

async function main() {
  console.log("📚 Building docs site artifacts...\n");

  // Step 1: Convert MDX to Markdown
  console.log("1️⃣  Converting MDX files to Markdown...");
  await convertAllMdx({
    srcDir: projectRoot,
    outDir: publicDir,
    enrichFrontmatterFromGit: false,
    failOnError: true,
  });
  console.log("   ✅ Markdown mirrors created at public/docs/*.md\n");

  // Step 2: Generate routing index (docs/llms.txt)
  console.log("2️⃣  Generating routing index (docs/llms.txt)...");
  await generateLlmsTxt({
    srcDir: projectRoot,
    outDir: publicDir,
    baseUrl: process.env.BASE_URL || "http://localhost:3000",
    product: config.product,
    nav: config.nav,
  });
  console.log("   ✅ Routing index created at public/docs/llms.txt\n");

  // Step 3: Generate full-context fallback
  console.log("3️⃣  Generating full-context fallback (llms-full.txt)...");
  await generateLLMFullContextFiles({
    outDir: publicDir,
    baseUrl: process.env.BASE_URL || "http://localhost:3000",
    product: { name: config.product.name },
    nav: config.nav,
  });
  console.log("   ✅ Full-context fallback created at public/llms-full.txt\n");

  // Step 4: Generate agent readability artifacts (optional but recommended)
  console.log("4️⃣  Generating agent readability artifacts...");
  const readabilityResult = await generateAgentReadabilityArtifacts({
    outDir: publicDir,
    baseUrl: process.env.BASE_URL || "http://localhost:3000",
    product: { name: config.product.name, summary: config.product.summary },
    nav: config.nav,
  });
  console.log("   ✅ Agent readability artifacts created:");
  console.log(`      - ${readabilityResult.files.manifest}`);
  console.log(`      - ${readabilityResult.files.robotsTxt}`);
  console.log(`      - ${readabilityResult.files.sitemapMd}`);
  console.log(`      - ${readabilityResult.files.sitemapXml}\n`);

  // Step 5: Generate static search index
  console.log("5️⃣  Generating static search index...");
  const searchResult = await generateDocsSearchFiles({
    outDir: publicDir,
    baseUrl: process.env.BASE_URL || "http://localhost:3000",
    outputFile: "search-index.json",
    embedContent: false,
  });
  console.log("   ✅ Search index created at public/search-index.json");
  console.log(`      - ${searchResult.docs} documents`);
  console.log(`      - ${searchResult.chunks} chunks`);
  console.log(`      - ${searchResult.terms} terms`);
  console.log(`      - ${searchResult.indexBytes} bytes\n`);

  console.log("✨ All artifacts generated successfully!");
  console.log(`📁 Output directory: ${publicDir}`);
}

main().catch((error) => {
  console.error("❌ Build failed:", error.message);
  if (error.stack) {
    console.error(error.stack);
  }
  process.exit(1);
});
