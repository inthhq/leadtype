import { defineDocsConfig } from "leadtype";
import type { DocsNavNode, ProductInfo } from "leadtype/llm";

export const product = {
  name: "Demo Library",
  summary: "A small library used to exercise the docs pipeline.",
} satisfies ProductInfo;

export const nav = [{ title: "Get Started", pages: [""] }] satisfies DocsNavNode[];

export default defineDocsConfig({
  product,
  nav,
});
