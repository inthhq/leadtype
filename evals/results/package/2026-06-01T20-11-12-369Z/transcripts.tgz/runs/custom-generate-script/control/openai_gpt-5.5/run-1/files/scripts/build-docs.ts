import path from "node:path";
import { rm } from "node:fs/promises";

import { convertAllMdx } from "leadtype/convert";
import { generateLLMFullContextFiles, generateLlmsTxt } from "leadtype/llm";
import { defaultRemarkPlugins, remarkInclude } from "leadtype/remark";
import { generateDocsSearchFiles } from "leadtype/search/node";

import { nav, product } from "../docs.config";

const rootDir = process.cwd();
const srcDir = rootDir;
const docsDir = path.join(rootDir, "docs");
const outDir = path.join(rootDir, "public");
const publicDocsDir = path.join(outDir, "docs");
const baseUrl = process.env.DOCS_BASE_URL;

const siteOptions = {
  outDir,
  ...(baseUrl ? { baseUrl } : {}),
};

// Remove only the generated docs artifacts so other public assets can coexist.
await Promise.all([
  rm(publicDocsDir, { force: true, recursive: true }),
  rm(path.join(outDir, "llms.txt"), { force: true }),
  rm(path.join(outDir, "llms-full.txt"), { force: true }),
]);

// 1. Convert source MDX into markdown mirrors at public/docs/**/*.md.
await convertAllMdx({
  srcDir: docsDir,
  outDir: publicDocsDir,
  remarkPlugins: [remarkInclude, ...defaultRemarkPlugins],
});

// 2. Generate the hosted-site routing indexes: /llms.txt and /docs/llms.txt.
await generateLlmsTxt({
  srcDir,
  ...siteOptions,
  product,
  nav,
});

// 3. Generate the root full-context fallback: /llms-full.txt.
await generateLLMFullContextFiles({
  ...siteOptions,
  product: { name: product.name },
  nav,
});

// 4. Generate the static search artifacts under public/docs/.
await generateDocsSearchFiles({
  ...siteOptions,
});

console.log(`Generated hosted docs artifacts in ${path.relative(rootDir, outDir) || outDir}`);
