/**
 * build-docs.ts — produce the agent-facing artifacts for a hosted docs site
 * using leadtype's library APIs directly (not the `leadtype` CLI).
 *
 * Output layout (under `public/`):
 *   - public/docs/*.md            converted markdown mirrors
 *   - public/llms.txt             routing index (+ public/docs/llms.txt map)
 *   - public/llms-full.txt        root full-context fallback
 *   - public/docs/search-index.json   static search index (+ search-content.json)
 *
 * The steps run in the same order the CLI uses for site mode so each stage can
 * consume the previous stage's on-disk output:
 *   1. resolve + validate navigation
 *   2. convert MDX → markdown mirrors
 *   3. generate llms.txt routing index (reads the source frontmatter)
 *   4. generate llms-full.txt (reads the converted mirrors in public/docs)
 *   5. generate the static search index (reads the converted mirrors)
 */

import path from "node:path";
import { fileURLToPath } from "node:url";

import { convertAllMdx } from "leadtype/convert";
import {
  generateLLMFullContextFiles,
  generateLlmsTxt,
  resolveDocsNavigation,
} from "leadtype/llm";
import {
  defaultRemarkPlugins,
  remarkInclude,
} from "leadtype/remark";
import { generateDocsSearchFiles } from "leadtype/search/node";

import docsConfig from "../docs.config.ts";

// `defineDocsConfig` returns the config object; pull the fields the pipeline
// needs straight off it.
const { product, nav } = docsConfig;

// Resolve paths relative to the project root (one level up from scripts/).
const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

// `srcDir` is the *repo root*: the llm/navigation helpers append `/docs`
// themselves to find the source MDX. `convertAllMdx`, by contrast, takes the
// docs folder directly.
const srcDir = projectRoot;
const docsSrcDir = path.join(srcDir, "docs");
const outDir = path.join(projectRoot, "public");

// Base URL for absolute links in llms.txt, the full-context file, and the
// search index. Override via LEADTYPE_BASE_URL for production deploys.
const baseUrl = process.env.LEADTYPE_BASE_URL ?? "https://leadtype.dev";

// Match the CLI's remark stack: expand <include> first, then run the default
// MDX → markdown flattener plugins. typeTableBasePath points at the repo root
// so <ExtractedTypeTable> references resolve.
const remarkPlugins = [
  remarkInclude,
  ...defaultRemarkPlugins,
];

async function main(): Promise<void> {
  // 1. Resolve navigation up front and fail fast on unknown groups, exactly
  //    like the CLI does before emitting any artifacts.
  const navigation = await resolveDocsNavigation({
    srcDir,
    nav,
    baseUrl,
  });
  const firstUnknownGroup = navigation.unknown[0];
  if (firstUnknownGroup) {
    throw new Error(
      `${firstUnknownGroup.urlPath} declares unknown group "${firstUnknownGroup.slug}"`
    );
  }

  // 2. Convert every .mdx under docs/ to public/docs/*.md, preserving the
  //    relative directory structure.
  await convertAllMdx({
    srcDir: docsSrcDir,
    outDir: path.join(outDir, "docs"),
    remarkPlugins,
    failOnError: true,
  });

  // 3. Routing index: writes public/llms.txt (product summary) and
  //    public/docs/llms.txt (curated docs map) from the source frontmatter.
  await generateLlmsTxt({
    srcDir,
    outDir,
    baseUrl,
    product,
    nav,
  });

  // 4. Root fallback: writes public/llms-full.txt by concatenating the
  //    markdown mirrors written in step 2.
  await generateLLMFullContextFiles({
    outDir,
    baseUrl,
    product: { name: product.name },
    nav,
  });

  // 5. Static search index: reads the converted mirrors and writes
  //    public/docs/search-index.json (+ search-content.json).
  const search = await generateDocsSearchFiles({
    outDir,
    baseUrl,
  });

  console.log(
    `Docs pipeline complete: ${search.docs} docs, ${search.chunks} chunks, ` +
      `index written to ${search.outputPath}`
  );
}

main().catch((error) => {
  console.error(error instanceof Error ? error.stack ?? error.message : error);
  process.exitCode = 1;
});
