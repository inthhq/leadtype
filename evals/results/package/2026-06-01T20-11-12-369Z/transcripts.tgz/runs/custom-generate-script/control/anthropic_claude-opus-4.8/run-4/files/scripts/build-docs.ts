/**
 * Build the agent-facing artifacts for a hosted docs site.
 *
 * Uses leadtype's library APIs (not the `leadtype` CLI) so we control the
 * exact pipeline order and output paths. Produces, under `public/`:
 *
 *   - public/docs/*.md            — converted markdown mirrors of the MDX
 *   - public/llms.txt             — routing index (product summary + docs map)
 *   - public/llms-full.txt        — root full-context fallback
 *   - public/docs/search-index.json — static search index
 *
 * Run order matters: the markdown mirrors are produced first because the
 * full-context file and the search index read the *generated* `.md` files,
 * while the routing index reads the *source* docs.
 */
import { convertAllMdx } from "leadtype/convert";
import {
  generateLLMFullContextFiles,
  generateLlmsTxt,
} from "leadtype/llm";
import { defaultRemarkPlugins } from "leadtype/remark";
import { generateDocsSearchFiles } from "leadtype/search/node";

import { nav, product } from "../docs.config.ts";

// Source MDX lives in `docs/`; the hosted site is emitted under `public/`.
// leadtype's llm/search helpers expect a `docs/` subdirectory under their
// `srcDir` / `outDir`, so the source root is "." and the output root is
// "public" while the converted markdown mirrors live in "public/docs".
const SRC_DIR = ".";
const OUT_DIR = "public";
const MDX_SRC_DIR = "docs";
const MD_OUT_DIR = "public/docs";

// Public origin of the hosted docs site. Used to build absolute links in the
// routing index, the full-context fallback, and the search index.
const BASE_URL = "https://docs.example.com";

async function main(): Promise<void> {
  // 1. Convert every `docs/*.mdx` into a flattened markdown mirror under
  //    `public/docs/*.md`. The default remark plugins flatten MDX components
  //    (Cards, Tabs, Callouts, …) into clean agent-readable markdown.
  await convertAllMdx({
    srcDir: MDX_SRC_DIR,
    outDir: MD_OUT_DIR,
    remarkPlugins: defaultRemarkPlugins,
    failOnError: true,
  });

  // 2. Generate the routing index `public/llms.txt` from the source docs.
  await generateLlmsTxt({
    srcDir: SRC_DIR,
    outDir: OUT_DIR,
    baseUrl: BASE_URL,
    product,
    nav,
  });

  // 3. Generate the root full-context fallback `public/llms-full.txt`. This
  //    reads the markdown mirrors written in step 1 from `public/docs/`.
  await generateLLMFullContextFiles({
    outDir: OUT_DIR,
    baseUrl: BASE_URL,
    product,
    nav,
  });

  // 4. Build the static search index. It reads the generated `public/docs/*.md`
  //    and writes `public/docs/search-index.json`.
  await generateDocsSearchFiles({
    outDir: OUT_DIR,
    baseUrl: BASE_URL,
  });
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
