/**
 * Build the agent-facing docs artifacts for a hosted docs site.
 *
 * Uses leadtype's library APIs directly (not the `leadtype` CLI) so we control
 * the order and the exact output paths. Everything is written under `public/`,
 * the conventional static-asset root served at the site origin:
 *
 *   public/docs/*.md          — converted markdown mirrors of the MDX sources
 *   public/llms.txt           — routing index (product summary + docs map)
 *   public/llms-full.txt      — root full-context fallback (whole corpus)
 *   public/docs/search-index.json — static, edge-safe BM25 search index
 *
 * Run order matters: the markdown mirrors must exist before the full-context
 * fallback and the search index are generated, because both read the already
 * converted `.md` files from `public/docs/`.
 */

import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";

import { convertAllMdx } from "leadtype/convert";
import {
  generateLlmsTxt,
  generateLLMFullContextFiles,
} from "leadtype/llm";
import { defaultRemarkPlugins } from "leadtype/remark";
import { generateDocsSearchFiles } from "leadtype/search/node";

import { product, nav } from "../docs.config.ts";

// Resolve paths relative to the project root (this file lives in scripts/).
const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const srcDir = projectRoot;
const outDir = resolve(projectRoot, "public");

// The site is served from this origin; leadtype uses it to rewrite internal
// links to absolute URLs in the routing index and search index.
const baseUrl = "https://leadtype.dev";

async function main() {
  // 1. Convert every docs/*.mdx into a clean markdown mirror under
  //    public/docs/*.md. defaultRemarkPlugins flattens MDX components into
  //    agent-readable markdown. This must run first — later steps read these
  //    generated files.
  await convertAllMdx({
    srcDir: resolve(srcDir, "docs"),
    outDir: resolve(outDir, "docs"),
    remarkPlugins: defaultRemarkPlugins,
    failOnError: true,
  });

  // 2. Routing index at public/llms.txt: the product summary plus a curated
  //    map of the docs, read from the MDX frontmatter under srcDir/docs/.
  await generateLlmsTxt({
    srcDir,
    outDir,
    baseUrl,
    product,
    nav,
  });

  // 3. Root full-context fallback at public/llms-full.txt: concatenates the
  //    converted markdown from public/docs/ into a single file.
  await generateLLMFullContextFiles({
    outDir,
    baseUrl,
    product,
    nav,
  });

  // 4. Static search index at public/docs/search-index.json, built from the
  //    generated markdown mirrors under public/docs/.
  await generateDocsSearchFiles({
    outDir,
    baseUrl,
  });
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
