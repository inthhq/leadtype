import path from "node:path";
import { rm } from "node:fs/promises";

import { convertAllMdx } from "leadtype/convert";
import {
  generateLLMFullContextFiles,
  generateLlmsTxt,
} from "leadtype/llm";
import { defaultRemarkPlugins, remarkInclude } from "leadtype/remark";
import { generateDocsSearchFiles } from "leadtype/search/node";

import docsConfig from "../docs.config";

const { product, nav } = docsConfig;

const projectRoot = process.cwd();
const sourceRoot = projectRoot;
const docsDir = path.join(sourceRoot, "docs");
const outDir = path.join(projectRoot, "public");
const outDocsDir = path.join(outDir, "docs");

// Set DOCS_BASE_URL (or BASE_URL) in hosted builds to make generated links absolute.
const baseUrl = process.env.DOCS_BASE_URL ?? process.env.BASE_URL;

async function cleanGeneratedArtifacts() {
  await Promise.all([
    rm(outDocsDir, { recursive: true, force: true }),
    rm(path.join(outDir, "llms.txt"), { force: true }),
    rm(path.join(outDir, "llms-full.txt"), { force: true }),
  ]);
}

async function buildDocs() {
  await cleanGeneratedArtifacts();

  // 1. Convert source MDX into agent-readable markdown mirrors under public/docs/.
  await convertAllMdx({
    srcDir: docsDir,
    outDir: outDocsDir,
    remarkPlugins: [remarkInclude, ...defaultRemarkPlugins],
    failOnError: true,
  });

  // 2. Generate hosted-site routing/discovery indexes from the source docs.
  await generateLlmsTxt({
    srcDir: sourceRoot,
    outDir,
    baseUrl,
    product,
    nav,
  });

  // 3. Generate the root full-context fallback from the converted markdown mirrors.
  await generateLLMFullContextFiles({
    outDir,
    baseUrl,
    product: { name: product.name },
    nav,
  });

  // 4. Build the static search index from the generated markdown mirrors.
  await generateDocsSearchFiles({
    outDir,
    baseUrl,
  });
}

await buildDocs();
