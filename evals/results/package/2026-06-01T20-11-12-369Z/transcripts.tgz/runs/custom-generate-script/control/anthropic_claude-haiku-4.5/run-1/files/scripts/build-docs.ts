#!/usr/bin/env node
/**
 * Build script: convert docs and generate agent-facing artifacts for a hosted docs site.
 *
 * Produces:
 * - public/docs/*.md (converted markdown mirrors)
 * - public/llms.txt (routing index)
 * - public/llms-full.txt (root fallback)
 * - public/docs/search-index.json (static search index)
 */

import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

import {
  generateLlmsTxt,
  generateLLMFullContextFiles,
  generateAgentReadabilityArtifacts,
} from "leadtype/llm";
import { generateDocsSearchFiles } from "leadtype/search/node";
import { convertAllMdx } from "leadtype/convert";

// Get project root and config
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const projectRoot = path.resolve(__dirname, "..");
const docsConfig = (await import(path.join(projectRoot, "docs.config.ts")))
  .default;

// Validate config has required fields
if (!docsConfig.product) {
  throw new Error("docs.config.ts must export a config with `product` field");
}

const { product, nav } = docsConfig;
const srcDir = projectRoot;
const outDir = path.join(projectRoot, "public");
const docsSourceDir = path.join(srcDir, "docs");

// Create output directory
await fs.mkdir(outDir, { recursive: true });

console.log("🔄 Building docs artifacts...\n");

// 1. Convert .mdx files to .md
console.log("📝 Converting MDX to markdown...");
await convertAllMdx({
  srcDir: docsSourceDir,
  outDir: path.join(outDir, "docs"),
});
console.log("✓ Markdown conversion complete\n");

// 2. Generate llms.txt (routing index for docs)
console.log("📋 Generating llms.txt (routing index)...");
await generateLlmsTxt({
  srcDir,
  outDir,
  baseUrl: process.env.BASE_URL || "http://localhost:3000",
  product,
  nav,
});
console.log("✓ llms.txt generated\n");

// 3. Generate llms-full.txt (root fallback)
console.log("📦 Generating llms-full.txt (full context)...");
await generateLLMFullContextFiles({
  outDir,
  baseUrl: process.env.BASE_URL || "http://localhost:3000",
  product: { name: product.name },
  nav,
});
console.log("✓ llms-full.txt generated\n");

// 4. Generate Agent Readability artifacts (optional but recommended)
console.log("🤖 Generating Agent Readability artifacts...");
try {
  await generateAgentReadabilityArtifacts({
    outDir,
    baseUrl: process.env.BASE_URL || "http://localhost:3000",
    product: { name: product.name, summary: product.summary || "" },
    nav,
  });
  console.log("✓ Agent Readability artifacts generated\n");
} catch (error) {
  console.warn("⚠ Agent Readability generation skipped (optional)\n");
}

// 5. Generate static search index
console.log("🔍 Generating search index...");
const searchResult = await generateDocsSearchFiles({
  outDir,
  baseUrl: process.env.BASE_URL || "http://localhost:3000",
});
console.log(
  `✓ Search index generated (${searchResult.docs} docs, ${searchResult.chunks} chunks)\n`
);

console.log("✅ All artifacts built successfully!");
console.log(`Output directory: ${outDir}`);
console.log("\nGenerated files:");
console.log("  - public/docs/*.md (markdown mirrors)");
console.log("  - public/llms.txt (routing index)");
console.log("  - public/llms-full.txt (full context)");
console.log("  - public/docs/search-index.json (search index)");
console.log("  - public/docs/robots.txt (agent readability)");
console.log("  - public/docs/sitemap.xml (agent readability)");
