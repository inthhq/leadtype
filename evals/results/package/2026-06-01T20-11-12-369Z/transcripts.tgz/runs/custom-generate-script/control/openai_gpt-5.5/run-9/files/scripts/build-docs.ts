import path from "node:path";
import { mkdir, rm } from "node:fs/promises";

import { convertAllMdx } from "leadtype/convert";
import { generateLLMFullContextFiles, generateLlmsTxt } from "leadtype/llm";
import { defaultRemarkPlugins, remarkInclude } from "leadtype/remark";
import { generateDocsSearchFiles } from "leadtype/search/node";

import { nav, product } from "../docs.config";

const rootDir = process.cwd();
const srcDir = rootDir;
const docsDir = path.join(rootDir, "docs");
const outDir = path.join(rootDir, "public");
const outDocsDir = path.join(outDir, "docs");

const baseUrl =
  process.env.DOCS_BASE_URL ??
  process.env.SITE_URL ??
  process.env.NEXT_PUBLIC_SITE_URL ??
  (process.env.VERCEL_PROJECT_PRODUCTION_URL
    ? `https://${process.env.VERCEL_PROJECT_PRODUCTION_URL}`
    : undefined);

async function buildDocs() {
  // Keep generated docs artifacts deterministic between builds without touching
  // other static files a hosted app might keep in public/.
  await mkdir(outDir, { recursive: true });
  await Promise.all([
    rm(outDocsDir, { recursive: true, force: true }),
    rm(path.join(outDir, "llms.txt"), { force: true }),
    rm(path.join(outDir, "llms-full.txt"), { force: true }),
  ]);

  // 1. Convert docs/*.mdx to public/docs/*.md mirrors for agents and tools.
  await convertAllMdx({
    srcDir: docsDir,
    outDir: outDocsDir,
    remarkPlugins: [remarkInclude, ...defaultRemarkPlugins],
    failOnError: true,
  });

  // 2. Generate the hosted routing index at public/llms.txt (and the docs map
  //    at public/docs/llms.txt, which leadtype emits alongside it).
  await generateLlmsTxt({
    srcDir,
    outDir,
    baseUrl,
    product,
    nav,
  });

  // 3. Generate the root full-context fallback at public/llms-full.txt from the
  //    markdown mirrors produced above.
  await generateLLMFullContextFiles({
    outDir,
    baseUrl,
    product: { name: product.name },
    nav,
  });

  // 4. Generate the static search artifacts under public/docs/.
  await generateDocsSearchFiles({
    outDir,
    baseUrl,
  });
}

await buildDocs();

console.log(`Built leadtype docs artifacts in ${path.relative(rootDir, outDir) || outDir}`);
