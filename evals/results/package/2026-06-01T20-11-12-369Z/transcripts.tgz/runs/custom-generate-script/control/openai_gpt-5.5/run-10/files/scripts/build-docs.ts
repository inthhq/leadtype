import path from "node:path";
import { rm } from "node:fs/promises";
import { fileURLToPath } from "node:url";

import { convertAllMdx } from "leadtype/convert";
import { generateLLMFullContextFiles, generateLlmsTxt } from "leadtype/llm";
import { defaultRemarkPlugins, remarkInclude } from "leadtype/remark";
import { generateDocsSearchFiles } from "leadtype/search/node";

import { nav, product } from "../docs.config";

const projectRoot = path.resolve(
  path.dirname(fileURLToPath(import.meta.url)),
  "..",
);
const srcDir = projectRoot;
const docsDir = path.join(projectRoot, "docs");
const outDir = path.join(projectRoot, "public");
const outDocsDir = path.join(outDir, "docs");

// Set DOCS_BASE_URL (or BASE_URL) in hosted builds to emit absolute links in
// llms.txt, llms-full.txt, and search results. Leaving it undefined still
// produces valid local artifacts.
const baseUrl = process.env.DOCS_BASE_URL ?? process.env.BASE_URL;

await rm(outDir, { force: true, recursive: true });

await convertAllMdx({
  srcDir: docsDir,
  outDir: outDocsDir,
  remarkPlugins: [remarkInclude, ...defaultRemarkPlugins],
  failOnError: true,
});

await generateLlmsTxt({
  srcDir,
  outDir,
  baseUrl,
  product,
  nav,
});

await generateLLMFullContextFiles({
  outDir,
  baseUrl,
  product: { name: product.name },
  nav,
});

await generateDocsSearchFiles({
  outDir,
  baseUrl,
});

console.log(`Generated hosted docs artifacts in ${path.relative(projectRoot, outDir)}`);
