import path from "node:path";
import { convertAllMdx } from "leadtype/convert";
import { generateLLMFullContextFiles, generateLlmsTxt } from "leadtype/llm";
import { defaultRemarkPlugins } from "leadtype/remark";
import { generateDocsSearchFiles } from "leadtype/search/node";
import { nav, product } from "../docs.config.ts";

const projectRoot = process.cwd();
const srcDir = projectRoot;
const docsDir = path.join(projectRoot, "docs");
const outDir = path.join(projectRoot, "public");
const docsOutDir = path.join(outDir, "docs");

// Set DOCS_BASE_URL in hosted builds (for example, https://example.com) so
// leadtype can emit absolute URLs in llms.txt/search metadata. The APIs also
// accept undefined, which keeps the artifacts usable in local builds.
const baseUrl = process.env.DOCS_BASE_URL;

await convertAllMdx({
  srcDir: docsDir,
  outDir: docsOutDir,
  remarkPlugins: [...defaultRemarkPlugins],
  failOnError: true,
});

await generateLlmsTxt({
  srcDir,
  outDir,
  baseUrl,
  product,
  nav,
});

await generateLLMFullContextFiles({
  outDir,
  baseUrl,
  product: { name: product.name },
  nav,
});

await generateDocsSearchFiles({
  outDir,
  baseUrl,
});

console.log(`Generated leadtype docs artifacts in ${path.relative(projectRoot, outDir) || outDir}`);
