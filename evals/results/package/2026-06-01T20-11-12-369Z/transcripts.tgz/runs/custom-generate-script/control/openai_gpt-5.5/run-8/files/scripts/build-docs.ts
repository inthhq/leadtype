import path from "node:path";
import { convertAllMdx } from "leadtype/convert";
import { generateLLMFullContextFiles, generateLlmsTxt } from "leadtype/llm";
import { remarkInclude, defaultRemarkPlugins, remarkTypeTableToMarkdown } from "leadtype/remark";
import { generateDocsSearchFiles } from "leadtype/search/node";
import { nav, product } from "../docs.config";

const projectRoot = process.cwd();
const docsDir = path.join(projectRoot, "docs");
const outDir = path.join(projectRoot, "public");
const markdownOutDir = path.join(outDir, "docs");

// Optional for hosted sites; set this in CI if you want absolute URLs in the
// generated llms/search artifacts, for example https://example.com.
const baseUrl = process.env.DOCS_BASE_URL || process.env.NEXT_PUBLIC_SITE_URL;

const remarkPlugins = [
  remarkInclude,
  ...defaultRemarkPlugins.map((plugin) =>
    plugin === remarkTypeTableToMarkdown
      ? [remarkTypeTableToMarkdown, { basePath: projectRoot }]
      : plugin,
  ),
];

await convertAllMdx({
  srcDir: docsDir,
  outDir: markdownOutDir,
  remarkPlugins,
  failOnError: true,
});

await generateLlmsTxt({
  srcDir: projectRoot,
  outDir,
  baseUrl,
  product,
  nav,
});

await generateLLMFullContextFiles({
  outDir,
  baseUrl,
  product: { name: product.name },
  nav,
});

await generateDocsSearchFiles({
  outDir,
  baseUrl,
});

console.log(`Built docs artifacts in ${path.relative(projectRoot, outDir) || "."}`);
