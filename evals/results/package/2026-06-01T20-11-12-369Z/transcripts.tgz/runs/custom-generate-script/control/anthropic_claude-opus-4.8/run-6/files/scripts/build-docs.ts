/**
 * Build the agent-facing artifacts for the HOSTED docs site.
 *
 * This script intentionally uses leadtype's *library* APIs (not the `leadtype`
 * CLI) so the pipeline stages can be sequenced explicitly. It runs them in
 * dependency order:
 *
 *   1. convertAllMdx               → public/docs/*.md               (markdown mirrors)
 *   2. generateLlmsTxt             → public/llms.txt                (routing index)
 *   3. generateLLMFullContextFiles → public/llms-full.txt           (full-context fallback)
 *   4. generateDocsSearchFiles     → public/docs/search-index.json  (static search index)
 *
 * Stages 3 and 4 read the converted `.md` files written by stage 1, so the
 * order is load-bearing.
 *
 * NOTE: the hosted-site outputs (`llms.txt`, root `llms-full.txt`, the search
 * index) are emitted here — NOT `AGENTS.md`, which is a package-bundle artifact
 * produced by `generateAgentsMd` in `--bundle` mode.
 */

import { convertAllMdx } from "leadtype/convert";
import {
  type DocsGroup,
  generateLLMFullContextFiles,
  generateLlmsTxt,
} from "leadtype/llm";
import { defaultRemarkPlugins } from "leadtype/remark";
import { generateDocsSearchFiles } from "leadtype/search/node";

import { nav, product } from "../docs.config.ts";

// `srcDir` is the repo root that *contains* the `docs/` folder. Keeping the
// repo root here (rather than `docs/`) makes `convertAllMdx` preserve the
// `docs/` path segment, so `docs/index.mdx` → `public/docs/index.md`. The llms
// and search generators read from `<outDir>/docs`, so that segment must exist.
const srcDir = ".";

// Hosted-site output root. All artifacts are written under here.
const outDir = "public";

// Public origin the hosted docs are served from. Used to rewrite links and
// build absolute URLs in llms.txt, llms-full.txt, and the search index.
const baseUrl = process.env.DOCS_BASE_URL ?? "https://leadtype.dev";

/**
 * The leadtype LLM generators describe navigation as a `DocsGroup[]` tree
 * (`{ slug, title, description?, children? }`) — group *metadata* only, since
 * per-page membership is declared in each page's frontmatter `group:` field.
 *
 * `docs.config.ts` exports `nav` in the authoring shape
 * (`{ title, pages }[]`), so we project it into the `DocsGroup[]` shape the
 * library expects. Each nav section becomes a group whose `slug` is derived
 * from its title.
 */
function slugify(value: string): string {
  return value
    .toLowerCase()
    .trim()
    .replace(/[^\da-z]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

const groups: DocsGroup[] = nav.map((section) => ({
  slug: slugify(section.title),
  title: section.title,
}));

async function main() {
  // 1. Convert every `docs/**/*.mdx` into a flattened markdown mirror under
  //    `public/docs/`. The default remark plugins flatten MDX components into
  //    clean markdown that agents and tools can read.
  await convertAllMdx({
    srcDir,
    outDir,
    remarkPlugins: defaultRemarkPlugins,
  });

  // 2. Routing index: `public/llms.txt` (product summary + curated docs map).
  //    Reads frontmatter from the source `docs/` tree under `srcDir`.
  await generateLlmsTxt({
    srcDir,
    outDir,
    baseUrl,
    product,
    groups,
  });

  // 3. Root full-context fallback: `public/llms-full.txt`.
  //    Reads the generated `.md` files from `public/docs/`, so this must run
  //    after `convertAllMdx`.
  await generateLLMFullContextFiles({
    outDir,
    baseUrl,
    product,
    groups,
  });

  // 4. Static search index written under `public/docs/` (defaults to
  //    `public/docs/search-index.json` + `search-content.json`). Reads the
  //    generated `.md` files, so this must run after `convertAllMdx`.
  await generateDocsSearchFiles({
    outDir,
    baseUrl,
  });
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
