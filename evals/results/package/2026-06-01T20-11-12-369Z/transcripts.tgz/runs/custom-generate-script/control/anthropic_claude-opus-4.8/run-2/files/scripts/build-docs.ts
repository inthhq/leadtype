/**
 * Build the agent-facing artifacts for a hosted docs site.
 *
 * Uses leadtype's library APIs (not the `leadtype` CLI) to emit, under
 * `public/`:
 *
 *   - the converted markdown mirrors  → public/docs/*.md
 *   - the routing index               → public/llms.txt
 *   - the root full-context fallback  → public/llms-full.txt
 *   - the static search index         → public/docs/search-index.json
 *
 * Directory contract (matches the leadtype library helpers):
 *   - `convertAllMdx` globs `**\/*.mdx` directly under its `srcDir` and writes
 *     the converted `.md` under its `outDir`, preserving structure. To turn
 *     `docs/*.mdx` into `public/docs/*.md`, srcDir = "docs", outDir = "public/docs".
 *   - `generateLlmsTxt` reads source frontmatter from `<srcDir>/docs`, so its
 *     srcDir is the *project root* (the folder that contains `docs/`), and it
 *     writes `<outDir>/llms.txt`.
 *   - `generateLLMFullContextFiles` and `generateDocsSearchFiles` read the
 *     converted mirrors from `<outDir>/docs/*.md` and write into `<outDir>`.
 *
 * The steps therefore run in this order:
 *   1. convertAllMdx writes the markdown mirrors the later steps read.
 *   2. generateLlmsTxt builds the routing index from source frontmatter.
 *   3. generateLLMFullContextFiles concatenates the converted mirrors.
 *   4. generateDocsSearchFiles indexes the converted mirrors.
 */

import { convertAllMdx } from "leadtype/convert";
import {
  generateLLMFullContextFiles,
  generateLlmsTxt,
} from "leadtype/llm";
import { defaultRemarkPlugins } from "leadtype/remark";
import { generateDocsSearchFiles } from "leadtype/search/node";

import { nav, product } from "../docs.config.ts";

// Project root: the directory that contains the `docs/` source folder.
const rootDir = ".";
// Where the MDX sources live, and where the hosted-site artifacts go.
const docsSrcDir = "docs";
const outDir = "public";
const baseUrl = "https://leadtype.dev";

async function main() {
  // 1. Markdown mirrors: docs/*.mdx → public/docs/*.md
  await convertAllMdx({
    srcDir: docsSrcDir,
    outDir: `${outDir}/docs`,
    remarkPlugins: defaultRemarkPlugins,
    failOnError: true,
  });

  // 2. Routing index: public/llms.txt (reads frontmatter from <rootDir>/docs).
  await generateLlmsTxt({
    srcDir: rootDir,
    outDir,
    baseUrl,
    product,
    nav,
  });

  // 3. Root full-context fallback: public/llms-full.txt (reads public/docs/*.md).
  await generateLLMFullContextFiles({
    outDir,
    baseUrl,
    product,
    nav,
  });

  // 4. Static search index: public/docs/search-index.json (indexes public/docs/*.md).
  await generateDocsSearchFiles({
    outDir,
    baseUrl,
  });
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
