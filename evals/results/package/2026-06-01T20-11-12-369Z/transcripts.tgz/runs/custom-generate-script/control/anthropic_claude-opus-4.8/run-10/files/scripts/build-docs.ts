/**
 * build-docs.ts — produce the agent-facing artifacts for a hosted docs site
 * using leadtype's library APIs (not the `leadtype` CLI).
 *
 * Output (all under `public/`):
 *   - public/docs/*.md        converted markdown mirrors
 *   - public/llms.txt         routing index (plus public/docs/llms.txt)
 *   - public/llms-full.txt    root full-context fallback
 *   - public/docs/search-index.json   static search index
 *
 * The steps run in order because later steps read the converted markdown that
 * earlier steps write into `public/docs/`:
 *
 *   1. resolveDocsNavigation — validate nav/groups against the source tree.
 *   2. convertAllMdx         — flatten MDX → public/docs/*.md.
 *   3. generateLlmsTxt       — write public/llms.txt + public/docs/llms.txt.
 *   4. generateLLMFullContextFiles — concatenate public/docs/*.md → llms-full.txt.
 *   5. generateDocsSearchFiles     — build the static search index from public/docs.
 */

import path from "node:path";
import { fileURLToPath } from "node:url";

import {
  generateLLMFullContextFiles,
  generateLlmsTxt,
  resolveDocsNavigation,
} from "leadtype/llm";
import { convertAllMdx } from "leadtype/convert";
import {
  defaultRemarkPlugins,
  remarkInclude,
  remarkTypeTableToMarkdown,
} from "leadtype/remark";
import { generateDocsSearchFiles } from "leadtype/search/node";

import { nav, product } from "../docs.config";

// Project root is the parent of this scripts/ directory.
const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

// `resolveDocsNavigation` / `generateLlmsTxt` expect the *repo root* that
// contains a `docs/` folder; conversion reads that `docs/` directory directly.
const srcDir = projectRoot;
const docsDir = path.join(srcDir, "docs");
const outDir = path.join(projectRoot, "public");

// Public URL the hosted docs are served from. Used to build absolute links in
// llms.txt, llms-full.txt, and the search index.
const baseUrl = process.env.DOCS_BASE_URL ?? "https://example.com";

/**
 * Remark plugin order matters: expand includes first, then run the default
 * flatteners (imports stripped, components flattened). Mirrors the order the
 * CLI uses, and wires `basePath` into the type-table flattener so
 * `<ExtractedTypeTable>` references resolve against the source root.
 */
function buildRemarkPlugins() {
  const plugins: typeof defaultRemarkPlugins = [remarkInclude];
  for (const plugin of defaultRemarkPlugins) {
    if (plugin === remarkTypeTableToMarkdown) {
      plugins.push([remarkTypeTableToMarkdown, { basePath: srcDir }]);
    } else {
      plugins.push(plugin);
    }
  }
  return plugins;
}

async function main() {
  const remarkPlugins = buildRemarkPlugins();

  // 1. Validate the navigation against the source tree before generating.
  //    A page declaring an unknown group is a hard error.
  const navigation = await resolveDocsNavigation({
    srcDir,
    nav,
    baseUrl,
  });
  const unknownGroup = navigation.unknown[0];
  if (unknownGroup) {
    throw new Error(
      `${unknownGroup.urlPath} declares unknown group "${unknownGroup.slug}"`,
    );
  }

  // 2. Convert every .mdx under docs/ to .md under public/docs/, preserving
  //    the relative directory structure. Later steps read these files.
  await convertAllMdx({
    srcDir: docsDir,
    outDir: path.join(outDir, "docs"),
    remarkPlugins,
    failOnError: true,
  });

  // 3. Routing index: public/llms.txt (product summary) and the curated
  //    public/docs/llms.txt docs map. Reads frontmatter from docs/.
  await generateLlmsTxt({
    srcDir,
    outDir,
    baseUrl,
    product,
    nav,
  });

  // 4. Root full-context fallback: public/llms-full.txt. Reads the converted
  //    markdown from public/docs/, so it must run after convertAllMdx.
  await generateLLMFullContextFiles({
    outDir,
    baseUrl,
    product: { name: product.name },
    nav,
  });

  // 5. Static search index: public/docs/search-index.json. Also reads the
  //    converted markdown from public/docs/.
  const search = await generateDocsSearchFiles({
    outDir,
    baseUrl,
  });

  console.log(`Docs artifacts written to ${outDir}`);
  console.log(
    `  search index: ${search.outputPath} (${search.docs} docs, ${search.chunks} chunks)`,
  );
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
