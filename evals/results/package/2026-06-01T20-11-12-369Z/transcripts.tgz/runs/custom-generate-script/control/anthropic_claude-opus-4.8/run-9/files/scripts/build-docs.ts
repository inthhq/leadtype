/**
 * Build the agent-facing docs artifacts for a hosted docs site.
 *
 * Uses leadtype's library APIs directly (not the `leadtype` CLI) so the build
 * has explicit control over plugin order, base URL, and output paths.
 *
 * Output layout (all under `public/`):
 *   - public/docs/*.md            converted markdown mirrors
 *   - public/llms.txt             routing index ( + public/docs/llms.txt map )
 *   - public/llms-full.txt        root full-context fallback
 *   - public/docs/search-index.json   static search index
 */

import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";

import { convertAllMdx } from "leadtype/convert";
import { defaultRemarkPlugins } from "leadtype/remark";
import {
  generateLlmsTxt,
  generateLLMFullContextFiles,
} from "leadtype/llm";
import { generateDocsSearchFiles } from "leadtype/search/node";

import { product, nav } from "../docs.config.ts";

// Resolve everything relative to the project root (parent of scripts/).
const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");

// The MDX source lives at `<root>/docs/*.mdx`; leadtype's llm/search helpers
// expect `srcDir` to be the folder *containing* the `docs/` directory.
const srcDir = projectRoot;
const outDir = resolve(projectRoot, "public");

// Public base URL for the hosted docs site. Used to rewrite links and build
// absolute URLs in the routing index, full-context file, and search index.
const baseUrl = process.env.DOCS_BASE_URL ?? "https://leadtype.dev";

async function main(): Promise<void> {
  // 1. Convert every `docs/*.mdx` source into a flattened markdown mirror at
  //    `public/docs/*.md`. This must run first because the full-context and
  //    search steps read the generated `.md` files from the output dir.
  await convertAllMdx({
    srcDir: resolve(srcDir, "docs"),
    outDir: resolve(outDir, "docs"),
    remarkPlugins: defaultRemarkPlugins,
    failOnError: true,
  });

  // 2. Routing index: `public/llms.txt` (product summary) and the curated
  //    `public/docs/llms.txt` map. Reads frontmatter from the MDX sources.
  await generateLlmsTxt({
    srcDir,
    outDir,
    baseUrl,
    product,
    nav,
  });

  // 3. Root full-context fallback: `public/llms-full.txt`. Reads the generated
  //    markdown mirrors from `public/docs/`.
  await generateLLMFullContextFiles({
    outDir,
    baseUrl,
    product,
    nav,
  });

  // 4. Static search index: `public/docs/search-index.json`. Built from the
  //    generated markdown mirrors.
  await generateDocsSearchFiles({
    outDir,
    baseUrl,
  });
}

main().catch((error: unknown) => {
  console.error(error);
  process.exitCode = 1;
});
