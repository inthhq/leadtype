import { defineDocsConfig } from "leadtype";

const config = defineDocsConfig({
  product: {
    name: "Demo Library",
    summary: "A small library used to exercise the docs pipeline.",
  },
  nav: [{ title: "Get Started", pages: [""] }],
});

export const { product, nav } = config;

export default config;
