import { convertAllMdx } from "leadtype/convert";
import { generateLlmsTxt, generateLLMFullContextFiles } from "leadtype/llm";
import { generateDocsSearchFiles } from "leadtype/search/node-index";
import docsConfig from "../docs.config.ts";
import { fileURLToPath } from "url";
import { dirname, resolve } from "path";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const projectRoot = resolve(__dirname, "..");
const srcDir = resolve(projectRoot, ".");
const outDir = resolve(projectRoot, "public");

async function buildDocs() {
  console.log("🔨 Building docs...");
  console.log(`  Source: ${srcDir}/docs`);
  console.log(`  Output: ${outDir}`);

  try {
    // Step 1: Convert all MDX files to Markdown
    console.log("\n📝 Converting MDX to Markdown...");
    await convertAllMdx({
      srcDir,
      outDir: resolve(outDir, "docs"),
    });
    console.log("✓ Markdown conversion complete");

    // Step 2: Generate the routing index (llms.txt)
    console.log("\n📑 Generating llms.txt routing index...");
    await generateLlmsTxt({
      srcDir,
      outDir,
      product: docsConfig.product,
      nav: docsConfig.nav,
      baseUrl: process.env.BASE_URL,
    });
    console.log("✓ Routing index generated");

    // Step 3: Generate the full context file (llms-full.txt)
    console.log("\n📋 Generating llms-full.txt fallback...");
    await generateLLMFullContextFiles({
      outDir,
      product: { name: docsConfig.product.name },
      nav: docsConfig.nav,
      baseUrl: process.env.BASE_URL,
    });
    console.log("✓ Full context file generated");

    // Step 4: Generate search index
    console.log("\n🔍 Generating search index...");
    await generateDocsSearchFiles({
      outDir: resolve(outDir, "search"),
      baseUrl: process.env.BASE_URL,
    });
    console.log("✓ Search index generated");

    console.log("\n✨ Build complete!");
    process.exit(0);
  } catch (error) {
    console.error("\n❌ Build failed:", error);
    process.exit(1);
  }
}

buildDocs();
