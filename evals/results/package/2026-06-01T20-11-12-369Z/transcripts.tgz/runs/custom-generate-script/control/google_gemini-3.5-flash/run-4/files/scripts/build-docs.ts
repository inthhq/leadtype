import { convertAllMdx } from "leadtype/convert";
import { generateLlmsTxt, generateLLMFullContextFiles } from "leadtype/llm";
import { generateDocsSearchFiles } from "leadtype/search/node";
import config from "../docs.config.ts";

const { product, nav } = config;

async function main() {
  console.log("Building docs artifacts...");

  console.log("1. Converting MDX to Markdown mirrors...");
  await convertAllMdx({
    srcDir: "docs",
    outDir: "public/docs",
  });

  console.log("2. Generating llms.txt...");
  await generateLlmsTxt({
    srcDir: ".",
    outDir: "public",
    product,
    nav,
  });

  console.log("3. Generating llms-full.txt fallback...");
  await generateLLMFullContextFiles({
    outDir: "public",
    product,
    nav,
  });

  console.log("4. Generating static search index...");
  await generateDocsSearchFiles({
    outDir: "public",
  });

  console.log("Successfully built all agent-facing artifacts in public/");
}

main().catch((err) => {
  console.error("Build failed:", err);
  process.exit(1);
});
