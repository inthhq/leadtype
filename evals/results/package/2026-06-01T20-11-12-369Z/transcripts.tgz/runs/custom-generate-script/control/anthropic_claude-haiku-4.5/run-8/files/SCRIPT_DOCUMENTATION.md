# Build Docs Script Documentation

## Overview

The `scripts/build-docs.ts` script is a TypeScript build utility that generates agent-facing documentation artifacts using leadtype's **library APIs** (not the CLI). It processes MDX files from the `docs/` directory and produces a complete hosted docs site output in `public/`.

## What It Does

The script executes five sequential build steps:

### 1. **MDX to Markdown Conversion** (`public/docs/*.md`)
- Converts all `.mdx` files from `docs/` to `.md` files
- Flattens MDX components into clean markdown readable by agents
- Parses and preserves frontmatter metadata
- Uses parallel processing for efficiency

### 2. **Routing Index** (`public/llms.txt`)
- Generates the routing index with product summary
- Includes curated navigation from `docs.config.ts`
- Renders product name, summary, and navigation structure
- Used by agents to discover which documentation pages exist

### 3. **Full-Context Fallback** (`public/llms-full.txt`)
- Creates a complete concatenation of all documentation
- Serves as a fallback when agents need the full context
- Reads from previously-generated markdown files
- Includes all page content in a single file

### 4. **Agent Readability Artifacts** (`public/docs/`)
- Generates `robots.txt` for search indexing
- Generates `sitemap.md` (markdown format) for discoverability
- Generates `sitemap.xml` (XML format) for compatibility
- Used by agents to understand site structure

### 5. **Static Search Index** (`public/docs/search-index.json`)
- Builds a BM25-based static search index
- Chunks documentation into searchable segments
- Tracks document-to-chunk mappings
- Enables edge-safe search without a backend

## Configuration

The script imports configuration from `docs.config.ts`:

```typescript
import docsConfig from "../docs.config.ts";
```

It reads these properties:
- `product.name` — Product display name
- `product.summary` — One-line summary
- `nav` — Curated navigation tree (optional)
- `groups` — Documentation groups (optional, uses nav if provided)

## Running the Script

### Using npm/bun
```bash
npm run build-docs
# or with bun
bun run scripts/build-docs.ts
```

### With environment variables
```bash
BASE_URL=https://docs.example.com npm run build-docs
```

The `BASE_URL` env var is optional and controls the base URL in generated artifacts.

## Output Structure

The script generates the following directory tree:

```
public/
├── llms.txt              # Routing index with navigation
├── llms-full.txt         # Full-context fallback
└── docs/
    ├── index.md          # Converted markdown mirrors
    ├── *.md              # Additional docs pages
    ├── search-index.json # Static BM25 search index
    ├── robots.txt        # Agent discovery metadata
    ├── sitemap.md        # Markdown sitemap
    └── sitemap.xml       # XML sitemap
```

## Library APIs Used

The script uses leadtype's library entry points for maximum control:

- **`leadtype/convert`** — `convertAllMdx()`
  - Converts MDX to markdown without using the CLI
  - Parallel processing with configurable concurrency
  - Full control over output paths and options

- **`leadtype/llm`** — Agent artifact generation:
  - `generateLlmsTxt()` — Routing index
  - `generateLLMFullContextFiles()` — Full-context file
  - `generateAgentReadabilityArtifacts()` — Sitemaps and robots.txt

- **`leadtype/search/node`** — Search index generation:
  - `generateDocsSearchFiles()` — Static BM25 index
  - Reads markdown files and builds chunks
  - Outputs JSON suitable for runtime search

## Error Handling

The script:
- Creates output directories automatically
- Uses `failOnError: true` for markdown conversion
- Catches and logs errors with helpful messages
- Exits with code 1 on failure
- Displays search index statistics on success

## Design Rationale

### Library APIs vs CLI
The library APIs allow:
- Custom plugin ordering
- Fine-grained error handling
- Integration with other build steps
- No subprocess spawning (faster, more reliable)

### Sequential Processing
Steps execute in order because:
1. Markdown must be converted before searching it
2. Search index reads the generated markdown files
3. Each step can handle missing outputs gracefully

### Configuration Import
The script imports `docs.config.ts` directly to:
- Avoid duplication of product info
- Keep a single source of truth
- Support dynamic config (e.g., fetching stars at build time)
- Enable type-safe config in the build step

## Requirements

- Node.js 22+
- `leadtype` package installed
- Valid `docs.config.ts` in project root
- MDX files in `docs/` directory

## Building for Different Environments

### For a Hosted Docs Site
```bash
BASE_URL=https://docs.example.com npm run build-docs
```
Use the generated `public/llms.txt`, `llms-full.txt`, and `search-index.json` on your web server.

### For CI/CD
```bash
npm run build-docs
# Then deploy `public/` directory
```

## Performance Notes

- Markdown conversion uses 4 parallel workers by default
- Search indexing happens in a single pass
- No external I/O beyond reading docs and writing files
- Suitable for pre-build steps in most CI/CD systems

## Extension Points

To customize the build, modify:

1. **Concurrency**: Adjust `convertAllMdx` `concurrency` option
2. **Search Options**: Pass `indexOptions` to `generateDocsSearchFiles`
3. **Base URL**: Set via `BASE_URL` environment variable
4. **Output Paths**: Change `outDir` and `docsDir` variables at the top

For advanced customization (custom plugins, transformers, etc.), use the library APIs directly in a custom build script.
