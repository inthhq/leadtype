import { convertAllMdx } from "leadtype/convert";
import { generateLlmsTxt, generateLLMFullContextFiles } from "leadtype/llm";
import { generateDocsSearchFiles } from "leadtype/search/node";
import docsConfig from "../docs.config.ts";

const { product, nav } = docsConfig as {
  product: { name: string; summary: string };
  nav: unknown;
};

async function main() {
  // 1. Mirror MDX source as flat markdown under public/docs/
  await convertAllMdx({
    srcDir: "docs",
    outDir: "public/docs",
  });

  // 2. Generate llms.txt routing index (and docs/llms.txt)
  await generateLlmsTxt({
    srcDir: ".",
    outDir: "public",
    product,
    nav,
  });

  // 3. Generate root llms-full.txt fallback from the mirrored markdown
  await generateLLMFullContextFiles({
    outDir: "public",
    product: { name: product.name },
    nav,
  });

  // 4. Build the static search index from the mirrored markdown
  const search = await generateDocsSearchFiles({
    outDir: "public",
  });

  console.log("Hosted docs artifacts written to public/");
  console.log("  - Markdown mirrors : public/docs/*.md");
  console.log("  - Routing index    : public/llms.txt");
  console.log("  - Full fallback    : public/llms-full.txt");
  console.log("  - Search index     :", search.outputPath);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
