import { convertAllMdx } from "leadtype/convert";
import { generateLlmsTxt, generateLLMFullContextFiles } from "leadtype/llm";
import { generateDocsSearchFiles } from "leadtype/search/node";
import config from "../docs.config.ts";

const { product, nav } = config;

async function main() {
  console.log("Starting docs build pipeline...");

  // 1. Convert all MDX files to Markdown mirrors
  console.log("Converting MDX files to Markdown mirrors...");
  await convertAllMdx({
    srcDir: "docs",
    outDir: "public/docs",
  });

  // 2. Generate the routing index public/llms.txt and public/docs/llms.txt
  console.log("Generating routing index (llms.txt)...");
  await generateLlmsTxt({
    srcDir: ".",
    outDir: "public",
    product,
    nav,
  });

  // 3. Generate the root public/llms-full.txt fallback
  console.log("Generating full-context fallback (llms-full.txt)...");
  await generateLLMFullContextFiles({
    outDir: "public",
    product,
    nav,
  });

  // 4. Generate the static search index
  console.log("Generating static search index...");
  await generateDocsSearchFiles({
    outDir: "public",
  });

  console.log("Docs build pipeline completed successfully!");
}

main().catch((error) => {
  console.error("Docs build pipeline failed:", error);
  process.exit(1);
});
