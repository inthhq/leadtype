import { mkdir } from "node:fs/promises";
import { existsSync } from "node:fs";
import { convertAllMdx } from "leadtype/convert";
import {
  generateLlmsTxt,
  generateLLMFullContextFiles,
  generateAgentReadabilityArtifacts,
} from "leadtype/llm";
import { generateDocsSearchFiles } from "leadtype/search/node";
import docsConfig from "../docs.config.ts";

async function main() {
  const { product, nav } = docsConfig;
  const outDir = "public";
  const srcDir = "docs";

  console.log("Starting docs build pipeline...");

  // Ensure output directory exists
  if (!existsSync(outDir)) {
    await mkdir(outDir, { recursive: true });
  }

  // 1. Convert all MDX files under docs/ to markdown under public/docs/
  console.log("Converting MDX files to markdown...");
  await convertAllMdx({
    srcDir,
    outDir: `${outDir}/docs`,
  });

  // 2. Generate routing index (public/llms.txt and public/docs/llms.txt)
  console.log("Generating llms.txt...");
  await generateLlmsTxt({
    srcDir,
    outDir,
    product,
    nav,
  });

  // 3. Generate root fallback (public/llms-full.txt)
  console.log("Generating llms-full.txt...");
  await generateLLMFullContextFiles({
    outDir,
    product,
    nav,
  });

  // 4. Generate static search index (public/docs/search-index.json and public/docs/search-content.json)
  console.log("Generating static search index...");
  await generateDocsSearchFiles({
    outDir,
  });

  // 5. Generate additional agent-readability files (robots.txt, sitemap.xml, sitemap.md, agent-readability.json)
  console.log("Generating agent readability artifacts...");
  await generateAgentReadabilityArtifacts({
    outDir,
    product,
    nav,
  });

  console.log("Docs build completed successfully!");
}

main().catch((err) => {
  console.error("Docs build failed:", err);
  process.exit(1);
});
