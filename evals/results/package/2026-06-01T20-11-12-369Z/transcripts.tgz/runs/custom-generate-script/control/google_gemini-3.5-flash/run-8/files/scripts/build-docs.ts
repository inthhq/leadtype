import docsConfig from "../docs.config.ts";
import { convertAllMdx } from "leadtype/convert";
import { generateLlmsTxt, generateLLMFullContextFiles } from "leadtype/llm";
import { generateDocsSearchFiles } from "leadtype/search/node";

const { product, nav } = docsConfig;

async function build() {
  console.log("Starting docs build process...");

  // 1. Convert MDX to Markdown mirrors
  console.log("Converting MDX files to Markdown mirrors...");
  await convertAllMdx({
    srcDir: "docs",
    outDir: "public/docs",
  });

  // 2. Generate routing index (llms.txt & docs/llms.txt)
  console.log("Generating llms.txt and docs/llms.txt...");
  await generateLlmsTxt({
    srcDir: "docs",
    outDir: "public",
    product,
    nav,
  });

  // 3. Generate root llms-full.txt fallback
  console.log("Generating llms-full.txt...");
  await generateLLMFullContextFiles({
    outDir: "public",
    product,
    nav,
  });

  // 4. Generate static search index (search-index.json & search-content.json)
  console.log("Generating static search index files...");
  await generateDocsSearchFiles({
    outDir: "public",
  });

  console.log("Docs build completed successfully!");
}

build().catch((err) => {
  console.error("Build failed:", err);
  process.exit(1);
});
