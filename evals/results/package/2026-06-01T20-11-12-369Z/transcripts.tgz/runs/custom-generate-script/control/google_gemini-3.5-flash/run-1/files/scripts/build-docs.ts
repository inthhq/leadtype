import { mkdir } from "node:fs/promises";
import { convertAllMdx } from "leadtype/convert";
import { generateLlmsTxt, generateLLMFullContextFiles } from "leadtype/llm";
import { generateDocsSearchFiles } from "leadtype/search/node";
import config from "../docs.config.ts";

async function main() {
  console.log("Starting docs build pipeline...");

  // 1. Ensure output directories exist
  await mkdir("public", { recursive: true });
  await mkdir("public/docs", { recursive: true });

  const { product, nav } = config;

  // 2. Convert all MDX files to MD under public/docs/
  console.log("Converting MDX files to Markdown mirrors...");
  await convertAllMdx({
    srcDir: "docs",
    outDir: "public/docs",
  });

  // 3. Generate the routing indexes: public/llms.txt and public/docs/llms.txt
  console.log("Generating llms.txt...");
  await generateLlmsTxt({
    srcDir: ".",
    outDir: "public",
    product,
    nav,
  });

  // 4. Generate the broad full-context fallback: public/llms-full.txt
  console.log("Generating llms-full.txt...");
  await generateLLMFullContextFiles({
    outDir: "public",
    product,
    nav,
  });

  // 5. Generate static search index under public/docs/search-index.json
  console.log("Generating static search index...");
  await generateDocsSearchFiles({
    outDir: "public",
  });

  console.log("Docs build pipeline completed successfully!");
}

main().catch((err) => {
  console.error("Error building docs:", err);
  process.exit(1);
});
