#!/usr/bin/env node
/**
 * Build script for hosted docs site using leadtype library APIs.
 *
 * Produces agent-facing artifacts under `public/`:
 * - Converted markdown mirrors: `public/docs/*.md`
 * - Routing index: `public/llms.txt`
 * - Root fallback: `public/llms-full.txt`
 * - Static search index: `public/docs/search.json`
 */

import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
import { mkdir } from "node:fs/promises";

// Import leadtype library APIs
import { convertAllMdx } from "leadtype/convert";
import {
  generateLlmsTxt,
  generateLLMFullContextFiles,
} from "leadtype/llm";
import { generateDocsSearchFiles } from "leadtype/search/node";

// Import product and nav from docs.config.ts
import config from "../docs.config.ts";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const projectRoot = resolve(__dirname, "..");

// Paths
const srcDir = resolve(projectRoot, "docs");
const outDir = resolve(projectRoot, "public");
const baseUrl = process.env.BASE_URL || "http://localhost:3000";

async function buildDocs() {
  console.log("🚀 Starting docs build...");
  console.log(`   Source: ${srcDir}`);
  console.log(`   Output: ${outDir}`);
  console.log(`   Base URL: ${baseUrl}`);

  try {
    // Ensure output directory exists
    await mkdir(outDir, { recursive: true });

    // Step 1: Convert MDX to Markdown
    console.log("\n📝 Converting MDX to Markdown...");
    await convertAllMdx({
      srcDir: resolve(projectRoot),
      outDir,
      failOnError: true,
    });
    console.log("   ✓ Markdown conversion complete");

    // Step 2: Generate routing index (llms.txt)
    console.log("\n📑 Generating routing index (llms.txt)...");
    await generateLlmsTxt({
      srcDir: resolve(projectRoot),
      outDir,
      baseUrl,
      product: config.product,
      nav: config.nav,
    });
    console.log("   ✓ Routing index generated at public/docs/llms.txt");

    // Step 3: Generate full-context fallback (llms-full.txt)
    console.log("\n📚 Generating full-context fallback (llms-full.txt)...");
    await generateLLMFullContextFiles({
      outDir,
      baseUrl,
      product: { name: config.product.name },
      nav: config.nav,
    });
    console.log("   ✓ Full-context fallback generated at public/llms-full.txt");

    // Step 4: Generate search index
    console.log("\n🔍 Generating search index...");
    const searchResult = await generateDocsSearchFiles({
      outDir,
      baseUrl,
      outputFile: resolve(outDir, "docs", "search.json"),
      embedContent: true,
    });
    console.log(`   ✓ Search index generated (${searchResult.docs} docs, ${searchResult.chunks} chunks)`);

    console.log("\n✅ Docs build complete!");
    console.log("\nGenerated artifacts:");
    console.log("  • public/docs/*.md (markdown mirrors)");
    console.log("  • public/docs/llms.txt (routing index)");
    console.log("  • public/llms-full.txt (full-context fallback)");
    console.log("  • public/docs/search.json (search index)");
  } catch (error) {
    console.error("\n❌ Build failed:", error);
    process.exit(1);
  }
}

buildDocs();
