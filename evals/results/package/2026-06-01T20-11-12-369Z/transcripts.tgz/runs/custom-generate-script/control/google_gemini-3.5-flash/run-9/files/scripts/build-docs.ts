import { convertAllMdx } from "leadtype/convert";
import { generateLlmsTxt, generateLLMFullContextFiles } from "leadtype/llm";
import { generateDocsSearchFiles } from "leadtype/search/node";
import config from "../docs.config.ts";

async function main() {
  console.log("Starting docs build pipeline...");

  try {
    const { product, nav } = config;

    // 1. Convert MDX to Markdown mirrors
    console.log("Step 1: Converting MDX docs to Markdown mirrors under public/docs...");
    await convertAllMdx({
      srcDir: "docs",
      outDir: "public/docs",
    });

    // 2. Generate routing index public/llms.txt and public/docs/llms.txt
    console.log("Step 2: Generating routing indexes (llms.txt)...");
    await generateLlmsTxt({
      srcDir: ".",
      outDir: "public",
      product,
      nav,
    });

    // 3. Generate fallback full-context index public/llms-full.txt
    console.log("Step 3: Generating fallback full-context index (llms-full.txt)...");
    await generateLLMFullContextFiles({
      outDir: "public",
      product,
      nav,
    });

    // 4. Generate the static search index (search-index.json / search-content.json)
    console.log("Step 4: Generating static search index...");
    await generateDocsSearchFiles({
      outDir: "public",
    });

    console.log("Docs build pipeline completed successfully!");
  } catch (error) {
    console.error("Docs build pipeline failed:", error);
    process.exit(1);
  }
}

main();
