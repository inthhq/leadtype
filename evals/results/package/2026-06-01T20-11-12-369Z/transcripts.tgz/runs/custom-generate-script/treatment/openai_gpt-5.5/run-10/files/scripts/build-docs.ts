import { rm } from "node:fs/promises";
import { convertAllMdx } from "leadtype/convert";
import {
  generateAgentReadabilityArtifacts,
  generateLLMFullContextFiles,
  generateLlmsTxt,
} from "leadtype/llm";
import { defaultRemarkPlugins, remarkInclude } from "leadtype/remark";
import { generateDocsSearchFiles } from "leadtype/search/node";
import { nav, product } from "../docs.config";

const srcDir = ".";
const docsDir = "docs";
const outDir = "public";
const docsOutDir = `${outDir}/docs`;
const baseUrl =
  process.env.LEADTYPE_AGENT_BASE_URL ??
  process.env.BASE_URL ??
  process.env.URL ??
  "http://localhost:3000";

const mounts = [{ pathPrefix: "", urlPrefix: "/docs" }];

await rm(outDir, { recursive: true, force: true });

await convertAllMdx({
  srcDir: docsDir,
  outDir: docsOutDir,
  remarkPlugins: [remarkInclude, ...defaultRemarkPlugins],
  failOnError: true,
});

await generateLlmsTxt({
  srcDir,
  outDir,
  baseUrl,
  product,
  nav,
  mounts,
});

await generateLLMFullContextFiles({
  outDir,
  baseUrl,
  product: { name: product.name },
  nav,
  mounts,
});

await generateDocsSearchFiles({
  outDir,
  baseUrl,
  mounts,
});

await generateAgentReadabilityArtifacts({
  outDir,
  baseUrl,
  product,
  nav,
  mounts,
});

console.log(`Generated docs artifacts in ${outDir}/`);
