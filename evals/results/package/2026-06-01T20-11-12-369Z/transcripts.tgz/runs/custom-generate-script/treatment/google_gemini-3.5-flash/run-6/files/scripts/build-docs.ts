import { mkdir } from "node:fs/promises";
import path from "node:path";
import config from "../docs.config.ts";
import { convertAllMdx } from "leadtype/convert";
import { generateLlmsTxt, generateLLMFullContextFiles } from "leadtype/llm";
import { generateDocsSearchFiles } from "leadtype/search/node";

async function main() {
  const { product, nav } = config;
  const outDir = "public";

  console.log("Ensuring output directories exist...");
  await mkdir(path.resolve(outDir, "docs"), { recursive: true });

  console.log("1. Converting MDX files to Markdown mirrors...");
  await convertAllMdx({
    srcDir: "docs",
    outDir: path.join(outDir, "docs"),
  });

  console.log("2. Generating routing index (llms.txt)...");
  await generateLlmsTxt({
    srcDir: ".",
    outDir,
    product,
    nav,
  });

  console.log("3. Generating full fallback index (llms-full.txt)...");
  await generateLLMFullContextFiles({
    outDir,
    product,
    nav,
  });

  console.log("4. Generating static search index (search-index.json & search-content.json)...");
  await generateDocsSearchFiles({
    outDir,
  });

  console.log("Documentation generation complete!");
}

main().catch((err) => {
  console.error("Error building documentation:", err);
  process.exit(1);
});
