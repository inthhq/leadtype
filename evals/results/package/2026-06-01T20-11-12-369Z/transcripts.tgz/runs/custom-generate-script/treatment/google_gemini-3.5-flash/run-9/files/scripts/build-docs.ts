import path from "node:path";
import { convertAllMdx } from "leadtype/convert";
import { defaultRemarkPlugins, remarkInclude } from "leadtype/remark";
import { generateLLMFullContextFiles, generateLlmsTxt } from "leadtype/llm";
import { generateDocsSearchFiles } from "leadtype/search/node";
import docsConfig from "../docs.config.ts";

const { product, nav } = docsConfig;
const outDir = path.resolve("public");
const srcDir = path.resolve(".");
const baseUrl = process.env.BASE_URL || "https://example.com";

async function main() {
  console.log("Starting docs build process...");

  // 1. Convert all MDX files under docs/ to markdown mirrors in public/docs/
  console.log("Converting MDX to markdown mirrors...");
  await convertAllMdx({
    srcDir: path.join(srcDir, "docs"),
    outDir: path.join(outDir, "docs"),
    remarkPlugins: [remarkInclude, ...defaultRemarkPlugins],
  });

  // 2. Generate routing index public/llms.txt and public/docs/llms.txt
  console.log("Generating routing indexes (llms.txt)...");
  await generateLlmsTxt({
    srcDir,
    outDir,
    baseUrl,
    product,
    nav,
  });

  // 3. Generate the root public/llms-full.txt fallback
  console.log("Generating full-context fallback (llms-full.txt)...");
  await generateLLMFullContextFiles({
    outDir,
    baseUrl,
    product: { name: product.name },
    nav,
  });

  // 4. Generate the static search index (public/docs/search-index.json and search-content.json)
  console.log("Generating static search index...");
  await generateDocsSearchFiles({
    outDir,
    baseUrl,
  });

  console.log("Docs build completed successfully!");
}

main().catch((err) => {
  console.error("Error building docs:", err);
  process.exit(1);
});
