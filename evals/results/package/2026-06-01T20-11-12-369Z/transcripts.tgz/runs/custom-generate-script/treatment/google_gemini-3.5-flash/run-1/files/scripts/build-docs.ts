import { mkdir } from "node:fs/promises";
import { convertAllMdx } from "leadtype/convert";
import { generateLlmsTxt, generateLLMFullContextFiles } from "leadtype/llm";
import { generateDocsSearchFiles } from "leadtype/search/node";
import config from "../docs.config.ts";

async function main() {
  console.log("Starting docs build process...");

  const outDir = "public";

  // Ensure output directory exists
  await mkdir(outDir, { recursive: true });

  // 1. Convert all MDX files to Markdown mirrors
  console.log("Converting MDX files...");
  await convertAllMdx({
    srcDir: "docs",
    outDir: "public/docs",
    transformers: config.transformers,
    frontmatterSchema: config.frontmatterSchema,
  });

  // 2. Generate routing index (llms.txt)
  console.log("Generating llms.txt...");
  await generateLlmsTxt({
    srcDir: ".",
    outDir,
    product: config.product,
    nav: config.nav,
    groups: config.groups,
    i18n: config.i18n,
    transformers: config.transformers,
  });

  // 3. Generate llms-full.txt fallback
  console.log("Generating llms-full.txt fallback...");
  await generateLLMFullContextFiles({
    outDir,
    product: config.product,
    nav: config.nav,
    groups: config.groups,
    i18n: config.i18n,
    transformers: config.transformers,
  });

  // 4. Generate the static search index (search-index.json and search-content.json)
  console.log("Generating static search index files...");
  await generateDocsSearchFiles({
    outDir,
    i18n: config.i18n,
    transformers: config.transformers,
  });

  console.log("Docs build complete! Artifacts successfully generated in 'public/'.");
}

main().catch((err) => {
  console.error("Docs build failed:", err);
  process.exit(1);
});
