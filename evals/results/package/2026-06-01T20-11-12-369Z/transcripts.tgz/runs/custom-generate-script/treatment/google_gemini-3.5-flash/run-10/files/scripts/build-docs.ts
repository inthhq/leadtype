import config from "../docs.config.ts";
import { convertAllMdx } from "leadtype/convert";
import { generateLlmsTxt, generateLLMFullContextFiles } from "leadtype/llm";
import { generateDocsSearchFiles } from "leadtype/search/node";

async function main() {
  console.log("Starting docs build pipeline using leadtype library APIs...");

  // 1. Convert all MDX files under docs/ to markdown mirrors in public/docs/
  console.log("Converting MDX files to markdown mirrors...");
  await convertAllMdx({
    srcDir: "docs",
    outDir: "public/docs",
    failOnError: true,
  });

  // 2. Generate routing index at public/llms.txt and public/docs/llms.txt
  console.log("Generating LLM routing index...");
  await generateLlmsTxt({
    srcDir: ".",
    outDir: "public",
    product: config.product,
    nav: config.nav,
    groups: config.groups,
  });

  // 3. Generate the root /llms-full.txt broad full-context fallback
  console.log("Generating full-context llms-full.txt fallback...");
  await generateLLMFullContextFiles({
    outDir: "public",
    product: config.product,
    nav: config.nav,
    groups: config.groups,
  });

  // 4. Generate the static search index (search-index.json and search-content.json)
  console.log("Generating static search index files...");
  await generateDocsSearchFiles({
    outDir: "public",
  });

  console.log("Docs build pipeline completed successfully!");
}

main().catch((err) => {
  console.error("Error building docs:", err);
  process.exit(1);
});
