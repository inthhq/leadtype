import { rm } from "node:fs/promises";
import path from "node:path";

import { convertAllMdx } from "leadtype/convert";
import {
  generateAgentReadabilityArtifacts,
  generateLLMFullContextFiles,
  generateLlmsTxt,
} from "leadtype/llm";
import {
  defaultRemarkPlugins,
  remarkInclude,
  remarkTypeTableToMarkdown,
} from "leadtype/remark";
import { generateDocsSearchFiles } from "leadtype/search/node";
import type { PluggableList } from "unified";

import docsConfig, { nav, product } from "../docs.config";

const sourceRoot = process.cwd();
const docsDir = path.join(sourceRoot, "docs");
const outDir = path.join(sourceRoot, "public");
const outDocsDir = path.join(outDir, "docs");

const {
  groups,
  flatteners,
  frontmatterSchema,
  transformers,
  typeTableBasePath,
  typeTableStrict,
  i18n,
} = docsConfig;

// Set this in CI/hosting when you want absolute canonical URLs. When omitted,
// Leadtype emits root-relative links that still work for static/local builds.
const baseUrl =
  process.env.LEADTYPE_AGENT_BASE_URL ?? process.env.BASE_URL ?? undefined;

const remarkPlugins = [
  remarkInclude,
  ...defaultRemarkPlugins.map((plugin) =>
    plugin === remarkTypeTableToMarkdown
      ? [
          remarkTypeTableToMarkdown,
          {
            basePath: typeTableBasePath
              ? path.resolve(sourceRoot, typeTableBasePath)
              : sourceRoot,
            strict: typeTableStrict,
          },
        ]
      : plugin
  ),
  ...(flatteners ?? []),
] as PluggableList;

// Remove generated docs artifacts that can otherwise survive file renames.
await rm(outDocsDir, { recursive: true, force: true });
await rm(path.join(outDir, "llms.txt"), { force: true });
await rm(path.join(outDir, "llms-full.txt"), { force: true });

// 1. Convert docs/*.mdx into hosted markdown mirrors at public/docs/*.md.
await convertAllMdx({
  srcDir: docsDir,
  outDir: outDocsDir,
  remarkPlugins,
  frontmatterSchema,
  transformers,
  failOnError: typeTableStrict,
});

// 2. Generate the hosted routing index: public/llms.txt (and docs/llms.txt).
await generateLlmsTxt({
  srcDir: sourceRoot,
  outDir,
  baseUrl,
  product,
  groups,
  nav,
  i18n,
  transformers,
});

// 3. Generate the root full-context fallback from public/docs/*.md.
await generateLLMFullContextFiles({
  outDir,
  baseUrl,
  product: { name: product.name },
  groups,
  nav,
  i18n,
  transformers,
});

// 4. Generate the static search index files from public/docs/*.md.
await generateDocsSearchFiles({
  outDir,
  baseUrl,
  i18n,
  transformers,
});

// 5. Generate Leadtype's hosted agent-readability metadata under public/docs/.
await generateAgentReadabilityArtifacts({
  outDir,
  baseUrl,
  product,
  groups,
  nav,
  i18n,
  transformers,
});

console.log(`Built Leadtype docs artifacts in ${path.relative(sourceRoot, outDir)}`);
