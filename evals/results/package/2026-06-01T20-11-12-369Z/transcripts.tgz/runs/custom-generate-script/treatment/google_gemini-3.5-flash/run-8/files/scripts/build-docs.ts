import { mkdir } from "node:fs/promises";
import { convertAllMdx } from "leadtype/convert";
import { generateLlmsTxt, generateLLMFullContextFiles } from "leadtype/llm";
import { generateDocsSearchFiles } from "leadtype/search/node";
import config from "../docs.config.ts";

async function main() {
  console.log("Starting docs build process...");

  const { product, nav } = config;
  const baseUrl = "https://example.com";

  // Ensure output directories exist
  await mkdir("public/docs", { recursive: true });

  // 1. Convert all MDX files in docs/ to markdown files in public/docs/
  console.log("Converting MDX to markdown...");
  await convertAllMdx({
    srcDir: "docs",
    outDir: "public/docs",
  });

  // 2. Generate the routing index (public/llms.txt and public/docs/llms.txt)
  console.log("Generating llms.txt...");
  await generateLlmsTxt({
    srcDir: ".",
    outDir: "public",
    product,
    nav,
    baseUrl,
  });

  // 3. Generate the root llms-full.txt fallback
  console.log("Generating llms-full.txt...");
  await generateLLMFullContextFiles({
    outDir: "public",
    product,
    nav,
    baseUrl,
  });

  // 4. Generate the static search index inside public/docs/
  console.log("Generating static search index...");
  await generateDocsSearchFiles({
    outDir: "public",
    baseUrl,
  });

  console.log("Docs build completed successfully!");
}

main().catch((err) => {
  console.error("Docs build failed:", err);
  process.exit(1);
});
