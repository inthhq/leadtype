import { mkdir } from "node:fs/promises";
import { convertAllMdx } from "leadtype/convert";
import {
  generateAgentReadabilityArtifacts,
  generateLLMFullContextFiles,
  generateLlmsTxt,
} from "leadtype/llm";
import { generateDocsSearchFiles } from "leadtype/search/node";
import docsConfig from "../docs.config.ts";

async function main() {
  console.log("Creating output directory...");
  await mkdir("public", { recursive: true });

  const { product, nav } = docsConfig;

  console.log("1. Converting MDX to Markdown mirrors under public/docs...");
  await convertAllMdx({
    srcDir: "docs",
    outDir: "public/docs",
  });

  console.log("2. Generating routing index public/llms.txt...");
  await generateLlmsTxt({
    srcDir: ".",
    outDir: "public",
    baseUrl: "https://example.com",
    product,
    nav,
  });

  console.log("3. Generating root public/llms-full.txt fallback...");
  await generateLLMFullContextFiles({
    outDir: "public",
    baseUrl: "https://example.com",
    product,
    nav,
  });

  console.log("4. Generating static search index under public/docs...");
  await generateDocsSearchFiles({
    outDir: "public",
    baseUrl: "https://example.com",
  });

  console.log("5. Generating agent readability artifacts...");
  await generateAgentReadabilityArtifacts({
    outDir: "public",
    baseUrl: "https://example.com",
    product,
    nav,
  });

  console.log("Docs build complete!");
}

main().catch((err) => {
  console.error("Build failed:", err);
  process.exit(1);
});
