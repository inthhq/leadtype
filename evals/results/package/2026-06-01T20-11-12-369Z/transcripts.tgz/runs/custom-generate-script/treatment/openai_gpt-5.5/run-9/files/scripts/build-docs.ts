import path from "node:path";
import { rm } from "node:fs/promises";

import { convertAllMdx } from "leadtype/convert";
import {
  generateAgentReadabilityArtifacts,
  generateLLMFullContextFiles,
  generateLlmsTxt,
  resolveDocsNavigation,
} from "leadtype/llm";
import { defaultRemarkPlugins, remarkInclude } from "leadtype/remark";
import { generateDocsSearchFiles } from "leadtype/search/node";

import { nav, product } from "../docs.config";

const sourceRoot = process.cwd();
const docsDir = path.join(sourceRoot, "docs");
const outDir = path.join(sourceRoot, "public");
const outDocsDir = path.join(outDir, "docs");

const baseUrl =
  process.env.LEADTYPE_AGENT_BASE_URL ??
  process.env.BASE_URL ??
  process.env.PORTLESS_URL ??
  "https://docs.example.com";

const mounts = [{ pathPrefix: "", urlPrefix: "/docs" }];

// Start from a clean generated docs surface while leaving any unrelated files in
// public/ alone.
await Promise.all([
  rm(outDocsDir, { recursive: true, force: true }),
  rm(path.join(outDir, "llms.txt"), { force: true }),
  rm(path.join(outDir, "llms-full.txt"), { force: true }),
]);

// Validate the curated navigation against the source tree before writing files.
const navigation = await resolveDocsNavigation({
  srcDir: sourceRoot,
  baseUrl,
  nav,
  mounts,
});

if (navigation.unknown.length > 0) {
  const unknown = navigation.unknown[0];
  throw new Error(
    `${unknown.urlPath} declares unknown navigation/group entry "${unknown.slug}"`
  );
}

// 1. Convert source MDX into agent-readable markdown mirrors.
await convertAllMdx({
  srcDir: docsDir,
  outDir: outDocsDir,
  remarkPlugins: [remarkInclude, ...defaultRemarkPlugins],
});

// 2. Generate the hosted llms.txt routing indexes from the source metadata and
//    the converted markdown mirrors.
await generateLlmsTxt({
  srcDir: sourceRoot,
  outDir,
  baseUrl,
  product,
  nav,
  mounts,
});

// 3. Generate the root full-context fallback from public/docs/*.md.
await generateLLMFullContextFiles({
  outDir,
  baseUrl,
  product: { name: product.name },
  nav,
  mounts,
});

// 4. Generate the static search files consumed by leadtype/search clients.
const search = await generateDocsSearchFiles({
  outDir,
  baseUrl,
  mounts,
});

// Hosted docs sites can also serve these docs-scoped discovery files (sitemap,
// robots, and agent-readability manifest) directly or merge them into site-wide
// equivalents.
const agentReadability = await generateAgentReadabilityArtifacts({
  outDir,
  baseUrl,
  product,
  nav,
  mounts,
});

console.log(
  JSON.stringify(
    {
      outDir,
      files: {
        markdown: outDocsDir,
        llmsTxt: path.join(outDir, "llms.txt"),
        docsLlmsTxt: path.join(outDocsDir, "llms.txt"),
        llmsFullTxt: path.join(outDir, "llms-full.txt"),
        searchIndex: search.outputPath,
        searchContent: search.contentOutputPath,
        agentReadabilityManifest: agentReadability.files.manifest,
      },
    },
    null,
    2
  )
);
