import { rm } from "node:fs/promises";

import { convertAllMdx } from "leadtype/convert";
import {
  generateLLMFullContextFiles,
  generateLlmsTxt,
} from "leadtype/llm";
import { defaultRemarkPlugins, remarkInclude } from "leadtype/remark";
import { generateDocsSearchFiles } from "leadtype/search/node";

import { nav, product } from "../docs.config.ts";

const sourceRoot = ".";
const docsSourceDir = "docs";
const outDir = "public";
const docsOutDir = `${outDir}/docs`;

// Set LEADTYPE_AGENT_BASE_URL (or BASE_URL / URL) in CI for absolute URLs in
// search metadata and LLM artifacts. Leaving this undefined keeps local builds
// runnable without environment setup.
const baseUrl =
  process.env.LEADTYPE_AGENT_BASE_URL ??
  process.env.BASE_URL ??
  process.env.URL ??
  undefined;

// Be explicit that generated markdown under public/docs is served at /docs/*.
const mounts = [{ pathPrefix: "", urlPrefix: "/docs" }];

await Promise.all([
  rm(docsOutDir, { recursive: true, force: true }),
  rm(`${outDir}/llms.txt`, { force: true }),
  rm(`${outDir}/llms-full.txt`, { force: true }),
]);

// 1. Convert docs/*.mdx to public/docs/*.md. Downstream LLM and search APIs
// read these generated markdown mirrors, so conversion must run first.
await convertAllMdx({
  srcDir: docsSourceDir,
  outDir: docsOutDir,
  remarkPlugins: [remarkInclude, ...defaultRemarkPlugins],
  failOnError: true,
});

// 2. Write the hosted-docs routing indexes: public/llms.txt plus the
// docs-scoped public/docs/llms.txt map.
await generateLlmsTxt({
  srcDir: sourceRoot,
  outDir,
  baseUrl,
  product,
  nav,
  mounts,
});

// 3. Write the root public/llms-full.txt fallback from public/docs/*.md.
await generateLLMFullContextFiles({
  outDir,
  baseUrl,
  product: { name: product.name },
  nav,
  mounts,
});

// 4. Write the static search index files under public/docs/.
await generateDocsSearchFiles({
  outDir,
  baseUrl,
  mounts,
});

console.log("Built leadtype docs artifacts in public/.");
