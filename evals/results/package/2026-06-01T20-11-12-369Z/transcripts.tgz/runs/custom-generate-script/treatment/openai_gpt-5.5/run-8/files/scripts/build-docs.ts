import { rm } from "node:fs/promises";
import { convertAllMdx } from "leadtype/convert";
import {
  generateLLMFullContextFiles,
  generateLlmsTxt,
} from "leadtype/llm";
import { defaultRemarkPlugins, remarkInclude } from "leadtype/remark";
import { generateDocsSearchFiles } from "leadtype/search/node";
import { nav, product } from "../docs.config.ts";

const sourceRoot = ".";
const docsDir = "docs";
const outDir = "public";
const generatedDocsDir = `${outDir}/docs`;

// Set LEADTYPE_AGENT_BASE_URL (preferred) or BASE_URL in hosted builds.
const baseUrl =
  process.env.LEADTYPE_AGENT_BASE_URL ??
  process.env.BASE_URL ??
  process.env.PORTLESS_URL ??
  "http://localhost:3000";

// Remove generated docs artifacts first so deleted or renamed source pages do not
// remain visible in llms.txt, llms-full.txt, or the search index.
await Promise.all([
  rm(generatedDocsDir, { recursive: true, force: true }),
  rm(`${outDir}/llms.txt`, { force: true }),
  rm(`${outDir}/llms-full.txt`, { force: true }),
]);

// 1. Convert source MDX to agent-readable markdown mirrors.
await convertAllMdx({
  srcDir: docsDir,
  outDir: generatedDocsDir,
  remarkPlugins: [remarkInclude, ...defaultRemarkPlugins],
});

// 2. Generate the hosted docs routing indexes: /llms.txt and /docs/llms.txt.
await generateLlmsTxt({
  srcDir: sourceRoot,
  outDir,
  baseUrl,
  product,
  nav,
});

// 3. Generate the root fallback that contains the full generated markdown corpus.
await generateLLMFullContextFiles({
  outDir,
  baseUrl,
  product: { name: product.name },
  nav,
});

// 4. Generate the static search files under public/docs/.
await generateDocsSearchFiles({
  outDir,
  baseUrl,
});
