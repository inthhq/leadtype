import { convertAllMdx } from "leadtype/convert";
import {
  generateLLMFullContextFiles,
  generateLlmsTxt,
} from "leadtype/llm";
import { defaultRemarkPlugins, remarkInclude } from "leadtype/remark";
import { generateDocsSearchFiles } from "leadtype/search/node";
import { nav, product } from "../docs.config";

const env =
  (globalThis as { process?: { env?: Record<string, string | undefined> } })
    .process?.env ?? {};

const sourceRoot = ".";
const outDir = "public";
const docsOutDir = `${outDir}/docs`;
const baseUrl =
  env.LEADTYPE_AGENT_BASE_URL ??
  env.BASE_URL ??
  env.PORTLESS_URL ??
  "http://localhost:3000";

await convertAllMdx({
  srcDir: "docs",
  outDir: docsOutDir,
  remarkPlugins: [remarkInclude, ...defaultRemarkPlugins],
  enrichFrontmatterFromGit: true,
  failOnError: true,
});

await generateLlmsTxt({
  srcDir: sourceRoot,
  outDir,
  baseUrl,
  product,
  nav,
});

await generateLLMFullContextFiles({
  outDir,
  baseUrl,
  product: { name: product.name },
  nav,
});

const search = await generateDocsSearchFiles({
  outDir,
  baseUrl,
});

console.log(
  `Built docs artifacts in ${outDir}: markdown mirrors, llms.txt, llms-full.txt, and search (${search.docs} docs, ${search.chunks} chunks).`,
);
