import { defineDocsConfig, type DocsNavNode, type ProductInfo } from "leadtype";

export const product: ProductInfo = {
  name: "Demo Library",
  summary: "A small library used to exercise the docs pipeline.",
};

export const nav: DocsNavNode[] = [{ title: "Get Started", pages: [""] }];

export default defineDocsConfig({
  product,
  nav,
});
