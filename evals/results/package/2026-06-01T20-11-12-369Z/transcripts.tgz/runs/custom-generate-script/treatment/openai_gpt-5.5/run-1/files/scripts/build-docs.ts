import path from "node:path";
import { rm } from "node:fs/promises";
import { convertAllMdx } from "leadtype/convert";
import {
  generateAgentReadabilityArtifacts,
  generateLLMFullContextFiles,
  generateLlmsTxt,
} from "leadtype/llm";
import { defaultRemarkPlugins, remarkInclude } from "leadtype/remark";
import { generateDocsSearchFiles } from "leadtype/search/node";
import { nav, product } from "../docs.config.ts";

const sourceRoot = process.cwd();
const docsDir = path.join(sourceRoot, "docs");
const outDir = path.join(sourceRoot, "public");
const outDocsDir = path.join(outDir, "docs");

// Set DOCS_BASE_URL (for example, https://docs.example.com) in hosted builds
// when you want generated links in llms.txt, search metadata, and sitemaps to
// be absolute. Leaving it undefined still produces usable site-relative files.
const baseUrl = process.env.DOCS_BASE_URL;

await rm(outDir, { recursive: true, force: true });

// 1. Convert source MDX into the markdown mirrors served from /docs/*.md.
await convertAllMdx({
  srcDir: docsDir,
  outDir: outDocsDir,
  remarkPlugins: [remarkInclude, ...defaultRemarkPlugins],
});

// 2. Build the hosted routing indexes. `generateLlmsTxt` writes /llms.txt and
//    /docs/llms.txt; `generateLLMFullContextFiles` writes /llms-full.txt.
await generateLlmsTxt({
  srcDir: sourceRoot,
  outDir,
  baseUrl,
  product,
  nav,
});

await generateLLMFullContextFiles({
  outDir,
  baseUrl,
  product: { name: product.name },
  nav,
});

// 3. Build the static search files from the generated markdown mirrors.
await generateDocsSearchFiles({
  outDir,
  baseUrl,
});

// 4. Also emit hosted agent-readability discovery files under /docs/ so the
//    docs site can expose sitemap/robots/metadata helpers alongside search.
await generateAgentReadabilityArtifacts({
  outDir,
  baseUrl,
  product,
  nav,
});

console.log(`Built docs artifacts in ${path.relative(sourceRoot, outDir) || outDir}`);
