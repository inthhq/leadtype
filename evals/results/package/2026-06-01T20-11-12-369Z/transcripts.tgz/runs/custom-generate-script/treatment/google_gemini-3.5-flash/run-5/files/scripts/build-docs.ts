import { convertAllMdx } from "leadtype/convert";
import { generateLlmsTxt, generateLLMFullContextFiles } from "leadtype/llm";
import { generateDocsSearchFiles } from "leadtype/search/node";
import config from "../docs.config.ts";

async function main() {
  console.log("Starting docs build pipeline...");

  const { product, nav, groups, i18n, transformers } = config;

  // 1. Convert all MDX files in the "docs" directory to Markdown mirrors under "public/docs"
  console.log("Converting MDX files to Markdown mirrors...");
  await convertAllMdx({
    srcDir: "docs",
    outDir: "public/docs",
    transformers,
  });

  // 2. Generate the routing index "public/llms.txt" (and "public/docs/llms.txt")
  console.log("Generating llms.txt...");
  await generateLlmsTxt({
    srcDir: ".",
    outDir: "public",
    product,
    nav,
    groups,
    i18n,
    transformers,
  });

  // 3. Generate the broad full-context fallback "public/llms-full.txt"
  console.log("Generating llms-full.txt...");
  await generateLLMFullContextFiles({
    outDir: "public",
    product,
    nav,
    groups,
    i18n,
    transformers,
  });

  // 4. Generate the static search index (search-index.json & search-content.json)
  console.log("Generating search index...");
  await generateDocsSearchFiles({
    outDir: "public",
    i18n,
    transformers,
  });

  console.log("Docs build pipeline completed successfully!");
}

main().catch((err) => {
  console.error("Docs build pipeline failed:", err);
  process.exit(1);
});
