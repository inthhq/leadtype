import { convertAllMdx } from "leadtype/convert";
import {
  generateAgentReadabilityArtifacts,
  generateLLMFullContextFiles,
  generateLlmsTxt,
} from "leadtype/llm";
import { defaultRemarkPlugins, remarkInclude } from "leadtype/remark";
import { generateDocsSearchFiles } from "leadtype/search/node";
import docsConfig from "../docs.config.ts";

const { product, nav } = docsConfig;

const baseUrl = "https://docs.example.com";
const mounts = [{ pathPrefix: "", urlPrefix: "/docs" }];

console.log("Starting docs build pipeline...");

// 1. Convert all MDX files to Markdown mirrors
console.log("Converting MDX to Markdown...");
await convertAllMdx({
  srcDir: "docs",
  outDir: "public/docs",
  remarkPlugins: [remarkInclude, ...defaultRemarkPlugins],
  enrichFrontmatterFromGit: true,
});

// 2. Generate the routing index llms.txt
console.log("Generating llms.txt...");
await generateLlmsTxt({
  srcDir: ".",
  outDir: "public",
  baseUrl,
  product,
  nav,
  mounts,
});

// 3. Generate the full context llms-full.txt
console.log("Generating llms-full.txt...");
await generateLLMFullContextFiles({
  outDir: "public",
  baseUrl,
  product: { name: product.name },
  nav,
  mounts,
});

// 4. Generate the static search index files
console.log("Generating static search index...");
await generateDocsSearchFiles({
  outDir: "public",
  baseUrl,
  mounts,
});

// 5. Generate additional agent-facing readability artifacts (robots.txt, sitemap.xml, etc.)
console.log("Generating Agent Readability artifacts...");
await generateAgentReadabilityArtifacts({
  outDir: "public",
  baseUrl,
  product,
  nav,
  mounts,
});

console.log("Docs build complete successfully!");
