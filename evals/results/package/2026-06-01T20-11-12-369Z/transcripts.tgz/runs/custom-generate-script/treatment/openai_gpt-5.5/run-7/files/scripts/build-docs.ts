import { rm } from "node:fs/promises";

import { convertAllMdx } from "leadtype/convert";
import {
  generateAgentReadabilityArtifacts,
  generateLLMFullContextFiles,
  generateLlmsTxt,
} from "leadtype/llm";
import { defaultRemarkPlugins, remarkInclude } from "leadtype/remark";
import { generateDocsSearchFiles } from "leadtype/search/node";

import { nav, product } from "../docs.config";

const sourceRoot = ".";
const docsDir = "docs";
const outDir = "public";
const docsOutDir = `${outDir}/docs`;

const baseUrl =
  process.env.LEADTYPE_AGENT_BASE_URL ??
  process.env.BASE_URL ??
  process.env.URL ??
  undefined;

const urlOptions = baseUrl ? { baseUrl } : {};
const navOptions = { ...urlOptions, nav };

await Promise.all([
  rm(docsOutDir, { recursive: true, force: true }),
  rm(`${outDir}/llms.txt`, { force: true }),
  rm(`${outDir}/llms-full.txt`, { force: true }),
]);

await convertAllMdx({
  srcDir: docsDir,
  outDir: docsOutDir,
  remarkPlugins: [remarkInclude, ...defaultRemarkPlugins],
  failOnError: true,
});

await generateLlmsTxt({
  srcDir: sourceRoot,
  outDir,
  product,
  ...navOptions,
});

await generateLLMFullContextFiles({
  outDir,
  product: { name: product.name },
  ...navOptions,
});

await generateDocsSearchFiles({
  outDir,
  ...urlOptions,
});

await generateAgentReadabilityArtifacts({
  outDir,
  product,
  ...navOptions,
});

console.log(`Built docs artifacts in ${outDir}/`);
