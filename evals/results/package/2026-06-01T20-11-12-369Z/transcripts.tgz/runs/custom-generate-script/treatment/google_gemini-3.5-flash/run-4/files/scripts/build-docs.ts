import { convertAllMdx } from "leadtype/convert";
import {
  generateLLMFullContextFiles,
  generateLlmsTxt,
} from "leadtype/llm";
import { generateDocsSearchFiles } from "leadtype/search/node";
import docsConfig from "../docs.config";

const { product, nav } = docsConfig;

async function main() {
  console.log("Starting docs build...");

  // 1. Convert all MDX files to markdown mirrors under public/docs
  console.log("Converting MDX files to markdown...");
  await convertAllMdx({
    srcDir: "docs",
    outDir: "public/docs",
  });

  // 2. Generate the routing index public/llms.txt
  console.log("Generating public/llms.txt...");
  await generateLlmsTxt({
    srcDir: ".",
    outDir: "public",
    product,
    nav,
  });

  // 3. Generate the root public/llms-full.txt broad full-context fallback
  console.log("Generating public/llms-full.txt...");
  await generateLLMFullContextFiles({
    outDir: "public",
    product: { name: product.name },
    nav,
  });

  // 4. Generate the static search index
  console.log("Generating static search index...");
  await generateDocsSearchFiles({
    outDir: "public",
  });

  console.log("Docs build completed successfully!");
}

main().catch((err) => {
  console.error("Docs build failed:", err);
  process.exit(1);
});
