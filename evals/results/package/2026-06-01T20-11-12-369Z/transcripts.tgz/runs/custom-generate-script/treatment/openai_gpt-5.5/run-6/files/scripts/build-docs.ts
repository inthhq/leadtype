import { rm } from "node:fs/promises";
import { convertAllMdx } from "leadtype/convert";
import {
  generateLLMFullContextFiles,
  generateLlmsTxt,
} from "leadtype/llm";
import { defaultRemarkPlugins, remarkInclude } from "leadtype/remark";
import { generateDocsSearchFiles } from "leadtype/search/node";
import { nav, product } from "../docs.config.ts";

const sourceRoot = ".";
const docsDir = "docs";
const outDir = "public";

const baseUrl =
  process.env.LEADTYPE_AGENT_BASE_URL ??
  process.env.BASE_URL ??
  process.env.URL ??
  "https://example.com";

// Remove only the Leadtype-owned outputs so unrelated public assets survive.
await Promise.all([
  rm(`${outDir}/docs`, { recursive: true, force: true }),
  rm(`${outDir}/llms.txt`, { force: true }),
  rm(`${outDir}/llms-full.txt`, { force: true }),
]);

// 1. Convert the source MDX into markdown mirrors. The remaining generators read
//    these files from public/docs, so conversion must happen first.
await convertAllMdx({
  srcDir: `${sourceRoot}/${docsDir}`,
  outDir: `${outDir}/docs`,
  remarkPlugins: [remarkInclude, ...defaultRemarkPlugins],
  failOnError: true,
});

// 2. Generate the hosted-site routing indexes: /llms.txt and /docs/llms.txt.
await generateLlmsTxt({
  srcDir: sourceRoot,
  outDir,
  baseUrl,
  product,
  nav,
});

// 3. Generate the root full-context fallback from the converted markdown.
await generateLLMFullContextFiles({
  outDir,
  baseUrl,
  product: { name: product.name },
  nav,
});

// 4. Generate the static search artifacts under public/docs/.
await generateDocsSearchFiles({
  outDir,
  baseUrl,
});

console.log(`Built Leadtype docs artifacts in ${outDir}/`);
