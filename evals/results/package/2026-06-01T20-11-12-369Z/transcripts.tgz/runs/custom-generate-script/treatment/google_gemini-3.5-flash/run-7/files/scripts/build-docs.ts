import { mkdir } from "node:fs/promises";
import { convertAllMdx } from "leadtype/convert";
import { defaultRemarkPlugins, remarkInclude } from "leadtype/remark";
import {
  generateLlmsTxt,
  generateLLMFullContextFiles,
  generateAgentReadabilityArtifacts,
} from "leadtype/llm";
import { generateDocsSearchFiles } from "leadtype/search/node";
import docsConfig from "../docs.config.ts";

async function main() {
  console.log("Starting docs build pipeline...");

  const { product, nav } = docsConfig;
  const baseUrl = process.env.BASE_URL || "https://example.com";

  // Ensure the public directory exists
  console.log("Ensuring public/ directory exists...");
  await mkdir("public", { recursive: true });

  // 1. Convert all MDX files to Markdown mirrors
  console.log("Converting MDX source files to Markdown mirrors under public/docs/...");
  await convertAllMdx({
    srcDir: "docs",
    outDir: "public/docs",
    remarkPlugins: [remarkInclude, ...defaultRemarkPlugins],
    enrichFrontmatterFromGit: false,
  });

  // 2. Generate routing index public/llms.txt
  console.log("Generating routing index at public/llms.txt...");
  await generateLlmsTxt({
    srcDir: ".",
    outDir: "public",
    baseUrl,
    product,
    nav,
  });

  // 3. Generate root public/llms-full.txt fallback
  console.log("Generating full context fallback at public/llms-full.txt...");
  await generateLLMFullContextFiles({
    outDir: "public",
    baseUrl,
    product: { name: product.name },
    nav,
  });

  // 4. Generate the static search index (public/docs/search-index.json and search-content.json)
  console.log("Generating static search index files under public/docs/...");
  await generateDocsSearchFiles({
    outDir: "public",
    baseUrl,
  });

  // 5. Generate Agent Readability artifacts (sitemap, robots, JSON manifest)
  console.log("Generating agent readability discovery artifacts...");
  await generateAgentReadabilityArtifacts({
    outDir: "public",
    baseUrl,
    product,
    nav,
  });

  console.log("Docs build pipeline completed successfully!");
}

main().catch((err) => {
  console.error("Error building docs:", err);
  process.exit(1);
});
