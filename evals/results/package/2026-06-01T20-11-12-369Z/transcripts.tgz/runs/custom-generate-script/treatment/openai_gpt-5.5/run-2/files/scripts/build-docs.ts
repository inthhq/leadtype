import { convertAllMdx } from "leadtype/convert";
import {
  generateLLMFullContextFiles,
  generateLlmsTxt,
} from "leadtype/llm";
import { defaultRemarkPlugins, remarkInclude } from "leadtype/remark";
import { generateDocsSearchFiles } from "leadtype/search/node";
import { nav, product } from "../docs.config.ts";

const srcDir = ".";
const docsDir = "docs";
const outDir = "public";
const generatedDocsDir = `${outDir}/docs`;

const mounts = [{ pathPrefix: "", urlPrefix: "/docs" }];

function resolveBaseUrl(): string | undefined {
  const rawBaseUrl =
    process.env.LEADTYPE_AGENT_BASE_URL ??
    process.env.BASE_URL ??
    process.env.URL ??
    process.env.VERCEL_URL;

  if (!rawBaseUrl) {
    return undefined;
  }

  return /^https?:\/\//.test(rawBaseUrl)
    ? rawBaseUrl
    : `https://${rawBaseUrl}`;
}

const baseUrl = resolveBaseUrl();

await convertAllMdx({
  srcDir: docsDir,
  outDir: generatedDocsDir,
  remarkPlugins: [remarkInclude, ...defaultRemarkPlugins],
});

await generateLlmsTxt({
  srcDir,
  outDir,
  baseUrl,
  product,
  nav,
  mounts,
});

await generateLLMFullContextFiles({
  outDir,
  baseUrl,
  product: { name: product.name },
  nav,
  mounts,
});

await generateDocsSearchFiles({
  outDir,
  baseUrl,
  mounts,
});

console.log("Built Leadtype docs artifacts in public/.");
