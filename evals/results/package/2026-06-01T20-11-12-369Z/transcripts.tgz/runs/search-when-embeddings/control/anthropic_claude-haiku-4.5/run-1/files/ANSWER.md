# What `leadtype` Gives You by Default

## 1. Default Docs Search Implementation

`leadtype` uses **BM25 (Best Matching 25)** — a statistical ranking algorithm — for docs search **by default**. This is a **static, edge-safe search index** embedded in your docs artifacts.

### What BM25 Does

BM25 is a probabilistic keyword-based retrieval model that scores documents/chunks based on:

- **Term frequency** (how often a query term appears)
- **Inverse document frequency** (how rare a term is across the corpus)
- **Field weighting** (title, headings, body text, and code blocks get different weights)
- **Document length normalization** (longer chunks don't automatically win)

### The Index includes:

- **Pre-indexed term postings** — every term in your docs maps to the chunks it appears in
- **Positional weights** — terms found in titles (weight: 4×) beat those in headings (2×), body text (1×), or code (0.35×)
- **Synonym mapping** (built-in: `ai` → `agent`/`llm`, `install` → `setup`/`add`, etc.)
- **Fuzzy matching** — typos (edit distance ≤ 2), prefix expansion, and stemming (`finding` → `find`)
- **Phrase proximity matching** — queries with multiple terms get boosted if they appear close together in a chunk

### Generated Artifacts

```
search-index.json          # Compressed inverted index + metadata (100s KB typical)
search-content.json        # (Optional) Full chunk texts for rich results
```

**Size:** Typical 500-page docs → ~50–100 KB index, scales linearly. Runs on edge (Cloudflare Workers, Vercel Edge).

### Why This Matters

- **No external dependency** on a hosted vector database
- **Version-matched** — index ships with your docs snapshot
- **Deterministic** — identical query → identical results every time
- **Instant** — runs in-browser or on edge; no network latency after load

---

## 2. When Embeddings Are Warranted

### Add embeddings **only if**:

1. **Your docs contain dense domain knowledge** that relies on *semantic meaning*, not keyword matching  
   - Example: A concept like "stateless function calls" should match "serverless invocations" or "pure functions"
   - BM25 alone would miss those without explicit synonyms
   
2. **Query intent is ambiguous without context**  
   - Example: "How do I speed things up?" could mean caching, parallelism, indexing, or precompilation
   - Semantic search captures the intent better

3. **Your docs are *genuinely long* (10k+ pages with overlapping topics)**  
   - Dense retrieval handles topic drift better than keyword expansion

4. **User satisfaction metrics show keyword search is failing** (actual measurement, not assumption)

---

## 3. What to Keep Even If You Add Embeddings

**Do not replace BM25.** Use embeddings as a **secondary re-ranker or fusion retriever**:

### Keep BM25 for:

- **Exact phrase matching** — "how to deploy on Vercel" should immediately surface that page
- **API/method lookups** — searching for `createSearchClient` must find the right function
- **Recall safety** — BM25 guarantees *some* result if the keyword exists; embeddings may return irrelevant semantic neighbors
- **Low-latency fallback** — edge search when the embedding index is unavailable

### Recommended Hybrid Pattern

```
1. Query BM25 index first (fast, deterministic)
2. Take top K results (e.g., top 20)
3. Re-rank those K with semantic similarity if available
4. Or: Search BM25 + embeddings independently, deduplicate, merge results
```

**Example:** leadtype supports `search/vercel`, `search/tanstack`, and `search/cloudflare` adapters that stream LLM answers from search results — you can pass both BM25 results *and* optional embeddings to the LLM context builder.

---

## Summary

| Aspect | BM25 (Default) | Embeddings (Optional) |
|--------|----------------|-----------------------|
| **Algorithm** | Statistical keyword + field weighting | Semantic similarity |
| **Artifacts** | `search-index.json` (~50–100 KB) | Vector DB + embeddings (~MB–GB) |
| **Dependency** | None; runs on edge | External (Pinecone, Weaviate, etc.) |
| **Best for** | Exact terms, API lookups, phrase search | Conceptual similarity, intent matching |
| **Latency** | Sub-millisecond | Network + DB + inference latency |
| **Cost** | Free | Monthly hosting + indexing |

**Before building a hosted vector DB:** Measure BM25 performance in your actual use case. Add hybrid search only if metrics prove keyword retrieval is insufficient. Keep BM25 as the primary tier — it's fast, self-contained, and covers 80% of docs search use cases.
