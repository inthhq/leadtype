# Leadtype docs search and embeddings

## What Leadtype uses by default

Leadtype already ships a docs-search pipeline. In normal site generation (`leadtype generate`), it produces static search artifacts under the generated docs output, by default:

- `docs/search-index.json`
- `docs/search-content.json` unless content is embedded into the index

Those artifacts are queried by the edge-safe runtime/client (`leadtype/search`, `leadtype/search/client`, framework hooks such as `useLeadtypeSearch`). There is no hosted vector database or embedding service in the default path.

The default retrieval model is lexical BM25 over generated Markdown chunks. The implementation:

- chunks flattened Markdown docs by headings, with default chunk size/overlap (`maxChunkChars: 1200`, `overlapChars: 160`);
- indexes title, heading, body, and code fields with different weights;
- tokenizes and normalizes terms, drops common stopwords, and supports stemming, built-in/custom synonyms, prefix matching, typo tolerance, phrase boosts, and proximity boosts;
- returns source-linked results with excerpts and URLs/anchors;
- can build source-grounded answer context (`createAnswerContext` / `streamDocsAnswer`) from the same BM25 results, with citations and instructions to use only the provided docs context.

So Leadtype's default is a static, file-backed BM25 search index plus optional LLM answer streaming over retrieved source chunks — not RAG backed by hosted embeddings.

## When embeddings are actually warranted

Add embeddings only after the default Leadtype search has been shipped or evaluated and you can show a real retrieval gap that lexical search cannot cover. Good triggers are:

1. **Measured semantic-recall failures**: query logs or an eval set show important queries where users phrase intent in words that do not appear in the relevant docs, and BM25/synonyms/frontmatter improvements do not fix it.
2. **Large or conceptually broad corpus**: the docs are big enough, heterogeneous enough, or written with enough vocabulary drift that exact-term retrieval misses whole classes of “how do I accomplish X?” questions.
3. **Cross-language or terminology-bridging requirements**: users search in language/terms materially different from the docs, and a multilingual/semantic model demonstrably improves recall.
4. **You need semantic reranking/recall for natural-language Q&A**: the product requires high-quality conversational discovery beyond API names, commands, config keys, errors, and paths.
5. **Operational requirements are accepted**: the team is ready to own embedding model choice, reindexing, hosting, latency, privacy/security review, cost, monitoring, and an eval suite proving that quality improved.

Even then, keep Leadtype's default search path. Use embeddings as a hybrid layer, not a replacement:

- Keep the Leadtype-generated Markdown chunks and source/content artifacts as the canonical retrievable material.
- Keep BM25 keyword search for exact identifiers: API names, options, error codes, file paths, package names, CLI commands, headings, and code snippets. Embeddings are often worse at these.
- Keep source-grounded answer construction and citations so generated answers remain tied to docs chunks and URLs.
- Prefer hybrid retrieval: BM25 + vector recall, optionally with reranking, then feed the selected Leadtype chunks into the answer context.
- Keep the static Leadtype index as a fast, cheap, edge-safe fallback if the vector service is slow, unavailable, stale, or over budget.

In short: start with Leadtype's static BM25 docs search. Add embeddings only when evaluated user behavior proves semantic recall is the bottleneck, and preserve BM25/source-grounding as the safety and precision layer.