# Leadtype Search Architecture and Recommendations

Before standing up a hosted, database-backed vector database for Retrieval-Augmented Generation (RAG) and docs search, here is a detailed breakdown of what `leadtype` already provides by default, and a rigorous analysis of when (and how) to introduce dense embeddings.

---

## 1. What Leadtype's Docs Search Uses by Default

By default, `leadtype` implements a highly optimized, **serverless, static keyword search engine** based on the state-of-the-art **BM25 (Best Matching 25)** text-ranking algorithm (a probabilistic refinement of TF-IDF). 

### How it Works (Under the Hood)
1. **Static Build-Time Compilation**: 
   When running `npx leadtype generate`, the library parses and flattens your MDX pages into clean markdown. It chunks the text at sentence/space boundaries (default: `maxChunkChars = 1200`, `overlapChars = 160`) and pre-computes an inverted index. This is serialized into a static, lightweight JSON package (`search-index.json` and `search-content.json`).
   
2. **Zero-Database Runtime**:
   Because the index is entirely self-contained within static JSON artifacts, search queries execute **in-memory** on the client (browser), in a serverless function, or at the CDN edge (Cloudflare Workers, Vercel Edge). **No external database, vector store, or dedicated hosted backend is required.**

### Out-of-the-Box Features and Search Quality Tuning
Unlike basic string matching, `leadtype`'s search engine includes sophisticated features that rival complex hosted databases:

* **Granular Field Weighting**:
  Matches are scored differently based on where they appear inside the document structure. Leadtype uses these default weights to ensure high-value regions rank highest:
  * **Title**: `4.0`
  * **Heading**: `2.0`
  * **Body Paragraph**: `1.0`
  * **Code Block Content**: `0.35` (ensures code syntax matches don't drown out natural language explanations)

* **Stemming and Suffix Stripping**:
  It runs a suffix-stripping pass to normalize words (e.g., maps `ies -> y`, and trims `ing`, `ed`, `es`, `s` for words with length $\ge 4$). This ensures a search for `"installing"` or `"installs"` correctly matches `"install"`.

* **Typo Tolerance via Edit Distance**:
  It calculates Levenshtein/Damerau-Levenshtein style edit distances on misspelled terms.
  * For 4-6 character words: allows up to **1 typo**.
  * For words with 7+ characters: allows up to **2 typos**.

* **Phrase and Proximity Boosting**:
  * Exact multi-token phrase matches receive a score boost of **1.4x**.
  * Multi-token queries found in close proximity within an 8-token sliding window (even if out-of-order) receive a proximity boost of **0.8x**.

* **Alias & Synonym Support**:
  Includes built-in synonym sets mapping developer jargon (e.g., `ai` $\leftrightarrow$ `["agent", "llm"]`, `api` $\leftrightarrow$ `["reference", "sdk"]`, `install` $\leftrightarrow$ `["setup", "add"]`, `ts` $\leftrightarrow$ `["typescript"]`), and lets you supply custom synonyms.

* **Stopword Filtering**:
  Excludes high-frequency, low-meaning words (such as `"the"`, `"and"`, `"with"`, `"for"`, `"is"`, `"how"`) to keep search scoring focused on intent.

### Source-Grounded RAG Out of the Box
If the goal is building a "RAG" agent, **you do not need a vector database to start.** 
`leadtype` provides a built-in search/RAG runtime hook (`createAnswerContext`) that does the following fully at the edge:
1. Runs the fast, client/edge BM25 query.
2. Selects the top $N$ most relevant chunks (respecting text boundaries and token budgets).
3. Compiles them into a structured prompt with system instructions (such as *"Use only the provided documentation context,"* *"Cite supporting sources like [1] and [2],"* and *"Do not invent APIs"*).
4. Directs the compiled payload straight to an LLM provider (e.g. via Vercel AI SDK or Cloudflare AI Workers) to generate source-grounded answers.

---

## 2. When Are Embeddings/Vectors Warranted — And What We Must Keep

While "vector-only RAG" is popular, standing up a hosted vector database is often a premature optimization that degrades query accuracy for technical documentation.

### Specific Conditions Under Which Adding Embeddings is Actually Warranted

1. **Conceptual & Synonym Gap (Semantic Matching)**:
   When users express questions using highly abstract or high-level language that does not overlap with your technical terminology (e.g., searching for *"How do I speed up my page loads"* when your docs only contain specific terms like *"cache tuning"*, *"lazy loading"*, or *"latency constraints"*).
   
2. **Conversational, Long-Form Queries**:
   When users enter long, narrative-style questions (e.g., *"I have been having this issue since Tuesday where my bundle sizes are too large and I tried splitting code but it still fails..."*). Keyword-based BM25 struggles with noisy, conversational filler, whereas dense embeddings excel at summarizing the high-level semantic intent of entire paragraphs.

3. **Massive Documentation Scale**:
   `leadtype` issues build-time alerts if your static search indexes exceed certain safety boundaries (e.g., total index payload over `5 MB`, total chunks > `10,000`, or combined index and content over `10 MB`). If your documentation is so massive that loading the static index on the client/edge strains bandwidth or memory limits, a hosted, server-side search system is required.

---

### What We Must Keep: The "Hybrid" Imperative

If you do decide to implement dense embeddings and a vector store, **do not throw away `leadtype`'s keyword search.** Technical documentation search demands a **Hybrid Search** (combining BM25 and Vector Search via algorithms like Reciprocal Rank Fusion - RRF). 

You must keep BM25 keyword matching for several critical reasons:

* **Exact Matches (APIs, Code, Command Line Flags)**:
  Vector embeddings compress text into dense semantic spaces and are notoriously bad at matching exact character sequences. A vector search will frequently fail to distinguish between closely named APIs (e.g., `createSearchClient` vs. `useLeadtypeSearch`) or locate specific CLI flags (e.g., `--bundle`). BM25 excels at exact keyword matching.
  
* **Error Code and Version Searches**:
  Users looking up a specific error code (e.g., `413`) or error string will get highly irrelevant matches with vectors because numbers do not have rich conceptual meaning in standard embedding spaces. Keyword search handles this perfectly.

* **Sub-Millisecond UI Autocomplete**:
  Downloading and querying a static keyword index locally on the client takes **<5ms** and operates offline. Querying a hosted vector database requires network roundtrips, embedding model inference (which takes 50-200ms), and database retrieval. You should keep the static BM25 index to power the instant search-as-you-type UI, and only fallback to vector RAG when a user submits a full question.

* **Determinism & Diagnostics**:
  BM25 is fully deterministic and mathematical. You can debug exactly why a result ranked where it did by analyzing term frequencies and weights. Vector search is a black box that can occasionally return completely irrelevant documents due to subtle drift in the embedding model space.

### Recommended Path
Start with **Leadtype's default BM25-backed `createAnswerContext`**. It is lightweight, free to host, and highly tuned for developer documentation. Only proceed to a hosted vector index if you run into scale boundaries or require high-level conceptual/multilingual semantic matching—and even then, deploy a **hybrid pipeline** that fuses Leadtype's keyword scores with your vector scores.
