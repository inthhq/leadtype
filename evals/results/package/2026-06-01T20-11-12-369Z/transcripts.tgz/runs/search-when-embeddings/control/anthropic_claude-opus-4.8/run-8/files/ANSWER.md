# Docs search with `leadtype`: what we already have

Before building a hosted, database-backed vector index, here's what `leadtype`
(v0.1.2, already installed) ships for docs search. The short version: **you
likely don't need a vector DB**, and even if you eventually add embeddings, you
should keep the BM25 layer described below.

## 1. What leadtype's docs search uses by default

leadtype builds a **static, edge-safe lexical search index** from your docs at
build time. There is **no embeddings model, no vector database, and no
inference server** involved. The defaults are:

- **Ranking algorithm: BM25.** The scorer in
  `leadtype/search` (`searchDocs`) uses textbook BM25 with `k1 = 1.2` and
  `b = 0.75`, computing inverse-document-frequency and length-normalized term
  frequency per chunk. This is keyword/lexical retrieval, not vector similarity.

- **A pre-built JSON index, not a runtime database.** `generateDocsSearchFiles`
  (`leadtype/search/node`) is run at build time and emits a
  `search-index.json` (and an optional content store). At query time the
  runtime just reads that JSON — it works on the edge / in the browser with no
  backend service to host, scale, or pay for.

- **Structure-aware chunking and field weighting.** Docs are split into
  overlapping chunks (default ~1200 chars with ~160-char overlap), tracked by
  heading path and anchor. Matches are weighted by where they occur — title
  (×4), headings (×2), body (×1), code (×0.35) — so titles and headings
  outrank incidental body mentions.

- **Lexical recall aids built in.** Even without semantics, the matcher already
  handles a lot of what people reach for embeddings to solve:
  - lightweight stemming (e.g. `installing` → `install`),
  - a synonym table (e.g. `ai`↔`agent`↔`llm`, `config`↔`settings`, `ts`↔`typescript`),
  - prefix expansion (typeahead-style),
  - typo tolerance via bounded edit distance,
  - phrase and ordered-proximity boosts for multi-word queries,
  - stopword removal and Unicode/diacritic normalization.

- **Source-grounded answers ("RAG") on the same index — optional.**
  `createAnswerContext` (`leadtype/search`) performs retrieval with the same
  BM25 search, then assembles cited source blocks plus a hardened system prompt
  (use only provided context, cite with `[1]`/`[2]`, treat docs as untrusted
  reference text, don't invent APIs). Streaming answer adapters exist for
  Vercel AI SDK, TanStack AI, and Cloudflare. **The retrieval step is still
  BM25** — no embeddings are required to get grounded, citation-backed answers.

- **Built-in request safety.** Query validation, body-size limits, a memory
  rate limiter, and client-identifier extraction are provided for the ask/search
  endpoints.

**Bottom line:** out of the box you get a hosted-site or npm-bundled search
index that is keyword-based (BM25), runs at the edge with zero database, and can
already power cited LLM answers.

## 2. When adding embeddings is actually warranted — and what to keep

A hosted vector index is **not** the default "how RAG is done" here, and adding
one has real cost (an embedding model, a vector DB to host/scale/secure, an
ingestion pipeline, and ongoing reindexing). Justify it only when the lexical
index demonstrably falls short. Add embeddings **only if** all of these hold:

1. **You have measured a real recall gap.** Run representative queries against
   the existing BM25 index first. If failures are mostly typos, word-form
   variants, or known synonyms, fix them with the built-in stemming/synonym/
   prefix/typo features (or extend the synonym map) — not a vector DB.

2. **The gap is genuinely semantic.** Users phrase queries with vocabulary that
   never appears in the docs (paraphrase / concept matching, cross-lingual
   intent), so no amount of lexical expansion bridges it.

3. **The corpus and query volume justify the infrastructure.** The doc set is
   large/diverse enough that a static JSON index plus lexical recall aids is
   insufficient, and the added operational burden of a database-backed service
   is worth it.

4. **You can keep retrieval quality measurable.** You have an eval set so you
   can prove hybrid retrieval beats BM25 alone, rather than assuming it.

**What to keep even then:**

- **Keep BM25 — go hybrid, don't replace.** Lexical search is what nails exact
  matches: API names, flags, error strings, code identifiers, version numbers.
  Embeddings are notoriously weak there. The right move is hybrid retrieval
  (BM25 + vector) with fused/reranked results, keeping leadtype's BM25 path.

- **Keep leadtype's field weighting and structure-aware chunking** (title/
  heading/body/code weights, heading paths, anchors). Embeddings don't give you
  this for free and it materially improves ranking and deep-linking.

- **Keep `createAnswerContext` and its hardened, citation-based grounding
  prompt and request guards.** You can swap *what feeds* the retrieval step, but
  the cited-source contract, untrusted-context handling, validation, and rate
  limiting are worth preserving regardless of the retriever.

- **Prefer the cheapest fix that closes the measured gap.** Extend the synonym
  table, tune chunk size, or add a reranker before committing to a hosted vector
  database.
