# Leadtype's Docs Search: What It Already Gives You

## 1. Default Search Implementation: BM25 Keyword Ranking

By default, **leadtype uses BM25 (Okapi BM25)** — a battle-tested probabilistic ranking function that scores documents based on keyword relevance. This is a *static, edge-safe search index* built at generation time and served as JSON.

### How It Works

The BM25 implementation is **sophisticated and multi-dimensional**:

- **Field-weighted scoring**: Title matches (weight 4×), heading matches (2×), body text (1×), and code blocks (0.35×) are scored separately, then combined.
- **Term expansion beyond exact matches**:
  - **Exact term** matches (weight 1.0)
  - **Stemmed term** matches — "searching" matches "search" (weight 0.82)
  - **Synonym expansion** — built-in synonyms like "install" ↔ "setup" and custom synonyms (weight 0.72)
  - **Prefix matching** — "inst" finds "install" (weight 0.55, max 24 expansions)
  - **Typo tolerance** — misspellings within edit distance 1–2 are matched (weight 0.45, max 16 expansions)
- **Content proximity matching**: Phrase detection (1.4× boost) and ordered proximity (0.8× boost) within an 8-word window further refine scoring.
- **Inverse document frequency (IDF)** prevents common terms from dominating results.

### Supporting Infrastructure

- **Chunking**: Docs are split into ~1200-character chunks with 160-character overlap to capture context.
- **Tokenization & normalization**: Unicode NFKD normalization, diacritic stripping, stopword filtering (25 common words), and stemming.
- **Static index format**: A lean JSON artifact with documents, chunks, term → posting lists (chunk index + term counts per field).
- **Optional content store**: Embeddings can be attached post-index; without them, chunk text is fetched from a separate JSON file.

**Search results** return up to 8 results by default, sorted by BM25 score with automatic excerpt generation highlighting matching terms.

---

## 2. When Embeddings Are Actually Warranted

### Conditions That Justify Vector Search

Add embeddings **only if you have evidence that keyword matching is insufficient**. This means:

1. **Semantic gaps in your docs**: Users ask conceptual questions that don't share exact keywords with answers.
   - Example: Users say "I want to run code on schedule" but docs say "cron job" — BM25 fails.
   
2. **Fuzzy intent matching across disparate pages**: A single query should surface unrelated but equally valid answers.
   - Example: "How do I integrate X?" should find both a dedicated integration page and a plugin guide, even if they don't share terminology.

3. **Cross-language or multi-dialect docs**: Synonyms and stemming are insufficient; you need semantic equivalence.

4. **Measurable relevance degradation in testing**: Run an A/B test. If >10% of queries get no useful results in top-3, embeddings may help.

### What to **Absolutely Keep** When Adding Embeddings

**Do not replace BM25 with embeddings alone.** Instead, implement **hybrid search**:

1. **Keep the static BM25 index** as-is. It costs nothing to serve, works edge-safe (Cloudflare Workers, Vercel Edge), and covers 95% of use cases.

2. **Hybrid ranking**: 
   - Run both BM25 and vector search in parallel.
   - Combine scores (e.g., 60% BM25 + 40% semantic similarity).
   - Prefer BM25-only results for explicit, factual queries; allow semantic boost for open-ended questions.

3. **Keep the chunking strategy** (1200-char chunks with overlap). It's tuned for FAQ-like docs and works well for both ranking approaches.

4. **Keep semantic metadata**: If you add vectors, embed the same chunk text that BM25 indexes — don't change the segmentation.

5. **Preserve the answer context builder** (`createAnswerContext`). It pulls top results into an LLM-ready format regardless of search backend.

---

## Summary

- **Default**: Static BM25 on chunks, with multi-factor term matching (stems, synonyms, typos, proximity). Edge-safe, zero operational cost.
- **When embeddings make sense**: Users face semantic gaps (not keyword gaps), and you've measured it. Only then add a vector index as a *secondary* scoring layer.
- **Keep intact**: The BM25 index, chunk boundaries, and answer formatting. Embeddings should augment, not replace.

For most teams, BM25 alone handles 90%+ of doc searches. The "hosted, database-backed vector index" is overhead until proven otherwise.
