# What leadtype Already Gives You for Docs Search

## 1. Default Search Mechanism: Static BM25 Index

By default, `leadtype` generates a **static, pre-built BM25 search index** served as JSON (`search-index.json`). This is a **keyword-based, non-neural ranking algorithm** that does not require embeddings or external databases.

### How It Works

- **Indexing Phase**: At build time, leadtype:
  1. Chunks documentation into ~1,200 character segments (with 160-character overlap)
  2. Tokenizes text, applies stemming, and removes stopwords
  3. Builds a term-posting index with **weighted signals**:
     - **Title matches** (weight 4×)
     - **Heading matches** (weight 2×)
     - **Body text matches** (weight 1×)
     - **Code block matches** (weight 0.35×)

- **Ranking Queries**: At runtime, BM25:
  1. Matches query tokens with exact, stemmed, synonym, prefix, and typo-tolerant expansions
  2. Applies phrase matching and proximity bonuses for multi-term queries
  3. Ranks results using **BM25 scoring** (inverse document frequency + term frequency normalization)

### Constants & Tuning
The defaults are baked into `leadtype` and include:
- `TITLE_WEIGHT = 4`, `HEADING_WEIGHT = 2`, `BODY_WEIGHT = 1`, `CODE_WEIGHT = 0.35`
- `BM25_K1 = 1.2`, `BM25_B = 0.75` (standard BM25 parameters)
- Default synonyms for common terms (e.g., `config` ↔ `configure`, `setup`, `settings`)
- Prefix expansions (up to 24 matches), typo tolerance (edit distance ≤ 2), and phrase/proximity bonuses

### What You Get Out of the Box
```
docs/search-index.json   — Term posting index + chunk metadata (typically 50–150 KB)
docs/search-content.json — Full chunk text for excerpts (optional, ~3–10× larger)
```

---

## 2. When Adding Embeddings Is Warranted — and What to Keep

**Do NOT build a hosted vector database by default.** That is premature infrastructure. Instead:

### Add Embeddings Only If:

1. **Keyword search fails on your docs style**  
   - You have many synonyms that the default synonym map doesn't cover
   - Your docs mix technical jargon with plain language in ways BM25 misses
   - You observe >20% irrelevant results in user searches
   - *Test case*: Run 20–30 real user queries against the static index; if precision <80%, embeddings may help

2. **Your query semantics are truly non-lexical**  
   - Example: "How do I troubleshoot slow API calls?" should find "Performance optimization guide" even if the words don't overlap
   - For most technical docs, exact keyword matching + stemming is sufficient
   - BM25 handles typos and prefix matches already; embeddings add little for well-formed queries

3. **You need multi-language or heavily colloquial docs**  
   - If users search in natural language far from doc language, embeddings can help bridge the gap
   - leadtype's i18n support handles translations; embeddings solve the *semantic distance* problem separately

### When Embeddings Help Least:
- API reference docs (exact names and parameters matter most)
- Quick-reference guides (keywords are explicit in headers)
- Tutorials with clear learning paths (BM25 finds relevant sections well)

---

## 3. What You Must Keep Even If Adding Embeddings

**The static BM25 index is not replaceable.** Keep it because:

1. **It works offline and at the edge** — No runtime API calls, no database latency. Essential for:
   - Docs sites served on CDNs (Vercel, Netlify, Cloudflare Workers)
   - Embedded AI agents reading docs from disk (npm packages ship bundled `AGENTS.md` + `docs/*.md`)
   - LLM context windows where you need deterministic, fast retrieval

2. **It handles exact matches and expert queries better** — A developer searching for `"useState hook"` or `useCallback` will find it faster with BM25 than with embeddings (which might return loose semantic matches first)

3. **It powers fallback behavior** — If embeddings fail (model not loaded, API down, budget exceeded), BM25 is your safety net

4. **It's composable with embeddings** — A hybrid approach (BM25 + embedding reranking) is more robust than embeddings alone:
   - Use BM25 to narrow candidates → 20 results
   - Rerank top 20 with embeddings if precision matters
   - This cuts embedding inference cost by 90%

---

## 4. Recommended Decision Tree

```
┌─ Does your team have GPU/embedding inference infrastructure already? 
│  └─ YES → Consider embeddings as a *second-pass reranker*
│  └─ NO  → Keep BM25 only (unless users complain about search quality)
│
├─ Are your docs >10,000 pages or highly interdisciplinary?
│  └─ YES → Embeddings *might* help for discovery (but verify first)
│  └─ NO  → BM25 is almost certainly enough
│
└─ Can you measure search quality (click-through, satisfaction surveys)?
   └─ YES → Run A/B test: BM25 vs. BM25+embeddings for 2 weeks
   └─ NO  → Keep BM25. Optimize query/chunking first (faster ROI)
```

---

## 5. Concrete Example: Hosted Vector Index "Because It's RAG"

**Do not build this first:**
```javascript
// ❌ Premature: Hosted vector DB + embedding API
const { embed } = require("some-embedding-api");
const vectorDb = new VectorIndex({ url: "cloud-db-url" });

async function search(query) {
  const embedding = await embed(query); // Network call
  return await vectorDb.query(embedding); // Second network call
}
```

**Do this instead:**
```javascript
// ✅ Start here: Static BM25, no external deps
import { searchDocs, createDocsSearchIndex } from "leadtype/search";

const index = createDocsSearchIndex(markdownDocs);
const results = searchDocs(index, userQuery); // ~1ms, edge-safe
```

**If search quality is insufficient, *then* add a hybrid layer:**
```javascript
// ✅ Later, if needed: BM25 → embeddings reranker
const top20 = searchDocs(index, userQuery, { limit: 20 });
const reranked = await rerankerModel.score(query, top20);
return reranked.slice(0, 8);
```

---

## 6. Summary

| Aspect | Default (BM25) | With Embeddings |
|--------|---|---|
| **Setup** | Build-time only, 0 infra | Requires API/GPU + DB |
| **Latency** | ~1–5ms | 100–500ms+ (network round-trips) |
| **Cost** | Free | Per-query embedding + storage |
| **Accuracy** | 80–95% for keyword searches | 85–98% for semantic mismatches |
| **Offline/Edge** | ✅ Yes | ❌ No |
| **Fallback** | N/A (always works) | Needs BM25 backup |

**Conclusion:** leadtype's default static BM25 search is **production-ready for nearly all docs sites**. Before investing in a hosted vector database, verify that keyword search actually fails on your content. For most teams, the answer is: it doesn't. Spend the infra budget on content quality, link structure, and clear headings instead.
