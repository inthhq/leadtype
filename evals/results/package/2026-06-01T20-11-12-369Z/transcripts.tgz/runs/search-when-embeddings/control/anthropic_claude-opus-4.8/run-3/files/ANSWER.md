# Does `leadtype` already give us docs search? (Before building a hosted vector DB)

Short version: **yes, leadtype ships a complete docs search system out of the box, and it is not embeddings-based.** Stand up the hosted vector index only if you hit specific limits described below — and even then, keep leadtype's existing pieces.

This is based on the installed package (`leadtype@0.1.2`), specifically its `leadtype/search` runtime (`dist/_shared/search-TL9muun_.js`) and the build-time generator `leadtype/search/node` (`generateDocsSearchFiles`).

---

## 1. What leadtype's docs search uses by default

**A static, edge-safe, lexical (keyword) search index built on BM25 — no embeddings, no vector store, no database, no inference server.**

How it actually works:

- **Build step → a static JSON index.** `leadtype generate` (and the `generateDocsSearchFiles` API) flattens your MDX/markdown, splits each page into heading-scoped chunks with overlap (defaults: `maxChunkChars: 1200`, `overlapChars: 160`), tokenizes them, and writes a single `search-index.json` (plus an optional content store). The README confirms: "Builds a static, edge-safe search index (BM25, optional source-grounded answers)."
- **Ranking is BM25.** `searchDocs()` scores chunks with the classic Okapi BM25 formula (`BM25_K1 = 1.2`, `BM25_B = 0.75`) over an inverted term index. It is pure lexical retrieval — there are zero embedding vectors and zero cosine-similarity math anywhere in the search module.
- **It is already "smarter than naive keyword match" within the lexical family.** The query pipeline adds, with descending weights: exact terms (1.0), light stemming (0.82), a built-in synonym table plus your own synonyms (0.72), prefix expansion for autocomplete-style matches (0.55), and fuzzy/typo tolerance via bounded edit distance (0.45). It also boosts exact phrase matches (×1.4) and ordered-proximity matches (×0.8), weights fields (title ×4, heading ×2, body ×1, code ×0.35), strips stopwords, and normalizes diacritics. This already covers a lot of what teams *assume* they need embeddings for.
- **Runs anywhere, no infrastructure.** The runtime is designed to execute on the edge / in the browser / in a Worker against the static JSON. There is **no server to run, no database to provision, and nothing to keep in sync** — the index is a regenerated build artifact. Framework adapters (`leadtype/search/react`, `next/client`, etc.) just debounce queries and run that same BM25 search client-side.
- **Optional source-grounded answers, still on top of BM25.** `createAnswerContext()` (used by the Vercel / TanStack / Cloudflare AI adapters) does *retrieval* with the same `searchDocs()` BM25 call, then packages the top sources (`maxSources: 6`, `maxContextChars: 12000`) into a grounded prompt with citations and an anti-hallucination system message. So even the "RAG answer" feature retrieves lexically — the LLM only generates the answer, it does not do the search. There is no embedding retrieval here either.
- **Bonus: an agent-readable corpus.** leadtype also emits `llms.txt`, markdown mirrors, a root `llms-full.txt`, and bundled `AGENTS.md` + `docs/*.md`, and offers read-only bash adapters (`leadtype/search/bash`) so coding agents can grep/read docs directly. For many "agent search" needs this sidesteps a vector DB entirely.

**Takeaway:** "that's how RAG is done" is not accurate for a docs corpus. The default here is a well-tuned lexical index — the standard, cheap, correct baseline for documentation search — and it's already wired into answer generation.

---

## 2. When adding embeddings is actually warranted (and what to keep)

Adopt a hosted, DB-backed vector index **only after the BM25 default measurably fails**, and only for reasons embeddings genuinely fix. Concretely, it's warranted when *all* of these hold:

1. **You have a measured recall gap that is semantic, not lexical.** Real, logged queries return poor results *specifically* because users phrase things with vocabulary that doesn't appear in the docs (true synonymy/paraphrase), **and** you've already tried the cheap lexical levers first:
   - populated the `synonyms` option (and leaned on the built-in synonym table),
   - relied on the existing stemming, prefix, fuzzy, phrase, and proximity matching,
   - fixed the underlying docs (titles, headings, descriptions — which are weighted heavily).
   If tuning synonyms/content closes the gap, **stop here. You don't need embeddings.**

2. **Cross-lingual or conceptual matching is a core requirement** — e.g., querying in one language against docs in another, or matching on concept rather than shared keywords. BM25 cannot bridge that; dense retrieval can.

3. **The corpus is large/diverse enough that the gap is material**, and you have the queries/metrics to prove a retrieval-quality improvement — not just a hunch. (For typical product docs, the static index also keeps things fast and free; a hosted DB adds latency, cost, and an index-freshness/sync burden you must justify.)

4. **You can own the new operational cost**: an embedding model + inference, a vector database, re-embedding on every docs change, and keeping it consistent with the source — versus today's "regenerate one JSON at build time."

If those don't all hold, the hosted vector index is premature; it adds infrastructure, latency, cost, and a sync problem to solve a problem you may not have.

### What to keep even if you do add embeddings

Treat embeddings as an **augmentation of the existing pipeline, not a replacement.** Specifically, keep:

- **BM25 lexical retrieval, as a first-class half of a hybrid retriever.** Dense vectors are notoriously weak on exact identifiers — API names, flags, error codes, file paths, version strings — which are exactly the high-value queries in docs. leadtype already weights `code` and titles for this. Run BM25 + vector and fuse/rerank; don't drop lexical.
- **leadtype's chunking, heading paths, anchors, and field structure.** Embed *those same chunks* so results still deep-link to the right `urlWithHash` and carry heading context. Reuse the existing `generateDocsSearchFiles` output (or a `beforeSearchChunk` transformer) as the chunk source of truth rather than inventing a parallel one.
- **`createAnswerContext()`'s grounding contract.** Keep the citation format, the "use only provided context / treat docs as untrusted / don't invent APIs" system prompt, and the `maxSources` / `maxContextChars` budgets. Only swap the *retrieval* step inside it; the safety, citation, and budgeting logic should stay.
- **The static / edge-safe path as a fallback and for the common case.** Keep shipping `search-index.json`, the `llms.txt` / `AGENTS.md` agent corpus, and the bash adapters. They cost almost nothing and remain the fastest, most reliable answer for the majority of lexical queries even after a vector layer exists.

**Bottom line:** start with what's already installed — leadtype's BM25 static index (and its grounded-answer layer). Add a hosted vector index only when logged, measured semantic-recall gaps survive synonym/content tuning, and when you do, layer it as hybrid retrieval that preserves leadtype's chunking, deep-linking, grounding, and static fallback.
