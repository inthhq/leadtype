# Documentation Search with `leadtype`: BM25 vs. Embeddings

We evaluated the architectural characteristics of `leadtype`'s built-in search pipeline to determine what it provides out-of-the-box and when a hosted, database-backed vector embedding system is actually warranted.

---

## 1. What `leadtype`'s Docs Search Uses by Default

By default, `leadtype` provides a **static, edge-safe, and dependency-free search index** that implements **BM25 relevance scoring** client-side or at the edge.

### Key Characteristics:
* **Build-Time Generation (`search-index.json`)**: During the build phase (or via `npx leadtype generate`), `leadtype` tokenizes your MDX/Markdown documentation, splits pages into chunks, and compiles them into a single static JSON index (`search-index.json`). This index contains term frequencies, chunk lengths, and metadata (e.g., titles, descriptions, and URL paths).
* **Client-Side/Edge BM25 Engine**: The `leadtype/search` runtime uses the standard **BM25 algorithm** (configured with standard parameters $k_1 = 1.2$ and $b = 0.75$) to calculate document relevance on the fly.
* **No Database Required**: Because the search is executed locally or on lightweight edge handlers by querying the static JSON file, there is **zero need** for hosted databases, stateful search clusters (e.g., Elasticsearch, Algolia), or cloud infrastructure.
* **Source-Grounded Answers**: If you want generative Q&A (RAG), `leadtype` already provides thin adapters (for the Vercel AI SDK, Cloudflare Workers AI, and TanStack AI) to feed retrieved BM25 context chunks into an LLM, all without needing to host a vector database.

---

## 2. When Are Embeddings Actually Warranted? (and What to Keep)

Introducing a hosted, database-backed vector embedding system (dense semantic search) is only warranted under specific conditions. Even when those conditions are met, **BM25 lexical search must not be discarded**.

### When Embeddings are Warranted:
1. **Conceptual/Synonym Queries**: When users search using concepts or synonyms that don't literally exist in your code/documentation. For example, a user searches for *"prevent duplicate submissions"* but the docs only mention *"idempotency keys"*.
2. **Conversational Natural-Language Questions**: When your primary search interface functions as an AI chat assistant accepting long-form conversational inputs (e.g., *"How do I fix a 403 error on Vercel deployment?"*).
3. **Multilingual/Cross-Lingual Search**: When you have users querying in languages other than English (e.g., Spanish or German), and you want them to retrieve relevant sections from your English-only documentation.
4. **Abstract Symptom Descriptions**: When non-expert users describe symptoms of a problem (e.g., *"my site is lagging on mobile"*) rather than searching for specific technical terms (e.g., *"compilation latency options"*).

### What We Should Keep (and Why):
Even if we introduce vector embeddings, we **must keep the BM25 lexical search index** and implement a **hybrid retrieval model** (e.g., via Reciprocal Rank Fusion / RRF).

#### Why we must keep BM25:
* **Precision with Code and Exact Terms**: Technical documentation search is dominated by queries for exact function names (`defineDocsConfig`), config parameters (`contentDir`), shell commands (`pnpm add leadtype`), or precise error codes (`ERR_INVALID_ARG_TYPE`). Vector embedding models struggle to map these exact alphanumeric tokens and often fail to find the exact API reference. BM25 handles these perfectly.
* **Hybrid Retrieval is the Industry Standard**: The absolute highest-recall and highest-precision search for technical RAG is a hybrid approach. Combining the keyword-exact precision of BM25 with the conceptual understanding of embeddings ensures users get the correct API reference as well as conceptually related topics.
* **Sub-Millisecond Offline/Local Fallback**: BM25 can run completely offline, for free, with sub-millisecond response times. For simple keyword searches, forcing users to wait for a network round-trip to an expensive embedding model adds unnecessary cost, latency, and system dependency.
