# What leadtype already gives us for docs search

## 1. By default: a static, edge-safe BM25 index with RAG built in

`leadtype` does **not** require a hosted database or vector store for docs search. By default it generates a **static BM25 search index** at build time and ships it as JSON (`search-index.json` + `search-content.json`). The search runtime runs entirely in-memory—on the client, in a worker, or at the edge.

What the index includes:
- **BM25 scoring** with field weights: title (×4), headings (×2), body (×1), code (×0.35).
- **Query expansion** out of the box: exact-term matching, stemming, built-in synonyms (e.g. `config` ↔ `configuration`), prefix expansion (up to 24 prefixes), and typo tolerance (edit-distance 1–2, capped at 16 matches).
- **Ranking boosts** for phrase matches and ordered proximity matches within an 8-token window.
- **Chunking** with configurable overlap, plus excerpt generation around query tokens.

What the RAG layer includes:
- `createAnswerContext` retrieves top-k chunks with BM25, formats them into cited source blocks, and builds a system prompt that instructs the LLM to answer only from the retrieved docs.
- Framework adapters (`leadtype/search/vercel`, `leadtype/search/tanstack`, `leadtype/search/cloudflare`) stream those answers with no extra retrieval infrastructure.

In short, leadtype already gives you a complete keyword-based retrieval + source-grounded answer pipeline with zero hosting cost.

## 2. When embeddings are actually warranted — and what to keep

A hosted, database-backed vector index is warranted **only in two specific conditions**:

1. **The corpus is too large to ship to the edge.** The build warns when the index exceeds ~5 MiB, total artifacts exceed ~10 MiB, or chunk count exceeds 10 000. If scoping with `--include` / `--exclude` is unacceptable because the entire corpus must remain searchable, a remote vector store can take over retrieval.
2. **Persistent semantic mismatch.** When user queries are natural-language questions whose vocabulary systematically diverges from the docs—so far that BM25 + synonyms + stemming regularly miss relevant chunks (e.g., broad conceptual questions against terse API reference).

**What you should keep even then:**
- **The static BM25 index and chunking pipeline.** Do not replace it. BM25 is faster, cheaper, edge-safe, and far better at exact matches, code identifiers, CLI flags, and API names. The right architecture is **hybrid**: use BM25 as the fast first-stage retriever (or fallback), and add embeddings only as a supplemental recall layer for semantically divergent queries.
- **The answer-context flow.** `createAnswerContext` and the streaming adapters are retrieval-backend-agnostic. Whether chunks come from BM25 or a vector DB, you should still feed them through leadtype’s citation formatting and source-grounded guardrails.
