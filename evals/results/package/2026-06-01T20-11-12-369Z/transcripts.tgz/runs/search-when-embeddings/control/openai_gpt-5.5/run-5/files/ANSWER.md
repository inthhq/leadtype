# Do we need a hosted vector index for docs search?

## What leadtype uses by default

Leadtype does **not** default to embeddings, a hosted vector database, or any database-backed index.

By default, `leadtype generate` produces static website artifacts for docs search: generated JSON files such as `docs/search-index.json` and `docs/search-content.json`. The runtime client (`leadtype/search/client`) fetches those static artifacts and searches them in-process/at the edge.

The default retrieval model is a **static, edge-safe lexical index using BM25** over flattened Markdown docs. From the installed package:

- The README describes the output as a “static, edge-safe search index (BM25, optional source-grounded answers).”
- The search implementation builds an inverted term index from document chunks, then scores matches with BM25 constants (`k1 = 1.2`, `b = 0.75`).
- It chunks docs by Markdown sections, with defaults of 1200 characters and 160 characters of overlap.
- It weights matches by field: title > heading > body > code.
- It adds pragmatic recall features around the lexical index: stopword removal, simple stemming, built-in/custom synonyms, prefix matching, typo-tolerant expansion, phrase boosts, and ordered-proximity boosts.
- The optional answer/RAG helpers (`createAnswerContext`, `streamDocsAnswer`) still start from this search index, gather source chunks, and produce source-grounded prompts/citations. They are not embedding retrieval.

So leadtype already gives us a no-infrastructure docs-search baseline: static artifacts, client/edge search, source chunks for citations, and optional answer streaming over those sources.

## When embeddings are actually warranted

Add embeddings only after the default BM25/static search has been tried and measured, and only if we can point to recall failures that lexical search is not designed to solve. Good reasons include:

1. **Semantic/paraphrase recall is materially failing.** Users ask conceptual questions whose wording has little term overlap with the docs, and synonym tuning/frontmatter/heading improvements do not fix it.
2. **Cross-language or translation-style queries are required.** For example, users search in one natural language while docs are written in another, and we need semantic matching across languages.
3. **The corpus is large or heterogeneous enough that keyword relevance is insufficient.** If docs span many products/domains and the same terms mean different things, embeddings may improve coarse semantic recall.
4. **We have evaluation data showing better outcomes.** Add embeddings because search logs, support tickets, or a retrieval benchmark show missed answers that embeddings recover—not because “RAG uses vectors.”
5. **We accept the operational tradeoffs.** Embeddings add indexing jobs, model/version choices, storage, refresh semantics, latency, cost, privacy review, and failure modes. Those costs should buy measurable recall/answer-quality gains.

Even then, we should keep leadtype’s default search path. Use embeddings, if needed, as a **hybrid layer**, not as a replacement:

- Keep the BM25/static index for exact API names, option names, error strings, CLI flags, code identifiers, versions, and URLs—cases where lexical search is usually superior to vectors.
- Keep leadtype’s generated content chunks as the canonical source text for grounding and citations.
- Keep query validation, source selection limits, and source-grounded answer behavior so generated answers cite docs and say when context is insufficient.
- Keep the static index as a cheap, fast fallback if the embedding service/database is slow or unavailable.

Recommendation: start with leadtype’s generated static BM25 search and answer context. Add embeddings only if measured semantic-recall gaps remain, and implement them as hybrid retrieval while preserving leadtype’s lexical index and source-grounding pipeline.
