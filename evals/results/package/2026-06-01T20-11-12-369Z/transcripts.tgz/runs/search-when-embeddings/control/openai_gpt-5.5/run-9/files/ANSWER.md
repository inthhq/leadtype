# Does leadtype require a hosted vector database for docs search?

No. In the installed `leadtype` package, docs search is **static lexical search by default**, not embeddings.

## 1. What leadtype's docs search uses by default

`leadtype generate` builds a static, edge-safe docs search index: `public/docs/search-index.json`. The package README describes this as a **"static, edge-safe search index (BM25, optional source-grounded answers)."**

Concretely, the installed runtime (`leadtype/search`) builds and queries a JSON index with:

- **BM25 scoring** over chunked markdown docs.
- **Weighted fields**: title, heading, body, and code are indexed separately with different weights.
- **Chunking with overlap** so long docs can retrieve the relevant section, not only the whole page.
- **Lexical recall helpers**: stemming, built-in/custom synonyms, prefix matching, typo-tolerant matching, and phrase/proximity boosts.
- **Static deployment**: the index and optional content store are JSON files that can be served from the docs site/CDN and queried in edge/server/client contexts.
- **Optional source-grounded answers**: `createAnswerContext` / AI adapters retrieve sources from the same search index, build a constrained context, and instruct the model to cite sources and not invent APIs.

So the default architecture is: **flattened docs -> static BM25 index -> search results / source-grounded answer context**. There is no hosted database and no vector index in the default path.

## 2. When embeddings are actually warranted

Adding embeddings is warranted only when we have evidence that lexical search is the bottleneck. Good triggers would be:

1. **Measured recall failures from real queries or a relevance test set** where the right doc exists but BM25 does not retrieve it near the top.
2. The failures are specifically due to **semantic vocabulary mismatch** — users ask in concepts or paraphrases that do not share terms with the docs, and simple fixes such as better titles/headings, aliases, glossary terms, or custom synonyms are not enough.
3. The corpus/query pattern genuinely benefits from semantic retrieval, for example broad conceptual Q&A across many pages, ambiguous natural-language questions, or cross-domain terminology where exact API names are not known.
4. We are prepared to own the extra production surface area: embedding generation during docs builds, re-indexing on every docs/version change, model/version drift, latency, cost, access control, evaluation, and operational monitoring.

Even then, embeddings should be an **addition**, not a replacement. Keep leadtype's BM25/static search path for:

- Exact matches on API names, options, flags, class/function names, error strings, code snippets, and versioned docs paths.
- Fast fallback search when the vector service is slow or unavailable.
- Hybrid retrieval: merge or rerank vector candidates with BM25 candidates instead of trusting semantic similarity alone.
- Source-grounded answer generation: continue feeding the model retrieved doc chunks with citations and the instruction to answer only from provided documentation.

Recommendation: start with leadtype's generated BM25 index and source-grounded answer helpers. Add embeddings only after search logs or an evaluation set show persistent semantic-recall misses that lexical tuning cannot fix, and keep BM25 as the precision/fallback half of a hybrid system.