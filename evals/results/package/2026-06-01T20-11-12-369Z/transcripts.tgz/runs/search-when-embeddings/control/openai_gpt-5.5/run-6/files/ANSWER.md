# Leadtype docs search and embeddings

## What leadtype uses by default

Leadtype already ships a database-free docs search system. A normal `leadtype generate` build emits static website artifacts, including:

- `docs/search-index.json`
- `docs/search-content.json`

The runtime client fetches those JSON files, for example from `/${collection}/search-index.json` and `/${collection}/search-content.json`, and searches them locally/at the edge. No hosted vector database or embedding pipeline is required by default.

The default index is lexical/BM25-style search over generated markdown chunks:

- docs are split into heading-aware chunks;
- default chunking is about 1200 characters with 160 characters of overlap;
- terms are indexed from title, heading, body, and code;
- scoring weights title highest, then headings, then body, with code weighted lower;
- the query side includes exact term matching, simple stemming, built-in and custom synonyms, prefix expansion, and typo-tolerant expansion;
- results get phrase/proximity boosts;
- the default result limit is 8.

Leadtype also supports source-grounded answer generation on top of the same search artifacts. `createAnswerContext`/the AI adapters retrieve search results, include the source chunks, and generate prompts that tell the model to use only the provided documentation context, cite sources, say when context is insufficient, and not invent APIs/options/paths/package names.

## When embeddings are actually warranted

Add embeddings only after the default static BM25 search has been measured against real docs-search queries and is failing in a way lexical search cannot reasonably fix.

Embeddings are warranted when all of these are true:

1. We have a representative query set or search logs with expected relevant docs.
2. Leadtype's built-in search, plus reasonable tuning such as page titles/headings/content fixes and synonym additions, still misses important results.
3. The misses are genuinely semantic: users ask for concepts whose wording does not appear in the docs, use very different vocabulary than the docs, or need cross-language / paraphrase-heavy retrieval.
4. The quality gain justifies the added operational cost: embedding generation, re-indexing on docs changes, hosted storage, latency, security review, monitoring, and fallback behavior.

Even then, we should keep leadtype's generated artifacts and lexical search path. Use embeddings as an additional retrieval/reranking signal, not as a wholesale replacement. In practice that means keeping:

- leadtype's markdown conversion and chunking pipeline as the source of truth for retrievable docs text;
- the static `search-index.json` / `search-content.json` artifacts as a cheap, reliable fallback;
- BM25/keyword search as a hybrid retrieval leg, because exact API names, flags, config keys, error strings, and code identifiers are often better served by lexical search than embeddings;
- leadtype's source-grounded answer-context behavior: cite retrieved docs, constrain the model to provided context, and refuse to invent missing details.

So the default should be: ship leadtype's static BM25 search first, evaluate it, and only add embeddings for proven semantic-recall gaps while preserving leadtype's lexical and grounding layers.