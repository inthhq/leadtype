# Leadtype Docs Search Architecture

Our team is considering building a hosted, database-backed vector index for documentation search ("because that's how RAG is done"). Before embarking on that complex build, here is a detailed breakdown of what `leadtype` provides out-of-the-box and the conditions under which a vector/embedding-based search is actually warranted.

---

## 1. What Leadtype's Docs Search Uses by Default

By default, `leadtype` uses a **static, edge-safe, framework-agnostic keyword search index** powered by a highly optimized, custom **BM25 scoring algorithm**. It does not require any hosted database, external search servers, API keys, or active runtime servers. 

### Key Technical Characteristics:
* **Storage Artifacts:** During build time, `leadtype` processes documentation files and generates two static, edge-safe JSON files (typically `search-index.json` and `search-content.json`).
* **Scoring Engine:** Features a client-side implementation of the **BM25 algorithm** (`BM25_K1 = 1.2`, `BM25_B = 0.75`) to calculate relevance.
* **Weighted Fields:** Relevance scoring weights different page components to prioritize primary headers over body content:
  * Title Weight: `4.0`
  * Heading Weight: `2.0`
  * Body Weight: `1.0`
  * Code Block Weight: `0.35`
* **Text Normalization & Linguistics:**
  * **Stopwords Filtering:** Automatically removes common stopwords (e.g., *a, an, of, with*).
  * **Stemming:** Uses suffix-based stemming rules (handling `-ies`, `-ing`, `-ed`, `-es`, `-s` suffixes) to match base words.
  * **Synonym Expansion:** Supports built-in and custom synonym mapping (e.g., matching `ai` with `agent`/`llm`, or `auth` with `authentication`/`login`).
* **Query Expansion & Tolerances:**
  * **Prefix Expansion:** Expands prefix queries for terms of length $\ge 4$ characters (up to 24 expansions).
  * **Typo/Fuzzy Matching:** Allows Levenshtein edit distance matches (distance 1 for shorter words, distance 2 for words $\ge 7$ characters) up to 16 expansions to tolerate typos.
* **Phrase and Proximity Boosts:**
  * **Phrase Match Boost:** Applies a `1.4x` multiplier if query terms appear consecutively as an exact phrase.
  * **Ordered Proximity Boost:** Applies a `0.8x` multiplier if query terms appear near each other within a sliding token window of size 8 (`PROXIMITY_WINDOW = 8`).
* **Source-Grounded Answer Prompt Generation (RAG Ready):**
  Through its `createAnswerContext` module, `leadtype` can search the index, retrieve the highest-ranking clean content chunks, and construct a citation-based system instruction context and user prompt. This can be directly streamed to an LLM provider (such as OpenAI, Anthropic, or Vercel AI SDK) without needing a dedicated vector database.

---

## 2. When Adding Embeddings (Vector Search) is Warranted

Adding ML embeddings and a hosted vector database introduces substantial complexity: active hosting costs, API/embedding latency, indexing pipelines on content updates, and database maintenance. It is only warranted under the following specific conditions:

1. **High Semantic Distance & Conceptual Queries:** When users consistently search for complex, abstract concepts where the exact terminology differs entirely from the written text (e.g., searching "how do I restrict page access" instead of using keywords like "auth", "login", or "role-based access control").
2. **Multilingual and Cross-Lingual Search:** When you have a global audience wanting to query the docs in their native languages (e.g., Spanish, Japanese) while the source material is written only in English. Multilingual vector embedding models align concepts across languages natively.
3. **Conversational, Long-Form Chat Queries:** When search queries are conversational natural language sentences (e.g., "I'm trying to set up my project but I keep getting a bundle error during build, what should I check?") where exact keyword density is low relative to the query length.
4. **Massive-Scale Documentation Corpus:** When the volume of documentation spans tens of thousands of pages. At that scale, downloading the static JSON `search-index.json` over the network to run client-side search becomes too heavy for user browsers, necessitating server-side index management.

---

### What We Should Keep Even If We Add Embeddings

If we determine that we *must* introduce embeddings, we should **never throw away Leadtype's keyword capabilities**. Instead, we should implement a **Hybrid Search** architecture and keep:

1. **Keyword Search / BM25 for Exact Technical Identifiers:** Vector embeddings are notoriously bad at matching arbitrary code fragments, specific API function names (e.g., `createSearchClient`), CLI flags (e.g., `--src`), or specific error message codes. BM25 guarantees perfect retrieval for these technical identifiers.
2. **The Same Parsing and Flattening Pipeline:** We should continue to use `leadtype`'s exceptional MDX/JSX-to-markdown parser. Its ability to flatten components into clean, agent-readable markdown is critical. The high-quality, cleanly-chunked segments generated by `leadtype` serve as the perfect source chunks for generating high-quality embeddings.
3. **Low-Latency, Cost-Free Instant Search:** We should retain Leadtype's client-side search for the main typing/autocomplete search bar. It delivers sub-millisecond, offline-capable results instantly with zero network roundtrips and zero API cost.
4. **Hybrid Retrieval Fusion (e.g., Reciprocal Rank Fusion / RRF):** We should merge Leadtype's keyword scores with the vector database's similarity scores. Combining sparse (keyword) and dense (vector) representations delivers the highest-leverage and most accurate search results possible.
