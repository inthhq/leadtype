# Leadtype's Default Search Architecture

## 1. What Leadtype Uses By Default

Leadtype's docs search uses **BM25 (Best Matching 25)**, a classical, battle-tested keyword ranking algorithm — **no embeddings or vector operations**. Here's the complete picture:

### Core Algorithm: BM25
- **Term weighting by location**: Title matches (4x), headings (2x), body text (1x), code blocks (0.35x)
- **Inverse Document Frequency (IDF)**: Ranks common terms lower and rare terms higher
- **Document length normalization**: Prevents artificially high scores in longer chunks
- **Constants**: K1=1.2, B=0.75 (tuned for typical doc search)

### Query Understanding
- **Exact matches** (1.0 weight) – direct term hits
- **Stemming** (0.82 weight) – "searching" matches "search"
- **Synonyms** (0.72 weight) – built-in defaults like `ai ↔ agent`, `cli ↔ command`
- **Prefix expansion** (0.55 weight) – "doc" matches "documentation" (capped at 24 expansions)
- **Typo tolerance** (0.45 weight) – 1–2 edit distance for queries ≥4 characters (capped at 16 expansions)
- **Phrase and proximity boosts** – exact phrase matches get 1.4x boost; tokens within 8-word window get 0.8x boost

### Index Structure (Static JSON)
- **Inverted index** on terms → chunks (documents split into overlapping ~1200-char pieces with 160-char overlap)
- **Posting lists** per term storing: chunk ID, title frequency, heading frequency, body frequency, code frequency
- **Content store** (optional, separate file): actual chunk text for excerpts and rendering

### Chunking Strategy
- **Semantic awareness**: Respects section boundaries (headings), sentence boundaries
- **Overlap**: 160 characters of context overlap between chunks for phrase-boundary safety

### Edge Case Handling
- **Stopwords**: Filters 26 common words (a, the, is, for, etc.)
- **Normalization**: NFKD + diacritic stripping ("Café" → "cafe")
- **Query validation**: Max 400 characters, no control characters, whitespace normalized
- **Markdown cleanup**: Strips links, inline formatting; preserves semantic content

### Result Ranking
Sorted by BM25 score, with tiebreaker on absolute URL (stable sort for pagination)

---

## 2. When Embeddings Are Actually Warranted

Adding embeddings (vector similarity search) is **genuinely useful only when**:

### A. Semantic Mismatch is Your Core Problem
- **Symptom**: Users ask "How do I install?" but you only have "Setup instructions" sections, and BM25 fails to match (no synonym exists for these terms in your domain)
- **Reality check**: Before adding embeddings, tune the **default synonyms** in `leadtype` or add custom synonyms to your search config. This often solves 80% of semantic mismatch cases at zero infrastructure cost.

### B. You Have Specialized/Ambiguous Terminology
- **Example**: Medical or legal docs where "litigation" (search term) should surface "lawsuit" (doc term) with equal weight, but your domain forbids simple aliases.
- **Fallback solution**: Still prefer extending the synonym map first.

### C. You're Serving Multiple Languages or Domains
- **Only if**: You need cross-lingual or cross-domain relevance (e.g., matching Spanish queries to English docs).
- **Leadtype already supports**: i18n structure and fallbacks; embeddings add complexity here without guaranteed ROI.

---

## 3. What You MUST Keep Even If You Add Embeddings

**Do NOT replace BM25**. Instead, use it as a hybrid:

### Keep These Components
1. **Static BM25 index** (JSON file)
   - ✅ Edge-cacheable (CDN-friendly)
   - ✅ No inference latency
   - ✅ Reliable for exact/typo-tolerant matches
   - ✅ Excellent recall for named entities, APIs, CLI flags

2. **The chunking strategy** (semantic section boundaries, overlap)
   - ✅ Embeddings operate on the same chunks—reuse the split
   - ✅ Section + heading context is gold for chunk embeddings

3. **Synonym layer** (even if using embeddings)
   - ✅ Fast, deterministic, no model latency
   - ✅ Handles domain-specific aliases that embeddings may miss
   - ✅ User expectations: "search" and "find" *should* be equivalent, full stop

4. **Excerpt generation and citation** (chunk metadata)
   - ✅ Users need highlighted, contextualized snippets, not just relevance scores
   - ✅ Leadtype's heading paths and text chunks make this automatic

### Hybrid Search Pattern (If You Still Choose Embeddings)
```
User query
  ↓
[BM25 ranking] → Top N results (fast, deterministic)
[Embedding similarity] → Top N results (slow, semantic)
  ↓
Merge & deduplicate → Union of both sets
Sort by combined score (or confidence-weighted blend)
  ↓
Return top K with full chunk metadata
```

**Trade-off**: Embedding-only search trades recall (BM25 catches typos/exact matches) and latency (inference is slower than JSON lookup) for theoretical semantic gains that Leadtype's synonym + stemming + proximity matching already cover well.

---

## Recommendation

**Before building a hosted vector index:**

1. **Audit your BM25 misses**: Run queries that fail in your current setup. How many would be fixed by adding 5–10 custom synonyms? (Probably 60%+.)
2. **Profile query latency**: BM25 over a 10K-page site is milliseconds. Your embedding API will add 200–500ms per request.
3. **Measure recall**: BM25 with proper tuning (stopwords, stemming, field weights) is competitive for docs search. Embeddings shine on semantic paraphrase, not terminology.
4. **Consider maintenance**: Leadtype's static index rebuilds at build time. A hosted vector DB requires model versioning, reindexing strategy, and operational overhead.

**If you still need embeddings** (e.g., you have user-generated content or cross-domain search), keep Leadtype's BM25 as the first pass and treat embeddings as a re-ranker or supplemental signal—never as a replacement.
