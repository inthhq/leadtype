# Leadtype's Default Search Approach & When Embeddings Matter

## 1. What Leadtype Uses by Default

**leadtype** generates a **static BM25-based search index** that runs entirely at the edge.

### The Default Stack:
- **Algorithm**: [BM25](https://en.wikipedia.org/wiki/Okapi_BM25) — the ranking function used by Elasticsearch, Solr, and most traditional document search systems
- **Index Format**: Compact JSON (`search-index.json`) containing:
  - Inverted term index with term-to-chunk postings
  - Per-chunk metadata (document ID, heading path, URL, length)
  - Optional embedded content (`search-content.json`) for display excerpts
- **Query Processing**: Client-side, no backend needed
  - Tokenization with stemming (e.g., "running" → "run")
  - Synonym expansion (built-in: "llm" ↔ "agent", "install" ↔ "setup", etc.)
  - Typo tolerance (1–2 edit distance for 4+ char tokens)
  - Prefix expansion (finds "doc" in "documentation")
  - Phrase matching and proximity boosts
  - Weighted fields: title (4×), headings (2×), body (1×), code (0.35×)

### Why This Works:
- **Fast**: ~microseconds per query on modern hardware
- **Reliable**: No API calls, no rate limits, no cold starts
- **Offline-capable**: Works in a browser tab without a network
- **Cost-zero**: No vector database, no embeddings compute
- **Deterministic**: Same query → same results, always

---

## 2. When Adding Embeddings Is Actually Warranted

### ✗ **Don't add embeddings if:**
- Your docs are **under 5–10K pages** with reasonable structure
- Users are searching for **named entities, exact terms, or features** ("how do I install X?", "what's the API for Y?")
- Your query traffic is **moderate** (hundreds to low thousands per month)
- Search latency is **already acceptable** (BM25 is instantaneous at the edge)
- You don't have funding/ops budget for a hosted vector database

**Real-world truth**: BM25 + stemming + synonyms handles 80–90% of documentation queries better than raw embeddings.

### ✓ **Consider embeddings only if:**
1. **Semantic mismatch is a real problem**: Your docs use vastly different terminology than users' mental models. Example: "authentication" docs never mention "login" and synonym expansion won't help.
2. **Very large corpus with poor structure**: 50K+ pages, minimal heading hierarchy, or dense narrative prose where lexical overlap is unreliable.
3. **You have strong operational capacity**: Hosting (Pinecone, Supabase Vector, Weaviate), embedding generation cost, and latency tolerance (embeddings are slower than BM25).
4. **Hybrid search is the real goal**: You want to combine BM25 *and* semantic search, not replace BM25. This requires storing both, adding complexity.

### ⚠ **What to Keep Even With Embeddings:**
Even if you add a vector index, **do not replace** leadtype's BM25 stack:
- Keep the **full-text inverted index** for exact-match queries
- Keep **structured metadata** (heading paths, document hierarchy, URLs) — embeddings are opaque black boxes
- Keep **field weighting** — embeddings treat all content equally, but a match in the title should rank higher than code
- Keep the **excerpt generation** — embedding distance scores don't tell users *why* a result matched
- Keep **edge-safe serving** — BM25 is cacheable and runs at the CDN level

**Hybrid approach** (BM25 + embeddings):
1. Run BM25 search, rank by relevance
2. Run embedding similarity search in parallel
3. Merge results: use BM25 rankings for exact matches, embeddings to surface thematically-similar pages the user wouldn't find otherwise
4. Deduplicate and re-rank by combined score

This is more work than either alone, but genuinely valuable only for high-traffic docs with mature search analytics showing BM25 misses a predictable class of queries.

---

## Summary

**Ship BM25 first.** It's free, fast, offline-capable, and handles the vast majority of real-world doc searches. Embeddings are a specialized tool for a specific problem: semantic gaps in terminology. If that's not your problem today, the complexity cost exceeds the benefit.

If you do add embeddings later, keep BM25 running in parallel. Hybrid search is the best of both worlds.
