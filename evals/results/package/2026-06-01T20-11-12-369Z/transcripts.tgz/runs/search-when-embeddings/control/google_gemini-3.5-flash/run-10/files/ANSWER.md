# Leadtype Documentation Search and RAG Analysis

Before investing engineering time to build and host a database-backed vector index for our docs search, here is a detailed breakdown of what the `leadtype` package already provides out of the box, and when (if ever) we actually need vector embeddings.

---

## 1. What Leadtype's Docs Search Uses by Default

By default, `leadtype` provides a **static, zero-database, edge-safe search engine** powered by a highly optimized, custom client-side **BM25 (Best Matching 25)** implementation.

### How it Works Under the Hood:
- **Client-Side & Edge-Safe Indexing:** It compiles documentation into a highly optimized, minified static JSON index (`search-index.json`). This index can run completely in-browser or inside lightweight, serverless, edge-safe endpoints (e.g., Cloudflare Workers, Vercel Edge Functions, Next.js route handlers) without requiring any server or database roundtrips.
- **Content Chunking with Overlap:** MDX files are automatically parsed and split into overlapping text chunks (by default, `maxChunkChars: 1200` with an `overlapChars: 160` overlap) to retain paragraph contexts and fit within standard search-result limits.
- **Smart Text Normalization & Suffix Stemming:** The parser strips markdown-specific tags and symbols, normalizes diacritics, lowercases text, filters out common stop words, and applies light suffix stemming (mapping terms like `ies`, `ing`, `ed`, `es`, `s` back to their roots).
- **Proximity & Phrase Match Boosting:** Multi-word queries are scored using advanced boosts:
  - **Phrase Match Boost (1.4x):** Applied when query tokens appear consecutively as an exact phrase.
  - **Ordered Proximity Boost (0.8x):** Applied when query tokens appear in the expected order within a window of 8 tokens.
- **Prefix Expansion & Typo Tolerance:** 
  - For incomplete queries, it supports **prefix matching** (up to 24 prefix expansions) for words matching the start of the query.
  - For spelling mistakes, it automatically performs **Levenshtein edit-distance calculations** (up to distance 1 or 2 for words with length $\ge$ 4) yielding up to 16 typo-corrected expansions.
- **Synonym Mapping:** It includes standard preconfigured synonyms (e.g., mapping `ai -> agent/llm`, `cli -> command/terminal`, `auth -> login/signin`, `setup -> install/configure`) and allows user-customized synonyms.
- **Location-Based Scoring Weights:** Relevance is calculated by assigning specific probabilistic weights depending on where the term matches:
  - **Title Weight:** 4
  - **Heading Weight:** 2
  - **Body Text Weight:** 1
  - **Code Blocks Weight:** 0.35
- **Out-of-the-Box RAG Integration:** Leadtype includes a built-in `createAnswerContext` utility. This utility queries the local BM25 index, extracts the top relevant content citations, compiles the necessary system prompts/guards (e.g., warning the model not to invent APIs or paths), and formats the context directly for LLM streaming integrations (via Vercel AI SDK, TanStack AI, Cloudflare Workers AI, etc.) without needing any external vector database.

---

## 2. When Are Embeddings Actually Warranted? (And What to Keep Even Then)

While traditional "RAG with a Hosted Vector DB" is a common buzzword, it introduces substantial hosting costs, database setup overhead, indexing synchronization latency, and slow cold starts. 

### Specific Conditions Where Adding Embeddings is Warranted:
1. **Semantic & Conceptual Gaps (High Synonym Density):** If users consistently search for solutions using conceptual descriptions rather than exact code tokens or standard technical terminology (e.g., searching *"How do I keep my secrets safe?"* instead of the keyword-specific *"environment variables"* or *"config"*).
2. **Multilingual/Cross-lingual Queries:** If the documentation is written in English, but users query the docs in Spanish, Chinese, or German and expect matching English chunks to be retrieved directly.
3. **Conversational, Verbose Queries with Negation:** When users input long conversational paragraphs or queries with complex logical/negation rules where keyword-matching is diluted by noise (e.g., *"Why does it fail when I try to run the server locally on my machine without registering an API key?"*).
4. **Massive-Scale Knowledge Bases:** If our documentation base spans hundreds of thousands of pages, making a client-side/edge BM25 static JSON file too large to fetch (e.g., $\ge$ 5-10 MB), necessitating a centralized database backend for query execution.

### What We Should Keep (Even if We Adopt Embeddings):
If we do decide to introduce a dense vector embedding database, we should **not** replace the existing system entirely. Instead, we must keep:

1. **Hybrid Search (BM25 + Dense Vectors / Reciprocal Rank Fusion):**
   - Dense embeddings are notoriously poor at matching exact technical terms, API names, error codes, command-line flags (e.g., `--src`), and package names.
   - We must keep the **BM25 keyword search** alongside the embedding search and merge their results (e.g., via RRF or linear scaling). This ensures exact keyword queries resolve perfectly while conceptual queries are caught by semantic vectors.
2. **Hierarchical Weights and Meta-Attributes:**
   - Any vector database payload should preserve Leadtype's structured document/chunk hierarchy (Titles, Headings, Anchors, and relative URL paths). This metadata is crucial for formatting accurate citations and generating deep links directly to markdown section anchor tags (e.g., `urlPath#anchor`).
3. **Agent-Readable Artifacts & LLM Files:**
   - Keep Leadtype’s automatic compilation of flattened markdown files (`docs/**/*.md`), the offline-accessible version-matched npm package artifact (`AGENTS.md`), and the `/llms.txt` or `/llms-full.txt` context fallbacks.
   - These files enable developer AI agents (such as cursor, copilot, or custom LLM bots) to consume our documentation in high-density, low-token forms without querying any UI or search endpoints.
4. **Edge Caching & Low-Latency Fallbacks:**
   - Keep the local/client-side static BM25 index as an instant fallback or pre-fetch cache. This allows for instant, sub-millisecond "search-while-typing" autocompletes, falling back to database-backed embeddings only when the user hits Enter or asks a complex question.
