# What `leadtype` already gives you for docs search

## 1. What leadtype uses by default

`leadtype` does **not** use a database, vector store, or embeddings for docs search. By default it builds a **static, edge-safe BM25 search index** that ships as ordinary JSON (`search-index.json` plus optionally `search-content.json`).

The search engine (`searchDocs`) implements a full lexical retrieval pipeline with these features visible in the source:

- **BM25 scoring** (K1 = 1.2, B = 0.75) over chunked docs.
- **Weighted fields**: title (4×), heading (2×), body (1×), code (0.35×).
- **Query expansion**: exact tokens, English stemming, built-in/custom synonyms, prefix matches (up to 24 expansions), and typo tolerance via edit-distance (up to 16 expansions, distance 1–2).
- **Phrase & proximity boosts**: ordered phrase matches get a 1.4× boost; nearby ordered tokens within an 8-token window get a 0.8× boost.
- **Smart chunking**: 1,200-character chunks with 160-character overlap, split at sentence boundaries when possible, preserving heading hierarchy and code blocks.
- **RAG-ready answer context**: `createAnswerContext` retrieves top chunks via BM25, truncates them to a 12,000-character context window, and formats them with bracket citations `[1]`, source URLs, and a system prompt that instructs the LLM to treat the text as untrusted reference material.
- **Framework adapters**: streaming answer handlers for Vercel AI SDK, TanStack AI, and Cloudflare Workers AI (`streamDocsAnswer`) all consume this same BM25-retrieved context.

In short, leadtype already gives you source-grounded RAG without any hosted infrastructure.

## 2. When adding embeddings is actually warranted — and what to keep

Adding a vector/embedding index is warranted only when the **vocabulary gap between queries and docs exceeds what leadtype’s query expansion can bridge**. Specifically:

- **Conceptual/semantic queries**: users search with descriptive natural language (e.g., *“how do I make my app faster?”*) rather than keywords that appear in the docs (e.g., *“performance tuning”*). BM25 + synonyms handle many cases, but dense vectors capture latent semantic similarity where there is zero lexical overlap.
- **Very large corpora**: when doc volume is high enough that lexical noise degrades precision despite leadtype’s ranking.
- **Cross-lingual retrieval**: when queries are submitted in languages different from the docs and you need semantic alignment rather than translated keyword overlap.

**What you should keep even if you add embeddings:**

- **The BM25 index and `searchDocs` pipeline**. Technical docs are full of exact tokens—API names, CLI flags, config keys, error codes—where lexical matching is unbeatable. Hybrid retrieval (BM25 + embeddings) consistently outperforms either method alone.
- **Leadtype’s chunking and content store**. The chunks are already engineered with heading context, code-block separation, and sentence-aware overlap. These same chunks are the ideal units to embed; don’t re-invent chunking.
- **`createAnswerContext` and the citation format**. Whether retrieval is lexical or dense, the answer context builder (source URLs, bracket citations, system prompt, 12k-character truncation) is the layer that keeps answers grounded and safe.
- **The static index as a fallback**. A hosted vector DB is an extra dependency and network hop. Keeping leadtype’s static JSON index means search still works offline, at the edge, and when the vector service is down.

If you do stand up a vector index, treat it as an **augmentation**, not a replacement: embed leadtype’s existing chunks, run hybrid retrieval, and feed the merged results into leadtype’s answer context builder.
