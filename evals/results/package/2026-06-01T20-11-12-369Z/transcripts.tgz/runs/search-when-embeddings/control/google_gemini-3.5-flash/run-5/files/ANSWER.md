# `leadtype` Documentation Search Analysis

Our team is considering building a hosted, database-backed vector index for our docs search because "that's how RAG is done." However, before we take on the cost, latency, and infrastructure complexity of a vector database, here is a breakdown of what `leadtype` provides out-of-the-box and the conditions under which embeddings are actually warranted.

---

## 1. Default Docs Search in `leadtype`

By default, `leadtype` uses a **static, edge-safe, client-side keyword search engine** powered by the industry-standard **BM25 algorithm**. It compiles documentation at build-time into highly optimized static JSON files (`search-index.json` and optionally `search-content.json`). 

Here are the key components of `leadtype`'s default search pipeline:

### A. Zero-Database Edge Architecture
* **Static Assets:** The index and content stores are published as static JSON files.
* **In-Memory Edge Run:** The search runs entirely in the client's browser, in an Edge Function (e.g., Cloudflare Workers, Vercel Edge), or even fully offline (within IDEs and coding agents via `AGENTS.md`). No hosted database or external API is queried.

### B. High-Fidelity Markdown Chunking
* **Overlapping Chunks:** Splitting is done using overlapping chunks (default: `maxChunkChars: 1200` with `overlapChars: 160`).
* **Natural Boundaries:** Instead of naive character-count slicing, it splits text intelligently at sentence endings (`. `) or space boundaries to avoid breaking context mid-sentence.
* **Heading Path Context:** High-level headers and document hierarchies are propagated down to chunks, preserving critical contextual metadata.

### C. Text Normalization, Stemming, and Filtering
* **Unicode Normalization & Diacritic Stripping:** Queries and indexes are normalized, lowercase-folded, and stripped of diacritics.
* **Stopwords Filtering:** Common English stopwords (`the`, `a`, `is`, `for`, `how`, etc.) are automatically ignored to focus on key terms.
* **Light Stemming:** To handle different word variations, a suffix-stripping stemming routine handles words with length $\ge 4$ (stripping/reconstructing endings like `-ies`, `-ing`, `-ed`, `-es`, `-s`).

### D. Advanced Search Enhancements
* **Built-in Synonyms:** Supports standard synonym expansion (e.g., mapping `ai` $\leftrightarrow$ `["agent", "llm"]`, `auth` $\leftrightarrow$ `["authentication", "login", "signin"]`, `cli` $\leftrightarrow$ `["command", "terminal"]`) plus custom configurations.
* **Prefix Matching:** Matches query prefixes for longer terms, expanding up to 24 prefix expansions.
* **Typo Tolerance (Edit Distance):** Uses Levenshtein Edit Distance (up to 16 expansions) to match misspelled query terms when no exact match is found.

### E. Scoring and Match Boosting
* **BM25 TF-IDF Formula:** Ranks chunks based on term frequency adjusted by overall document length (`averageChunkLength`) and inverse document frequency.
* **Weighted Fields:** Different document elements are assigned specific importance weights during scoring:
  - **Title Weight:** `4.0`
  - **Heading Weight:** `2.0`
  - **Body Text:** `1.0`
  - **Code Blocks:** `0.35`
* **Phrase Match Boost:** Adds a **`1.4` multiplier/boost** if the exact query phrase is found sequentially.
* **Ordered Proximity Boost:** Adds a **`0.8` boost** if query terms appear in order within a sliding window of 8 tokens.

### F. Optional Source-Grounded LLM Context
Through `createAnswerContext`, it provides built-in prompt assembly for RAG:
* Selects the highest-scoring matching chunks (up to `maxSources`, default `6`) within prompt budget limits.
* Formats strict system-prompt boundaries ("Use only the provided context", "Do not invent APIs, options, behavior, paths, or package names") and structures bracket-based source citations.

---

## 2. When are Embeddings Warranted, and What Should We Keep?

### When are Embeddings/Vector Search Warranted?
Adding dense vector embeddings and a hosted vector database is **only warranted** if we face specific semantic and linguistic challenges that keyword matching cannot address:

1. **Purely Conceptual Queries:** When users search for abstract concepts without using any exact technical terms or keywords present in the text (e.g., searching "how do I protect my secret keys" instead of the exact configuration setting `apiKey` or `env`).
2. **Cross-Lingual/Multilingual Search:** When documentation is in one language (e.g., English), but we expect users to query in other languages (e.g., Spanish, Japanese) and get high-quality semantic matches.
3. **Vast, Heterogeneous Docsets:** If we have hundreds of thousands of documents written across multiple domains with differing vocabularies where manual synonym mapping is impractical.
4. **Conversational, Free-form Chatbots:** Where users expect a conversational assistant to trace long-range connections over conversational turns, rather than simple target-oriented documentation queries.

### Why Avoid Moving *Exclusively* to Vectors?
For **developer and technical documentation**, an exclusive vector search database often **performs worse** than BM25:
* **API and Technical Token Mismatch:** Developers search for precise strings: function signatures, config keys (e.g. `defineDocsConfig`), command flags (e.g. `--bundle`), or specific error codes. Vector models tend to smooth these out, matching similar *concepts* but failing to retrieve the exact page containing that specific technical term.
* **Cost, Cold Starts, and Network Latency:** Generating embeddings on-the-fly during search requires API calls or dedicated hosted inference, causing notable latency and operational costs compared to client/edge-side static search which has 0ms cold starts.

### What We Should Keep Even If We Add Embeddings

If we do choose to implement embeddings, we should treat them as an *addition* rather than a complete replacement:

1. **Hybrid Search (BM25 + Dense Vectors via RRF):** We must keep `leadtype`'s BM25 search index. Combine search results using a merging technique like Reciprocal Rank Fusion (RRF). BM25 will guarantee that precise searches (API keys, exact function names, CLI flags) work perfectly, while dense vectors will handle broad conceptual queries.
2. **The Markdown-to-Text Chunking Pipeline:** Do not replace `leadtype`'s build-time chunker. A vector model is only as good as the chunks it embeds. We should reuse `leadtype`'s intelligent overlapping splits, header context propagation, and code-fencing separation as the exact input payload for generating embeddings.
3. **Client-Side/Edge Fallback:** Retain the static search index as a local fallback for offline development, local previews, coding agents, and CLI integrations when the hosted vector database is offline or out-of-reach.
4. **Strict RAG Prompts and Guardrails:** Keep the system prompt structures and constraints defined in `createAnswerContext` to prevent LLM hallucinations, enforce strict bracket-citation habits, and restrict answers strictly to verified context.
