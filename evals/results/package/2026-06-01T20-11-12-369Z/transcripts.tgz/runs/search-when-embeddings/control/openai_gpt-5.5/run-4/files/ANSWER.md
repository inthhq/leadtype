# Leadtype docs search and when embeddings are worth adding

## 1. What Leadtype uses by default

Leadtype already builds a **static, edge-safe lexical search index** for docs search. By default it is **BM25**, not a hosted vector database and not embeddings.

Concretely, Leadtype:

- Converts source MDX/docs into flattened markdown.
- Splits the docs into heading-aware chunks, with default chunk sizing around `1200` characters and overlap around `160` characters.
- Writes generated JSON search artifacts such as `search-index.json` and, depending on configuration, separate or embedded search content.
- Scores queries with BM25 over an inverted term index.
- Weights matches differently by field:
  - title matches are strongest,
  - heading matches are next,
  - body text is normal weight,
  - code is lower weight.
- Adds practical lexical matching behavior: token normalization, stopword removal, light stemming, built-in and custom synonyms, prefix expansion, typo tolerance, and phrase/proximity boosts.
- Can build source-grounded answer context for an LLM from the retrieved chunks, but retrieval is still based on Leadtype’s local/static search index unless we add something else.

So the default system is: **static generated docs artifacts + BM25 lexical retrieval + optional LLM answer generation grounded in retrieved source chunks**. It does not require a database, embeddings service, or hosted vector index.

## 2. When embeddings are actually warranted

Embeddings are worth adding only when we have evidence that lexical retrieval is not enough. Good reasons include:

1. **Measured vocabulary mismatch**  
   Real query logs or an evaluation set show users ask questions using language that does not overlap with the docs, and BM25 misses the right pages even after improving titles, headings, descriptions, synonyms, and docs wording.

2. **Semantic or conceptual queries dominate**  
   Users frequently ask broad natural-language questions like “how do I recover from a failed deploy?” where the best docs may use different terms such as rollback, release health, or restore.

3. **The corpus is large or heterogeneous enough that keyword ranking is consistently weak**  
   For example, many products, old/new terminology, aliases, renamed APIs, support-style content, or docs where the same concept is described in many different ways.

4. **Cross-lingual or heavy paraphrase search is a real requirement**  
   If users search in one language or dialect and the docs use another, embeddings may help more than synonym lists.

5. **We are prepared to operate it properly**  
   A vector system adds freshness, deletion, versioning, access-control, cost, latency, evaluation, and relevance-tuning work. It is warranted only if the retrieval gains justify that operational burden.

Even if we add embeddings, we should **keep Leadtype’s BM25/static search path**. Embeddings should augment it, not replace it.

Keep:

- Leadtype’s generated markdown/chunks as the canonical source material to embed and cite.
- BM25 lexical retrieval for exact identifiers, API names, option names, error strings, CLI flags, code symbols, and version-specific terms — these are often where embeddings are weakest.
- Hybrid retrieval: combine BM25 and vector results, then optionally rerank.
- Leadtype’s source-grounded answer pattern: answer only from retrieved docs chunks, cite sources, and say when context is insufficient.
- Query validation, limits, rate limiting, and the “docs excerpts are untrusted reference text” guardrail.

Bottom line: start with Leadtype’s default static BM25 search. Add embeddings only after measured search failures show semantic recall is the bottleneck, and keep BM25 as part of a hybrid retrieval system.