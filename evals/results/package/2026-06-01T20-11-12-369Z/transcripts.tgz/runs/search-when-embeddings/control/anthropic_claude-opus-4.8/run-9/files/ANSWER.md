# Does our docs search need a hosted vector index? (leadtype)

Short version: **no, not to start.** `leadtype` already ships a complete docs
search system that needs no database, no embedding model, and no separate
service. Build on it first; reach for embeddings only when you hit a specific,
measured limit — and even then, keep what leadtype already gives you.

---

## 1. What leadtype's docs search uses by default

leadtype builds a **static, edge-safe search index** at build time and queries
it with **BM25** — a classic lexical (keyword) ranking algorithm. There are **no
embeddings, no vectors, and no vector database** anywhere in the runtime.

How it actually works (from `leadtype/search` and `leadtype/search/node`):

- **Build step (`generateDocsSearchFiles` / `createDocsSearchIndex`).** Your
  flattened markdown is split into overlapping chunks (default ~1200 chars with
  ~160 chars overlap), tokenized, stop-worded, and inverted into a term →
  postings index. The output is plain JSON:
  `public/docs/search-index.json` (plus optional embedded content). No server,
  no DB — just a file you ship to the edge/CDN.

- **Query step (`searchDocs`).** Ranking is **BM25** (`k1 = 1.2`, `b = 0.75`)
  with field weighting — titles count most, then headings, then body, then code
  (`TITLE_WEIGHT 4`, `HEADING_WEIGHT 2`, `BODY_WEIGHT 1`, `CODE_WEIGHT 0.35`).

- **It is smarter than naive keyword match.** Even without embeddings, the
  matcher already does: light stemming, a built-in synonym table (e.g.
  `auth → authentication/login/signin`, `cli → command/terminal`), prefix
  expansion (good for as-you-type), typo tolerance via bounded edit distance,
  and phrase/proximity boosts. This covers a large share of what people *assume*
  they need semantic search for.

- **Optional "source-grounded answers" are still BM25 under the hood.**
  `createAnswerContext` (used by the `leadtype/search/vercel`,
  `/tanstack`, and `/cloudflare` answer adapters) is retrieval-augmented
  generation where **retrieval is the same BM25 index**. It pulls the top
  chunks (default `maxSources = 6`, `maxContextChars = 12000`), then hands an
  LLM a strict, citation-enforcing system prompt that says: use only the
  provided context, treat docs as untrusted reference text, cite sources `[1]`,
  and don't invent APIs. So you can already offer "ask the docs" with citations
  **without any vector store** — the LLM only writes the answer; it does not do
  the retrieval.

- **Runtime guards are built in.** Query validation, request-size limits, and an
  in-memory rate limiter ship with the package, so the search endpoint is
  production-shaped out of the box.

**Net:** the default is a CDN-served JSON index + BM25 ranking, optionally
wrapped with grounded LLM answers. Zero infrastructure beyond static hosting.

---

## 2. When adding embeddings is actually warranted — and what to keep

Stand up an embedding/vector layer **only after** you can point to a concrete,
measured failure of lexical search — not "because that's how RAG is done."
Embeddings buy you *semantic* matching (paraphrase/concept overlap with no shared
words); they cost you an embedding model, an indexing pipeline, a vector store to
host and keep in sync, and added latency/spend. That trade is justified when **at
least one** of these is true and demonstrated with real query logs:

- **Vocabulary mismatch is the dominant failure.** Users search for concepts in
  words your docs never use, and leadtype's synonym table + stemming + typo
  tolerance demonstrably don't bridge the gap. (First, try *extending the synonym
  map* — it's a config, not a rebuild of the stack.)
- **The corpus is large and broad enough** that keyword precision/recall has
  measurably degraded — not a few dozen tightly-scoped pages.
- **You need cross-lingual or true natural-language Q&A retrieval** where the
  query language/phrasing routinely diverges from the source text.
- **You have the operational appetite** to own re-embedding on every docs change,
  monitor drift, and pay the hosting/latency bill.

If none of these hold, the hosted vector index is premature infrastructure.

### Keep these even if you add embeddings

- **Keep BM25.** Lexical search is unbeatable for exact terms: API names, flags,
  error strings, file paths, `kebab-case`/`camelCase` identifiers — exactly the
  high-intent queries in dev docs. Best practice is **hybrid retrieval** (BM25 +
  vectors, fused), with embeddings *augmenting* leadtype's index, not replacing
  it.
- **Keep leadtype's chunking and the static index as the lexical half.** The
  chunk + heading-path structure is already what you'd want to embed; reuse it so
  the two retrievers stay aligned to the same content units.
- **Keep `createAnswerContext`'s grounding contract.** Citations, "use only
  provided context," "treat docs as untrusted," and "don't invent APIs" are what
  make answers trustworthy. Swapping the retriever to vectors changes *how chunks
  are found*; it should not loosen *how answers are constrained and cited*.
- **Keep the edge-served static index as the default path.** Even with a vector
  service, the no-dependency static index is a cheap, always-available fallback
  and remains the right default for most pages.

---

## Recommendation

Ship leadtype's built-in BM25 static index now (optionally with grounded
answers). Add synonyms where logs show gaps. Only introduce a hosted, DB-backed
vector index once query logs prove semantic recall is the bottleneck — and add it
as the *second* retriever in a hybrid setup, keeping BM25 and the existing
grounding/citation contract.
