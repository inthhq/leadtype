# Leadtype Docs Search: Capabilities and Architectural Trade-offs

Here is an evaluation of `leadtype`'s default search capabilities and the specific conditions under which introducing a hosted vector database/embeddings is warranted.

---

## 1. What Leadtype's Docs Search Uses by Default

By default, `leadtype` implements a **static, edge-safe, zero-dependency keyword-based search engine** powered by a highly tuned implementation of the **BM25 probabilistic retrieval algorithm**.

Instead of requiring an external database or hosted vector index, `leadtype` generates compact, static JSON search artifacts at build time:
*   `search-index.json`: A space-efficient inverted index containing postings lists, term frequencies, document metadata, and token statistics.
*   `search-content.json`: The raw text chunks of the documentation, loaded on-demand to construct snippets and feed prompts.

### Default Search Architecture and Features:
1.  **Semantic-Aware BM25 Ranking & Tuning**:
    *   Scores matching pages/chunks using BM25 with standard tuning parameters: $k_1 = 1.2$ (`BM25_K1`) and $b = 0.75$ (`BM25_B`).
    *   Weights fields differently to ensure prominent sections rank higher:
        *   **Title Weight**: `4.0`
        *   **Heading Weight**: `2.0`
        *   **Body Weight**: `1.0`
        *   **Code Block Weight**: `0.35`
2.  **Advanced Natural Language Processing (NLP)**:
    *   **Tokenization**: Uses a Unicode-aware word boundary pattern (`/[\p{L}\p{N}]+/gu`) to extract tokens.
    *   **Stopwords Filtering**: Automatically removes common filler words (e.g., "the", "with", "what").
    *   **Rule-Based Stemming**: Normalizes words by stripping/mapping common English suffixes (`-ies` $\rightarrow$ `-y`, `-ing`, `-ed`, `-es`, `-s`).
    *   **Synonym Mapping**: Maps equivalent terms (e.g., `ai` $\rightarrow$ `["agent", "llm"]`, `ts` $\rightarrow$ `["typescript"]`, `auth` $\rightarrow$ `["authentication", "login"]`) using a configurable synonyms registry.
    *   **Typo Tolerance**: Matches spelling mistakes using Levenshtein edit-distance calculations up to an edit distance of $2$ for longer terms.
    *   **Prefix Expansion**: Automatically matches partial query words to terms in the index (up to 24 prefix expansions).
3.  **Syntactic and Semantic Boosts**:
    *   **Ordered Phrase Match Boost**: Adds a `1.4` multiplier if search terms appear consecutively.
    *   **Ordered Proximity Match Boost**: Adds a `0.8` multiplier if search terms appear within an 8-word window (`PROXIMITY_WINDOW`).
4.  **Automatic Section-Aware Chunking**:
    *   Splits files along markdown headings and paragraphs into overlapping chunks (`DEFAULT_MAX_CHUNK_CHARS = 1200` characters, `DEFAULT_OVERLAP_CHARS = 160` characters). This keeps structural text blocks whole and maintains context without cutting off sentences mid-thought.
5.  **Source-Grounded Prompt Generation (Local RAG)**:
    *   Using `createAnswerContext`, it acts as a fully offline RAG coordinator. It extracts the top relevant context blocks, assigns bracket citations, and compiles them into structured system and user prompts ready to be streamed to an LLM via adapters like `leadtype/search/vercel` or `leadtype/search/tanstack`.
6.  **Framework Integration**:
    *   Includes edge-safe hook APIs (e.g., `useLeadtypeSearch`) for React, Svelte, and Vue, plus server-side helpers for Next.js and Cloudflare Workers to handle queries locally and instantly.

---

## 2. When to Add Embeddings — and What to Keep

### When Adding Embeddings is Actually Warranted
Standing up a hosted, database-backed vector database for embeddings (dense vector retrieval) is justified only under these specific conditions:

1.  **Conceptual and Semantic Queries (No Keyword Overlap)**:
    *   When users describe concepts or problems in natural language without using the exact technical jargon found in the docs (e.g., searching *"How do I run code when the app shuts down?"* when the documentation only uses technical terms like *"lifecycle hook"* or *"teardown process"*).
2.  **Conversational/Chat-Style Q&A (Complex Intent)**:
    *   When embedding a chat assistant that deals with verbose, conversational, multi-sentence user queries. BM25 is highly sensitive to keyword density and can rank poor matches highly if filler keywords overlap, whereas embeddings capture the aggregate semantic intent.
3.  **Cross-Lingual Search**:
    *   When your documentation is written in English, but you must support users searching in Spanish, Japanese, or other languages. Multi-lingual vector models embed semantically equivalent concepts into the same vector space, enabling cross-language matching out of the box.

---

### What We Should Keep (Even with Vector Search)
If you decide to integrate embeddings, **do not throw away `leadtype`'s defaults**. A pure vector search engine is highly fragile on its own. Instead, implement a **hybrid search strategy** and keep the following:

1.  **Leadtype's BM25 Index (for Hybrid Search)**:
    *   **Why**: Vector embeddings are notoriously bad at searching for exact identifiers, code symbols, technical parameters, or command-line flags (e.g., searching for `useLeadtypeSearch`, `--src`, `overlapChars`, or specific status codes like `413`). 
    *   **Solution**: Keep the static BM25 index and use **Hybrid Search** with **Reciprocal Rank Fusion (RRF)** or weighted score fusion. BM25 guarantees that exact technical matches are retrieved, while embeddings provide conceptual fallback.
2.  **Leadtype's Markdown Parser and Chunking Pipeline**:
    *   **Why**: Quality embeddings rely on clean chunking.
    *   **Solution**: Do not write custom chunking scripts. Keep using `leadtype`'s build-time `collectSectionBlocks` and `splitWithOverlap` utilities. By generating embeddings directly from `leadtype`'s parsed chunks, your vector index and BM25 index will remain perfectly aligned, point to the same anchors/headings, and maintain identical section contexts.
3.  **Local UI Client and Instant Fallback**:
    *   **Why**: Querying a hosted vector database has latency and financial costs.
    *   **Solution**: Keep `leadtype`'s client-side search for the primary search bar. Instant, client-side BM25 queries (with 0ms network latency and $0 cost) provide a much faster user experience for basic keyword lookup, reserving the heavier vector DB queries for specialized conversational/AI-answer blocks.
4.  **Edge-Safe Rate-Limiting, Session-Guard, and prompt utilities**:
    *   Utilities like `createMemoryRateLimiter`, `getClientIdentifier`, and the streaming response format of `streamDocsAnswer` remain extremely valuable for managing requests and orchestrating security at the edge.
