# Leadtype Docs Search & Embedding Analysis

## 1. Default Leadtype Docs Search Architecture

By default, `leadtype` uses a **high-performance, static, edge-safe BM25 full-text keyword search engine** that compiles a pre-tokenized inverted index during build time. This architecture has zero database or external hosted search engine dependencies, meaning the search runs entirely client-side or on edge workers using static JSON files (`search-index.json` and `search-content.json`).

Here are the key technical components of `leadtype`'s default search engine:

### A. Core Search Algorithm: Okapi BM25
The search ranks documents using the standard BM25 TF-IDF variant.
* **Core Formula Parameters**: It uses BM25 configuration constants: `BM25_K1 = 1.2` (term frequency saturation controls) and `BM25_B = 0.75` (document length normalization).
* **Length Normalization**: Chunks are scored relative to the `averageChunkLength` to prevent longer sections from dominating short, highly relevant ones.

### B. Weighted Fields
Search items (chunks) are scored using field-level prioritization weights to ensure high-intent titles and headings rank higher than body text or code:
* **Title Weight**: `4`
* **Heading Weight**: `2`
* **Body Weight**: `1`
* **Code Weight**: `0.35` (code snippets are indexed but weighted lower to avoid noise from syntax)

### C. Advanced Query Expansion & Linguistics
The default engine goes far beyond simple exact-match string search by implementing several NLP and ranking heuristics:
* **Tokenization & Stopwords**: Standardizes text via lowercasing, NFKD unicode normalization, and removing diacritics. It filters common stopwords (e.g., `a`, `the`, `with`, `use`, `how`) to focus on key search terms.
* **Stemming**: Custom suffix reduction (`stemToken`) for standard plurals and gerunds (reducing suffixes like `-ies` to `-y`, `-ing`, `-ed`, `-es`, `-s` for words with length >= 4).
* **Synonyms**: Uses a built-in synonym vocabulary (`DEFAULT_SYNONYMS` maps keys like `ai`/`agent`/`llm`, `auth`/`authentication`/`login`, `ts`/`typescript`, `install`/`setup`/`add`) and supports custom user-configured synonyms. Matches are scored with a weight of `0.72`.
* **Prefix Expansion**: Automatically expands trailing prefix matches (up to `24` expansions) for terms with length >= 4, scored with a weight of `0.55`.
* **Typo Tolerance**: Uses a dynamic Levenshtein edit distance calculation (`editDistanceWithin` up to distance 1 for short words, distance 2 for words >= 7 chars starting with the same character) to find typo corrections (up to `16` expansions), scored with a weight of `0.45`.
* **Phrase & Proximity Boosting**:
  * **Phrase Match Boost**: Grants a `1.4` multiplier if multiple query terms appear in sequence in the text.
  * **Proximity Boost**: Grants a `0.8` multiplier if query terms appear in order within a proximity window of `8` words.

### D. Document Chunking & Structural Modeling
* **Overlapping Chunks**: Splits documents into digestible segments using configurable limits (defaults: `maxChunkChars = 1200`, `overlapChars = 160`).
* **Heading Paths**: Restructures MDX sections under hierarchical heading paths (`headingPath`) to preserve document context even within a single excerpt.
* **Static Assets**: Generates lightweight JSON artifacts (`search-index.json` and `search-content.json`) that can be fetched dynamically and queried directly.

---

## 2. When is Vector Search/Embeddings Warranted?

Hosted vector databases and embedding-based RAG pipelines are a major architectural change. Adding vector embeddings is only warranted under the following specific conditions:

1. **Conceptual & Semantic Gap**: When users frequently query using high-level concepts, synonyms, or descriptive scenarios that do not share exact keywords with the technical documentation. For example, a user searching "how to secure my API" should find pages discussing "authentication tokens" or "request signing," even if the word "secure" is absent from those pages.
2. **Natural Language / Conversational Queries**: When your main interface is a conversational chatbot or voice search where queries are phrased as conversational sentences (e.g., "My deployment is failing with an out of memory error, what config do I change?") rather than distinct keywords.
3. **Cross-Lingual Search**: If you have a multilingual audience and want query terms in one language (e.g., Spanish) to surface relevant sections written in another language (e.g., English) using cross-lingual semantic embedding spaces.
4. **LLM Synthesis (Generative RAG)**: When you are building a full chatbot assistant that synthesizes customized prose answers from multiple sections of documentation, and the exact keyword-retrieved sections lack the holistic coverage that a semantic vector match can surface.

---

## 3. What to Keep Even if We Adopt Vector Search (Hybrid Search Strategy)

If you decide to adopt a hosted vector index, **you should NOT discard Leadtype's BM25 search.** Instead, you should build a **hybrid search** system that merges both approaches, and you should preserve Leadtype's content pipeline:

### A. Keep BM25 (Lexical Search) alongside Vector Search
Vector embeddings are notoriously bad at indexing and matching **exact technical keywords, specific API names, command-line arguments, configuration flags, and error messages**.
* **Why?** An embedding model compresses the entire string into a dense vector space. A query for a precise API like `useLeadtypeSearch` or an option like `--src` might have a similar vector coordinate to unrelated hook or CLI parameters, leading to poor precision. BM25 is vastly superior at retrieving documents with exact matches for technical tokens.
* **Hybrid Search Integration**: Combine BM25 scores and Vector Search similarity scores using **Reciprocal Rank Fusion (RRF)** or a linear weighted combination. This ensures users get the best of both worlds: conceptual comprehension from vectors and exact technical precision from BM25.

### B. Keep Leadtype's Build and Chunking Pipeline
Generating high-quality embeddings requires clean, structurally well-formed, and chunked text inputs. You should keep Leadtype's build-time pipeline because:
1. **MDX Content Flattening**: MDX code includes custom React/Astro/Svelte components, markdown imports, and frontmatter. Leadtype flattens and converts raw MDX into clean, LLM-readable plain markdown (`convert/index.js`). Passing raw MDX directly to an embedding model would pollute the vector representations with JSX syntax and code blocks.
2. **Structured Chunking & Metadata**: Leadtype's default partitioner intelligently splits files based on heading hierarchies, tracks heading paths, and computes relative URLs. You can leverage these pre-made, logically coherent chunks as the inputs for your embedding generator, rather than writing a custom chunking algorithm.
3. **Framework Adaptability and Local RAG Utilities**: Leadtype already provides lightweight context assembly and rate-limiting utilities (e.g., `createAnswerContext` and rate limiters) which are incredibly useful for constructing LLM prompt payloads locally or on the edge.
