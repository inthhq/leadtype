# What `leadtype` already gives us for docs search

Short version: before standing up a hosted, database-backed vector index, know
that `leadtype` already ships a complete, zero-infrastructure docs search — and
for most documentation it is the right default, not a placeholder.

## 1. What leadtype's docs search uses by default

leadtype builds a **static, edge-safe search index** at build time and ranks
results with **BM25 (lexical / keyword) search**. There is no database, no
embedding model, and no vector store anywhere in the package.

How it works (from `leadtype/search` + `leadtype/search/node`):

- **Build-time index.** `leadtype generate` emits
  `public/docs/search-index.json` — a single static JSON file. It is served as
  a plain asset from your existing host/CDN/edge; there is nothing to run or
  operate.
- **Chunking.** Each doc is split into heading-scoped chunks
  (~1200 chars with ~160-char overlap), preserving the heading path so results
  can deep-link to the right anchor.
- **BM25 ranking** with sensible tuning (`k1 = 1.2`, `b = 0.75`) and
  **field weighting** so matches in titles/headings outrank body, and code
  blocks count least (title 4× / heading 2× / body 1× / code 0.35×).
- **Lexical recall beyond exact matches.** The query pipeline already does:
  - stopword removal and Unicode/diacritic normalization,
  - lightweight stemming,
  - a built-in synonym map (e.g. `cli`→`command`, `config`→`configure`,
    `install`→`setup`),
  - prefix/autocomplete expansion,
  - typo tolerance (bounded edit distance),
  - phrase and ordered-proximity boosts.
- **Runs at the edge / in the browser.** The runtime (`searchDocs`) is
  dependency-light and synchronous over the JSON index — no server round-trip
  to a search service is required.
- **Optional source-grounded answers (still no embeddings).** If you want an
  "ask" experience, `createAnswerContext` runs the *same* BM25 retrieval, then
  hands only the retrieved doc chunks to an LLM with citations and a strict
  "use only the provided context, do not invent APIs" system prompt
  (`leadtype/search/vercel`, `/tanstack`, `/cloudflare`). The retrieval layer is
  lexical; the LLM only summarizes what BM25 already found.

So the default is: **static JSON + BM25 lexical search, optionally feeding a
source-grounded (cited) answer layer — with zero hosted infrastructure.**

## 2. When embeddings are actually warranted — and what to keep

Adding embeddings / a hosted vector index is a real cost (an embedding model, a
vector DB to run and pay for, an indexing pipeline, sync/freshness handling, and
new failure modes). It is only worth it under specific conditions, **not** by
default and not just "because that's how RAG is done."

Add embeddings only when **all** of these hold:

- **Measured recall gap.** You have evidence (real query logs / eval set) that
  BM25 is missing relevant results — typically because users search by
  *concept/synonym/paraphrase* using vocabulary that does not appear in the
  docs, and the built-in synonym map + stemming + typo tolerance don't close it.
- **The corpus is large and diverse enough** that semantic matching meaningfully
  beats keyword matching. Small, well-structured, jargon-consistent docs rarely
  benefit.
- **The improvement justifies the operational cost** of running and keeping a
  vector index fresh on every docs change. For most product docs, it does not.

Even then, **keep the leadtype defaults rather than replacing them:**

- **Keep BM25 as the baseline / first-pass retriever** and use embeddings as a
  *complement* (hybrid search), not a replacement. Lexical search is
  unbeatable for exact terms: API names, flags, error strings, code identifiers
  — exactly the things docs users search for, and exactly where pure-vector
  search tends to underperform.
- **Keep the static build-time index and edge-served JSON** as the default,
  always-available path. It needs no infrastructure, can't go down independently
  of your site, and is the right answer for offline/agent/bundled consumption.
- **Keep the chunking + heading-anchored, cited, source-grounded answer
  pipeline.** Whatever retriever you add should still feed the same
  citation-backed, "only use provided context" answer layer — that grounding is
  what keeps answers trustworthy, and it's independent of whether retrieval is
  lexical or vector.

### Recommendation

Ship leadtype's default static BM25 search now. Instrument real queries. Only if
the logs show a genuine semantic-recall gap on a large enough corpus, add an
embedding index as a *hybrid* layer on top of BM25 — keeping the static index,
the chunking, and the cited source-grounded answers. Don't start by building a
hosted vector DB.
