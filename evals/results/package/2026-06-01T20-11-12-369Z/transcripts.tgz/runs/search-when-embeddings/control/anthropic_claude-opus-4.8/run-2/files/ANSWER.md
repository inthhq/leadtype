# Docs search in `leadtype` — what we already have, and when embeddings are worth it

_Based on `leadtype@0.1.2` as installed in `node_modules/leadtype` (README + the
search runtime in `dist/_shared/search-TL9muun_.js`, exposed via `leadtype/search`
and built with `leadtype/search/node`)._

## TL;DR

`leadtype` ships a complete, static, **lexical (BM25)** docs search engine out of
the box. There are **no embeddings, no vector store, and no database** anywhere in
the package — and for a typical docs set, you very likely don't need one. Reach for
embeddings only when you have evidence that lexical retrieval is failing on
real, vocabulary-mismatched queries, and even then keep BM25 as the backbone.

---

## 1. What leadtype's docs search uses by default

leadtype builds a **static, edge-safe BM25 search index** at generate time and
queries it at runtime with a small pure-JS function. No server, no database, no
embedding model is involved.

### Build time (`leadtype generate` → `generateDocsSearchFiles` / `createDocsSearchIndex`)
- Flattens MDX to markdown, strips frontmatter, and splits each page into
  **section-aware chunks** with overlap (defaults: `maxChunkChars` 1200,
  `overlapChars` 160), tracking the heading path and anchor for each chunk.
- **Tokenizes** text: Unicode-aware word splitting, NFKD normalization, diacritic
  stripping, lowercasing, stopword removal, single-character tokens dropped.
- Stores an **inverted index** (`terms` → postings) with per-field term counts so
  fields can be weighted at query time:
  - title ×4, heading ×2, body ×1, code ×0.35.
- Emits a plain `search-index.json` (current `SEARCH_INDEX_VERSION = 2`). Chunk
  text can be inlined or split into a separate content file via the
  `embedContent` option — note this is about **embedding text into the JSON file**,
  *not* vector embeddings.

### Query time (`searchDocs` / `createSearchClient` / `useLeadtypeSearch`)
- Scores chunks with **BM25** (`k1 = 1.2`, `b = 0.75`) using the field-weighted
  term frequencies and an IDF over chunks.
- Recall is widened beyond exact matches by lightweight, fully local techniques:
  - **stemming** (weight 0.82), **synonyms** (built-in map + user-supplied, 0.72),
    **prefix expansion** (0.55), and **typo / fuzzy matching** via bounded edit
    distance (0.45). Exact matches score 1.0.
  - **phrase** (×1.4) and ordered **proximity** (×0.8) boosts for multi-word queries.
- Returns ranked results with title, URL (+ heading anchor), heading path, and a
  query-aware **excerpt**. Includes request guards: query validation, body-size
  limits, and an in-memory rate limiter.

### Optional AI answers (`createAnswerContext` + the `vercel` / `tanstack` / `cloudflare` adapters)
- "Answers" are **retrieval-augmented over the same BM25 index**: leadtype selects
  the top chunks, builds a citation-numbered context block, and hands a model a
  strict system prompt ("use only the provided context", treat docs as untrusted
  reference, cite `[1]`/`[2]`, don't invent APIs). The LLM is only used to phrase
  an answer — **retrieval is still lexical BM25**.

### Key properties (why this is more than "good enough")
- **Zero infrastructure**: a single static JSON artifact served from the edge/CDN.
- **No runtime model calls or API keys** for search; **deterministic & offline-capable**.
- **No build-time embedding cost**, no index drift, trivial to diff and cache.

---

## 2. When adding embeddings is actually warranted — and what to keep

Adding embeddings (and only then, possibly, a hosted vector index) is justified
**only when all of these hold**:

1. **Measured lexical failure on real queries.** You have logs/eval data showing
   users phrase questions with vocabulary that doesn't appear in the docs
   (concept/synonym mismatch), *and* leadtype's built-in synonym map, stemming,
   prefix, and fuzzy expansion don't already cover it. If you haven't first
   extended the **`synonyms` option**, you haven't earned an embedding model yet.
2. **Scale/recall ceiling.** The corpus is large and diverse enough that pure
   lexical recall is the demonstrated bottleneck (not chunking, weighting, or UI).
3. **Cross-lingual / paraphrase needs** that lexical matching structurally can't
   serve.
4. **You can absorb the new costs**: an embedding model in the build (and/or at
   query time), index regeneration on every docs change, and the operational
   burden of whatever store you pick.

A **hosted, database-backed vector index is the last resort, not the default.**
Before standing one up, prefer in-order:
- extend `synonyms` and tune field weights / chunk size;
- if you add embeddings, keep the artifact **static** (precomputed vectors shipped
  alongside `search-index.json`, queried at the edge) rather than introducing a
  managed DB. Only adopt a hosted vector DB if corpus size, write frequency, or
  multi-tenant requirements genuinely exceed a static artifact.

### What to keep even then
- **Keep BM25 as the retrieval backbone.** Embeddings should *augment*, not
  replace it — the strongest setup is **hybrid**: run leadtype's BM25 and combine
  it with vector similarity (e.g. reciprocal-rank fusion). BM25 still wins on exact
  terms, code identifiers, flags, API names, and error strings that embeddings blur.
- **Keep leadtype's chunking, heading/anchor metadata, and field weighting** — they
  remain the right retrieval units and ranking signals regardless of the matcher.
- **Keep the static, edge-first delivery model** wherever possible; preserve the
  zero-key, deterministic, CDN-cacheable property that makes the default search cheap.
- **Keep source-grounded answering** (`createAnswerContext`): the citation-enforcing,
  "context-only / don't-invent-APIs" prompt contract is independent of how chunks
  are retrieved and should stay in place.

**Bottom line:** leadtype already gives us field-weighted BM25 with stemming,
synonyms, fuzzy/prefix expansion, phrase/proximity boosts, and source-grounded
answers — as a static, no-database artifact. Start there, instrument real queries,
extend the synonym map, and only add embeddings (and, even more rarely, a hosted
vector index) when measurements prove lexical recall is the bottleneck — keeping
BM25, the existing chunking/metadata, and the static delivery model underneath.
