# Leadtype Docs Search: What It Provides by Default

## 1. Default Search Implementation

**Leadtype builds a static, edge-safe BM25 full-text search index** out of the box.

### What this means:

- **BM25 ranking algorithm**: A probabilistic retrieval model that scores documents based on term frequency, inverse document frequency, and field-specific weighting (title, headings, body, code get different weights).
- **Full-text indexing**: Every word in your docs is tokenized, normalized, stemmed, and indexed as a compressed posting list.
- **Static generation**: The search index is built at docs generation time (via `npx leadtype generate`), producing a `search-index.json` file that's small, versioned with your docs, and requires zero backend.
- **Edge-safe runtime**: The search executes entirely in the browser or edge worker—no server calls needed. The client-side `createSearchClient()` loads the pre-built index and runs queries locally.
- **Rich matching features**:
  - **Exact term matching** (highest weight)
  - **Stemming** (e.g., "installing" matches "install")
  - **Synonyms** (e.g., "setup" matches "install"; built-in synonym map is extensible)
  - **Prefix matching** (e.g., "doc" matches "documentation")
  - **Typo tolerance** (edit distance ≤1 or ≤2 depending on term length)
  - **Phrase and proximity boosts** (consecutive or nearby query terms boost relevance)
- **Chunking with overlap**: Documents are split into semantic chunks (default 1200 chars with 160-char overlap) so results point to specific page sections with anchors, not just whole pages.
- **Optional answers**: Built-in support for generating LLM-grounded answers via `createAnswerContext()`, which retrieves top search results as source context and outputs system + prompt templates ready for model calls.

### The search index includes:

- Document metadata (title, description, URL, locale info)
- Chunk boundaries with heading paths (for deep linking)
- Inverse index of terms → postings (chunk occurrences with per-field term counts)
- Optional separated content store (`search-content.json`) for deferred loading

### Typical size:

- Index alone: ~10–50 KB for 50–100 docs (highly compressible, often gzipped in transit)
- With embedded content: larger but still edge-deployable
- No database; no API; no rate limiting needed beyond memory-based in-process rate limiters if desired

---

## 2. When Adding Embeddings Is Actually Warranted

**Most doc sites do not need embeddings.** BM25 is fast, lightweight, and works well for keyword-driven queries. However, **add embeddings if**:

### Conditions warranting embeddings:

1. **High semantic mismatch between queries and docs**  
   - Users ask conceptual questions ("How do I authorize API calls?") that don't share keywords with your docs ("API key authentication flow").
   - Synonyms and stemming alone miss these gaps.

2. **Large doc sets (>500 pages) with complex topic interconnections**  
   - BM25's ranking degrades gracefully but becomes less precise.
   - Semantic similarity can disambiguate polysemous terms and concept drift.

3. **Multi-language or transliteration needs**  
   - Embeddings handle meaning across scripts; BM25 is character-based.

4. **You already have a hosted vector database for other products**  
   - Hosting overhead is amortized across your infra.

### Critical: What to keep even when you add embeddings

**Do not replace the static BM25 index; hybrid search is best:**

- **Keep the BM25 index** as a fast, reliable fallback and first-pass filter.
  - It runs client-side with zero latency and no backend dependency.
  - It catches exact-match and near-keyword queries instantly.
  - It reduces the corpus for embedding-based reranking.

- **Use embeddings as a reranker or second pass**:
  - Query both systems, merge or rerank results by semantic similarity.
  - This prevents embedding errors (hallucinated relevance) from dominating recall.
  - Example: BM25 retrieves top 20 candidates; semantic scoring reranks them into top 8.

- **Keep the optional built-in LLM answer generation** (`createAnswerContext`):
  - It's protocol-agnostic: works with your chosen embedding/ranking backend.
  - Generate answers from whatever search results you return; the pipeline remains composable.

- **Maintain offline bundling**:
  - Ship docs + BM25 index inside npm packages (`node_modules/leadtype/AGENTS.md`).
  - Coding agents can search your docs without network calls.
  - Embeddings break this guarantee; static BM25 preserves it.

### Why embeddings alone are insufficient:

- **No justification for eliminating BM25** for doc search. Exact keyword matches are common and should be instant.
- **Vector databases add operational overhead** (hosting, sync, scaling) that's often unnecessary for docs.
- **Embeddings can hallucinate relevance** (e.g., returning a tangentially-related page with high semantic similarity but low utility).
- **Offline/bundled search breaks**: Embeddings require live model inference or precomputed vectors per doc—both incompatible with offline packages.

---

## Summary

| Aspect | BM25 (default) | Embeddings (if added) |
|--------|----------------|-----------------------|
| **Latency** | <10ms (client-side) | 100ms+ (network + API) |
| **Cost** | None (static file) | Hosting + API calls per query |
| **Offline capability** | ✅ Full support | ❌ Breaks unless vectors bundled |
| **Keyword matching** | Excellent | Mediocre (token-level) |
| **Semantic matching** | Poor | Excellent |
| **Fallback reliability** | Single source of truth | Requires careful degradation |

**Recommendation**: Ship BM25 by default. Add embeddings for hybrid search *only if* you observe users struggling with semantic queries that BM25 misses. Keep BM25 running in parallel; never replace it.
