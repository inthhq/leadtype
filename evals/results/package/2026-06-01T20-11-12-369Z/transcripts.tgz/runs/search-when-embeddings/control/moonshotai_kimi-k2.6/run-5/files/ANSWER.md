## 1. What leadtype's docs search uses by default

`leadtype generate` produces a **static, edge-safe JSON search index** (`search-index.json`, plus an optional `search-content.json`). There is no vector database, no embedding model, and no hosted retrieval service. The search runtime (`searchDocs`, `createSearchClient`, `useLeadtypeSearch`) loads these JSON artifacts and performs all ranking in-memory.

Default retrieval stack:

- **BM25** with tuned parameters (`k1 = 1.2`, `b = 0.75`).
- **Field-weighted term matching**: title hits count **4×**, heading hits **2×**, body hits **1×**, and code hits **0.35×**.
- **Lexical preprocessing**: NFKD normalization, diacritic stripping, lowercasing, stopword filtering, and a simple stemmer.
- **Query expansion**: exact tokens, built-in synonyms (e.g. `ai` ↔ `agent` / `llm`), prefix matches (up to 24 expansions), and typo tolerance via bounded edit distance (1 edit for 4–6-char tokens, 2 edits for 7+, capped at 16 expansions).
- **Phrase and proximity boosting**: ordered phrase matches get a **1.4×** boost; ordered proximity matches within an 8-token window get a **0.8×** boost.
- **Chunking**: documents are split into **~1,200-character chunks** with **~160-character overlap**, aligned to sentence or word boundaries and preserving heading hierarchy.
- **Source-grounded LLM answers**: `createAnswerContext` and the streaming adapters (e.g. `streamDocsAnswer`) use the top BM25 results to build a bounded, cited context prompt for an LLM—giving you RAG-style answers without embeddings.

The CLI also warns when the static artifacts grow past practical edge limits:
- index > **5 MB**
- total size > **10 MB**
- chunk count > **10,000**

## 2. When adding embeddings is actually warranted — and what to keep even then

A hosted, database-backed vector index is only warranted when you have outgrown the static-file constraints above **and** your query patterns are dominated by semantic gaps that BM25 cannot bridge. The specific conditions are:

1. **Scale limits** — the corpus is so large that the JSON index is impractical to ship to the edge or hydrate in the browser (i.e., you are hitting or exceeding the 5 MB / 10 MB / 10k-chunk guardrails even after scoping with `--include` / `--exclude`).
2. **Semantic mismatch** — users consistently query with concepts and paraphrases that share no keywords with the docs, and the built-in synonym/typo expansion is insufficient.
3. **Cross-lingual or deeply heterogeneous corpora** — queries and docs are in different languages or the vocabulary gap is too wide for lexical matching.

Even if you add embeddings, **keep**:

- **The BM25 index** as a fast, exact-match first stage or fallback. Hybrid search (BM25 + embeddings) outperforms pure semantic retrieval for keyword-heavy and API-reference queries.
- **The chunking pipeline** (title + description + heading path + sentence-aware chunks with overlap). These chunks are intentionally sized for LLM context windows and citation accuracy.
- **The source-grounded answer builder** (`createAnswerContext` / `streamDocsAnswer`). It already handles source limits (default 6 sources, 12,000 context chars), citation formatting, and safety prompts. You can feed vector-retrieved chunks into the same pipeline.
- **The static artifact model for the subset that fits**. Treat embeddings as an augmentation for overflow or semantic tail-cases, not a wholesale replacement of the edge-safe static index.

In short: leadtype already ships a complete, static RAG pipeline. Only add a hosted vector store when the static index is objectively too big for the edge **and** your users are failing on semantic recall. When you do, layer embeddings on top of the existing BM25 and chunking infrastructure rather than replacing it.
