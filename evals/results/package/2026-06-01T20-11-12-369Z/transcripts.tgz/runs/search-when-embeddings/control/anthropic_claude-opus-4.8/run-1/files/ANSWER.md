# What `leadtype` already gives us for docs search

Short version: before standing up a hosted, DB-backed vector index, know that
`leadtype` already ships a complete docs-search story that needs **no database,
no embedding model, and no hosted service**. For most docs sites it is enough on
its own, and even when embeddings are warranted you keep the leadtype index.

## 1. What leadtype's docs search uses by default

**A static, edge-safe BM25 lexical index — not vectors.**

When you run `leadtype generate`, it emits `public/docs/search-index.json`
(see the README "Add search" / "Build a static, edge-safe search index (BM25,
optional source-grounded answers)"). Confirmed in the installed package types
(`node_modules/leadtype/dist/...`):

- **Algorithm:** BM25 ranked retrieval. The React hook docs literally describe
  the debounce as the delay "between query updates and **BM25 execution**"
  (`search/react.d.ts`). BM25 needs only a term→postings map, no model.
- **Index shape (`DocsSearchIndex`):** an inverted index —
  `terms: Record<string, DocsSearchPosting[]>` — plus document and chunk tables
  and `averageChunkLength` (the BM25 length-normalization input). It is a plain
  JSON artifact, versioned (`SEARCH_INDEX_VERSION = 2`).
- **Field-weighted postings:** each `DocsSearchPosting` carries separate counts
  for `title`, `heading`, `body`, and `code`, so matches in titles/headings
  outrank incidental body hits.
- **Chunked content:** docs are split into overlapping chunks
  (`maxChunkChars: 1200`, `overlapChars: 160`) with heading paths and anchors,
  so results deep-link to the right section.
- **Where it runs:** the runtime (`leadtype/search`) is edge-safe and ships
  "state and routing primitives only." Search executes client-side / at the edge
  against the static JSON — there is no server query path, no database, and no
  per-query model inference. Defaults like `searchLimit: 8` and `maxQueryChars:
  400` come from `docsSearchDefaults`.
- **Built-in RAG-style answers, still lexical:** `createAnswerContext` /
  `streamDocsAnswer` (`leadtype/search/vercel`, `/tanstack`, `/cloudflare`)
  retrieve with the **same BM25 index**, then build cited, source-grounded
  context for an LLM (`maxSources: 6`, `maxContextChars: 12000`). So "answers"
  are already supported without any embedding store.

In other words, the thing the team is about to build (an index that powers
retrieval and grounded answers) substantially already exists — the only
difference is the retrieval method (BM25 vs. dense vectors), and BM25 is the
default precisely because it is cheap, deterministic, offline-buildable, and
requires no infrastructure.

## 2. When adding embeddings is actually warranted — and what to keep

Embeddings/a vector index are warranted **only** when you can point to a concrete
gap that BM25 cannot close, for example:

- **Semantic / synonym-heavy queries** where users phrase things differently
  from the docs and the vocabulary mismatch is real — *and* you've already tried
  leadtype's built-in `synonyms` option on `searchDocs` and it isn't enough.
- **Large or multilingual corpora** where keyword overlap is genuinely too sparse
  for lexical matching to rank well.
- **Conceptual "how do I…" questions** that don't share keywords with the
  relevant passage, where measured answer quality from the BM25-grounded
  `createAnswerContext` path is demonstrably insufficient.

The deciding factor should be **measured retrieval quality on real queries**, not
"that's how RAG is done." A hosted DB-backed vector index adds an embedding model,
an ingestion/refresh pipeline, a database, and a network query path — real cost
and operational surface that the current static index avoids.

**Even when embeddings are warranted, keep:**

- **The leadtype BM25 static index.** The strongest production pattern is
  **hybrid** retrieval — run BM25 and vectors and merge — because lexical search
  still wins on exact terms, code identifiers, API names, flags, and error
  strings (note leadtype indexes `code` as its own field). Don't replace it.
- **leadtype's chunking and document model** (`DocsSearchChunk`: heading paths,
  anchors, deep-link URLs, citations). Embed *these* chunks so vector hits map
  back to the same deep-linkable, citeable sources rather than inventing a
  parallel chunking scheme.
- **The build-time generation flow** (`generateDocsSearchFiles`, transformer
  hooks like `beforeSearchChunk`). Generate embeddings as an additional step over
  the chunks leadtype already produces, keeping a single source of truth.
- **The grounded-answer / citation layer** (`createAnswerContext`,
  `streamDocsAnswer`). Swap or augment the *retrieval* step with vectors, but keep
  the existing cited-context assembly and edge-safe runtime contract.

**Recommendation:** start with leadtype's default BM25 index (it's already built),
turn on `synonyms` and the grounded-answer adapter if you need Q&A, and only add a
vector layer if measured quality on real queries justifies it — and even then as a
hybrid that retains leadtype's index, chunking, and citation layer rather than a
rip-and-replace hosted vector DB.
