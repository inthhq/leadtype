# What leadtype Gives You for Docs Search

## 1. Default Search: BM25 + Lexical Ranking

By default, **leadtype uses BM25**, a battle-tested ranking algorithm from information retrieval. This is not a placeholder—it's a production-grade full-text search that ships as:

- **Static, edge-safe JSON index** (`search-index.json`) built at generation time
- **Zero runtime dependencies** — the search client runs in-memory on the edge or in the browser
- **Sophisticated term matching** including:
  - **Exact term matching** (highest weight: 1.0)
  - **Stemming** (e.g., "installing" → "install", weight: 0.82)
  - **Built-in synonym expansion** (e.g., "ai" expands to ["agent", "llm"], weight: 0.72)
  - **Prefix matching** for partial queries (weight: 0.55)
  - **Typo tolerance** via edit distance (weight: 0.45)
  - **Phrase boost** (1.4×) when query terms appear consecutively
  - **Proximity boost** (0.8×) when terms appear nearby

- **Context-aware ranking** with field-level weights:
  - **Title**: 4× weight (highest signal)
  - **Headings**: 2× weight
  - **Body text**: 1× weight (baseline)
  - **Code blocks**: 0.35× weight

- **Chunk-based retrieval** with automatic overlap:
  - Content split into ~1200-character chunks with 160-character overlap
  - Each chunk tracked with heading path, anchor, and metadata

**Result**: Queries like "how to install" find exact matches, stemmed variants, synonyms, and typos—all ranked by relevance without external APIs.

---

## 2. When Embeddings Are Actually Warranted

Add embeddings only when **lexical search fails** on your specific content. The decision tree:

### ✅ Keep leadtype's BM25 search if:
- Your docs contain **technical terminology** (APIs, functions, configuration options)
- Queries include **exact terms or variations** users would naturally type
- You have **working links and structure** that chunk well
- Your team **cannot afford** hosted vector infrastructure costs
- You **need offline-first or edge-deployable** search
- **Ranking quality** is acceptable for your users

### ⚠️ Consider supplementing or replacing with embeddings only if:
1. **Semantic queries dominate** — users ask natural-language questions like "How do I make my site faster?" where lexical tokens don't capture intent
2. **Dense text with loose terminology** — e.g., conceptual guides, user stories, or discussions where synonyms and stemming don't bridge the gap
3. **Cross-language or domain-divergent vocabulary** — users ask "authentication" but docs say "sign-up flows"
4. **You measure search failure** (bounce rate, feedback) and can prove embeddings help more than BM25 improvements

### ⚠️ If you add embeddings, **keep:**
- leadtype's **static index as a fallback** — hybrid search (BM25 + vector) outlasts vector-only
- leadtype's **chunk generation and metadata** — embeddings still need well-structured text and headings
- leadtype's **build-time generation** — avoid dynamic indexing unless you have no choice
- leadtype's **exact matching for literals** (API names, paths, version strings) — embeddings excel at concepts, not precise strings

---

## Summary

**Default:** BM25 is sophisticated, offline-capable, and production-ready. It handles synonyms, typos, stemming, and phrase matching out of the box.

**Embeddings:** Add them only when you've proven users' queries are fundamentally *semantic* (intent-based, not term-based) and BM25 leaves gaps. Hybrid (BM25 + vector) is safer than replacing BM25 entirely.

**Cost-benefit:** A database-backed vector index trades simplicity and deployability for semantic power you may not need. Validate the assumption first.
