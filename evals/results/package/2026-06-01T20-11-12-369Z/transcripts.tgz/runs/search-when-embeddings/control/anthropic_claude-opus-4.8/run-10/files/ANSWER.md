# Docs search in `leadtype` — what we already have

_Based on the installed package `leadtype@0.1.2` (`leadtype/search`, `leadtype/search/node`)._

## TL;DR

Before standing up a hosted, database-backed vector index, know this: `leadtype`
already ships a complete docs search system that needs **no server, no database,
and no embedding model**. It is lexical (BM25) over a static JSON index, runs at
the edge or in the browser, and is the right default for almost all docs sites.
Embeddings are a narrow, additive optimization — not a replacement — and only pay
off under specific conditions described below.

---

## 1. What leadtype's docs search uses by default

**A static, edge-safe BM25 keyword index — no embeddings, no vector store, no database.**

At build time, `generateDocsSearchFiles` (`leadtype/search/node`) flattens your
MDX docs and emits a plain JSON artifact (`search-index.json`, schema version 2).
Key characteristics, all confirmed in the package source:

- **Algorithm: BM25 (lexical / keyword ranking).** Tunable Okapi BM25 with
  `k1 = 1.2`, `b = 0.75`. Scoring is `IDF × normalized term frequency`, summed
  across query terms. No vectors, no cosine similarity, no neural model.
- **Field-weighted relevance.** Each chunk's terms are scored by where they
  appear: title (weight 4) > heading (2) > body (1) > code (0.35). Exact phrase
  and ordered-proximity matches get additional boosts (1.4× / 0.8×).
- **Chunked content.** Docs are split on headings into overlapping chunks
  (default `maxChunkChars = 1200`, `overlapChars = 160`), so results deep-link to
  the right section via heading anchors (`urlWithHash`).
- **Recall features that approximate "fuzzy"/semantic matching without a model:**
  - lightweight stemming (e.g. `installing` → `install`),
  - prefix matching (typeahead-style),
  - bounded typo tolerance via edit distance (Levenshtein, distance 1–2),
  - a built-in synonym table (`ai`↔`agent`↔`llm`, `config`↔`settings`, etc.),
    extendable via the `synonyms` option,
  - stopword filtering and Unicode/diacritic normalization.
- **Runs anywhere, statically.** The runtime (`searchDocs`) is dependency-free
  and edge-safe. It can run in the browser, in a serverless/edge function, or at
  the CLI. There is **no index server and no database to operate** — search is
  reading a JSON file.
- **Client/framework glue is included.** `leadtype/search/client`,
  `.../react`, `.../vue`, `.../svelte`, and `leadtype/next/client`
  (`useLeadtypeSearch`) provide query state/routing; framework adapters ship
  state primitives only (no rendered DOM).
- **Optional source-grounded answers (still no embeddings).** `createAnswerContext`
  runs the same BM25 search, then assembles the top chunks into a citation-ready
  context + system prompt for an LLM (streamed via `leadtype/search/vercel`,
  `.../tanstack`, or `.../cloudflare`). The retrieval step is keyword BM25; the
  LLM only summarizes/cites the retrieved documentation. The system prompt
  explicitly forbids inventing APIs and treats excerpts as untrusted text.
- **Built-in request hardening** for any hosted "ask" endpoint:
  `validateDocsQuery`, `readJsonWithLimit`, `createMemoryRateLimiter`,
  `getClientIdentifier`.

**In short:** out of the box you get production-grade keyword search with
typo/stem/synonym tolerance, section deep-links, optional LLM answers with
citations, and zero infrastructure. This is already a complete, "RAG-style"
retrieval pipeline — it just uses lexical retrieval instead of vectors.

---

## 2. When adding embeddings is actually warranted — and what to keep

A hosted, DB-backed vector index is **not** required to "do RAG" here; leadtype's
BM25 retrieval already supplies the retrieval half of RAG. Treat embeddings as an
optional, additive recall layer, justified **only** when you can point at a
concrete, measured failure of keyword search. Add embeddings only if **one or more**
of the following clearly holds:

1. **Vocabulary-mismatch queries dominate.** Users routinely search by *concept
   or paraphrase* using words that never appear in the docs (e.g. "make my page
   load faster" when the docs say "caching" / "ISR"), and the built-in
   synonym table + stemming + typo tolerance demonstrably don't bridge the gap.
   First try extending the `synonyms` option — it's cheaper than a vector store.
2. **The corpus is large and semantically diverse** enough that keyword recall
   measurably misses relevant sections (validate with real query logs / a
   relevance eval, not a hunch). Small-to-medium doc sets rarely qualify.
3. **You need cross-lingual or heavy natural-language Q&A** where the answer
   quality is bottlenecked by *retrieval recall*, and you have logs/evals proving
   BM25 is the limiting factor.
4. **You've already exhausted the free levers** above (synonyms, chunk size,
   field weights) and quantified that embeddings improve answer/result quality
   on your own queries.

If none of these are demonstrably true, the hosted vector DB is unjustified cost
and operational burden — keep the static index.

### What to keep even if you add embeddings

Do **not** rip out the existing pipeline. Layer embeddings *on top of* it as
hybrid retrieval:

- **Keep BM25 as the base / first-pass retriever.** It is fast, exact on
  identifiers (API names, flags, file paths, error strings) where embeddings are
  notoriously weak, needs no model at query time, and degrades gracefully.
  Hybrid search (BM25 + vectors, fused) consistently beats either alone.
- **Keep the static build artifact and chunking.** `generateDocsSearchFiles`,
  the heading-based chunks, anchors/deep-links, and the schema-versioned JSON
  remain your source of truth; embed the *same chunks* so citations and links
  still resolve.
- **Keep `createAnswerContext` and the grounding/citation prompt.** Embeddings
  only change *which* chunks are retrieved; the source-grounded, citation-first,
  "don't invent APIs" answer flow and its request hardening (query validation,
  body limits, rate limiting) should stay exactly as-is.
- **Keep the edge-safe / no-DB default path available** as a fallback so search
  still works without the vector service online.

### Recommendation

Ship leadtype's default BM25 search now. Instrument it, extend `synonyms` where
queries miss, and only introduce embeddings later as a *hybrid* layer if real
query data proves keyword recall is the bottleneck. Don't build the hosted vector
DB preemptively "because that's how RAG is done" — leadtype already does
source-grounded retrieval + answers without it.
