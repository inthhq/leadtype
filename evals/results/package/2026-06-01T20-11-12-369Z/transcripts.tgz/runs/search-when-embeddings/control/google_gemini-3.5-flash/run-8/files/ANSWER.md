# Leadtype Docs Search Architecture

Before building a hosted, database-backed vector index, it is important to understand the highly optimized search capabilities that `leadtype` already provides out of the box, as well as when an upgrade to vector embeddings is actually justified.

---

## 1. What Leadtype's Docs Search Uses by Default

By default, `leadtype` compiles and queries a **static, edge-safe, zero-dependency search index (`search-index.json`)** using a sophisticated client-side text-retrieval engine. The architecture features:

### A. Core Search Model: BM25
The engine implements an advanced version of **BM25 (Okapi BM25)**, the industry standard for keyword relevance ranking. It scores chunks using:
*   **BM25 Parameters**: Preconfigured with standard coefficients (`BM25_K1 = 1.2` for term frequency saturation and `BM25_B = 0.75` for document length normalization).
*   **Average Chunk Length**: Calculated across the entire index to normalize scores dynamically relative to chunk sizes.

### B. Preprocessing & Tokenization
*   **Unicode Normalization**: Normalizes inputs with `NFKD` Unicode normalization, strips diacritics, and forces lowercase conversion.
*   **Word Extraction**: Splits text using a global, multi-lingual, alphanumeric RegExp pattern (`/[\p{L}\p{N}]+/gu`).
*   **Stopword Filtering**: Strips out highly common, low-information words (e.g., *"a"*, *"an"*, *"and"*, *"are"*, *"the"*, *"how"*, *"what"*, etc.) from a built-in set to keep index size small and scoring focused.

### C. Advanced Query Expansion (Fuzzy & Semantic Match)
Unlike naive text searches, `leadtype`'s default search expands terms to cover variations without contacting any remote API:
*   **Built-in Suffix Stemmer**: Stems plurals and common verb conjugations (e.g., maps `ies` to `y`, and strips trailing `ing`, `ed`, `es`, `s`) to match search terms with different tenses or forms.
*   **Default & Custom Synonyms**: Automatically expands developer-centric terms to their synonyms (e.g., `ai` $\leftrightarrow$ `agent` / `llm`; `ts` $\leftrightarrow$ `typescript`; `auth` $\leftrightarrow$ `authentication` / `login`; `error` $\leftrightarrow$ `fail`). Custom synonyms are also fully supported.
*   **Prefix Matching**: Automatically matches prefixes for terms of length $\ge 4$ (up to 24 prefix expansions) to support autocomplete as-you-type.
*   **Fuzzy Typo Tolerance**: Uses a Levenshtein edit distance calculation (allowing a distance of up to `1` for words of length 4–6, and up to `2` for words of length $\ge 7$) to automatically correct and expand search terms sharing the same first letter (up to 16 typo expansions).

### D. Multi-Field Weighting & Match Boosting
*   **Hierarchical Field Weighting**: Scores documents based on where terms match. Default weights are:
    *   **Page Title**: `4.0`
    *   **Heading Path**: `2.0`
    *   **Body Content**: `1.0`
    *   **Code Blocks**: `0.35`
*   **Phrase Match Boost**: Applies a **`1.4x` boost** if the exact sequence of query tokens is found consecutively in the chunk.
*   **Proximity Match Boost**: Applies a **`0.8x` boost** if the query tokens appear in order within a sliding window of `8` tokens.

### E. Smart Chunking Strategy
During the `generate` phase, `leadtype` strips frontmatter and parses MDX/Markdown. It splits sections into overlapping chunks using a sliding window:
*   `maxChunkChars`: Defaults to `1200` characters.
*   `overlapChars`: Defaults to `160` characters.

### F. Out-of-the-Box RAG Integration
`leadtype` provides server and Edge primitives (such as `createAnswerContext`) that select the top relevant BM25-retrieved chunks and format them into a structured prompt/system context. It handles source attribution (citations) automatically, meaning you can wire up **source-grounded AI answering (RAG)** directly to Vercel AI SDK, Cloudflare Workers AI, or TanStack without needing any vector database.

---

## 2. When Are Embeddings Warranted, and What Should We Keep?

### When Adding Embeddings (Vector Search) is Actually Warranted
Moving beyond BM25 to a database-backed vector/embedding index is only warranted under specific conditions:

1.  **High Conceptual / Semantic Divergence**: When your users tend to query using completely different vocabularies or abstract questions (e.g., searching *"how to make API calls fast"* when the documentation strictly talks about *"latency reduction"*, *"edge caching"*, or *"CDN acceleration"*). Embeddings capture the underlying mathematical meaning of sentences.
2.  **Cross-Lingual Search**: If you serve a global user base and need searchers querying in Japanese or Spanish to find resources that are currently only written in English.
3.  **Conversational or Long-Form Narrative Queries**: When queries are long-form paragraphs, chat messages, or full stack traces that lack explicit high-quality keywords but contain deep contextual intent.
4.  **Complex Recommendation Features**: If your search UI includes highly dynamic features like *"related pages"* or recommendations based on behavioral user-history rather than literal text matches.

---

### What We Must Keep Even If We Use Embeddings

If you decide to adopt vector embeddings, **do not replace keyword search entirely**. Instead, implement a **Hybrid Search** pipeline (e.g., combining them via Reciprocal Rank Fusion - RRF). 

You **must keep BM25/keyword search** for the following critical reasons:

1.  **Exact Match Precision for Technical Terms**: Vector embeddings are notoriously poor at matching precise technical identifiers. If a developer searches for a specific function name (`createSearchClient`), configuration property (`maxContextChars`), error code (`ERR_1029`), or CLI flag, vector search might surface a conceptually "similar" page, whereas BM25 guarantees an exact match on the code token.
2.  **Zero-Shot Handling of New Terms & Acronyms**: Generic pre-trained embedding models cannot map new product names, internal custom libraries, or newly introduced terminology because they weren't in their training vocabulary. BM25 handles new terms instantly.
3.  **Ultra-Low Latency & Cost-Efficiency**: `leadtype`'s static index runs in milliseconds directly on the client browser or Edge handler with **zero network/database roundtrips** and **zero API costs**. Routing every single keystroke or simple search to an embedding model + vector DB is expensive, slow, and fragile.
4.  **Fully Offline Support**: BM25 search remains completely functional offline (e.g., inside the bundled `AGENTS.md` format consumed by local developer coding agents). Keeping the static index guarantees that offline users and IDE integrations still have high-performance search without internet connectivity.
