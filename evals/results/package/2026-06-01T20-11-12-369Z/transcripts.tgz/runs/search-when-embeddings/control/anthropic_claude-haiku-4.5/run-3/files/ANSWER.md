# What leadtype Already Gives Us for Docs Search

## 1. Default Search Implementation: BM25

**leadtype generates a static, edge-safe search index using BM25**, a battle-tested ranking algorithm from information retrieval. You get this by default with no additional configuration.

### How it Works

The BM25 implementation:
- **Tokenizes and normalizes** all content (diacritics, case, Unicode normalization)
- **Terms per field**: Documents are chunked into searchable pieces, and each term is indexed with counts for title, headings, body text, and code blocks separately
- **Field-aware scoring**: Title matches are weighted 4x, headings 2x, body 1x, and code 0.35x to prioritize where terms appear
- **Phrase and proximity matching**: Boosts scores when query terms appear in order or close together
- **Intelligent expansions**: Handles typos (edit distance ≤ 2), stemming (trailing -ing/-ed/-ies/-es/-s), synonyms, and prefix matching—without requiring vector embeddings
- **Chunk overlap**: Content is split into ~1,200-character chunks with 160 characters of overlap, so important content doesn't get lost at boundaries

### Search Index Artifacts

Running `npx leadtype generate` produces:

```
public/
├── docs/search-index.json      # BM25 index: terms, postings, metadata
└── docs/search-content.json    # Chunk content store (text of each chunk)
```

**Size**: The index itself is compact (terms and postings), and content is stored separately so you can optionally omit it.

### Query-Time Search

The client-side `searchDocs()` function:
1. Tokenizes the query
2. Expands it to related terms (stems, synonyms, typos, prefix matches)
3. Scores each chunk using BM25 formula with field weights
4. Returns ranked results with excerpts and score

**Configurable limits**: `maxQueryChars`, `searchLimit`, `maxChunkChars`, synonym injection.

---

## 2. When Embeddings Are Actually Warranted

Embeddings (vector similarity) are warranted **only if**:

1. **Your docs are dense with semantic synonymy**: You have concepts that use different vocabulary across pages, or many questions that don't share exact keywords with answers. Example: "How do I authenticate?" should match "Sign in with OAuth" even though the words don't overlap. BM25 handles many synonym cases out of the box, but embeddings excel when you need semantic matching at scale.

2. **You have moderate-to-high query volume**: The cost of embedding queries (API calls or model runs) becomes worth the improved coverage. If you have 1–100 searches per day, BM25 is cheaper and faster.

3. **Your current user experience shows a recall problem**: You're measuring that users find relevant docs less than 90% of the time because of keyword mismatch. Before adding embeddings, validate the problem exists.

4. **You can afford the operational complexity**: Hosting vector databases, managing embedding model updates, and handling versioning adds surface area. It's not free.

---

## 3. What to Keep Even When Adding Embeddings

**Do not replace BM25.** Even with embeddings, keep:

1. **The static BM25 index**: It's cheap to serve from a CDN, requires no backend, and handles exact-match and typo queries brilliantly. Use it as the first filter.

2. **Chunking strategy**: The 1,200-character chunk size with overlap works well. Don't re-chunk for embeddings alone; embed the same chunks.

3. **The full search-index.json and search-content.json**: These are your fallback. If your vector backend is down, BM25 still works.

4. **Field-weighted scoring**: Even if you add embeddings, keep title/heading/body weighting. A match in the title is more likely relevant than in code.

5. **The answer context builder**: The `createAnswerContext()` function already formats search results for LLM prompts, with proper citation formatting and character budgets. Reuse it.

### Suggested Hybrid Approach

If you decide embeddings are justified:

```
User Query
  ↓
BM25 search (fast, offline) → top 20 results
  ↓
Embed query + top 20 chunk embeddings (optional, if you want re-ranking)
  ↓
Deduplicate & re-rank by semantic similarity
  ↓
Take top 8 results → build answer context → serve to LLM
```

This way:
- You still get BM25's speed and edge-safety for most queries
- You add semantic re-ranking only when it adds value
- You don't force all users through an embedding API call

---

## Summary

- **Default**: Static BM25 index with field weighting, typo/stem/synonym/prefix expansion, phrase/proximity boosting
- **When to add embeddings**: Dense semantic content, high query volume, validated recall problem, operational capacity
- **What to keep**: BM25 index, chunking, field weights, answer formatter, and the option to fall back to BM25 offline
