# What leadtype already gives you for docs search (and RAG)

## 1. What leadtype uses by default

Leadtype does **not** need a database or a vector store for search. By default it builds a **static, edge-safe BM25 search index** that ships as ordinary JSON and runs entirely at the edge or in the browser.

### The index
- **Algorithm:** BM25 (K1 = 1.2, B = 0.75) over weighted fields:
  - Title (×4), heading (×2), body (×1), code (×0.35).
- **Tokenization:** NFKD-normalized, diacritic-stripped, stopword-filtered word tokens.
- **Stemming:** Simple suffix rules (`ies → y`, `ing → …`, `ed`, `es`, `s`).
- **Fuzzy recall layers:**
  - Exact-term matching
  - Stem matching
  - Built-in synonym expansion (e.g. `ai` ↔ `agent` ↔ `llm`, `search` ↔ `find` ↔ `lookup`, `ts` ↔ `typescript`, etc.)
  - Prefix expansion (up to 24 terms)
  - Typo tolerance via edit distance (up to 16 terms; distance 1 for tokens < 7 chars, distance 2 for longer tokens)
- **Ranking boosts:** phrase-match boost (1.4) and ordered-proximity boost (0.8) when query tokens appear close together.
- **Chunking:** documents are split into ~1,200-character chunks with 160-character overlap, flushed at sentence or word boundaries.
- **Output:** `search-index.json` (and optionally `search-content.json`) written at build time by `generateDocsSearchFiles`.

### Runtime search & RAG
- **`searchDocs(index, query)`** – runs the full BM25 + fuzzy + boost pipeline client-side or at the edge. Default limit: 8 results.
- **`createAnswerContext(index, query)`** – takes the top BM25 chunks, builds a citation-ranked context block, and returns a ready-to-send `system` prompt + `prompt` for an LLM. This is source-grounded RAG without embeddings.
- **Framework adapters** (`leadtype/search/vercel`, `leadtype/search/tanstack`, `leadtype/search/cloudflare`) stream those cited answers through the major AI SDKs.
- **Guards & limits:** query validation (`validateDocsQuery`), rate limiting (`createMemoryRateLimiter`), and size caps (max query 400 chars for search, 600 for ask; max body 16 KB; max context 12,000 chars; max sources 6).

### Build-time safety valves
`generateDocsSearchFiles` warns you when the static artifacts get heavy:
- Index > **5 MB**
- Total output > **10 MB**
- Chunk count > **10,000**

These thresholds are the library’s own signal that the “static JSON” model is still viable. If you stay below them, you get fast, zero-inference-cost search and RAG out of the box.

---

## 2. When adding embeddings is actually warranted — and what to keep

### Conditions that justify embeddings
1. **Corpus size exceeds the static JSON sweet spot.**
   If your docs blow past the ~5 MB index / ~10 MB total / ~10k chunk warnings, shipping the entire index to every edge node or browser becomes impractical. A hosted index (vector or otherwise) can make sense at that scale.
2. **Predominantly semantic, natural-language queries.**
   BM25 is lexical. If your users ask conceptual questions that paraphrase the docs without overlapping keywords (e.g., “How do I let users sign in?” when the docs only say “authentication” and “login”), dense retrieval can bridge the vocabulary gap.
3. **Cross-lingual or deeply synonym-rich domains.**
   If the built-in synonym list and stemming are insufficient for your domain jargon or multilingual content, learned representations can generalize where hand-curated rules cannot.

### What you should keep even then
- **The BM25 index and content store.**
  BM25 is faster, cheaper, and better at exact matches (API names, CLI flags, error codes) and typo-tolerant prefix search. The best pattern is **hybrid retrieval**: BM25 for fast, high-recall candidate generation, plus embeddings for semantic re-ranking or augmentation.
- **The chunking pipeline (`DocsSearchIndex` / `DocsSearchContentStore`).**
  Leadtype already produces clean, citation-ready text segments with anchors and heading paths. Whether you retrieve chunks via BM25, a vector DB, or both, the chunk format and content store are what feed the answer pipeline.
- **`createAnswerContext` and the streaming adapters.**
  These functions already wire retrieval → cited sources → LLM prompt. Even if you swap in a vector DB for the retrieval stage, the surrounding RAG plumbing (citation formatting, system prompt, source limits, request guards) remains the same.
- **Query validation and rate limiting.**
  `validateDocsQuery` and `createMemoryRateLimiter` protect your endpoint regardless of whether the backing store is a JSON file or a hosted vector index.

### Bottom line
Leadtype already gives you a full RAG pipeline. You do not need embeddings “because that’s how RAG is done.” You only need them when the static BM25 index hits scaling limits or when your query traffic is so semantic that lexical matching alone is insufficient. If you do add them, treat embeddings as an **augmentation** to the existing static index, not a replacement.
