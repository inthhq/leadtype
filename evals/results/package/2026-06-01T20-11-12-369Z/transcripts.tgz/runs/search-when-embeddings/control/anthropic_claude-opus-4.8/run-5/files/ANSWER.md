# Docs search in `leadtype` — what we already have, and whether we need embeddings

_Based on `leadtype@0.1.2` as installed in `node_modules/leadtype` (README + `leadtype/search` runtime in `dist/_shared/search-*.js`)._

## TL;DR

`leadtype` already ships a complete docs search engine: a **static, edge-safe BM25
lexical index** generated at build time, plus an **optional source-grounded "answer"
mode** that feeds your own LLM the retrieved chunks. There is **no vector store, no
embeddings, and no database anywhere in the package** — and for typical docs search
that is a feature, not a gap. Stand up a hosted vector index only if you hit specific
limits below, and even then keep the BM25 index as the retrieval (or rerank) base.

---

## 1. What leadtype's docs search uses by default

### It's lexical BM25, not vectors

`leadtype generate` emits a `search-index.json` (and optional content file) from your
MDX/markdown. Querying it (`searchDocs` in `leadtype/search`) is **classic BM25 ranking
over an inverted index** — pure term matching, no embeddings:

- **BM25 scoring** with `k1 = 1.2`, `b = 0.75` (standard term-frequency saturation +
  document-length normalization).
- **Field weighting** so structure matters: title ×4, heading ×2, body ×1, code ×0.35.
- **Phrase / proximity boosts**: exact phrase match ×1.4; ordered proximity within an
  8-token window ×0.8.

### It's "smarter than plain keyword" without needing a model

The query pipeline does a lot of the work people *think* they need embeddings for, all
deterministically and offline:

- **Tokenization + stopword removal + diacritic/case normalization** (NFKD).
- **Light stemming** (e.g. `ies→y`, `ing`, `ed`, `es`, `s`) with a stem-match weight (0.82).
- **Synonym expansion** from a built-in table (e.g. `install↔setup↔add`,
  `config↔configure↔settings`, `ai↔agent↔llm`, `ts↔typescript`) — extensible via the
  `synonyms` option (0.72).
- **Prefix matching** for autocomplete-style queries (0.55).
- **Typo tolerance** via bounded edit distance (1 edit for short tokens, 2 for length ≥7) (0.45).

### It's chunked, anchored, and citable

- Content is split into ~**1200-char chunks with ~160-char overlap**, tracking the
  heading path so results link to the right `#anchor`.
- Results carry title, heading path, absolute URL with hash, excerpt, and score.

### "Answers" are source-grounded retrieval, still no embeddings

`createAnswerContext` (and the `leadtype/search/{vercel,tanstack,cloudflare}` adapters)
runs the **same BM25 search**, takes the top chunks (default `maxSources = 6`,
`maxContextChars = 12000`), and assembles a cited prompt for **your** LLM. The built-in
system prompt enforces: use only provided context, cite with `[1]`/`[2]`, treat docs as
untrusted reference text, and don't invent APIs. The retrieval layer itself is lexical.

> Note: the build flag `embedContent` means "inline the chunk **text** into the index
> JSON," **not** vector embeddings. The package has no embedding generation at all.

### Why this default is the right starting point

- **Edge-safe & zero-infra**: a static JSON file served from a CDN — no database, no
  vector store, no inference endpoint, no per-query model cost or latency.
- **Versioned with your docs**: the index is built from the same source, so it can't
  drift or go stale relative to the content.
- **Deterministic & debuggable**: scores are explainable; no opaque nearest-neighbor
  behavior or embedding-model/version skew.

---

## 2. When adding embeddings is actually warranted — and what to keep

BM25 wins on exact terms, code identifiers, flags, error strings, and product names —
exactly the queries docs/RAG-for-docs users actually type. Embeddings help only with
**semantic/paraphrase recall**, and that's worth real infrastructure only if you can
point to concrete evidence, not "that's how RAG is done."

### Add embeddings only if **all** of these hold

1. **Measured lexical miss rate.** You have query logs / an eval set showing BM25 is
   genuinely failing on conceptual or paraphrased queries ("how do I make my site
   multilingual?" → docs say "i18n / locale"), and that the built-in
   synonym/stem/typo/prefix expansion (and a tuned custom `synonyms` table) doesn't
   already cover it. Tune synonyms first — it's free.
2. **Vocabulary mismatch is the real problem.** Users describe concepts in words that
   never appear in the docs, so term overlap can't reach them. (If queries *do* share
   terms with the docs, embeddings add cost without moving recall.)
3. **Scale/quality justifies the cost.** The corpus and traffic are large enough that
   the recall gain outweighs the new operational burden: an embedding model + a vector
   DB, re-embedding on every docs change, model-version pinning, query-time inference
   latency/cost, and loss of edge-only/offline simplicity. For a typical docs set,
   that's a poor trade.

### Even then, keep these

- **Keep the BM25 index.** Don't replace it — run **hybrid retrieval**: lexical for
  exact terms/identifiers/flags/errors, vectors for semantic recall, then fuse/rerank.
  Pure vector search is notoriously bad at exact symbol/keyword matches, which dominate
  developer-docs queries.
- **Keep the build-time, source-versioned pipeline.** Generate embeddings from the same
  flattened markdown chunks leadtype already produces (consistent chunking, heading
  paths, anchors, URLs) so vectors stay version-matched to the docs and can't drift.
- **Keep `createAnswerContext`'s grounding contract.** Continue assembling cited,
  source-grounded prompts with the "only use provided context / cite sources / don't
  invent APIs" guardrails. Embeddings change *retrieval*; they should not change the
  citation and anti-hallucination discipline.
- **Keep the option to stay static/edge.** Only move to a hosted, DB-backed service if
  the corpus genuinely outgrows a static index. Reach for managed infra last, not first.

### Bottom line

Don't build the hosted vector index yet. Start from leadtype's built-in BM25 + answer
mode, tune the synonym table, and instrument query logs. Add a hybrid embedding layer
only when measurements prove a semantic recall gap — and keep BM25 and the source-
grounded, version-matched pipeline even after you do.
