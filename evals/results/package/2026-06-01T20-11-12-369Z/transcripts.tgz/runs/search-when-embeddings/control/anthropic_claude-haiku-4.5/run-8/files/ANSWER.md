# What leadtype Gives You for Docs Search

## By Default: BM25 Full-Text Search

`leadtype` generates a **static, edge-safe search index** using **BM25** (a proven relevance ranking algorithm) with zero dependencies at query time. It is not a vector/embedding-based search.

### How It Works

1. **Index Generation** (`generateDocsSearchFiles`)
   - Extracts structured text from markdown: title, headings, body, and code blocks
   - Chunks content at ~1200 characters with 160-character overlap to preserve context
   - Tokenizes text (removes stopwords, applies stemming)
   - Builds inverted index with per-document and per-chunk term postings

2. **Query Scoring**
   - Uses BM25 with tuned constants (K1=1.2, B=0.75)
   - Weights content sections: **Title (4×) > Heading (2×) > Body (1×) > Code (0.35×)**
   - Applies intelligent term matching:
     - **Exact** (weight 1.0) — exact token match
     - **Stem** (0.82) — morphological (install/installed)
     - **Synonym** (0.72) — config→settings, search→find, etc.
     - **Prefix** (0.55) — for token.startsWith(query)
     - **Typo** (0.45) — 1–2 edits away (spell tolerance)
   - Boosts results with **phrase matching** (+40%) or **proximity matching** (+80%)

3. **Output**
   - `search-index.json` — the BM25 index (compressed, typically KB–MB)
   - `search-content.json` (optional) — separate chunk text storage
   - Can be served from a CDN; clients load via `createSearchClient()`

## When Embeddings Are Actually Warranted

### The Gap BM25 Has
- **Semantic mismatch**: User searches for "how do I authenticate?" but docs use the word "login" → BM25 handles this *partially* via synonyms, but misses synonyms not in the hardcoded map
- **Concept drift**: Queries about related-but-differently-worded topics (e.g., "token-based auth" vs. "JWT patterns") may score lower if exact terms don't align
- **Negation and intent**: Queries like "what NOT to do" don't map to BM25 term frequency

### When to Add Vector Embeddings

**Only if you observe real search failures:**
1. Run a **search quality audit**: Log user queries and their results. Measure click-through or satisfaction.
2. Identify gaps: Are users not finding relevant docs? Are the results semantically wrong (not just syntactically)?
3. If yes: Add embeddings alongside BM25, **do not replace it**.

**Why keep BM25 even then?**
- **Exact term match is irreplaceable**: User searches for "404 error" → BM25 gives the right page instantly; embeddings may hallucinate.
- **Cost and latency**: BM25 is free at query time (edge-safe, runs in browser or worker). Embeddings require a vector DB (Pinecone, Weaviate, etc.) or LLM API, adding latency and cost.
- **Observability**: BM25 term weights are transparent; you can debug why a page ranked #3. Embeddings are a black box.
- **Durability**: Your docs version-match the index. A vector DB is external state that can desync or be unavailable.

### Recommended Hybrid Approach
```
1. Search with BM25 (local, instant, exact matches)
2. Rerank top-K results with semantic similarity (if latency budget allows)
3. Only persist embeddings if step 2 measurably improves user outcomes
```

Leadtype already gives you step 1 out of the box. Step 2 is optional and should be data-driven, not assumed necessary.

---

## Summary for Your Team

**Current state:** You have a production-grade search tool. BM25 + intelligent tokenization + stored synonyms will handle ~95% of docs search queries well.

**Before building a hosted vector index:**
- Ship BM25 search, measure real user query success
- If search is genuinely failing (not hypothetically), then add embeddings
- Keep BM25 as the primary path; embeddings as a reranker

This avoids premature infrastructure complexity and database operational burden.
