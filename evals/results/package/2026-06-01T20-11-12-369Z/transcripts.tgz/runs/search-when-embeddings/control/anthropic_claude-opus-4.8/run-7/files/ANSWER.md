# Docs search with `leadtype`: do we need a hosted vector DB?

Short version: **not to start, and probably not at all for most docs sets.** `leadtype`
already ships a complete docs-search stack that runs without a database, without
embeddings, and without a server. Stand that up first; only reach for vectors under
specific, measurable conditions — and even then, keep the lexical index.

## 1. What leadtype's docs search uses by default

leadtype's `leadtype generate` command builds a **static, edge-safe lexical search
index** (`public/docs/search-index.json`). The retrieval algorithm is **BM25**, a
classic keyword/term-frequency ranking — **not** embeddings, **not** a vector index,
and **not** a database. There is no embedding, vector, cosine-similarity, or
vector-store code anywhere in the package; "RAG via a hosted vector DB" is not what
leadtype does or needs.

Concretely, the default index (built by `createDocsSearchIndex`, queried by
`searchDocs` from `leadtype/search`) does the following:

- **BM25 scoring** with the standard saturation/length-normalization parameters
  (`k1 = 1.2`, `b = 0.75`) over chunked markdown.
- **Field weighting** so matches count for more in important places:
  title ×4, heading ×2, body ×1, code ×0.35.
- **Query expansion that recovers most of what people expect from "semantic" search**,
  without any model:
  - lightweight **stemming** (`installing` → `install`),
  - a built-in **synonym** table (e.g. `search`↔`find`, `config`↔`configuration`,
    `ai`↔`agent`↔`llm`) that you can extend via the `synonyms` option,
  - **prefix** expansion (autocomplete-style),
  - **typo tolerance** via bounded edit distance,
  - **phrase** and **ordered-proximity** boosts so multi-word queries rank tighter
    matches higher.
- **Heading-aware chunking** with overlap, so results deep-link to the right section
  anchor (`url#heading`).
- **Stopword removal** and Unicode/diacritic normalization.

Because the index is a single static JSON artifact:

- It is **edge-safe and serverless** — the runtime (`leadtype/search`, plus framework
  adapters like `leadtype/next`, `leadtype/search/react`) runs in the browser, on the
  edge, or in a worker. **No database, no separate search service, no network round
  trip to a vector store.**
- It is **version-matched and offline-capable** — the index ships with the docs build.
- It is essentially **free to operate** (static hosting / CDN) and has no per-query
  inference cost.

leadtype also offers **optional source-grounded answers** (`createAnswerContext` plus
the `leadtype/search/vercel`, `.../tanstack`, `.../cloudflare` adapters). This is the
"RAG" piece — but note the retrieval step is **the same BM25 index**. It selects the
top chunks, attaches them as cited context, and hands them to an LLM with a strict
"use only the provided context, cite sources, don't invent APIs" system prompt. You get
grounded, cited answers **without** introducing a vector database.

## 2. When adding embeddings is actually warranted (and what to keep)

Embeddings/vector search are a tool for **semantic recall** — finding the right doc when
the user's words don't overlap with the doc's words. They are warranted only when you
have **evidence** that lexical retrieval is the bottleneck. Adopt them when **all** of
these hold:

1. **You've measured a real recall gap.** You have query logs / an eval set showing
   users repeatedly fail to find content that exists, specifically because of
   **vocabulary mismatch** (paraphrases, synonyms, conceptual questions) that survives
   even after extending leadtype's `synonyms` table and tuning chunking. Don't add
   vectors on vibes — quantify the miss rate first.
2. **The corpus is large and/or conceptual**, not a tight, well-keyworded product-docs
   set. BM25 with synonyms handles the latter very well; embeddings pay off on big,
   prose-heavy, or cross-domain corpora.
3. **The benefit clears the new cost/complexity**, which is real: an embedding model
   (build-time + query-time inference), a vector store to host and operate, freshness/
   re-embedding on every docs change, and version-skew risk between code and index —
   all of which the current static index avoids.

**Even then, keep the lexical index — do hybrid retrieval, not a vector-only swap:**

- **Keep leadtype's BM25 index as the lexical half of a hybrid retriever.** Lexical
  search still wins decisively on exact terms: API names, flags, error strings, code
  identifiers, version numbers. Vectors are notoriously weak there; BM25 is exactly
  right. Fuse the two (e.g. reciprocal-rank fusion) rather than replacing one.
- **Keep the static, edge-safe artifact and its zero-DB deployment for as long as
  possible.** If you add vectors, scope them to the narrow set of queries that
  demonstrably need them, and treat the vector store as an *augmentation*, not the
  system of record.
- **Keep leadtype's answer/grounding layer** (`createAnswerContext` and its adapters):
  the citation discipline, untrusted-context handling, and "don't invent APIs" prompt
  are independent of how chunks are retrieved. Swap or extend the *retriever* feeding
  it; don't rebuild the answer pipeline.

### Recommendation

Ship leadtype's built-in BM25 search (and, if you want answers, its source-grounded
answer adapters) now. It requires **no hosted database and no embeddings**. Instrument
search quality, extend the synonym list, and only invest in a vector index if/when the
logs prove a semantic-recall gap that lexical tuning can't close — and add it as a
hybrid layer beside the existing index, never as a wholesale replacement.
