# Leadtype Docs Search & Embeddings Strategy

## 1. What Leadtype's Docs Search Uses by Default

By default, `leadtype` implements a **static, edge-safe search index** generated at build-time. It requires **no external database or server-side database infrastructure**. It can be queried entirely in-browser (client-side) or at the edge.

### Core Architecture & Content Processing:
- **Build-Time Generation:** During the build process, `leadtype` parses the documentation files, extracts metadata (titles, descriptions, headings, paths), cleans markdown (stripping formatting tags, links, and inline wrappers), and outputs a highly compressed `search-index.json`.
- **Text Normalization:**
  - Converts all characters to lowercase.
  - Normalizes unicode characters (NFKD) and strips diacritics.
- **Smart Chunking (`splitWithOverlap`):** It splits files into logically overlapping chunks to maintain local context. By default, it chunks text using `maxChunkChars = 1200` and an overlap of `overlapChars = 160`, making sure to split at sentence boundaries (`. `) or spaces where possible.
- **Tokenization & Stopword Filtering:** Tokenizes content on word boundaries, filters out common stopwords (e.g., *a, an, and, use, how, what*), and utilizes a custom lightweight stemmer (`stemToken`) to handle pluralization and common suffixes (like `-ing`, `-ed`, `-es`, `-ies`, `-s`).

### Custom BM25 Retrieval Engine:
At query time, `leadtype` runs a highly optimized **BM25 (Best Matching 25)** ranking algorithm directly on the static index:
- **Field Weighting:** It assigns different weights depending on where the match is found in the document chunk:
  - **Title:** `4.0x`
  - **Heading:** `2.0x`
  - **Body text:** `1.0x`
  - **Code blocks:** `0.35x`
- **BM25 Parameters:** Configured with robust defaults: `k1 = 1.2` (term frequency saturation) and `b = 0.75` (document length normalization).
- **Query Expansion Mechanisms:**
  - **Synonyms:** Translates common abbreviations/synonyms (e.g., `ai` &harr; `['agent', 'llm']`, `cli` &harr; `['command', 'terminal']`, `ts` &harr; `['typescript']`) using a built-in synonym dictionary.
  - **Prefix Matching:** Automatically expands query prefix terms up to 24 variations to support partial word search.
  - **Typo Tolerance:** Uses Levenshtein edit distance to match spelling errors (up to distance 1 for 4–6 character words, and distance 2 for words with &ge; 7 characters; capped at 16 expansions).
- **Match Boosting:**
  - **Exact Phrase Boost:** `1.4x` boost if query terms appear in exact sequence.
  - **Proximity Boost:** `0.8x` boost if query terms appear close to each other within a sliding window of 8 tokens (`PROXIMITY_WINDOW`).

### Native RAG Capabilities:
Without a vector database, `leadtype` provides built-in support for source-grounded answering (RAG) through `createAnswerContext`. This function retrieves the best BM25 chunks, builds an optimized LLM system prompt (managing token allocation up to `12,000` context characters by default), and formats cited sources with standard bracket references (`[1]`, `[2]`).

---

## 2. When Embeddings are Warranted (and What to Keep)

Deploying a hosted, database-backed vector search engine (Dense Retrieval / Embeddings) is **only warranted under specific conditions**. It should not be the starting point.

### Conditions Warranting Vector Embeddings:
1. **Conceptual & Semantic Understanding:** When users query with abstract concepts, goals, or phrasing that shares *zero* keywords or synonyms with the text in the docs (e.g., querying *"how do I prevent my app from dragging?"* when the documentation only refers to *"performance scaling"* and *"lazy-loading"*).
2. **Multi-Lingual / Cross-Lingual Queries:** When documentation is written in English, but users query in Spanish, Japanese, or other languages. Multi-lingual embeddings map semantic meaning across languages automatically.
3. **Conversational, Broad QA Queries:** When powering an AI chat assistant that must synthesize answers from disparate themes across thousands of documents, where keyword overlap is minimal but conceptual similarity is high.
4. **Massive Document Corpuses (&gt;100k pages):** If your documentation size causes the static BM25 JSON index file to grow so large that sending it to the client's browser degrades page-load performance.

---

### What to Keep Even If You Add Embeddings (The Hybrid Approach)

If you decide vector embeddings are warranted, **you must keep the BM25/Keyword search index and combine them using a Hybrid Search strategy** (e.g., using Reciprocal Rank Fusion / RRF). 

**Never throw away BM25 keyword search in developer documentation for the following reasons:**

1. **Exact API and Code Matches:** Vector models struggle with exact matches for highly specific technical terms, API names, function signatures, error codes, CLI flags, or package imports (e.g., `BM25_K1`, `createDocsSearchIndex`, or `--out`). Embeddings often cluster these to similar-looking but incorrect pages. BM25 guarantees that exact variable/method name matches rank first.
2. **Zero-Latency UI / Typing Feedback:** BM25 can run client-side instantly on keypress. Generating embeddings requires an API network call to a model (like OpenAI) and a query to an external vector database, which is too slow for instant "as-you-type" search bar suggestions.
3. **Zero Maintenance & Synchronization Overhead:** A static BM25 index is automatically built with your site build. Maintaining a vector database requires running complex data pipelines, chunking, generating embeddings, indexing, paying database hosting fees, handling deleted page syncs, and managing index migrations.
4. **Best-of-Both-Worlds Ranking:** True state-of-the-art retrieval (Hybrid Search) scores results by summing or merging the normalized rank from both dense retrieval (embeddings, which capture semantic intent) and sparse retrieval (BM25 keyword matches, which capture precise vocabulary).
