# Documentation Search with `leadtype`

Before building a hosted, database-backed vector database for search (RAG), here is a breakdown of what `leadtype` already provides out-of-the-box and when a vector-based embedding index is actually warranted.

---

## 1. What `leadtype` Uses by Default

By default, `leadtype` does **not** require any database, hosted server, or external API service. Instead, it generates a **static, edge-safe, high-performance search engine** at build-time. 

Here is exactly how it works under the hood:

### A. Document Chunking & Parsing
* **Section-Based Splitting**: It parses your MDX/Markdown pages and divides them into logical blocks based on document headers (`#` to `######`) and code fences.
* **Overlapping Chunks**: Text within each section is split into overlapping chunks (default `maxChunkChars: 1200`, `overlapChars: 160`) using `splitWithOverlap`. This ensures query terms located near chunk boundaries are not lost.
* **Metadata Extraction**: Each chunk retains critical metadata like the full heading path (e.g., `Installation > Getting Started`), URL paths, relative paths, locales, and generated anchors.

### B. Probabilistic Text Matching (BM25)
At query time, `leadtype` executes search queries against this index using a highly optimized, custom implementation of the **BM25 (Best Matching 25)** algorithm—the gold standard for keyword-based search. 

Its search pipeline includes:
* **Linguistic Preprocessing**:
  * **Normalization**: Diacritic/accent removal and folding to lowercase.
  * **Tokenization**: Parsing string inputs into valid word tokens.
  * **Stopword Filtering**: Filtering out common English filler words (e.g., `the`, `is`, `with`).
  * **Stemming**: Custom suffix-stripping for English pluralization and tense variations (e.g., mapping `-ies` $\rightarrow$ `-y`, `-ing` $\rightarrow$ root, `-ed` $\rightarrow$ root).
* **Multi-Field Weighting**: It prioritizes hits in critical sections of the document over standard body text:
  * `TITLE_WEIGHT = 4` (Document titles)
  * `HEADING_WEIGHT = 2` (Subheadings)
  * `BODY_WEIGHT = 1` (Body copy and descriptions)
  * `CODE_WEIGHT = 0.35` (Code snippets)
* **Flexible Term Matching Weights**:
  * **Exact Match**: `1.0`
  * **Stemmed Match**: `0.82` (matches variations of words)
  * **Synonym Match**: `0.72` (uses customizable synonym maps; includes built-in defaults like `ai` $\leftrightarrow$ `agent`/`llm`, `auth` $\leftrightarrow$ `authentication`, `ts` $\leftrightarrow$ `typescript`)
  * **Prefix Match**: `0.55` (for partial word typing, up to 24 prefix expansions)
  * **Typo/Fuzzy Match**: `0.45` (utilizes edit-distance/Levenshtein matching, up to 16 expansions for words $\ge 4$ characters)
* **Match Boosting**:
  * **Phrase Match Boost (`1.4` multiplier)**: Applied if query tokens appear exactly in sequence.
  * **Proximity Match Boost (`0.8` multiplier)**: Applied if query tokens appear near each other (within an 8-word window) in the correct relative order.

### C. Native RAG Support
If you want to feed your search results into an LLM for conversational answers, `leadtype` includes a helper called `createAnswerContext()`. It:
1. Runs the BM25 search to locate the most relevant document chunks.
2. Extracts and concatenates these chunks into a citation-mapped reference block.
3. Automatically constructs a system instruction template and prompt with numbered source citations and strict constraints (e.g., "Do not invent APIs, options, behavior...").
4. Integrates seamlessly with edge-friendly runtimes (e.g., Vercel AI SDK, Cloudflare Workers AI, and TanStack AI).

---

## 2. When Are Embeddings/Vector Search Warranted?

While `leadtype`'s local BM25 search is incredibly powerful, extremely fast, and completely free, certain scenarios can benefit from adding vector embeddings.

### A. Specific Conditions Where Embeddings are Warranted
1. **High Semantic Gap / Conceptual Queries**: When users search using completely different vocabulary than your documentation authors used (e.g., searching for *"how to secure my API"* when the documentation strictly uses the terms *"TLS certificates"*, *"JSON Web Tokens"*, or *"authentication hooks"*).
2. **Multi-lingual / Cross-lingual Retrieval**: When your documentation is written in English, but users query in Spanish, Japanese, or French. Semantic multi-lingual embeddings (like Cohere or OpenAI's text-embedding-3) allow cross-language matching without translating documents first.
3. **Conversational, Long-form, or Highly Informal Inputs**: When users copy-paste long conversational requests, general problem descriptions, or raw error logs into a search bar. Dense embeddings excel at finding overall contextual similarity where keyword overlap is very low.

### B. What We Should Keep (Even if We Add Embeddings)
If you decide to adopt vector search, **you should not discard your keyword search**. A pure vector-based search is notorious for failing on standard developer docs queries. 

Even with a hosted vector database, we should keep the following:

1. **BM25 Keyword Indexing (for Hybrid Search)**:
   * **The Problem**: Developers search using exact identifiers, such as API endpoints (e.g., `/v1/auth`), function names (e.g., `defineDocsConfig`), CLI flags (e.g., `--bundle`), configuration keys, and error codes. Vector embeddings compress text into dense semantic spaces and often fail to distinguish between highly specific technical terms or exact alphanumeric strings.
   * **The Solution**: Maintain a **Hybrid Search** strategy. Combine the dense retrieval score from your vector database with the sparse keyword score from `leadtype`'s BM25 search index using **Reciprocal Rank Fusion (RRF)**.
2. **`leadtype`'s Chunking, Normalization, and Synonym Logic**:
   * Instead of using a generic, naive character-count splitter, keep using `leadtype`'s section-aware splitter (`splitWithOverlap`) to generate the text chunks for your embedding model. This ensures chunks preserve heading hierarchies and code block integrity, producing higher-quality embeddings.
3. **Edge-Safe Client Search Fallbacks**:
   * Keep the static local search index as a zero-latency fallback layer. Users get immediate, offline-ready auto-completion and search results as they type, without triggering costly, network-bound vector search database queries for simple queries.
