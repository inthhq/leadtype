# Leadtype docs search and when embeddings are worth adding

## What Leadtype uses by default

Leadtype already ships a database-free docs search stack. By default, `leadtype generate` produces static docs artifacts, including a JSON search index under the generated `docs` output, and the runtime queries that artifact with Leadtype's local/edge-safe search code.

That default search is **lexical BM25**, not a hosted vector database and not embeddings. The indexer:

- reads the generated markdown docs;
- splits content into section-based chunks, with default chunking of about 1,200 characters and 160 characters of overlap;
- tokenizes and normalizes text, removes common stopwords, and indexes terms;
- scores with BM25 using different weights for title, heading, body, and code text;
- expands query matching with built-in synonyms, stemming, prefix matching, typo tolerance, and phrase/proximity boosts;
- returns source-bearing results with URLs, headings, excerpts, and scores.

Leadtype also provides source-grounded answer helpers (`createAnswerContext` and AI streaming adapters) that use those search results as cited documentation context. In other words: Leadtype already gives us the retrieval and citation substrate for RAG without requiring a database-backed vector index.

## When embeddings are actually warranted

Add embeddings only if we can demonstrate that the default Leadtype BM25 search is missing important docs queries that are genuinely semantic rather than lexical. The practical bar should be:

1. We have real query logs or a representative golden test set.
2. The failures are important user journeys, not edge cases.
3. The right docs do not share useful words with the user's phrasing, synonyms, API names, error text, commands, or headings.
4. Leadtype tuning has been tried first: better titles/headings, clearer terminology in docs, custom synonyms, chunking options, and search result evaluation.
5. The corpus and product needs justify the extra operational cost: embedding generation, re-indexing on doc changes, hosted storage, versioning, monitoring, latency, privacy/security review, and fallback behavior.

Embeddings are most defensible for broad conceptual or paraphrased questions where users ask for an idea and the docs explain it with different language. They are much less compelling for docs search dominated by exact identifiers: API names, CLI flags, package names, error messages, config keys, route paths, code snippets, and version-specific behavior. BM25 is usually better for those.

Even if we add embeddings, we should **keep Leadtype's default search artifacts and BM25 retrieval**. Use embeddings as a hybrid layer or reranker, not as a replacement. Keep BM25 for exact-match precision and fallback; keep Leadtype's generated markdown/source chunks as the canonical context; keep the cited source URLs/headings/excerpts; and keep the source-grounded answer behavior that says when the context is insufficient instead of inventing answers.
