# Leadtype docs search vs. a hosted vector index

## What leadtype uses by default

Leadtype already ships a docs-search pipeline. By default it does **not** require a hosted database, vector store, or embeddings.

Its generated docs search is a **static, edge-safe lexical index**:

- `leadtype generate` writes JSON search artifacts for the generated markdown docs, normally `docs/search-index.json` plus `docs/search-content.json`.
- The runtime loads those artifacts and searches them with **BM25**.
- Pages are split into heading-aware chunks with overlap. Defaults exposed by the package include `maxChunkChars: 1200`, `overlapChars: 160`, and `searchLimit: 8`.
- Ranking is lexical but not just naive substring search: Leadtype tokenizes text, removes common stopwords, weights matches in title/heading/body/code differently, applies stemming, built-in/custom synonyms, prefix expansion, typo tolerance, phrase boosts, and proximity boosts.
- The search runtime is framework-neutral and can run in the browser, at the edge, in a worker, or behind framework adapters. The client defaults to fetching `/<collection>/search-index.json` and `/<collection>/search-content.json`.
- Leadtype can also build **source-grounded answer context** from the same search results. The optional Vercel/TanStack/Cloudflare answer helpers retrieve sources with Leadtype search, construct a constrained prompt, and return citations. That is RAG-style grounding, but the default retrieval step is still BM25 over generated docs artifacts, not embeddings.

So the default answer to “how do we stand up docs search?” is: generate Leadtype’s static artifacts, serve them with the docs site, and query them with `leadtype/search` or a framework adapter.

## When embeddings are actually warranted

Add embeddings only after the static BM25 index has been tried against representative docs-search queries and it fails a measured requirement. Embeddings are warranted when at least one of these is true:

1. **Semantic recall is consistently poor despite lexical tuning.** Real users ask broad conceptual or paraphrased questions that do not share enough vocabulary with the docs, and synonyms/stemming/prefix/typo support do not recover the right chunks.
2. **The corpus is too large or too dynamic for the static artifact model.** For example, the index/content JSON becomes too large to ship or cache well, or the searchable content changes frequently enough that a hosted incremental index is operationally necessary.
3. **You need server-side retrieval because of access control or personalization.** If docs results depend on tenant, plan, permissions, private/internal content, or user-specific state, a public static index may be the wrong boundary.
4. **You have a measured answer-quality gap that lexical retrieval cannot close.** For RAG answers, if bad answers are caused by missing semantically related sources rather than generation issues, an embedding retriever or hybrid retriever can be justified.

Even then, do **not** replace Leadtype’s search path wholesale. Keep:

- **Leadtype’s generated, flattened markdown/docs artifacts** as the canonical source text for retrieval and citations.
- **BM25 lexical search** as part of a hybrid system, because it is usually better for exact API names, option names, error strings, headings, code identifiers, and copy-pasted snippets.
- **Leadtype’s chunking/source metadata and citation discipline** so answers remain grounded in specific docs URLs/headings instead of opaque vector hits.
- **The lightweight static search experience** as a fallback and baseline, especially for docs-site search where exact-match speed and zero infrastructure are valuable.

Practical recommendation: start with Leadtype’s default static BM25 search and optional source-grounded answer helpers. Add embeddings only if evaluation/query logs show a real semantic-recall problem, and implement them as a hybrid layer over the Leadtype-generated content rather than as a replacement for it.
