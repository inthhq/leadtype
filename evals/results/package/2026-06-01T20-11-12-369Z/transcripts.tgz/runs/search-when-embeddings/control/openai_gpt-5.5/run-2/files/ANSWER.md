# Leadtype docs search and when to add embeddings

## What Leadtype uses by default

Leadtype does **not** require a hosted database-backed vector index for docs search by default.

Its default search path is a **static, edge-safe lexical index** generated from the docs. The package README describes this as a static search index using **BM25**. In the installed package, `leadtype/search` exposes `createDocsSearchIndex`, `searchDocs`, `createAnswerContext`, and related helpers; the client fetches generated JSON artifacts such as `/<collection>/search-index.json` and `/<collection>/search-content.json`.

Concretely, the default indexer/runtime:

- chunks the flattened markdown docs into overlapping sections;
- stores document/chunk metadata, headings, URLs, and content separately in JSON artifacts;
- tokenizes text, removes stopwords, and scores with **BM25**;
- weights fields differently: title matches score highest, then headings, body text, and code;
- expands lexical recall with stemming, built-in/custom synonyms, prefix matches, and typo-tolerant matches;
- boosts phrase and ordered-proximity matches;
- returns excerpts and canonical source URLs/anchors;
- can build source-grounded answer context for an LLM using the same search results.

So Leadtype already gives us the core RAG retrieval substrate for docs: generated chunks, ranked retrieval, source URLs, excerpts, and optional LLM answer context — without standing up a vector database.

## When embeddings are actually warranted

Add embeddings only if the default Leadtype search has been tried, tuned, and measured, and we still have a recall problem that lexical search cannot reasonably solve.

Embeddings are warranted when these conditions are true:

1. **We have evidence from real queries or an evaluation set** that relevant docs are being missed, not merely ranked a little lower.
2. The misses are mainly **semantic/vocabulary mismatches**: users ask with concepts, intents, paraphrases, or domain language that do not share useful terms with the docs.
3. The problem cannot be fixed well enough by improving headings/content, adding Leadtype synonyms, or tuning chunking/limits.
4. The expected gain justifies the operational cost: embedding generation, re-indexing on every docs change, hosted storage, auth, latency, monitoring, evals, and failure modes.
5. We still need source-grounded answers with citations, not just nearest-neighbor text snippets.

Even then, we should **keep Leadtype’s default search artifacts and BM25 retrieval**. Use embeddings as an additional retrieval signal, not a replacement. BM25 is still better for exact API names, option names, error messages, CLI flags, code symbols, paths, and versioned docs terms. A good production setup would be hybrid: retrieve with BM25 plus vectors, merge/rerank results, and feed the final selected Leadtype chunks/URLs into the answer-context/citation flow.

In short: start with Leadtype’s static BM25 search. Add embeddings only after measured lexical recall failures, and keep BM25 plus Leadtype’s chunk/source/citation pipeline as the reliable exact-match and grounding layer.
