# Leadtype docs search vs. a vector database

## What Leadtype uses by default

Leadtype already generates a docs search system without a hosted database or embeddings. Its default output is a **static, edge-safe search index**: `search-index.json` plus, when split out, `search-content.json`, generated from the flattened markdown docs and served like any other static asset.

The runtime search is **lexical BM25**, not vector similarity. The installed package shows the default search pipeline does the following:

- splits docs into overlapping chunks (`maxChunkChars: 1200`, `overlapChars: 160` by default);
- indexes terms from title, heading, body, and code fields;
- scores with BM25 (`k1 = 1.2`, `b = 0.75`);
- weights matches by field:
  - title: `4`
  - heading: `2`
  - body: `1`
  - code: `0.35`
- normalizes/tokenizes text, removes common stopwords, and applies light stemming;
- expands queries with built-in and optional synonyms;
- supports prefix and typo-tolerant expansion;
- adds phrase/proximity boosts;
- returns a default of `8` results.

For RAG-style answers, Leadtype does not require a vector database either. Its answer helpers build a **source-grounded prompt from the same search results**: retrieve top BM25 chunks, cap the context size, attach citations, and instruct the model to answer only from the provided docs context.

So the default architecture is: **static generated docs artifacts + BM25 retrieval + optional LLM answer generation grounded in retrieved source chunks**.

## When embeddings are actually warranted

Adding embeddings is warranted only when we have evidence that lexical search is the bottleneck. Concretely, we should consider embeddings if all or most of these are true:

1. **Representative query logs or evals show recall failures**: users ask valid questions whose relevant docs exist, but BM25 does not retrieve them near the top.
2. **The failures are semantic/paraphrase failures**, not content-quality problems: the query and the docs use different vocabulary, and fixes like better headings, clearer prose, aliases, redirects, metadata, or Leadtype synonyms are not enough.
3. **The queries are genuinely conceptual or vague**, e.g. task descriptions, troubleshooting descriptions, or “how do I accomplish X?” questions where exact API names/options/error messages are unknown.
4. **The added infrastructure is justified** by corpus size, query volume, latency needs, update frequency, privacy/security requirements, and operational cost.
5. **We can evaluate hybrid retrieval quality**, not just add vectors because “that is how RAG is done.”

Even then, we should **keep Leadtype’s BM25/static search path**. Use embeddings as an additional retriever or reranker, not as a replacement. BM25 is still better for exact names, API symbols, option flags, error messages, headings, and known-item lookup; it is cheap, deterministic, debuggable, cacheable, and works from static artifacts. For answers, we should also keep Leadtype’s source-grounding pattern: retrieve concrete docs chunks, provide citations, cap context, and require the model to say when the context is insufficient.

Recommended path: start with Leadtype’s generated BM25 index and answer context; add embeddings only after measured misses show semantic recall gaps that the docs/search configuration cannot reasonably fix; if added, run a **hybrid BM25 + vector** system and preserve the Leadtype source chunks/citations as the grounding layer.
