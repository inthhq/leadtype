# Leadtype docs search vs. adding embeddings

## 1. What Leadtype uses by default

Leadtype already ships docs search as a **static, edge-safe lexical search index**, not a hosted/vector database.

By default, the pipeline:

- flattens MDX/docs content into clean markdown;
- chunks that markdown into overlapping sections;
- writes generated JSON artifacts such as `docs/search-index.json` and, when content is not embedded in the index, `docs/search-content.json`;
- searches those artifacts with an in-process **BM25-style inverted index**.

The installed package confirms this in both the README and runtime code: Leadtype describes the default as “static, edge-safe search index (BM25, optional source-grounded answers).” The search implementation indexes terms from title, headings, body, and code with different weights, then adds practical lexical recall features such as stemming, synonyms, prefix matching, typo-tolerant expansion, phrase boosts, and proximity boosts.

So the default is:

> generated static JSON + BM25 lexical retrieval + optional source-grounded LLM answer streaming

It is **not**:

> embeddings + vector similarity + hosted database

The optional AI answer layer is also still source-grounded on Leadtype retrieval. `createAnswerContext` first calls `searchDocs`, selects a bounded set of sources, builds a context prompt, and instructs the model to use only that context and cite sources. In other words, Leadtype already supports the “retrieve docs, then answer from sources” shape of RAG without requiring embeddings.

## 2. When embeddings are actually warranted — and what to keep

Do not add embeddings merely because “that is how RAG is done.” Add them only when we can show that Leadtype’s default lexical search is the limiting factor.

Embeddings are warranted if **all or most** of these are true:

1. **Measured recall gap:** real search logs or an evaluation set show that relevant docs are missed by BM25.
2. **Semantic mismatch:** missed queries use wording that does not overlap with the docs — e.g. users ask conceptual/paraphrased questions while the docs use different terminology.
3. **Lexical tuning is insufficient:** improving titles, headings, descriptions, synonyms, docs wording, or Leadtype transformers does not fix the misses.
4. **The value justifies the operational cost:** a server-side/vector service is acceptable for our latency, hosting, privacy, deployment, and maintenance requirements.
5. **Scale or access patterns require it:** the docs corpus is too large or too dynamic for static JSON artifacts, or retrieval must be filtered by tenant, product version, permissions, or other runtime state.

Even then, we should keep Leadtype’s default retrieval assets and behavior:

- Keep the generated Leadtype markdown/chunks as the canonical source text for retrieval and answers.
- Keep BM25 as a first-stage retriever, fallback, or hybrid scoring signal.
- Keep lexical search for exact matches: API names, CLI flags, config keys, error codes, package names, headings, and code snippets are often better served by BM25 than by embeddings.
- Keep Leadtype’s URLs, anchors, excerpts, and citation/source metadata so answers remain inspectable and link back to docs.
- Keep the source-grounded answer discipline: answer only from retrieved docs, cite sources, and say when context is insufficient.

Recommended path: start with Leadtype’s static BM25 search and optional source-grounded answers. Add embeddings only after we have evidence that semantic recall is failing and a hybrid BM25 + vector approach would materially improve results.