# What leadtype's Docs Search Already Provides

## 1. Default Search Implementation

**leadtype uses BM25 (Okapi BM25) keyword-based search by default.**

This is a battle-tested probabilistic ranking function that matches query terms against indexed documents. The system:

- **Builds a static, edge-safe search index** (`search-index.json`) at build time from your MDX docs
- **Chunks documents** (default 1200 chars per chunk with 160-char overlap) into searchable units with full positional tracking
- **Indexes terms** with relevance scores across title, headings, body text, and code blocks separately
- **Scores results** at runtime using BM25 without any embeddings or external services
- **Stores chunk metadata** (id, url, anchor, heading path, locale) needed for search result display
- **Runs entirely on the client or edge** — the JSON index is served statically, no database required

The implementation is part of the `leadtype/search` entry point with framework-specific bindings for React (`leadtype/search/react`), Vue (`leadtype/search/vue`), Svelte (`leadtype/search/svelte`), and others.

## 2. When (and What) to Add Embeddings

**Embeddings are warranted only if:**

1. **Your docs have conceptually similar content that doesn't share keywords.** BM25 succeeds when users search for terms present in the docs. It fails when users describe concepts in different vocabulary than the source (e.g., searching "how do I get started" when your docs say "installation" and "setup guide"). Semantic search via embeddings bridges this gap.

2. **Your docs are large (100+ pages) or highly cross-referenced.** Small, well-organized docs are easier to search with keywords. Large, interconnected knowledge bases benefit from semantic understanding.

3. **You can absorb the operational cost.** Embeddings require:
   - A hosted vector index (Pinecone, Weaviate, Supabase pgvector, etc.)
   - An embedding model API (OpenAI, Cohere, local) with latency
   - Ongoing database costs and maintenance
   - Sync logic to keep embeddings in step with doc updates

**What to keep even with embeddings:**

- **BM25 keyword index as the primary search backend.** It's fast, deterministic, and requires zero operational infrastructure. Use it for exact-match queries and high-confidence results.
- **Static chunk metadata** (titles, headings, URLs, code snippets). Embeddings alone won't give users the context they need to decide if a result is relevant. The existing chunk structure is essential for display and citation.
- **The static `search-index.json` generation.** Continue building it as part of your standard doc generation pipeline. It's your fallback when embeddings are unavailable or slow.
- **The `searchDocs()` function and `createDocsSearchIndex()` logic.** Don't replace them; augment them. Hybrid search (BM25 + embeddings) outperforms either alone.

**Example hybrid approach:** Rank results by BM25 first (fast, no API), then re-rank top-K results using embedding similarity. If BM25 returns nothing useful, fall back to a pure embedding search. This keeps your docs searchable offline and gives you the best of both worlds.

---

**Bottom line:** leadtype ships a production-ready, zero-ops keyword search solution. It's sufficient for most docs. Before building a hosted vector index, verify that keyword search actually fails for your use case. If it does, add embeddings *on top* of the static index, not instead of it.
