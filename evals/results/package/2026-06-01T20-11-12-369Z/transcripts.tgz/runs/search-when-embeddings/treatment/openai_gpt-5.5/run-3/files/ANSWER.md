# What leadtype already gives us for docs search

## Default search

Leadtype's docs search is **static and lexical by default**, not a hosted database-backed vector index.

In site mode, `leadtype generate` writes:

- `public/docs/search-index.json` — compact term postings and chunk/document references
- `public/docs/search-content.json` — chunk text stored separately so content can load lazily for excerpts or answers

At runtime, leadtype loads those JSON files and runs local search with `searchDocs` or the framework helpers (`leadtype/search/react`, `leadtype/search/vue`, `leadtype/search/svelte`, `leadtype/search/client`, etc.). This is edge-safe and does not require a database.

The ranking is **BM25** over heading-aware chunks. Leadtype weights fields as follows:

- title: 4×
- headings: 2×
- body: 1×
- code: 0.35×

It is designed to be precise for docs queries such as API names, config keys, error messages, paths, headings, and guide phrases. It also includes practical lexical search behavior like stemming, prefix matches, typo-tolerant fallbacks, and a small synonym map; product-specific synonyms can be added when users search for words the docs do not use.

Leadtype can also stream AI answers, but that still starts from the same static index: query → `searchDocs` → retrieved chunks → constrained prompt with citations → streamed answer. The model is supposed to answer only from the retrieved docs context, not from memory.

## When embeddings are actually warranted

We should start with leadtype's local BM25 index. Add embeddings only if one of these is true:

1. **Users consistently search with vocabulary the docs do not use**, and aliases/synonyms are not enough.
2. **The corpus grows beyond the practical size for the static index**, specifically into the range of tens of thousands of chunks.

Even then, we should **keep the lexical BM25 index**. Use embeddings as an additional semantic retrieval layer, not a replacement. The lexical index remains better for exact matches: API names, config keys, CLI flags, error strings, file paths, identifiers, and headings. A hybrid approach lets BM25 handle precise lookups while embeddings help with semantic or vocabulary-mismatch queries.
