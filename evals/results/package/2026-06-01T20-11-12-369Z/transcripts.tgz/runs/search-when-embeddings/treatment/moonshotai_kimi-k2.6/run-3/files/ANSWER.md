# Leadtype Docs Search: Default Behavior & When to Add Embeddings

## 1. What leadtype uses by default

Leadtype’s docs search is **static, edge-safe, and database-free** by default.

At build time it generates two JSON files:
- **`search-index.json`** — compact term postings + document/chunk references (loaded on every search)
- **`search-content.json`** — the actual chunk text (loaded lazily for excerpts and AI answers)

At runtime the framework hooks or `searchDocs()` load these files and query them **locally** — no database, no vector store, no network round-trips to a search backend.

The ranking function is **BM25** with these field weights:
- **Title:** 4×
- **Headings:** 2×
- **Body:** 1×
- **Code blocks:** 0.35×

The default query pipeline also includes:
- **Stemming** (basic English suffix rules)
- **Prefix matching** (e.g., `lint` → `linting`)
- **Typo tolerance** (edit-distance 1 for short terms, 2 for longer terms)
- **Built-in synonym map** (e.g., `ts` ↔ `typescript`, `auth` ↔ `authentication`)
- **Phrase and proximity boosts** for multi-word queries

## 2. When embeddings are actually warranted — and what to keep

> *"Start with the local index — static, cheap, edge-safe, and precise for API names, config keys, error messages, and paths. Add embeddings only when users search with vocabulary the docs don't use, or the corpus grows past tens of thousands of chunks. Even then, keep the lexical index for exact matches and layer embeddings on top."*
> — `leadtype/docs/reference/search.md`

### Specific conditions for adding embeddings
1. **Vocabulary mismatch:** Users search with words or concepts that do not appear in the docs text (semantic search is needed).
2. **Scale:** The corpus grows past **tens of thousands of chunks**.

### What you should keep even then
- **Keep the lexical BM25 index.** It is already precise for exact matches like API names, config keys, error messages, and file paths — things embeddings can mangle or rank poorly.
- **Layer embeddings on top** of the existing static index rather than replacing it. Use the embedding retrieval to broaden recall for semantically related terms, then let the BM25 layer (or a hybrid re-ranker) preserve exact-match accuracy.
