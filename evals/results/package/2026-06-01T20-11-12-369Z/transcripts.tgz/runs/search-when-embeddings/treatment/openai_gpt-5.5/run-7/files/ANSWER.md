# Leadtype docs search vs. embeddings

## What leadtype uses by default

Leadtype docs search is **static and lexical by default**, not a hosted database-backed vector index.

In site mode, `leadtype generate` writes two JSON artifacts:

- `public/docs/search-index.json` — a compact **BM25-ranked inverted index**.
- `public/docs/search-content.json` — chunk text/content stored separately so the index stays small and content can be loaded lazily for excerpts or answers.

The index is built over heading-aware chunks of the generated markdown docs. Ranking weights are:

- title: 4×
- headings: 2×
- body: 1×
- code: 0.35×

At runtime, `searchDocs` or the framework hooks/client load those JSON files and query them locally. This is edge-safe, cheap, and requires no database. Leadtype search also includes stemming, prefix matching, typo-tolerant fallbacks, and a small built-in synonym map. Product-specific synonyms can be added when users use terms the docs do not use.

Leadtype's optional AI-answer flow also starts from this same static index: it retrieves relevant chunks with `searchDocs`, builds a constrained source-grounded prompt, and streams an answer with citations. It is RAG over the existing static lexical index, not vector search by default.

## When embeddings are actually warranted

Start with the default local BM25 index. Add embeddings only when at least one of these is true:

1. **Users search with vocabulary the docs do not use**, and aliases/synonyms are not enough to bridge the gap.
2. **The corpus grows past tens of thousands of chunks**, where a semantic retrieval layer becomes useful for recall at scale.

Even then, do **not** replace the lexical index. Keep Leadtype's BM25/static index for exact, high-precision matches such as API names, config keys, error messages, code symbols, and paths. If we add embeddings, they should be layered on top as a hybrid retrieval path, while preserving the generated search JSON artifacts and lexical search behavior for precision, snippets, citations, and fallback results.
