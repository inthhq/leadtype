# Docs Search in `leadtype`: Do We Need a Hosted Vector Index?

Short answer: **not by default, and probably not at all yet.** `leadtype`
ships a complete, production-grade docs search that needs no database, no
server-side index, and no embeddings. Build a hosted vector store only if we
hit a specific, measurable limit — and even then we keep the existing index.

## 1. What leadtype's docs search uses by default

leadtype search is **static and lexical** — there is no database and nothing to
host as a stateful service.

- **Build step** produces two plain JSON files (`leadtype generate` or
  `generateDocsSearchFiles(...)`):
  - `public/docs/search-index.json` — compact term postings + document/chunk
    refs, loaded on every search.
  - `public/docs/search-content.json` — chunk text, loaded lazily for excerpts
    and AI answers (kept separate so search stays cheap).
- **Ranking** is **BM25** (a lexical/keyword ranking function) over
  **heading-aware chunks**, so results jump to the right section. Field weights:
  title 4×, headings 2×, body 1×, code 0.35×.
- **Runtime query** is `searchDocs(index, query, opts)` from `leadtype/search`.
  It is **edge-safe** — no Node APIs, no backend, no vector DB. You can query
  directly, use framework hooks (`useLeadtypeSearch` for React/Next/Vue/Svelte,
  `createSearchClient` for vanilla), or layer source-grounded AI answers
  (`createAnswerContext` / `streamDocsAnswer`) and read-only agent bash tools
  on the *same* index.
- **Quality features already included** out of the box: stemming, prefix
  matching, typo-tolerant fallbacks, a built-in synonym map, and an optional
  per-product synonym/alias map (`synonyms: {...}`) for vocabulary the docs
  don't use.

In other words, the default already covers the "RAG retrieval" job for docs —
statically, cheaply, and precisely — without standing up any infrastructure.

## 2. When embeddings are actually warranted (and what to keep)

Per leadtype's own guidance, start with the local lexical index. It is static,
cheap, edge-safe, and **precise for the things people actually search in docs**:
API names, config keys, error messages, and file paths.

Add embeddings **only** when one of these specific conditions is true:

1. **Vocabulary mismatch at scale** — users routinely search with words the
   docs don't use, and per-product **synonym aliases are no longer enough** to
   bridge the gap. (Try the built-in synonym map first; it's free.)
2. **Corpus size** — the docs grow past **tens of thousands of chunks**, where
   pure lexical recall starts to degrade.

Even then, **keep the lexical index.** Do not replace it with a vector store.
Embeddings go **on top** of BM25:

- Keep the static `search-index.json` / `search-content.json` for **exact
  matches** (API names, config keys, errors, paths) — semantic search is worse
  at these.
- Layer embeddings as a recall booster for fuzzy/conceptual queries, then merge
  / re-rank against the lexical results.

## Recommendation

Don't build the hosted, DB-backed vector index "because that's how RAG is done."
Ship leadtype's default static search now. Measure real query failures. If we
see genuine vocabulary mismatch, add product synonyms first. Only if synonyms
fall short *or* the corpus crosses tens of thousands of chunks should we add
embeddings — and we keep the lexical index as the exact-match layer underneath.
