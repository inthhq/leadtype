# Leadtype docs search: default vs. embeddings

## What leadtype uses by default

Leadtype’s docs search is **static, local, and lexical by default** — not a hosted database-backed vector index.

In site mode, `leadtype generate` writes two files:

- `public/docs/search-index.json` — compact ranking/index data
- `public/docs/search-content.json` — chunk text, loaded lazily for excerpts or answers

At runtime, `leadtype/search` loads those JSON artifacts and queries them locally with `searchDocs`. This is edge-safe and does not require a database or search service.

The default ranking is a **BM25 inverted index** over heading-aware chunks of the docs. Leadtype weights fields roughly as:

- title: 4×
- headings: 2×
- body: 1×
- code: 0.35×

It also supports practical lexical-search behavior such as stemming, prefix matches, typo-tolerant fallbacks, and a small built-in synonym map. Product-specific synonyms can be layered in when users search with terms the docs do not use.

For AI answers, leadtype still starts from the same static index: it retrieves relevant chunks with `searchDocs`, builds a constrained source-grounded prompt, and streams an answer with citations. In other words, leadtype already gives us a lightweight RAG path without standing up a vector database first.

## When embeddings are actually warranted

Start with leadtype’s local BM25 index. It is the right default for docs because it is cheap, precise, deploys as static files, works at the edge, and is especially strong for:

- API names
- config keys
- exact phrases
- error messages
- file paths
- code identifiers
- section titles

Adding embeddings is warranted only under specific conditions:

1. **Users search with vocabulary the docs do not use.**  
   If people consistently ask for concepts using different language than appears in the docs, and synonyms/wording fixes are not enough, embeddings can help bridge that semantic gap.

2. **The corpus grows past tens of thousands of chunks.**  
   At that scale, a dedicated retrieval layer may become useful for recall, ranking, or operational reasons.

Even then, we should **keep leadtype’s lexical index**. Embeddings should be layered on top, not used as a replacement. The BM25 index remains important for exact matches — API names, flags, config keys, errors, code symbols, and paths — where vector search can be less reliable.