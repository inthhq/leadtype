# Leadtype docs search vs. hosted vector search

## What Leadtype uses by default

Leadtype’s docs search is **static by default**, not database-backed and not embedding-backed.

In site mode (`leadtype generate`), Leadtype writes two JSON artifacts:

- `public/docs/search-index.json` — compact ranking data loaded for search
- `public/docs/search-content.json` — chunk text loaded lazily for excerpts or source-grounded answers

At runtime, `leadtype/search` queries those files locally with an edge-safe **BM25 lexical index**. The index is built over heading-aware chunks of the generated markdown and ranks matches using weighted fields:

- title: 4×
- headings: 2×
- body: 1×
- code: 0.35×

It is designed to be precise for docs queries such as API names, config keys, error messages, paths, guide phrases, and section-level navigation. Leadtype also includes normal search niceties like stemming, prefix matches, typo-tolerant fallbacks, and a small built-in synonym map; product-specific synonyms can be added without introducing embeddings.

Leadtype’s optional AI answer streaming still starts from this same static index: it retrieves relevant chunks with `searchDocs`, builds a constrained prompt from those sources, and tells the model to answer only from the retrieved context with citations. That is RAG-style grounding without requiring a hosted vector database.

## When embeddings are actually warranted

Start with Leadtype’s local static index first. Add embeddings only when one of these is true:

1. **Users search with vocabulary the docs do not use.**  
   For example, users consistently phrase concepts semantically while the docs use different terminology, and aliases/synonyms are not enough.

2. **The corpus grows past tens of thousands of chunks.**  
   At that scale, a semantic retrieval layer may help recall across a much larger documentation set.

Even then, do **not** replace Leadtype’s lexical index. Keep the BM25 index for exact matches — API names, config keys, errors, paths, symbols, and code-like terms — and layer embeddings on top as an additional semantic-recall path.