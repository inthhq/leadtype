# Does `leadtype` already give us docs search? (Before we build a hosted vector DB)

Short version: **yes — and it's deliberately *not* a hosted vector index.** Before standing up a database-backed embeddings service "because that's how RAG is done," here's what `leadtype` ships and when embeddings are actually justified.

## 1. What leadtype's docs search uses by default

Leadtype docs search is **static and lexical by default — no database, no embeddings, no hosted service, edge-safe.**

- **Build time** produces two JSON files (`leadtype generate`, or `generateDocsSearchFiles` from `leadtype/search/node`):
  - `public/docs/search-index.json` — compact term postings + document/chunk refs. Loaded on every search.
  - `public/docs/search-content.json` — chunk text, kept separate so search stays cheap and content (excerpts/answers) loads lazily.
- **Runtime** loads those JSON files and queries them locally with `searchDocs(index, query, { content })`. The runtime is edge-safe (no Node APIs) — it runs in a server route, a Worker, or the browser. There is no index server to host and no DB to operate.
- **Ranking is BM25** (a classic lexical/keyword ranking function), with field weights: title 4×, headings 2×, body 1×, code 0.35×. Documents are **heading-aware chunks**, so a result jumps to the right section (`urlWithHash`), not just the page.
- **Out of the box it already does** stemming, prefix matching, typo-tolerant fallbacks, and a small built-in synonym map. You add product-specific synonyms (`synonyms: { starter: ["quickstart", ...] }`) only when users search with words the docs don't use.
- **UI is provided** via framework hooks (`leadtype/search/react`, `/vue`, `/svelte`, `/client`, and `leadtype/next/client`) that load the two JSON files by collection name, debounce input, and manage loading state.

This is precise exactly where docs search matters most: **API names, config keys, error messages, and file paths** — the kinds of exact-match queries that embedding-only semantic search is notoriously *worse* at.

### What about AI / RAG answers?

Leadtype also supports source-grounded AI answers (`leadtype/search/ai-answers`, `streamDocsAnswer` for Vercel AI SDK / TanStack AI / Cloudflare Workers AI) — and notably, **it retrieves over the same static lexical index.** Retrieval feeds `createAnswerContext`, which builds a constrained prompt instructing the model to answer *only* from the retrieved chunks and cite them. So you can do grounded RAG-style answers today **without** a vector database. (It also ships endpoint guards — rate limiting, body-size limits, query validation — for the paid-model route.)

## 2. When adding embeddings is actually warranted — and what to keep

Per leadtype's own guidance, **start with the local lexical index** and add embeddings **only** when one of these specific conditions holds:

1. **Vocabulary mismatch the synonym map can't cover** — users consistently search with words/phrasing that don't appear in the docs, so lexical matching (even with stemming + synonyms) genuinely misses relevant content.
2. **Corpus scale** — the corpus grows past **tens of thousands of chunks**, where lexical ranking alone starts to lose precision/recall.

If neither is true, a hosted vector index adds infrastructure, cost, and an operational service (DB to run, embeddings to keep in sync, latency, an extra failure mode) for little gain over what's already in the box.

### What to keep even then

**Do not replace the lexical index — layer embeddings on top of it.** Keep:

- **The static BM25 lexical index** for exact matches (API names, config keys, error strings, paths) — semantic search is weaker at these.
- **Heading-aware chunking** and the chunk/content split, so results still deep-link to sections and content loads lazily.
- **The existing grounded-answer flow** (`createAnswerContext` / `streamDocsAnswer`) and **endpoint guards** (rate limiting, `readJsonWithLimit`, `validateDocsQuery`, `503` when the provider is unconfigured).

In other words: embeddings become an *additional* retrieval signal fused with lexical results — a **hybrid** approach — not a wholesale swap to a vector-DB-only design.

## Recommendation

Before building a hosted, DB-backed vector index, ship leadtype's built-in static search (and, if you want answers, its source-grounded AI answer endpoint). Only invest in embeddings if you can point to (1) real vocabulary-mismatch misses or (2) a corpus crossing tens of thousands of chunks — and even then, keep the lexical index and run embeddings as a hybrid layer rather than a replacement.

---

*Sources: leadtype docs — `docs/search/add-search.md`, `docs/reference/search.md` ("When to add embeddings"), and `docs/search/ai-answers.md`.*
