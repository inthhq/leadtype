# Does `leadtype` already give us docs search? (Yes — before you build a vector DB)

Short version: **don't stand up a hosted, database-backed vector index yet.**
`leadtype` ships a complete docs search out of the box, and its own guidance is
to start there and only add embeddings under specific, measurable conditions.

## 1. What leadtype's docs search uses by default

Leadtype search is **static and lexical by default** — no database, no service,
no embeddings.

- **Ranking: BM25** (a lexical/keyword ranking function), with field weights
  tuned for docs — title 4×, headings 2×, body 1×, code 0.35×.
- **Two generated artifacts** produced at build time by
  `generateDocsSearchFiles` (or `leadtype generate`):
  - `search-index.json` — compact term postings + document/chunk refs, loaded
    on every search.
  - `search-content.json` — chunk text, kept separate so search stays cheap and
    content loads lazily (for excerpts/answers).
- **Heading-aware chunking** — each chunk is a separate document, so results
  jump to the right section (hash URLs, heading paths).
- **Edge-safe runtime** — `searchDocs(index, query, ...)` uses no Node APIs;
  it loads the JSON locally and queries it. Framework hooks exist for React,
  Next, Vue, Svelte, and vanilla (`useLeadtypeSearch` / `createSearchClient`).
- **Smart matching already built in** — stemming, prefix matches,
  typo-tolerant fallbacks, and a small built-in synonym map. You can add
  product-specific synonym aliases when users search with words the docs don't
  use, e.g. `synonyms: { starter: ["quickstart", "getting started"] }`.

So "database-backed vector index" is not how leadtype does RAG by default — it
deliberately ships a static, local, lexical index that's cheap, precise, and
deployable to the edge. (Source-grounded AI answers and agent tools are layered
*on top of this same static index*, not a separate vector store.)

## 2. When adding embeddings is actually warranted — and what to keep

Per leadtype's own guidance, start with the local index — it is static, cheap,
edge-safe, and **precise for API names, config keys, error messages, and
paths**. Add embeddings **only** when one of these is true:

- **Vocabulary mismatch:** users search with words/phrasing the docs don't use
  (semantic gap that synonyms can't reasonably cover), **or**
- **Scale:** the corpus grows past **tens of thousands of chunks**.

**Even then, keep the lexical (BM25) index for exact matches** and layer
embeddings on top — hybrid retrieval, not a replacement. Exact identifiers (API
names, config keys, error strings, file paths) are exactly where lexical search
beats vector search, so you don't want to give that up.

### Recommendation

Ship the built-in static index first. Measure whether real queries fail because
of vocabulary mismatch or corpus size. Try synonym aliases for vocabulary gaps
before reaching for embeddings. Only if those thresholds are genuinely hit do
you add a vector layer — and keep BM25 underneath it.
