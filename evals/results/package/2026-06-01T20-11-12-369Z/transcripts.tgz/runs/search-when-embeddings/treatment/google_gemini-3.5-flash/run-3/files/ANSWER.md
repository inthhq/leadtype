# Leadtype Docs Search: BM25 Lexical Indexing vs. Embeddings

Before standing up a hosted, database-backed vector index for documentation search, here is a detailed breakdown of what `leadtype` already provides out of the box and the specific criteria for when embeddings/vector search are actually warranted.

---

## 1. What Leadtype's Docs Search Uses by Default

By default, `leadtype` provides a **static, local, edge-safe lexical search index** that requires zero database infrastructure.

### Build-Time Generation
Running `leadtype generate` or calling `generateDocsSearchFiles` at build time produces two compact JSON files:
*   **`search-index.json`**: Compact term postings and document/chunk references. This file is loaded on every search to perform rapid lookup and ranking.
*   **`search-content.json`**: Chunk text separated from the index. Keeping this content out of the main index ensures queries remain lightweight and fast, loading lazily only when needed for excerpts, snippets, or AI answers.

### Runtime Matching and Ranking Engine
*   **BM25 Algorithm**: The matching and relevance engine uses the classic BM25 ranking function.
*   **Field Weighting**: It applies the following default weights to favor structural context:
    *   **Title**: 4× weight
    *   **Headings**: 2× weight
    *   **Body Text**: 1× weight
    *   **Code Blocks**: 0.35× weight
*   **Robust Linguistic Features**: The default runtime search supports:
    *   Stemming
    *   Prefix matches
    *   Typo-tolerant fallbacks
    *   A small, built-in synonym map
    *   Product-specific synonym overrides (vocabulary aliases) via custom runtime mapping (e.g., mapping `"starter"` to `["quickstart", "getting started"]`).
*   **Local, Edge-Safe Querying**: Because matching happens locally in memory (using the edge-compatible `searchDocs` API or client/framework hooks for React, Next.js, Vue, and Svelte), queries are extremely fast, cheap, and run perfectly on edge networks.

---

## 2. When Are Embeddings Actually Warranted?

According to `leadtype`'s architecture and evaluation findings, a vector/embeddings index is **not** a blanket replacement for search. 

### Specific Conditions Warranting Embeddings
Adding embeddings or a vector index is warranted **only under these specific conditions**:
1.  **Semantic / Vocabulary Gap**: When users frequently search with vocabulary, concepts, or terminology that the documentation itself does not actually use, and managing synonym lists does not scale.
2.  **Corpus Scale**: When the size of the documentation corpus grows very large, specifically growing past **tens of thousands of chunks**.

### What to Keep Even Then
If you do decide to implement embeddings, **do not discard the default lexical (BM25) search**. 

You should **keep the lexical index** and **layer the embeddings on top** (hybrid search).

### Why Keep the Lexical Index?
*   **Precision**: BM25 is highly precise for exact matches. It handles searches for **exact API names, configuration keys, exact error messages, flag names, and directory/file paths** much better than vector models. 
*   **Failures of Vector Search**: Pure semantic/embedding-based search models frequently fail or hallucinatively rank unrelated concepts for precise technical queries because they map syntax to general semantic neighborhoods rather than literal matches.
