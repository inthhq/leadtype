# Leadtype's Default Docs Search

## 1. What Leadtype Uses by Default

Leadtype's docs search uses **BM25 (static, lexical ranking)** with no embeddings or database required.

### The Stack

- **Build time**: `generateDocsSearchFiles()` produces two static JSON files:
  - `search-index.json` — compact term postings, document/chunk references, and BM25 scores
  - `search-content.json` — chunk text (loaded lazily for excerpts and answers)

- **Runtime**: `searchDocs()` loads both JSON files and runs BM25 queries locally
  - Edge-safe (no Node.js APIs)
  - Works in browser, serverless functions, and service workers
  - Framework hooks available for React (`useLeadtypeSearch`), Vue, Svelte, vanilla JS

- **Ranking**: BM25 with configurable weights:
  - Title: 4×
  - Headings: 2×
  - Body: 1×
  - Code: 0.35×

### Built-in Query Features

- Stemming
- Prefix matching
- Typo-tolerant fallbacks
- Small built-in synonym map
- Custom vocabulary aliases via `synonyms` option

### What You Get Without Adding Anything

A complete docs search experience with **static generation and zero database infrastructure**. Results include page URLs, section hashes, heading paths, and lazy-loaded excerpts. The default limit is 8 results.

---

## 2. When Embeddings Are Actually Warranted (And What to Keep)

### Add Embeddings Only When

1. **Users search with vocabulary the docs don't use** — Semantic search bridges synonyms and conceptual distance. Example: users search "starter" but your docs only say "quickstart" or "getting started."

2. **Corpus grows past tens of thousands of chunks** — At scale, lexical matching becomes a bottleneck relative to embedding cost, and semantic drift compounds.

3. **Retrieval precision is insufficient** — You've tuned the lexical index and it still misses relevant sections, and users are willing to pay embedding costs.

### What You MUST Keep Even When Adding Embeddings

**Keep the lexical BM25 index unchanged.** The reference explicitly states:

> "Even then, keep the lexical index for exact matches and layer embeddings on top."

#### Why

1. **Exact matches always win** — Users searching API names, config keys, error messages, and file paths rely on lexical precision. BM25 is unbeatable here.

2. **Cost and speed** — BM25 is instant, free, and edge-safe. Layering embeddings on top means:
   - Run BM25 first (no cost)
   - Fall back to embeddings only if needed
   - Use embeddings to *rerank* or *supplement* BM25 results, not replace them

3. **Operationally simpler** — You avoid:
   - Embedding API dependencies and latency
   - Database uptime and scaling concerns
   - Cache invalidation complexity
   - Per-deployment embedding drift

#### Implementation Pattern

```ts
// Existing BM25 search — keep this
const results = searchDocs(index, query, { content, limit: 8 });

// If quality is poor, layer embeddings
if (results.length === 0 || results[0].score < threshold) {
  // Embed the query and retrieve from your external index
  const embeddingResults = await embeddedSearch(query);
  // Merge or rerank; prefer exact matches
}
```

---

## Summary

**Default**: Static BM25 search from two JSON files. Zero infrastructure, instant queries, precise for documented terms.

**Embeddings decision**: Only add if vocabulary mismatch or corpus scale forces it. When you do, keep BM25 as the primary retrieval layer and layer embeddings for reranking or semantic fallback. The lexical index always stays in the rendering path.
