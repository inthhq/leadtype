# Does `leadtype` already give us docs search? (Before building a hosted vector DB)

Short answer: **yes.** `leadtype` ships a complete docs search system out of the
box, and it is deliberately *not* a hosted, database-backed vector index. Read
this before standing up RAG infrastructure — for most docs corpora the local
index is the right tool, and embeddings are an additive layer for narrow cases,
not a replacement.

## 1. What leadtype's docs search uses by default

Leadtype docs search is **static and lexical** — no database, no embedding
service, edge-safe.

- **Build time** produces two JSON files (`leadtype generate`, or
  `generateDocsSearchFiles` from `leadtype/search/node`):
  - `public/docs/search-index.json` — compact term postings + document/chunk
    refs. Loaded on every search.
  - `public/docs/search-content.json` — the chunk text, kept separate so search
    stays cheap and content (excerpts/answers) loads lazily.
- **Ranking is BM25**, a classic lexical/keyword ranking function, with
  field-aware weighting: title 4×, headings 2×, body 1×, code 0.35×.
- **Chunks are heading-aware** — each heading-scoped slice of a page is its own
  document, so results deep-link to the right section (`urlWithHash`,
  `headingPath`).
- **Query at runtime** with `searchDocs(index, query, { content })` from
  `leadtype/search`. The runtime is edge-safe — it uses no Node APIs and no
  network/database call. There are ready-made hooks for React, Vue, Svelte,
  Next App Router, and a vanilla client (`leadtype/search/client`).
- **Already handles fuzzy matching without embeddings:** stemming, prefix
  matches, typo-tolerant fallbacks, and a small built-in synonym map. You can
  add product-specific synonyms (`synonyms: { starter: ["quickstart", ...] }`)
  when users search with words the docs don't use.
- Optional **AI answers** (`streamDocsAnswer` / `createAnswerContext`) layer on
  top of *this same static index*: it retrieves chunks lexically, builds a
  constrained prompt that forces the model to answer only from retrieved chunks
  with citations, then streams the response. Even the "RAG" path here is
  grounded in the local lexical index — not a vector store.

In short: the default is a static, local BM25 index over heading-aware chunks —
cheap, fast, precise for the things docs queries are usually about (API names,
config keys, error messages, file paths), and with no infrastructure to host.

## 2. When adding embeddings is actually warranted — and what to keep

Per leadtype's own guidance (Search reference, "When to add embeddings"):

**Start with the local index.** It is static, cheap, edge-safe, and precise for
exact tokens — API names, config keys, error strings, and paths — which is the
bulk of real docs traffic.

**Add embeddings only when one of these is true:**

1. **Vocabulary mismatch** — users consistently search with terminology your
   docs don't contain, so lexical matching (even with synonyms and stemming)
   misses. Note: the cheap fix (the built-in synonym map / custom `synonyms`)
   should be exhausted first.
2. **Scale** — the corpus grows past **tens of thousands of chunks**, where
   semantic recall starts to matter beyond keyword matching.

**Even then, keep the lexical index.** Don't replace it. Leadtype's explicit
recommendation is to **retain the local BM25 index for exact matches and layer
embeddings on top** (hybrid retrieval). Exact identifiers (function names,
config keys, error codes) are exactly where pure vector search degrades, and
that's also where docs users most need precision.

### Practical takeaway for the team

Before building a hosted, database-backed vector index:

- Ship leadtype's default static search first — it's likely sufficient and needs
  no DB, no embedding pipeline, and no hosting cost.
- If recall is the complaint, try custom synonyms before reaching for
  embeddings.
- Only invest in embeddings/vector infrastructure if you hit genuine vocabulary
  mismatch or a tens-of-thousands-of-chunks corpus — and design it as a hybrid
  that keeps the lexical index, rather than swapping it out for "how RAG is
  done."
