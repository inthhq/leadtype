# Leadtype docs search: default vs. embeddings

## 1. What leadtype uses by default

Leadtype’s docs search is **static and lexical** — not database-backed and not vector-based.

- **Build-time output:** `leadtype generate` produces two JSON files:
  - `search-index.json` — compact BM25 ranking data (loaded on every search).
  - `search-content.json` — heading-aware chunk text (loaded lazily for excerpts and AI answers).
- **Ranking:** BM25 with field weights: **title 4×, headings 2×, body 1×, code 0.35×**.
- **Query behavior:** The runtime is edge-safe and runs locally in the browser or a lightweight server function. It uses stemming, prefix matching, typo-tolerant fallbacks, and a small built-in synonym map.
- **No infrastructure required:** There is no database, vector store, or hosted index to operate by default.

## 2. When embeddings are actually warranted — and what to keep

Per the leadtype search reference, add embeddings **only** when:

1. **Users search with vocabulary the docs don’t use** (semantic gaps where keyword/BM25 can’t bridge the mismatch).
2. **The corpus grows past tens of thousands of chunks** (scale where pure lexical recall starts to degrade).

**Even then, keep the lexical index.** The BM25 index should remain the foundation for exact matches — API names, config keys, error messages, and file paths — and embeddings should be **layered on top**, not substituted for it.
