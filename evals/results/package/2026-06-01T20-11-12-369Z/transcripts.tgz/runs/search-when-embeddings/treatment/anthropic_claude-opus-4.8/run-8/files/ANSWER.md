# Does `leadtype` already cover docs search? (Before building a hosted vector index)

Short version: **yes.** `leadtype` ships a complete docs search system out of the
box. You don't need a hosted, database-backed vector index to "do RAG" — and in
most cases you shouldn't start there. Here's what the package already gives us
and when embeddings are actually warranted.

## 1. What leadtype's docs search uses by default

Leadtype search is **static and lexical by default** — no database, no embedding
service, edge-safe.

- **Ranking algorithm: BM25** (lexical/keyword ranking), not vector similarity.
  Field weights are tuned for docs: title 4×, headings 2×, body 1×, code 0.35×.
- **Two static JSON artifacts** generated at build time (`leadtype generate` or
  `generateDocsSearchFiles(...)`):
  - `search-index.json` — compact term postings + document/chunk refs, loaded on
    every search.
  - `search-content.json` — chunk text, kept separate and loaded lazily so the
    index stays cheap.
- **Heading-aware chunking** — each page is sliced into chunks per heading, so
  results jump to the right section (`urlWithHash`, `headingPath`).
- **Runtime query via `searchDocs(index, query, options)`** — pure, edge-safe,
  uses no Node APIs. Runs in server routes, edge functions, or the browser.
- **Built-in query intelligence already included:** stemming, prefix matching,
  typo-tolerant fallbacks, and a small built-in synonym map. Product-specific
  synonyms can be added via the `synonyms` option without any new infrastructure.
- **Ready-made UI hooks** for React/Next, Vue, and Svelte (plus a vanilla
  client), with debouncing and loading state handled.
- **Optional source-grounded AI answers** (`createAnswerContext` /
  `streamDocsAnswer`) layer *on top of the same static index* — the model is
  constrained to retrieved context with citations. This already provides the "RAG"
  experience without a vector store.

In other words, retrieval is keyword/BM25 over a static, pre-built index that
loads locally. There is no server-side vector database in the default path.

## 2. When adding embeddings is actually warranted — and what to keep

Per leadtype's own guidance, **start with the local lexical index** because it is
static, cheap, edge-safe, and precise for the things docs search is mostly used
for: API names, config keys, error messages, and paths. Exact-match lookups are
exactly where BM25 shines and where pure vector search tends to get fuzzy.

Add embeddings **only** when one of these specific conditions holds:

- **Vocabulary mismatch:** users search with words/phrasing the docs don't
  actually use (semantic/synonym gap that the built-in synonym map and custom
  `synonyms` aliases can't reasonably cover).
- **Scale:** the corpus grows past **tens of thousands of chunks**, where lexical
  recall starts to degrade.

And even then, the rule is **keep the lexical index** — don't replace it:

- Retain BM25 for exact matches (API names, config keys, error strings, paths).
- **Layer embeddings on top** of the lexical index rather than swapping it out.

### Practical recommendation for the team

Before standing up a hosted, DB-backed vector index, ship the default static
search first. It costs almost nothing to run and likely covers our needs. Try the
cheaper levers (custom `synonyms`, the existing typo/stemming/prefix handling)
when recall gaps appear. Reach for embeddings only once we can point to a real
vocabulary-mismatch problem or a corpus in the tens-of-thousands-of-chunks range
— and even then, keep the lexical index as the exact-match layer underneath.

---

*Sources: `leadtype/docs/reference/search.md` ("When to add embeddings",
"Vocabulary", build/runtime API) and `leadtype/docs/search/add-search.md`
("Leadtype search is static by default… no database, edge-safe").*
