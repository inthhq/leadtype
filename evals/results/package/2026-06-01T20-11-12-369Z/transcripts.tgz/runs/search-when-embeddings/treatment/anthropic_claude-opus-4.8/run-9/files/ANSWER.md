# Does `leadtype` already give us docs search?

Yes. Before standing up a hosted, database-backed vector index, here's what
`leadtype` ships out of the box.

## 1. What leadtype's docs search uses by default

**Leadtype search is static and lexical by default — no database, no embeddings,
no server required.**

At build time, `leadtype generate` (or `generateDocsSearchFiles` from
`leadtype/search/node`) emits two JSON files:

- `public/docs/search-index.json` — compact term postings + document/chunk refs;
  loaded on every search.
- `public/docs/search-content.json` — chunk text, kept separate so the index
  stays cheap and content loads lazily (for excerpts/answers).

Key properties of the default:

- **Ranking is BM25**, a lexical ranking function, with field weights:
  title 4×, headings 2×, body 1×, code 0.35×.
- **Heading-aware chunking** — each chunk is its own document, so results jump
  straight to the right section (hash URLs / heading paths).
- **Runtime is edge-safe** — `searchDocs(index, query, { content })` uses no
  Node APIs and runs locally; no database round-trip.
- It already does **stemming, prefix matching, typo-tolerant fallbacks, and a
  built-in synonym map**, with optional product-specific synonym aliases.
- Framework hooks (`leadtype/search/react`, `/vue`, `/svelte`, `/client`,
  `leadtype/next/client`) load the two JSON files by collection name and manage
  debouncing/loading state.

In short, this is **precise for the things developers actually search**: API
names, config keys, error messages, and paths — and it's static, cheap, and
fast. **We do not need to build a hosted vector index to have working docs
search.**

## 2. When adding embeddings is actually warranted — and what to keep

Per leadtype's own guidance ("When to add embeddings"), start with the local
index and add embeddings **only** when one of these specific conditions holds:

1. **Users search with vocabulary the docs don't use** — i.e., a semantic gap
   that synonym aliases can't reasonably cover. (First try the built-in
   stemming/synonyms and `searchDocs(..., { synonyms })` aliases.)
2. **The corpus grows past tens of thousands of chunks**, where lexical recall
   starts to degrade.

**Even then, keep the lexical (BM25) index for exact matches and layer
embeddings on top of it** — don't replace it. Exact-match needs (API names,
config keys, error strings, file paths) are exactly where lexical search wins
and embeddings are weakest.

### Recommendation

Neither condition is "because that's how RAG is done." Unless we can point to a
real vocabulary mismatch or a corpus in the tens-of-thousands-of-chunks range,
the hosted, database-backed vector index is premature. Adopt leadtype's static
lexical search now; revisit embeddings only against the two conditions above,
and even then keep BM25 as the base layer.
