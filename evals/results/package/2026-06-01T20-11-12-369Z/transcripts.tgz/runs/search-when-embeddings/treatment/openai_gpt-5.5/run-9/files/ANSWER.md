# Leadtype docs search and embeddings

## What leadtype uses by default

Leadtype docs search is **static lexical search**, not a hosted vector database.

By default, `leadtype generate` in site mode writes two static files:

- `public/docs/search-index.json` — a compact BM25-style inverted index and chunk references.
- `public/docs/search-content.json` — chunk text, kept separate so the index stays small and content can be loaded lazily for excerpts or AI answers.

At runtime, Leadtype loads those JSON files and queries them locally with `searchDocs` or the framework hooks (`leadtype/search/react`, `leadtype/search/vue`, `leadtype/search/svelte`, etc.). This is designed to be **database-free** and **edge-safe**.

The ranking is BM25 over heading-aware chunks. Leadtype weights fields roughly as:

- title: 4×
- headings: 2×
- body: 1×
- code: 0.35×

It also already includes practical lexical-search behavior such as stemming, prefix matches, typo-tolerant fallbacks, and a small built-in synonym map. Product-specific synonyms can be added when users search with terms the docs do not use.

Leadtype's AI answer path also starts from this same static index: `searchDocs` retrieves relevant chunks, `createAnswerContext` builds a constrained, citation-oriented prompt from those chunks, and `streamDocsAnswer` streams a source-grounded response. That is RAG-style retrieval, but it does not require embeddings by default.

## When embeddings are actually warranted

Do **not** add a hosted, database-backed vector index just because the feature is called RAG. Leadtype's guidance is to start with the local static index because it is cheap, precise, edge-safe, and especially good for docs queries involving API names, config keys, error messages, paths, and exact terminology.

Add embeddings only when one of these is true:

1. **Users search with vocabulary the docs do not use**, and synonyms/lexical tuning are not enough.
2. **The corpus grows past tens of thousands of chunks**, where a purely static local index may no longer be the right retrieval layer by itself.

Even then, keep Leadtype's lexical index. Use embeddings as an additional semantic layer, not a replacement. The BM25/lexical index should remain available for exact matches, identifiers, config names, errors, code terms, paths, and as the precise source-retrieval layer that feeds answers and citations.
