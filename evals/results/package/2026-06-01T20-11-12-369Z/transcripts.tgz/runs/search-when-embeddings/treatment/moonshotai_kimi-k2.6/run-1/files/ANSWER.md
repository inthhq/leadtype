# Leadtype Docs Search: Default Behavior & When to Add Embeddings

## 1. What leadtype uses by default

Leadtype ships a **static, edge-safe lexical search index** — no database, no vector store, and no hosted inference required.

- **Algorithm:** BM25 ranking over heading-aware chunks.  
  Weights: `title 4×`, `headings 2×`, `body 1×`, `code 0.35×`.
- **Artifacts:** `leadtype generate` produces two JSON files at build time:
  - `search-index.json` — compact term postings + document/chunk refs (loaded on every search).
  - `search-content.json` — chunk text (loaded lazily for excerpts/answers).
- **Runtime:** The query engine runs entirely in the browser or edge worker — no network round-trip to a search service. It supports stemming, prefix matches, typo-tolerant fallbacks, and a small built-in synonym map.
- **Result shape:** Page URL, heading path, hash link, score, and excerpt.

In short, the default is a **client-side / edge-side BM25 index**, not embeddings.

## 2. When adding embeddings is actually warranted

Per the leadtype reference docs, you should consider embeddings **only** when:

1. **Users search with vocabulary the docs don't use** (semantic gap / synonymy beyond the built-in map).
2. **The corpus grows past tens of thousands of chunks** (BM25 may start to miss broader conceptual matches at scale).

### What to keep even then

Even if you add embeddings, **keep the existing lexical BM25 index**:

- Use BM25 for exact matches (API names, config keys, error messages, file paths).
- **Layer embeddings on top** — treat them as a semantic retrieval enhancement, not a replacement.

This hybrid approach preserves the precision and speed of lexical search for the queries where it already excels, while embeddings fill the semantic-gap cases where BM25 alone falls short.

## Bottom line for the team

Before standing up a hosted, database-backed vector index, recognize that leadtype already gives you a fast, precise, zero-ops search system out of the box. The conditions that justify embeddings are specific — vocabulary mismatch or very large corpus size — and even then the default BM25 index remains a critical component of the search stack.
