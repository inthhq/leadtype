# Leadtype Docs Search & Embeddings Analysis

This document describes the capabilities of the default search system in `leadtype` and the specific conditions under which transitioning or adding embeddings is warranted.

---

### 1. Leadtype's Default Docs Search System

By default, `leadtype` uses a **static, edge-safe, lexical search engine** built directly into the generated site. It operates purely locally or at the edge, requiring **no database** or server-side infrastructure.

#### How It Works:
* **Build-Time Generation**: Running the pipeline (e.g., `leadtype generate`) analyzes your MDX source files and produces two static, compact JSON files:
  * **`search-index.json`**: Contains the compact term postings and document/chunk references used for indexing and ranking. It is small and loaded immediately on every search.
  * **`search-content.json`**: Holds the raw chunk text. It is stored separately to keep the main search index small and is loaded lazily only when needed for rendering excerpts or streaming AI answers.
* **Granular Chunking**: Documents are split into **heading-aware slices (chunks)**. Each chunk behaves as a separate document, enabling users to jump directly to the precise heading or section hash matching their query.
* **Lexical Ranking (BM25)**: Ranking is computed using the **Okapi BM25** ranking function. It prioritizes exact matching terms and applies specific weights depending on where the term appears:
  * **Title**: 4× weight
  * **Headings**: 2× weight
  * **Body**: 1× weight
  * **Code**: 0.35× weight
* **Query Features**: It provides stemming, prefix matches, typo-tolerant fallbacks, and a built-in synonym map (which can be customized with custom synonym mapping options).
* **AI Grounding**: For generative AI answers (RAG), it acts as the retriever. It retrieves the most relevant chunks from the static BM25 index and builds a constrained system prompt with a 16 KB request limit and 12,000-character context limit, ensuring the LLM only answers based on retrieved context and cites its sources.

---

### 2. When are Embeddings Warranted (and What to Keep)?

While hosted vector databases and embeddings are popular for RAG, they introduce latency, hosting costs, and complexity. `leadtype` outlines specific guidelines for when they are actually necessary.

#### Conditions Under Which Embeddings are Warranted:
1. **Vocabulary Mismatch**: When users search using entirely different terms, phrasing, or synonyms that do not exist within the written documentation text (i.e., conceptual queries where exact keyword matching fails).
2. **Corpus Scale**: When the size of the documentation scales massively, specifically growing past **tens of thousands of chunks**.

#### What to Keep Even When Adding Embeddings:
If you decide to adopt embeddings, **do not discard the default lexical (BM25) search**. 

* **Why?** A purely semantic vector search is notoriously poor at finding exact keyword matches. Coding queries frequently involve precise technical vocabulary such as **API names, config keys, error messages, and file/module paths**. 
* **The Solution**: Keep the **lexical BM25 index** for precise exact-match lookup and **layer the embeddings on top** (a hybrid search approach). This combines the best of both worlds: semantic understanding for conceptual queries and absolute precision for technical identifiers.
