# Does `leadtype` already cover docs search? (Read before building a vector index)

Short version: **`leadtype` ships a complete docs search system out of the box, and it is deliberately *not* a hosted, database-backed vector index.** Standing one up before you've hit the conditions below is solving a problem you don't have yet.

## 1. What leadtype's docs search uses by default

Leadtype search is **static and lexical** — no database, no embeddings, no hosted service, and edge-safe.

- **Build step produces two JSON files** (`leadtype generate`, or `generateDocsSearchFiles` from `leadtype/search/node`):
  - `public/docs/search-index.json` — compact term postings + document/chunk references. Loaded on every search.
  - `public/docs/search-content.json` — the chunk text, kept separate so search stays cheap and content loads lazily (for excerpts/answers).
- **Ranking is BM25** (a classic lexical ranking function), with field weights: title 4×, headings 2×, body 1×, code 0.35×.
- **Documents are heading-aware chunks**, so a result links straight to the right section (`urlWithHash` / `headingPath`), not just the page.
- **Runtime query is `searchDocs(index, query, { content })`** from `leadtype/search`. It runs locally against the JSON — no Node APIs, so it works in server routes, edge functions, or fully client-side.
- **The matching is already smart:** stemming, prefix matches, typo-tolerant fallbacks, and a small built-in synonym map. You can add product-specific synonyms inline via the `synonyms` option when users search with words your docs don't use.
- **UI is provided:** framework hooks/clients for React (`leadtype/search/react`), Next App Router (`leadtype/next/client`), Vue (`leadtype/search/vue`), Svelte (`leadtype/search/svelte`), and vanilla (`leadtype/search/client`), each handling fetch, debounce, and loading state.
- **Optional AI answers layer on top of the same static index** (`createAnswerContext` / `streamDocsAnswer` for Vercel AI SDK, TanStack AI, or Cloudflare Workers AI). Retrieval comes from the lexical index; the model is constrained to only answer from the retrieved chunks and cite them. There are also read-only agent bash tools (`ls`/`cat`/`grep`/`rg` over a virtual `/docs`) and endpoint guards (query validation, body-size limits, rate limiting).

**Implication for the proposed plan:** the "hosted, database-backed vector index" is exactly what leadtype intentionally avoids. The default already gives you precise search, an answers pipeline, and UI with zero infrastructure to operate. Most teams never need more than this.

## 2. When adding embeddings is actually warranted — and what to keep

Per leadtype's own guidance, **start with the local lexical index**. It is static, cheap, edge-safe, and precise exactly where it matters most: API names, config keys, error messages, and file paths — terms a semantic/embedding model often blurs.

Add embeddings **only** when one of these specific conditions holds:

1. **Vocabulary mismatch:** users consistently search with words your docs don't use, *and* you've already exhausted the cheaper fix — the built-in synonym handling plus custom `synonyms` aliases — without success.
2. **Scale:** the corpus grows past **tens of thousands of chunks**, where lexical recall starts to genuinely degrade.

Even when you do add embeddings:

- **Keep the lexical index.** It remains the reliable path for exact matches (API names, keys, errors, paths) that embeddings handle poorly.
- **Layer embeddings on top of it** (hybrid retrieval), rather than replacing it.

So before building any vector infrastructure, confirm you're actually hitting condition (1) or (2). If you are, the move is to *add* a semantic layer alongside leadtype's existing static index — not to swap leadtype's search out for a hosted vector database.
