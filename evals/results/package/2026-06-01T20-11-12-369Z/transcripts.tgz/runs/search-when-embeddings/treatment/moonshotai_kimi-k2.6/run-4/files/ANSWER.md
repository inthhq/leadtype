# What `leadtype` already gives us for docs search

## 1. What leadtype uses by default

`leadtype` ships a **static, edge-safe lexical search** — no database, no vector index, and no embeddings required.

- **Build-time**: `leadtype generate` (or `generateDocsSearchFiles`) emits two JSON artifacts:
  - `search-index.json` — a compact BM25-ranked inverted index over headings, titles, body text, and code.
  - `search-content.json` — the chunk text stored separately so the index stays small and can be loaded lazily.
- **Runtime**: the index is queried locally in the browser or at the edge via `searchDocs` or the framework hooks (`useLeadtypeSearch`, `createSearchClient`, etc.). There is no network round-trip to a search service or vector DB.
- **Ranking**: BM25 with field weights — **title 4×, headings 2×, body 1×, code 0.35×**.
- **Query features out of the box**: stemming, prefix matches, typo-tolerant fallbacks, and a small built-in synonym map.
- **Precision**: it is intentionally strong at exact matches for API names, config keys, error messages, and file paths.

In short, the default is a **static BM25 index**, not a hosted vector database.

## 2. When adding embeddings is actually warranted — and what to keep

Per the `leadtype` reference docs, you should consider adding embeddings **only** under these two specific conditions:

1. **Vocabulary mismatch** — users search with words or concepts that do not appear in the docs (semantic gaps that lexical search cannot bridge).
2. **Corpus scale** — the docs grow past **tens of thousands of chunks**, where a pure lexical index starts to miss broader conceptual relationships.

**Even then, keep the lexical index.** The guidance is to:

- **Retain the BM25 index** for exact matches (API names, paths, config keys, error strings).
- **Layer embeddings on top** as a secondary retrieval signal — a hybrid approach, not a replacement.

So before standing up a hosted, database-backed vector index, the default static BM25 search is already edge-safe, cheap, and precise for the majority of docs-search use cases.
