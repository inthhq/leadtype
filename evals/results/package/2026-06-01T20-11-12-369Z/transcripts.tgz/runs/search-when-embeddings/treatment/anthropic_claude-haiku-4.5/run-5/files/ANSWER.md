# What Leadtype Gives You for Docs Search

## 1. Default Docs Search: Static BM25 Index

By default, **leadtype uses a static, locally-queryable BM25 search index** — no database, no embeddings, no external APIs required at query time.

### How it works:

- **Build time** — `generateDocsSearchFiles()` reads your markdown and produces two JSON files:
  - `search-index.json` — compact term postings with document/chunk references (loaded on every search)
  - `search-content.json` — chunk text stored separately for lazy loading (fetches only when you need excerpts or answers)

- **Chunks** — pages are split heading-by-heading so search results jump to the right section, not just the page.

- **Ranking** — BM25 weighting:
  - Title: 4×
  - Headings: 2×
  - Body: 1×
  - Code: 0.35×

- **Runtime** — edge-safe, no database:
  - Client-side in browsers via `useLeadtypeSearch()` (React, Vue, Svelte, Next.js)
  - Server-side via `searchDocs()` with the JSON files in memory
  - No dependencies on external services for search itself

### Built-in capabilities (no config required):

- Stemming and prefix matching
- Typo-tolerant fallback
- Small built-in synonym map
- Product-specific synonyms can be added at query time
- Results include page URL, heading path, hash anchor, and (optionally) excerpt snippets

### Framework hooks provided:

- React: `useLeadtypeSearch("docs")`
- Next.js App Router: `useLeadtypeSearch("docs")` from `leadtype/next/client`
- Vue: `useLeadtypeSearch("docs")`
- Svelte: `createLeadtypeSearch("docs")`
- Vanilla JS: `createSearchClient("docs")`

---

## 2. When Embeddings Actually Make Sense

**Start with the local BM25 index.** It's static, cheap, edge-safe, and precise for exact matches. Add embeddings **only** when:

1. **Users search with vocabulary your docs don't use** — when the semantic gap between query language and your actual content is real and persistent (not a one-off synonym issue).

2. **Corpus exceeds tens of thousands of chunks** — the static index stays performant, but re-ranking or semantic relevance becomes harder to achieve lexically.

### Critical constraint: Keep the lexical index even when adding embeddings

**Do not replace BM25 with embeddings alone.** Instead:

- Use BM25 as the primary retrieval mechanism
- Layer embeddings on top as a **re-ranker** or **semantic fallback** for cases where exact term matching fails
- Always keep the static index for:
  - API names, config keys, error messages, paths — exact matches are fastest and most correct
  - Zero-latency, offline-capable search in contexts where external APIs are unavailable
  - Cost efficiency (no embedding model API calls for every search)

### What to expect if you do add embeddings:

- **Cost**: Every search query calls an embedding API (e.g., OpenAI embeddings API)
- **Latency**: Network round-trip to generate query embedding + vector search
- **Maintenance**: Database setup, periodic re-indexing, API key management
- **Benefit**: Better results when terminology diverges (e.g., users say "setup" but docs say "installation"; users say "crash" but docs say "panic")

### Pattern: Hybrid search

The best practice is **hybrid**: use BM25 for the first pass, then:
1. Retrieve the top N lexical results
2. Re-rank with embeddings similarity
3. Return the combined ranked set

This gives you precision on known terms + semantic understanding when vocabulary diverges, without replacing your static infrastructure.

---

## Summary

**By default**: A static, edge-safe BM25 search index built at your docs site's build time. No database, no embeddings, no external APIs at query time. Precise for API references, error messages, and exact config key lookups.

**Add embeddings when**: Users consistently search using different words than your docs contain, *and* your corpus has grown large enough that the BM25 signal is genuinely weak. Even then, keep the BM25 index as your primary retrieval layer and use embeddings as a re-ranker or fallback.
