# Leadtype docs search: do we need a hosted vector index?

## 1. What leadtype uses by default

Leadtype's docs search is **static and lexical by default**, not database-backed.

At build time, `leadtype generate` / `generateDocsSearchFiles()` writes two JSON artifacts:

- `public/docs/search-index.json` — compact ranking data / inverted index
- `public/docs/search-content.json` — chunk text, kept separate so content can load lazily for excerpts and answers

At runtime, the app loads those files and queries them locally with `searchDocs()` or through the provided React/Vue/Svelte/vanilla client helpers. There is no hosted search service, no database, and no vector store required; the runtime is edge-safe.

The ranking model is **BM25** over heading-aware chunks. Leadtype weights fields as:

- title: 4×
- headings: 2×
- body: 1×
- code: 0.35×

The built-in search is designed to work well for docs-shaped queries: API names, config keys, error messages, file paths, section names, guide phrases, and code-ish terms. It also includes stemming, prefix matches, typo-tolerant fallbacks, and a small built-in synonym map. Product-specific synonyms can be added without introducing embeddings.

Leadtype can also stream AI answers on top of this same static index: `searchDocs` retrieves relevant chunks, `createAnswerContext` builds a constrained prompt from those chunks, and `streamDocsAnswer` streams a source-grounded answer with citations. So the default path already supports retrieval-augmented answers without needing a vector database.

## 2. When embeddings are actually warranted

Start with Leadtype's local BM25 index. Add embeddings only if one of these conditions is true:

1. **Users search with vocabulary the docs do not use.**  
   Example: users consistently ask conceptual or alternate-language questions whose terms do not appear in the docs, and simple product-specific synonyms are not enough.

2. **The corpus grows past tens of thousands of chunks.**  
   At that scale, a hybrid retrieval layer may become useful for broader semantic recall or ranking.

Even then, embeddings should be **layered on top of**, not used as a replacement for, Leadtype's lexical index. Keep the BM25/static index for exact matches — API names, config keys, error strings, paths, headings, and code identifiers are often better served by lexical search than semantic similarity. Also keep the existing source-grounded answer flow: retrieve documented chunks, constrain the model to those chunks, cite sources, and keep endpoint guards/rate limits around paid model calls.
