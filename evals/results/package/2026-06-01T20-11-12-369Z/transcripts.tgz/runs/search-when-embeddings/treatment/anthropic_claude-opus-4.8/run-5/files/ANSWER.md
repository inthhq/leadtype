# Docs search with `leadtype`: what we already have

TL;DR: Before standing up a hosted, DB-backed vector index, know that
`leadtype` already ships a complete docs search that needs **no database and no
embeddings**. For most docs corpora, that's the right answer — and even when
embeddings are warranted, you keep the existing index, you don't replace it.

## 1. What leadtype's docs search uses by default

Leadtype search is **static and lexical by default** — no database, no
embedding service, edge-safe.

**How it's built and queried**

- At build time, `leadtype generate` (or `generateDocsSearchFiles`) emits two
  JSON files:
  - `public/docs/search-index.json` — compact term postings + document/chunk
    refs. Loaded on every search.
  - `public/docs/search-content.json` — the chunk text, kept separate so search
    stays cheap and content loads lazily (for excerpts/answers).
- Pages are split into **heading-aware chunks**, so a result links straight to
  the relevant section (page URL + heading path + hash URL).
- At runtime, `searchDocs(index, query, { content })` queries the JSON locally.
  The runtime uses **no Node APIs**, so it runs in server routes, the browser,
  or the edge.
- Framework hooks (`leadtype/search/react`, `/vue`, `/svelte`, `/client`, and
  `leadtype/next/client`) fetch the two JSON files by collection name, debounce
  input, and manage loading state for a search box.

**The ranking and matching engine**

- Ranking is **BM25** (a classic lexical/keyword ranker), with field weights:
  title 4×, headings 2×, body 1×, code 0.35×.
- Out of the box it already does **stemming, prefix matching, typo-tolerant
  fallbacks, and a small built-in synonym map**.
- You can add product-specific **vocabulary aliases** (`synonyms: { ... }`) when
  users search with words your docs don't use — a config change, not new
  infrastructure.

**Optional layer on the same index**

- AI answers (`streamDocsAnswer` / `createAnswerContext`) and agent bash tools
  (`ls`/`cat`/`grep` over a virtual read-only `/docs`) are built **on top of the
  same static index** — retrieval still comes from the lexical index; the LLM is
  constrained to cite only retrieved chunks. This is still not a vector DB.

So the default already covers what teams usually reach for "RAG" to do:
chunking, retrieval, and grounded answers — using static files.

## 2. When adding embeddings is actually warranted (and what to keep)

Per leadtype's own guidance ("When to add embeddings" in the search reference),
start with the local lexical index because it is **static, cheap, edge-safe, and
precise for the things docs queries are usually made of**: API names, config
keys, error messages, and file paths. Exact-token matching beats semantic
similarity for those.

**Add embeddings only when one of these specific conditions holds:**

1. **Vocabulary mismatch** — users consistently search with words/phrasing your
   docs don't actually use, and synonym aliases aren't enough to bridge the gap.
2. **Scale** — the corpus grows past **tens of thousands of chunks**, where
   lexical recall starts to leave relevant material out.

If neither condition is true, a hosted vector index adds cost, operational
burden, and a database dependency without buying better results — and it tends
to be *worse* at exact API-name / error-string lookups.

**What to keep even then:**

- **Keep the lexical (BM25) index for exact matches.** Don't replace it.
- **Layer embeddings on top of it** (hybrid retrieval), so semantic recall is an
  addition, not a substitution. Exact identifiers keep resolving correctly while
  the embeddings catch paraphrased/conceptual queries.

### Recommendation for our team

Stand up the built-in static search first (it's effectively free and already
installed). Measure real query failures. Only if we hit a genuine vocabulary gap
that synonyms can't fix, or cross the tens-of-thousands-of-chunks threshold,
introduce embeddings as a hybrid layer *behind* the existing lexical index —
rather than building a hosted vector DB up front.
