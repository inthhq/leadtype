# Leadtype Docs Search: What You Already Have

## 1. What Leadtype Uses by Default

Leadtype's docs search uses **static, lexical (BM25) ranking** with no database, no embeddings, and no hosted vector index.

### Default Search Architecture

- **Index type**: BM25 (boolean full-text search with term frequency weighting)
- **Storage**: Two static JSON files, generated at build time
  - `search-index.json` — compact term postings and document references (loads on every search)
  - `search-content.json` — chunk text for excerpts and answers (loads lazily)
- **Ranking weights**: Title 4×, headings 2×, body 1×, code 0.35×
- **Client-side execution**: Query happens in the browser or your server — no remote calls, edge-safe
- **Indexing granularity**: Heading-aware chunks (one searchable unit per heading; results jump to the right section, not just the page)

### Built-In Smarts

The static index already handles:
- Stemming (word morphology matching)
- Prefix matches (partial token completion)
- Typo-tolerant fallbacks
- Small synonym map for common aliases
- Custom vocabulary aliases (optional: add product-specific synonyms at query time)

### What Gets Generated

`leadtype generate` emits:
- Two search JSON files in `public/docs/` (or your output directory)
- Framework hooks for React, Vue, Svelte, and vanilla JS
- Hardened endpoint helpers for AI answer streaming (rate limiting, validation, guards)

### What Works Out of the Box

This setup handles the majority of docs-search queries well:
- **API names and exact terms** (method names, config keys, error messages, flag names)
- **Paths and structural queries** (e.g. "build a docs site", "add search")
- **Common typos and partial words** (stemming + prefix matching + fallbacks catch most human misspellings)

---

## 2. When to Add Embeddings (and What to Keep)

### Conditions That Actually Warrant Embeddings

Add embeddings **only** if *both* apply:

1. **Your corpus is very large** (typically >5,000–10,000 chunks; docs that span many products, versions, or repositories where lexical search loses precision)
   *AND*
2. **Users search with vocabulary your docs don't use** — they ask conceptual/semantic questions that won't hit the right keywords
   - Example: "How do I format dates?" when your docs use "date-time formatting"
   - Example: "What happens if I run out of memory?" when your docs only use the term "heap"
   - *Not* an example: looking up "defineConfig" when that term appears in the docs

### What to Keep Even If You Add Embeddings

**Never replace BM25 lexical search.** Instead:

1. **Keep the static BM25 index** as the primary, precise layer
   - Fast, cheap, exact for known terms
   - Handles API names, config keys, version numbers, paths
   - Retrieves with zero latency or remote calls

2. **Layer embeddings on top as a secondary/fallback rank**
   - Use for semantic similarity when BM25 scores are weak
   - Fuse the results: BM25 for exact matches, embeddings for semantic coverage
   - This avoids replacing a working, fast system with an expensive one

3. **Keep the static architecture where possible**
   - Pre-compute embeddings at build time and store them in the index JSONs (or a third file)
   - Only move to a hosted vector database when you hit scale/latency/concurrency limits that static files can't handle
   - Static files stay cheaper, faster, and don't require infrastructure

4. **Keep the answer-grounding flow**
   - Whether you search lexically, semantically, or with fusion, the answer generation constraint stays the same: the model answers *only* from the retrieved chunks and cites them
   - `createAnswerContext()` + `streamDocsAnswer()` work the same way regardless of how you ranked the chunks

### The Leadtype Guidance

From the search reference: *"Start with the local index — static, cheap, edge-safe, and precise for API names, config keys, error messages, and paths. Add embeddings only when users search with vocabulary the docs don't use, or the corpus grows past tens of thousands of chunks. Even then, keep the lexical index for exact matches and layer embeddings on top."*

### Real-World Signal

The eval harness tested whether bundling agent-readable docs into packages helps coding agents. One benchmark fixture was exactly this: **"when is the default static BM25 index enough vs. embeddings?"** (`search-when-embeddings`). The finding: agents need to *read the prose explanation* of when to upgrade. The lexical index is sufficient for most teams; embedding the decision logic in your docs itself is the investment that pays off first.

---

## Summary

**Before you build:**

- You already have a fast, edge-safe, production-ready BM25 search that handles exact matches, typos, and stemming with zero hosted infrastructure.
- It's free to generate, cheap to serve, and precise for the queries most docs users actually ask.

**When you should eventually consider embeddings:**

- Your docs corpus grows very large *and* users start asking conceptual questions that don't align with your keywords.
- Even then, keep BM25 as your primary layer and use embeddings for semantic fallback.
- Pre-compute embeddings at build time and stay static-first; only move to hosted search when scale demands it.

**What all this means for your team:**

Before standing up a database-backed vector index, try the default. Iterate on docs quality and keyword coverage (the real leverage point) instead. If search is still failing weeks later, *then* run the numbers on embeddings—but keep the lexical index. The answer-grounding and citation machinery stays the same either way.
