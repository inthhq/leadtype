# Leadtype's Default Docs Search

## 1. What Leadtype Uses by Default

**BM25 lexical search** on a **static, local JSON index**.

### Build Time
- `generateDocsSearchFiles()` reads markdown docs and produces two compact JSON files:
  - `search-index.json` — term postings, document references, and ranking data
  - `search-content.json` — chunk text for excerpts (loaded lazily)

### Runtime Query
- `searchDocs(index, query)` executes client-side in JavaScript (edge-safe, no database)
- Uses **BM25 ranking** with semantic weighting:
  - Title: 4× weight
  - Headings: 2× weight  
  - Body text: 1× weight
  - Code: 0.35× weight
- Built-in stemming, prefix matching, typo tolerance, and small synonym map
- Results are heading-aware chunks (not whole pages), so users jump directly to the relevant section

### Zero Infrastructure
- Static files deployed with your site
- No server, no database, no cold starts
- Precise for API names, config keys, error messages, and paths

---

## 2. When to Add Embeddings — and What to Keep

### The Condition: Add Embeddings When
1. **Users search with vocabulary the docs don't use** — they think "quickstart" but the docs say "getting started"
2. **Corpus grows past tens of thousands of chunks** — lexical search becomes less efficient

### What to Keep (Even With Embeddings)
**Keep the BM25 lexical index.** Don't replace it.

- Exact matches are fast and precise
- Layer embeddings **on top** of the static index
- Use embeddings to surface conceptually similar content that lexical search misses
- The static index still handles the common, high-confidence queries

### Why
The default approach is already solving the hard parts: cheap, instant, reliable matching for concrete terms (function names, config keys, error codes). Embeddings are expensive ($, latency, hallucination risk) and slower to iterate on. Only add them for the gap they fill—semantic similarity across vocabulary—and only when that gap is actually costing you.
