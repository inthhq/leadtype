# Docs search with `leadtype`: do we need a hosted vector index?

Short answer: **not by default, and probably not at all for most teams.** `leadtype`
ships a static, local search index that already covers the common docs-search cases
without any database or hosted service. A hosted, DB-backed vector index is only
warranted under specific conditions, and even then you keep the existing index.

## 1. What leadtype's docs search uses by default

Leadtype docs search is **static and lexical by default** — no database, no embeddings,
no hosted index, and edge-safe.

- **Build time** produces two JSON files (`leadtype generate`, or
  `generateDocsSearchFiles` from `leadtype/search/node`):
  - `public/docs/search-index.json` — compact term postings + document/chunk refs;
    loaded on every search.
  - `public/docs/search-content.json` — chunk text, loaded lazily for excerpts/answers
    (kept separate so search stays cheap).
- **Ranking** uses **BM25** (a classic lexical ranking function), with field weights:
  title 4×, headings 2×, body 1×, code 0.35×.
- **Chunking** is heading-aware: each heading-scoped slice of a page is its own
  document, so results jump straight to the right section (hash URLs).
- **Runtime query** is `searchDocs(index, query, { content })` — pure, edge-safe, no
  Node APIs and no network calls. Results carry `title`, `urlPath`, `urlWithHash`,
  `headingPath`, `score`, and (with content) `excerpt`.
- **Quality features built in**: stemming, prefix matching, typo-tolerant fallbacks,
  and a small built-in synonym map. You can add product-specific synonyms via the
  `synonyms` option when users search with words the docs don't use.
- **UI** is wired with framework hooks (`leadtype/search/react`, `/vue`, `/svelte`,
  `/client`, and `leadtype/next/client`) that load the JSON files by collection name,
  debounce input, and manage loading state.

Optional **AI answers** (`leadtype/search/{vercel,tanstack,cloudflare}`) layer on top of
this *same static index*: `searchDocs` retrieves chunks, `createAnswerContext` builds a
constrained, citation-grounded prompt, and `streamDocsAnswer` streams the response.
Importantly, this still does **not** require embeddings or a vector DB — retrieval is the
lexical index.

**Takeaway:** the default already gives us serving without infrastructure (static JSON on
a CDN/edge), and it is precise for the things developer docs are mostly searched by —
API names, config keys, error messages, and file paths — which is exactly where lexical
search outperforms fuzzy semantic matching.

## 2. When adding embeddings is actually warranted — and what to keep

Per leadtype's own guidance, start with the local index (static, cheap, edge-safe,
precise). Add embeddings **only** when one of these specific conditions holds:

- **Vocabulary mismatch:** users routinely search with words/phrases that the docs
  don't actually use, so lexical + synonyms can't bridge the gap (semantic similarity
  would help). Note: the cheaper first move here is adding entries to the built-in
  `synonyms` map, not standing up a vector store.
- **Corpus scale:** the documentation grows past **tens of thousands of chunks**, where
  pure lexical ranking starts to lose recall.

If neither is true, the hosted vector index is unjustified overhead — it adds a database,
an embedding pipeline, hosting cost, and operational surface for no measurable retrieval
gain on our content.

**Even when embeddings are warranted, keep the lexical index.** The recommended
architecture is hybrid:

- Retain the static BM25 lexical index for **exact matches** (API names, config keys,
  error strings, paths) where semantic search is weaker.
- **Layer embeddings on top** of it rather than replacing it.

In other words: embeddings are an additive, conditional enhancement — not the default and
not a wholesale replacement for what `leadtype` already provides.

## Recommendation

Ship leadtype's default static search now (zero new infrastructure). If we later observe
real vocabulary-mismatch misses or cross the tens-of-thousands-of-chunks threshold, add a
hybrid embedding layer on top of — not instead of — the existing lexical index. Don't
build the hosted DB-backed vector index up front "because that's how RAG is done."

### Sources (from the installed `leadtype` package)
- `docs/search/add-search.md` — "static by default … no database, edge-safe"; the two
  JSON files; built-in stemming/prefix/typo/synonyms.
- `docs/reference/search.md` — BM25 weights, chunking, edge-safe runtime, and the
  explicit **"When to add embeddings"** guidance.
- `docs/search/ai-answers.md` — source-grounded answers built over the same static index.
