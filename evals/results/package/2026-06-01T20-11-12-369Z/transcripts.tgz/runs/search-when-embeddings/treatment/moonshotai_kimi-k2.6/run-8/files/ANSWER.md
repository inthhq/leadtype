# What `leadtype` already gives us for docs search

## 1. Default search behavior

`leadtype` uses a **static, edge-safe lexical index** by default — no database or hosted vector store is required.

- **Build-time output**: `leadtype generate` (or `generateDocsSearchFiles`) writes two JSON files:
  - `search-index.json` — compact term postings, document/chunk references, and BM25 ranking data.
  - `search-content.json` — the actual chunk text, loaded lazily only when excerpts or answers are needed.
- **Ranking**: BM25 with built-in weighting — **title 4×, headings 2×, body 1×, code 0.35×**.
- **Query features**: stemming, prefix matching, typo-tolerant fallbacks, and a small built-in synonym map.
- **Runtime**: `searchDocs` (and the framework hooks) load the JSON and query it locally. It is heading-aware (results jump to the relevant section hash) and returns URLs, heading paths, scores, and snippets.
- **AI answers**: The optional answer-streaming helpers (`streamDocsAnswer`, `createAnswerContext`) retrieve chunks from the **same static index** and constrain the model to cite only those chunks — still without embeddings.

## 2. When embeddings are warranted — and what to keep

Per the search reference, add embeddings **only** when:

1. **Users search with vocabulary the docs do not use** (semantic gap between query terms and doc terms).
2. **The corpus grows past tens of thousands of chunks** (scale where lexical matching alone starts to miss conceptual matches).

Even then, **keep the lexical BM25 index** for exact matches (API names, config keys, error messages, paths) and **layer embeddings on top** of it — do not replace the static index.
