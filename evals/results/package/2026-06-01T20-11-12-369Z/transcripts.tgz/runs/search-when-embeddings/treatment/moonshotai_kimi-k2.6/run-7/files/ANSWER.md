# What `leadtype` already gives us for docs search

## 1. What leadtype uses by default

`leadtype` docs search is **static and lexical** by default. At build time it produces two JSON files:

- `search-index.json` – compact term postings and document/chunk references
- `search-content.json` – the actual chunk text, loaded lazily

Runtime queries are executed locally with **BM25** ranking (title 4×, headings 2×, body 1×, code 0.35×). The search is edge-safe, requires no database or hosted vector service, and already includes stemming, prefix matching, typo-tolerant fallbacks, and a small built-in synonym map.

## 2. When adding embeddings is warranted — and what to keep

Add embeddings **only** when:

- Users search with vocabulary the docs do not actually use (semantic gap), **or**
- The corpus grows past tens of thousands of chunks.

Even then, **keep the lexical BM25 index for exact matches** (API names, config keys, error messages, paths) and **layer embeddings on top** of it rather than replacing it.
