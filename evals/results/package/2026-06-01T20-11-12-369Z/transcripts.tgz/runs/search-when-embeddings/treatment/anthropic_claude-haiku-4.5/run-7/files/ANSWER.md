# What Leadtype's Docs Search Gives You by Default

## 1. Default Search Mechanism

**Leadtype's docs search uses a static, locally-queryable BM25 index by default** — no database, no backend, no embeddings. Here's what you get:

### Two JSON files (built at generation time)
- **`search-index.json`** — compact term postings + document/chunk references. Loaded on every search.
- **`search-content.json`** — chunk text stored separately so search stays cheap and content loads lazily.

### BM25 ranking (not a vector model)
Leadtype ranks results using **BM25 with carefully tuned weights**:
- **Title**: 4× weight
- **Headings**: 2× weight
- **Body text**: 1× weight
- **Code blocks**: 0.35× weight

### Built-in linguistic smarts (stemming, prefix matching, typos)
The index includes:
- Stemming (so "running," "runs," "ran" all match "run")
- Prefix matching (so "config" matches "configuration")
- Typo-tolerant fallbacks
- A small built-in synonym map

### Edge-safe, client-side execution
- Pure JavaScript runtime — no Node APIs required
- Can run on edge networks (Vercel Edge, Cloudflare Workers, etc.)
- No secrets or rate-limiting headaches for the search itself

### Framework hooks ready to use
- **React**: `useLeadtypeSearch(collection)`
- **Vue**: `useLeadtypeSearch(collection)`
- **Svelte**: `createLeadtypeSearch(collection)`
- **Vanilla**: `createSearchClient(collection)`
- Direct API: `searchDocs(index, query, options)`

### Optional source-grounded answers
You can layer AI-powered answers on top using the same static index:
- Vercel AI SDK support
- TanStack AI support
- Cloudflare Workers AI support
- Model answers only from retrieved chunks (source-grounded)
- Built-in request guards (rate limiting, query validation, etc.)

---

## 2. When Embeddings Are Warranted — And What to Keep

**Start with the lexical BM25 index.** It's precise, cheap, and proven. Add embeddings only in these specific scenarios:

### Conditions warranting embeddings:

1. **Users search with vocabulary the docs don't use**
   - Example: users say "configuration" but your docs always say "setup" or "initialize"
   - BM25 handles *some* semantic distance (through stemming + synonyms), but dense embeddings help when the conceptual mismatch is large
   - Try adding vocabulary aliases first: `{ starter: ["quickstart", "getting started"] }`

2. **Your corpus grows past tens of thousands of chunks**
   - BM25 scales well up to ~10,000 chunks
   - Beyond that, embedding-based retrieval can reduce latency and network payload
   - But this is a performance optimization, not a correctness issue

### What to keep even with embeddings:

**Always keep the lexical BM25 index.** Hybrid search (lexical + embedding) is stronger than either alone:

1. **For exact matches** — API names, config keys, error messages, file paths, URLs
   - BM25 finds these instantly; embeddings would waste latency and cost
   
2. **For recall** — some users will search terms that appear nowhere in the docs but are mentioned by name in titles and headings
   - BM25 catches these; embeddings can miss low-frequency terms

3. **For cost** — lexical search is free after build time; embeddings cost per query (model inference + vector storage lookups)

4. **For latency** — BM25 is local and edge-safe; embedding models and vector DBs add round-trips

5. **For determinism** — lexical search is reproducible; LLM ranking of top results varies

### The right architecture:

```
User query
  ↓
[1] BM25 lexical retrieval (fast, exact matches, always free)
  ↓
[2] If needed, embed + vector lookup for semantic matches (only when vocab gap is real)
  ↓
Merge & deduplicate results
  ↓
Return top K chunks for answer generation
```

This way:
- 80% of queries (API lookups, error messages, paths) stay cheap and instant
- Semantic searches get embeddings support without replacing BM25
- You measure the actual vocabulary gap before spending on infrastructure
- You keep the static index as a fallback when the embedding service is slow or down

---

## Summary

**Don't build a hosted vector DB yet.** Start with leadtype's static BM25 index—it's production-grade, edge-safe, and handles the vast majority of docs searches. Measure whether users actually search with vocabulary mismatches before moving to embeddings. When you do add embeddings, layer them *on top* of the lexical index, not instead of it.
