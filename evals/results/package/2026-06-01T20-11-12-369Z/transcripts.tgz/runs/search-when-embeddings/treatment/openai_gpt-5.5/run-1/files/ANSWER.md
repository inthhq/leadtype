# Leadtype docs search: do we need a hosted vector index?

## 1. What Leadtype uses by default

Leadtype's docs search is **static lexical search**, not a hosted vector database.

By default, `leadtype generate` in site mode writes two files:

- `public/docs/search-index.json` — a compact BM25 inverted index with ranking data.
- `public/docs/search-content.json` — chunk text stored separately and loaded lazily for excerpts or grounded answers.

At runtime, Leadtype loads those JSON files and queries them locally with `leadtype/search`. There is **no database**, no hosted search service, and no Node-only runtime requirement; the search runtime is edge-safe.

The index is chunk-based and heading-aware, so results can point at the right section of a page. Ranking is BM25 with these default field weights:

- title: 4x
- headings: 2x
- body: 1x
- code: 0.35x

Leadtype search also supports practical lexical-search behavior such as stemming, prefix matches, typo-tolerant fallbacks, a small built-in synonym map, and optional project-specific synonyms.

For AI answers, Leadtype layers source-grounded answer generation on top of the same static search index: retrieve relevant docs chunks first, then ask the model to answer with citations. That is already a RAG-style flow without requiring embeddings or a vector database.

## 2. When embeddings are actually warranted

Start with Leadtype's local static BM25 index. It is cheap, precise, fast, edge-safe, and especially strong for docs queries involving exact technical terms such as:

- API names
- config keys
- error messages
- file paths
- CLI flags
- code identifiers

Add embeddings only when one of these conditions is true:

1. **Users search with vocabulary the docs do not use.**  
   For example, users consistently describe concepts in different words than the product/docs terminology, and aliases or synonyms are not enough.

2. **The corpus grows past tens of thousands of chunks.**  
   At that scale, semantic retrieval may be useful as an additional recall layer.

Even then, we should **keep the lexical BM25 index**. Embeddings should be layered on top, not used as a replacement, because lexical search remains the right tool for exact matches, identifiers, paths, errors, and other high-precision docs queries.
