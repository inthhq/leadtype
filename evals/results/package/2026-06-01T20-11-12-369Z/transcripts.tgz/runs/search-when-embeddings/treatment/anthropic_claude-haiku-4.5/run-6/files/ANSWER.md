# Leadtype's Default Docs Search

## What Leadtype Gives You By Default

Leadtype provides **static, edge-safe, lexical (BM25) search** at zero hosting cost:

1. **Build time:** `generateDocsSearchFiles()` produces two compact JSON artifacts:
   - `search-index.json` — term postings and document references (ranks results via BM25)
   - `search-content.json` — chunk text for excerpts and answer context (loaded lazily)

2. **Runtime behavior:** Search happens in the browser or edge environment with no database:
   - Queries load the pre-built index and search locally
   - Heading-aware chunking means results point to specific sections
   - Ranking weights: titles 4×, headings 2×, body 1×, code 0.35× (BM25)
   - Includes built-in stemming, prefix matching, typo-tolerant fallbacks, and small synonym map

3. **Search UX features included:**
   - Framework hooks for React, Vue, Svelte, vanilla JS
   - Query debouncing (120ms default)
   - Lazy content loading (so you don't download all page text upfront)
   - Edge-safe runtime (no Node.js APIs)

4. **Optional answer layer:** On top of the static index, you can stream **source-grounded AI answers** (the retrieved chunks constrain the model's response and ensure citations). Works with Vercel AI SDK, TanStack AI, and Cloudflare Workers AI.

## When to Add Embeddings—and What to Keep

**Do NOT build a hosted, database-backed vector index first.** Start with the static lexical search.

### Add embeddings only when:

1. **Semantic vocabulary gap:** Users search with words your docs don't use. Examples:
   - Your docs say "rate limiting," but users ask "throttling"
   - Your docs call it "configuration," but users ask "setup" or "customize"
   - You cannot capture these with synonyms alone

2. **Corpus scale:** You have tens of thousands of chunks (not typical for product docs) and lexical precision becomes harder to maintain

### What to keep even after adding embeddings:

**Keep the static BM25 index.** Do not replace it. Instead, layer embeddings on top:

- **Lexical search handles what it does best:** exact API names, config keys, error messages, paths, and code. These are precise and don't need semantic understanding.
- **Embeddings handle what they do best:** conceptual queries, paraphrases, and vocabulary mismatches.
- **Hybrid ranking:** Fuse lexical + embedding scores. Lexical results act as a precision filter; embeddings expand recall. A query for "openssl certificate" should return exact matches first, then semantic neighbors if needed.

### The practical strategy:

1. **Ship BM25 search.** It's static, costs nothing to serve, loads edge-safe, and is precise for 90% of docs queries (especially API/reference content).
2. **Add custom synonyms** for the 1–2 vocabulary gaps you discover from logs.
3. **Only if logs show real gaps** at scale, add embeddings as a secondary retrieval channel (not a replacement).

This keeps your docs search fast, cheap, and maintainable—and avoids the operational burden of a hosted vector database for a problem you likely don't have yet.
