# What leadtype already gives us for docs search

## 1. What leadtype uses by default

Leadtype’s docs search is **static and lexical** — no database, no vector store, and no embeddings out of the box.

At build time (`leadtype generate`), it produces two JSON files:

- **`search-index.json`** — a compact, BM25-ranked inverted index over heading-aware page chunks. It is loaded on every search.
- **`search-content.json`** — the actual chunk text, kept separate so the index stays small and content can be loaded lazily for excerpts or AI answers.

The ranking weights are: **title 4×, headings 2×, body 1×, code 0.35×**.

At runtime, `searchDocs` (or the framework hooks like `useLeadtypeSearch`) queries that index directly in the browser or at the edge. The default setup also includes stemming, prefix matching, typo-tolerant fallbacks, and a small built-in synonym map.

## 2. When adding embeddings is actually warranted — and what to keep

According to the leadtype search reference, you should add embeddings **only** when either:

- Users search with **vocabulary that the docs themselves do not use**, or
- The corpus grows past **tens of thousands of chunks**.

Even then, the guidance is to **keep the lexical BM25 index for exact matches** (API names, config keys, error messages, paths) and **layer embeddings on top** of it — not replace it.
