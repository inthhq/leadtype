# What leadtype Already Gives You for Docs Search

## 1. Default Search Implementation

Leadtype provides **static, lexical search (BM25 ranking)** by default.

### What that means:
- **At build time**: `leadtype generate` produces two JSON files:
  - `search-index.json` — compact term postings (loaded on every search)
  - `search-content.json` — chunk text (loaded lazily for excerpts/answers)
  
- **At runtime**: Search happens entirely client-side or in-process via `searchDocs()`:
  - Zero database required
  - No external API calls to rank results
  - Edge-safe; works in serverless/Cloudflare Workers
  - Users query locally-stored JSON files

### Search quality features built-in:
- **BM25 ranking** with intelligent weighting: title 4×, headings 2×, body 1×, code 0.35×
- **Chunk-aware indexing**: pages split at headings so results jump to the right section
- **Stemming** for morphological matching (e.g., "running" matches "run")
- **Typo-tolerant fallbacks** for misspellings
- **Prefix matching** for partial terms
- **Built-in synonym map** for common aliases
- **Vocabulary aliasing**: teams can add product-specific synonyms at query time

### Output to users:
- Result pages with URLs, heading paths, hash anchors for deep-linking
- Excerpts (when content store is available)
- Precise ranking for API names, config keys, error messages, and file paths

---

## 2. When Embeddings Are Actually Warranted

**Embeddings become justified only if both conditions hold:**

1. **Users search with vocabulary the docs don't explicitly use**, AND
2. **The corpus exceeds tens of thousands of chunks**

### Even when adding embeddings, keep the lexical index

The BM25 index should remain as the **primary search layer** because it excels at:
- **Exact matches** for API names, error messages, config keys, and paths
- **Phrase searches** where word order matters
- **Cost and latency** — no external embedding model calls
- **Precision** — no hallucination risk from vector similarity

### The layered approach:
- Query the **lexical index first** for results (fast, cheap, precise)
- Fall back to or **layer embeddings on top** for semantic discovery (only when lexical misses)
- Never replace BM25; augment it

This hybrid strategy is already the industry best practice and keeps the system maintainable without adding infrastructure overhead until it's proven necessary.

---

## Key Insight

Before building a hosted vector database, your team already has:
- A production-ready, static search system
- Framework hooks for React, Vue, Svelte, vanilla JS
- Rate-limited answer streaming that cites sources correctly
- Zero infrastructure cost for basic search

The default is already "how RAG should work" — grounded retrieval with no hallucination. Embeddings are a **scaling tool for semantic discovery**, not a prerequisite.
