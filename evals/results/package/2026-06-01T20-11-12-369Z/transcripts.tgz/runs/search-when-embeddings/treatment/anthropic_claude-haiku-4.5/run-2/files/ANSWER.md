# Leadtype's Default Search & When to Add Embeddings

## What Leadtype Provides by Default

Leadtype's docs search uses **BM25 (lexical ranking)** — a proven, static, locally-queryable approach:

- **Index type**: BM25 with custom weights (title: 4×, headings: 2×, body: 1×, code: 0.35×)
- **Storage**: Two JSON files built at generation time
  - `search-index.json` — compact term postings + document/chunk references (loaded on every search)
  - `search-content.json` — actual chunk text for excerpts/answers (loaded lazily)
- **Runtime**: Edge-safe, client-side JavaScript that queries locally without a database or network call
- **Behavior**: Handles stemming, prefix matches, typo-tolerant fallbacks, and a small built-in synonym map
- **Chunking**: Heading-aware slicing so results jump to the exact section
- **No infrastructure required**: Static files served from any CDN or static host

This is precisely what most teams need — fast, accurate, and cheap.

## When Embeddings Are Actually Warranted

Add embeddings **only under these conditions**:

1. **Users search with vocabulary your docs don't use** — e.g., they say "starter" but your docs call it "quickstart" or "getting started" (though this is often solved with synonyms first)
2. **The corpus grows past tens of thousands of chunks** — at which point pure lexical search degrades and semantic similarity becomes valuable

## What to Keep Even If You Add Embeddings

**Do not replace the lexical index.** Keep BM25 as your foundation and layer embeddings on top:

- **Exact matches** (API names, config keys, error messages, file paths) are fast and precise with BM25 — embeddings add noise and latency
- **Hybrid search** — retrieve lexical matches first, then re-rank or supplement with embedding-based results
- The lexical index is static, requires no hosted service, works offline/locally, and is deterministic

The team's instinct to stand up a database-backed vector index is premature. Start with what leadtype gives you, measure real search quality problems, *then* consider embeddings as a supplement — not a replacement.
