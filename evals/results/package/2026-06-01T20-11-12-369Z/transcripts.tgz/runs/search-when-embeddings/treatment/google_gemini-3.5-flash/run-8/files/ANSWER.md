# Leadtype Docs Search & Embedding Analysis

## 1. Default Docs Search in Leadtype

By default, `leadtype` provides a **static, local, and edge-safe search pipeline**. It does not require a database, external search servers, or complex cloud infrastructure. 

### Build-Time Generation
During the build process (e.g., using `npx leadtype generate` or calling `generateDocsSearchFiles`), `leadtype` generates two lightweight JSON artifacts:
- **`search-index.json`**: Contains compact term postings, document references, and ranking metadata. This file is highly optimized and loaded on every search to perform instantaneous lookup.
- **`search-content.json`**: A separate content store containing chunk text. By separating raw text from the index, initial searches remain fast and cheap, and the actual content can be loaded lazily on-demand (e.g., for displaying excerpts, snippets, or feeding context to an LLM).

### Runtime & Query Mechanism
- **Fully Local & Edge-Safe**: The runtime runs entirely client-side or on edge functions with zero Node.js dependencies, database overhead, or network hops during a query.
- **Chunking Strategy**: Content is split into heading-aware slices (chunks), ensuring search results point and jump directly to the precise heading or section.
- **Default Ranking Function**: Uses **BM25**, a state-of-the-art probabilistic relevance ranking algorithm.
- **Field Weighting**: Out-of-the-box weights prioritize relevance:
  - **Title**: `4×`
  - **Headings**: `2×`
  - **Body**: `1×`
  - **Code**: `0.35×`
- **Query Preprocessing**: Comes built-in with stemming, prefix matching, typo-tolerant fallbacks, and a small built-in synonym map (which can be customized at runtime with product-specific synonyms).
- **Framework Tooling**: Ships with dedicated client hooks and primitives (for React, Next.js, Vue, Svelte, and Vanilla JS) that handle loading states, debouncing, and caching.

---

## 2. When are Embeddings Warranted (and What to Keep)

While vector embeddings and RAG are popular, introducing a hosted, database-backed vector search is not always appropriate or beneficial.

### When Embeddings are Actually Warranted
You should only consider adding vector embeddings under the following specific conditions:
1. **Vocabulary Divergence**: When users frequently search using conceptual queries or vocabulary that your documentation does not actually contain (and which cannot be easily handled by custom synonym mappings).
2. **Corpus Scale**: When your documentation grows extremely large, specifically **past tens of thousands of chunks**, making client-side index storage and local processing inefficient.

### What to Keep Even Then
Even if you introduce vector embeddings, you should **keep the lexical (BM25) index** intact and layer embeddings on top of it (e.g., using a hybrid search approach). 

**Why?**
The static BM25 index is highly precise and superior to embeddings for finding **exact matches** such as:
- Specific API names
- Configuration keys
- Command-line flags
- Error messages
- Filesystem paths

Vector embeddings frequently struggle with these precise, low-frequency technical tokens (often hallucinating or returning irrelevant pages based on conceptual similarity instead of the exact match), whereas lexical search handles them perfectly.
