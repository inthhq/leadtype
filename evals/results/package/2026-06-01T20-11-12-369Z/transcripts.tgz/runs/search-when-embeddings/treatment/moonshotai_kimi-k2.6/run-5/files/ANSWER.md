# Leadtype Docs Search: Default Behavior & When to Add Embeddings

## 1. What leadtype's docs search uses by default

By default, leadtype search is **static, lexical, and edge-safe** — no database or vector store is involved.

- **Ranking**: BM25 with built-in field weights:
  - **Title**: 4×
  - **Headings**: 2×
  - **Body**: 1×
  - **Code**: 0.35×

- **Build artifacts**: `leadtype generate` (or `generateDocsSearchFiles`) produces two JSON files:
  - `search-index.json` — compact term postings + document/chunk references (loaded on every search)
  - `search-content.json` — chunk text (loaded lazily for excerpts and AI answers)

- **Runtime behavior**: The index is queried locally in the browser, at the edge, or on a server. It is **stateless and database-free**.

- **Query features out of the box**:
  - Stemming
  - Prefix matching
  - Typo-tolerant fallbacks
  - A small built-in synonym map
  - Heading-aware chunking (results jump directly to the relevant section)

## 2. When adding embeddings is actually warranted

The leadtype docs are explicit: **start with the local BM25 index**. It is precise for exact matches like API names, config keys, error messages, and paths.

Add embeddings **only** when:

1. **Users search with vocabulary the docs don't use** (semantic mismatch between query terms and doc terminology).
2. **The corpus grows past tens of thousands of chunks** (scale where lexical recall alone may miss relevant conceptual matches).

### What to keep even then

- **Keep the lexical index** for exact matches.
- **Layer embeddings on top** of the existing static index rather than replacing it.
