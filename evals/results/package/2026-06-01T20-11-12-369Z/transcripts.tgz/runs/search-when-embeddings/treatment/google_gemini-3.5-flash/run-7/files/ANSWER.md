# Leadtype Docs Search Analysis

Based on the official `leadtype` documentation and codebase, here is a detailed breakdown of what `leadtype`'s search system provides by default, and when adding embeddings is actually warranted.

---

## 1. What Leadtype's Docs Search Uses by Default

By default, `leadtype` provides a **static, local, and edge-safe lexical search index**. It requires no database, no hosted vector index, and no network calls to run query execution. 

### Key Characteristics:
* **Build-Time Generation**: At build time, calling the generator writes two lightweight, static JSON files to the output directory (e.g., under `public/docs/`):
  1. `search-index.json`: A compact index storing term postings and document/chunk references. It is highly optimized and loaded on every search.
  2. `search-content.json`: A separate content store containing actual chunk text (heading-aware slices of pages). It is loaded lazily only when generating excerpts or AI answers to keep search fast and cheap.
* **Lexical Ranking Algorithm (BM25)**: It ranks search results using a custom BM25 implementation. To deliver highly precise results, it applies specific weights to different parts of the content:
  * **Title**: $4\times$ weight
  * **Headings**: $2\times$ weight
  * **Body**: $1\times$ weight
  * **Code**: $0.35\times$ weight
* **Heading-Aware Chunking**: Pages are sliced into "Chunks" based on headings, allowing search results to jump directly to the correct section (using URL hashes).
* **Robust Built-in Matchers**: Out of the box, the search client supports stemming, prefix matches, typo-tolerant fallbacks, and customizable product-specific synonym mapping.
* **Edge-Safe & Browser-Ready Client Hooks**: Integration is client-side or edge-safe. It provides lightweight framework-specific hooks (`leadtype/search/react`, `leadtype/next/client`, `leadtype/search/vue`, `leadtype/search/svelte`) that handle asynchronous fetching, preloading, input debouncing, and state management completely locally.

---

## 2. When Adding Embeddings is Warranted & What to Keep

According to `leadtype`'s guidelines, standing up a hosted vector database or using semantic embeddings is only warranted under very specific conditions:

### Specific Conditions for Adding Embeddings:
1. **Vocabulary Mismatch**: When users frequently search for concepts or topics using terminology, slang, or vocabulary that the documentation does not explicitly use.
2. **Corpus Scale**: When the size of the documentation corpus becomes extremely large, specifically growing **past tens of thousands of chunks**.

### What to Keep Even When Introducing Embeddings:
Even if you decide to layer on embeddings for semantic coverage, you should **keep the local lexical index**. 

* **Why?** The static lexical index is incredibly fast, cheap to run, fully edge-safe, and highly precise for exact keyword/token matches—such as **API names, configuration keys, error messages, and system/file paths**—which vector embeddings typically struggle to match with high accuracy.
* **The Strategy**: Layer embeddings *on top of* the existing lexical index (e.g., a hybrid search approach) rather than replacing it entirely, maintaining the lexical index to handle high-precision exact queries.
