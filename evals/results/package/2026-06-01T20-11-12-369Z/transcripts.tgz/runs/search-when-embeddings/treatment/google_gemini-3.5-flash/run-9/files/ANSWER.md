# Leadtype Docs Search: Architecture and Embedding Strategy

Before building a hosted, database-backed vector index for docs search, here is what `leadtype` already provides out of the box and how to evaluate if/when to add embeddings.

---

### 1. What Leadtype's Docs Search Uses by Default

By default, `leadtype` uses a **static, local, edge-safe lexical search pipeline** powered by a **BM25-ranked inverted index**. 

Key details of this default search implementation:
- **Build-Time Generation**: Running `leadtype generate` (in site mode) produces two compact, static JSON files in the public directory:
  - `search-index.json`: Contains compact term postings and document/chunk references. This is small and loaded on every search.
  - `search-content.json`: Contains the actual chunk text, separated from the index so that the main index remains extremely lightweight. Text content is loaded lazily only when needed for excerpts or AI-generated answers.
- **Heading-Aware Chunking**: The search indexes heading-aware slices ("chunks") of pages independently. This ensures that search results can jump directly to the precise section hash on a page rather than just pointing to the page root.
- **BM25 Scoring Weights**: Relevant chunks are scored and ranked with the following default weights:
  - **Titles**: 4×
  - **Headings**: 2×
  - **Body text**: 1×
  - **Code blocks**: 0.35×
- **Robust Out-of-the-Box Features**: The query runtime performs word stemming, prefix matches, typo-tolerant fallbacks, and leverages a small built-in synonym map.
- **Edge-Safe Runtime**: The search client and query logic (`searchDocs`) run entirely on the edge (no Node.js dependencies), making them fast, free of database latency, and incredibly cheap to serve.

---

### 2. When Adding Embeddings is Warranted (and What to Keep)

According to `leadtype`'s design and search reference guidelines, you should start with the local lexical index first.

#### Specific Conditions to Add Embeddings:
Adding embeddings is warranted **only** when:
1. **Vocabulary Mismatch**: Users frequently search for concepts using vocabulary, terminology, or phrasing that the documentation itself does not actually use (which a standard lexical search with a synonym map cannot easily bridge).
2. **Corpus Scale**: The documentation corpus grows very large, specifically **past tens of thousands of chunks**.

#### What to Keep Even Then:
Even when you introduce embeddings, **you must keep the default lexical index** (the local, static BM25 index) rather than replacing it entirely. 

- **Why?** Lexical indices are highly precise for exact matches, such as finding specific **API names, configuration keys, exact error messages, and file/URL paths**—use cases where semantic vector search often fails or returns irrelevant results.
- **The Strategy:** Keep the lexical index for these precise matches, and **layer the vector embeddings on top** (as a hybrid search strategy).
