# What leadtype Gives You for Docs Search

## 1. What leadtype's docs search uses by default

**Leadtype uses a static, lexical (keyword-based) search index powered by BM25 ranking.**

The approach is:

- **Build-time generation**: `generateDocsSearchFiles()` creates two static JSON files:
  - `search-index.json` — compact term postings with BM25 weighted document/chunk references
  - `search-content.json` — chunk text for excerpts and answers
  
- **Runtime queries**: The client-side `searchDocs()` function loads these JSON files and performs keyword matching locally. No database, no network calls, fully edge-safe.

- **Ranking weights**: BM25 scoring with:
  - Title matches: 4×
  - Heading matches: 2×
  - Body text: 1×
  - Code blocks: 0.35×

- **Built-in intelligence**: The index already includes:
  - Stemming
  - Prefix matching
  - Typo-tolerant fallbacks
  - A small built-in synonym map

- **Chunk-aware**: Results are "heading-aware slices" — each heading becomes a separate searchable document, so results jump to the exact section users need.

## 2. When adding embeddings is actually warranted — and what to keep

**Only add embeddings when both conditions are true:**

1. **Users search with vocabulary the docs don't use** — e.g., they ask for "starter guide" but your docs call it "quickstart". Embeddings help bridge semantic gaps. Lexical search alone can be extended with product-specific synonyms first (much cheaper).

2. **The corpus grows past tens of thousands of chunks** — the lexical index stays fast, but relevance degradation from sheer volume is where embeddings shine.

**What you must keep even then:**

- **Keep the BM25 lexical index as your primary layer.** It excels at:
  - Finding exact API names, config keys, error messages, and file paths
  - Handling common, on-vocabulary searches
  - Staying cheap and edge-safe
  
- **Layer embeddings on top for fuzzy semantic retrieval,** not as a replacement. Use a hybrid approach: retrieve with both, merge/rank results, or let embeddings catch what lexical search misses.

---

**Conclusion**: Before building a hosted vector database, verify that your users actually need semantic search. Start with the static lexical index (it's genuinely good at what it does), add synonyms for domain-specific vocabulary gaps, and only move to embeddings once you have evidence that lexical + synonym strategies have hit a ceiling on corpus size or user satisfaction.
