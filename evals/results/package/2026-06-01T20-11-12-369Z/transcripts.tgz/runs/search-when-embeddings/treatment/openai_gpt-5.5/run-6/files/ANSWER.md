# Leadtype docs search and embeddings

## What leadtype uses by default

Leadtype docs search is **static and lexical by default**, not a hosted database-backed vector index.

At build time, Leadtype generates two JSON artifacts:

- `docs/search-index.json` — a compact inverted search index with ranking data.
- `docs/search-content.json` — chunk text stored separately so excerpts and answer context can be loaded lazily.

At runtime, the site or API loads those JSON files and queries them locally with `searchDocs` or the framework search hooks. This is designed to be cheap, edge-safe, and database-free.

The default ranking model is **BM25** over heading-aware chunks. Leadtype weights fields roughly as:

- title: 4×
- headings: 2×
- body: 1×
- code: 0.35×

It also includes practical lexical search behavior such as stemming, prefix matches, typo-tolerant fallbacks, and a small built-in synonym map. Product-specific synonyms can be added when users search with terms the docs do not use.

## When embeddings are warranted

Start with Leadtype's local static index. It is the right default for docs because it is precise for:

- API names
- config keys
- error messages
- file paths
- exact feature names
- guide phrases and section headings

Add embeddings only when one of these conditions is true:

1. **Vocabulary mismatch is a real problem**: users search with concepts or wording that the docs do not use, and aliases/synonyms are not enough.
2. **The corpus is very large**: the docs grow past tens of thousands of chunks, where semantic retrieval may help recall or candidate selection.

Even then, do **not** replace Leadtype's lexical index. Keep the static BM25 index for exact matches, identifiers, paths, errors, and high-precision retrieval, and layer embeddings on top as an additional semantic signal or fallback.