# Leadtype docs search: what you get by default vs. when to add embeddings

## 1. What leadtype uses by default

Leadtype ships a **static, edge-safe lexical search index** — no database, no vector store, no hosted service.

- **Build-time output:** `generateDocsSearchFiles` (or `leadtype generate`) writes two JSON files:
  - `search-index.json` — compact term postings + document/chunk references.
  - `search-content.json` — the actual chunk text, loaded lazily for excerpts and answers.
- **Ranking:** BM25 with heading-aware weights:
  - title: **4×**
  - headings: **2×**
  - body: **1×**
  - code: **0.35×**
- **Runtime query:** `searchDocs` runs entirely in the browser or at the edge (no Node.js APIs). It already includes stemming, prefix matching, typo-tolerant fallbacks, and a small built-in synonym map.
- **UI hooks:** Framework-specific hooks (`leadtype/search/react`, `leadtype/search/vue`, `leadtype/search/svelte`, `leadtype/search/client`) load the JSON files, debounce input, and return results with titles, URLs, heading paths, and excerpts.

In short: the default is a lightweight, static, BM25-based full-text index that lives next to your assets and works without any backend infrastructure.

## 2. When adding embeddings is warranted — and what to keep

Add embeddings **only** when one of these conditions is met:

1. **Vocabulary mismatch:** users search with words or concepts your docs do not actually contain (semantic/paraphrase gaps the synonym map cannot cover).
2. **Corpus scale:** the docs grow past **tens of thousands of chunks**, where pure lexical retrieval starts to miss nuance or degrade in recall.

**What you should keep even then:**

- **Keep the lexical BM25 index.** It is precise for exact matches like API names, config keys, error messages, and file paths — things embeddings can mangle.
- **Layer embeddings on top.** Use the vector index to broaden recall for fuzzy/semantic queries, but continue to use the static BM25 index for exact-match ranking and source grounding.
