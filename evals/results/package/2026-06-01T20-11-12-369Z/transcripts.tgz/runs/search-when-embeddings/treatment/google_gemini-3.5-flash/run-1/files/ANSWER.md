# Leadtype Docs Search: Architecture & Best Practices

Here is an evaluation of `leadtype`'s built-in docs search capabilities to help guide our team's decision before building a hosted, database-backed vector search index.

---

### 1. What Leadtype's Docs Search Uses by Default

By default, `leadtype` provides a **static, local, lexical search** pipeline that does not require an external database, servers, or cloud dependencies. It operates using the following components:

* **Build-Time Generation:**
  When running in **Site mode** (e.g., via `leadtype generate`), the build step converts MDX into flattened Markdown and produces two static JSON artifacts:
  1. **`search-index.json`:** A compact, BM25-ranked inverted index containing term postings and document/chunk references. This file is loaded in full on every search.
  2. **`search-content.json`:** The raw chunk text. Stored separately from the main index, this keeps the index payload small and allows content to be loaded lazily on demand (for generating excerpts or AI answers).

* **Chunk-Based Splitting:**
  Pages are automatically sliced into heading-aware **"chunks"**. Each chunk is scored and ranked independently, allowing search results to deep-link directly to the specific heading/section of a page.

* **Lexical Ranking (BM25 Algorithm):**
  At runtime, query results are scored and sorted locally using a standard **BM25 ranking function**. It uses the following default term-matching weights:
  * **Titles:** `4×`
  * **Headings:** `2×`
  * **Body:** `1×`
  * **Code:** `0.35×`

* **Built-in Query Features:**
  Without any extra configuration, the local runtime engine performs:
  * **Stemming** (matching different word forms).
  * **Prefix matches** (matching partial words).
  * **Typo-tolerant fallbacks**.
  * A small **built-in synonym map** (which can be customized at runtime with product-specific synonyms).

* **Runtime Portability:**
  The `leadtype/search` querying code is lightweight, edge-safe, and dependency-free (has zero Node.js API dependencies), making it highly performant to run in-browser, inside Cloudflare Workers, or on Vercel Edge functions.

---

### 2. When Adding Embeddings is Warranted & What to Keep

According to the `leadtype` documentation and methodology, adding a hosted vector database and embedding-based search is only warranted under specific conditions.

#### **Specific Conditions for Adding Embeddings:**
1. **Vocabulary / Terminology Mismatch:** When users frequently search for concepts using different words, synonyms, or terminology than what is written in the official documentation.
2. **Extremely Large Scale:** When the documentation corpus grows significantly large, specifically expanding past **tens of thousands of chunks**.

#### **What We Should Keep Even Then:**
Even if embeddings are added, we should **keep the local lexical (BM25) search index** and layer embeddings on top of it.
* **Why?** A lexical index is exceptionally precise, cheap, and fast for exact-match searches. Embeddings can be notoriously weak at finding exact API names, configuration keys, specific error messages, or exact file paths.
* **Hybrid Approach:** Keeping the lexical index for exact matches while layering semantic embeddings on top guarantees the best of both worlds: conceptual retrieval for conversational queries alongside pinpoint accuracy for technical, exact-match queries.
