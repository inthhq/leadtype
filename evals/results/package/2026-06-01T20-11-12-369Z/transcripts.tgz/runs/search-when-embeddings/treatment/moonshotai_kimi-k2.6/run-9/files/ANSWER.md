# Leadtype Docs Search: Default Behavior & When to Add Embeddings

## 1. What leadtype uses by default

Leadtype docs search is **static and lexical** out of the box. `leadtype generate` (or `generateDocsSearchFiles`) emits two JSON artifacts:

- `search-index.json` — compact term postings and document/chunk references.
- `search-content.json` — the actual chunk text, loaded lazily.

At runtime, `searchDocs` queries these files directly with **no database, no vector store, and no embeddings**. It is edge-safe and runs entirely in the request or browser context.

The ranking function is **BM25** with the following built-in field weights:

- **Title:** 4×
- **Headings:** 2×
- **Body:** 1×
- **Code:** 0.35×

By default the query layer also applies stemming, prefix matching, typo-tolerant fallbacks, and a small built-in synonym map. You can add product-specific synonyms via the `synonyms` option when needed.

## 2. When adding embeddings is warranted — and what to keep

You should consider adding embeddings **only** when one or both of these conditions are true:

- Users search with **vocabulary that does not appear in the docs** (semantic gap).
- The corpus grows past **tens of thousands of chunks** (scale where lexical sparsity becomes a problem).

**Even then, keep the lexical index.** Do not replace BM25 with a pure vector approach. Leadtype’s recommendation is to **layer embeddings on top** of the existing static index and continue using the lexical index for exact matches (API names, config keys, error messages, file paths, etc.).

In short: start with the static BM25 index; add embeddings only for semantic mismatch or large scale, and treat them as an augment, not a replacement.
