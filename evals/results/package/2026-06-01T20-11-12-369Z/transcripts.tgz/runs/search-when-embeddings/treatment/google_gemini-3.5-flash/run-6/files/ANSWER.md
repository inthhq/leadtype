# Leadtype Docs Search & Embeddings

Before standing up a hosted, database-backed vector index, here is an overview of what `leadtype` provides out-of-the-box and the recommended approach for search scaling.

## 1. What Leadtype's Docs Search Uses by Default

By default, Leadtype uses a **static, cheap, and edge-safe lexical search index** that does not require any database or server. It runs entirely locally or at the edge. 

At build time, `leadtype generate` produces two main JSON files:
*   `search-index.json`: Contains compact ranking data, term postings, and document/chunk references. This is small and loaded on every search.
*   `search-content.json`: Contains the raw chunk text. It is stored separately to keep the main search index small and is loaded lazily only when needed for excerpts or AI answers.

### Default Search Capabilities
*   **BM25 Ranking Function**: Documents/pages are broken into heading-aware "chunks" (so search results jump to exact headings). BM25 weights are applied as:
    *   **Title**: 4× weight
    *   **Headings**: 2× weight
    *   **Body**: 1× weight
    *   **Code**: 0.35× weight
*   **Built-in Processing**: Includes stemming, prefix matching, typo-tolerant fallbacks, and a small built-in synonym map.
*   **Synonym Aliases**: Supports adding custom vocabulary/synonym mappings if users search using words your documentation doesn't explicitly use.
*   **Precision**: Highly precise for API names, config keys, error messages, and exact paths.

---

## 2. When Embeddings are Warranted (and What to Keep)

According to Leadtype's methodology and reference guides, you should start with the default local index because it is cheap, fast, edge-safe, and highly precise for exact terms. 

### Conditions for Adding Embeddings
Adding embeddings is warranted only under the following conditions:
1.  **Semantic / Vocabulary Gap**: When users search with vocabulary, concepts, or synonyms that the documentation does not use, and custom synonym mappings are insufficient.
2.  **Corpus Scale**: When the documentation corpus grows excessively large—specifically past **tens of thousands of chunks**.

### What to Keep Even Then
Even when embeddings are introduced, you should **keep the default lexical (BM25) index** and layer the embeddings search on top of it (e.g., hybrid search). 

*Why?* Lexical search remains far superior and more reliable for exact matches like API names, config keys, error messages, and specific file paths, where semantic vector search often fails to match precise terms.
