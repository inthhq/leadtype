# Do we need a hosted vector index for docs search?

Short answer: not to start. `leadtype` already ships a complete docs search
system, and it is deliberately **not** a hosted, database-backed vector index.
Embeddings are an optional layer to add later under specific conditions — and
even then you keep what's described below.

## 1. What leadtype's docs search uses by default

Leadtype search is **static and lexical by default** — no database, no embedding
service, edge-safe.

- **Build time** produces two JSON files (via `leadtype generate` or
  `generateDocsSearchFiles` from `leadtype/search/node`):
  - `public/docs/search-index.json` — compact term postings + document/chunk
    refs. Loaded on every search.
  - `public/docs/search-content.json` — chunk text, kept separate so search
    stays cheap and content loads lazily (for excerpts/answers).
- **Ranking** uses **BM25** (a lexical ranking function), with field weights:
  title 4×, headings 2×, body 1×, code 0.35×.
- **Chunking** is heading-aware: each heading-scoped slice of a page is its own
  document, so results jump straight to the right section (hash URLs).
- **Runtime** is `searchDocs(index, query, options)` from `leadtype/search`,
  plus framework hooks (`useLeadtypeSearch` for React/Next/Vue/Svelte, and a
  vanilla `createSearchClient`). The runtime is edge-safe and uses no Node APIs —
  it just loads the two JSON files and queries them locally.
- **Query quality out of the box** includes stemming, prefix matches,
  typo-tolerant fallbacks, and a small built-in synonym map. You can add
  product-specific synonym aliases when users search with words the docs don't
  use.

In other words, the default is a precise, cheap, statically-hosted lexical index
— especially strong for API names, config keys, error messages, and paths, which
are exact-match-heavy and where embeddings tend to be fuzzy.

## 2. When embeddings are actually warranted — and what to keep

Per leadtype's own guidance, **start with the local lexical index** and add
embeddings **only** when one of these holds:

- **Vocabulary mismatch:** users search with vocabulary the docs don't use
  (semantic/synonym gap that the synonym map can't reasonably cover), **or**
- **Corpus scale:** the corpus grows past **tens of thousands of chunks**.

Before reaching for embeddings, try the cheaper lever first: add
product-specific **synonym aliases** to `searchDocs`, since stemming, prefix
matching, typo tolerance, and a built-in synonym map are already in place.

Even when embeddings are justified:

- **Keep the lexical (BM25) index for exact matches** — API names, config keys,
  error strings, and paths — where lexical precision beats vector similarity.
- **Layer embeddings on top** of the lexical index (hybrid retrieval), rather
  than replacing it.

## Recommendation

Don't stand up a hosted, database-backed vector index "because that's how RAG is
done." Adopt leadtype's default static lexical search first (two JSON files,
BM25, edge-served). Only introduce embeddings if you hit the vocabulary-mismatch
or scale (tens of thousands of chunks) thresholds — and keep the lexical index
underneath it for exact matches.

> Sources in the installed package:
> `node_modules/leadtype/docs/reference/search.md` ("When to add embeddings")
> and `node_modules/leadtype/docs/search/add-search.md` ("Leadtype search is
> static by default ... no database, edge-safe").
