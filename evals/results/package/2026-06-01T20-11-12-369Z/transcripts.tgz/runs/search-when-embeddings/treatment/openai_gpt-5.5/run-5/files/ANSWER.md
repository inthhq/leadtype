# Leadtype docs search: do we need a hosted vector index?

## 1. What Leadtype uses by default

Leadtype docs search is **static and lexical by default**, not database-backed and not embedding-backed.

In site mode, `leadtype generate` writes two files:

- `public/docs/search-index.json` — a compact BM25 inverted index with term postings and chunk/page references.
- `public/docs/search-content.json` — the chunk text/content store, kept separate so the index stays small and content can be loaded lazily for excerpts or AI-answer context.

At runtime, the app loads those JSON files and searches locally with `searchDocs`. The runtime is edge-safe and does not require Node APIs, a search service, a database, or a vector store.

The ranking model is **BM25** over heading-aware chunks. Leadtype weights fields as follows:

- title: 4×
- headings: 2×
- body: 1×
- code: 0.35×

Leadtype also already includes practical lexical-search behavior: stemming, prefix matches, typo-tolerant fallbacks, and a small built-in synonym map. Product-specific synonyms can be added when users search for words the docs do not use.

For AI answers, Leadtype still starts from the same static index: `searchDocs` retrieves relevant chunks, `createAnswerContext` builds a constrained prompt from those chunks, and `streamDocsAnswer` streams a source-grounded answer. That is RAG over the static BM25 index, not a vector database by default.

## 2. When embeddings are actually warranted

Start with Leadtype's local static index. It is cheap, deploys as static files, works at the edge, and is especially good for docs queries involving exact language such as:

- API names
- configuration keys
- error messages
- file paths
- command names
- code identifiers
- guide phrases that appear in the docs

Add embeddings only under the conditions Leadtype calls out:

1. **Vocabulary mismatch:** users consistently search with concepts or wording that the docs do not use, and simple product-specific synonyms are not enough.
2. **Corpus scale:** the corpus grows past **tens of thousands of chunks**, where a semantic retrieval layer may help recall or ranking across a very large body of docs.

Even then, do **not** replace Leadtype's lexical index. Keep the static BM25 index for exact matches and layer embeddings on top as an additional retrieval signal. Exact identifiers, error strings, config names, and paths are where lexical search is strongest and where embedding-only retrieval is often weakest.

So the practical recommendation is: ship Leadtype's generated `search-index.json` and `search-content.json` first; tune synonyms if needed; add embeddings only when real query logs show vocabulary mismatch or the docs corpus reaches very large scale; and keep BM25 as the exact-match backbone even if a vector layer is added.