# Leadtype Search Architecture and RAG Guidelines

Before investing time and resources into standing up a hosted, database-backed vector database for documentation search, here is a detailed breakdown of what `leadtype` provides out of the box, and the conditions under which a vector/embedding approach is actually warranted.

---

## 1. What Leadtype's Docs Search Uses by Default

By default, `leadtype` provides a **static, cheap, highly precise, and edge-safe local search pipeline**. It does not require any hosted databases, external search APIs, or running servers.

### Core Architecture and Mechanics

1. **Build-Time Static Generation**:
   During the documentation build phase (via the `leadtype generate` CLI command or the programmatic `generateDocsSearchFiles` API), Leadtype analyzes your markdown files and compiles them into two optimized static files in your web root:
   * **`search-index.json`**: A highly compact index containing term postings and document/chunk references. This file is designed to be loaded quickly on every search.
   * **`search-content.json`**: A separate, larger store containing the actual raw text of the chunks. Keeping this content separate from the index keeps search operations cheap, while allowing content to be loaded lazily on-demand for search excerpts or AI answer context.

2. **Heading-Aware Chunking**:
   Leadtype slices each page into smaller, logical "chunks" based on heading boundaries. Each chunk is treated as a separate searchable document, allowing search results to link directly to the exact page section (complete with URL hash anchors) rather than just the top-level page.

3. **BM25 Lexical Ranking**:
   The default query engine (`leadtype/search`) uses the industry-standard **BM25 ranking function** (a highly optimized term-frequency/inverse-document-frequency variant) to score search results. 

4. **Strategic Field Weighting**:
   BM25 relevance scores are tuned using a default weighting system to prioritize structural document hierarchy:
   * **Title**: `4×` weight
   * **Headings**: `2×` weight
   * **Body**: `1×` weight
   * **Code Blocks**: `0.35×` weight

5. **Heuristics & Query Tolerances**:
   Out of the box, the local engine handles linguistic variations using:
   * Stemming (mapping words to their base form).
   * Prefix matching.
   * Typo-tolerant fallbacks.
   * A small, built-in synonym map (which can be extended programmatically with product-specific synonyms at runtime).

6. **Edge-Safe & Framework-Integrated**:
   Because the runtime relies purely on parsing the generated static JSON files, the search engine is fully **edge-safe** (zero Node.js dependencies) and can run directly in client browsers or lightweight edge environments (e.g., Cloudflare Workers, Vercel Edge). 
   
   Leadtype bundles simple hooks and clients for React, Next.js (App Router), Vue, Svelte, and vanilla JS to handle preloading, debouncing, loading states (`idle | loading | ready | error`), and rendering out-of-the-box.

7. **Source-Grounded AI Answers (RAG)**:
   For teams wanting "AI chat" search, `leadtype` already provides structured wrappers (`leadtype/search/vercel`, `leadtype/search/tanstack`, `leadtype/search/cloudflare`) to perform **RAG without a database**. It queries the local static index for the top $N$ relevant chunks, compiles a constrained LLM context prompt instructing the model to *only* answer using the provided context and format citations, and streams the response directly to the client.

---

## 2. When Vector Embeddings are Warranted (and What to Keep)

Many teams jump straight to a hosted vector database because "that's how RAG is done." However, doing so introduces unnecessary architecture complexity, latency, and hosting costs. 

According to Leadtype's design methodology and evaluation benchmarks, adding vector embeddings is only warranted under two specific conditions:

### Warranted Conditions
1. **Conceptual & Vocabulary Gaps**: 
   When users consistently search using abstract concepts, mental models, or vocabulary that the documentation does not explicitly mention (where traditional stemming, prefix matching, and manual synonym maps fail to connect the search term to the page).
2. **Corpus Scale**: 
   When the documentation base grows extremely large—specifically **past tens of thousands of chunks**. At this scale, downloading the static `search-index.json` and searching it entirely in-memory on the client/edge becomes computationally or network-prohibitive.

### What We Should Keep Even Then
If you do decide to introduce vector embeddings, **do not replace the static BM25 index. Keep it and layer the embeddings on top (Hybrid Search).**

* **Why?** Lexical indices (BM25) are vastly superior and highly precise for matching:
  * **API Names** (e.g., specific function, variable, or class names).
  * **Configuration keys** and flags (e.g., `--out-dir`).
  * **Exact error messages** or error codes.
  * **File or URL paths**.
* **The Failure of Pure Vector Search**: Vector models map keywords to high-dimensional space. While excellent at capturing conceptual similarity, they are notoriously bad at matching precise characters. A user searching for a specific configuration key or method name in a pure vector database will often get a conceptually "similar" page instead of the exact API reference they need.
* **The Solution**: Maintain the lightweight, static lexical index for exact matching and use a hybrid/fusion search strategy to merge exact BM25 keyword results with vector-based semantic results.
