# Leadtype Docs Search: Default Capabilities vs. Embeddings

Our team does not need to rush to spin up a hosted, database-backed vector database for docs search. `leadtype` already provides an incredibly robust, local-first search system out-of-the-box. Below is a detailed breakdown of what `leadtype` uses by default and when/how we should evaluate moving to embeddings.

---

## 1. What Leadtype's Docs Search Uses by Default

By default, `leadtype` search is **completely static, client-side/edge-safe, and local-first**. It operates without any external database, hosted search servers, or complex server infrastructure.

### Build-Time Generation
At build time, the generator builds and outputs two highly-optimized static JSON files into your public directory:
* **`public/docs/search-index.json` (Search Index):** Contains compact term postings, document/chunk references, and ranking data. Because of its tiny footprint, it is loaded on every search to power instant client-side queries.
* **`public/docs/search-content.json` (Content Store):** Contains the full text for each document chunk. To keep search cheap and fast, this file is loaded lazily only when needed to show text excerpts, snippets, or to feed context into AI/LLM answers.

### Chunking and Structural Relevance
Instead of indexing whole documents as single units, `leadtype` splits files into **Chunks** (heading-aware page slices). This ensures search results pinpoint the exact section and link to the precise heading hash on the page.

### The BM25 Ranking Engine
Default search runs on a local implementation of the **BM25** ranking function. It prioritizes structure by weighting terms based on where they appear:
* **Title:** `4×`
* **Headings:** `2×`
* **Body:** `1×`
* **Code:** `0.35×`

### Query Capabilities
Without any external APIs or vector databases, the default local index supports:
* **Stemming** and **prefix matches**.
* **Typo-tolerant fallbacks**.
* **A small, built-in synonym map** (with simple support for adding custom, product-specific synonyms at runtime).

---

## 2. Under What Specific Conditions Adding Embeddings is Actually Warranted

According to `leadtype`'s official documentation and design methodology, you should **only** introduce embeddings under the following specific conditions:

1. **Semantic & Vocabulary Gap:** When users frequently search using vocabulary, synonyms, or conceptual terms that are completely absent from the actual written text of the documentation.
2. **Corpus Scale:** When your documentation corpus grows exceedingly large, specifically **past tens of thousands of chunks**.

### What We Should Keep Even Then

If you do decide that embeddings are warranted, **do not replace the default search index**. 

* **Keep the Lexical (BM25) Index:** You must retain the static lexical index.
* **Why?** Vector embeddings are notoriously bad at finding exact, character-level matches like **API names, configuration keys, error messages, and file/module paths**. A local BM25 index remains the absolute best and most precise tool for these developer-focused queries.
* **The Hybrid Solution:** You should layer the embeddings *on top* of the lexical search index as a hybrid retrieval system, using exact BM25 matches to catch technical terms and embeddings to catch broad, conceptual search queries.
