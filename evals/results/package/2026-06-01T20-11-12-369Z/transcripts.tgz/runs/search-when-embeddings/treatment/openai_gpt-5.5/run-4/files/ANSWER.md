# Leadtype search: default vs. embeddings

## What Leadtype uses by default

Leadtype docs search is **static, local lexical search** by default — not a hosted vector database.

At build time, `leadtype generate` in site mode writes two files:

- `public/docs/search-index.json` — compact ranking data: term postings plus page/chunk references.
- `public/docs/search-content.json` — chunk text, stored separately so content can be loaded lazily for excerpts or answers.

At runtime, `leadtype/search` loads those JSON files and queries them locally with `searchDocs`. The ranking is **BM25** over heading-aware chunks, with weighted fields:

- title: 4×
- headings: 2×
- body: 1×
- code: 0.35×

The runtime is edge-safe and does not require Node APIs, a database, or a network service. Client helpers are provided for React, Vue, Svelte, vanilla clients, and Next. Search also already includes stemming, prefix matching, typo-tolerant fallbacks, and a small built-in synonym map. For AI answers, Leadtype retrieves chunks from the same static index and uses them as source-grounded context.

## When embeddings are actually warranted

Start with Leadtype’s local lexical index. It is cheap, static, precise, and especially good for docs queries involving exact API names, config keys, error messages, command names, file paths, and section titles.

Add embeddings only when one of these is true:

1. **Users search with vocabulary the docs do not use**, so lexical matching and product-specific synonyms are not enough.
2. **The corpus grows beyond tens of thousands of chunks**, where semantic retrieval may become useful as an additional retrieval layer.

Even then, do **not** replace Leadtype’s lexical index. Keep it for exact matches and layer embeddings on top as a supplemental semantic retrieval path. In other words: use embeddings to broaden recall when needed, while preserving BM25/static search for precision, debuggability, low cost, and fast exact-match docs lookup.
