# Leadtype Search Architecture & Recommendation

Before standing up a hosted, database-backed vector index for document search "because that's how RAG is done," here is a breakdown of what the `leadtype` package already provides out of the box.

---

### 1. What Leadtype's Docs Search Uses by Default

By default, Leadtype uses a **static, edge-safe, lexical search index**. It does not require a database, external search APIs, or any server-side database infrastructure.

* **Static Build-time Generation**:
  At build-time, running the `leadtype generate` pipeline analyzes your documentation and outputs two highly-optimized, static JSON files inside your static asset directory (e.g., `public/docs/`):
  1. `search-index.json` – Contains compact term postings and document/chunk references. This file is loaded on every search.
  2. `search-content.json` – Contains chunk text. This file is loaded lazily for rendering excerpts/snippets or feeding context to an AI answer engine.

* **Underlying Ranking Algorithm**:
  It queries locally at runtime using the **BM25** ranking function. Out of the box, weights are balanced for technical documentation:
  * **Title**: 4× weighting
  * **Headings**: 2× weighting
  * **Body**: 1× weighting
  * **Code**: 0.35× weighting

* **Chunk-Aware Indexing**:
  Instead of indexing entire pages, Leadtype indexes heading-aware "chunks" of a page. This allows search results to navigate users directly to the relevant section hash or heading path.

* **Built-in Search Enhancements**:
  The static client engine automatically supports:
  * **Stemming** and **prefix matches**.
  * **Typo-tolerant fallbacks**.
  * A **small built-in synonym map** (with API support for adding custom product-specific synonyms at query time).

* **Edge-Safe Runtime & Framework Hooks**:
  Leadtype provides vanilla client clients and framework-native hooks (`React`/`Next.js`, `Vue`, `Svelte`) that load, debounce, and query the index entirely on the client side or on the edge.

* **Zero-DB AI Answers / RAG**:
  Even for RAG, you don't need a vector database by default. Leadtype's AI answer feature (`streamDocsAnswer`) retrieves the most relevant chunks directly from the local static index, constructs a constrained prompt (system message, sources, and user query), and feeds them to any LLM runtime (e.g., Vercel AI SDK, TanStack AI, Cloudflare Workers AI) to stream a source-grounded answer safely.

---

### 2. When Are Embeddings Warranted, and What to Keep

While a vector database/embeddings model might sound appealing, Leadtype recommends holding off until specific thresholds are met.

#### Specific Conditions Warranting Embeddings:
1. **Vocabulary Mismatch**: Users frequently search with highly conceptual, conversational language or terminology/synonyms that do not explicitly appear anywhere within your docs' text.
2. **Corpus Scale**: Your documentation corpus grows to massive proportions, specifically **past tens of thousands of chunks**.

#### What to Keep Even Then:
If you do decide to implement embeddings, you should **keep the lexical (BM25) index** intact.
* **Why**: Vector/semantic search is notoriously poor at looking up exact terms such as **API names**, **configuration keys**, **error messages**, and **file/import paths**. 
* **The Strategy**: Keep the lexical index as the source of truth for exact matches and **layer the embeddings on top** as a hybrid search mechanism rather than replacing the default index entirely.
