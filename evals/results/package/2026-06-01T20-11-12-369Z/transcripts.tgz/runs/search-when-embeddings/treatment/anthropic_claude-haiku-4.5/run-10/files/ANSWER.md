# What leadtype Gives You for Docs Search

## 1. Default Search Implementation

**By default, leadtype uses a static, edge-safe BM25 lexical search index.**

The `leadtype generate` command produces two JSON files at build time:

- **`search-index.json`** — a compact inverted index with term postings and document/chunk references. BM25 ranking applies weight factors: title (4×), headings (2×), body (1×), code (0.35×).
- **`search-content.json`** — the actual chunk text, stored separately so the index stays lightweight.

**How it works:**
- Leadtype breaks each page into **chunks** (heading-aware slices) so search results jump to the right section.
- At runtime, queries are executed locally (no server round-trip) using the `searchDocs()` function.
- The runtime is **edge-safe** — no Node.js APIs, runs anywhere (browser, Cloudflare Workers, Vercel Edge, etc.).
- No database required. No embeddings. No external API calls.

**Strengths of this approach:**
- Fast, precise for exact matches (API names, config keys, error messages, paths).
- Cheap to build and host—just two JSON files.
- Works offline once loaded.
- Built-in stemming, prefix matching, typo-tolerant fallbacks, and a small synonym map.

---

## 2. When to Add Embeddings — and What to Keep

**Add embeddings only when:**

1. **Users search with vocabulary the docs don't use** — when synonymy gaps exist that synonym aliases can't bridge. For example, users say "starter" but your docs only say "quickstart" or "getting started."

2. **The corpus exceeds tens of thousands of chunks** — when the lexical index alone becomes too broad, or when semantic intent matters more than term matching.

**Critical: Keep the lexical index even when you add embeddings.**

From the leadtype docs:

> "Start with the local index — static, cheap, edge-safe, and precise for API names, config keys, error messages, and paths. Add embeddings only when users search with vocabulary the docs don't use, or the corpus grows past tens of thousands of chunks. **Even then, keep the lexical index for exact matches and layer embeddings on top.**"

**The hybrid approach:**
- Use BM25 for exact-match precision (API references, function names, configuration keys).
- Layer embeddings as a fallback for semantic intent and vocabulary mismatch.
- Rank results by combining both signals, preferring exact lexical matches when they exist.

This avoids the overhead of a database while gaining semantic coverage where it matters most.
