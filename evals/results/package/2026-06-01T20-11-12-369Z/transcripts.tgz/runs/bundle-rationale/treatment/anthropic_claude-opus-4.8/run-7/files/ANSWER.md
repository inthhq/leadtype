# Docs inside the npm tarball: use `AGENTS.md`, not `llms.txt`

## 1. Why `AGENTS.md` is the right shape for docs shipped inside a tarball

`llms.txt` is a **website convention**: a file served at `/llms.txt` whose links are absolute, hosted URLs that an agent fetches over HTTP. That shape breaks inside an npm package — the installed files sit at `node_modules/<pkg>/`, so absolute URLs point at a site the agent may not be able to reach, the content isn't version-matched to the installed code, and no major coding agent even looks for `node_modules/<pkg>/llms.txt`. `AGENTS.md` is the **filesystem convention** built for exactly this case: tools like Claude Code, OpenAI Codex, Cursor, GitHub Copilot, Aider, and Devin already read `AGENTS.md` when working with files on disk. Leadtype's `--bundle` output writes `AGENTS.md` at the package root with **relative** links (`./docs/<topic>.md`), so the index resolves with no network, works both in local dev (`packages/<name>/`) and after install (`node_modules/<name>/`), and always matches the installed version. (The two conventions aren't either/or: Leadtype emits `llms.txt` in website mode for HTTP-discoverable agents and `AGENTS.md` in `--bundle` mode for offline, filesystem-discoverable ones. Note that just shipping `AGENTS.md` isn't enough — consumers should point their project's root `AGENTS.md` at `node_modules/<pkg>/AGENTS.md`, which lifts the read rate from ~29% to ~90–100%.)

## 2. Website artifacts `leadtype generate --bundle` deliberately skips

Bundle mode intentionally omits the URL-anchored, website-only artifacts because they're meaningless offline inside a tarball:

- **`llms.txt`** and **`docs/llms.txt`** — HTTP routing indexes with absolute URLs; nothing fetches them from `node_modules`.
- **`llms-full.txt`** (root all-docs fallback) — a network-served full-context file; the bundled `docs/*.md` already ship in full on disk.
- **`search-index.json` / `search-content.json`** (BM25 search) — feeds a hosted search endpoint, not a local read.
- **`sitemap.xml` / `sitemap.md`** and **`robots.txt`** — crawler/SEO files tied to a base URL (`--base-url` is ignored in `--bundle`).
- **`agent-readability.json`** (Agent Readability discovery metadata) — a site-level discovery artifact for HTTP agents.

All of these are anchored to a hosted origin and a base URL, so they belong to a docs *website*, not a package. `--bundle` keeps only what's useful from disk: `AGENTS.md` plus per-topic `docs/*.md` mirrors with relative links.
