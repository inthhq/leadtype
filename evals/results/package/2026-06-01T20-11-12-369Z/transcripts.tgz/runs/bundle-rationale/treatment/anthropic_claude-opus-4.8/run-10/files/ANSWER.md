# Bundling docs inside the npm tarball

## 1. Why `AGENTS.md`, not `llms.txt`

`llms.txt` is a **website convention**: a file served at `/llms.txt` whose links are absolute HTTP URLs that an agent fetches over the network. Inside an npm tarball that shape breaks down — every link points at a hosted URL the installer may not be able to reach, the content can drift out of sync with the installed version, and no major coding agent looks for `node_modules/<pkg>/llms.txt` anyway. `AGENTS.md` is the **filesystem convention** that fits a published package: tools like Claude Code, OpenAI Codex, Cursor, GitHub Copilot, Aider, and Devin already read `AGENTS.md` when working on files on disk. Shipped at `node_modules/<your-package>/AGENTS.md`, it uses relative links (e.g. `./docs/quickstart.md`) that resolve offline, needs no network request, and is version-matched to exactly the package the consumer installed. (To actually get read, pair it with a pointer in the consuming project's root `AGENTS.md` — discovery jumps from ~29% to ~90–100%.)

## 2. What `leadtype generate --bundle` deliberately skips

In `--bundle` mode the CLI emits only `AGENTS.md` plus the per-topic `docs/**/*.md` mirrors, and it intentionally omits the **website artifacts**: `llms.txt`, `llms-full.txt`, and the **search index**. These are all built for a hosted site reached over HTTP — `llms.txt`/`llms-full.txt` carry absolute URLs for HTTP-discoverable agents, and the search index backs a server-side query endpoint. None of them make sense offline inside `node_modules/`, where there is no base URL to fetch and no running server to query, so they don't belong in the package (they're still produced in website mode, where they do belong).
