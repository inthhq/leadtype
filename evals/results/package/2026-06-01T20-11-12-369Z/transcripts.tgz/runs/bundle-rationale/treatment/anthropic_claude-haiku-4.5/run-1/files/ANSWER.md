# Why AGENTS.md, Not llms.txt, and What `leadtype generate --bundle` Skips

## AGENTS.md is the Right Shape for Package-Bundled Docs

`llms.txt` is a **website convention** designed for HTTP discovery—it lives at `/llms.txt` on a hosted domain and contains absolute URLs that agents fetch over the network. Inside an npm tarball, it breaks that assumption: every link points at a hosted URL the agent may not reach, and no major coding agent looks for `node_modules/<pkg>/llms.txt` anyway. `AGENTS.md`, by contrast, is the **filesystem convention** for offline agent-readable docs. It uses relative links like `./docs/quickstart.md` that work both during local development and after `npm install`, where the file lands at `node_modules/<your-package>/AGENTS.md`. Coding agents like Claude Code, Cursor, GitHub Copilot, and Aider can discover and read it without network access, making it the right shape for version-matched docs that ship with the installed package itself.

## What `leadtype generate --bundle` Deliberately Skips

When you run `leadtype generate --bundle`, it **skips `llms.txt`, `llms-full.txt`, and the search index**—all website artifacts that don't belong in a tarball. `llms.txt` and `llms-full.txt` assume HTTP delivery with absolute URLs, which fail offline. The search index (`search-index.json`) is designed for a hosted site where agents query it over HTTP; bundling it adds weight to every install and provides no value when agents can't reach a search endpoint. By generating only `AGENTS.md` and per-topic markdown files (with relative paths), `--bundle` mode produces the minimal, working set of artifacts that make sense for offline filesystem discovery while keeping packages lean.
