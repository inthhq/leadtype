# AGENTS.md vs. llms.txt for package-bundled docs

## 1. Why `AGENTS.md` is the right shape inside a tarball

`llms.txt` is a **website convention**: it lives at `/llms.txt`, uses absolute, root-relative URLs, and is meant to be *fetched over HTTP* by agents that can reach your hosted docs. Inside an installed npm package none of that holds — the file would land at `node_modules/<pkg>/llms.txt`, every link would point at a hosted URL the agent may not be able to (or want to) reach, and no major coding agent even looks for an `llms.txt` on disk. It ships docs that nothing reliably reads.

`AGENTS.md` is the **filesystem convention** that fits this case. Tools like Claude Code, OpenAI Codex, Cursor, GitHub Copilot, Aider, and Devin already read `AGENTS.md` when working with files on disk, and leadtype emits it with **relative links** (`./docs/<topic>.md`) so it works both at `packages/<name>/AGENTS.md` during local dev and at `node_modules/<pkg>/AGENTS.md` after install. The result is offline, version-matched docs that need no network and stay accurate as the dependency updates. (Note: bundling alone gets read only ~29% of the time — the consuming project should also add a one-line pointer to `node_modules/<pkg>/AGENTS.md` in its own root `AGENTS.md`, which raises that to ~90–100%.)

## 2. What `leadtype generate --bundle` deliberately skips

`--bundle` emits only `AGENTS.md` (at the package root) plus the per-topic `docs/**/*.md` mirrors. It deliberately omits the **website artifacts**, because they only make sense for a hosted site served over HTTP, not for files read from an installed dependency:

- **`llms.txt`** (and the docs-scoped `docs/llms.txt`) — HTTP-discovery routing indexes built around absolute/root-relative website URLs; `AGENTS.md` is the offline, relative-link equivalent.
- **`llms-full.txt`** — the root single-file flattened fallback meant to be fetched when page-level links aren't enough; redundant offline, where the agent can already open the `docs/*.md` files directly.
- **The search index** (search JSON) — powers a runtime/website search UI and AI-answer endpoints, which don't exist for files sitting in `node_modules`.

In short, anything tied to URL resolution, HTTP fetching, or a running site (`llms.txt`, `llms-full.txt`, the search index, and the related sitemap/robots/agent-readability discovery files) is left out, because offline filesystem readers can't use it and it would only bloat the tarball with broken-link content.
