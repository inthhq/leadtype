# Why AGENTS.md, Not llms.txt, for Package Bundles

`llms.txt` is a **website convention**—a file served at `/llms.txt` with absolute HTTP URLs that an agent fetches over the network. Inside an npm tarball, this design breaks: all links point to hosted URLs the agent may not reach, and no major coding agent (Claude Code, Cursor, GitHub Copilot, Aider, Devin, etc.) looks for `node_modules/<pkg>/llms.txt` anyway. 

`AGENTS.md` solves this by being the **filesystem convention** for offline docs. It ships inside `node_modules/<your-package>/` with relative paths like `./docs/quickstart.md`, so links work without network access and the content always matches the installed version. Tools that work with files on disk naturally discover and read `AGENTS.md` when embedded in a package—evals show discovery jumps from ~29% to ~90–100% when a root pointer exists. leadtype generates both: `llms.txt` for website agents (HTTP-discoverable), and `AGENTS.md` for package agents (filesystem-discoverable).

## Website Artifacts That `--bundle` Deliberately Skips

The `leadtype generate --bundle` command skips `llms.txt`, `llms-full.txt`, and `search-index.json`—plus sitemap, robots, and agent-readability artifacts—because they require a **base URL**. These are website-only: they assume an agent fetches over HTTP with absolute paths like `/docs/quickstart.md` or `/llms.txt`, use domain-relative canonical links for SEO and redirect handling, and compile a searchable index that only makes sense when served from a live server. None of these work offline inside a tarball, where there is no base URL and no HTTP server. Bundle mode produces only `AGENTS.md` and per-topic markdown—the smallest, most portable shape for version-matched offline reading.
