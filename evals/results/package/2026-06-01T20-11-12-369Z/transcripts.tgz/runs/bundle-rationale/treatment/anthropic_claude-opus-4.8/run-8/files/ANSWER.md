# Bundle docs as `AGENTS.md`, not `llms.txt`

## 1. Why `AGENTS.md` is the right shape inside a tarball

`llms.txt` is a *website* convention: it lives at `/llms.txt` and lists **absolute HTTP URLs** that an agent fetches over the network. Dropped inside a published tarball it's the wrong shape — every link points at a hosted URL the consuming agent may not be able (or allowed) to reach, the content isn't guaranteed to match the installed version, and no major coding agent even looks for `node_modules/<pkg>/llms.txt`. `AGENTS.md` is the *filesystem* convention that solves exactly this case. Tools like Claude Code, OpenAI Codex, Cursor, GitHub Copilot, Aider, and Devin already read `AGENTS.md` when working with files on disk, so an `AGENTS.md` at the package root lands at `node_modules/<pkg>/AGENTS.md` after install, uses **relative** links (e.g. `./docs/quickstart.md`) that resolve offline, and ships docs that are version-matched to the installed code. (To make discovery reliable, the consuming project should still add a one-line pointer to `node_modules/<pkg>/AGENTS.md` in its own root `AGENTS.md` — agents find the bundle on their own only ~29% of the time, versus ~90–100% with the pointer.) leadtype emits *both* shapes from the same source: `llms.txt` in website mode for HTTP-discoverable agents, and `AGENTS.md` in `--bundle` mode for offline, filesystem-discoverable ones.

## 2. What `leadtype generate --bundle` deliberately skips

`--bundle` produces only `AGENTS.md` plus per-topic `docs/**/*.md`. It deliberately omits the website-only artifacts that the site-mode pipeline emits, because they assume a hosted origin and HTTP serving and are meaningless inside an installed package:

- **`llms.txt`** — a discovery index of absolute, hosted URLs; pointless offline (its job is done by `AGENTS.md` with relative links).
- **`llms-full.txt`** — the concatenated full-corpus fallback served at a website root; not a filesystem artifact.
- **The search index** (and related agent-readability/JSON-LD, `sitemap.xml`/`sitemap.md`, and `robots.txt` outputs) — these exist to make a *running site* crawlable, queryable, and attributable over HTTP, and have no role in a `node_modules` directory that agents read directly as files.

In short, `--bundle` ships the content an agent can read straight off disk and drops everything whose only purpose is to be fetched from a live website.
