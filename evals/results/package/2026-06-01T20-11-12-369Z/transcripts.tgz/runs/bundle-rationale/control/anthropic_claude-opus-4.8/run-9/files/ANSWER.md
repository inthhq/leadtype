# Why `AGENTS.md`, not `llms.txt`, ships inside the tarball

`llms.txt` is a *website* convention: it's a root-served index (`https://site/llms.txt`) whose entries are absolute URLs that an HTTP agent fetches over the network. That shape makes no sense inside an installed package — a tarball at `node_modules/<pkg>/` has no host, no base URL, and a coding agent reading it works from the local filesystem, not from links it has to go fetch. `AGENTS.md` is the right shape because it's the established, filesystem-first entry point coding agents already look for: it lives at the package root (`node_modules/<pkg>/AGENTS.md`), is version-matched to exactly the code that was installed, and points at the sibling `docs/*.md` files by relative path so it stays accurate offline. That's why `leadtype generate --bundle` emits `AGENTS.md` + `docs/*.md` for packages, while `llms.txt` is produced only in default (site) mode — and why the recommended setup is to have your project's root `AGENTS.md` point at `node_modules/<pkg>/AGENTS.md`.

# What `leadtype generate --bundle` deliberately skips

Compared to default site mode (which writes `llms.txt`, `llms-full.txt`, `docs/*.md`, `docs/search-index.json`, plus `docs/sitemap.xml`, `docs/sitemap.md`, and `docs/robots.txt`), bundle mode writes only `AGENTS.md` and `docs/*.md`. It intentionally skips:

- **`llms.txt`** — a root-served website index of absolute doc URLs; meaningless without a hosted base URL.
- **`llms-full.txt`** — the single-file, whole-site fallback meant to be fetched from the site root; redundant when the agent already has the real `docs/*.md` files on disk.
- **Search artifacts (`search-index.json` / search content)** — a static, edge-served BM25 index built to power a hosted docs site's search endpoint; it needs a running site/runtime to be useful and just bloats the install.
- **Sitemap and robots files (`sitemap.xml`, `sitemap.md`, `robots.txt`)** and the agent-readability manifest — crawler/SEO and HTTP discovery metadata for a public website.

All of these are **website-only**: they describe or serve a hosted docs site over HTTP. They don't belong in a package tarball, where there's no server, no base URL, and no crawler — only an agent reading version-matched Markdown straight from `node_modules`.
