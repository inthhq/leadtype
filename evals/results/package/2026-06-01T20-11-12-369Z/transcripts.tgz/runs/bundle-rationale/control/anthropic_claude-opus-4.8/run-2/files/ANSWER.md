# Why `AGENTS.md` (not `llms.txt`) belongs inside the npm tarball

`llms.txt` is a *website* convention: it lives at a known URL on a hosted docs
site (`/llms.txt`) so HTTP agents can discover and fetch the doc set over the
network, alongside a root `llms-full.txt` fallback and a static search index.
None of that addressing makes sense inside a tarball — once a package is
installed there is no base URL to serve from, and an agent isn't *crawling* the
files, it's reading them straight off disk at `node_modules/<pkg>/`. The right
shape for in-package docs is `AGENTS.md` at the package root: a single,
version-matched entry point that a coding agent (or your project's own root
`AGENTS.md`) can point at, which in turn links out to the flattened
`docs/*.md` topic files shipped beside it. Because it's bundled with the code,
it always matches the installed version and stays accurate as the package
updates — exactly what a consumer reading the package from disk needs. That's
why `leadtype generate --bundle` produces `AGENTS.md` + `docs/*.md` and tells
you to wire your README at `node_modules/<pkg>/AGENTS.md`.

# What `leadtype generate --bundle` deliberately skips, and why

In bundle mode leadtype writes only `AGENTS.md` and `docs/*.md`, and
deliberately omits the website-only artifacts that default (site) mode emits:

- **`llms.txt`** — a URL-addressed discovery file for hosted sites; there's no
  origin to serve it from inside a package, and `AGENTS.md` is the on-disk
  entry point instead.
- **`llms-full.txt`** — the root single-file context *fallback* for HTTP
  agents that can't follow links; unnecessary in a tarball where the agent can
  read the real `docs/*.md` files directly.
- **Search artifacts (`search-index.json` / `search-content.json`)** — a
  static BM25 index meant to be queried by a deployed search runtime/edge
  endpoint. There's no server or query runtime in an installed package, so the
  index is dead weight.
- **Sitemap / robots / agent-readability metadata (`sitemap.xml`,
  `sitemap.md`, `robots.txt`, `agent-readability.json`)** — these describe and
  govern crawling of a *published website* and are meaningless on disk.

All of these are tied to a live origin (a base URL, crawlers, or a search
backend). Shipping them in the tarball would only bloat the package with files
that can't function offline — so bundle mode keeps just the plain markdown an
agent actually reads locally.
