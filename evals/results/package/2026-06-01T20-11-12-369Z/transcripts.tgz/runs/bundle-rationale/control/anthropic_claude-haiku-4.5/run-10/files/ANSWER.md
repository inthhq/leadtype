# Why AGENTS.md, Not llms.txt, For npm Packages

`AGENTS.md` is the correct shape for docs inside an npm tarball because it uses **relative filesystem paths** to link to flattened markdown files (`./docs/<segment>/<slug>.md`), making the entire documentation tree work offline inside `node_modules/<pkg>/` after `npm install`. `llms.txt` is designed for **HTTP-served websites** with absolute URLs, making it unsuitable for tarball consumption. AGENTS.md lets coding agents read version-matched docs directly from disk without network access, the whole point of bundling.

## Website Artifacts Skipped in `--bundle` Mode

When you run `leadtype generate --bundle`, it deliberately omits:

- **`llms.txt` and `llms-full.txt`** — designed for HTTP agents fetching from a hosted docs site (e.g., `/llms.txt`, `/docs/llms.txt`), not for offline `node_modules` reading.
- **`search-index.json` and search-content.json`** — static search indexes meant for edge deployment on a docs site (`/docs/search-index.json`), not for package consumers to query locally.
- **`docs/sitemap.xml`, `docs/sitemap.md`, `docs/robots.txt`, and `agent-readability.json`** — HTTP/SEO artifacts for a website's root-level discovery and robot directives. Packages don't serve HTTP, so these have no meaning inside a tarball.

All these outputs only appear in default `leadtype generate` (site mode) because they're meant for served websites, not shipped packages.
