# Why AGENTS.md, Not llms.txt, for Package Bundles

`AGENTS.md` uses **relative filesystem paths** (`./docs/<segment>/<slug>.md`) that work inside a published npm tarball at `node_modules/<pkg>/AGENTS.md`, while `llms.txt` uses absolute URLs (`/docs/...`) designed for HTTP serving. When an agent or tool installs your package and reads `node_modules/<pkg>/AGENTS.md`, the file system paths resolve correctly to the adjacent `docs/` folder without requiring a running server or external HTTP calls. This makes bundled docs instant, offline-friendly, and version-matched to the installed package. The `generateAgentsMd` function explicitly returns relative paths; `generateLlmsTxt` does not.

## Artifacts Skipped in --bundle Mode

The `leadtype generate --bundle` command deliberately omits:

1. **`llms.txt` and `/docs/llms.txt`** — HTTP-style product and docs indexes designed for hosted sites with `Accept: text/markdown` negotiation.
2. **`llms-full.txt`** — A fallback full-context file for HTTP agents; irrelevant inside a tarball.
3. **Search artifacts** (`search-index.json`, `search-content.json`) — Require build-time indexing and runtime query infrastructure that doesn't exist in an offline npm package.
4. **Agent readability metadata** (`agent-readability.json`, `robots.txt`, `sitemap.xml`, `sitemap.md`) — These are site-level discovery and crawl-control files for web servers, not needed when docs are read directly from the filesystem.

Bundle mode writes only `AGENTS.md` and `docs/*.md` because packages ship offline; websites need the full indexing and HTTP machinery.
