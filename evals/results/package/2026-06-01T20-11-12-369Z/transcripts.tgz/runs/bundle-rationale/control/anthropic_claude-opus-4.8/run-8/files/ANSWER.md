# Bundled docs: `AGENTS.md`, not `llms.txt`

## 1. Why `AGENTS.md` is the right shape for docs inside an npm tarball

`llms.txt` is a *website* convention: it lives at a site root and is fetched
over HTTP by agents that hit a URL (e.g. `https://leadtype.dev/llms.txt`, or via
`Accept: text/markdown`). It describes a hosted, crawlable surface and assumes a
network round trip. None of that applies to a package on disk — after
`npm install`, there's no origin to fetch, no base URL, and no crawler; a coding
agent just opens files in `node_modules/<pkg>/`.

`AGENTS.md` is the on-disk convention for exactly that situation. leadtype
emits it at the package root (`node_modules/<pkg>/AGENTS.md`) alongside
`docs/*.md`, so it acts as a single, version-matched entry point that points the
agent at the flattened markdown topic files shipped in the same tarball. Because
it's a real file in the installed tree, it stays in lockstep with the installed
version (no risk of reading newer/older hosted docs), works offline, and is the
file a consuming project's own root `AGENTS.md` should reference (e.g. "read
`node_modules/leadtype/AGENTS.md` first"). That's why `leadtype generate --bundle`
produces `AGENTS.md` + `docs/*.md` and nothing website-shaped.

## 2. Website artifacts `leadtype generate --bundle` deliberately skips

In bundle (package) mode leadtype writes only `AGENTS.md` and `docs/*.md`. It
deliberately skips the website-only outputs that default `generate` (site mode)
produces:

- **`llms.txt`** — a site-root index keyed to a base URL; meaningless without a
  hosted origin to serve and link to.
- **`llms-full.txt`** — the single-file, whole-site fallback concatenation meant
  to be fetched from the site root; redundant on disk where the agent can read
  `AGENTS.md` and the individual `docs/*.md` files directly.
- **Search artifacts (`search-index.json` / `search-content.json`)** — the
  static BM25 search index is built to power a hosted docs UI's search box; a
  consumer reading files locally has no search runtime, so shipping the index
  just bloats the tarball.
- **Sitemap / robots / agent-readability metadata (`sitemap.xml`, `sitemap.md`,
  `robots.txt`, the agent-readability manifest)** — crawler- and SEO-oriented
  artifacts that describe URLs on a website. They have no meaning inside a
  package and reference base URLs that don't exist on disk.

All of these are URL- and crawler-centric, so they belong to the hosted site
output, not the npm tarball. Excluding them keeps the published package small
and free of stale, network-assuming files.
