# Why `AGENTS.md`, not `llms.txt`, for docs shipped inside an npm tarball

An `llms.txt` file is a *website* convention: it lives at a known, fetchable URL (`https://yoursite/llms.txt`) and is meant for HTTP agents that crawl a hosted docs site. It is a discovery manifest of absolute links back to the site. None of that makes sense inside a tarball — after `npm install`, the package sits on disk at `node_modules/<pkg>/` with no base URL, no server, and no crawler. A coding agent reading the installed package needs a single, predictable on-disk entry point, not a list of URLs to fetch. That's exactly the shape `AGENTS.md` provides: it lands at the package root (`node_modules/leadtype/AGENTS.md`), points at the version-matched local `docs/*.md` mirrors that shipped alongside it, and is the conventional file coding agents already look for. Because it's bundled with the code, it stays in lockstep with the installed version — no risk of reading docs for a different release than the one on disk. That's why `leadtype generate --bundle` emits `AGENTS.md` + `docs/*.md` for packages, and reserves `llms.txt` for site mode.

# What `leadtype generate --bundle` deliberately skips, and why

In bundle mode `leadtype` writes only `AGENTS.md` and `docs/*.md`, and deliberately skips the website-only artifacts that the default site mode produces:

- **`llms.txt`** and the root **`llms-full.txt`** — link-manifest / concatenated-context files keyed to a hosted site's base URL; they're served and fetched over HTTP, not read from `node_modules`.
- **`docs/search-index.json`** (and the companion `search-content.json`) — the static BM25 search index that powers an edge-served search endpoint on the website. A consumer reading docs locally queries the markdown files directly, so a prebuilt search index is dead weight.
- **`sitemap.xml`, `sitemap.md`, and `robots.txt`** (plus the `agent-readability.json` manifest) — crawler/SEO and HTTP-agent-discovery metadata that only matter for a live URL.

These all exist to make a *deployed website* discoverable and searchable by browsers and HTTP agents. Inside a package they would be unusable (they encode a base URL that doesn't exist on disk) and would just bloat the published tarball, so the bundle output omits them and keeps the version-matched `AGENTS.md` + flattened markdown that an installed-package reader actually needs.
