# Bundling docs inside the `leadtype` npm tarball

## Why `AGENTS.md`, not `llms.txt`

`llms.txt` is a *website* convention: it's a root-served file fetched over HTTP (e.g. `https://yoursite.dev/llms.txt`) whose link list points at absolute URLs. That shape only works when something is serving the docs. Inside a published tarball there is no server — the files just sit on disk at `node_modules/leadtype/`, so any absolute URL or `/llms.txt`-style entry point is meaningless to a coding agent reading the installed package. `leadtype`'s `generateAgentsMd` exists precisely for this case: it emits `AGENTS.md` at the package root where every link is a **relative filesystem path** (`./docs/<segment>/<slug>.md`), so the doc set is navigable offline straight from `node_modules/leadtype/AGENTS.md`. It is also version-matched — consumers get the docs that correspond to the exact version they installed, rather than whatever a hosted `llms.txt` happens to be serving today. `AGENTS.md` is additionally the emerging cross-tool convention for "agent, read this first," so a project's own root `AGENTS.md` can simply redirect agents to the bundled one.

## What `leadtype generate --bundle` deliberately skips, and why

The `--bundle` mode emits only `AGENTS.md` plus the flattened `docs/*.md` mirrors. It intentionally omits the website-only artifacts that default `leadtype generate` produces:

- **`llms.txt` and `docs/llms.txt`** — server-served discovery indexes built around absolute base-URL links; there's nothing serving them in a tarball, so their entry-point role doesn't apply offline.
- **Root `llms-full.txt`** — the concatenated full-context fallback meant to be fetched as a single HTTP request; on disk it's just a large duplicate of the per-page `docs/*.md` files, bloating the package for no benefit.
- **`docs/search-index.json`** (and the agent-readability `robots.txt` / `sitemap.md` / `sitemap.xml` discovery artifacts) — these power an *edge-served* search runtime and crawler discovery for a hosted site. An installed package isn't crawled and has no search endpoint, so shipping the index only adds weight.

In short, those files assume an HTTP origin (absolute URLs, crawler discovery, an edge search endpoint). None of that exists for a package read from `node_modules`, so `--bundle` keeps the tarball lean by shipping only the relative-linked `AGENTS.md` and its markdown topic files.
