# Why AGENTS.md, Not llms.txt, for npm Packages

`AGENTS.md` is the right shape for docs shipped *inside* an npm tarball because it uses **relative filesystem paths** (`./docs/<segment>/<slug>.md`) instead of absolute URLs. When a consumer runs `npm install`, they read the bundled docs from `node_modules/<package>/AGENTS.md`, which then links to `./docs/*.md` files in the same directory. These relative paths work offline and immediately, without needing an HTTP server or base URL. `llms.txt`, by contrast, contains absolute URLs intended for a hosted website where HTTP agents fetch `/docs/...` or `/llms.txt` endpoints. Inside a tarball, those URLs are meaningless.

## Files That `--bundle` Deliberately Skips

The `leadtype generate --bundle` mode skips website-only artifacts: `llms.txt`, `llms-full.txt`, `sitemap.xml`, `sitemap.md`, `robots.txt`, and `search-index.json`. These don't belong in a package because they're designed for HTTP discovery and server routing—agents reach them by making web requests to `/llms.txt`, `/sitemap.xml`, `/robots.txt`, and `/search-index.json`. A published npm package lives on the filesystem, not a web server, so these server-bound discovery layers are pointless. The root `AGENTS.md` file replaces them, acting as the filesystem-local entry point that offline agents read directly from disk.
