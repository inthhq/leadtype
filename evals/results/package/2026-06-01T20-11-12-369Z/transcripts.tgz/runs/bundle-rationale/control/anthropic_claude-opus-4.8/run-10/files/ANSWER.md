# Why `AGENTS.md`, not `llms.txt`, belongs inside the tarball

`llms.txt` is a **website convention**: it's a fetched-over-HTTP entry point that lives at a site's root (e.g. `https://yoursite.dev/llms.txt`) and points at *absolute URLs* for an agent to crawl. Inside an npm tarball there is no host, no base URL, and no network step — the consumer has already `npm install`ed the package, so the docs sit on disk at `node_modules/<pkg>/`. The right shape there is `AGENTS.md`: a single, version-matched, on-disk entry point that a coding agent reads directly and that links to sibling `docs/*.md` files by relative path. That's exactly what `leadtype generate --bundle` emits (`AGENTS.md` + `docs/*.md`), and the documented setup is to have the consuming project's root `AGENTS.md` point at `node_modules/<pkg>/AGENTS.md`. Because it ships with the package, it stays accurate as the package version changes, whereas a hosted `llms.txt` can drift from whatever version a project actually installed.

# What `leadtype generate --bundle` deliberately skips, and why

In bundle (package) mode, `leadtype` skips the website-only artifacts that default site mode produces — per the CLI's own usage text, it "skips llms.txt, llms-full.txt, and search artifacts — those are website-only." Concretely the omitted artifacts are:

- **`llms.txt`** — a root-served, URL-based index that assumes a `--base-url` and HTTP fetching; meaningless on disk inside a tarball.
- **`llms-full.txt`** — the single-file "everything concatenated" fallback meant to be fetched from a hosted site; redundant when the agent can already read the local `docs/*.md` files.
- **Search artifacts** (`search-index.json` / `search-content.json`, plus the agent-readability manifest, `sitemap.xml`, `sitemap.md`, and `robots.txt`) — these power a static, edge-served search runtime and crawler/SEO metadata for a deployed website. They carry a base URL, add weight to every install, and have no role inside a package consumed offline.

In short, anything that presupposes a hosted origin (a base URL, HTTP fetching, crawling, or search serving) is left out of the bundle so the package ships only the lean, relative-linked `AGENTS.md` + `docs/*.md` that an agent reads straight from `node_modules`.
